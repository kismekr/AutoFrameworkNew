package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class GroupLookUpPageObjects {
	public static String keywordTextBox = "xpath#//input[@id='userGroupLookupForm:userGroupKeyword']";
	public static String searchButton = "xpath#//button[@id='userGroupLookupForm:findButtonForGroup']";
	public static String clearButton = "xpath#//button[@id='userGroupLookupForm:groupClear']";
	public static String okButton = "xpath#//button[@id='userGroupLookupForm:okButtonBottomForGroup']";
	public static String cancelButton = "xpath#//button[@id='userGroupLookupForm:cancelButtonBottomForGroup']";
	
	public static String selectData = "xpath#//*[text()='%data%']/ancestor::tr/td/div/div/span";
	
	// Select Group Data from Search Result
    public static String selectGroupData(String data) {
        String value = selectData.replace("%data%", data);
        return value;
    }
}
