package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FDE_CausalityPageObjects {

	public static String blindedButton = "xpath#//button[text()='Switch to Blinded']";
	public static String unblindedButton = "xpath#//button[text()='Switch to Unblinded']";
	public static String productDropdown = "xpath#//span[@class='tableHeaderCol']/p-dropdown/div";
	public static String productList = "xpath#//div[contains(@class,'ng-trigger ng-trigger-overlayAnimation')]/div/ul/li/div";
	public static String productGetText = "xpath#(//div[contains(@class,'ng-trigger ng-trigger-overlayAnimation')]/div/ul/li/div)[{0}]";
	public static String AESI_CheckBox = "AESI";
	public static String checkBoxUnder = "xpath#//table/thead[@class='ui-table-thead']/tr[2]/th[text()='{0}']//ancestor::div//div//td[8]/p-checkbox/div/div[2]";
	public static String e2BCausalityLink = "xpath#//span[@class='agCasPanelHeader']//a[contains(text(),'E2B Causality')]";
	public static String e2BCausalityAddLink = "xpath#//span[@class='agAddDeleteBlock']//a[contains(text(),'Add')]";
	public static String result_Dropdown = "xpath#//select[contains(@name,'e2bCausResult')]";
	public static String Reporter_Dropdown = "xpath#//tbody//td[2]//p-dropdown//span[contains(text(),'Select')]";
	public static String Company_Dropdown = "xpath#//tbody//td[3]//p-dropdown//span[contains(text(),'Select')]";
	public static String Rechallenge_Dropdown = "xpath#//tbody//p-dropdown//div//div//input[contains(@id,'causalityRechallenge')]/parent::div/parent::div//span[contains(text(),'Select')]";
	public static String Dechallenge_Dropdown = "xpath#//tbody//p-dropdown//div//div//input[contains(@id,'causalityDechallenge')]/parent::div/parent::div//span[contains(text(),'Select')]";
	public static String clicksource_Dropdown = "xpath#(//p-table[@styleclass='agCasualityTable']/div/div/table/tbody/tr[{0}]/td/span/p-dropdown/div)[1]";
	public static String clickReportTerm_Dropdown = "xpath#(//p-table[@styleclass='agCasualityTable']/div/div/table/tbody/tr/td[2]/p-dropdown//label)[1]";
	public static String set_Dropdown = "xpath#//ul[contains(@class,'ui-dropdown-items')]/child::li/div/span[contains(text(),'%s')]";
	public static String setReportTerm_Dropdown = "xpath#//ul[contains(@class,'ui-dropdown-items')]/child::li/span[contains(text(),'%s')]";
	public static String clickmethod_Dropdown = "xpath#(//p-table[@styleclass='agCasualityTable']/div/div/table/tbody/tr[{0}]/td/span/p-dropdown/div)[2]";
	public static String clickresul_Dropdown = "xpath#(//p-table[@styleclass='agCasualityTable']/div/div/table/tbody/tr[{0}]/td/span/p-dropdown/div)[3]";
	public static String clickSecondCausality = "xpath#//i[contains(@class,'pi pi-caret-right')]";
	public static String ActionTakenWithDrug = "xpath#//span[contains(text(),'Action taken with the drug')]/following-sibling::span/label";
	public static String e2bAdd_Button = "xpath#//a[contains(text(),'Add')]";
	public static String e2bRecord = "xpath#//label[@class='causReactionLabel']";
	public static String AccessRelationShip_Dropdown="xpath#//tbody//td[4]//p-dropdown//span[contains(text(),'Select')]";
	
	
	public static String companyCasuality = "xpath#//thead/tr[2]//following::tbody/tr/td[3]/span/p-dropdown/div";
	public static String endLatencyLabel = "xpath#//th[text()='End Latency ']";
	public static String getCompanyCasuality = "xpath#(//thead[@class='ui-table-thead']/tr/following::tr/th[text()='Company causality ']//following::tbody/tr/td[3]/span/p-dropdown/div)[{%count%}]";
	public static String AESICheckboxChecked = "xpath#//table/thead[@class='ui-table-thead']/tr[2]//ancestor::div//div//td[8]/p-checkbox/div/div[2]/span[contains(@class,'ui-chkbox-icon ui-clickable pi pi-check')]";

	public static String confirmationPopup = "xpath#//span[@class='ui-confirmdialog-message']";
	public static String confirmPOPupNoBtn = "xpath#//span[@class='ui-button-text ui-clickable'][text()='No']";
	public static String startLatency_CheckBoxUnder = "xpath#//table/thead[@class='ui-table-thead']/tr[2]/th[text()='Manual']//ancestor::div//div//td[12]/p-checkbox/div/div[2]";
	public static String Causality_StartLatency = "xpath#//input[@id='causStartLatency_0']";
	public static String startLatencyUnit_Dropdown = "xpath#//select[contains(@name,'causStartLatencyUnit_0')]";

	public static String endLatency_CheckBoxUnder = "xpath#//table/thead[@class='ui-table-thead']/tr[2]/th[text()='Manual']//ancestor::div//div//td[15]/p-checkbox/div/div[2]";
	public static String Causality_EndLatency = "xpath#//input[@id='causEndLatency_0']";
	public static String EndLatencyUnit_Dropdown = "xpath#//input[@id='causEndLatencyUnit_0']";

	// R2 Tags
	public static String R2Actiontakenwiththedrug = "xpath#//label[text()='[B.4.K.16]']";
	public static String R2Rechallenge = "xpath#//label[text()='[B.4.K.17.1]']";
	public static String R2StartLatency = "xpath#//label[text()='[B.4.K.13.1A/B]']";
	public static String R2EndLatency = "Xpath#//label[text()='[B.4.K.13.2A/B]']";

	// R3 Tags
	public static String R3Actiontakenwiththedrug = "xpath#//label[text()='[G.K.8]']";
	public static String R3Rechallenge = "xpath#//label[text()='[G.K.9.I.4]']";
	public static String R3StartLatency = "xpath#//label[text()='[G.K.9.I.3.1A/B]']";
	public static String R3EndLatency = "xpath#//label[text()='[G.K.9.I.3.2A/B]']";

	// Codelist Tags
	public static String CLReportercausality = "xpath#//th[text()='Reporter causality ']//parent::th/label[text()='[9062]']";
	public static String CLCoumpanycausality = "xpath#//th[text()='Company causality ']//parent::th/label[text()='[9062]']";
	public static String CLDechallenge = "xpath#//label[text()='[1027]']";
	public static String CLRechallenge = "xpath#//label[text()='[9054]']";
	public static String CLStartLatency = "xpath#//th[text()='Start Latency ']//parent::th/label[text()='[1017]']";
	public static String CLEndLatency = "xpath#//th[text()='End Latency ']//parent::th/label[text()='[1017]']";

	public static String Rep_Dropdown = "xpath#(//tbody//td[2]//p-dropdown//span[contains(text(),'Select')])[%count%]";
	public static String Com_Dropdown = "xpath#(//tbody//td[3]//p-dropdown//span[contains(text(),'Select')])[%count%]";
	public static String Rechallen_Dropdown = "xpath#(//tbody//td[6]//p-dropdown//span[contains(text(),'Select')][%count%]";
	public static String Dechallen_Dropdown = "xpath#(//tbody//td[5]//p-dropdown//span[contains(text(),'Select')][%count%]";

	public static String addDropdownitem = "xpath#//li[contains(@class,'ng-star-inserted')]/descendant::span[starts-with(normalize-space(text()),'%s')]";
	public static String AESIManualCheckBox="xpath#(//th[text()='AESI']/ancestor::div[@class='ui-table-wrapper ng-star-inserted']//tbody//td//p-checkbox)[3]";
	public static String AESIManualNoCheckBox="xpath#//select[contains(@name,'causalityDechallenge')]/ancestor::p-dropdown/parent::td/preceding-sibling::td//p-checkbox//div[2]";
	public static String AccessRelationShipCheckBox="xpath#(//th[text()='AESI']/ancestor::div[@class='ui-table-wrapper ng-star-inserted']//tbody//td//p-checkbox)[1]";
	public static String AccessRelationShipCheckBoxClick="xpath#(//th[text()='AESI']/ancestor::div[@class='ui-table-wrapper ng-star-inserted']//tbody//td//p-checkbox//div//span)[1]";
	public static String AESICheckbx="xpath#(//th[text()='AESI']/ancestor::div[@class='ui-table-wrapper ng-star-inserted']//tbody//td//p-checkbox//div//span)[2]";
	public static String UnSelectedARDropDown="xpath#//input[contains(@id,'causalityAssessRelationship') and 'disabled']//parent::div/parent::div";
	//added by rashmi
	public static String Reporter_DropdownWithRow = "xpath#//tr[%s]/td/label/span/../../following-sibling::td/span/p-dropdown/div//label/span";
	public static String Company_DropdownWithRow="xpath#//tr[%s]/td/label/span/../../following-sibling::td[2]/span/p-dropdown/div//label/span";
	public static String Rechallenge_DropdownWithRow = "xpath#//tbody//tr[%s]//p-dropdown//div//div//input[contains(@id,'causalityRechallenge')]/parent::div/parent::div//span[contains(text(),'Select')]";
	public static String Dechallenge_DropdownWithRow = "xpath#//tbody//tr[%s]//p-dropdown//div//div//input[contains(@id,'causalityDechallenge')]/parent::div/parent::div//span[contains(text(),'Select')]";
	
	
	
	public static String selectDropdown(String label) {
		String value = addDropdownitem.replace("%s", label);
		return value;
	}

	public static String productGetText(String num) {
		String value = productGetText.replace("{0}", num);
		return value;

	}
	
	
	public static String selectReporterDropdown(String label) {
		String value = Reporter_DropdownWithRow.replace("%s", label);
		return value;
	}
	
	public static String selectCompanyDropdown(String label) {
		String value = Company_DropdownWithRow.replace("%s", label);
		return value;
	}
	
	public static String selectRechallengeDropdown(String label) {
		String value = Rechallenge_DropdownWithRow.replace("%s", label);
		return value;
	}
	
	public static String selectDechallengeDropdown(String label) {
		String value = Dechallenge_DropdownWithRow.replace("%s", label);
		return value;
	}


	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author: Avinash k
	 * @Date : 30-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String resultLocator = null;

	public static String checkBoxUnder(String checkBoxLabel) {
		String actualLocator = checkBoxUnder;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}

	// Click Dropdown value
	public static String clicksource_Dropdown(String row) {
		String value = clicksource_Dropdown.replace("{0}", row);
		return value;
	}

	// Set Dropdown value
	public static String set_Dropdown(String row, String Value) {
		String actual = set_Dropdown;
		String temp = actual.replace("{0}", row);
		String result = temp.replace("%s", Value.trim());
		return result;
	}

	// Click Dropdown value
	public static String clickmethod_Dropdown(String row) {
		String value = clickmethod_Dropdown.replace("{0}", row);
		return value;
	}

	// Click Dropdown value
	public static String clickresul_Dropdown(String row) {
		String value = clickresul_Dropdown.replace("{0}", row);
		return value;
	}

	public static String clickReportTerm_Dropdown(String row) {
		String value = clickReportTerm_Dropdown.replace("{0}", row);
		return value;
	}

	public static String setReportTerm_Dropdown(String row, String Value) {
		String actual = setReportTerm_Dropdown;
		String temp = actual.replace("{0}", row);
		String result = temp.replace("%s", Value.trim());
		return result;
	}

	/**********************************************************************************************************
	 * @Objective:get companyCasuality name by passing input Parameters:rowNum
	 *                Output
	 * @Parameters: Case data attribute value
	 * @author:Pooja S Date :08-May-2020 Updated by and when
	 **********************************************************************************************************/
	public static String indexCount(String count) {
		String value = getCompanyCasuality;
		String value2;
		value2 = value.replace("{%count%}", count);
		return value2;
	}
}
