package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import org.openqa.selenium.By;

public abstract class SystemAdministrationPageObjects {
	
	public static String sessionUserLink  = "xpath#//span[contains(text(),'Session user')]";
	public static String sessionUserLabel = "xpath#//label[@id='sessionUserInfoForm:sessionuserinfolabel']";
	public static String activeSessionsLink = "xpath#//span[contains(text(),'Active sessions')]";
	public static String activeSessionsLabel = "xpath#//label[@id='activeSessionForm:mainLineId']";
	public static String lockInfoLink = "xpath#//span[contains(text(),'Lock info')]";
	public static String lockInfoLabel= "xpath#//div[@class='CaseList_Title']/Label[text()='Lock Info']";
	public static String applicationParametersLink = "xpath#//span[contains(text(),'Application parameters')]";
	public static String applicationParametersLabel = "xpath#//input[@id='applicationParameterForm:companyName']";
	
	public static String general_Link  = "xpath#//a[@id = 'applicationParameterForm:generalLink']";
	public static String caseManagement_Link  = "xpath#//a[@id = 'applicationParameterForm:adverseEventLink']";
	public static String callLog_Link  = "xpath#//a[@id = 'applicationParameterForm:callLogLink']";
	public static String submission_Link  = "xpath#//a[@id = 'applicationParameterForm:submissionLink']";
	public static String complaint_Link  = "xpath#//a[@id = 'applicationParameterForm:complaintLink']";
	public static String centralCoding_Link  = "xpath#//a[@id = 'applicationParameterForm:centralCodingLink']";
	public static String dms_Link  = "xpath#//a[@id = 'applicationParameterForm:dmsLink']";
	public static String externalApplication_Link  = "xpath#//a[@id = 'applicationParameterForm:externalApplicationLink']";
	public static String medDRASettings_Link  = "xpath#//a[@id = 'applicationParameterForm:medDRALink']";
	public static String nlpSettings_Link  = "xpath#//a[@id = 'applicationParameterForm:nlplink']";
	
	
	public static String applicationID_TextBox = "xpath#//input[@id ='applicationParameterForm:eaapplicationid']";	
	public static String save_Button = "xpath#//button[@id = 'applicationParameterForm:visibleSave']";
	
	public static String impreciseDateForAutoCalculation_CheckBox = "Consider Imprecise Date for Auto Calculation rules";
	public static String configurationLabel = "xpath#//div/label[contains(text(),'%s')]";
	
	public static String ackTitle_Label = "xpath#//div/span[@id='mandatoryDialogform:mandatoryID_title']";
	public static String ackInfo_label = "xpath#//td/label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String ackOK_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']/span[text()='OK']";
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to identify a config label.
	 * @InputParameters: Label value
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 11-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String configurationLabel(String label) {
		String value = configurationLabel.replace("%s", label);
		return value;
	}
}
