package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FAQPageObjects {

	public static String FAQ = "xpath#//div[contains(@id,'headerForm')][@role='menubar']/ul/li/a/span[text()='FAQ']";
	public static String FAQListing="xpath#//a[@id='headerForm:faqListId']";
	public static String basicSearch = "xpath#//input[@id='faqListForm:searchFieldId']";
	
}
