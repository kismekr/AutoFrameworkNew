package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_CaseDocumentsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.Lib_AlwaysSeriousEvent_PageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.Lib_IMEDME_PageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.LibrariesPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.PharmacologicalClassPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.StudyPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.TherapeuticAreaPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Libraries_IMEDME_Management  extends ToolManager{
	static String className = Libraries_IMEDME_Management.class.getSimpleName();
	static boolean status;
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to search IME DME Events.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 05-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void search(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(Lib_IMEDME_PageObjects.clickeventversion_Dropdown);
		agClick(Lib_IMEDME_PageObjects.eventVersion(getTestDataCellValue(scenarioName, "IMEDMEEventVersion")));
		agSetStepExecutionDelay("2000");
		agSetValue(Lib_IMEDME_PageObjects.keywordSearch_Textbox, getTestDataCellValue(scenarioName, "PTTerm"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(Lib_IMEDME_PageObjects.search_Icon);
		agSetStepExecutionDelay("3000");
		agIsVisible(Lib_IMEDME_PageObjects.paginator);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Search is successful", true);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify IS DME Pt term in listing screen
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :05-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Boolean verifysearchData(String scenarioName) {
	   Boolean falg =false;
		String paginator = agGetText(Lib_IMEDME_PageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
     List<WebElement> list = agGetElementList(Lib_IMEDME_PageObjects.get_ListofIMEDMEEvents);
		String columnHeader = null;
		for (int j = 1; j <= list.size(); j++) {			
			columnHeader = agGetText(Lib_IMEDME_PageObjects.columnHeaderList(Integer.toString(j)));
			if (getTestDataCellValue(scenarioName, "PTTerm").equalsIgnoreCase(columnHeader)) {
				 falg = true;
				 break;
		}}}
		 System.out.println(falg);
       return falg; 
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to create IME Event.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :05-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createIMEDMEEvent(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(Lib_IMEDME_PageObjects.imeDME_Lable);
		agClick(Lib_IMEDME_PageObjects.imeDMEEventMedDRAPTTerm_lookup);
		agSetValue(Lib_IMEDME_PageObjects.dictionaryCodingBrowser_SearchTxtfield, getTestDataCellValue(scenarioName, "SearchTerm"));
		agClick(Lib_IMEDME_PageObjects.dictionaryCodingBrowser_SearchBtn);
		agSetStepExecutionDelay("5000");
		agClick(Lib_IMEDME_PageObjects.dictionaryCodingBrowser_OkBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetStepExecutionDelay("5000");
		
		if(getTestDataCellValue(scenarioName, "Active").equalsIgnoreCase("Uncheck"))
		{
				agClick(Lib_IMEDME_PageObjects.checkbox(Lib_IMEDME_PageObjects.activeCheckbox));
		}
		
if(getTestDataCellValue(scenarioName, "IsIME").equalsIgnoreCase("Check"))
{
		agClick(Lib_IMEDME_PageObjects.checkbox(Lib_IMEDME_PageObjects.isIME_Checkbox));
}

if(getTestDataCellValue(scenarioName, "IsDME").equalsIgnoreCase("Check"))
{
		agClick(Lib_IMEDME_PageObjects.checkbox(Lib_IMEDME_PageObjects.isDME_Checkbox));
	}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.setListDropDownValue(Lib_IMEDME_PageObjects.typeDropdown, getTestDataCellValue(scenarioName, "Type"));
		agSetValue(Lib_IMEDME_PageObjects.comment_Textbox, getTestDataCellValue(scenarioName, "Comment"));
        agJavaScriptExecuctorClick(Lib_IMEDME_PageObjects.saveButton);
        CommonOperations.setAuditInfo(scenarioName);
		agIsVisible(LibrariesPageObjects.imeKeywordSearch);
        Reports.ExtentReportLog("", Status.INFO,"IME/DME Management Listing screen is displayed", true);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify IME DME Event.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :05-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyIMEDMEEvent(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(Lib_IMEDME_PageObjects.edit_Icon);
		agSetStepExecutionDelay("3000");
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PTTerm"), Lib_IMEDME_PageObjects.get_IMDMEEventMedDRAPTTerm);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MedDRAPTCode"), Lib_IMEDME_PageObjects.get_MedDRAPTCode);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "SOCName"), Lib_IMEDME_PageObjects.get_SOCName);
		CommonOperations.verifyCheckBoxUnder(Lib_IMEDME_PageObjects.active_checkbox, getTestDataCellValue(scenarioName,"Active"));
		CommonOperations.verifyCheckBoxUnder(Lib_IMEDME_PageObjects.isDME_Checkbox, getTestDataCellValue(scenarioName,"IsDME"));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Type"), Lib_IMEDME_PageObjects.typeDropdown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Comment"), Lib_IMEDME_PageObjects.comment_Textbox);
		CommonOperations.takeScreenShot();
		agClick(Lib_IMEDME_PageObjects.cancelButton);
		agSetStepExecutionDelay("3000");
		agIsVisible(Lib_IMEDME_PageObjects.paginator);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to search IME DME Event.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :05-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreateIMEDMEEvent(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		if(verifysearchData(scenarioName)==true ) {
			Reports.ExtentReportLog("", Status.PASS, "IME DME Event already exists!" , true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "PTTerm"), Lib_IMEDME_PageObjects.get_PtTerm);	
		}
		else
		{
			agClick(Lib_IMEDME_PageObjects.new_Btn);
			createIMEDMEEvent(scenarioName);
			search(scenarioName);
			verifyIMEDMEEvent(scenarioName);
		}
	}
	
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to IME DME Event.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :13-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createIMEDME(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(Lib_IMEDME_PageObjects.new_Btn);
		createIMEDMEEvent(scenarioName);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to download Template
	 *             export to excel.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 26-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportToexcel(String FileName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		
		agClick(Lib_IMEDME_PageObjects.downloadTemplate_Btn);
		agWaitTillVisibilityOfElement(TherapeuticAreaPageObjects.export_Btn);
			CommonOperations.move_Downloadedexcel(FileName);
			agClick(PharmacologicalClassPageObjects.exportexcelcancel_Button);
		} 
	
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Import Template
	 *             export to excel.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 13-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void importTemplate(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(Lib_IMEDME_PageObjects.import_btn);
	agSetStepExecutionDelay("5000");
	agUploadDocuments(lsmvConstants.LSMV_testDataInput + "\\"
			+ getTestDataCellValue(scenarioName, "FileName"));
	agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	agSetStepExecutionDelay("8000");
	agAssertContainsText(Lib_IMEDME_PageObjects.validationPopup_Btn, "Excel is successfully imported");
	agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Excel is successfully imported", true);
	agClick(Lib_IMEDME_PageObjects.validationOK_Btn);
	Reports.ExtentReportLog("", Status.INFO, "Excel is successfully imported", true);
	agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to download Template
	 *             export to excel.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 26-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downloadTemplate(String FileName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		
		agClick(Lib_IMEDME_PageObjects.downloadTemplate_Btn);
		
		int i = 0, sz = agGetWindowCount();
		agSetStepExecutionDelay("5000");
		while (!(sz == 2) && i < 75) {
			sz = agGetWindowCount();
			i++;
			System.out.println("Waiting" + i);
		}
		agGetCurrentWindow();
		agSetStepExecutionDelay("3000");
		
		try {
			Thread.sleep(8000);
		} catch (InterruptedException e) // Hard wait is used reason file to get download taking time
		{
			e.printStackTrace();

		}
		Reports.ExtentReportLog("", Status.INFO, "Download Template", true);
		
			CommonOperations.move_Downloadedexcel(FileName);
			agCloseCurrentWindow();
			agGetWindowControlByInstance(1);
			
			
		} 
}