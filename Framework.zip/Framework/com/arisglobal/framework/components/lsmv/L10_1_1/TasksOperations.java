package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1.CommonOperations;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.TasksPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class TasksOperations extends ToolManager {
	public static WebElement webElement;
	static String className = TasksOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below Method is create to the perform menu navigations in
	 *             tasks Module
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void menuNavigation(String menu) {

		agMouseHover(TasksPageObjects.tasksHover);
		agClick(menu);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in tasks
	 *             Module and verify the label name.
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void tasksNavigations(String menu) {
		switch (menu) {
		case "taskNew":
			menuNavigation(TasksPageObjects.tasksNew);
			status = agIsVisible(TasksPageObjects.commentsTextarea);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to task New is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to task New is Unsuccessfull", true);
			}
			break;
		case "taskListing":
			menuNavigation(TasksPageObjects.tasksListing);
			status = agIsVisible(TasksPageObjects.tasksListingKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to task Listing is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to task Listing is Unsuccessfull", true);
			}
			break;
		default:
			System.out.println("Invalid Menu Link!");
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to enter Basic Details of a task.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 6-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void enterBasicTaskDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		// setCreatedDate(CommonOperations.returnDateTime(getTestDataCellValue(scenarioName,
		// "Tasks_New_CreatedDate")));
		setDatesCalender(CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Tasks_New_CreatedDate")),
				TasksPageObjects.createdDateLabel);
		agSetStepExecutionDelay("2000");
		CommonOperations.setListDropDownValue(TasksPageObjects.relatedModuleDropdown,
				getTestDataCellValue(scenarioName, "Tasks_New_RelatedModule"));
		CommonOperations.setListDropDownValue(TasksPageObjects.caseTaskTypeDropdown,
				getTestDataCellValue(scenarioName, "Tasks_New_CaseTaskType"));

		agSetValue(TasksPageObjects.commentsTextarea, getTestDataCellValue(scenarioName, "Tasks_New_Comments"));

		CommonOperations.setListDropDownValue(TasksPageObjects.priorityDropdown,
				getTestDataCellValue(scenarioName, "Tasks_New_Priority"));
		CommonOperations.setListDropDownValue(TasksPageObjects.taskStatusDropdown,
				getTestDataCellValue(scenarioName, "Tasks_New_TaskStatus"));

		agJavaScriptExecuctorScrollToElement(TasksPageObjects.replyStatusDropdown);
		CommonOperations.takeScreenShot();
		CommonOperations.setListDropDownValue(TasksPageObjects.replyStatusDropdown,
				getTestDataCellValue(scenarioName, "Tasks_New_ReplyStaus"));

		setDatesCalender(CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Tasks_New_ReplyDate")),
				TasksPageObjects.replyDateLabel);
		setDatesCalender(CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Tasks_New_ScheduledDate")),
				TasksPageObjects.scheduledDateLabel);
		setDatesCalender(
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Tasks_New_ActualCompletionDate")),
				TasksPageObjects.actualCompletionDateLabel);

		Reports.ExtentReportLog("", Status.INFO, "Basic Details of task entered", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to verify Basic Details of a task.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 7-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyBasicTaskDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agJavaScriptExecuctorScrollToElement(TasksPageObjects.createdDateTextbox);
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Tasks_New_CreatedDate")),
				TasksPageObjects.createdDateTextbox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Tasks_New_RelatedModule"),
				TasksPageObjects.relatedModuleDropdown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Tasks_New_CaseTaskType"),
				TasksPageObjects.caseTaskTypeDropdown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Tasks_New_Comments"),
				TasksPageObjects.commentsTextarea);

		agCheckPropertyText(getTestDataCellValue(scenarioName, "Tasks_New_Priority"),
				TasksPageObjects.priorityDropdown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Tasks_New_TaskStatus"),
				TasksPageObjects.taskStatusDropdown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Tasks_New_ReplyStaus"),
				TasksPageObjects.replyStatusDropdown);

		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Tasks_New_ReplyDate")),
				TasksPageObjects.replyDateTextbox);
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Tasks_New_ScheduledDate")),
				TasksPageObjects.scheduledDateTextbox);
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Tasks_New_ActualCompletionDate")),
				TasksPageObjects.actualCompletionDateTextbox);

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to enter Distribution Contact Details of a
	 *             task.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 6-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void enterDistributionContactDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		CommonOperations.setListDropDownValue(TasksPageObjects.authorityDropdown,
				getTestDataCellValue(scenarioName, "Tasks_New_Authority"));
		CommonOperations.setListDropDownValue(TasksPageObjects.contactDropdown,
				getTestDataCellValue(scenarioName, "Tasks_New_Contact"));
		Reports.ExtentReportLog("", Status.INFO, "Distribution Contact Details of task entered", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to verify Distribution Contact Details of a
	 *             task.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 7-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDistributionContactDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agJavaScriptExecuctorScrollToElement(TasksPageObjects.authorityDropdown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Tasks_New_Authority"),
				TasksPageObjects.authorityDropdown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Tasks_New_Contact"), TasksPageObjects.contactDropdown);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to enter remainder Details of a task.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 6-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void enterRemainderDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorScrollToElement(TasksPageObjects.uploadButton);
		setDatesCalender(
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Tasks_New_PlannedCompletionDate")),
				TasksPageObjects.plannedCompletionDateLabel);
		agSetStepExecutionDelay("2000");
		setDatesCalender(CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Tasks_New_ReminderOn")),
				TasksPageObjects.remainderOnDateLabel);

		Reports.ExtentReportLog("", Status.INFO, "Remainder Details of task entered", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to verify remainder Details of a task.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 7-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyRemainderDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(TasksPageObjects.plannedCompletionDateTextbox);
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Tasks_New_PlannedCompletionDate")),
				TasksPageObjects.plannedCompletionDateTextbox);
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Tasks_New_ReminderOn")),
				TasksPageObjects.remainderOnDateTextbox);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to enter Document Details of a task.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 6-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void enterDocmentDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agJavaScriptExecuctorScrollToElement(TasksPageObjects.uploadButton);
		setDocumentUpload(scenarioName);
		agSetValue(
				TasksPageObjects
						.docsDescriptionTextbox(getTestDataCellValue(scenarioName, "Tasks_Document_UploadFileName")),
				getTestDataCellValue(scenarioName, "Tasks_Document_Description"));

		Reports.ExtentReportLog("", Status.INFO, "Document Details of task entered", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to verify remainder Details of a task.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 7-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDocmentDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agJavaScriptExecuctorScrollToElement(TasksPageObjects.uploadButton);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Tasks_Document_Description"),
				TasksPageObjects.docsDescriptionTextbox(getTestDataCellValue(scenarioName, "Tasks_New_Document")));

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to upload document of a task.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 6-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDocumentUpload(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		String fileName = Multimaplibraries.getTestDataCellValue(scenarioName, "Tasks_New_Document");
		agSetValue(TasksPageObjects.uploadButton, lsmvConstants.LSMV_testDataInput + "\\" + fileName);
		agSetGlobalTimeOut("10000");
		agAssertVisible(CommonPageObjects.linkText(fileName));
		agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
		Reports.ExtentReportLog("Documents", Status.INFO, "Added document", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to assign User/Group of a task.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 7-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void assignUserGroupDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(TasksPageObjects.userList_SourceFilter);
		if (getTestDataCellValue(scenarioName, "Tasks_New_Assignment_BoolUser").equalsIgnoreCase("true")
				&& getTestDataCellValue(scenarioName, "Tasks_New_Assignment_BoolUserAssignAll")
						.equalsIgnoreCase("#skip#")) {
			agClick(TasksPageObjects
					.select_UserList_Item(getTestDataCellValue(scenarioName, "Tasks_New_Assignment_User")));
			agClick(TasksPageObjects.add_PicklistItem);
		} else if (getTestDataCellValue(scenarioName, "Tasks_New_Assignment_BoolUser").equalsIgnoreCase("true")
				|| getTestDataCellValue(scenarioName, "Tasks_New_Assignment_BoolUserAssignAll")
						.equalsIgnoreCase("true")) {
			agClick(TasksPageObjects.addAll_PicklistItem);
		}

		if (getTestDataCellValue(scenarioName, "Tasks_New_Assignment_BoolGroup").equalsIgnoreCase("true")
				&& getTestDataCellValue(scenarioName, "Tasks_New_Assignment_BoolGroupAssignAll")
						.equalsIgnoreCase("#skip#")) {
			agSetStepExecutionDelay("5000");
			agClick(TasksPageObjects.selectUserOrGroupRadio("Group"));
			agSetStepExecutionDelay("5000");
			agClick(TasksPageObjects
					.select_GroupList_Item(getTestDataCellValue(scenarioName, "Tasks_New_Assignment_Group")));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agClick(TasksPageObjects.add_PicklistItem);
		} else if (getTestDataCellValue(scenarioName, "Tasks_New_Assignment_BoolGroup").equalsIgnoreCase("true")
				|| getTestDataCellValue(scenarioName, "Tasks_New_Assignment_BoolGroupAssignAll")
						.equalsIgnoreCase("true")) {
			agClick(TasksPageObjects.addAll_PicklistItem);
		}

	}

	/**********************************************************************************************************
	 * @Objective: Select date in JS calendar
	 * @InputParameters: Date , label
	 * @OutputParameters:NA
	 * @author:Mithun M P
	 * @Date : 06-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDatesCalender(String date, String label) {
		if (!date.trim().equalsIgnoreCase("#skip#")) {
			String[] Date = date.split("-");
			agClick(TasksPageObjects.setDatesTextboxes(label));
			agClick(TasksPageObjects.monthSelect);
			agClick(TasksPageObjects.monthDropdown(Date[1]));
			agClick(TasksPageObjects.yearSelect);
			agClick(TasksPageObjects.yearDropdown(Date[2]));

			char[] temp = Date[0].toCharArray();
			char result;
			if (temp[0] == '0') {
				result = temp[1];
				agJavaScriptExecuctorClick(TasksPageObjects.dateSelect(String.valueOf(result)));
			} else {
				agJavaScriptExecuctorClick(TasksPageObjects.dateSelect(Date[0]));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is to create a new Task
	 * @InputParameters: scenarioName
	 * @OutputParameters:NA
	 * @author:Mithun M P
	 * @Date : 10-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createNewTask(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		tasksNavigations("taskNew");
		TasksOperations.enterBasicTaskDetails(scenarioName);
		TasksOperations.enterDistributionContactDetails(scenarioName);
		TasksOperations.enterRemainderDetails(scenarioName);
		TasksOperations.enterDocmentDetails(scenarioName);
		// TasksOperations.assignUserGroupDetails(scenarioName);

		agClick(TasksPageObjects.savebutton);
		String savedMsg = CommonOperations.setAuditInfo("Create_Tasks");

		String[] arrOfStr = savedMsg.split("Task Id ");
		arrOfStr = arrOfStr[1].split(" saved Successfully");
		savedMsg = arrOfStr[0].replace(",", "");

		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "TasksOperations", scenarioName, "NewTaskId",
				savedMsg.trim());
	}

	/**********************************************************************************************************
	 * @Objective: This method is to delete the Task in Listing screen
	 * @InputParameters: scenarioName , edit
	 * @OutputParameters:NA
	 * @author:Avinash k
	 * @Date : 24-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteTask(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		menuNavigation(TasksPageObjects.tasksListing);
		agSetStepExecutionDelay("6000");
		TasksOperations.searchAndEditTask(scenarioName, false);

		agClick(TasksPageObjects.listingcheckBox);
		agClick(TasksPageObjects.archiveButton);
		agWaitTillVisibilityOfElement(TasksPageObjects.deleteconfirmationPopup);
		if (agIsVisible(TasksPageObjects.deleteconfirmationPopup) == true) {
			agSetStepExecutionDelay("3000");
			agAssertContainsText(TasksPageObjects.deleteconfirmationPopup,
					"Are you sure you want to archive the task ?");
			agClick(TasksPageObjects.deletepopupYesButton);
			agSetStepExecutionDelay("3000");
			Reports.ExtentReportLog("", Status.PASS, "Delete is successfull ", true);
			agClick(TasksPageObjects.deletepopupOkButton);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download account export to excel.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 15-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportToexcel(String FileName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		agIsVisible(TasksPageObjects.tasksListingKeywordSearch);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agMouseHover(TasksPageObjects.downloadIcon);
		agClick(TasksPageObjects.exporttoExcel_link);
		agWaitTillVisibilityOfElement(TasksPageObjects.export_Btn);
		if (agIsVisible(TasksPageObjects.export_Btn) == true) {
			agClick(TasksPageObjects.export_Btn);
			try {
				Thread.sleep(8000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			CommonOperations.move_Downloadedexcel(FileName);
			agClick(TasksPageObjects.exportexcelcancel_Btn);
		} else {
			Reports.ExtentReportLog("Export to excel pop is not displayed", Status.INFO, "", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to compare record count with download
	 *             excel
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:Avinash K
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void recordCountVerification(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		String count = xls.getCellData("Sheet 1", 2, 4);
		String[] Totalcount = count.split(":");
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in exported excel::" + Totalcount[1].trim(),
				false);
		String applrecordcount = agGetText(TasksPageObjects.paginator);
		String appcount = applrecordcount.substring(10, applrecordcount.lastIndexOf(")"));

		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in application::" + appcount.trim(), false);
		if (appcount.trim().equalsIgnoreCase(Totalcount[1].trim())) {
			Reports.ExtentReportLog("", Status.PASS, "Record count verification is successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Record count verification is Unsuccessfull", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search for deleted Task.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 24-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchDeleteTask(String scenarioName) {
		menuNavigation(TasksPageObjects.tasksListing);
		TasksOperations.searchAndEditTask(scenarioName, false);
		String paginator = agGetText(TasksPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.FAIL, "Search for Deleted Task: Deleted Task is listed", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS, "Search for Deleted Task: Deleted Task is not listed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is to search and edit Task in Listing screen
	 * @InputParameters: scenarioName , edit
	 * @OutputParameters:NA
	 * @author:Mithun M P
	 * @Date : 14-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndEditTask(String scenarioName, boolean edit) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agSetValue(TasksPageObjects.tasksListingKeywordSearch, getTestDataCellValue(scenarioName, "NewTaskId"));
		agClick(TasksPageObjects.keywordSearchIcon);
		agSetStepExecutionDelay("6000");

		if (agIsVisible(TasksPageObjects.searchRec(getTestDataCellValue(scenarioName, "NewTaskId")))) {
			Reports.ExtentReportLog("", Status.INFO, "Search successful", true);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Search Unsuccessful", true);
		}

		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Search is successfull ", true);
		if (edit == true) {
			agJavaScriptExecuctorClick(TasksPageObjects.searchRec(getTestDataCellValue(scenarioName, "NewTaskId")));
			Reports.ExtentReportLog("", Status.INFO, "Search and edit is successfull ", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is to create a new Task
	 * @InputParameters: scenarioName
	 * @OutputParameters:NA
	 * @author:Mithun M P
	 * @Date : 10-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyTasks(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		TasksOperations.verifyBasicTaskDetails(scenarioName);
		;
		TasksOperations.verifyDistributionContactDetails(scenarioName);
		TasksOperations.verifyRemainderDetails(scenarioName);
		TasksOperations.verifyDocmentDetails(scenarioName);
		agClick(TasksPageObjects.cancelbutton);
	}
}