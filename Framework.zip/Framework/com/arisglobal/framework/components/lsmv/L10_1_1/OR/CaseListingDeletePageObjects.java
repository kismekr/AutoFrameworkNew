package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public abstract class CaseListingDeletePageObjects {
	
    public static String clickdeleteReasonCodeDropdown = "xpath#//div[@id='deleteReason_Id']/select[@name='auditDeleteCode']";
    public static String selectdeleteReasonCode = "xpath#//div[@id='deleteReason_Id']/select[@name='auditDeleteCode']/option[text()='Other']";
    public static String deleteAuditReason_Textarea ="xpath#//textarea[@id='auditDeleteCodeComments']";
    public static String deleteAuditReasonSubmit_Btn ="xpath#//div[@id='deleteAuditWindowsId']//div/span[@id='okCnfDlgDetails']";
    public static String validationPopup = "xpath#//div[@id='validationDialog']/div//label";
    public static String validationPopupOkBtn = "xpath#//div[@id='validationDialog']/div//button";
  
    public static String clickRejectReasonCodeDropdown = "xpath#//div[@id='rejectCase_Id']/select[@name='rejectSelect']";
    public static String selectRejectReasonCode= "xpath#//div[@id='rejectCase_Id']/select[@name='rejectSelect']/option[text()='Others']";
    public static String rejectAuditReason_Textarea = "xpath#//textarea[@id='rejectReasonComments']";
    public static String rejectAuditReasonSubmit_Btn ="xpath#//div[@id='rejectCaseWindowsId']//div/span[@id='okCnfDlgDetails']";
    
    public static String retriveButton = "xpath#//a[@id='adverseEventNew:retriveID']";
	 public static String retriveReasonCodeTextarea= "xpath#//input[@id='retriveReason']";
			 public static String retriveConfirmButton = "xpath#//span[@id='okCnfDlgDetails']";
			 public static String deleteCaseReason_Textarea ="xpath#//textarea[@id='reasonTxt']";
			 public static String deleteCaseReasonSubmit_Btn ="xpath#//button[@id='adverseEventDelete']";
			 public static String clickCasedeleteReasonCodeDropdown = "xpath#//span[@id='select2-reasonCode-container']";
			    public static String selectCasedeleteReasonCode(String value) {
			    return "xpath#//li[text()='"+value+"']";
			    }
}