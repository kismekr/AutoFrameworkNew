package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.LibrariesPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.PharmacologicalClassPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.TherapeuticAreaPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Libraries_PharmacologicalClass extends ToolManager {

	static String className = Libraries_PharmacologicalClass.class.getSimpleName();

	static Boolean status;

	/******************************************************************************************************
	 * @Objective: The below method is created to create Pharmacological Class.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 8-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createPharmacologicalClass(String scenarioName) {

		agAssertVisible(PharmacologicalClassPageObjects.PharmacologicalClass_lable);
		agSetValue(PharmacologicalClassPageObjects.code_TxtField, getTestDataCellValue(scenarioName, "Code"));
		agSetValue(PharmacologicalClassPageObjects.PharmacologicalClass_TxtField,
				getTestDataCellValue(scenarioName, "Pharmacological Class"));
		agSetValue(PharmacologicalClassPageObjects.description_TextArea,
				getTestDataCellValue(scenarioName, "Description"));
		CommonOperations.takeScreenShot();
		agClick(PharmacologicalClassPageObjects.save_Button);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search and create Pharmacological
	 *             Class.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 8-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreatePharmacologicalClass(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		if (verifysearchData(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Pharmacological Class already exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Code"), PharmacologicalClassPageObjects.get_Code);
		} else {
			agClick(PharmacologicalClassPageObjects.new_Button);
			createPharmacologicalClass(scenarioName);
			CommonOperations.setAuditInfo(scenarioName);
			search(scenarioName);
			VerifyPharmacologicalClass(scenarioName);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search and create Pharmacological
	 *             Class.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 03-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreatePharmacologicalClassRecord(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		if (verifysearchData(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS,
					getTestDataCellValue(scenarioName, "Code") + " : Record already exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Code"), PharmacologicalClassPageObjects.get_Code);
		} else {
			agClick(PharmacologicalClassPageObjects.new_Button);
			createPharmacologicalClass(scenarioName);
			CommonOperations.setAuditInfo("Create_PharmacologicalClass");
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Pharmacological Class.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 8-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyPharmacologicalClass(String scenarioName) {
		agClick(PharmacologicalClassPageObjects.edit_Icon);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Code"),
				PharmacologicalClassPageObjects.code_TxtField);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Pharmacological Class"),
				PharmacologicalClassPageObjects.PharmacologicalClass_TxtField);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Description"),
				PharmacologicalClassPageObjects.description_TextArea);
		CommonOperations.takeScreenShot();
		agClick(PharmacologicalClassPageObjects.cancel_Button);
		agIsVisible(PharmacologicalClassPageObjects.paginator);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Pharmacological Class.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 8-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void search(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(PharmacologicalClassPageObjects.keywordSearch_TxtField, getTestDataCellValue(scenarioName, "Code"));
		agClick(PharmacologicalClassPageObjects.search_Icon);
		agIsVisible(PharmacologicalClassPageObjects.paginator);
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Pharmacological class exist
	 *             or not based on Pharmacological Class code.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 8-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static Boolean verifysearchData(String scenarioName) {
		Boolean falg = false;
		String paginator = agGetText(PharmacologicalClassPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			List<WebElement> list = agGetElementList(PharmacologicalClassPageObjects.get_ListofCode);
			String columnHeader = null;
			for (int j = 1; j <= list.size(); j++) {
				columnHeader = agGetText(PharmacologicalClassPageObjects.columnHeaderList(Integer.toString(j)));
				if (getTestDataCellValue(scenarioName, "Code").equalsIgnoreCase(columnHeader)) {
					falg = true;
					break;
				}
			}
		}
		return falg;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit and update Pharmacological
	 *             class.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 8-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void updatePharmacologicalClass(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(PharmacologicalClassPageObjects.edit_Icon);
		createPharmacologicalClass(scenarioName);
		CommonOperations.setAuditInfo(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Pharmacological Class.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 8-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchPharmacologicalClass(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		String paginator = agGetText(PharmacologicalClassPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Code"), PharmacologicalClassPageObjects.get_Code);
			Reports.ExtentReportLog("", Status.PASS, "Search Pharmacological Class: Pharmacological Class Listed",
					true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Search Pharmacological Class: Pharmacological Class Not Listed",
					true);
		}
		// agClick(PharmacologicalClassPageObjects.refresh_Icon);
		agIsVisible(LibrariesPageObjects.pharmaClassKeywordSearch);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete Pharmacological Class.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deletePharmacologicalClass(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		String paginator = agGetText(PharmacologicalClassPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Code"), PharmacologicalClassPageObjects.get_Code);
			Reports.ExtentReportLog("", Status.PASS, "Pharmacological Class Found", true);
			agClick(PharmacologicalClassPageObjects.selectListingCheckbox(getTestDataCellValue(scenarioName, "Code")));
			delete(scenarioName);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Pharmacological Class Not Found", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete Pharmacological Class.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void delete(String scenarioName) {
		agClick(PharmacologicalClassPageObjects.delete_Button);
		agSetStepExecutionDelay("5000");
		agClick(PharmacologicalClassPageObjects.deleteYes_Button);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.verifyMessage(scenarioName);
		CommonOperations.agClick(CommonPageObjects.validaionOk_Btn);
		
		
		//CommonOperations.setDeleteAuditInfo(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search for deleted Pharmacological
	 *             Class.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchDeletedPharmacologicalClass(String scenarioName) {
		search(scenarioName);
		String paginator = agGetText(PharmacologicalClassPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.FAIL,
					"Search for Deleted PharmacologicalClass: Deleted PharmacologicalClass is listed", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS,
					"Search for Deleted PharmacologicalClass: Deleted PharmacologicalClass is not listed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download Pharmacological Class
	 *             export to excel.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportToexcel(String FileName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(PharmacologicalClassPageObjects.download_Icon);
		agClick(PharmacologicalClassPageObjects.exporttoExcel_link);
		agWaitTillVisibilityOfElement(TherapeuticAreaPageObjects.export_Btn);
		if (agIsVisible(PharmacologicalClassPageObjects.export_Button) == true) {
			agClick(PharmacologicalClassPageObjects.export_Button);
			try {
				Thread.sleep(8000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			CommonOperations.move_Downloadedexcel(FileName);
			agClick(PharmacologicalClassPageObjects.exportexcelcancel_Button);
		} else {
			Reports.ExtentReportLog("Export to excel pop is not displayed", Status.INFO, "", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to compare record count with download
	 *             excel
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:Avinash K
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void recordCountVerification(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		String count = xls.getCellData("Approvals", 2, 4);
		String[] Totalcount = count.split(":");
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in exported excel::" + Totalcount[1].trim(),
				false);
		String applrecordcount = agGetText(PharmacologicalClassPageObjects.paginator);
		String[] data = applrecordcount.split(" ");
		String recordCount = data[4];
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in application::" + recordCount, false);
		if (recordCount.equalsIgnoreCase(Totalcount[1].trim())) {
			Reports.ExtentReportLog("", Status.PASS, "Record count verification is successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Record count verification is Unsuccessfull", true);
		}
	}
}