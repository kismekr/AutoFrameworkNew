package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class DataAssessmentPageObjects {

	public static String AER_Lookup = "xpath#//span[contains(@id,'classifyFollowupAerNoLP')][not(contains(@id,'adverseEventNew:aer_no_duplicate1'))]";
	public static String AERLookup_Header = "xpath#//span[@id='aerNoForm:aerNoLookUpDialog_title']";
	public static String AERNo_Textfield = "xpath#//input[contains(@title,'Enter ReceiptNo. / Aer No.') or @placeholder='Search...']";
	public static String AERLookupSearch_Btn = "xpath#//span[@class='lsmv-grid-search-icon']";
	public static String AERLookupCancel_Btn = "xpath#//button[@id='aerNoForm:clear']";
	public static String AERLookupSearchRes_label = "xpath#//div[@id='aerNoForm:aerTable:aerLookUpDataTable']/div[text()='Search Results']";
	public static String AERLookupRadio_Btn = "xpath#//span[text()='%s']/ancestor::div[@id='libraryDataMain']//div[contains(@class,'lsmv-grid-row')]/span";
	public static String AERLookupOk_Btn = "xpath#//span[@id='selecctBtnId']";
	public static String AERSeachTextBox = "xpath#//inputCmpClass lsmvGridSearchCmp";
	public static String AERSelect_CheckBox = "xpath#//div[@id='targetPanelForDataLibLookup']/div[2]/span[contains(@class,'lsmv-grid-sel-unchk')]";

	public static String receiptNo_followupLookup = "xpath#//span[@id='classifyFollowupReceiptNoLP']";
	public static String receiptNo_Lookup = "xpath#//img[@title='Receipt No.']";
	public static String receiptNoLookup_ReceiptNo = "xpath#//input[@id='receiptNoForm:receipt']";
	public static String receiptNoLookup_Search_Button = "xpath#//button[@id='receiptNoForm:findButton']";
	public static String firstRadio_Button = "xpath#//tr[@data-ri='0']//span[@class='ui-radiobutton-icon ui-icon ui-icon-blank ui-c']";
	public static String receiptNoLookupOK_Button = "xpath#//button[@id='receiptNoForm:okButtonBottom']";
	public static String clasifyCase_Button = "xpath#//button[@role='button']/span[text()='Classify Case']";
	public static String conformationOK_Button = "xpath#//button[@id='mandatoryDialogform:okButton']";
	public static String receiptNumber_Txtbox = "xpath#//input[@id='receiptNoForm:receipt']";
	public static String specifyReason = "xpath#//label[contains(@id,'aeClassificationForm:')][text()='--Select--']";
	public static String specifyReasonSelect = "xpath#//li[contains(@id,'aeClassificationForm:')][@data-label='Others']";

	public static String ReconsileYesBtn = "xpath#//button[contains(@onclick,'openReconciliation')]";
	public static String ReconsileNoBtn = "xpath#//div[@id='followupReconciliationId']//button[text()='No']";
	public static String reconsileNotificationAlert = "xpath#//div[@id='followupReconciliationAlertId']";
	public static String reconcileSubmitBtn = "xpath#//button[@onclick='appendToExisting();'][text()='Submit']";
	public static String reconcileMessage = "xpath#//span[contains(text(),'reconciled successfully')]";
	public static String followupNotificationAlert = "xpath#//div[@id='followupNotificationAlertId']";
	public static String followupReconsileYesBtn = "xpath#//button[contains(@onclick,'openFollowUpNotificationDialog')]";
	public static String followupReconsileNoBtn = "xpath#//button[contains(@onclick,'followupNotification')][text()='No']";
	public static String followupReconsileIcon = "xpath#//a/img[contains(@alt,'Follow-up Notification')]";

	// Case summary sheet verification

	public static String CaseSumamrysheetchckbox = "xpath#//div[@id='classifyFollowupTargCaseCaseSumm']/input[@id='classifyFollowupTargCaseSummChk']";
	public static String caseSymmarySheetCheckbox_Left = "xpath#//div[@id='classifyFollowupCurrCaseCaseSumm']/input[@id='classifyFollowupCurrCaseSummChk']";

	// public static String filnamelink =
	// "xpath#//a[@id='aeClassificationForm:%sForParent:{0}:viewFileLinkForParent']";
	public static String docList = "xpath#//div[@class='lsmv-grid-col lsmv-tooltip '][@fieldid='%id%']/div";
	public static String docLink = "xpath#(//div[@class='lsmv-grid-col lsmv-tooltip '][@fieldid='%id%']/div)[%count%]";
	public static String fileName = "fileName";
	public static String docCategory = "docCategory";
	public static String date = "date";
	public static String doccategory = "xpath#//div[contains(@id,'aeClassificationForm:{%label%}ForParent:{0}:')]//label[text()='%s']";
	public static String FUokpopbtn = "xpath#//button[@id='mandatoryDialogform:okButton']/span[text()='OK']";
	public static String validationpopup = "xpath#//span[text()='Action  Completed Successfully']";
	public static String docCheckBox_Support = "xpath#(//div[@id='classifyFollowupTargCaseSupDocs']/div/span)[1]";
	public static String docCheckBox_Source = "xpath#(//div[@id='classifyFollowupTargCaseSrcDocs']/div/span)[1]";
	public static String docCheckox_Child = "xpath#(//span[@class='lsmv-grid-sel-unchk lsmv-grid-row-no-chk'])[%count%]";
	public static String dupAERLookUP = "xpath#//span[@id='classifyDuplicateAerNoLP']";
	public static String libraryListHeader = "xpath#//span[text()='List of Library data']";

	public static String AERLookupcheckBox = "xpath#//span[text()='%s']/ancestor::div[@id='targetPanelForDataLibLookup']//div[contains(@class,'lsmv-grid-row')]/span";

	public static String customRadio = "xpath#(//span[text()='Custom']//parent::div/input)[2]";
	public static String searchBtn = "xpath#//span[text()='Search']";
	public static String patientId = "xpath#//input[@fieldid='PATIENT_ID']";
	public static String productDescLookUp = "xpath#//label[text()='Product Description']//parent::div//span[@class='lsmv-lookup-icon']";
	public static String listOfproductHeader = "xpath#//span[text()='List of Product']";
	public static String productName = "xpath#//input[@fieldid='PRODUCT_NAME']";
	// public static String checkSearchedProduct =
	// "xpath#//div[@id='targetPanelForPrdLookupGrid']//span[@class='lsmv-grid-row-sel-chk
	// lsmv-grid-sel-unchk']";
	public static String checkSearchedProduct = "xpath#//div[@id='targetPanelForPrdLookupGrid']//span[@class='lsmv-grid-chk-sticky lsmv-grid-row-sel-chk lsmv-grid-sel-unchk']";
	public static String productSearchBtn = "xpath#//span[@id='propPopupAdvPanelColExpIcon']//parent::div//span[text()='Search']";
	public static String productOkBtn = "xpath#//div[@id='targetPanelForPrdLookupGrid']//span[@id='selecctBtnId']";
	public static String productChaacterzation_Dropdown = "xpath#//select[@fieldid='PRODUCT_CHARACTERIZATION']";

	public static String safetyReportId = "xpath#//input[@fieldid='SAFETYREPORTID']";
	public static String reportedTerm = "xpath#//input[@fieldid='reported_term']";
	public static String loader = "xpath#headerForm:j_id_1f";
	public static String noRecordFound = "xpath#//div[text()='No records to display']";

	public static String authorityNo = "xpath#//input[@fieldid='AUTHORITYNO']";
	public static String LRDFromRecvDate = "xpath#//input[@fieldid='FROMDATE_REVCEIVED']/following::span[1]";
	public static String LRDToRecvDate = "xpath#//input[@fieldid='TODATE_REVCEIVED']/following::span[1]";
	public static String primarySourceCountry_Dropdown = "xpath#//select[@fieldid='PRIMARY_SOURCE_COUNTRY']";
	public static String reportType_Dropdown = "xpath#//select[@fieldid='REPORT_TYPE']";
	public static String countryDetection_Dropdown = "xpath#//select[@fieldid='COUNTRY_OF_OCCURRENCE']";

	public static String onsetDate = "xpath#//input[@fieldid='ae_onset_Date']/following::span[1]";

	public static String patientDOB = "xpath#//input[@fieldid='PATIENT_DOB']/following::span[1]";
	public static String ageTimeEvent = "xpath#//input[@fieldid='PATIENT_AGE']";
	public static String patientAgeUnit_Dropdown = "xpath#//select[@fieldid='PATIENT_AGE_UNIT']";
	public static String patientID = "xpath#//input[@fieldid='PATIENT_ID']";
	public static String hospitalRecordNo = "xpath#//input[@fieldid='HOSPITAL_RECORD_NUMBER']";
	public static String GPrecordNo = "xpath#//input[@fieldid='RECORD_NO']";
	public static String gender_dropDown = "xpath#//select[@fieldid='PATIENT_SEX']";

	public static String articleTitle = "xpath#//input[@fieldid='LITERATURE_ARTICLE_TITLE']";
	public static String journalTitle = "xpath#//input[@fieldid='LITERATURE_JOURNAL_TITLE']";
	public static String literatureRef = "xpath#//input[@fieldid='LITERATURE_REREFERENCE']";

	public static String referenceType_Dropdown = "xpath#//select[@fieldid='REFERENCE_TYPE']";
	public static String referenceNum = "xpath#//input[@fieldid='OTHER_REFERENCE_NO']";

	public static String ProtocolNoLookup = "xpath#//label[text()='Protocol No']//following::span[@class='lsmv-lookup-icon']";
	public static String sponsorStudyNo = "xpath#";
	public static String searchTextBox = "xpath#//input[@placeholder='Search...']";
	public static String ProtocolSearchIcon = "xpath#//span[@class='lsmv-search-icon']";
	public static String ProductRadioBtn = "xpath#";
	public static String studyOkBtn = "xpath#";
	public static String centerNo = "xpath#//input[@fieldid='SITE_NUMBER']";
	public static String subjectID = "xpath#//input[@fieldid='SUBJECT_ID']";

	public static String firstName = "xpath#//input[@fieldid='REPORTER_FIRST_NAME']";
	public static String LastName = "xpath#//input[@fieldid='REPORTER_LAST_NAME']";
	public static String state = "xpath#//input[@fieldid='STATE']";
	public static String postalCode = "xpath#//input[@fieldid='ZIP_CODE']";
	public static String country_Dropdown = "xpath#//select[@fieldid='REPORTER_COUNTRY']";
	public static String receiptNoList = "xpath#//div[@class='lsmv-grid-row']//div[@fieldid='receiptNo']//div";
	public static String receiptNo = "xpath#(//div[@class='lsmv-grid-row']//div[@fieldid='receiptNo']//div)[%count%]";

	public static String otherSafetyRefNoLabel = "xpath#//label[text()='Other Safety Ref Number']";
	public static String MergeDocumentCheckBox = "xpath#//input[@id='classifyFollowupDocMerge']";
	public static String SelectBtn = "xpath#//span[@id='selecctBtnId']";
	public static String totalcasecount="xpath#//span[@class='lsmv-pager-info']";

	/**********************************************************************************************************
	 * @Objective:The below method is created to select the verify the document
	 *                category in data assesment followup screen.
	 * @Input Parameters:
	 * @Output Parameters:
	 * @author:Pooja S Date :21-Apr-2020 Updated by and when
	 **********************************************************************************************************/
	public static String VerifyDocumentcategory(String index, String label, String num) {
		String value = doccategory;
		String value2;
		String value3;
		String value4;
		value2 = value.replace("{0}", index);
		value3 = value2.replace("%s", label);
		value4 = value3.replace("{%label%}", num);
		return value4;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to verify the filename link in data
	 *                assesment followup screen.
	 * @Input Parameters:
	 * @Output Parameters:
	 * @author:Pooja S Date :21-Apr-2020 Updated by and when
	 **********************************************************************************************************/
	public static String verifyDocs(String count, String id) {
		String value = docLink;
		String value2;
		value2 = value.replace("%count%", count);
		String value3 = value2.replace("%id%", id);
		return value3;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created select radio button next to AERNo by
	 *                passing AERNo at runtime.
	 * @Input Parameters:
	 * @Output Parameters:
	 * @author:Avinash K Date :20-Sep-2019 Updated by and when
	 **********************************************************************************************************/
	public static String AERLookupRadio_Btn(String AERNo) {
		String value = AERLookupRadio_Btn;
		String value2;
		value2 = value.replace("%s", AERNo);
		return value2;
	}

	public static String AERLookup_CheckBox(String ReceiptNo) {
		String value = AERLookupcheckBox;
		String value2;
		value2 = value.replace("%s", ReceiptNo);
		return value2;
	}
}
