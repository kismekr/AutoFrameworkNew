package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import com.arisglobal.framework.lib.main.ToolManager;

public class QBEPageObjects {

	public static String QBEIcon="xpath#//img[contains(@src,'QBE-icon.png')]";
	public static String QBESavedCriteriaDD="xpath#//div[@class='lsmv-panel-header']//input[@placeholder='Saved Criterias']";
	public static String QBEAERNo="xpath#//div[text()='AER_Number']";
	public static String QBEAERNoValue="xpath#//input[@class='conddRhsElement i18n_pl']";
	public static String QBESearch="xpath#//div[@class='lsmv-panel-header']//span[contains(text(),'Search')]";
	public static String QBEExpression="xpath#//span[text()='Expressions']";
	//public static String QBEShowAllFields="xpath#//div/ancestor::div[@id='fieldLibTreeGridPanel']//input[@type='checkbox']";
	//public static String QBEShowAllFieldsSearch="xpath#//input[@id='fieldLibSearchCmp']";
	public static String QBEInitialRecvDate="xpath#//div[text()='InitalRecDate']";
	public static String QBEInitialRecvDateFrom="xpath#//input[@class='conddRhsElement i18n_pl']";
	public static String QBEInitialRecvDateTo="xpath#//input[@class='conddRhsElement2 i18n_pl']";
	public static String QBEBack="xpath#//span[@class='cl-back-icon i18n']";
	public static String Study_InitialRecvDate="xpath#//div[text()='StudyNo&InitialRecvDate']";
	public static String Protocol_Checkbox="xpath#(//span[@class='lsmv-grid-row-sel-chk lsmv-grid-sel-unchk'])[1]/parent::div[@class='lsmv-grid-row']";
	public static String Protocol_NoLookUPSearch="xpath#//div[@class='expConddPanel lsmv-tree-str-last']//span[@class='lsmv-search-icon']";
	public static String StudyRefresh="xpath#//span[text()='Refresh']";
	public static String CompanyUnit_CheckBox="xpath#(//span[@class='lsmv-grid-row-sel-chk lsmv-grid-sel-unchk'])[1]/parent::div[@class='lsmv-grid-row']";
	public static String Validation="xpath#//div[text()='Report from study']";
	public static String Select_Btn="xpath#//div//span[text()='Select']";
	public static String Protocol_initial_RecvFromdate="xpath#//div[@class='expConddPanel lsmv-tree-str-last']//input[@class='conddRhsElement i18n_pl']";
	public static String Protocol_initial_RecvTodate="xpath#//div[@class='expConddPanel lsmv-tree-str-last']//input[@class='conddRhsElement2 i18n_pl']";
	public static String Report_term="xpath#//div[@class='expConddPanel lsmv-tree-str']//input[@class='conddRhsElement i18n_pl']";
	public static String Report_type="xpath#//div[@class='expConddPanel lsmv-tree-str-last']//input[@class='conddRhsElement i18n_pl']";
	public static String Report_typeLookUP="xpath#//div[@class='expConddPanel lsmv-tree-str-last']//span[@class='lsmv-search-icon']";
	public static String Report_typeandTerm="xpath#//div[text()='Reporter&ReportedTerm']";
	public static String ListofCodeListText="xpath#//span[text()='List of Code list']";
	public static String ReportType_Checkbox="xpath#//div[contains(text(),'Not available to sender')]/ancestor::div[@class='lsmv-grid-row']//span[@class='lsmv-grid-row-sel-chk lsmv-grid-sel-unchk']";
	public static String Sex_DOB_CompUnit="xpath#//div[text()='DOB,Gen,Compunit']";
	public static String Gender_Checkbox="xpath#//div[text()='Female']/ancestor::div[@class='lsmv-grid-col lsmv-tooltip ']";
	public static String Gender_LookUP="xpath#//span[text()='C2']/parent::div[@class='expConddPanel lsmv-tree-str']//div/span[@class='lsmv-search-icon']";
	public static String PatientDOBFromdate="xpath#//div[@class='expConddPanel lsmv-tree-str-last']//input[@class='conddRhsElement i18n_pl']";
	public static String PatientDOBTodate="xpath#//div[@class='expConddPanel lsmv-tree-str-last']//input[@class='conddRhsElement2 i18n_pl']";
	public static String Company_UnitLookUP="xpath#//div[@class='expConddPanel lsmv-tree-str-last']//span[@class='lsmv-search-icon']";
	public static String Select_EnterVal_ToCompareLookUP1="xpath#//span[text()='C1']/parent::div[@class='expConddPanel lsmv-tree-str']//div/span[@class='lsmv-search-icon']";
	public static String Select_EnterVal_ToCompareLookUP2="xpath#//span[text()='C2']/parent::div[@class='expConddPanel lsmv-tree-str']//div/span[@class='lsmv-search-icon']"; 
	public static String Select_EnterVal_ToCompareLookUP3="xpath#//span[text()='C3']/parent::div[@class='expConddPanel lsmv-tree-str']//div/span[@class='lsmv-search-icon']";	
	public static String Select_EnterVal_ToCompareLookUP4="xpath#//span[text()='C4']/parent::div[@class='expConddPanel lsmv-tree-str']//div/span[@class='lsmv-search-icon']";
	public static String Select_EnterVal_ToCompareLookUP5="xpath#//span[text()='C5']/parent::div[@class='expConddPanel lsmv-tree-str']//div/span[@class='lsmv-search-icon']";
	public static String Select_EnterVal_ToCompareLookUP6="xpath#//span[text()='C6']/parent::div[@class='expConddPanel lsmv-tree-str-last']//div/span[@class='lsmv-search-icon']";
	public static String Fromdate="xpath#//div[@class='expConddPanel lsmv-tree-str-last']//input[@class='conddRhsElement i18n_pl']";
	public static String Todate="xpath#//div[@class='expConddPanel lsmv-tree-str-last']//input[@class='conddRhsElement2 i18n_pl']";
	public static String Country_Checkbox="xpath#//div[text()='AFGHANISTAN']/ancestor::div[@class='lsmv-grid-col lsmv-tooltip ']";
	public static String Report_Recv_CheckBox="xpath#//div[text()='Bulk import']/ancestor::div[@class='lsmv-grid-col lsmv-tooltip ']";
	public static String Select6_Variabless="xpath#//div[text()='6_Variables']";
	public static String SourceMed_Reptype="xpath#//div[text()='SourceMed&RepType']";
	public static String Paginator="xpath#//div[@class='dataTables_paginate paging_simple']";
	public static String GeneralLabel="xpath#//span[text()='General ']";
	
	public static String Select_From_Month="xpath#//select[@class='calendar-month']";
	public static String DatePick_From_Icon="xpath#//input[@class='conddRhsElement i18n_pl']//following-sibling::span[@class='lsmv-calendarIcon']";
	public static String Select_From_Year="xpath#//select[@class='calendar-year']";
	public static String Select_From_Day="xpath#//td[not(contains(@class,'ui-datepicker-other-month'))]/a[text()='%s']";
	public static String DatePick_To_Icon="xpath#//input[@class='conddRhsElement2 i18n_pl']//following-sibling::span[@class='lsmv-calendarIcon']";
	public static String Select_To_Month="xpath#//span[text()=' To ']/parent::div/div//select[@name='calendar-month']";
	public static String Select_To_Year="xpath#//div[@class='conddRhsElement2Div form-group']//following-sibling::select[@name='calendar-year']";
	public static String Select_TO_Day="xpath#(//td[not(contains(@class,'ui-datepicker-other-month'))]/a[text()='%s'])[2]";
	
	
	/**********************************************************************************************************
	 * @Objective: The below Method is to pick the FromDay from calendar
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Pooja S
	 * @return 
	 * @Date : 04-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static String  Select_FromDay(String day)
	{		
		String value = Select_From_Day;
		String value2;
		value2 = value.replace("%s", day);
		return value2;
	}
	/**********************************************************************************************************
	 * @Objective: The below Method is to pick the ToDay from calendar
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Pooja S
	 * @return 
	 * @Date : 04-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String  Select_ToDay(String day)
	{		
		String value = Select_TO_Day;
		String value2;
		value2 = value.replace("%s", day);
		return value2;
	}
	/**********************************************************************************************************
	 * @Objective: The below Method is to pick the date Fromdate from calendar
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Pooja S
	 * @return 
	 * @Date : 04-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void DatePickerFrom(String date) 
	{
		String[] Array_Date=date.split("-");	
		ToolManager.agSelectByValue(QBEPageObjects.Select_From_Month,Array_Date[1]);
		ToolManager.agSelectByValue(QBEPageObjects.Select_From_Year,Array_Date[2]);
		ToolManager.agClick(QBEPageObjects.Select_FromDay(Array_Date[0]));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below Method is to pick the date Todate from calendar
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Pooja S
	 * @return 
	 * @Date : 04-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void DatePickerTo(String date)
	{
		String[] Array_Date=date.split("-");	
		ToolManager.agSelectByValue(QBEPageObjects.Select_To_Month,Array_Date[1]);
		ToolManager.agSelectByValue(QBEPageObjects.Select_To_Year,Array_Date[2]);
	    ToolManager.agClick(QBEPageObjects.Select_ToDay(Array_Date[0]));
	}
	

	
	
	
	
	
	
	
	

}