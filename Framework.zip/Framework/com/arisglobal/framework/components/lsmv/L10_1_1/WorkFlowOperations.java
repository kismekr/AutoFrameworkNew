package com.arisglobal.framework.components.lsmv.L10_1_1;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.WorkFlowPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.XMLDocConfigPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class WorkFlowOperations extends ToolManager {

	static String className = WorkFlowOperations.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: The below method is created to check checkbox left of specified
	 *             label.
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 16-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickCheckBoxLeftOf(String label, String boolCheck) {
		if (!boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus;
			String xpath = WorkFlowPageObjects.checkBoxLeftOf(label);
			checkBoxStatus = ToolManager.agGetAttribute("class", xpath);
			if (checkBoxStatus.contains("ui-icon-check") || checkBoxStatus.contains("pi-check")) {
				checkBoxStatus = "true";
			} else if (checkBoxStatus.contains("ui-icon-blank")
					|| checkBoxStatus.endsWith("ui-chkbox-icon ui-clickable")) {
				checkBoxStatus = "false";
			}
			if ((boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check"))
					&& checkBoxStatus.equalsIgnoreCase("false")) {
				ToolManager.agJavaScriptExecuctorClick(WorkFlowPageObjects.checkBoxLeftOf(label));
			} else if ((boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck"))
					&& checkBoxStatus.equalsIgnoreCase("true")) {
				ToolManager.agJavaScriptExecuctorClick(WorkFlowPageObjects.checkBoxLeftOf(label));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select list type dropdown value.
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 16-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDownValue(String locator, String valueToSelect) {
		if (!valueToSelect.equalsIgnoreCase("#skip#")) {
			// agJavaScriptExecuctorScrollToElement(locator);
			agSetStepExecutionDelay("2000");
			agClick(locator);
			agClick(WorkFlowPageObjects.selectListDropDown(locator, valueToSelect));
			// agCheckPropertyText(valueToSelect, locator);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select list type dropdown value.
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 16-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setListDropDownValue(String locator, String valueToSelect) {
		if (!valueToSelect.equalsIgnoreCase("#skip#")) {
			// agJavaScriptExecuctorScrollToElement(locator);
			agSetStepExecutionDelay("2000");
			agClick(locator);
			agClick(WorkFlowPageObjects.selectList(locator, valueToSelect));
			// agCheckPropertyText(valueToSelect, locator);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Check/Uncheck Operation on
	 *             CheckBox under Specified Label.
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 16-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickCheckBoxUnder(String label, String boolCheck) {
		if (!boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = null;
			checkBoxStatus = ToolManager.agGetAttribute("class", WorkFlowPageObjects.checkBoxUnder(label));
			if (checkBoxStatus.contains("blank") || !checkBoxStatus.contains("pi-check")) {
				checkBoxStatus = "false";
			} else {
				checkBoxStatus = "true";
			}
			if ((boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check"))
					&& checkBoxStatus.equalsIgnoreCase("false")) {
				ToolManager.agClick(WorkFlowPageObjects.checkBoxUnder(label));
			} else if ((boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck"))
					&& checkBoxStatus.equalsIgnoreCase("true")) {
				ToolManager.agClick(WorkFlowPageObjects.checkBoxUnder(label));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Check/Uncheck Operation on
	 *             CheckBox under Specified Label
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 16-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCheckBoxUnder(String label, String boolCheck) {
		if (!label.trim().contains("#skip#") && !boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = agGetAttribute("class", WorkFlowPageObjects.checkBoxUnder(label));
			if (boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check")) {
				if (!checkBoxStatus.contains("ui-state-active")) {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is not checked", true);
				} else {
					Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is checked", false);
				}
			} else if (boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck")) {
				if (checkBoxStatus.contains("ui-state-active")) {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is checked", true);
				} else {
					Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is not checked", false);
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Check/Uncheck Operation on
	 *             CheckBox for Specified Label.
	 * @InputParameters: span, boolCheck
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 16-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickCheckBox(String label, String boolCheck) {
		if (!boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = null;
			checkBoxStatus = ToolManager.agGetAttribute("class", WorkFlowPageObjects.checkBox(label));
			if (checkBoxStatus.contains("blank") || !checkBoxStatus.contains("pi-check")) {
				checkBoxStatus = "false";
			} else {
				checkBoxStatus = "true";
			}
			if ((boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check"))
					&& checkBoxStatus.equalsIgnoreCase("false")) {
				ToolManager.agClick(WorkFlowPageObjects.checkBox(label));
			} else if ((boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck"))
					&& checkBoxStatus.equalsIgnoreCase("true")) {
				ToolManager.agClick(WorkFlowPageObjects.checkBox(label));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Check/Uncheck Operation on
	 *             radio button under Specified Label.
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 16-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickRadioBtn(String label, String boolCheck) {
		if (!boolCheck.trim().contains("#skip#")) {
			String radioBtnStatus = null;
			radioBtnStatus = ToolManager.agGetAttribute("class", WorkFlowPageObjects.radioButton(label));
			if (radioBtnStatus.contains("blank") || !radioBtnStatus.contains("pi-check")) {
				radioBtnStatus = "false";
			} else {
				radioBtnStatus = "true";
			}
			if ((boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check"))
					&& radioBtnStatus.equalsIgnoreCase("false")) {
				ToolManager.agClick(WorkFlowPageObjects.radioButton(label));
			} else if ((boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck"))
					&& radioBtnStatus.equalsIgnoreCase("true")) {
				ToolManager.agClick(WorkFlowPageObjects.radioButton(label));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to Navigate to the XML Doc Config Page
	 * @InputParameters:
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void WorkflowConfigNavigation() {

		agMouseHover(WorkFlowPageObjects.Links(WorkFlowPageObjects.Administartion));
		agClick(WorkFlowPageObjects.Links(WorkFlowPageObjects.Workflow));
		agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.NewBtn);
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to Set the Submission due data and Affiliate
	 *             due date for ISP Submsiion workflow
	 * @InputParameters: scenario Name
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 26-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void SetSubmissionDateAndAffiliateDate(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		try {
			Reports.ExtentReportLog("", Status.INFO,
					"Set the Submission due data and Affiliate due date for ISP Submsiion workflow Starts", false);
			WorkflowConfigNavigation();
			agClick(WorkFlowPageObjects.editSubmissionWorkflow);
			agWaitTillVisibilityOfElement(WorkFlowPageObjects.Links(WorkFlowPageObjects.ActivityDueDates));
			agClick(WorkFlowPageObjects.Links(WorkFlowPageObjects.ActivityDueDates));
			agWaitTillVisibilityOfElement(WorkFlowPageObjects.ActivityDueDateFields(WorkFlowPageObjects.CaseDueDateDD,
					WorkFlowPageObjects.Initial));
			// Initial
			// System.out.println(getTestDataCellValue(scenarioName, "InitialCaseDueDate"));
			agSetStepExecutionDelay("2000");
			agClick(WorkFlowPageObjects.ActivityDueDateFields(WorkFlowPageObjects.CaseDueDateDD,
					WorkFlowPageObjects.Initial));
			agClick(WorkFlowPageObjects.CaseDDValue.replace("%index", "1").replace("%s",
					getTestDataCellValue(scenarioName, "InitialCaseDueDate").trim()));

			agSetValue(
					WorkFlowPageObjects.ActivityDueDateFields(WorkFlowPageObjects.ActivityDueDateValue,
							WorkFlowPageObjects.Initial),
					getTestDataCellValue(scenarioName, "InitialActivityDueDateValue"));

			String lateness = getTestDataCellValue(scenarioName, "InitialLatness");

			if (lateness.equalsIgnoreCase("YES")) {
				if (!checkBoxChecked(WorkFlowPageObjects.ActivityDueDateFields(
						WorkFlowPageObjects.latensessCheckBoxChecked, WorkFlowPageObjects.Initial))) {
					agClick(WorkFlowPageObjects.ActivityDueDateFields(WorkFlowPageObjects.latensessCheckBoxChecked,
							WorkFlowPageObjects.Initial));
				}
				agClick(WorkFlowPageObjects.ActivityDueDateFields(WorkFlowPageObjects.LatenessReasonDD,
						WorkFlowPageObjects.Initial));
				agClick(WorkFlowPageObjects.LatenessReasonDDValue.replace("%index", "0").replace("%s",
						getTestDataCellValue(scenarioName, "InitialLatnessReason").trim()));

			}

			// Local Submission
			agClick(WorkFlowPageObjects.ActivityDueDateFields(WorkFlowPageObjects.CaseDueDateDD,
					WorkFlowPageObjects.LocalSubmission));
			agClick(WorkFlowPageObjects.CaseDDValue.replace("%index", "2").replace("%s",
					getTestDataCellValue(scenarioName, "InitialCaseDueDate").trim()));
			agSetValue(
					WorkFlowPageObjects.ActivityDueDateFields(WorkFlowPageObjects.ActivityDueDateValue,
							WorkFlowPageObjects.LocalSubmission),
					getTestDataCellValue(scenarioName, "LocalSubmissionActivityDueDateValue"));

			lateness = getTestDataCellValue(scenarioName, "LocalSubmissionLatness");

			if (lateness.equalsIgnoreCase("YES")) {
				if (!checkBoxChecked(WorkFlowPageObjects.ActivityDueDateFields(
						WorkFlowPageObjects.latensessCheckBoxChecked, WorkFlowPageObjects.LocalSubmission))) {
					agClick(WorkFlowPageObjects.ActivityDueDateFields(WorkFlowPageObjects.latensessCheckBoxChecked,
							WorkFlowPageObjects.LocalSubmission));
				}
				agClick(WorkFlowPageObjects.ActivityDueDateFields(WorkFlowPageObjects.LatenessReasonDD,
						WorkFlowPageObjects.LocalSubmission));
				agClick(WorkFlowPageObjects.LatenessReasonDDValue.replace("%index", "1").replace("%s",
						getTestDataCellValue(scenarioName, "LocalSubmissionLatnessReason").trim()));
			}

			// Submission Review
			agClick(WorkFlowPageObjects.ActivityDueDateFields(WorkFlowPageObjects.CaseDueDateDD,
					WorkFlowPageObjects.SubmissionReview));
			agClick(WorkFlowPageObjects.CaseDDValue.replace("%index", "3").replace("%s",
					getTestDataCellValue(scenarioName, "SubmissionReviewCaseDueDate").trim()));
			agSetValue(
					WorkFlowPageObjects.ActivityDueDateFields(WorkFlowPageObjects.ActivityDueDateValue,
							WorkFlowPageObjects.SubmissionReview),
					getTestDataCellValue(scenarioName, "SubmissionReviewActivityDueDateValue"));

			lateness = getTestDataCellValue(scenarioName, "SubmissionReviewLatness");

			if (lateness.equalsIgnoreCase("YES")) {
				if (!checkBoxChecked(WorkFlowPageObjects.ActivityDueDateFields(
						WorkFlowPageObjects.latensessCheckBoxChecked, WorkFlowPageObjects.SubmissionReview))) {
					agClick(WorkFlowPageObjects.ActivityDueDateFields(WorkFlowPageObjects.latensessCheckBoxChecked,
							WorkFlowPageObjects.SubmissionReview));
				}
				agClick(WorkFlowPageObjects.ActivityDueDateFields(WorkFlowPageObjects.LatenessReasonDD,
						WorkFlowPageObjects.SubmissionReview));
				agClick(WorkFlowPageObjects.LatenessReasonDDValue.replace("%index", "2").replace("%s",
						getTestDataCellValue(scenarioName, "SubmissionReviewLatnessReason").trim()));
			}
			agSetStepExecutionDelay(Constants.defaultGlobalStepExecutionDelay + "");
			agClick(WorkFlowPageObjects.saveButton);
			agWaitTillVisibilityOfElement(WorkFlowPageObjects.ConfirmationPopUp);
			agWaitTillVisibilityOfElement(WorkFlowPageObjects.ConfirmationPopUpOk);
			agClick(WorkFlowPageObjects.ConfirmationPopUpOk);
			Reports.ExtentReportLog("", Status.INFO,
					"Set the Submission due data and Affiliate due date for ISP Submsiion workflow is Sucessfull",
					true);
			agClick(WorkFlowPageObjects.cancelButton);
			agWaitTillVisibilityOfElement(WorkFlowPageObjects.NewConfigBtn);
			Reports.ExtentReportLog("", Status.INFO,
					"Set the Submission due data and Affiliate due date for ISP Submsiion workflow Ends", false);
		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL,
					"Set the Submission due data and Affiliate due date for ISP Submsiion workflow Failed", false);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to check whethere the check box is slected or
	 *             not
	 * @InputParameters:
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 26-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static boolean checkBoxChecked(String locator) {
		boolean result = false;
		String value = agGetAttribute("class", locator);
		if (value.contains("ui-state-active"))
			result = true;
		return result;
	}

}
