package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class Product_LookupPageObjects {

	public static String productNameTextbox = "xpath#//label[contains(text(),'Product Name')]/ancestor::div/input[@type='text']";
	public static String level1ProductTextbox = "xpath#//label[contains(text(),'{0}')]/ancestor::div/input[@type='text']";

	public static String searchButton = "xpath#//span[contains(text(),'Search')]/ancestor::button";
	// public static String okButton =
	// "xpath#//button[@id='productLookupForm:bottomOkButton']";
	public static String okButton = "xpath#//p-dialog//div/button/span[text()='OK']";
	public static String cancelButton = "xpath#//button[@id='productLookupForm:bottomCancelButton']";
	public static String prodLibOkButton = "xpath#//div[contains(@class,'agSearchprodcutTable')]//div/button/span[text()='OK' or text()='Ok']";
	public static String prodLibCancelButton = "xpath#//button[@label='Cancel']";

	public static String prodLookUpListing_Chkbox = "xpath#//*[starts-with(normalize-space(text()),'%labelName%')]/ancestor::tr/td/descendant::div/span[contains(@class, 'ui-chkbox-icon')]";
	public static String prodLookUpListing_Radio = "xpath#//*[starts-with(normalize-space(text()),'%labelName%')]/ancestor::tr/td/descendant::div/span[contains(@class, 'ui-radiobutton-icon')]";
	public static String LibStudyFirstProductChkbox = "xpath#//tr[@data-ri='0']/td/div[@class='ui-chkbox ui-widget']";
	public static String checkFirstProdInProdLib = "xpath#//p-table[@class='agcommonTblStyle proLibTblDialog']//tbody/tr[1]/td/p-tableradiobutton";

	public static String productLibray_RadioBtn = "xpath#//label[text()='Product Library']/ancestor::p-radiobutton/div/child::div/span";
	public static String indication_Popup = "xpath#//span[contains(@class,'ui-dialog-title')][text()='Indications']";
	public static String indicationPopup_CloseIcon = "xpath#//span[contains(@class,'ui-dialog-title')][text()='Indications']/following-sibling::a";
	public static String prodDescAsRepNullButton = "xpath#(//div[@class='ui-tabview-panels']//a[@class='agNfAppliedLink'])[16]";

	public static String prodLookUpSelectChkbox = "xpath#(//tbody[@class='ui-table-tbody']/tr/td//div[@class='ui-chkbox ui-widget'])[1]";

	// p-dialog[contains(@class,'agIndicationDailog')]/div//button[@type='button']/span[text()='Cancel']
	public static String prodLibproductNameTextbox = "Product Name";
	public static String localTradeName = "xpath#//span[text()='Local TradeNames']";
	public static String FDAProdName = "xpath#//label[text()='Preferred Product Description / Synonym']/following-sibling::input";
	public static String prodLibTradeNameTextBox = "Trade/Brand Name";
	public static String prodName = "Preferred Product Description";

	// Product lookup level 2

	public static String ProductName_TxtfieldLookup = "xpath#//label[text()='Product Name']/following-sibling::input";
	public static String activeRadioButtonLv2_Label = "xpath#//p-radiobutton[@name='licenseActive']/label[text()='Active']";
	public static String inactiveRadioButtonLv2_Label = "xpath#//p-radiobutton[@name='licenseInActive']/label[text()='Inactive']";
	public static String bothRadioButtonlv2_Label = "xpath#//p-radiobutton[@name='licenseBoth']/label[text()='Both']";
	public static String activeRadioButtonLv2 = "xpath#//p-radiobutton[@name='licenseActive']//div[contains(@class,'ui-state-active')]";

	// Product lookup level 1
	public static String activeRadioButtonLv1_Label = "xpath#//p-radiobutton[@name='productLookupActive']/label[text()='Active']";
	public static String inactiveRadioButtonlv1_Label = "xpath#//p-radiobutton[@name='productLookupInActive']/label[text()='Inactive']";
	public static String bothRadioButtonLv1_Label = "xpath#//p-radiobutton[@name='productLookupBoth']/label[text()='Both']";
	public static String activeRadioButtonLv1 = "xpath#//p-radiobutton[@name='productLookupActive']//div[contains(@class,'ui-state-active')]";

	public static String alreadyCodedPopUp = "xpath#//span[text()='Existing Term is already Coded. Do you want to recode?']";
	public static String alreadyCodedYesBtn = "xpath#//div[@class='ui-dialog-footer ui-widget-content ng-tns-c12-26 ng-star-inserted']//span[text()='Yes']";

	public static String level1ProductTextbox(String label) {
		String value = level1ProductTextbox.replace("{0}", label);
		return value;

	}

	public static String selectProdLookUpListingCheckBox(String label) {
		String value = prodLookUpListing_Chkbox.replace("%labelName%", label);
		return value;
	}

	public static String selectProdLookUpListing_Radio(String label) {
		String value = prodLookUpListing_Radio.replace("%labelName%", label);
		return value;
	}
}
