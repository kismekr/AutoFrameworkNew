package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class TasksPageObjects {
	
	public static String tasksHover = "xpath#//span[contains(text(),'Tasks')]";
	public static String tasksNew = "xpath#//a[@id='headerForm:tasksNewId']//span[@class='ui-menuitem-text'][contains(text(),'New')]";
	public static String tasksNewLable = "xpath#//span[@class='ui-panel-title']/label[text()='Basic Details']";
	public static String tasksListing = "xpath#//a[@id='headerForm:tasksListId']//span[@class='ui-menuitem-text'][contains(text(),'Listing')]";
	public static String tasksListingLable = "xpath#//span[@id='taskFormlisting:taskSrcPanel']//label[text()='Listing']";
	public static String tasksListingKeywordSearch = "xpath#//input[@id='taskFormlisting:keyword']";
	public static String keywordSearchIcon = "xpath#//img[contains(@src,'search_icon')]";
	public static String searchRec = "xpath#//span[text()='%s']//parent::a[@id='taskFormlisting:taskDataTablenew:0:taskId1']//parent::td//preceding-sibling::td//a";
	public static String paginator = "xpath#//div[@id='taskFormlisting:taskDataTablenew_paginator_top']/span[@class='ui-paginator-current']";
	
	
	
	//ListingScreen
	public static String editIcon = "xpath#//tbody[@id='taskFormlisting:taskDataTablenew_data']//tr[1]//img[contains(@id,'editImgId')]";
	public static String refreshLink = "xpath#//label[text()='Refresh']";
	public static String refreshIcon = "xpath#//img[@title='Refresh Listing Screen']";
	public static String archiveButton = "xpath#//a[@title='Archive Task']";
	public static String listingcheckBox = "xpath#//a[@id='taskFormlisting:taskDataTablenew:0:editTaskId']/ancestor::tbody[@id='taskFormlisting:taskDataTablenew_data']/tr//div//span";
	public static String deleteconfirmationPopup = "xpath#//span[@class='ui-confirm-dialog-message']";
	public static String archivePopup = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	
	
	public static String deletepopupYesButton = "xpath#//button[@id='taskFormlisting:deluserConfirm1']";
	public static String deletepopupOkButton = "xpath#//button[@id='mandatoryDialogform:okButton']";
			
	//NewScreen
	public static String savebutton = "xpath#//button[@id='taskForm:visibleSave']";
	public static String cancelbutton = "xpath#//button[@id='taskForm:cancelId']";
	public static String createdDateTextbox = "xpath#//label[text()='Created Date']//parent::div//input[@title='Scheduled Date']";
	
	public static String relatedModuleDropdown = "xpath#//label[@id='taskForm:rtdid_label']";
	public static String caseTaskTypeDropdown = "xpath#//label[@id='taskForm:C-9873_label']";
	public static String caseTaskTypeDropdownListValue = "xpath#//li[text()='%s']";
	public static String caseTaskTypeTextbox = "xpath#//span[contains(@id,'CaseTypePanel')]//input[@id='taskForm:SubjectID']";
	public static String commentsTextarea = "xpath#//textarea[@id='taskForm:commenttaskID']";
	public static String priorityDropdown = "xpath#//label[@id='taskForm:C-905_label']";
	public static String taskStatusDropdown = "xpath#//label[@id='taskForm:taskstatus_label']";
	public static String replyStatusDropdown = "xpath#//label[@id='taskForm:C-9871_label']";
	
	public static String replyDateTextbox = "xpath#//input[@id='taskForm:replyDate_input']";
	public static String scheduledDateTextbox = "xpath#//input[@id='taskForm:scheduledDate_input']";
	public static String actualCompletionDateTextbox = "xpath#//input[@id='taskForm:completionId_input']";
	
	public static String createdDateLabel = "Created Date";
	public static String replyDateLabel = "Reply Date";
	public static String scheduledDateLabel = "Scheduled Date";
	public static String actualCompletionDateLabel = "Actual Completion Date";
	
	//Reminder Details
	public static String plannedCompletionDateTextbox = "xpath#//input[@id='taskForm:duedatetaskId_input']";
	public static String remainderOnDateTextbox = "xpath#//input[@id='taskForm:remindertaskId_input']";
	public static String plannedCompletionDateLabel = "Planned Completion Date";
	public static String remainderOnDateLabel = "Reminder On";
	
	//public static String setDatesTextboxes = "xpath#//label[text()='%s']//parent::div//input[@title='%s']";
	public static String setDatesTextboxes = "xpath#//label[text()='%s']//parent::div//input[contains(@class, 'Datepicker')]";
	
	public static String monthSelect = "xpath#//div[@class='ui-datepicker-title']/select[@class='ui-datepicker-month']";
	public static String yearSelect = "xpath#//div[@class='ui-datepicker-title']/select[@class='ui-datepicker-year']";
	public static String monthDropdown = "xpath#//div[@class='ui-datepicker-title']/select[@class='ui-datepicker-month']/option[text()='{@}']";
	public static String yearDropdown = "xpath#//div[@class='ui-datepicker-title']/select[@class='ui-datepicker-year']/option[text()='{@}']";
	public static String dateSelect = "xpath#//a[contains(@class,'ui-state-default')][text()='{@}']";
	
	//export to execl
	
	public static String downloadIcon = "xpath#//a[@id='taskFormlisting:actionId']";
	public static String exporttoExcel_link = "xpath#//button[contains(@id,'taskFormlisting:excelID')]/span[text()='Export To Excel']";
	public static String exporttoExcel_popup = "xpath#//span[@id='listingForm:columnSelectionDialogId_title']";
	public static String export_Btn= "xpath#//button[@id='taskFormlisting:submitIdpopup']";
	public static String exportexcelcancel_Btn= "xpath#//button[@id='taskFormlisting:cancelDialogId']";
	
	
	public static String dateSelect(String date) {
		String value = dateSelect;
		value = value.replace("{@}", date);
		return value;
	}

	public static String monthDropdown(String month) {
		String value = monthDropdown;
		value = value.replace("{@}", month);
		return value;
	}

	public static String yearDropdown(String year) {
		String value = yearDropdown;
		value = value.replace("{@}", year);
		return value;
	}
		
	//Distribution Contact Information
	public static String authorityDropdown = "xpath#//label[@id='taskForm:C1-42_label']";
	public static String contactDropdown = "xpath#//label[@id='taskForm:C2-9908_label']";
	
	
	
	//Document
	public static String uploadButton = "xpath#//span[text()='Upload file']//following-sibling::input";
	public static String deleteDocsButton = "xpath#//a[@id='taskForm:deleteDocumentss']";
	public static String docsDescriptionTextbox = "xpath#//a[text()='%s']//parent::td//following-sibling::td//input";
	public static String selectDocumentCheckbox = "xpath#//a[text()='%s']//parent::td//preceding-sibling::td//span";
	
	//User/Group Assignment Details
	public static String userRadio_Btn = "User";
	public static String groupRadio_Btn = "Group";
	//public static String selectUserOrGroupRadio = "xapth#//label[text()='%s']//parent::td//div[2]//span//parent::div";
	public static String selectUserOrGroupRadio = "xpath#//label[contains(@for,'taskForm:j_id')][text()='%s']";
	public static String userList_SourceFilter = "xpath#//div[@id='taskForm:assignmentPicklistPnlGrp']//input[contains(@id,'source_filter')]";
	public static String userList_TargetFilter = "xpath#//div[@id='taskForm:assignmentPicklistPnlGrp']//input[contains(@id,'target_filter')]";
	
	public static String add_PicklistItem = "xpath#//div[@class='ui-picklist-buttons']//button[@title='Add']";
	public static String addAll_PicklistItem = "xpath#//div[@class='ui-picklist-buttons']//button[@title='Add All']";
	public static String remove_PicklistItem = "xpath#//div[@class='ui-picklist-buttons']//button[@title='Remove']";
	public static String removeAll_PicklistItem = "xpath#//div[@class='ui-picklist-buttons']//button[@title='Remove All']";
	
	public static String groupList_Item = "xpath#//div[@class='ui-picklist-list-wrapper']//ul[@aria-label='Group List']//li[@data-item-label='%s']";
	public static String userList_Item = "xpath#//div[@class='ui-picklist-list-wrapper']//ul[@aria-label='User List']//li[@data-item-label='%s']";
	
	public static String select_GroupList_Item(String group) {
        String value = groupList_Item.replace("%s", group);
        return value;
    }
	
	public static String select_UserList_Item(String user) {
        String value = userList_Item.replace("%s", user);
        return value;
    }
	
	public static String selectCaseTaskTypeDropdownListValue(String item) {
        String value = caseTaskTypeDropdownListValue.replace("%s", item);
        return value;
    }
	
	public static String setDatesTextboxes(String label) {
        String value = setDatesTextboxes.replace("%s", label);
        return value;
    }
	
	public static String docsDescriptionTextbox(String fileName) {
        String value = docsDescriptionTextbox.replace("%s", fileName);
        return value;
    }
	
	public static String selectDocumentCheckbox(String fileName) {
        String value = selectDocumentCheckbox.replace("%s", fileName);
        return value;
    }
	
	public static String selectUserOrGroupRadio(String label) {
        String value = selectUserOrGroupRadio.replace("%s", label);
        return value;
    }
	
	public static String searchRec(String taskId) {
        String value = searchRec.replace("%s", taskId);
        return value;
    }
}
