package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AppParameters_CaseManagementPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDEContactLookupPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDELookupsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_EventsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_PatientPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_ProductsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_ReporterPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.WorkFlowPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_General extends ToolManager {
	public static WebElement webElement;
	static String className = FDE_General.class.getSimpleName();
	static boolean status;
	static String[] skipData = { "#skip#" };
	static String caseSignificanceVal = null;
	static String reportClassificationVal = null;

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 25-Jul-2019
	 * @UpdatedByAndWhen: Padmapriya (15/3/2021)
	 **********************************************************************************************************/
	public static void setDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.selectGeneralDroprdown(label));
			agSetGlobalTimeOut("1");
			if (agIsExists(FDE_GeneralPageObjects.alreadyCodedWarning)) {
				// agSetGlobalTimeOut("1");
				agClick(FDE_GeneralPageObjects.recodeNoBtn);
				agSetStepExecutionDelay("2000");
				agClick(FDE_GeneralPageObjects.selectGeneralDroprdown(label));
				agClick(FDE_GeneralPageObjects.selectGeneralDroprdown(label));
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				// agSetGlobalTimeOut("60");
			}
			agSetGlobalTimeOut("30");
			agJavaScriptExecuctorClick(
					FDE_GeneralPageObjects.clickDropDownValue(getTestDataCellValue(scenarioName, columnName)));

		} else {
			if (getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("NoData")) {
				agClick(FDE_GeneralPageObjects.selectGeneralDroprdown(label));
				agJavaScriptExecuctorClick(FDE_GeneralPageObjects.noDropDownValue);

			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 05-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDownValue(String label, String testdataValue) {
		agClick(FDE_GeneralPageObjects.selectGeneralDroprdown(label));
		agSetGlobalTimeOut("1");
		if (agIsExists(FDE_GeneralPageObjects.alreadyCodedWarning)) {
			// agSetGlobalTimeOut("1");
			agClick(FDE_GeneralPageObjects.recodeNoBtn);
			agSetStepExecutionDelay("2000");
			agClick(FDE_GeneralPageObjects.selectGeneralDroprdown(label));
			agClick(FDE_GeneralPageObjects.selectGeneralDroprdown(label));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			// agSetGlobalTimeOut("60");
		}
		agSetGlobalTimeOut("30");
		agJavaScriptExecuctorClick(FDE_GeneralPageObjects.clickDropDownValue(testdataValue));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value in sender
	 *             organization lookup
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 25-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void senderlookup_setDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDELookupsPageObjects.companyunit_clickDropDown(label));
			agClick(FDELookupsPageObjects.companyunit_SetdropDownValue(getTestDataCellValue(scenarioName, columnName)));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Case dates in FDE General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 25-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCaseDates(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "CustomDateFlag").equalsIgnoreCase("YES")) {
			agSetValue(FDE_GeneralPageObjects.initialReceiveDate,
					getTestDataCellValue(scenarioName, "Gen_CaseDates_InitialReceivedDate"));
			agSendKeyStroke(Keys.TAB);
			agSetValue(FDE_GeneralPageObjects.latestReceiveDate,
					getTestDataCellValue(scenarioName, "Gen_CaseDates_LatestReceivedDate"));
			agSendKeyStroke(Keys.TAB);
			CommonOperations.captureScreenShot(true);
		} else {
			agSetValue(FDE_GeneralPageObjects.initialReceiveDate, CommonOperations
					.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_InitialReceivedDate")));
			agSetValue(FDE_GeneralPageObjects.latestReceiveDate, CommonOperations
					.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_LatestReceivedDate")));
		}
		agSetValue(FDE_GeneralPageObjects.regulatoryStartDate, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_RegulatoryClockStartDate")));
		agSetValue(FDE_GeneralPageObjects.caseDueDate,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_CaseDueDate")));
		agSetValue(FDE_GeneralPageObjects.submissionDueDate,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_SubmissionDueDate")));
		agSetValue(FDE_GeneralPageObjects.aerCloseDate,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_AERCloseDate")));

		String[] ColumnTitles = { "Initial Receive Date", "Latest Receive Date", "Regulatory Start Date",
				"case Due Date", "Submission Due Date", "AER Close Date" };
		String[] ColumnName = { "Gen_CaseDates_InitialReceivedDate", "Gen_CaseDates_LatestReceivedDate",
				"Gen_CaseDates_RegulatoryClockStartDate", "Gen_CaseDates_CaseDueDate",
				"Gen_CaseDates_SubmissionDueDate", "Gen_CaseDates_AERCloseDate" };
		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, skipData);
		Reports.ExtentReportLog("", Status.INFO,
				"Data enetered in General tab Case dates section: Scenario Name::" + scenarioName, false);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set multi Value DropDown in FDE
	 *             General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 25-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void multiValueDropDown(String el, String dropdownValue) {
		if (dropdownValue != "" && dropdownValue != null) {
			agClick(el);
			String excelData = dropdownValue;
			String[] data = excelData.split(",");
			if (data.length == 1) {
				agClick(FDE_GeneralPageObjects.reportClassification(dropdownValue.trim()));
			} else {
				for (int i = 0; i < data.length; i++) {
					agClick(FDE_GeneralPageObjects.reportClassification(data[i].trim()));
				}
			}
			// agClick(el);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Sender Organization As Coded
	 *             in Case Unit details in FDE General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 14-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSenderOrganizationCoded(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Gen_CaseUnits_SenderOrganizationAsCoded_Lookup").equals("Yes")) {
			agClick(FDE_GeneralPageObjects.senderOrganizationasCodedLookup);
			search_CompanyUnit(scenarioName);
			search_Account(scenarioName);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search company unit in Set Sender
	 *             Organization in Case Unit details in FDE General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 14-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void search_CompanyUnit(String scenarioName) {
		if (getTestDataCellValue(scenarioName, "Gen_SenderPartnerLookup_CompanyUnit").equals("Yes")) {
			agClick(FDELookupsPageObjects.companyUnit_Radiobtn);
			// agSetValue(FDELookupsPageObjects.set_Textfields(FDELookupsPageObjects.companyUnitCode_Textfield),
			// getTestDataCellValue(scenarioName, "Gen_SenderCompanyUnitCode"));//Added
			agSetValue(FDELookupsPageObjects.set_Textfields(FDELookupsPageObjects.companyUnitName_Textfield),
					getTestDataCellValue(scenarioName, "Gen_SenderCompanyUnitName"));
			// senderlookup_setDropDownValue(FDELookupsPageObjects.type_Dropdown,
			// scenarioName, "Gen_SenderCompanyUnit_Type");//Added
			// senderlookup_setDropDownValue(FDELookupsPageObjects.country_Dropdown,
			// scenarioName, "Gen_SenderCompanyUnit_Country");//Added
			agClick(FDELookupsPageObjects.searchSenderButton);
			agSetStepExecutionDelay("2000");
			agClick(FDELookupsPageObjects.radioButton);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			// CommonOperations.takeScreenShot();
			agJavaScriptExecuctorClick(FDELookupsPageObjects.senderOkBtn);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search account in Sender
	 *             Organization As Coded in Case Unit details in FDE General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 14-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void search_Account(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Gen_SenderPartnerLookup_Account").equals("Yes")) {
			// agClick(FDELookupsPageObjects.sender_Radiobtn);
			agSetValue(FDELookupsPageObjects.set_Textfields(FDELookupsPageObjects.accountName_Textfield),
					getTestDataCellValue(scenarioName, "Gen_SenderAccountName"));
			// agSetValue(FDELookupsPageObjects.set_Textfields(FDELookupsPageObjects.domain_Textfield),
			// getTestDataCellValue(scenarioName, "Gen_SenderDomain"));
			// agSetValue(FDELookupsPageObjects.set_Textfields(FDELookupsPageObjects.firm_SiteFEINumber_Textfield_),
			// getTestDataCellValue(scenarioName, "Gen_SenderFirm_SiteNumber"));
			agClick(FDELookupsPageObjects.searchSenderButton);
			agSetStepExecutionDelay("2000");
			agClick(FDELookupsPageObjects.radioButton);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CommonOperations.takeScreenShot();
			agClick(FDELookupsPageObjects.senderOkBtn);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Case Unit details in FDE
	 *             General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 14-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCaseUnitsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		setDropDownValue(FDE_GeneralPageObjects.companyUnit_Dropdown, scenarioName, "Gen_CaseUnits_CompanyUnit");
		setSenderOrganizationCoded(scenarioName);
		agSetValue(FDE_GeneralPageObjects.setTextField(FDE_GeneralPageObjects.senderOrganization_LookupField),
				getTestDataCellValue(scenarioName, "Gen_CaseUnits_SenderOrganizationAsReported"));
		setDropDownValue(FDE_GeneralPageObjects.processingUnit_Dropdown, scenarioName, "Gen_CaseUnits_ProcessingUnit");
		setDropDownValue(FDE_GeneralPageObjects.localCriteriaReportType_Dropdown, scenarioName,
				"Gen_CaseUnits_localCriteriaReportType");
		CommonOperations.captureScreenShot(true);

		String[] ColumnName = { "Gen_CaseUnits_CompanyUnit", "Gen_SenderPartnerLookup_CompanyUnit",
				"Gen_SenderAccountName", "Gen_CaseUnits_SenderOrganizationAsReported", "Gen_CaseUnits_ProcessingUnit",
				"Gen_CaseUnits_localCriteriaReportType" };
		String[] ColumnTitles = { FDE_GeneralPageObjects.companyUnit_Dropdown, "CompanyUnit",
				FDELookupsPageObjects.accountName_Textfield, FDE_GeneralPageObjects.senderOrganization_LookupField,
				FDE_GeneralPageObjects.processingUnit_Dropdown,
				FDE_GeneralPageObjects.localCriteriaReportType_Dropdown };
		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, skipData);
		Reports.ExtentReportLog("", Status.INFO,
				"Data enetered in General tab Case Unit section: Scenario Name::" + scenarioName, false);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Case report details in FDE
	 *             General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 14-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCaseReportDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.caseReportlabel);
		setDropDownValue(FDE_GeneralPageObjects.reportType_Dropdown, scenarioName, "Gen_CaseReport_ReportType");

		if (agIsVisible(FDE_GeneralPageObjects.ReportTypeChangeConfirmation)) {

			agClick(FDE_GeneralPageObjects.ReportTypeChangeConfirmation_Yes);
		}

		agSetStepExecutionDelay("5000");
		status = agIsVisible(FDE_GeneralPageObjects.ReportTypeStudy);
		if (status) {
			CommonOperations.captureScreenShot(true);
		}
		setDropDownValue(FDE_GeneralPageObjects.reportCategory_Dropdown, scenarioName, "Gen_CaseReport_ReportCategory");
		agSetStepExecutionDelay("3000");
		CommonOperations.captureScreenShot(true);
		if (!getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportClassification").trim().contains("#skip#")) {
			multiValueDropDown(FDE_GeneralPageObjects.ReportClassifiDropdown,
					getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportClassification"));
		}

		setDropDownValue(FDE_GeneralPageObjects.reportPriority_Dropdown, scenarioName, "Gen_CaseReport_ReportPriority");
		setDropDownValue(FDE_GeneralPageObjects.reportReceivingMedium_Dropdown, scenarioName,
				"Gen_CaseReport_ReportReceivingMedium");
		setDropDownValue(FDE_GeneralPageObjects.reportReceivingFormat_Dropdown, scenarioName,
				"Gen_CaseReport_ReportReceivingFormat");
		setInitial_Followup(scenarioName);
		setDropDownValue(FDE_GeneralPageObjects.NonCaseAssessmentReason_Dropdown, scenarioName,
				"Gen_CaseReport_NonCaseAssessmentReason");
		// setAssignTo(scenarioName);

		String[] ColumnTitles = { FDE_GeneralPageObjects.reportType_Dropdown,
				FDE_GeneralPageObjects.reportCategory_Dropdown, FDE_GeneralPageObjects.ReportClassifiDropdown,
				FDE_GeneralPageObjects.reportPriority_Dropdown, FDE_GeneralPageObjects.reportReceivingMedium_Dropdown,
				FDE_GeneralPageObjects.reportReceivingMedium_Dropdown,
				FDE_GeneralPageObjects.reportReceivingFormat_Dropdown,
				FDE_GeneralPageObjects.NonCaseAssessmentReason_Dropdown };
		String[] ColumnName = { "Gen_CaseReport_ReportType", "Gen_CaseReport_ReportCategory",
				"Gen_CaseReport_ReportClassification", "Gen_CaseReport_ReportPriority",
				"Gen_CaseReport_ReportReceivingMedium", "Gen_CaseReport_ReportReceivingFormat",
				"Gen_CaseReport_NonCaseAssessmentReason" };
		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, skipData);

		Reports.ExtentReportLog("", Status.INFO,
				"Data enetered in General tab Case report details section: ScenarioName::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Assign To in Case report
	 *             details in FDE General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 14-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setAssignTo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Gen_CaseReport_AssignTo").equalsIgnoreCase("User")) {
			agClick(FDE_GeneralPageObjects.assignToRadioBtn(FDE_GeneralPageObjects.userRadiobtn));
			agSetStepExecutionDelay("3000");
			// setDropDownValue(FDE_GeneralPageObjects.assignTo_Dropdown, scenarioName,
			// "Gen_CaseReport_User");
			CommonOperations.setListDropDownValue(FDE_GeneralPageObjects.assignTo_Dropdown,
					(getTestDataCellValue(scenarioName, "Gen_CaseReport_User")));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		if (getTestDataCellValue(scenarioName, "Gen_CaseReport_AssignTo").equalsIgnoreCase("Group")) {
			agClick(FDE_GeneralPageObjects.assignToRadioBtn(FDE_GeneralPageObjects.groupRadiobtn));
			setDropDownValue(FDE_GeneralPageObjects.assignTo_Dropdown, scenarioName, "Gen_CaseReport_Group");
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Initial_Followup in Case
	 *             report details in FDE General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 14-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setInitial_Followup(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Gen_CaseReport_Initial").equalsIgnoreCase("Yes")) {
			agClick(FDE_GeneralPageObjects.initial_Followup_RadioBtn(FDE_GeneralPageObjects.initialRadiobtn));
		}
		if (getTestDataCellValue(scenarioName, "Gen_CaseReport_FollowUp").equalsIgnoreCase("Yes")) {
			agClick(FDE_GeneralPageObjects.initial_Followup_RadioBtn(FDE_GeneralPageObjects.followUpRadiobtn));
			agSetValue(FDE_GeneralPageObjects.FollowUpRefNo,
					getTestDataCellValue(scenarioName, "Gen_CaseReport_FollowUpRefNo"));
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set General Basic Details in FDE
	 *             form
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void LSMVSetGeneralBasicDetails(String scenarioName) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,
		// "ConfigurationSettings");
		// if (getTestDataCellValue(scenarioName,
		// "FDE_General").equalsIgnoreCase("Yes")) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		setCaseUnitsDetails(scenarioName);
		setCaseDates(scenarioName);
		setCaseReportDetails(scenarioName);
		addContact_FDEForm(scenarioName);
		setCaseSpecificInfo(scenarioName);
		setAdditionalDocumentsDetails(scenarioName);
		setCaseReferencesDetails(scenarioName);
		setE2BCaseReferencesinPreviousTransmissionsDetails(scenarioName);
		// }

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify General Basic Details in
	 *             FDE form
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void generalDetails_Verification(String scenarioName) {
		caseUnits_Verification(scenarioName);
		caseDates_Verification(scenarioName);
		caseReport_Verification(scenarioName);
		contact_Verification(scenarioName);
		caseSpecificInformation_Verification(scenarioName);
		AdditionalDocuments_Verification(scenarioName);
		CaseReferences_Verification(scenarioName);
		e2BCaseReferencesInPreviousTransmissions_Verification(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify caseSeriousness in General
	 *             section
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 24-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void caseSeriousness_Verification(String scenarioName) {
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.caseSeriousness_Label);
		CommonOperations.verifyRadioButton(FDE_GeneralPageObjects.seriousness_Radiobtn,
				FDE_Events.getData(scenarioName, "Events_EventSeriousness_Seriousness"));
		CommonOperations.verifyRadioButton(FDE_GeneralPageObjects.death_Radiobtn,
				FDE_Events.getData(scenarioName, "Events_EventSeriousness_Death"));
		CommonOperations.verifyRadioButton(FDE_GeneralPageObjects.lifeThreatening_Radiobtn,
				FDE_Events.getData(scenarioName, "Events_EventSeriousness_LifeThreatening"));
		CommonOperations.verifyRadioButton(FDE_GeneralPageObjects.caused_prolongedhospitalization_Radiobtn,
				FDE_Events.getData(scenarioName, "Events_EventSeriousness_CausedProlongedHospitalization"));
		CommonOperations.verifyRadioButton(FDE_GeneralPageObjects.disability_PermanentDamage_Radiobtn,
				FDE_Events.getData(scenarioName, "Events_EventSeriousness_DisabilityPermanentDamage"));
		CommonOperations.verifyRadioButton(FDE_GeneralPageObjects.congenitalAnomalyBirthDefect_Radiobtn,
				FDE_Events.getData(scenarioName, "Events_EventSeriousness_CongenitalAnomalyBirthDefect"));
		CommonOperations.verifyRadioButton(FDE_GeneralPageObjects.OtherMedicallyCondition_Radiobtn,
				FDE_Events.getData(scenarioName, "Events_EventSeriousness_OtherMedicallyImportantCondition"));
		CommonOperations.verifyRadioButton(FDE_GeneralPageObjects.requiredIntervenation_Radiobtn,
				FDE_Events.getData(scenarioName, "Events_EventSeriousness_RequiredIntervention"));
		Reports.ExtentReportLog("", Status.INFO,
				"Data verification in General tab Case Seriousness section: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set General Reporter Details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addContact_FDEForm(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.contactlabel);
		agSetStepExecutionDelay("5000");
		agClick(FDEContactLookupPageObjects.contactLookUpIcon);
		agSetValue(FDEContactLookupPageObjects.FirstNameTextbox,
				getTestDataCellValue(scenarioName, "Gen_Contact_FirstName"));
		agSetValue(FDEContactLookupPageObjects.LastNameTextbox,
				getTestDataCellValue(scenarioName, "Gen_Contact_LastName"));
		agClick(FDEContactLookupPageObjects.SearchButton);
		agClick(FDEContactLookupPageObjects.CheckBox);
		Reports.ExtentReportLog("", Status.INFO,
				"Data enetered in General tab Reporter section: Scenario Name::" + scenarioName, false);
		CommonOperations.captureScreenShot(true);
		agClick(FDEContactLookupPageObjects.OkButton);
		agWaitTillInvisibilityOfElement(FDEContactLookupPageObjects.OkButton);

		agSetStepExecutionDelay("5000");
		agWaitTillVisibilityOfElement(FDEContactLookupPageObjects.contactLookUpIcon);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetStepExecutionDelay("2000");
		agClick(FDEContactLookupPageObjects.contactTab);
		status = agIsVisible(FDEContactLookupPageObjects.contactTab);
		if (status) {
			CommonOperations.captureScreenShot(true);
		}

		String[] ColumnTitles = { "First Name", "Last Name" };
		String[] ColumnName = { "Gen_Contact_FirstName", "Gen_Contact_LastName" };
		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, skipData);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in text field value
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyData(String object, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(object);
			agCheckPropertyValue("title", getTestDataCellValue(scenarioName, columnName), object);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform case unit data
	 *             verification in FDE form
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void contact_Verification(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(FDE_GeneralPageObjects.get_EmailId);
		verifyData(FDE_GeneralPageObjects.get_FirstName, scenarioName, "Gen_Contact_FirstName");
		String FirstName = Constants.actualVal;
		verifyData(FDE_GeneralPageObjects.get_LastName, scenarioName, "Gen_Contact_LastName");
		String LastName = Constants.actualVal;
		verifyData(FDE_GeneralPageObjects.get_EmailId, scenarioName, "Gen_Contact_EmailAddress");
		String EmailAddress = Constants.actualVal;

		String[] ColumnName = { "Gen_Contact_FirstName", "Gen_Contact_LastName", "Gen_Contact_EmailAddress" };
		String[] ColumnTitles = { "FirstName", "LastName", "EmailAddress" };
		String[] actval = { FirstName, LastName, EmailAddress };

		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, actval);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform case unit data
	 *             verification in FDE form
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void caseUnits_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// agCheckPropertyText(getTestDataCellValue(scenarioName, "ReceiptNo"),
		// FDE_GeneralPageObjects.get_RecieptId);
		String SenderAccountName = "";
		String SenderCompanyUnitName = "";
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Gen_CaseUnits_CompanyUnit"),
				FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.companyUnit_Dropdown));
		String CompanyUnit = Constants.actualVal;
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Gen_CaseUnits_ProcessingUnit"),
				FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.processingUnit_Dropdown));
		String ProcessingUnit = Constants.actualVal;
		if (getTestDataCellValue(scenarioName, "Gen_CaseUnits_SenderOrganizationAsCoded_Lookup").equals("Yes")
				&& getTestDataCellValue(scenarioName, "Gen_SenderPartnerLookup_Account").equals("Yes")) {
			agClick(FDE_GeneralPageObjects.getData_senderOrgLookupField);
			agCheckPropertyValue("title", getTestDataCellValue(scenarioName, "Gen_SenderAccountName"),
					FDE_GeneralPageObjects.getData_senderOrgLookupField);
			SenderAccountName = Constants.actualVal;
		} else if (getTestDataCellValue(scenarioName, "Gen_CaseUnits_SenderOrganizationAsCoded_Lookup").equals("Yes")
				&& getTestDataCellValue(scenarioName, "Gen_SenderPartnerLookup_CompanyUnit").equals("Yes")) {
			agClick(FDE_GeneralPageObjects.getData_senderOrgLookupField);
			agCheckPropertyValue("title", getTestDataCellValue(scenarioName, "Gen_SenderCompanyUnitName"),
					FDE_GeneralPageObjects.getData_senderOrgLookupField);
			SenderCompanyUnitName = Constants.actualVal;
		}

		verifyData(FDE_GeneralPageObjects.setTextField(FDE_GeneralPageObjects.senderOrganizationReporter_Textfield),
				scenarioName, "Gen_CaseUnits_SenderOrganizationAsReported");
		String senderOrganizationReporter = Constants.actualVal;
		Reports.ExtentReportLog("", Status.INFO,
				"Data verification in General tab Case unit section: Scenario Name::" + scenarioName, true);

		String[] ColumnName = { "Gen_CaseUnits_CompanyUnit", "Gen_CaseUnits_ProcessingUnit", "Gen_SenderAccountName",
				"Gen_SenderCompanyUnitName", "Gen_CaseUnits_SenderOrganizationAsReported" };
		String[] ColumnTitles = { FDE_GeneralPageObjects.companyUnit_Dropdown,
				FDE_GeneralPageObjects.processingUnit_Dropdown, "SenderAccountName", "SenderCompanyUnitName",
				"senderOrganizationReporter" };
		String[] actval = { CompanyUnit, ProcessingUnit, SenderAccountName, SenderCompanyUnitName,
				senderOrganizationReporter };
		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, actval);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform case Dates data
	 *             verification in FDE form
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void caseDates_Verification(String scenarioName) {
		agCheckPropertyValue("value",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_InitialReceivedDate")),
				FDE_GeneralPageObjects.setData_Datesfields(FDE_GeneralPageObjects.initialReceiveDateLabel));
		String InitialReceivedDate = Constants.actualVal;

		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_LatestReceivedDate")),
				FDE_GeneralPageObjects.setData_Datesfields(FDE_GeneralPageObjects.latestReceiveDatelabel));
		String LatestReceivedDate = Constants.actualVal;

		agCheckPropertyValue("value",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_CompanyReceivedDate")),
				FDE_GeneralPageObjects.setData_Datesfields(FDE_GeneralPageObjects.companyReceivedDatelabel));
		String CompanyReceivedDate = Constants.actualVal;

		agCheckPropertyValue("value",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_RegulatoryClockStartDate")),
				FDE_GeneralPageObjects.setData_Datesfields(FDE_GeneralPageObjects.regulatoryStartDatelabel));
		String RegulatoryClockStartDate = Constants.actualVal;

		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_CaseDueDate")),
				FDE_GeneralPageObjects.setData_Datesfields(FDE_GeneralPageObjects.caseDueDatelabel));
		String CaseDueDate = Constants.actualVal;

		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_SubmissionDueDate")),
				FDE_GeneralPageObjects.setData_Datesfields(FDE_GeneralPageObjects.submissionDueDatelabel));
		String SubmissionDueDate = Constants.actualVal;
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_AERCloseDate")),
				FDE_GeneralPageObjects.setData_Datesfields(FDE_GeneralPageObjects.aerCloseDatelabel));
		String AERCloseDate = Constants.actualVal;

		String[] ColumnName = { "Gen_CaseDates_InitialReceivedDate", "Gen_CaseDates_LatestReceivedDate",
				"Gen_CaseDates_CompanyReceivedDate", "Gen_CaseDates_RegulatoryClockStartDate",
				"Gen_CaseDates_CaseDueDate", "Gen_CaseDates_SubmissionDueDate", "Gen_CaseDates_AERCloseDate" };
		String[] ColumnTitles = { FDE_GeneralPageObjects.initialReceiveDateLabel,
				FDE_GeneralPageObjects.latestReceiveDatelabel, FDE_GeneralPageObjects.companyReceivedDatelabel,
				FDE_GeneralPageObjects.regulatoryStartDatelabel, FDE_GeneralPageObjects.caseDueDatelabel,
				FDE_GeneralPageObjects.submissionDueDatelabel, FDE_GeneralPageObjects.aerCloseDatelabel };
		String[] actval = { InitialReceivedDate, LatestReceivedDate, CompanyReceivedDate, RegulatoryClockStartDate,
				CaseDueDate, SubmissionDueDate, AERCloseDate };

		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, actval);
		Reports.ExtentReportLog("", Status.INFO,
				"Data verification in General tab Case Dates section: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Case Report data
	 *             verification in FDE form
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void caseReport_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(
				FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.reportType_Dropdown));

		agCheckPropertyText(getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportType"),
				FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.reportType_Dropdown));
		String ReportType = Constants.actualVal;

		agCheckPropertyText(getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportCategory"),
				FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.reportCategory_Dropdown));
		String ReportCategory = Constants.actualVal;
		;
		/*
		 * agCheckPropertyValue("title", getTestDataCellValue(scenarioName,
		 * "Gen_CaseReport_ReportClassification"),
		 * FDE_GeneralPageObjects.get_ReportClassification);
		 */
		String ReportClassification = Constants.actualVal;

		agCheckPropertyText(getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportPriority"),
				FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.reportPriority_Dropdown));
		String ReportPriority = Constants.actualVal;

		agCheckPropertyText(getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportReceivingMedium"),
				FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.reportReceivingMedium_Dropdown));
		String ReceivingMedium = Constants.actualVal;

		agCheckPropertyText(getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportReceivingFormat"),
				FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.reportReceivingFormat_Dropdown));
		String ReportReceivingFormat = Constants.actualVal;

		// agCheckPropertyValue("title", getTestDataCellValue(scenarioName,
		// "Gen_CaseReport_User"),FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.assignTo_Dropdown));
		String CaseReport_User = Constants.actualVal;

		if (getTestDataCellValue(scenarioName, "Gen_CaseReport_FollowUp").equalsIgnoreCase("Yes")) {
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Gen_CaseReport_FollowUpRefNo"),
					FDE_GeneralPageObjects.FollowUpRefNo);
		}
		String FollowUp = Constants.actualVal;

		String[] ColumnName = { "Gen_CaseReport_ReportType", "Gen_CaseReport_ReportCategory",
				"Gen_CaseReport_ReportClassification", "Gen_CaseReport_ReportPriority",
				"Gen_CaseReport_ReportReceivingMedium", "Gen_CaseReport_ReportReceivingFormat", "Gen_CaseReport_User",
				"Gen_CaseReport_FollowUpRefNo" };
		String[] ColumnTitles = { FDE_GeneralPageObjects.reportType_Dropdown,
				FDE_GeneralPageObjects.reportCategory_Dropdown, FDE_GeneralPageObjects.get_ReportClassification,
				FDE_GeneralPageObjects.reportPriority_Dropdown, FDE_GeneralPageObjects.reportReceivingMedium_Dropdown,
				FDE_GeneralPageObjects.reportReceivingFormat_Dropdown, FDE_GeneralPageObjects.assignTo_Dropdown,
				FDE_GeneralPageObjects.FollowUpRefNo };
		String[] actval = { ReportType, ReportCategory, ReportClassification, ReportPriority, ReceivingMedium,
				ReportReceivingFormat, CaseReport_User, FollowUp };

		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, actval);
		Reports.ExtentReportLog("", Status.INFO,
				"Data verification in General tab Case Report section: Scenario Name::" + scenarioName, true);

	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Write data into excel sheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, columnName, data);
		agSetStepExecutionDelay("20000");
	}

	/**********************************************************************************************************
	 * @Objective: Set case specific Information test data in general page of FDE
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 14-August-2019
	 * @UpdatedByAndWhen:Pooja S on 03-Apr-2020 Added Case Significance Manual
	 *                         Checkbox and select the value from DD
	 **********************************************************************************************************/
	public static void setCaseSpecificInfo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.caseSpecificationlabel);
		setDropDownValue(FDE_GeneralPageObjects.primarySourceCountry, scenarioName,
				"Gen_CaseSpecificInformation_PrimarySourceCountry");
		agSetStepExecutionDelay("4000");
		status = agIsVisible(FDE_GeneralPageObjects.primarySourceCountryValue);
		{
			CommonOperations.captureScreenShot(true);
		}

		setDropDownValue(FDE_GeneralPageObjects.countryOfDetection, scenarioName,
				"Gen_CaseSpecificInformation_CountryOfDetection");

		agSetStepExecutionDelay("4000");
		status = agIsVisible(FDE_GeneralPageObjects.countryOfDetectionValue);
		{
			CommonOperations.captureScreenShot(true);
		}
		// setDropDownValue(FDE_GeneralPageObjects.caseSignificance, scenarioName,
		// "Gen_CaseSpecificInformation_CaseSignificance");
		if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			agSetStepExecutionDelay("5000");
			CommonOperations.captureScreenShot(true);
		}
		setDropDownValue(FDE_GeneralPageObjects.overallTransmissionStatus, scenarioName,
				"Gen_CaseSpecificInformation_OverallTransmissionStatus");

		// CommonOperations.captureScreenShot(true);
		// if (getTestDataCellValue(scenarioName,
		// "Gen_CaseSpecificInformation_BoolLocallyExpedited").equalsIgnoreCase("True"))
		// {
		// agClick(FDE_GeneralPageObjects.locallyExpeditedNF);
		// }
		setDropDownValue(FDE_GeneralPageObjects.locallyExpedited, scenarioName,
				"Gen_CaseSpecificInformation_LocallyExpedited");

		if (getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_MedicallyConfirmed_Manual")
				.equalsIgnoreCase("Check")) {
			agClick(FDE_GeneralPageObjects.manualChkbox);
			agClick(FDE_GeneralPageObjects.medicallyConfirmedRadio(
					getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_MedicallyConfirmed")));
		}
		if (getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_Nullification").equalsIgnoreCase("True")) {
			agClick(FDE_GeneralPageObjects.nullificationAmendmentRadio(FDE_GeneralPageObjects.nullification));
			agSetStepExecutionDelay("4000");
			agSetValue(FDE_GeneralPageObjects.reasonForNullAmend,
					getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_ReasonForNullificationAmendment"));
			agSendKeyStroke(Keys.TAB);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		if (getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_Amendment").equalsIgnoreCase("True")) {
			agClick(FDE_GeneralPageObjects.nullificationAmendmentRadio(FDE_GeneralPageObjects.amendment));
			agSetValue(FDE_GeneralPageObjects.reasonForNullAmend,
					getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_ReasonForNullificationAmendment"));
		}

		// case significance manual checkbox and selecting the case significance drop
		// down
		if (getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_CaseSignificance_Manual")
				.equalsIgnoreCase("Check")) {
			agSetStepExecutionDelay("2000");
			agClick(CommonPageObjects.manualCheckBox(FDE_GeneralPageObjects.casesignifcancemanual));

			// Changed for validating the Case Significance Dropdown
			setDropDownValue(FDE_GeneralPageObjects.casesignificance, scenarioName,
					"Gen_CaseSpecificInformation_CaseSignificance");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		String[] ColumnTitles = { FDE_GeneralPageObjects.primarySourceCountry,
				FDE_GeneralPageObjects.countryOfDetection, FDE_GeneralPageObjects.overallTransmissionStatus,
				FDE_GeneralPageObjects.locallyExpedited, "MedicallyConfirmed_Manua",
				FDE_GeneralPageObjects.nullification, FDE_GeneralPageObjects.reasonForNullAmend,
				FDE_GeneralPageObjects.amendment, FDE_GeneralPageObjects.casesignifcancemanual,
				FDE_GeneralPageObjects.casesignificance };
		String[] ColumnName = { "Gen_CaseSpecificInformation_PrimarySourceCountry",
				"Gen_CaseSpecificInformation_CountryOfDetection",
				"Gen_CaseSpecificInformation_OverallTransmissionStatus", "Gen_CaseSpecificInformation_LocallyExpedited",
				"Gen_CaseSpecificInformation_MedicallyConfirmed", "Gen_CaseSpecificInformation_Nullification",
				"Gen_CaseSpecificInformation_ReasonForNullificationAmendment", "Gen_CaseSpecificInformation_Amendment",
				"Gen_CaseSpecificInformation_CaseSignificance_Manual", "Gen_CaseSpecificInformation_CaseSignificance" };
		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, skipData);
		Reports.ExtentReportLog("", Status.INFO,
				"Data enetered in General tab Case Specific Information section: Scenario Name::" + scenarioName,
				false);

	}

	/**********************************************************************************************************
	 * @Objective:Verification of case specific Information test data in general
	 *                         page of FDE
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 14-August-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void caseSpecificInformation_Verification(String scenarioName) {
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.reasonForNullAmend);

		agAssertContainsText(FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.primarySourceCountry),
				getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_PrimarySourceCountry"));
		String primarySourceCountry = Constants.actualVal;

		agAssertContainsText(FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.countryOfDetection),
				getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_CountryOfDetection"));
		String countryOfDetection = Constants.actualVal;

		/*
		 * agCheckPropertyText(getTestDataCellValue(scenarioName,
		 * "Gen_CaseSpecificInformation_PrimarySourceCountry"),
		 * FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.
		 * primarySourceCountry)); String primarySourceCountry = Constants.actualVal;
		 * 
		 * agCheckPropertyText(getTestDataCellValue(scenarioName,
		 * "Gen_CaseSpecificInformation_CountryOfDetection"),
		 * FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.
		 * countryOfDetection)); String countryOfDetection = Constants.actualVal;
		 */

		agCheckPropertyText(getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_CaseSignificance"),
				FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.caseSignificance));
		String caseSignificance = Constants.actualVal;

		String[] ColumnName = { "Gen_CaseSpecificInformation_PrimarySourceCountry",
				"Gen_CaseSpecificInformation_CountryOfDetection", "Gen_CaseSpecificInformation_CaseSignificance" };
		String[] ColumnTitles = { FDE_GeneralPageObjects.primarySourceCountry,
				FDE_GeneralPageObjects.countryOfDetection, FDE_GeneralPageObjects.caseSignificance };
		String[] actval = { primarySourceCountry, countryOfDetection, caseSignificance };

		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, actval);

		Reports.ExtentReportLog("", Status.INFO,
				"Data verification in General tab Case Specific Information section: Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to enter Additional documents Module
	 *             details in General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 04-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setAdditionalDocumentsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Gen_AdditionalDocumentsAvailable").equalsIgnoreCase("Yes")) {

			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.additionalDocumentsAvailableRadio(
					getTestDataCellValue(scenarioName, "Gen_AdditionalDocumentsAvailable")));
			agSetValue(FDE_GeneralPageObjects.listOfDocumentsHeldByTheSenderTextarea, getTestDataCellValue(scenarioName,
					"Gen_AdditionalDocumentsAvailable_ListOfDocumentsHeldByTheSender"));

			if (getTestDataCellValue(scenarioName, "Gen_AdditionalDocumentsAvailable_IsDocumentIncluded")
					.equalsIgnoreCase("Check")) {
				agSetStepExecutionDelay("6000");
				agJavaScriptExecuctorClick(FDE_GeneralPageObjects.isDocumentIncludedListCheckbox("0"));
				/*
				 * agSetValue(FDE_GeneralPageObjects.documentNameTextbox ,
				 * getTestDataCellValue(scenarioName,
				 * "Gen_AdditionalDocumentsAvailable_DocumentName"));
				 */
				if (getTestDataCellValue(scenarioName, "Gen_AdditionalDoc_BoolLookUP").equalsIgnoreCase("Yes")) {
					agClick(FDE_GeneralPageObjects.DocumentName_LookUP);
					agClick(FDE_GeneralPageObjects.DocumentName_Checkbx(
							getTestDataCellValue(scenarioName, "Gen_AdditionalDocumentsAvailable_DocumentName")));
					agClick(FDE_GeneralPageObjects.DocumentName_Okbtn);
					agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				}

			}

		} else {

			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.additionalDocumentsAvailableRadio(
					getTestDataCellValue(scenarioName, "Gen_AdditionalDocumentsAvailable")));

			agSetStepExecutionDelay("5000");
			if (agIsExists(FDE_GeneralPageObjects.ConfirmationYes_Btn)) {
				agClick(FDE_GeneralPageObjects.ConfirmationYes_Btn);
			}
			Reports.ExtentReportLog("", Status.INFO, "No Documents available::" + scenarioName, true);
		}
		Reports.ExtentReportLog("", Status.PASS, "", true);

		String[] ColumnTitles = { "AdditionalDocumentsAvailable", "listOfDocumentsHeldByTheSender",
				"IsDocumentIncluded", "AdditionalDocumentsAvailable" };
		String[] ColumnName = { "Gen_AdditionalDocumentsAvailable",
				"Gen_AdditionalDocumentsAvailable_ListOfDocumentsHeldByTheSender",
				"Gen_AdditionalDocumentsAvailable_IsDocumentIncluded",
				"Gen_AdditionalDocumentsAvailable_DocumentName" };
		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, skipData);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to enter Case References Module details in
	 *             General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 04-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCaseReferencesDetails(String scenarioName) {
		CommonOperations.setFDEDropDownValue(FDE_GeneralPageObjects.initialSenderDropdown,
				getTestDataCellValue(scenarioName, "Gen_CaseReferences_InitialSender"));
		agSetValue(FDE_GeneralPageObjects.safetyReportIDtextbox,
				getTestDataCellValue(scenarioName, "Gen_CaseReferences_SafetyReportID"));
		agSetValue(FDE_GeneralPageObjects.AuthorityNoCompNumbertextbox,
				getTestDataCellValue(scenarioName, "Gen_CaseReferences_AuthorityNoCompNumber"));
		// agSetValue(FDE_GeneralPageObjects.safetyReportIdAsExportedtextbox
		// ,getTestDataCellValue(scenarioName,
		// "Gen_CaseReferences_SafetyReportIdAsExported"));

		String[] ColumnTitles = { FDE_GeneralPageObjects.initialSenderDropdown, "safetyReportID",
				"AuthorityNoCompNumbertextbox", "ReportIdAsExported" };
		String[] ColumnName = { "Gen_CaseReferences_InitialSender", "Gen_CaseReferences_SafetyReportID",
				"Gen_CaseReferences_AuthorityNoCompNumber", "Gen_CaseReferences_SafetyReportIdAsExported" };
		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, skipData);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to enter E2B Case References in Previous
	 *             Transmissions Module details in General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 04-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setE2BCaseReferencesinPreviousTransmissionsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Gen_CaseReferences_E2BCaseRefInPreTransmissions")
				.equalsIgnoreCase("Check")) {
			// CommonOperations.clickCheckBoxRightOf(FDE_GeneralPageObjects.e2BCaseReferencesinPreviousTransmissionsLabel,
			// "true" );
			agClick(FDE_GeneralPageObjects.e2BprefCheckbox);
			agSetStepExecutionDelay("4000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agSetValue(FDE_GeneralPageObjects.duplicateSourcetextbox,
					getTestDataCellValue(scenarioName, "Gen_CaseReferences_DuplicateSource"));
			agSetValue(FDE_GeneralPageObjects.duplicateNumbertextbox,
					getTestDataCellValue(scenarioName, "Gen_CaseReferences_DuplicateNumber"));
		}

		String[] ColumnTitles = { "E2BCaseRefInPreTransmissions", "DuplicateSource", "DuplicateNumber" };
		String[] ColumnName = { "Gen_CaseReferences_E2BCaseRefInPreTransmissions", "Gen_CaseReferences_DuplicateSource",
				"Gen_CaseReferences_DuplicateNumber" };
		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, skipData);

	}

	/**********************************************************************************************************
	 * @Objective: This method is created to enter duplicate number in General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 02-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setDuplicateNumber(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FDE_GeneralPageObjects.duplicateNumbertextbox,
				getTestDataCellValue(scenarioName, "Gen_CaseReferences_DuplicateNumber"));
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to verify additional documents Module
	 *             details in General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 04-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AdditionalDocuments_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String AdditionalDocumentsAvailable = "", listOfDocumentsHeldByTheSender = "",
				AdditionalDocumentsAvailable_DocumentName = "";
		if (getTestDataCellValue(scenarioName, "Gen_AdditionalDocumentsAvailable").equalsIgnoreCase("Yes")) {
			CommonOperations.verifyRadioButton(FDE_GeneralPageObjects.additionalDocumentsAvailableLabel,
					getTestDataCellValue(scenarioName, "Gen_AdditionalDocumentsAvailable"));
			AdditionalDocumentsAvailable = Constants.actualVal;

			agCheckPropertyValue("value",
					getTestDataCellValue(scenarioName,
							"Gen_AdditionalDocumentsAvailable_ListOfDocumentsHeldByTheSender"),
					FDE_GeneralPageObjects.listOfDocumentsHeldByTheSenderTextarea);
			listOfDocumentsHeldByTheSender = Constants.actualVal;

			Reports.ExtentReportLog("", Status.PASS, "", true);
			if (getTestDataCellValue(scenarioName, "Gen_AdditionalDocumentsAvailable_IsDocumentIncluded")
					.equalsIgnoreCase("Check")) {
				// CommonOperations.verifyCheckBoxUnder(FDE_GeneralPageObjects.isDocumentIncludedLabel,
				// "true");
				agCheckPropertyValue("value",
						getTestDataCellValue(scenarioName, "Gen_AdditionalDocumentsAvailable_DocumentName"),
						FDE_GeneralPageObjects.documentNameTextbox);
				AdditionalDocumentsAvailable_DocumentName = Constants.actualVal;
			}

			CommonOperations.takeScreenShot();
		}
		String[] ColumnName = { "Gen_AdditionalDocumentsAvailable",
				"Gen_AdditionalDocumentsAvailable_ListOfDocumentsHeldByTheSender",
				"Gen_AdditionalDocumentsAvailable_DocumentName" };
		String[] ColumnTitles = { FDE_GeneralPageObjects.additionalDocumentsAvailableLabel,
				"listOfDocumentsHeldByTheSender", "AdditionalDocumentsAvailable_DocumentName" };
		String[] actval = { AdditionalDocumentsAvailable, listOfDocumentsHeldByTheSender,
				AdditionalDocumentsAvailable_DocumentName };

		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, actval);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to verify Case References Module details
	 *             in General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 04-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void CaseReferences_Verification(String scenarioName) {
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.safetyReportIDtextbox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Gen_CaseReferences_InitialSender"),
				FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.initialSender));
		String initialSender = Constants.actualVal;

		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Gen_CaseReferences_SafetyReportID"),
				FDE_GeneralPageObjects.safetyReportIDtextbox);
		String safetyReportID = Constants.actualVal;

		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Gen_CaseReferences_AuthorityNoCompNumber"),
				FDE_GeneralPageObjects.AuthorityNoCompNumbertextbox);

		String AuthorityNoCompNumber = Constants.actualVal;

		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Gen_CaseReferences_SafetyReportIdAsExported"),
				FDE_GeneralPageObjects.safetyReportIdAsExportedtextbox);
		String safetyReportIdAsExported = Constants.actualVal;

		String[] ColumnName = { "Gen_CaseReferences_InitialSender", "Gen_CaseReferences_SafetyReportID",
				"Gen_CaseReferences_AuthorityNoCompNumber", "Gen_CaseReferences_SafetyReportIdAsExported" };
		String[] ColumnTitles = { FDE_GeneralPageObjects.initialSender, "safetyReportID", "AuthorityNoCompNumber",
				safetyReportIdAsExported };
		String[] actval = { initialSender, safetyReportID, AuthorityNoCompNumber, safetyReportIdAsExported };

		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, actval);

		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to verify 'E2B Case References in Previous
	 *             Transmissions' Module details in General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 04-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void e2BCaseReferencesInPreviousTransmissions_Verification(String scenarioName) {

		String DuplicateSource = "", DuplicateNumber = "";
		if (getTestDataCellValue(scenarioName, "Gen_CaseReferences_E2BCaseRefInPreTransmissions")
				.equalsIgnoreCase("Check")) {
			agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.duplicateNumbertextbox);
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Gen_CaseReferences_DuplicateSource"),
					FDE_GeneralPageObjects.duplicateSourcetextbox);
			DuplicateSource = Constants.actualVal;

			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Gen_CaseReferences_DuplicateNumber"),
					FDE_GeneralPageObjects.duplicateNumbertextbox);
			DuplicateNumber = Constants.actualVal;

			CommonOperations.takeScreenShot();
		} else {
			boolean dupNo = agIsExists(FDE_GeneralPageObjects.duplicateNumberdisabled);
			boolean dupSrc = agIsExists(FDE_GeneralPageObjects.duplicateSourcedisabled);

			if (dupNo == true && dupSrc == true) {
				Reports.ExtentReportLog("Disabled", Status.PASS,
						"Both DuplicateSource and DuplicateNumber fields are disabled", true);
			}
		}

		String[] ColumnName = { "Gen_CaseReferences_DuplicateSource", "Gen_CaseReferences_DuplicateNumber" };
		String[] ColumnTitles = { "DuplicateSource", "DuplicateNumber" };
		String[] actval = { DuplicateSource, DuplicateNumber };

		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, actval);
	}

	/**********************************************************************************************************
	 * @Objective: To Verify SUSAR Checkbox
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 30-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifySUSARCheckGen(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.SUSAR_Label);
		agSetStepExecutionDelay("2000");
		CommonOperations.takeScreenShot();
		CommonOperations.verifyCheckBoxUnder(FDE_GeneralPageObjects.SUSAR_CheckBox,
				getTestDataCellValue(scenarioName, "Gen_CaseReport_SUSAR"));
		String SUSAR_CheckBox = Constants.actualVal;
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		String[] ColumnName = { "Gen_CaseReport_SUSAR" };
		String[] ColumnTitles = { FDE_GeneralPageObjects.SUSAR_CheckBox };
		String[] actval = { SUSAR_CheckBox };

		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, actval);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to verify Case Significance Value in
	 *             CaseSignificanceDropdown in General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmarS
	 * @Date : 11-Feb-2020
	 * @UpdatedByAndWhen:WajahatUmar S 01-Apr-2020
	 **********************************************************************************************************/

	public static void CaseSignificance_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.CaseSignificanceDropdown);

		agSetStepExecutionDelay("2000");
		CommonOperations.takeScreenShot();
		CommonOperations.verifyFDEDropDownValue(FDE_GeneralPageObjects.CaseSignificanceDropdown,
				getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_CaseSignificance"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO,
				"Case Significance Verification in General tab in Case Specific Information section: Scenario Name::"
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to verify Case Significance Value in
	 *             CaseSignificanceDropdown and to verify manual flag is unchecked
	 *             or not in General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 07-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyCaseSignificancedisbled(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.CaseSignificanceDropdown);
		agSetStepExecutionDelay("2000");
		String expMsg = "--Select--";
		String actMsg = agGetText(FDE_GeneralPageObjects.Casesignificancevalue);
		if (actMsg.equalsIgnoreCase(expMsg)) {
			Reports.ExtentReportLog("", Status.PASS, "Message::" + actMsg, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Message::" + actMsg, false);
		}
		CommonOperations.takeScreenShot();
		status = agIsVisible(CommonPageObjects.manualCheckBox(FDE_GeneralPageObjects.casesignifcancemanual));

		if (status) {
			Reports.ExtentReportLog("Manual check box checked", Status.FAIL, "", false);
		} else {
			Reports.ExtentReportLog("Manual check box  not checked", Status.PASS, "", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO,
				"Case Significance Manual flag Verification in General tab in Case Specific Information section: Scenario Name::"
						+ scenarioName,
				true);
	}

	public static void VerifyCaseSignificance(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.CaseSignificanceDropdown);
		agSetStepExecutionDelay("2000");
		String actMsg = agGetText(FDE_GeneralPageObjects.CaseSignificanceDropdown);
		String expMsg = getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_CaseSignificance");
		System.out.println("Actual significance value--" + actMsg);
		System.out.println("Expected significance value--" + expMsg);
		if (actMsg.equalsIgnoreCase(expMsg)) {
			Reports.ExtentReportLog("", Status.PASS,
					"Actual significance value::" + actMsg + "    Expected significance value:: " + expMsg, true);

		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Actual significance value::" + actMsg + "    Expected significance value:: " + expMsg + actMsg,
					false);
		}
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Verify Nullification Flag Enabled
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 08-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void NullificationFlagEnabled(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.Nullification_Label);
		agSetStepExecutionDelay("2000");
		CommonOperations.takeScreenShot();
		CommonOperations.verifyCheckBoxLeftOf(FDE_GeneralPageObjects.Nullification_Checkbox,
				getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_Nullification"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Case dates in FDE General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 25-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setlatestReceiveDate(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FDE_GeneralPageObjects.latestReceiveDate, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_LatestReceivedDate")));
		agSetValue(FDE_GeneralPageObjects.latestReceiveDate, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_LatestReceivedDate")));
		Reports.ExtentReportLog("", Status.INFO,
				"Data enetered in General tab Case dates section: Scenario Name::" + scenarioName, true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set latest received date in FDE
	 *             General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 02-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setlatestReceive(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FDE_GeneralPageObjects.latestReceiveDate,
				getTestDataCellValue(scenarioName, "Gen_CaseDates_LatestReceivedDate"));
		agSetValue(FDE_GeneralPageObjects.latestReceiveDate,
				getTestDataCellValue(scenarioName, "Gen_CaseDates_LatestReceivedDate"));
		agSendKeyStroke(Keys.TAB);
		Reports.ExtentReportLog("", Status.INFO,
				"Data enetered in General tab Case dates section: Scenario Name::" + scenarioName, true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is Automatic calculation of Regulatory
	 *             submission date and case due date
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @Date : 06-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AutocalculationofsubmissionDateandCaseDate(String scenarioName, String Case) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String ReportClassifaction = agGetText(FDE_GeneralPageObjects.ReportClassifiDropdown);
		switch (Case) {

		case "Serious cases":
			agCheckPropertyValue("value",
					CommonOperations
							.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_SubmissionDueDate")),
					FDE_GeneralPageObjects.setData_Datesfields(FDE_GeneralPageObjects.submissionDueDate));
			Reports.ExtentReportLog("", Status.INFO,
					"Auto Calculation of Regulatory submission date=LRD+15 days for Serious cases: Scenario Name::"
							+ scenarioName,
					true);
			agCheckPropertyValue("value",
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_CaseDueDate")),
					FDE_GeneralPageObjects.setData_Datesfields(FDE_GeneralPageObjects.caseDueDate));
			Reports.ExtentReportLog("", Status.INFO,
					"Automatic calculation of case due date=LRD+10 days for Serious cases: Scenario Name::"
							+ scenarioName,
					true);
			break;

		case "Non-Serious cases":
			agCheckPropertyValue("value",
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "submissionDueDate")),
					FDE_GeneralPageObjects.setData_Datesfields(FDE_GeneralPageObjects.submissionDueDate));
			Reports.ExtentReportLog("", Status.INFO,
					"Auto Calculation of Regulatory submission date=LRD+90 days for Serious cases: Scenario Name::"
							+ scenarioName,
					true);
			agCheckPropertyValue("value",
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_CaseDueDate")),
					FDE_GeneralPageObjects.setData_Datesfields(FDE_GeneralPageObjects.caseDueDate));
			Reports.ExtentReportLog("", Status.INFO,
					"Automatic calculation of case due date=LRD+80 days for Serious cases: Scenario Name::"
							+ scenarioName,
					true);
			break;

		}

	}

	/**********************************************************************************************************
	 * @Objective: Verify rollover from Initial/Follow-up and Follow-up number field
	 *             from data assessment to Initial/Follow-up and Follow-up number
	 *             field in General screen upon save, import and export of the case.
	 * 
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 18-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void followupInitialRadioBtnAutoRolloverVerification() {
		Reports.ExtentReportLog("", Status.INFO,
				" Auto Rollover verification of Initial/Followup Radio button in General Tab started", true);
		try {
			FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
			agSetStepExecutionDelay("3000");
			if (agIsVisible(FullDataEntryFormPageObjects
					.initial_Followup_RadioBtn(FullDataEntryFormPageObjects.initial)) == true) {
				Reports.ExtentReportLog("", Status.PASS, "Initial Radio button is Enabled in Data assessment Tab",
						true);
				verifyInitialRadioBtninGeneral_RollOver();
			} else if (agIsVisible(FullDataEntryFormPageObjects
					.initial_Followup_RadioBtn(FullDataEntryFormPageObjects.followup)) == true) {
				Reports.ExtentReportLog("", Status.PASS, "Followup Radio button is Enabled in Data assessment Tab",
						true);
				verifyFollowUpRadioBtninGeneral_RollOver();
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Followup or Initial Radio button is not Enabled in Data assessment Tab", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					" Auto Rollover verification of Initial/Followup Radio button in General Tab is not verified" + e,
					true);
		}
		Reports.ExtentReportLog("", Status.INFO,
				" Auto Rollover verification of Initial/Followup Radio button in General Tab ended", true);
	}

	/**********************************************************************************************************
	 * @Objective:Verify rollover from Initial/Follow-up and Follow-up number field
	 *                   from data assessment to Initial/Follow-up and Follow-up
	 *                   number field in General screen upon save, import and export
	 *                   of the case.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 18-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyInitialRadioBtninGeneral_RollOver() {
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.caseInformation_Link);
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorScrollToElement(FullDataEntryFormPageObjects.fuLabel);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		status = agIsVisible(FDE_GeneralPageObjects.initial_Followup_RadioBtn(FDE_GeneralPageObjects.initialRadiobtn));
		if (status) {
			Reports.ExtentReportLog("", Status.PASS,
					"Auto Rollover verification of initial radiobutton in general tab is selected", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Auto Rollover verification of initial radiobutton in general tab is not selected", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verify rollover from Initial/Follow-up and Follow-up number field
	 *             from data assessment to Initial/Follow-up and Follow-up number
	 *             field in General screen upon save, import and export of the case.
	 * 
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 18-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyFollowUpRadioBtninGeneral_RollOver() {
		String followupRef = agGetText(FullDataEntryFormPageObjects.followupRef);
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.caseInformation_Link);
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorScrollToElement(FullDataEntryFormPageObjects.fuLabel);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		String followupRefGen = agGetText(FDE_GeneralPageObjects.FollowUpRefNo);
		status = agIsVisible(FDE_GeneralPageObjects.initial_Followup_RadioBtn(FDE_GeneralPageObjects.followUpRadiobtn));
		if (status && followupRef.equalsIgnoreCase(followupRefGen)) {
			Reports.ExtentReportLog("", Status.PASS,
					"Auto Rollover verification of follow-up radiobutton and Followup Ref no. in general tab is verified",
					true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Auto Rollover verification of follow-up radiobutton and Followup Ref no. in general tab is not verified",
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verify Report Classification based on Reporter , patient and
	 *             Events
	 * 
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String reportClassification(String scenarioName) {
		String reportClassification = "";
		try {
			FDE_Operations.tabNavigation("General");
			reportClassification = agGetText(FDE_GeneralPageObjects.ReportClassifiDropdown);
			if (reportClassification.equalsIgnoreCase("Non-Case")) {
				agAssertContainsText(CaseListingPageObjects.caseActHeader, "Non Case");
				FDE_Operations.tabNavigation("Product(s)");
				String productNameAsReported = agGetAttribute("value",
						FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.prductNameAsReportedTxtbox));
				String productDescription = agGetAttribute("value", FDE_ProductsPageObjects.productDescriptionTextbox);
				Reports.ExtentReportLog("", Status.INFO, "Non Case Product Details", true);
				boolean productFactor = false;
				if ((productNameAsReported.equalsIgnoreCase("unknown") || productNameAsReported.isEmpty())
						&& (productDescription.isEmpty()))
					productFactor = true;
				else
					productFactor = false;
				FDE_Operations.tabNavigation("Event(s)");
				String eventName = agGetAttribute("value", FDE_EventsPageObjects.reportedTerm_Textfield);
				String eventCode = agGetAttribute("value", FDE_EventsPageObjects.eventMedDRALLTCode);
				Reports.ExtentReportLog("", Status.INFO, "Non Case Event Details", true);
				boolean eventFactor = false;
				if ((eventName.equalsIgnoreCase("unknown") || eventName.isEmpty()) && (eventCode.isEmpty()))
					eventFactor = true;
				else
					eventFactor = false;
				FDE_Operations.tabNavigation("General");
				if (productFactor || eventFactor) {
					String nonCaseReason = "Other  ";
					if (eventFactor)
						nonCaseReason = "No Adverse event reported";
					agClick(FDE_GeneralPageObjects.noncaseReasonDropdown);
					agClick(FDE_GeneralPageObjects.selectnoncasereasondropdownValue(nonCaseReason));
					Reports.ExtentReportLog("", Status.PASS,
							"Report is Calasiified as " + reportClassification + " Correctly", true);
				}

				else
					Reports.ExtentReportLog("", Status.FAIL,
							"Report is Calasiified as " + reportClassification + " Inocorrectly", true);

			} else if (reportClassification.equalsIgnoreCase("Invalid")) {
				FDE_Operations.tabNavigation("Reporter");
				String reporterFName = agGetAttribute("value",
						FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.firstName_Textbox));
				Reports.ExtentReportLog("", Status.INFO, "Invalid Case Reporter Details", true);
				boolean reporterFactor = false;
				if ((reporterFName.equalsIgnoreCase("unknown") || reporterFName.isEmpty()))
					reporterFactor = true;
				else
					reporterFactor = false;

				FDE_Operations.tabNavigation("Patient");
				String patientName = agGetAttribute("value",
						FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.patientID_Textbox));
				boolean patientFactor = false;
				Reports.ExtentReportLog("", Status.INFO, "Invalid Case Patient Details", true);
				if ((patientName.equalsIgnoreCase("unknown") || patientName.isEmpty()))
					patientFactor = true;
				else
					patientFactor = false;

				FDE_Operations.tabNavigation("General");
				if (patientFactor || reporterFactor)
					Reports.ExtentReportLog("", Status.PASS,
							"Report is Calasiified as " + reportClassification + " Correctly", true);
				else
					Reports.ExtentReportLog("", Status.FAIL,
							"Report is Calasiified as " + reportClassification + " Inocorrectly", true);

			} else
				Reports.ExtentReportLog("", Status.INFO, "Report Neithere Classiffied as Non - Case or Invalid", true);

		} catch (Exception ex) {
			reportClassification = "";
			Reports.ExtentReportLog("", Status.INFO, "Report Neithere Classiffied as Non - Case nor Invalid", true);
		}
		return reportClassification;
	}

	/**********************************************************************************************************
	 * @Objective: Verify R2 tags in general tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 12-NOv-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyGenaralR2Tags() {
		System.out.println("********General R2 tag verification Started*******");
		agAssertVisible(FDE_GeneralPageObjects.R2WWUID);
		agAssertVisible(FDE_GeneralPageObjects.R2initialReceivedDate);
		agAssertVisible(FDE_GeneralPageObjects.R2latestReceivedDate);
		agAssertVisible(FDE_GeneralPageObjects.R2combinationProdReport);
		agAssertVisible(FDE_GeneralPageObjects.R2reportType);
		// agAssertVisible(FDE_GeneralPageObjects.R2otherSafteyRef);
		agAssertVisible(FDE_GeneralPageObjects.R2primarySourceCountry);
		agAssertVisible(FDE_GeneralPageObjects.R2countryOfDetection);
		agAssertVisible(FDE_GeneralPageObjects.R2locallyExpedited);
		agAssertVisible(FDE_GeneralPageObjects.R2MedicallyConfirmed);
		agAssertVisible(FDE_GeneralPageObjects.R2Nullification);
		agAssertVisible(FDE_GeneralPageObjects.R2AmadmentReason);
		agAssertVisible(FDE_GeneralPageObjects.R2Seriousness);
		agAssertVisible(FDE_GeneralPageObjects.R2Death);
		agAssertVisible(FDE_GeneralPageObjects.R2LifeThreathening);
		agAssertVisible(FDE_GeneralPageObjects.R2Caused_ProlongedHospitalization);
		agAssertVisible(FDE_GeneralPageObjects.R2Disability_PermanentDamage);
		agAssertVisible(FDE_GeneralPageObjects.R2CongenitalAnomaly_BirthDefect);
		agAssertVisible(FDE_GeneralPageObjects.R2OtherMedicallyImportantCondition);
		agAssertVisible(FDE_GeneralPageObjects.R2AdditionalDocumentsAvailable);
		agAssertVisible(FDE_GeneralPageObjects.R2ListOfDocumentsHeldByTheSender);
		agAssertVisible(FDE_GeneralPageObjects.R2SafetyReportID);
		agAssertVisible(FDE_GeneralPageObjects.R2AuthorityNo_CompNumber);
		agAssertVisible(FDE_GeneralPageObjects.R2E2BCaseReferences);
		agAssertVisible(FDE_GeneralPageObjects.R2DuplicateSource);
		agAssertVisible(FDE_GeneralPageObjects.R2DuplicateNumber);
		System.out.println("********General R2 tag verification Completed*******");
	}

	/**********************************************************************************************************
	 * @Objective: Verify R3 tags in general tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 12-NOv-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyGenaralR3Tags() {
		System.out.println("********General R3 tag verification Started*******");
		agAssertVisible(FDE_GeneralPageObjects.R3LocalCriteriaReportType);
		agAssertVisible(FDE_GeneralPageObjects.R3WWUID);
		agAssertVisible(FDE_GeneralPageObjects.R3initialReceivedDate);
		agAssertVisible(FDE_GeneralPageObjects.R3latestReceivedDate);
		agAssertVisible(FDE_GeneralPageObjects.R3combinationProdReport);
		agAssertVisible(FDE_GeneralPageObjects.R3reportType);
		// agAssertVisible(FDE_GeneralPageObjects.R3otherSafteyRef);
		agAssertVisible(FDE_GeneralPageObjects.R3locallyExpedited);
		agAssertVisible(FDE_GeneralPageObjects.R3Nullification);
		agAssertVisible(FDE_GeneralPageObjects.R3AmadmentReason);
		agAssertVisible(FDE_GeneralPageObjects.R3AdditionalDocumentsAvailable);
		agAssertVisible(FDE_GeneralPageObjects.R3ListOfDocumentsHeldByTheSender);
		agAssertVisible(FDE_GeneralPageObjects.R3IsDocumentIncluded);
		agAssertVisible(FDE_GeneralPageObjects.R3InitialSender);
		agAssertVisible(FDE_GeneralPageObjects.R3SafetyReportID);
		agAssertVisible(FDE_GeneralPageObjects.R3AuthorityNo_CompNumber);
		agAssertVisible(FDE_GeneralPageObjects.R3E2BCaseReferencesInPreviousTransmissions);
		agAssertVisible(FDE_GeneralPageObjects.R3DuplicateSource);
		agAssertVisible(FDE_GeneralPageObjects.R3DuplicateNumber);
		System.out.println("********General R3 tag verification Completed*******");
	}

	/**********************************************************************************************************
	 * @Objective: Verify Codelist tags in general tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 12-NOv-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyGeneralCodeList() {
		System.out.println("********General Codelist verification Started*******");
		agAssertVisible(FDE_GeneralPageObjects.CLlocalCriteriaReportType);
		agAssertVisible(FDE_GeneralPageObjects.CLCombinationProductReport);
		agAssertVisible(FDE_GeneralPageObjects.CLReportType);
		agAssertVisible(FDE_GeneralPageObjects.CLReportCategory);
		agAssertVisible(FDE_GeneralPageObjects.CLReportClassification);
		agAssertVisible(FDE_GeneralPageObjects.CLReportPriority);
		agAssertVisible(FDE_GeneralPageObjects.CLReportReceivingMedium);
		agAssertVisible(FDE_GeneralPageObjects.CLReportReceivingFormat);
		agAssertVisible(FDE_GeneralPageObjects.CLInitial);
		agAssertVisible(FDE_GeneralPageObjects.CLOverallLatenessReason);
		agAssertVisible(FDE_GeneralPageObjects.CLNonCaseAssessmentReason);
		agAssertVisible(FDE_GeneralPageObjects.CLTurnOffTouchLess);
		agAssertVisible(FDE_GeneralPageObjects.CLPrimarySourceCountry);
		agAssertVisible(FDE_GeneralPageObjects.CLCountryOfDetection);
		agAssertVisible(FDE_GeneralPageObjects.CLCaseSignificance);
		agAssertVisible(FDE_GeneralPageObjects.CLLocallyExpedited);
		agAssertVisible(FDE_GeneralPageObjects.CLMedicallyConfirmed);
		agAssertVisible(FDE_GeneralPageObjects.CLNullification);
		agAssertVisible(FDE_GeneralPageObjects.CLOverallTransmissionStatus);
		agAssertVisible(FDE_GeneralPageObjects.CLSeriousness);
		agAssertVisible(FDE_GeneralPageObjects.CLDeath);
		agAssertVisible(FDE_GeneralPageObjects.CLLifeThreatening);
		agAssertVisible(FDE_GeneralPageObjects.CLCaused_ProlongedHospitalization);
		agAssertVisible(FDE_GeneralPageObjects.CLDisability_PermanentDamage);
		agAssertVisible(FDE_GeneralPageObjects.CLCongenitalAnomaly_BirthDefect);
		agAssertVisible(FDE_GeneralPageObjects.CLOtherMedicallyImportantCondition);
		agAssertVisible(FDE_GeneralPageObjects.CLRequiredIntervention);
		agAssertVisible(FDE_GeneralPageObjects.CLIsDocumentIncluded);
		agAssertVisible(FDE_GeneralPageObjects.CLInitialSender);
		System.out.println("********General R3 tag verification Completed*******");
	}

	/**********************************************************************************************************
	 * @Objective: Click on Additional Documents Add button
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 30-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickAddAdditionalDoc() {
		agWaitTillVisibilityOfElement(FDE_GeneralPageObjects.additionalDocumentsAdd_Btn);
		agClick(FDE_GeneralPageObjects.additionalDocumentsAdd_Btn);
	}

	/**********************************************************************************************************
	 * @Objective: Click on Additional Documents Add button
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 30-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addMultipleAdditionalDocRecords(String scenarioName, int recordNumber) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		recordNumber = recordNumber - 1;

		if (getTestDataCellValue(scenarioName, "Gen_AdditionalDocumentsAvailable").equalsIgnoreCase("Yes")) {

			if (recordNumber == 0) {
				agJavaScriptExecuctorClick(FDE_GeneralPageObjects.additionalDocumentsAvailableRadio(
						getTestDataCellValue(scenarioName, "Gen_AdditionalDocumentsAvailable")));
			}
			agSetValue(
					FDE_GeneralPageObjects.additionalDocLocatorBuilder(
							FDE_GeneralPageObjects.listOfDocumentsHeldByTheSender_Textarea, recordNumber),
					getTestDataCellValue(scenarioName,
							"Gen_AdditionalDocumentsAvailable_ListOfDocumentsHeldByTheSender"));

			if (getTestDataCellValue(scenarioName, "Gen_AdditionalDocumentsAvailable_IsDocumentIncluded")
					.equalsIgnoreCase("Check")) {
				agSetStepExecutionDelay("6000");
				agJavaScriptExecuctorClick(FDE_GeneralPageObjects.isDocumentIncludedListCheckbox("0"));
				/*
				 * agSetValue(FDE_GeneralPageObjects.documentNameTextbox ,
				 * getTestDataCellValue(scenarioName,
				 * "Gen_AdditionalDocumentsAvailable_DocumentName"));
				 */
				if (getTestDataCellValue(scenarioName, "Gen_AdditionalDoc_BoolLookUP").equalsIgnoreCase("Yes")) {
					agClick(FDE_GeneralPageObjects.DocumentName_LookUP);
					agClick(FDE_GeneralPageObjects.DocumentName_Checkbx(
							getTestDataCellValue(scenarioName, "Gen_AdditionalDocumentsAvailable_DocumentName")));
					agClick(FDE_GeneralPageObjects.DocumentName_Okbtn);
					agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				}

			}

		} else {
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.additionalDocumentsAvailableRadio(
					getTestDataCellValue(scenarioName, "Gen_AdditionalDocumentsAvailable")));
			Reports.ExtentReportLog("", Status.INFO, "No Documents available::" + scenarioName, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Case dates in FDE General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth
	 * @Date : 14-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCaseDatesAsText(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FDE_GeneralPageObjects.initialReceiveDate,
				getTestDataCellValue(scenarioName, "Gen_CaseDates_InitialReceivedDate"));
		agSetValue(FDE_GeneralPageObjects.latestReceiveDate,
				getTestDataCellValue(scenarioName, "Gen_CaseDates_LatestReceivedDate"));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Case dates in FDE General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth
	 * @Date : 14-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCaseOwner(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		FDE_Operations.tabNavigation("General");
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.caseReportlabel);
		setDropDownValue("Case Owner", scenarioName, "Gen_CaseReport_CaseOwner");
		/*
		 * agClick(FDE_GeneralPageObjects.selectGeneralDroprdown("Case Owner"));
		 * agSetStepExecutionDelay("2000");
		 * agClick(FDE_GeneralPageObjects.CaseOwnerSearchFiled);
		 * agSetStepExecutionDelay("2000");
		 * agSetValue(FDE_GeneralPageObjects.CaseOwnerSearchKeyFiled,
		 * getTestDataCellValue(scenarioName, "Gen_CaseReport_CaseOwner"));
		 * agSetStepExecutionDelay("2000");
		 * agJavaScriptExecuctorClick(FDE_GeneralPageObjects
		 * .clickDropDownValue(getTestDataCellValue(scenarioName,
		 * "Gen_CaseReport_CaseOwner")));
		 */
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Case dates in FDE General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth
	 * @Date : 14-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void completeMedicalReviewCheck() {
		agSetStepExecutionDelay("2000");
		if (agIsExists(FDE_GeneralPageObjects.allEvaluated_Checkbox)) {
			agClick(FDE_GeneralPageObjects.allEvaluated_Checkbox);
			agClick(FDE_GeneralPageObjects.actionToBeTaken_DropDown);
			agClick(FDE_GeneralPageObjects.dropDown_NoActionNeeded);
			agWaitTillVisibilityOfElement(FDE_GeneralPageObjects.Confirmation_Text);
			System.out.println("Confirmation Message: " + agGetText(FDE_GeneralPageObjects.Confirmation_Text));
			agClick(FDE_GeneralPageObjects.ConfirmationYes_Btn);
			agSetStepExecutionDelay("2000");
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set case owner in FDE General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 22-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCaseOwner(String scenarioName, String columnName, String label) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.selectGeneralDroprdown(label));
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.selectGeneralDroprdown(label));
			agJavaScriptExecuctorClick(
					FDE_GeneralPageObjects.clickDropDownValue(getTestDataCellValue(scenarioName, columnName)));

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set case owner in FDE General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 22-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setLatestReceivedDates(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClearText(FDE_GeneralPageObjects.latestReceiveDate);
		agSetValue(FDE_GeneralPageObjects.latestReceiveDate,
				(getTestDataCellValue(scenarioName, "Gen_CaseDates_LatestReceivedDate")));

		if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created Verify report priority field blank
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 22-Jan-2021
	 * @UpdatedByAndWhen: Updated by Praveen Patil 25-Jan-2021
	 **********************************************************************************************************/
	public static void VerifyReportPriorityBlank(Boolean screenShot) {
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.reportPriorityField);
		agIsVisible(FDE_GeneralPageObjects.reportPriorityNull);
		String selectedOption = agGetText(FDE_GeneralPageObjects.reportPriorityNull);
		String defaultReportPriority = "--Select--";
		if (selectedOption.equals(defaultReportPriority)) {
			Reports.ExtentReportLog("", Status.PASS, "As Expected " + "<br>" + "Report Priority is Blank ", screenShot);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Report Proprity field is not blank", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created Update report priority field
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 22-Jan-2021
	 * @UpdatedByAndWhen:Updated by Praveen Patil 25-Jan-2021
	 **********************************************************************************************************/
	public static void UpdatedReportPriorityValue(String scenarioName, Boolean screenShot) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.caseReportlabel);
		setDropDownValue(FDE_GeneralPageObjects.reportPriority_Dropdown, scenarioName, "Gen_CaseReport_ReportPriority");
		String selectedOption = agGetText(FDE_GeneralPageObjects.reportPriorityNull);
		String valueInExcel = getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportPriority");
		if (selectedOption.equals(valueInExcel)) {
			Reports.ExtentReportLog("", Status.PASS, "As Expected" + "<br>" + "Report Priority: " + selectedOption + "",
					screenShot);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Selected Report Priority value and Value passed from excel are different", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: To add multiple Doc details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 22-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addTwoDocDetails(String scenarioName1, String scenarioName2) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String scenarioName = scenarioName1;
		for (int i = 1; i < 3; i++) {
			if (i == 2) {
				scenarioName = scenarioName2;
			}
			String rowNo = String.valueOf(i - 1);
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.additionalDocumentsAvailableRadio(
					getTestDataCellValue(scenarioName, "Gen_AdditionalDocumentsAvailable")));
			agSetValue(FDE_GeneralPageObjects.listOfDocHeldByTheSenderTextarea(rowNo), getTestDataCellValue(
					scenarioName, "Gen_AdditionalDocumentsAvailable_ListOfDocumentsHeldByTheSender"));
			if (getTestDataCellValue(scenarioName, "Gen_AdditionalDocumentsAvailable_IsDocumentIncluded")
					.equalsIgnoreCase("Check")) {
				agSetStepExecutionDelay("6000");
				agJavaScriptExecuctorClick(FDE_GeneralPageObjects.isDocumentIncludedListCheckbox(rowNo));
			}
			if (i < 2) {
				clickAddAdditionalDoc();
			}
		}
		Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
	}

	/**********************************************************************************************************
	 * @Objective: To add multiple Doc details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 22-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setNullFactor_E2bTransmission() {
		agSetStepExecutionDelay("3000");
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.e2BTransmissionsNF);
		agClick(FDE_GeneralPageObjects.e2BTransmissionsNF);
		agJavaScriptExecuctorClick(FDE_GeneralPageObjects.e2BTransmissionsNF_Dropdown);
		agJavaScriptExecuctorClick(FDE_GeneralPageObjects.e2BTransmissionsNF_DropdownVal);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Latest Recieved dates in FDE
	 *             General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Abhisek Ghosh
	 * @Date : 10-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setLatestReceiveDate(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agSetValue(FDE_GeneralPageObjects.latestReceiveDate, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_LatestReceivedDate")));
		Reports.ExtentReportLog("", Status.INFO,
				"Data enetered in General tab Case dates section: Scenario Name::" + scenarioName, false);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify the Medically Confirmed
	 *             Radio Button is selected at case level.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :18-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verify_MedicallyConfirmedSelection() {

		String No = agGetAttribute("class", FDE_GeneralPageObjects.verifyMedicallyConfirmedRadioSelection("No"));
		String yes = agGetAttribute("class", FDE_GeneralPageObjects.verifyMedicallyConfirmedRadioSelection("Yes"));

		agJavaScriptExecuctorScrollToElement(
				FDE_GeneralPageObjects.labelField(FDE_GeneralPageObjects.medicallyConfirmedLabel));

		if (yes.contains("active")) {

			Reports.ExtentReportLog("Medically Confirmed - YES - radio button selected", Status.PASS,
					"Medically Confirmed -YES- radio is selected at case level", true);

		}

		else if (No.contains("active")) {

			Reports.ExtentReportLog("Medically Confirmed - NO - radio button selected ", Status.PASS,
					"Medically Confirmed -NO- radio is selected at case level", true);

		}

		else {

			Reports.ExtentReportLog("", Status.PASS,
					"Neither of the Medically Confirmed radio buttons are selected at case level", true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to verify whether any value is selected in
	 *             Case Significance Dropdown field in General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 18-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void caseSignificance_Verification() {

		Reports.ExtentReportLog("", Status.INFO, "verify Case Significance Dropdown Selection", true);
		agJavaScriptExecuctorScrollToElement(
				FDE_GeneralPageObjects.labelField(FDE_GeneralPageObjects.caseSignificanceLabel));
		// agSetStepExecutionDelay("3000");
		CommonOperations.takeScreenShot();
		if (agCheckPropertyText("--Select--", FDE_GeneralPageObjects.CaseSignificanceDropdown)) {
			Reports.ExtentReportLog("Case Significance Dropdown Verification", Status.PASS,
					"Case Significance Dropdown do not have auto-populated value", true);
		} else {
			Reports.ExtentReportLog("Case Significance Dropdown Verification", Status.PASS,
					"Case Significance Dropdown is having auto-populated value", true);
		}
		// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify the Medically Confirmed -
	 *             Application Parametre at case level.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :19-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void medicallyConfirmed_AppParameter_CaseLevel(String scenarioName) {
		// agSetStepExecutionDelay("5000");
		// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
		String boolMedicallyConfirmed = getTestDataCellValue(scenarioName, "AllowManualSelectionofMedicallyConfirmed");
		// System.out.println(boolMedicallyConfirmed);
		if (boolMedicallyConfirmed.equalsIgnoreCase("true")) {
			// agSetStepExecutionDelay("5000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
			// agSetStepExecutionDelay("10000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Operations.tabNavigation("General");

			agJavaScriptExecuctorScrollToElement(
					FDE_GeneralPageObjects.labelField(FDE_GeneralPageObjects.medicallyConfirmedLabel));

			Reports.ExtentReportLog("", Status.INFO,
					"verify Manual check box for Medically Confirmed at Case Level when flag is enabled at App Parametre level",
					true);

			if (agIsVisible(FDE_GeneralPageObjects
					.manualCheckBoxSelection_General(FDE_GeneralPageObjects.medicallyConfirmedLabel)) == true) {
				// if (agIsVisible(FDE_EventsPageObjects.medicallyConfirmed_Manual_checkbox) ==
				// true) {
				Reports.ExtentReportLog("Manual Flag for Medically Confirmed field", Status.PASS,
						"Manual Flag for Meically Confirmed field is displayed at case level", true);

				if ((agGetAttribute("class",
						FDE_GeneralPageObjects
								.manualCheckBoxSelection_General(FDE_GeneralPageObjects.medicallyConfirmedLabel)))
										.contains("active")) {
					MdicallyConfirmed_ManualFlagEnabled();

				} else {
					agClick(FDE_GeneralPageObjects
							.manualCheckBoxSelection_General(FDE_GeneralPageObjects.medicallyConfirmedLabel));
					MdicallyConfirmed_ManualFlagEnabled();
					agClick(FDE_GeneralPageObjects
							.manualCheckBoxSelection_General(FDE_GeneralPageObjects.medicallyConfirmedLabel));
					FDE_Operations.LSMVSaveTheCase();
				}
			} else {
				Reports.ExtentReportLog("Manual Flag for Medically Confirmed field", Status.FAIL,
						"Manual Flag for Meically Confirmed field is not displayed at case level", true);
			}

		}

		else {

			// agSetStepExecutionDelay("5000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
			// agSetStepExecutionDelay("10000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Operations.tabNavigation("General");

			agJavaScriptExecuctorScrollToElement(
					FDE_GeneralPageObjects.labelField(FDE_GeneralPageObjects.medicallyConfirmedLabel));

			Reports.ExtentReportLog("", Status.INFO,
					"verify Manual Flag for Medically Confirmed at Case Level when flag is disabled at Application Parametre Level",
					true);
			if (agIsVisible(FDE_GeneralPageObjects
					.manualCheckBoxSelection_General(FDE_GeneralPageObjects.medicallyConfirmedLabel)) == true) {
				{
					Reports.ExtentReportLog(
							"Manual Flag for Medically Confirmed field when flag is disabled at Application Parametre Level",
							Status.FAIL,
							"Manual Flag for Medically Confirmed field is displayed at case level when flag is disabled at Application Parametre Level",
							true);
				}
			} else {
				Reports.ExtentReportLog(
						"Manual Flag for Medically Confirmed field when flag is disabled at Application Parametre Level",
						Status.PASS,
						"Manual Flag for Medically Confirmed field is not displayed at case level when flag is disabled at Application Parametre Level",
						true);
			}
			SystemAdministrationOperations.systemAdministrationNavigations("applicationParameters");
			SystemAdministrationOperations.systemAdministrationNavigations("CaseManagement");

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);

			agClick(WorkFlowPageObjects.CheckedCheckBox2(
					AppParameters_CaseManagementPageObjects.allowManualSelectionofMedicallyConfirmed_CheckBox));
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.Save);
			agWaitTillVisibilityOfElement(AppParameters_CaseManagementPageObjects.SaveOkBtn);
			// agSetStepExecutionDelay("8000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("Medically Confirmed flag enabled at App Parametre level", Status.PASS,
					"Medically Flag enabled successfully at Application Parametre Level", true);
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.SaveOkBtn);

			AppParameters_CaseManagement
					.verifyAppParameters_MedicallyConfirmedSelection_CaseManagementTabDetails(scenarioName);

			// agSetStepExecutionDelay("5000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
			// agSetStepExecutionDelay("10000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Operations.tabNavigation("General");

			agJavaScriptExecuctorScrollToElement(
					FDE_GeneralPageObjects.labelField(FDE_GeneralPageObjects.medicallyConfirmedLabel));

			Reports.ExtentReportLog("", Status.INFO,
					"verify Manual check box for Medically Confirmed at Case Level when flag is enabled at App Parametre level",
					true);

			if (agIsVisible(FDE_GeneralPageObjects
					.manualCheckBoxSelection_General(FDE_GeneralPageObjects.medicallyConfirmedLabel)) == true) {
				// if (agIsVisible(FDE_EventsPageObjects.medicallyConfirmed_Manual_checkbox) ==
				// true) {
				Reports.ExtentReportLog("Manual Flag for Medically Confirmed field", Status.PASS,
						"Manual Flag for Meically Confirmed field is displayed at case level", true);

				if ((agGetAttribute("class",
						FDE_GeneralPageObjects
								.manualCheckBoxSelection_General(FDE_GeneralPageObjects.medicallyConfirmedLabel)))
										.contains("active")) {
					MdicallyConfirmed_ManualFlagEnabled();

				} else {
					agClick(FDE_GeneralPageObjects
							.manualCheckBoxSelection_General(FDE_GeneralPageObjects.medicallyConfirmedLabel));
					MdicallyConfirmed_ManualFlagEnabled();
					agClick(FDE_GeneralPageObjects
							.manualCheckBoxSelection_General(FDE_GeneralPageObjects.medicallyConfirmedLabel));
					FDE_Operations.LSMVSaveTheCase();
				}
			} else {
				Reports.ExtentReportLog("Manual Flag for Medically Confirmed field", Status.FAIL,
						"Manual check box for Meically Confirmed field is not displayed at case level though it is enabled at App Parametre level",
						true);
			}
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify the functionality of Manual
	 *             Checkbox for Medically Confirmed field which is enabled at
	 *             Application Parametre at case level.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :09-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void MdicallyConfirmed_ManualFlagEnabled() {

		String No = agGetAttribute("class", FDE_GeneralPageObjects.verifyMedicallyConfirmedRadioSelection("No"));
		String yes = agGetAttribute("class", FDE_GeneralPageObjects.verifyMedicallyConfirmedRadioSelection("Yes"));

		if (yes.contains("active")) {

			agClick(FDE_GeneralPageObjects.select_MedicallyConfirmedRadioSelection("No"));
			FDE_Operations.LSMVSaveTheCase();
			agJavaScriptExecuctorScrollToElement(
					FDE_GeneralPageObjects.labelField(FDE_GeneralPageObjects.medicallyConfirmedLabel));

			String NoBtn = agGetAttribute("class", FDE_GeneralPageObjects.verifyMedicallyConfirmedRadioSelection("No"));
			if (NoBtn.contains("active")) {
				Reports.ExtentReportLog("Medically Confirmed - No - radio button selected on save", Status.PASS,
						"Medically Confirmed -No- radio is selected", true);
			} else {
				Reports.ExtentReportLog("Medically Confirmed - No - radio button selected on save", Status.FAIL,
						"Medically Confirmed -No- radio is not selected", true);

			}

			agClick(FDE_GeneralPageObjects.select_MedicallyConfirmedRadioSelection("Yes"));
			FDE_Operations.LSMVSaveTheCase();
			agJavaScriptExecuctorScrollToElement(
					FDE_GeneralPageObjects.labelField(FDE_GeneralPageObjects.medicallyConfirmedLabel));

			String YesBtn = agGetAttribute("class",
					FDE_GeneralPageObjects.verifyMedicallyConfirmedRadioSelection("Yes"));
			if (YesBtn.contains("active")) {
				Reports.ExtentReportLog("Medically Confirmed - Yes - radio button selected on save", Status.PASS,
						"Medically Confirmed -Yes- radio is selected", true);
			} else {
				Reports.ExtentReportLog("Medically Confirmed - Yes - radio button selected on save", Status.FAIL,
						"Medically Confirmed -Yes- radio is not selected", true);

			}
			// agSetStepExecutionDelay("3000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			// FDE_Operations.LSMVSaveTheCase();

		}

		else if (No.contains("active")) {

			agClick(FDE_GeneralPageObjects.select_MedicallyConfirmedRadioSelection("Yes"));
			FDE_Operations.LSMVSaveTheCase();
			agJavaScriptExecuctorScrollToElement(
					FDE_GeneralPageObjects.labelField(FDE_GeneralPageObjects.medicallyConfirmedLabel));

			String YesBtn = agGetAttribute("class",
					FDE_GeneralPageObjects.verifyMedicallyConfirmedRadioSelection("Yes"));
			if (YesBtn.contains("active")) {
				Reports.ExtentReportLog("Medically Confirmed - Yes - radio button selected on save", Status.PASS,
						"Medically Confirmed -Yes- radio is selected", true);
			} else {
				Reports.ExtentReportLog("Medically Confirmed - Yes - radio button selected on save", Status.FAIL,
						"Medically Confirmed -Yes- radio is not selected", true);

			}

			agClick(FDE_GeneralPageObjects.select_MedicallyConfirmedRadioSelection("No"));
			FDE_Operations.LSMVSaveTheCase();
			agJavaScriptExecuctorScrollToElement(
					FDE_GeneralPageObjects.labelField(FDE_GeneralPageObjects.medicallyConfirmedLabel));

			String NoBtn = agGetAttribute("class", FDE_GeneralPageObjects.verifyMedicallyConfirmedRadioSelection("No"));
			if (NoBtn.contains("active")) {
				Reports.ExtentReportLog("Medically Confirmed - No - radio button selected on save", Status.PASS,
						"Medically Confirmed -No- radio is selected", true);
			} else {
				Reports.ExtentReportLog("Medically Confirmed - No - radio button selected on save", Status.FAIL,
						"Medically Confirmed -No- radio is not selected", true);

			}

			// agSetStepExecutionDelay("3000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			// FDE_Operations.LSMVSaveTheCase();

		}

		else {
			agClick(FDE_GeneralPageObjects.select_MedicallyConfirmedRadioSelection("No"));
			FDE_Operations.LSMVSaveTheCase();
			agJavaScriptExecuctorScrollToElement(
					FDE_GeneralPageObjects.labelField(FDE_GeneralPageObjects.medicallyConfirmedLabel));

			String NoBtn = agGetAttribute("class", FDE_GeneralPageObjects.verifyMedicallyConfirmedRadioSelection("No"));
			if (NoBtn.contains("active")) {
				Reports.ExtentReportLog("Medically Confirmed - No - radio button selected on save", Status.PASS,
						"Medically Confirmed -No- radio is selected", true);
			} else {
				Reports.ExtentReportLog("Medically Confirmed - No - radio button selected on save", Status.FAIL,
						"Medically Confirmed -No- radio is not selected", true);

			}

			agClick(FDE_GeneralPageObjects.select_MedicallyConfirmedRadioSelection("Yes"));
			FDE_Operations.LSMVSaveTheCase();
			agJavaScriptExecuctorScrollToElement(
					FDE_GeneralPageObjects.labelField(FDE_GeneralPageObjects.medicallyConfirmedLabel));

			String YesBtn = agGetAttribute("class",
					FDE_GeneralPageObjects.verifyMedicallyConfirmedRadioSelection("Yes"));
			if (YesBtn.contains("active")) {
				Reports.ExtentReportLog("Medically Confirmed - Yes - radio button selected on save", Status.PASS,
						"Medically Confirmed -Yes- radio is selected", true);
			} else {
				Reports.ExtentReportLog("Medically Confirmed - Yes - radio button selected on save", Status.FAIL,
						"Medically Confirmed -Yes- radio is not selected", true);

			}

			// agSetStepExecutionDelay("3000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			// FDE_Operations.LSMVSaveTheCase();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify the Case Significant -
	 *             Application Parametre at case level.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :19-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verify_CaseSignificant_AppParameters_CaseLevel(String scenarioName, String scenarioName1) {
		// agSetStepExecutionDelay("5000");
		// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
		String boolCaseSignificant = getTestDataCellValue(scenarioName, "AllowManualSelectionofCaseSignificance");

		if (boolCaseSignificant.equalsIgnoreCase("true")) {
			// agSetStepExecutionDelay("5000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
			// agSetStepExecutionDelay("10000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			FDE_Operations.tabNavigation("General");
			agJavaScriptExecuctorScrollToElement(
					FDE_GeneralPageObjects.labelField(FDE_GeneralPageObjects.caseSignificanceLabel));

			Reports.ExtentReportLog("", Status.INFO,
					"verify Manual Flag for Case Significance at Case Level when flag is enabled at App Parametre level",
					true);

			if (agIsVisible(FDE_GeneralPageObjects
					.manualCheckBoxSelection_General(FDE_GeneralPageObjects.caseSignificance)) == true) {
				Reports.ExtentReportLog("Manual Flag for Case Significance field ", Status.PASS,
						"Manual Flag for Case Significance field is displayed at case level when respective flag is enabled at Application Parametre level",
						true);

				if ((agGetAttribute("class",
						FDE_GeneralPageObjects
								.manualCheckBoxSelection_General(FDE_GeneralPageObjects.caseSignificance)))
										.contains("active")) {
					setData_CaseSignificance(scenarioName1);

				}

				else {
					agClick(FDE_GeneralPageObjects
							.manualCheckBoxSelection_General(FDE_GeneralPageObjects.caseSignificance));
					setData_CaseSignificance(scenarioName1);
					agClick(FDE_GeneralPageObjects
							.manualCheckBoxSelection_General(FDE_GeneralPageObjects.caseSignificance));
					FDE_Operations.LSMVSaveTheCase();
				}
			}

			else {
				Reports.ExtentReportLog("Manual Flag for Case Significance field ", Status.FAIL,
						"Manual Flag for Case Significance field is not displayed at case level though respective flag is enabled at Application Parametre level",
						true);
			}

		}

		else {
			// agSetStepExecutionDelay("5000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
			// agSetStepExecutionDelay("10000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Operations.tabNavigation("General");
			agJavaScriptExecuctorScrollToElement(
					FDE_GeneralPageObjects.labelField(FDE_GeneralPageObjects.caseSignificanceLabel));
			Reports.ExtentReportLog("", Status.INFO,
					"verify Manual Flag for Case Significance at Case Level when flag is disabled at App Parametre level",
					true);
			if (agIsVisible(FDE_GeneralPageObjects
					.manualCheckBoxSelection_General(FDE_GeneralPageObjects.caseSignificance)) == true) {
				{
					Reports.ExtentReportLog(
							"Manual Flag for Case Significance field when flag is disabled at Application Parametre Level",
							Status.FAIL,
							"Manual Flag for Case Significance field is displayed at case level though flag is disabled at Application Parametre Level",
							true);
				}
			}

			else {
				Reports.ExtentReportLog(
						"Manual Flag for Case Significance field when flag is disabled at Application Parametre Level",
						Status.PASS,
						"Manual Flag for Case Significance field is not displayed at case level when flag is disabled at Application Parametre Level",
						true);
			}
			SystemAdministrationOperations.systemAdministrationNavigations("applicationParameters");
			SystemAdministrationOperations.systemAdministrationNavigations("CaseManagement");
			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
			agClick(WorkFlowPageObjects.CheckedCheckBox2(
					AppParameters_CaseManagementPageObjects.allowManualSelectionofCaseSignificance_CheckBox));
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.Save);
			agWaitTillVisibilityOfElement(AppParameters_CaseManagementPageObjects.SaveOkBtn);
			// agSetStepExecutionDelay("8000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("Case Significance flag enabled at App Parametre level", Status.PASS,
					"Case Significance Flag enabled successfully at Application Parametre Level", true);
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.SaveOkBtn);

			AppParameters_CaseManagement.verifyAppParameters_caseSignificance_CaseManagementTabDetails(scenarioName);

			// agSetStepExecutionDelay("5000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
			// agSetStepExecutionDelay("10000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			FDE_Operations.tabNavigation("General");
			agJavaScriptExecuctorScrollToElement(
					FDE_GeneralPageObjects.labelField(FDE_GeneralPageObjects.caseSignificanceLabel));

			Reports.ExtentReportLog("", Status.INFO,
					"verify Manual Flag for Case Significance at Case Level when flag is enabled at App Parametre level",
					true);

			if (agIsVisible(FDE_GeneralPageObjects
					.manualCheckBoxSelection_General(FDE_GeneralPageObjects.caseSignificance)) == true) {
				Reports.ExtentReportLog("Manual Flag for Case Significance field ", Status.PASS,
						"Manual Flag for Case Significance field is displayed at case level when respective flag is enabled at Application Parametre level",
						true);

				if ((agGetAttribute("class",
						CommonPageObjects.manualCheckBoxSelection(FDE_GeneralPageObjects.caseSignificance)))
								.contains("active")) {
					setData_CaseSignificance(scenarioName1);

				}

				else {
					agClick(FDE_GeneralPageObjects
							.manualCheckBoxSelection_General(FDE_GeneralPageObjects.caseSignificance));
					setData_CaseSignificance(scenarioName1);
					agClick(FDE_GeneralPageObjects
							.manualCheckBoxSelection_General(FDE_GeneralPageObjects.caseSignificance));
					FDE_Operations.LSMVSaveTheCase();
				}
			}

			else {
				Reports.ExtentReportLog("Manual Flag for Case Significance field ", Status.FAIL,
						"Manual Flag for Case Significance field is not displayed at case level though respective flag is enabled at Application Parametre level",
						true);
			}

		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is to set value at "Case Significance" Dropdown
	 * 
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :19-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setData_CaseSignificance(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		// agSetStepExecutionDelay("3000");

		// agClick(CommonPageObjects.manualCheckBox(FDE_PatientPageObjects.ageGroup_DropDown));
		String preValue = agGetText(FDE_GeneralPageObjects.CaseSignificanceDropdown);

		agJavaScriptExecuctorClick(FDE_GeneralPageObjects.CaseSignificanceDropdown);

		agJavaScriptExecuctorClick(FDE_GeneralPageObjects.clickDropDownValue(
				getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_CaseSignificance")));

		/*
		 * agJavaScriptExecuctorClick(setDropDownValue(FDE_GeneralPageObjects.
		 * CaseSignificanceDropdown, scenarioName,
		 * "Gen_CaseSpecificInformation_CaseSignificance"));
		 * 
		 * setDropDownValue(FDE_GeneralPageObjects.casesignificance, scenarioName,
		 * "Gen_CaseSpecificInformation_CaseSignificance");
		 */

		FDE_Operations.LSMVSaveTheCase();
		agSetStepExecutionDelay("5000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agJavaScriptExecuctorScrollToElement(
				FDE_GeneralPageObjects.labelField(FDE_GeneralPageObjects.caseSignificanceLabel));

		String newValue = agGetText(FDE_GeneralPageObjects.CaseSignificanceDropdown);

		CommonOperations.takeScreenShot();
		if (preValue.equalsIgnoreCase(newValue)) {
			Reports.ExtentReportLog("Verification of Case Significance value update", Status.FAIL,
					"Case Significance value not updated", true);
		} else {
			Reports.ExtentReportLog("Verification of Case Significance value update", Status.PASS,
					"Case Significance value updated", true);
		}

	}

	/***********************************************************************************************************************
	 * @Objective: The below method is to get the value from "Case Significance"
	 *             drop down
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth
	 * @Date : 02-Mar-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/

	public static String getCaseSignificanceValue() {
		FDE_Operations.tabNavigation("General");
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.caseSpecificationlabel);
		agMouseHover(FDE_GeneralPageObjects.caseSpecificationlabel);
		caseSignificanceVal = agGetText(FDE_GeneralPageObjects.CaseSignificanceDropdown);
		return caseSignificanceVal;
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is to get the value from "Case Significance"
	 *             drop down
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth
	 * @Date : 02-Mar-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static boolean verifyCaseSignificanceValue(String expectedVal) {
		Boolean result = false;

		caseSignificanceVal = getCaseSignificanceValue();
		String actualVal = caseSignificanceVal.trim().toLowerCase();
		expectedVal = expectedVal.trim().toLowerCase();
		Reports.ExtentReportLog("", Status.INFO, "Expected Case Significance value: " + expectedVal, false);
		Reports.ExtentReportLog("", Status.INFO, "Actual Case Significance value: " + caseSignificanceVal, false);

		if (expectedVal.equals(actualVal)) {
			Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
			result = true;
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Not as Expected", true);
		}

		return result;
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to clear AuthorityNo
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 18-Mar-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void clearAuthorityNo() {
		agClick(FDE_GeneralPageObjects.caseReference);
		agSetStepExecutionDelay("3000");
		agClearText(FDE_GeneralPageObjects.AuthorityNoCompNumbertextbox);
		agSendKeyStroke(Keys.TAB);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Verify_ReportTypeandPatientAge in
	 *             General and Patient TAB.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Wajahat Umar S
	 * @Date : 17-March-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void Verify_ReportType(String scenarioName, String ReportType) {

		// if(agIsVisible(FDE_GeneralPageObjects.ReporterClassification)==true) {
		//
		// Reports.ExtentReportLog("", Status.INFO, "report classification is blank",
		// true);
		//
		// }else {
		// agJavaScriptExecuctorClick(FDE_GeneralPageObjects.ReporterClassification);
		// agSetStepExecutionDelay("4000");
		// agJavaScriptExecuctorClick(FDE_GeneralPageObjects.SelectAllCheckbxReporterClassification);
		// agSetStepExecutionDelay("3000");
		// agJavaScriptExecuctorClick(FDE_GeneralPageObjects.UnSelectAllCheckbxReporterClassification);
		//
		// Reports.ExtentReportLog("", Status.INFO, "report classification is Updated to
		// blank", true);
		// }

		if (ReportType.equalsIgnoreCase("Spontenous")) {

			if (agGetText(FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.reportType_Dropdown))
					.equalsIgnoreCase("")) {
				Reports.ExtentReportLog("", Status.INFO, "Reporter Type is Already Updated as Spontenous", true);
			} else {
				setDropDownValue(FDE_GeneralPageObjects.reportType_Dropdown, scenarioName, "Gen_CaseReport_ReportType");
				Reports.ExtentReportLog("", Status.INFO, "Reporter Type is Updated as Spontenous", true);
			}
		} else if (ReportType.equalsIgnoreCase("Report from Study")) {
			setDropDownValue(FDE_GeneralPageObjects.reportType_Dropdown, scenarioName, "Gen_CaseReport_ReportType");
			Reports.ExtentReportLog("", Status.INFO, "Reporter Type is Updated as Report From Study", true);
		}

		FDE_Operations.LSMVSaveReconsile();
		// FDE_Operations.tabNavigation("Patient");
		//
		// String AgeatEventDropdown =
		// agGetText(FDE_PatientPageObjects.AgeAtTimeofEVentDropDownValue);
		// agClick(FDE_PatientPageObjects.AgeAtTimeofEventTextBoxValue);
		// String AgeAtEventTextBox = agGetAttribute("title",
		// FDE_PatientPageObjects.AgeAtTimeofEventTextBoxValue);
		//
		// if(AgeatEventDropdown.contains("--Select--") &&
		// !AgeAtEventTextBox.equalsIgnoreCase("40")) {
		// FDE_Operations.tabNavigation("Patient");
		// FDE_Patient.set_Patient(scenarioName);
		// FDE_Operations.tabNavigation("Event(s)");
		// FDE_Events.set_Events(scenarioName);
		// FDE_Operations.LSMVSave(scenarioName, "FDE_General");
		// }
		// FDE_Operations.tabNavigation("Patient");
		//
		//
		// AgeatEventDropdown =
		// agGetText(FDE_PatientPageObjects.AgeAtTimeofEVentDropDownValue);
		// agClick(FDE_PatientPageObjects.AgeAtTimeofEventTextBoxValue);
		// AgeAtEventTextBox = agGetAttribute("title",
		// FDE_PatientPageObjects.AgeAtTimeofEventTextBoxValue);
		//
		// if (AgeatEventDropdown.equalsIgnoreCase("Year(s) ( Y )") &&
		// AgeAtEventTextBox.equalsIgnoreCase("40") ) {
		// Reports.ExtentReportLog("", Status.INFO, "Patient age is updated as 40
		// years", true);
		//
		// }else {
		// Reports.ExtentReportLog("", Status.FAIL, "Patient age is updated as 40
		// years", true);
		// }
		//
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Set report Classidication Value.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Wajahat Umar S
	 * @Date : 17-March-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void ReportClassification(String CaseType) {

		if (CaseType.equalsIgnoreCase("Blank")) {
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.ReporterClassification);
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.SelectAllCheckbxReporterClassification);
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.UnSelectAllCheckbxReporterClassification);

			Reports.ExtentReportLog("", Status.INFO, "report classification is Updated as blank", true);
			FDE_Operations.LSMVSaveReconsile();

		} else if (CaseType.equalsIgnoreCase("Non-AE")) {
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.ReporterClassification);
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.SelectAllCheckbxReporterClassification);
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.UnSelectAllCheckbxReporterClassification);
			agSetStepExecutionDelay("3000");

			agJavaScriptExecuctorClick(
					FDE_GeneralPageObjects.ReporterClassificationValue(FDE_GeneralPageObjects.NonAE));
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorClick(
					FDE_GeneralPageObjects.ReporterClassificationValue(FDE_GeneralPageObjects.NONAECase));
			Reports.ExtentReportLog("", Status.INFO, "report classification is Updated as Non-AE case, Non-case", true);
			FDE_Operations.LSMVSaveReconsile();

		} else if (CaseType.equalsIgnoreCase("Invalid")) {

			if (agIsVisible(FDE_GeneralPageObjects.ReporterClassification) == true) {

				Reports.ExtentReportLog("", Status.INFO, "report classification is blank", true);
			} else {
				agJavaScriptExecuctorClick(FDE_GeneralPageObjects.ReporterClassification);
				agSetStepExecutionDelay("3000");
				agJavaScriptExecuctorClick(
						FDE_GeneralPageObjects.ReporterClassificationValue(FDE_GeneralPageObjects.Invalid));
				Reports.ExtentReportLog("", Status.INFO, "report classification is Updated as In-valid", true);

				FDE_Operations.LSMVSaveReconsile();
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Set report Classidication Value.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 07-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setReportClassification(String CaseType) {
		if (CaseType.equalsIgnoreCase("Blank")) {
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.ReportClassification);
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.SelectAllCheckbxReporterClassification);
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.UnSelectAllCheckbxReporterClassification);
			Reports.ExtentReportLog("", Status.INFO, "report classification is Updated as blank", true);
			FDE_Operations.LSMVSaveReconsile();
		}
	}

}
