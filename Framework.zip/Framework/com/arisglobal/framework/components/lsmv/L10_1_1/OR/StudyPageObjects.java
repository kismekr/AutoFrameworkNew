package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class StudyPageObjects {
	
	////////////////////////////////////// Study Listing ///////////////////////////////////////////////////////////////////
	
	public static String searchListing_TextBox = "xpath#//input[@id='studyFormListing:keyword']";
	public static String search_Icon = "xpath#//img[contains(@id, 'studyFormListing:') and contains(@src, 'search_icon.png')]";
	public static String paginator = "xpath#//div[@id='studyFormListing:studyTablenew_paginator_top']/span[@class='ui-paginator-current']";
	public static String edit_Icon = "xpath#//img[@id='studyFormListing:studyTablenew:0:editImgId']";
	public static String newButton = "xpath#//a[@id='studyFormListing:newId']";
	public static String deleteButton = "xpath#//a[@id='studyFormListing:deleteStudyBtn']";
	public static String saveButton = "xpath#//button[@id='studyForm:visibleSave']";
	public static String cancelButton = "xpath#//button[@id='studyForm:cancelId']";
	
	
	////////////////////////////// Common Object for Study  Screen  //////////////////////////////////////////////////////////////////////////////////

	public static String divAdd_Button = "xpath#//label[text()='%divName%']/ancestor::span[@class='ui-panel-title']/*/a[text()='Add']";

	
	////////////////////////////////////// Libraries >> Study >> General >> Study  /////////////////////////////////////////////////////////////////// 

	public static String projectNo_TextBox = "xpath#//input[@id='studyForm:prjctId']";
	public static String studyNo_TextBox = "xpath#//input[@id='studyForm:studydetId']";
	public static String studyDescription_TextArea = "xpath#//textarea[@id='studyForm:studydescriptId']";
	public static String studyTitle_TextArea = "xpath#//textarea[@id='studyForm:studytittId']";
	public static String studyDesign_DropDown = "xpath#//label[@id='studyForm:S-132_label']";
	public static String studyPhase_DropDown = "xpath#//label[@id='studyForm:S-133_label']";
	public static String blindedStudy_DropDown = "xpath#//label[@id='studyForm:S-4_label']";
	public static String eudraCTNumber_TextBox = "xpath#//input[@id='studyForm:eudId']";
	public static String codeBroken_DropDown = "xpath#//label[@id='studyForm:ST-54_label']";
	public static String primaryTestCompound_TextBox = "xpath#//input[@id='studyForm:primaryTestCompound']";
	public static String codeBrokenOn_TextBox = "xpath#//input[@id='studyForm:codeBrokenId_input']";
	public static String clinicalTrialsGovID_TextBox = "xpath#//input[@id='studyForm:eutrialdId']";
	public static String studyDesignDescription_TextArea = "xpath#//textarea[@id='studyForm:studydesigndescriptId']";
	public static String primaryIND_TextBox = "xpath#//input[@id='studyForm:primaryInd']";
	public static String studyType_DropDown = "xpath#//label[@id='studyForm:S-122_label']";
	public static String active_RadioBtn = "Active";
	public static String queryContact_DropDown = "xpath#//label[@id='studyForm:S-9874_label']";
	public static String queryContact_TextBox = "xpath#//textarea[@id='studyForm:studyQueryContact']";
	public static String protocolDetails_TextArea = "xpath#//textarea[@id='studyForm:studyProtocolDetails']";
	public static String studyAcronym_TextBox = "xpath#//input[@id='studyForm:studyAcronym']";
	public static String iis_CheckBox = "IIS";
	public static String euCTRegulation_CheckBox = "EU CT Regulation 2019";
	public static String addToCase_CheckBox = "Add To Case";
	
	public static String study_Div = "xpath#//label[contains(@id, 'studyForm:') and text()= 'Study']";
	
	////////////////////////////////////// Libraries >> Study >> General >> Product  //////////////////////////////////////////////////////////////////////
	
	public static String product_Label = "Product";
	public static String product_Div = "xpath#//label[contains(@id, 'studyForm:') and text()= 'Product']";
	public static String studyProductType_DropDown = "xpath#//label[@id='studyForm:productDataTable:%rowNo%:S-8008_label']";
	public static String productName_Label = "xpath#//label[contains(@id, 'studyForm:productDataTable:') and text()= '%prodName%']";
	
	
	//////////////////////////////////////Libraries >> Study >> General >> Exempted Events  ///////////////////////////////////////////////////////////////////
	
	public static String exemptedEvents_Label = "Exempted Events";
	public static String exemptedEvents_Div = "xpath#//label[contains(@id, 'studyForm:') and text()= 'Exempted Events']";
	public static String exemptedEventslltTerm_LookUp = "xpath#//a[@id = 'studyForm:eventtermsDataTable:%rownNo%:reactionMeddraLookup']/img[contains(@src, 'icon-lookup.gif')]";
	public static String exemptedEventslltTerm_TextBox = "xpath#//input[@id='studyForm:eventtermsDataTable:%rownNo%:meddraLltDecode']";


	//////////////////////////////////////Libraries >> Study >> General >> Anticipated Events  ///////////////////////////////////////////////////////////////////
	
	public static String anticipatedEvents_Label = "Anticipated Events";
	public static String anticipatedEvents_Div = "xpath#//label[contains(@id, 'studyForm:') and text()= 'Anticipated Events']";
	public static String anticipatedEvents_LookUp = "xpath#//a[@id = 'studyForm:expEventtermsDataTable:%rownNo%:reactionMeddraLookup']/img[contains(@src, 'icon-lookup.gif')]";
	public static String anticipatedEvents_TextBox = "xpath#//input[@id='studyForm:expEventtermsDataTable:%rownNo%:meddraLltDecode']";


	////////////////////////////////////// Libraries >> Study >> General >> Indications  ///////////////////////////////////////////////////////////////////
	
	public static String indications_Label = "Indications";
	public static String indications_Div = "xpath#//label[contains(@id, 'studyForm:') and text()= 'Indications']";
	public static String indicationslltTerm_LookUp = "xpath#//a[@id = 'studyForm:indicationTermsDatatable:%rownNo%:reactionMeddraLookup']/img[contains(@src, 'icon-lookup.gif')]";
	public static String indicationslltTerm_TextBox = "xpath#//input[@id='studyForm:indicationTermsDatatable:%rownNo%:meddraLltDecode']";
	
	////////////////////////////////////// Libraries >> Study >> General >> Study Registration Information   //////////////////////////////////////
	
	public static String studyRegistrationInformation_Label = "Study Registration Information ";
	public static String studyRegistrationInformation_Div = "xpath#//label[contains(@id, 'studyForm:') and text()= 'Study Registration Information ']";
	public static String registrationNumber_Label = "xpath#//label[contains(@id, ':studyRegNo') and text() = '%regnNo%']";
	public static String authority_Label = "xpath#//label[contains(@id, ':studyAuth') and text() = '%auth%']";
	public static String country_Label= "xpath#//label[contains(@id, ':studyRegCountry') and text() = '%country%']";
	
	//Registration Number Window
	public static String registrationNumber_TextBox = "xpath#//input[@id='studyRegistrationDetailsForm:registrationNo']";
	public static String authority_DropDown = "xpath#//label[@id='studyRegistrationDetailsForm:A1-42_label']";
	public static String statusOfTheTrail_DropDown = "xpath#//label[@id='studyRegistrationDetailsForm:A1-5509_label']";
	public static String responsibleOPU_LookUpIcon = "xpath#//a[@id='studyRegistrationDetailsForm:addAssigntcu:companyUnitLookup']/img[contains(@src, 'Lookup_Selection.svg')]";
	public static String country_DropDown = "xpath#//label[@id='studyRegistrationDetailsForm:A1-1015_label']";
	public static String localApprovalNumber_TextBox = "xpath#//input[@id='studyRegistrationDetailsForm:approvalNo']";
	public static String ecReportingFlag_DropDown = "xpath#//label[@id='studyRegistrationDetailsForm:A1-9850_label']";
	public static String addRegistrationNumber_Button = "xpath#//button[@id='studyRegistrationDetailsForm:saveLink']";
	public static String cancelRegistrationNumber_Button = "xpath#//button[@id='studyRegistrationDetailsForm:backLink']";
	
	
	////////////////////////////////////// Libraries >> Study >> General >> Cross Referenced INDs /////////////////////////////////////////////////
	
	public static String crossReferencedINDs_Label = "Cross Referenced INDs";
	public static String crossReferencedINDs_Div = "xpath#//label[contains(@id, 'studyForm:') and text()= 'Cross Referenced INDs']";
	public static String crossReferencedIND_TextBox = "xpath#//input[@id='studyForm:crossRefINDstermsDataTable:%rownNo%:crossRefINDsLabel']";
	public static String studyTypeCrossReferencedIND_DropDown = "xpath#//label[@id='studyForm:crossRefINDstermsDataTable:%rownNo%:studyType-122_label']";
	
	
	/////////////////////////////////// Libraries >> Study >> Sites ////////////////////////////////////////////////////////////////////////////////
	
	public static String sites_Link = "xpath#//a[@id='studyForm:sitestabTabId']";
	public static String sites_Label = "Sites";
	
	
	/////////////////////////////////// Libraries >> Study >> Processing Unit //////////////////////////////////////////////////////////////////////
	
	public static String processingUnit_Link = "xpath#//a[@id='studyForm:companyUnittabTabId']";
	public static String processingUnit_Label = "Processing unit";
	public static String allCompanyUnits_CheckBox = "All Company Units";
	
	
	/////////////////////////////////// Libraries >> Study >> Documents ///////////////////////////////////////////////////////////////////////////
	
	public static String studyDocument_Link = "xpath#//a[@id='studyForm:studyDocTabId']";
	public static String studyDocument_Add = "xpath#//a[@id='studyForm:studyDocAdd']";
	public static String upload_Link = "xpath#//input[contains(@id, '%rownNo%:sourceUpload_input')]";
	public static String description_TextArea = "xpath#//textarea[contains(@id, ':0:description')]";
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to click on Add Button for specified Section in Study Tab
	 * @InputParameters: Div Label
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String clickAddBtton(String label) {
		String value = divAdd_Button.replace("%divName%", label);
		return value;
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to pass Product Name for verification
	 * @InputParameters: Product Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String prodNameStudy(String prodName) {
		String value = productName_Label.replace("%prodName%", prodName);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to pass Registration Number for verification in Study Registration Information Section.
	 * @InputParameters: Registration Number
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String registrationNumberStudy(String regNo) {
		String value = registrationNumber_Label.replace("%regnNo%", regNo);
		return value;
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to pass Authority for verification in Study Registration Information Section.
	 * @InputParameters: Authority
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String authorityStudy(String authority) {
		String value = authority_Label.replace("%auth%", authority);
		return value;
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to pass Country for verification in Study Registration Information Section.
	 * @InputParameters: Country
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String countryStudy(String country) {
		String value = country_Label.replace("%country%", country);
		return value;
	}
}
