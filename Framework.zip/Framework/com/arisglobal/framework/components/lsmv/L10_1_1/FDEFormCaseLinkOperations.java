package com.arisglobal.framework.components.lsmv.L10_1_1;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDEFormLinkCasesWindowPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDEMoreOptionsPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDEFormCaseLinkOperations extends ToolManager{
	static boolean status;
	static String className = FDEFormCaseLinkOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to navigated to link case window  in FDE form
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void navigateToMoreactions_LinkCase(){
		FDE_Operations.MoreOptionsLinksNavigation(FDEMoreOptionsPageObjects.moreOptions("Linked Cases"));
	    CommonOperations.agwaitTillVisible(FDEFormLinkCasesWindowPageObjects.linkLabel);
		agIsVisible(FDEFormLinkCasesWindowPageObjects.linkLabel);
	}

	
	/**********************************************************************************************************
	 * @Objective: The below method is created to link case 
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void caseLink(String scenarioName)
	
	{
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		agClick(FDEFormLinkCasesWindowPageObjects.link);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agIsVisible(FDEFormLinkCasesWindowPageObjects.looklabel);
		agSetValue(FDEFormLinkCasesWindowPageObjects.receiptno, getTestDataCellValue(scenarioName, "ReceiptNo"));
		agClick(FDEFormLinkCasesWindowPageObjects.search);
		agSetStepExecutionDelay("2000");
		agClick(FDEFormLinkCasesWindowPageObjects.checkbox);
		agClick(FDEFormLinkCasesWindowPageObjects.ok);  
		setData_LinkedReasonWindow(scenarioName);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
}
	/*{
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		navigateToMoreactions_LinkCase();
		searchAndLinkReceiptNo(scenarioName);
		agClick(FDEFormLinkCasesWindowPageObjects.closeLink);
		status =agIsVisible(FDEFormLinkCasesWindowPageObjects.validationPopup);
		if (status) {
			String Validation = agGetText(FDEFormLinkCasesWindowPageObjects.validationPopup);
			agAssertContainsText(FDEFormLinkCasesWindowPageObjects.validationPopup, "Linked Successfully.");
			Reports.ExtentReportLog("Link Case", Status.PASS,"Case is Linked successfully :: Validation-" + Validation, true);
		} else {
			Reports.ExtentReportLog("Link Case", Status.FAIL, "Case is not Linked!", true);
		}
		agClick(FDEFormLinkCasesWindowPageObjects.validationOkButton);
	}*/
	/**********************************************************************************************************
	 * @Objective: The below method is created to search the case based on receipt ID
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndLinkReceiptNo(String scenarioName){
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDEFormLinkCasesWindowPageObjects.link);
		agSetStepExecutionDelay("2000");
		agSetValue(FDEFormLinkCasesWindowPageObjects.setDataAdverseEventLookUp("Receipt No"), getTestDataCellValue(scenarioName, "ReceiptNo"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(FDEFormLinkCasesWindowPageObjects.searchButton);
		agSetStepExecutionDelay("2000");
		agClick(FDEFormLinkCasesWindowPageObjects.adverseEventlookupcheckBox);
		agClick(FDEFormLinkCasesWindowPageObjects.lookupOkButton);
		setData_LinkedReasonWindow(scenarioName);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to set linked reason dropdown
	 * @InputParameters: dropdownvalue 
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void setlinkedReasonDropdown(String dropdownvalue){
		agClick(FDEFormLinkCasesWindowPageObjects.linkedReasonDropdownClick);
		agClick(FDEFormLinkCasesWindowPageObjects.selectlinkedReason(dropdownvalue));
		
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to set data in linked reason code.
	 * @InputParameters: scenarioName 
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void setData_LinkedReasonWindow(String scenarioName){
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		setlinkedReasonDropdown(getTestDataCellValue(scenarioName, "LinkedReason"));
		agSetValue(FDEFormLinkCasesWindowPageObjects.descriptionTextArea,getTestDataCellValue(scenarioName, "Description"));
		agClick(FDEFormLinkCasesWindowPageObjects.submitButton);
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify linked reason data in link AE case PopUp.
	 * @InputParameters: scenarioName 
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 30-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void verifyLinkedData(String scenarioName, String verify) 
	
	{

		if(verify.equals("LinkCase"))
	    {   Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
	        CommonOperations.agwaitTillVisible(FDEFormLinkCasesWindowPageObjects.deLinkbutton, 5, 1000);
	        agClick(FDEFormLinkCasesWindowPageObjects.verifyRCPTNo_ReferredAECase);
	        agCheckPropertyValue("title", getTestDataCellValue(scenarioName, "ReceiptNo"), FDEFormLinkCasesWindowPageObjects.verifyRCPTNo_ReferredAECase);
			Reports.ExtentReportLog("Link Case Verification is Successfull", Status.PASS,"", true);
		}
		
		
		else if(verify.equals("DelinkCase"))	
		{	Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
	    	CommonOperations.agwaitTillVisible(FDEFormLinkCasesWindowPageObjects.deLinkbutton, 5, 1000);
		    agClick(FDEFormLinkCasesWindowPageObjects.verifyRCPTNo_ReferredAECase);
		  //  agCheckPropertyValue("title", getTestDataCellValue(scenarioName, "ReceiptNo"), FDEFormLinkCasesWindowPageObjects.verifyRCPTNo_ReferredAECase);
		    Reports.ExtentReportLog("Link Case Verification is Successfull", Status.PASS,"", false);
		}
		else
		{
		Reports.ExtentReportLog("Verification is Unsuccessfull", Status.FAIL,"", true);
		}
		    
	}
	
	/*{
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		navigateToMoreactions_LinkCase();
		if(verify.equals("LinkCase"))
	    {   
			agAssertVisible(FDEFormLinkCasesWindowPageObjects.referredAECaseLabel);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "ReceiptNo"), FDEFormLinkCasesWindowPageObjects.verifyRCPTNo_ReferredAECase);
			Reports.ExtentReportLog("Link Case Verification is Successfull", Status.PASS,"", true);
		}
		else if(verify.equals("DelinkCase"))
			
		{
			if(agIsVisible(FDEFormLinkCasesWindowPageObjects.referredAECaseLabel)==false)
			{
				Reports.ExtentReportLog("DeLink Case Verification is Successfull", Status.PASS,"", true);
			}
			else
			{
				Reports.ExtentReportLog("Delink Verification is Unsuccessfull", Status.FAIL,"", true);
			}
		}
		else
		{
		Reports.ExtentReportLog("Verification is Unsuccessfull", Status.FAIL,"", true);
		}
		
      agClick(FDEFormLinkCasesWindowPageObjects.closeLink);
}*/
	/**********************************************************************************************************
	 * @Objective: The below method is created to delink the case.
	 * @InputParameters:  
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 30-Jul-2019
	 * @UpdatedByAndWhen:

*********************************************************************************************************/	
	public static void deLinkCase(String scenarioName)
	{
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.agwaitTillVisible(FDEFormLinkCasesWindowPageObjects.deLinkbutton, 5, 1000);
		agClick(FDEFormLinkCasesWindowPageObjects.deLinkcase(getTestDataCellValue(scenarioName, "ReceiptNo")));
		Reports.ExtentReportLog("", Status.INFO, "Case is Delinked", true);
		agClick(FDEFormLinkCasesWindowPageObjects.deLinkbutton);
		agClick(FDEFormLinkCasesWindowPageObjects.okbutton);
		
	}
	/*{
		navigateToMoreactions_LinkCase();
		agClick(FDEFormLinkCasesWindowPageObjects.deLinkCheckBox);
		agClick(FDEFormLinkCasesWindowPageObjects.deLink);
		agClick(FDEFormLinkCasesWindowPageObjects.delinkYesButton);
		agClick(FDEFormLinkCasesWindowPageObjects.closeLink);
		CommonOperations.agwaitTillVisible(FDEFormLinkCasesWindowPageObjects.validationPopup);
		status =agIsVisible(FDEFormLinkCasesWindowPageObjects.validationPopup);
		if (status) {
			String Validation = agGetText(FDEFormLinkCasesWindowPageObjects.validationPopup);
			agAssertContainsText(FDEFormLinkCasesWindowPageObjects.validationPopup, "DeLinked Successfully.");
			Reports.ExtentReportLog("Delink Case", Status.PASS,"Case is Delinked successfully :: Validation-" + Validation, true);
		} else {
			Reports.ExtentReportLog("Delink Case", Status.FAIL, "Case is not Delinked!", true);
		}
		agClick(FDEFormLinkCasesWindowPageObjects.validationOkButton);
	}*/
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to delink the case.(SCript specific)
	 * @InputParameters:  
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date : 30-Jul-2020
	 * @UpdatedByAndWhen:

*********************************************************************************************************/	
	public static void deLinkCas(String ReceiptNo)
	{
		CommonOperations.agwaitTillVisible(FDEFormLinkCasesWindowPageObjects.deLinkbutton, 5, 1000);
		if(agIsVisible(FDEFormLinkCasesWindowPageObjects.deLinkcase(ReceiptNo))){
			agJavaScriptExecuctorClick(FDEFormLinkCasesWindowPageObjects.deLinkcase(ReceiptNo));
		}else {
			agJavaScriptExecuctorClick(FDEFormLinkCasesWindowPageObjects.deLinkcasesingle);
		}
		Reports.ExtentReportLog("", Status.INFO, "Case is Delinked", true);
		agClick(FDEFormLinkCasesWindowPageObjects.deLinkbutton);
		agClick(FDEFormLinkCasesWindowPageObjects.okbutton);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to get linked case number
	 * @InputParameters:  
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date : 30-Jul-2020
	 * @UpdatedByAndWhen:

*********************************************************************************************************/	
	public static String getLinkedRCT() {
		return agGetAttribute("value", FDEFormLinkCasesWindowPageObjects.Linkreceiptno);
	}
}