package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDEMoreOptionsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_SubmissionTrackingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_SubmissionTrackingOperation extends ToolManager {

	static String className = FDE_SubmissionTrackingOperation.class.getSimpleName();

	public static WebElement webElement;
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to add distribution contact in
	 *             Submission tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 13-February-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addDistributionContact(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agClick(FDE_SubmissionTrackingPageObjects.AddDistContact_Btn);
		agSetStepExecutionDelay("3000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		agSetValue(FDE_SubmissionTrackingPageObjects.Contact_Textbox,
				getTestDataCellValue(scenarioName, "Distribute_SubTracking_DistContLookUp_Contact"));
		agSetValue(FDE_SubmissionTrackingPageObjects.ReportFormat_Textbox,
				getTestDataCellValue(scenarioName, "Distribute_SubTracking_DistContLookUp_ReportFormatName"));
		CommonOperations.setListDropDownValue(FDE_SubmissionTrackingPageObjects.partnerType_Dropdown,
				getTestDataCellValue(scenarioName, "Distribute_SubTracking_DistContLookUp_PartnerType"));

		if (getTestDataCellValue(scenarioName, "Distribute_SubTracking_DistContLookUp_PartnerType")
				.equalsIgnoreCase("Company Unit")) {
			CommonOperations.setListDropDownValue(FDE_SubmissionTrackingPageObjects.unitType_Dropdown,
					getTestDataCellValue(scenarioName, "Distribute_SubTracking_DistContLookUp_UnitType"));
		}

		CommonOperations.setListDropDownValue(FDE_SubmissionTrackingPageObjects.format_Dropdown,
				getTestDataCellValue(scenarioName, "Distribute_SubTracking_DistContLookUp_Format"));
		CommonOperations.setListDropDownValue(FDE_SubmissionTrackingPageObjects.report_Dropdown,
				getTestDataCellValue(scenarioName, "Distribute_SubTracking_DistContLookUp_Report"));

		Reports.ExtentReportLog("", Status.PASS,
				"contacts  are added and listed in submission tracking tab." + "<br />", true);
		agClick(FDE_SubmissionTrackingPageObjects.searchContact_Btn);

		agSetStepExecutionDelay("3000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		if (agIsVisible(FDE_SubmissionTrackingPageObjects.selectContact_Chkbox)) {
			agClick(FDE_SubmissionTrackingPageObjects.selectContact_Chkbox);
			Reports.ExtentReportLog("", Status.INFO, "Contact selected", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Contact not present", true);
		}

		agClick(FDE_SubmissionTrackingPageObjects.okContact_Btn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click the submission contacts
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 11-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void DistributeContact_Click(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		setDropDownValue(FDE_SubmissionTrackingPageObjects.contactName_Dropdown, scenarioName,
				"DistributionContactName");
		CommonOperations.takeScreenShot();
		agAssertVisible(FDE_SubmissionTrackingPageObjects
				.ContactName(getTestDataCellValue(scenarioName, "DistributionContactName")));
		agClick(FDE_SubmissionTrackingPageObjects
				.ContactName(getTestDataCellValue(scenarioName, "DistributionContactName")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is verify distribution contact in Submission
	 *             tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 13-February-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDistributionContact(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		String contName = getTestDataCellValue(scenarioName, "Distribute_SubTracking_DistContLookUp_Contact");
		String format = getTestDataCellValue(scenarioName, "Distribute_SubTracking_DistContLookUp_Format");

		if (agIsVisible(FDE_SubmissionTrackingPageObjects.select_Contact(contName, format))) {
			Reports.ExtentReportLog("List of Distribution Contacts", Status.PASS, "Distribution Contact is added",
					true);
		} else {
			Reports.ExtentReportLog("List of Distribution Contacts", Status.FAIL, "Distribution Contact not added",
					true);
		}
		CommonOperations.incremAlmStepNo("False", "Pass", "Contact Name:"+contName+" and Format Name:"+format, false);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is Delete Single Contact
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 13-February-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void SingleDeleteOperation() {

		// Storing Contact Names in an ArrayList
		ArrayList<String> Names = FDE_SubmissionTrackingOperation.GetContactListFromExcel();
		int count = Names.size() - 5;

		// loop to find contacts in each table and perform iterations if table doesnt
		// exist
		for (int i = 0; i < count; i++) {
			String Contact = Names.get(i);
			System.out.print(Contact);

			for (int j = 0; j < 9; j++) {
				if (agIsVisible(FDE_SubmissionTrackingPageObjects.ContactName(Contact)) == true) {
					System.out.print("Contact Exist");

					if (Contact == Names.get(0) || Contact == Names.get(1) || Contact == Names.get(2)) {
						agSetValue(FDE_SubmissionTrackingPageObjects.RemovalReason(Contact), Contact);
						agClick(FDE_SubmissionTrackingPageObjects.CheckBox(Contact));
						Reports.ExtentReportLog("", Status.INFO, "Contact is Selected", true);
						agClick(FDE_SubmissionTrackingPageObjects.DropDeleteBtn);
						agIsVisible(FDE_SubmissionTrackingPageObjects.SubmissionConfirmMsg);
						agClick(FDE_SubmissionTrackingPageObjects.ConfirmationOkBtn);
						agWaitTillInvisibilityOfElement(FDE_SubmissionTrackingPageObjects.CheckBox(Contact));
						break;
					} else {
						Reports.ExtentReportLog("", Status.INFO, "Failed to Delete Contact", true);
						break;
					}
				}

				else {
					// click on next table if it could able to find in first table.
					if (agIsVisible(FDE_SubmissionTrackingPageObjects.NxtTableBtn)) {
						agClick(FDE_SubmissionTrackingPageObjects.NxtTableBtn);
					}

				}
			}
			// Moved back to first table.
			agClick(FDE_SubmissionTrackingPageObjects.FirstTable);

		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Verify Nullification Review
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 08-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void NullificationReview() {

		// Storing Contact Names in an ArrayList
		ArrayList<String> Names = FDE_SubmissionTrackingOperation.GetContactListFromExcel();
		int count = Names.size() - 5;

		// loop to find contacts in each table and perform iterations if table doesnt
		// exist
		for (int i = 0; i < count; i++) {
			String Contact = Names.get(i);
			System.out.print(Contact);

			for (int j = 0; j < 9; j++) {
				if (agIsVisible(FDE_SubmissionTrackingPageObjects.NullificationContact(Contact)) == true) {
					System.out.print("Contact Exist");
					Reports.ExtentReportLog("", Status.INFO, "Nullification Review Exist", true);
				}

				else {
					// click on next table if it could able to find in first table.
					if (agIsVisible(FDE_SubmissionTrackingPageObjects.NxtTableBtn)) {
						agClick(FDE_SubmissionTrackingPageObjects.NxtTableBtn);
					}

				}
			}
			// Moved back to first table.
			agClick(FDE_SubmissionTrackingPageObjects.FirstTable);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Verify E2B R2 Report Format.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 08-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void IsE2BR2ReportingEnabled() {
		ArrayList<String> Names = FDE_SubmissionTrackingOperation.GetContactListFromExcel();
		int count = Names.size() - 7;
		for (int i = 0; i < count; i++) {
			String Contact = Names.get(i);
			System.out.print(Contact);
			agSetStepExecutionDelay("3000");
			for (int j = 0; j < 4; j++) {
				if ((agIsVisible(FDE_SubmissionTrackingPageObjects.ContactName(Contact)) == true)
						&& (agIsVisible(FDE_SubmissionTrackingPageObjects.IsE2BR2FormatName(Contact)) == true)
						&& (agIsVisible(FDE_SubmissionTrackingPageObjects.IsE2BReportFormat(Contact)) == true)) {
					Reports.ExtentReportLog("", Status.INFO, "E2B_R2_ Report Format Exist for", true);
					Reports.ExtentReportLog("", Status.INFO, "E2B Format Name Exist for", true);
					break;
				} else {
					// click on next table if it could able to find in first table.
					if (agIsVisible(FDE_SubmissionTrackingPageObjects.NxtTableBtn)) {
						agClick(FDE_SubmissionTrackingPageObjects.NxtTableBtn);
					}

				}
			}
			// Moved back to first table.
			agClick(FDE_SubmissionTrackingPageObjects.FirstTable);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Verify E2B R3 Report Format.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 16-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void IsE2BR3ReportingEnabled() {
		ArrayList<String> Names = FDE_SubmissionTrackingOperation.GetContactListFromExcel();
		int count = Names.size() - 5;
		for (int i = 0; i < count; i++) {
			String Contact = Names.get(i);
			System.out.print(Contact);

			for (int j = 0; j < 4; j++) {
				if ((agIsVisible(FDE_SubmissionTrackingPageObjects.ContactName(Contact)) == true)
						&& (agIsVisible(FDE_SubmissionTrackingPageObjects.IsE2BR3FormatName(Contact)) == true)
						&& (agIsVisible(FDE_SubmissionTrackingPageObjects.IsE2BReportFormat(Contact)) == true)) {
					Reports.ExtentReportLog("", Status.INFO, "E2B_R3_ Report Format Exist for", true);
					Reports.ExtentReportLog("", Status.INFO, "E2B Format Name Exist for", true);
					break;
				} else {
					// click on next table if it could able to find in first table.
					if (agIsVisible(FDE_SubmissionTrackingPageObjects.NxtTableBtn)) {
						agClick(FDE_SubmissionTrackingPageObjects.NxtTableBtn);
					}

				}
			}
			// Moved back to first table.
			agClick(FDE_SubmissionTrackingPageObjects.FirstTable);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Verify When R2 is failed, do you get to
	 *             see validations? .
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 20-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void R2FailedValidation() {
		ArrayList<String> Names = FDE_SubmissionTrackingOperation.GetContactListFromExcel();
		int count = Names.size() - 5;
		for (int i = 0; i < count; i++) {
			String Contact = Names.get(i);
			System.out.print(Contact);
			agSetStepExecutionDelay("3000");
			for (int j = 0; j < 4; j++) {
				if ((agIsVisible(FDE_SubmissionTrackingPageObjects.ContactName(Contact)) == true)
						&& (agIsVisible(FDE_SubmissionTrackingPageObjects.IsE2BR2FormatName(Contact)) == true)
						&& (agIsVisible(FDE_SubmissionTrackingPageObjects.DistributionFailedStatus(Contact)) == true)) {
					agClick(FDE_SubmissionTrackingPageObjects.DistributionFailedStatus(Contact));
					if ((agIsVisible(FDE_SubmissionTrackingPageObjects.ValidationMsg) == true)
							&& (agIsVisible(FDE_SubmissionTrackingPageObjects.TagId) == true)) {
						Reports.ExtentReportLog("", Status.INFO, "R2 Failed to generate Report", true);
					}
					agClick(FDE_SubmissionTrackingPageObjects.DistributionFailureCloseBtn);
					break;
				} else {
					// click on next table if it could able to find in first table.
					if (agIsVisible(FDE_SubmissionTrackingPageObjects.NxtTableBtn)) {
						agClick(FDE_SubmissionTrackingPageObjects.NxtTableBtn);
					}

				}
			}
			// Moved back to first table.
			agClick(FDE_SubmissionTrackingPageObjects.FirstTable);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The Add and Delete Documents/files under submission
	 *             Tracking(in-progress)
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 14-February-2020
	 * @UpdatedByAndWhen: Pooja S on 11-March-2020
	 **********************************************************************************************************/

	public static void AddDeleteLocalDocuments(String scenarioName) {

		/*
		 * if(agIsVisible(FDE_SubmissionTrackingPageObjects.DocumentCheckBox)==true) {
		 * agClick(FDE_SubmissionTrackingPageObjects.DeleteDocumentBtn);
		 * agIsVisible(FDE_SubmissionTrackingPageObjects.SubmissionConfirmMsg);
		 * agClick(FDE_SubmissionTrackingPageObjects.ConfirmationOkBtn);
		 * agIsVisible(FDE_SubmissionTrackingPageObjects.NoRecordFoundMsg);
		 * agSetValue(FDE_SubmissionTrackingPageObjects.AddDocument,""); }
		 */
		agJavaScriptExecuctorClick(FDE_SubmissionTrackingPageObjects.documents);
		CommonOperations.agwaitTillVisible(FDE_SubmissionTrackingPageObjects.DisDocheldbysender_label);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String Filename = Multimaplibraries.getTestDataCellValue(scenarioName, "Filename");
		if (getTestDataCellValue(scenarioName, "AddLocalFiles").equals("true")) {
			agClick(FDE_SubmissionTrackingPageObjects.AddDocumentBtn);
			agSetStepExecutionDelay("6000");
			agUploadDocuments(lsmvConstants.LSMV_testDataInput + "\\" + getTestDataCellValue(scenarioName, "Filename"));
			agWaitTillInvisibilityOfElement(FDE_SubmissionTrackingPageObjects.loading);
			agWaitTillVisibilityOfElement(FDE_SubmissionTrackingPageObjects.docUploadMsg);

			if (getTestDataCellValue(scenarioName, "DeleteDocuments").equalsIgnoreCase("true")) {
				agClick(FDE_SubmissionTrackingPageObjects.SubmissionDoc_Checkbox);
				agClick(FDE_SubmissionTrackingPageObjects.DeleteDocumentBtn);
				agIsVisible(FDE_SubmissionTrackingPageObjects.deleteConfirmPOPUp);
				agJavaScriptExecuctorClick(FDE_SubmissionTrackingPageObjects.deleteConfirmPOPupOkBtn);
				agWaitTillInvisibilityOfElement(FDE_SubmissionTrackingPageObjects.Delete_Tooltip);
			}
			CommonOperations.takeScreenShot();
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Verify View Proposed Distribution Contact
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 18-February-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyViewProposedDistributionContact() {
		agSetStepExecutionDelay("2000");

		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("View Proposed Distribution Contacts "));

		// agWaitTillVisibilityOfElement(FDE_SubmissionTrackingPageObjects.Paginatoricon);
		ArrayList<String> Names = FDE_SubmissionTrackingOperation.GetContactListFromExcel();
		int count = Names.size();

		// loop to find contacts in Search Box
		for (int i = 0; i < count; i++) {
			String Contact = Names.get(i);
			System.out.print(Contact);
			agSetValue(FDE_SubmissionTrackingPageObjects.searchTextBox, Contact);
			agClick(FDE_SubmissionTrackingPageObjects.SearchIcon);

			if (agIsVisible(FDE_SubmissionTrackingPageObjects.DistributionContact(Contact)) == true) {
				System.out.print("Contact Exist");
				Reports.ExtentReportLog("", Status.INFO, "Contact Exist", true);

			} else {
				// if contact doesnt exist.
				Reports.ExtentReportLog("", Status.INFO, "Contact Not Found", true);
				System.out.print("Contact not Exist");
				agSetStepExecutionDelay("2000");

			}

		}
		agClick(FDE_SubmissionTrackingPageObjects.close_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Get list of Contacts from the Excel Sheet
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 18-February-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> GetContactListFromExcel() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		ArrayList Al = new ArrayList<>();
		String st1;

		for (int i = 0; i < 11; i++) {
			int j = i + 1;
			Al.add(i, getTestDataCellValue("DistCont_" + j, "DistributionContactName"));
		}
		return Al;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 6-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_SubmissionTrackingPageObjects.clickdropdown(label));
			agSetStepExecutionDelay("4000");
			agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);
			agClick(FDE_SubmissionTrackingPageObjects.clickdropdown(label));
			agClick(FDE_SubmissionTrackingPageObjects
					.selectDropdownvalue(getTestDataCellValue(scenarioName, columnName)));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify distribution contact in Submission
	 *             tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 18-February-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyProposedContactList(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		setDropDownValue(FDE_SubmissionTrackingPageObjects.contactName_Dropdown, scenarioName,
				"DistributionContactName");
		CommonOperations.takeScreenShot();
		agAssertVisible(FDE_SubmissionTrackingPageObjects
				.ContactName(getTestDataCellValue(scenarioName, "DistributionContactName")));
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify distribution contact in Submission
	 *             tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 18-February-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyRuleName(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		setDropDownValue(FDE_SubmissionTrackingPageObjects.contactName_Dropdown, scenarioName,
				"DistributionContactName");
		agSetStepExecutionDelay("5000");
		agClick(FDE_SubmissionTrackingPageObjects.automatic_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agAssertVisible(FDE_SubmissionTrackingPageObjects.ruleNameText(getTestDataCellValue(scenarioName, "RuleName")));
		CommonOperations.takeScreenShot();
		agClick(FDE_SubmissionTrackingPageObjects.close_Btn);
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify distribution contact Message
	 *             Submission tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 19-February-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyProposedContactListMsg() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		for (int i = 1; i < 10; i++) {
			agSetStepExecutionDelay("5000");
			agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);
			String Expectedmsg = agGetText(FDE_SubmissionTrackingPageObjects.listGenerated_msg);
			if (Expectedmsg.equals("Auto-Distribution List Generation Completed")) {
				Reports.ExtentReportLog("", Status.PASS, "Auto-Distribution List Generation Completed", true);
				break;
			} else
				agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);

		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download
	 *             ProposedDistributedContacts to excel.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 20-February-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void exportListofProposedDistributedContacts(String FileName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("View Proposed Distribution Contacts "));
		agSetStepExecutionDelay("5000");

		if (agIsVisible(FDE_SubmissionTrackingPageObjects.export_Btn) == true) {
			agClick(FDE_SubmissionTrackingPageObjects.export_Btn);
			CommonOperations.takeScreenShot();
			try {
				Thread.sleep(8000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			CommonOperations.move_Downloadedexcel(FileName);
		} else {
			Reports.ExtentReportLog("Export to excel pop is not displayed", Status.INFO, "", true);
		}
		agClick(FDE_SubmissionTrackingPageObjects.close_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add the case documents and delete
	 *             the case documents.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 10-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AddCase_Documents() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		agClick(FDE_SubmissionTrackingPageObjects.AddCaseDocumentBtn);
		agClick(FDE_SubmissionTrackingPageObjects.DocumentCheckBox);
		agClick(FDE_SubmissionTrackingPageObjects.SelectBtn);
		agClick(FDE_SubmissionTrackingPageObjects.ConfirmationOkBtn);
		// agClick(FDE_SubmissionTrackingPageObjects.submission_Checkbx("1"));
		// agClick(FDE_SubmissionTrackingPageObjects.DeleteDocumentBtn);
		// agWaitTillInvisibilityOfElement(FDE_SubmissionTrackingPageObjects.Delete_Tooltip);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to compare record count with
	 *             downloaded excel
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 20-February-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void recordCountVerification(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		int c = xls.getRowCount("Sheet1");
		int count = c - 1;
		// String num = Integer.toString(count);
		/*
		 * String applrecordcount =
		 * agGetText(FDE_SubmissionTrackingPageObjects.paginator); String[] data =
		 * applrecordcount.split(" "); System.out.println(data.length); String
		 * recordCount = data[4]; System.out.println(recordCount);
		 */
		/*
		 * String applrecordcount =
		 * agGetText(FDE_SubmissionTrackingPageObjects.paginator); String a =
		 * applrecordcount.substring(applrecordcount.lastIndexOf("of")); String r =
		 * a.substring(2).trim(); //int record=Integer.parseInt(recordCount);
		 * Reports.ExtentReportLog("", Status.INFO,
		 * "Total no of Records in exported excel::" + count, false);
		 */

		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in application::" + count, false);
		/*
		 * if (num.equalsIgnoreCase(r.trim())) { Reports.ExtentReportLog("",
		 * Status.PASS, "Record count verification is successfull", true); } else {
		 * Reports.ExtentReportLog("", Status.FAIL,
		 * "Record count verification is Unsuccessfull", true); }
		 */
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify distributed contact Message
	 *             Submission tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 09-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyFailedDistributionStatus() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		for (int i = 1; i < 10; i++) {
			agSetStepExecutionDelay("5000");
			agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);
			String Expectedmsg = agGetText(FDE_SubmissionTrackingPageObjects.listGenerated_msg);
			System.out.print(Expectedmsg);
			if (Expectedmsg.equals("Report Generation Failed")) {
				Reports.ExtentReportLog("", Status.PASS, "Report Generation Completed ", true);
				break;
			} else
				agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);

		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify distribution contact in Submission
	 *             tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 10-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyReportGenerationStatus(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		setDropDownValue(FDE_SubmissionTrackingPageObjects.contactName_Dropdown, scenarioName,
				"DistributionContactName");
		agAssertVisible(FDE_SubmissionTrackingPageObjects.distFailStatus_msg);
		agClick(FDE_SubmissionTrackingPageObjects.distFailStatus_msg);
		agClick(FDE_SubmissionTrackingPageObjects.xmlGeneration_close);
		CommonOperations.takeScreenShot();
		agClick(FDE_SubmissionTrackingPageObjects.close_Btn);
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify distribution contact in Submission
	 *             tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 11-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SetDistributionStatus(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		setDropDownValue(FDE_SubmissionTrackingPageObjects.contactName_Dropdown, scenarioName,
				"DistributionContactName");
		agClick(FDE_SubmissionTrackingPageObjects.listSelect_checkbox);
		agMouseHover(FDE_SubmissionTrackingPageObjects.moreOptionsHover);
		agClick(FDE_SubmissionTrackingPageObjects.moreOptions("Redistribute(R)"));
		CommonOperations.takeScreenShot();
		agAssertVisible(FDE_SubmissionTrackingPageObjects.redistPlaced_label);
		agClick(FDE_SubmissionTrackingPageObjects.redistPlaced_Ok);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify Exclusion contact List in
	 *             Submission tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @Date : 12-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyExclusionList(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		ArrayList<String> Names = FDE_SubmissionTrackingOperation.GetContactListFromExcel();
		int count = Names.size();

		// loop to find contacts in each table and perform iterations if table doesnt
		// exist
		for (int i = 0; i < count; i++) {
			String Contact = Names.get(i);
			System.out.print(Contact);

			for (int j = 0; j < 9; j++) {
				agSetStepExecutionDelay("2000");
				if (agIsVisible(FDE_SubmissionTrackingPageObjects.ContactName(Contact)) == true) {
					System.out.print("Contact Exist");

					agSetStepExecutionDelay("2000");
					if (agIsVisible(FDE_SubmissionTrackingPageObjects.ExclusionContact(Contact))
							&& agIsVisible(FDE_SubmissionTrackingPageObjects.ExclusionContactRemoval(Contact))) {
						CommonOperations.takeScreenShot();
						Reports.ExtentReportLog("", Status.INFO, "Selected Contact is in Exclusion List", true);
						break;
					} else {
						Reports.ExtentReportLog("", Status.INFO, "Selected contact not in exclusion list", true);
						break;
					}
				}

				else {
					// click on next table if it could able to find in first table.
					if (agIsVisible(FDE_SubmissionTrackingPageObjects.NxtTableBtn)) {
						agClick(FDE_SubmissionTrackingPageObjects.NxtTableBtn);
						agSetStepExecutionDelay("2000");
					}

				}
			}
			// Moved back to first table.
			agClick(FDE_SubmissionTrackingPageObjects.FirstTable);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify case in minor change workflow.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 11-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyWorkflow() {
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
		String WorkFlowheader = agGetText(CaseListingPageObjects.caseActHeader);
		if (WorkFlowheader.equalsIgnoreCase("Minor Change")) {
			Reports.ExtentReportLog("", Status.PASS, "Case Moved to Minor Change Automatically", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Drop/delete distribution contact in
	 *             Submission tracking screen and distribute
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 12-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void dropContactAndDistribute(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		setDropDownValue(FDE_SubmissionTrackingPageObjects.contactName_Dropdown, scenarioName,
				"DistributionContactName");
		agSetValue(FDE_SubmissionTrackingPageObjects.removalReason_txt,
				getTestDataCellValue(scenarioName, "Distribute_SubTracking_Removal_Reason"));
		agClick(FDE_SubmissionTrackingPageObjects.listSelect_checkbox);
		Reports.ExtentReportLog("", Status.INFO, "Contact is Selected", true);
		agClick(FDE_SubmissionTrackingPageObjects.DropDeleteBtn);
		Reports.ExtentReportLog("", Status.INFO, "Contact is Deleted", true);
		CommonOperations.takeScreenShot();
		agIsVisible(FDE_SubmissionTrackingPageObjects.SubmissionConfirmMsg);
		agClick(FDE_SubmissionTrackingPageObjects.ConfirmationOkBtn);
		agClick(FDE_SubmissionTrackingPageObjects.listSelect_checkbox);
		agClick(FDE_SubmissionTrackingPageObjects.distribution_Btn);
		agIsVisible(FDE_SubmissionTrackingPageObjects.distributionConfirm_msg);
		agClick(FDE_SubmissionTrackingPageObjects.distconfirmationOkBtn);
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify success distribution contact in
	 *             Submission tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 12-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySuccessDistributionStatus() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		for (int i = 1; i < 10; i++) {
			agSetStepExecutionDelay("5000");
			agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);
			String Expectedmsg = agGetText(FDE_SubmissionTrackingPageObjects.listGenerated_msg);
			System.out.print(Expectedmsg);
			if (Expectedmsg.equals("Report Generation Successful")) {
				Reports.ExtentReportLog("", Status.PASS, "Report Generation Completed ", true);
				break;
			} else
				agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);

		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify distribution status in Submission
	 *             tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 12-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySucessReportGenerationStatus(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		setDropDownValue(FDE_SubmissionTrackingPageObjects.contactName_Dropdown, scenarioName,
				"DistributionContactName");
		agSetStepExecutionDelay("3000");
		agAssertVisible(FDE_SubmissionTrackingPageObjects.redistributionStatus_msg);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.takeScreenShot();
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set the report details in
	 *             Distribute--> submisison tracking Informed Authority
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 12-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setReportDetails_IA(String scenarioName) {
		agSetStepExecutionDelay("5000");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		setDropDownValue_IA(FDE_SubmissionTrackingPageObjects.IA_Report_Medium, scenarioName,
				"Distribute_Subtracking_IA_Report_Medium");
		setDropDownValue_IA(FDE_SubmissionTrackingPageObjects.IA_Reporting_Status, scenarioName,
				"Distribute_Subtracking_IA_Reporting_Status");
		setDropDownValue_IA(FDE_SubmissionTrackingPageObjects.IA_LocallyExpeditedLabel, scenarioName,
				"Distribute_Subtracking_IA_LocallyExpedited");
		setDropDownValue_IA(FDE_SubmissionTrackingPageObjects.IA_LocalCriteriaLabel, scenarioName,
				"Distribute_Subtracking_IA_LocalCriteriaReportType");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value in submission
	 *             tracking Informed Authority
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 12-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setDropDownValue_IA(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_SubmissionTrackingPageObjects.clickdropdown_IA(label));
			agClick(FDE_SubmissionTrackingPageObjects
					.selectDropdownvalue_IA(getTestDataCellValue(scenarioName, columnName)));

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set the values in Submission
	 *             tracking Informed Authority screen.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 12-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setTextBox_IA(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		// agSetValue(
		// FDE_SubmissionTrackingPageObjects
		// .setInputTextbox_IA(FDE_SubmissionTrackingPageObjects.IA_autorityLabel),
		// getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_PartnerID"));

		agSetValue(
				FDE_SubmissionTrackingPageObjects
						.setInputTextbox_IA(FDE_SubmissionTrackingPageObjects.IA_commentsReasonLabel),
				getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Comments"));

		agSetValue(
				FDE_SubmissionTrackingPageObjects.setInputTextbox_IA(FDE_SubmissionTrackingPageObjects.IA_AckNoLabel),
				getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Ack_No"));

		agSetValue(
				FDE_SubmissionTrackingPageObjects.setInputTextbox_IA(FDE_SubmissionTrackingPageObjects.IA_RefNoLabel),
				getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Ref_No"));

		agSetValue(
				FDE_SubmissionTrackingPageObjects.setInputTextbox_IA(FDE_SubmissionTrackingPageObjects.IA_FollowupNo),
				getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Followup_No"));

		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Follow up check boxes in
	 *             submission tracking Informed Authority
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 13-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setFollowup_Checkbox_IA(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		if (getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Followup_Correction")
				.equalsIgnoreCase("Check")) {
			agClick(FDE_SubmissionTrackingPageObjects
					.followup_Checkbox(FDE_SubmissionTrackingPageObjects.Followup_Correction));
		}
		if (getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Followup_AddInfo")
				.equalsIgnoreCase("Check")) {
			agClick(FDE_SubmissionTrackingPageObjects
					.followup_Checkbox(FDE_SubmissionTrackingPageObjects.Followup_Addtional_Info));
		}
		if (getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Followup_ResponsetoAuthReq")
				.equalsIgnoreCase("Check")) {
			agClick(FDE_SubmissionTrackingPageObjects
					.followup_Checkbox(FDE_SubmissionTrackingPageObjects.Followup_Responseto_AuthReq));
		}
		if (getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Followup_DeviceEval")
				.equalsIgnoreCase("Check")) {
			agClick(FDE_SubmissionTrackingPageObjects
					.followup_Checkbox(FDE_SubmissionTrackingPageObjects.Followup_Device_Eval));
		}
		if (getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Followup_RepsenttoMFR")
				.equalsIgnoreCase("Check")) {
			agClick(FDE_SubmissionTrackingPageObjects
					.followup_Checkbox(FDE_SubmissionTrackingPageObjects.Followup_Reportsentto_Mfr));
		}
		if (getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Followup_RepsenttoFDA")
				.equalsIgnoreCase("Check")) {
			agClick(FDE_SubmissionTrackingPageObjects
					.followup_Checkbox(FDE_SubmissionTrackingPageObjects.Followup_Reportsentto_FDA));
		}
		if (getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Final").equalsIgnoreCase("Check")) {
			agClick(FDE_SubmissionTrackingPageObjects.followup_Checkbox(FDE_SubmissionTrackingPageObjects.Final));
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}
	/**********************************************************************************************************
	 * @Objective: Select date in JS calendar
	 * @InputParameters: Date , label
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 16-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	/*
	 * public static void setDatesCalender(String date , String label) { if
	 * (!date.trim().equalsIgnoreCase("#skip#")) { String[] Date = date.split("-");
	 * agClick(FDE_SubmissionTrackingPageObjects.setDatesTextboxes_IA(label));
	 * agClick(FDE_SubmissionTrackingPageObjects.monthSelect_IA);
	 * agJavaScriptExecuctorClick(FDE_SubmissionTrackingPageObjects.monthDropdown(
	 * Date[1],label)); agClick(FDE_SubmissionTrackingPageObjects.yearSelect_IA);
	 * agJavaScriptExecuctorClick(FDE_SubmissionTrackingPageObjects.yearDropdown(
	 * Date[2],label)); //
	 * agClick(FDE_SubmissionTrackingPageObjects.yearDropdown(Date[2]));
	 * 
	 * char[] temp = Date[0].toCharArray(); char result; if(temp[0] =='0') { result
	 * = temp[1];
	 * agClick(FDE_SubmissionTrackingPageObjects.dateSelect(String.valueOf(result),
	 * label)); } else {
	 * agClick(FDE_SubmissionTrackingPageObjects.dateSelect(Date[0],label)); } } }
	 */

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set the dates in submission
	 *             tracking Informed Authority
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 16-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDatesDetails_IA(String scenarioName) {
		agSetStepExecutionDelay("3000");
		agClick(FDE_SubmissionTrackingPageObjects
				.setDatesTextboxes_IA(FDE_SubmissionTrackingPageObjects.IA_DateInformedLabel));
		agClick(FDE_SubmissionTrackingPageObjects.setDates(FDE_SubmissionTrackingPageObjects.IA_DateInformedLabel));

		agClick(FDE_SubmissionTrackingPageObjects
				.setDatesTextboxes_IA(FDE_SubmissionTrackingPageObjects.IA_DecisionDateLabel));
		agClick(FDE_SubmissionTrackingPageObjects.setDates(FDE_SubmissionTrackingPageObjects.IA_DecisionDateLabel));

		agClick(FDE_SubmissionTrackingPageObjects
				.setDatesTextboxes_IA(FDE_SubmissionTrackingPageObjects.IA_AcknowledgementRecvDateLabel));
		agClick(FDE_SubmissionTrackingPageObjects
				.setDates(FDE_SubmissionTrackingPageObjects.IA_AcknowledgementRecvDateLabel));

		agClick(FDE_SubmissionTrackingPageObjects
				.setDatesTextboxes_IA(FDE_SubmissionTrackingPageObjects.IA_RefNo_RecvDate));
		agClick(FDE_SubmissionTrackingPageObjects.setDates(FDE_SubmissionTrackingPageObjects.IA_RefNo_RecvDate));

		agClick(FDE_SubmissionTrackingPageObjects
				.setDatesTextboxes_IA(FDE_SubmissionTrackingPageObjects.IA_DateInf_Distrbutor));
		agClick(FDE_SubmissionTrackingPageObjects.setDates(FDE_SubmissionTrackingPageObjects.IA_DateInf_Distrbutor));

		Reports.ExtentReportLog("", Status.INFO, "setdates : Scenario Name::" + scenarioName, true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the radio button and set
	 *             the reason for Nullification or Amendment radio button
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 16-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setReportingInfo_IA(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		if (getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Repfor_Nullification_Amendment")
				.equalsIgnoreCase("yes")) {
			agClick(FDE_SubmissionTrackingPageObjects
					.setReportNull_Amendment(FDE_SubmissionTrackingPageObjects.NullficationLabel));
			agSetValue(FDE_SubmissionTrackingPageObjects.Nullification_ReasonTextbox,
					getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Reasonfor_Nullification"));
		} else {
			agClick(FDE_SubmissionTrackingPageObjects
					.setReportNull_Amendment(FDE_SubmissionTrackingPageObjects.AmendementLabel));
			agSetValue(FDE_SubmissionTrackingPageObjects.Nullification_ReasonTextbox,
					getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Reasonfor_Nullification"));
		}
		Reports.ExtentReportLog("", Status.INFO, "Reporting information : Scenario Name::" + scenarioName, true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set the text boxes for sender's
	 *             comments event description and Case Summary and Reporter's
	 *             Comments
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 16-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setTextArea_IA(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		agSetValue(
				FDE_SubmissionTrackingPageObjects.setTextboxes(FDE_SubmissionTrackingPageObjects.sendersComments_label),
				getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Senders_comments"));
		agSetValue(FDE_SubmissionTrackingPageObjects.setTextboxes(FDE_SubmissionTrackingPageObjects.EventDesc_label),
				getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Event_Description"));
		agSetValue(FDE_SubmissionTrackingPageObjects.setTextboxes(FDE_SubmissionTrackingPageObjects.CaseSummary_label),
				getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_CaseSummary_Text"));
		Reports.ExtentReportLog("", Status.INFO, "Textboxes in IA screen : Scenario Name::" + scenarioName, true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to save the IA information
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 17-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void Save_IA() {
		agSetStepExecutionDelay("3000");
		agJavaScriptExecuctorClick(FDE_SubmissionTrackingPageObjects.SaveIA_Btn);
		agJavaScriptExecuctorClick(FDE_SubmissionTrackingPageObjects.Confirm_okBtn);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to check the radio button for
	 *             reporter info authority
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 17-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setReporter_authority(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		if (getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_ReporterInf_Authority")
				.equalsIgnoreCase("yes")) {
			agClick(FDE_SubmissionTrackingPageObjects.setRep_radiobtn(FDE_SubmissionTrackingPageObjects.Yeslabel));
			Reports.ExtentReportLog("", Status.INFO, "Reporter authority : Scenario Name::" + scenarioName, true);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verification of Report details of test data in IA submission
	 *             tracking(in-progress)
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 17-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void Reportdetails_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Report_Medium"),
				FDE_SubmissionTrackingPageObjects.Reports_Verify("reportMedium"));

		agCheckPropertyText(getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Reporting_Status"),
				FDE_SubmissionTrackingPageObjects.Reports_Verify("reportingStatus"));
		Reports.ExtentReportLog("", Status.INFO, "Report details : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: Verification of dates in IA submission tracking
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 17-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void Dates_Verification(String scenarioName) {
		agCheckPropertyValue("value",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Date_informed")),
				FDE_SubmissionTrackingPageObjects.Dates_Verify(FDE_SubmissionTrackingPageObjects.IA_dateInformed));

		agCheckPropertyValue("value",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Decision_Date")),
				FDE_SubmissionTrackingPageObjects.Dates_Verify(FDE_SubmissionTrackingPageObjects.IA_decisionDate));

		agCheckPropertyValue("value",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Ack_RecvDate")),
				FDE_SubmissionTrackingPageObjects.Dates_Verify(FDE_SubmissionTrackingPageObjects.IA_ackReceivedDate));

		agCheckPropertyValue("value",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_RefNo_RecvDate")),
				FDE_SubmissionTrackingPageObjects
						.Dates_Verify(FDE_SubmissionTrackingPageObjects.IA_refNumReceivedDate));

		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(
						getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Dateinf_Distributor")),
				FDE_SubmissionTrackingPageObjects
						.Dates_Verify(FDE_SubmissionTrackingPageObjects.IA_dateInformedToDistributor));

		Reports.ExtentReportLog("", Status.INFO, "Verified dates : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in text field value
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 17-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyData(String object, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorClick(object);
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, columnName), object);
			Reports.ExtentReportLog("", Status.INFO, "Data verification : Scenario Name::" + scenarioName, true);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Reporter info and authority
	 *             in submission tracking IA
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 17-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyReporterInfo_authority(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.verifyRadioButton(FDE_SubmissionTrackingPageObjects.ReporterInfo_AuthRadiobtn,
				getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_ReporterInf_Authority"));
		CommonOperations.verifyRadioButton(
				FDE_SubmissionTrackingPageObjects
						.setReportNull_Amendment(FDE_SubmissionTrackingPageObjects.NullficationLabel),
				getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Repfor_Nullification_Amendment"));
		Reports.ExtentReportLog("", Status.INFO, "Verified reporter info autority : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Followup checkboxes in
	 *             submission tracking IA
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 17-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyFollowup_checkBox(String scenarioName) {
		CommonOperations.verifyCheckBoxUnder(
				FDE_SubmissionTrackingPageObjects
						.followup_Checkbox(FDE_SubmissionTrackingPageObjects.Followup_Correction),
				getTestDataCellValue(scenarioName, "Distribute_Subtracking_IA_Followup_Correction"));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download Distributed conditions
	 *             report to excel.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 12-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void exportDistributionConditionsReport(String FileName) {
		agIsVisible(FDEMoreOptionsPageObjects.moreActionHover);
		agMouseHover(FDEMoreOptionsPageObjects.moreActionHover);
		agSetStepExecutionDelay("3000");
		agClick(FDEMoreOptionsPageObjects.moreAction("Distribution Conditions Report"));
		agWaitTillVisibilityOfElement(FDE_SubmissionTrackingPageObjects.refresh_Btn);
		agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);
		agWaitTillInvisibilityOfElement(FDE_SubmissionTrackingPageObjects.filterSpinner);
		agSetStepExecutionDelay("15000");
		CommonOperations.move_Downloadedexcel(FileName);
		Reports.ExtentReportLog("Distribution Conditions Report downloaded successfully", Status.INFO, "", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is used to verify excel count and paginator
	 *             counts.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 16-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void DistributionLogsCountVerification(String filePath) {

		XlsReader xls = new XlsReader(filePath);
		// int startNo = xls.getCellRowNum("Sheet1", "Status","Successful Anchor Logs");
		int endNo = xls.getCellRowNum("Sheet1", "Status", "Failure Anchor Logs");

		int valCount = 0;

		for (int i = 2; i < endNo; i++) {

			String value = xls.getCellData("Sheet1", 2, i);

			if (value.length() > 0) {

				System.out.println(value);
				valCount++;
			}

			System.out.println("Total count: " + valCount);
		}

		String excelCount = Integer.toString(valCount);

		String GetPaginatore = agGetText(FDE_SubmissionTrackingPageObjects.distpaginator);
		String gridCount = "";
		gridCount = GetPaginatore.substring(9);

		if (excelCount.equals(gridCount)) {

			Reports.ExtentReportLog("Distribution Conditions Report counts matched. ", Status.PASS, "", true);
		} else {

			Reports.ExtentReportLog("Distribution Conditions Report counts are not matched. ", Status.FAIL, "", true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify distribution status in Submission
	 *             tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 12-Mar-2020
	 * @UpdatedByAndWhen:Yashwanth Naidu - 17-04-2020
	 **********************************************************************************************************/
	public static void verifySubmittedStatus(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		setDropDownValue(FDE_SubmissionTrackingPageObjects.contactName_Dropdown, scenarioName,
				"DistributionContactName");

		agAssertVisible(FDE_SubmissionTrackingPageObjects.submittedStatus_msg);
		status = agIsVisible(FDE_SubmissionTrackingPageObjects.submittedStatus_msg);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Status Verified successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Status not verified successfully", true);
		}

		CommonOperations.takeScreenShot();
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to click the IA.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 26-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void IA_click() {
		agSetStepExecutionDelay("5000");
		agJavaScriptExecuctorClick(FDE_SubmissionTrackingPageObjects.InformedAuthority_Label);
		agWaitTillVisibilityOfElement(FDE_SubmissionTrackingPageObjects.CaseVersion_Label);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify distributed contact Message
	 *             Submission tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 27-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyPassDistributionStatus() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		for (int i = 1; i < 10; i++) {
			agSetStepExecutionDelay("5000");
			agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);
			String Expectedmsg = agGetText(FDE_SubmissionTrackingPageObjects.listGenerated_msg);
			System.out.print(Expectedmsg);
			if (Expectedmsg.equals("Report Generation Successful")) {
				Reports.ExtentReportLog("", Status.PASS, "Report Generation Completed ", true);
				break;
			} else
				agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);

		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify distribution status in Submission
	 *             tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 20-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyContactStatus(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		for (int i = 1; i < 10; i++) {
			agSetStepExecutionDelay("5000");
			agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
			setDropDownValue(FDE_SubmissionTrackingPageObjects.contactName_Dropdown, scenarioName,
					"DistributionContactName");
			agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);
			status = agIsVisible(FDE_SubmissionTrackingPageObjects.distributionStatus_msg);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Status Verified successfully", true);
				break;
			} else {
				Reports.ExtentReportLog("", Status.PASS, "Status not verified successfully", true);
			}
			CommonOperations.takeScreenShot();
			agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify success distribution contact in
	 *             Submission tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 04-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyReportGenerationforEachContact(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		for (int i = 1; i < 10; i++) {
			agSetStepExecutionDelay("5000");
			agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);
			String Expectedmsg = agGetText(FDE_SubmissionTrackingPageObjects.listGenerated_msg);
			System.out.print(Expectedmsg);
			if (Expectedmsg.equals("Report Generation Successful")) {
				Reports.ExtentReportLog("", Status.PASS, "Report Generation Completed ", true);
				SubmissionOperations.VerificationofReportGenerationforEachContact(scenarioName,
						"DataAssessmentOperations", "AERNo");
				break;
			} else
				agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);

		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is Auto Contact Population
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 12-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void AutoContactPopulation() {

		// Storing Contact Names in an ArrayList
		ArrayList<String> Names = FDE_SubmissionTrackingOperation.GetContactListFromExcel();
		int count = Names.size() - 2;
		System.out.print(count);
		// loop to find contacts in each table and perform iterations if table doesnt
		// exist
		for (int i = 0; i < count; i++) {
			String Contact = Names.get(i);
			System.out.print(Contact);
			for (int j = 0; j < 9; j++) {
				if (agIsVisible(FDE_SubmissionTrackingPageObjects.ContactName(Contact)) == true) {
					System.out.print("Contact Exist");
					if (Contact == Names.get(i)) {
						Reports.ExtentReportLog("", Status.INFO, "Contact is Auto Populated", true);
						break;
					} else {
						Reports.ExtentReportLog("", Status.INFO, "Contact is not Auto Popluated", true);

					}
				}

				else {
					// click on next table if it could able to find in first table.
					if (agIsVisible(FDE_SubmissionTrackingPageObjects.NxtTableBtn)) {
						agClick(FDE_SubmissionTrackingPageObjects.NxtTableBtn);
					}

				}
			}
			// Moved back to first table.
			agClick(FDE_SubmissionTrackingPageObjects.FirstTable);

		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to set details informed authority details in
	 *             Submission tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 12-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setInformedAuthority(String scenarioName) {
		IA_click();
		setReportDetails_IA(scenarioName);
		setTextBox_IA(scenarioName);
		setFollowup_Checkbox_IA(scenarioName);
		setDatesDetails_IA(scenarioName);
		setReporter_authority(scenarioName);
		setReportingInfo_IA(scenarioName);
		setTextArea_IA(scenarioName);
		Save_IA();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to add local documents in Submission tracking
	 *             screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 12-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addLocalDocuments(String scenarioName) {
		/*
		 * if(agIsVisible(FDE_SubmissionTrackingPageObjects.DocumentCheckBox)==true) {
		 * agClick(FDE_SubmissionTrackingPageObjects.DeleteDocumentBtn);
		 * agIsVisible(FDE_SubmissionTrackingPageObjects.SubmissionConfirmMsg);
		 * agClick(FDE_SubmissionTrackingPageObjects.ConfirmationOkBtn);
		 * agIsVisible(FDE_SubmissionTrackingPageObjects.NoRecordFoundMsg);
		 * agSetValue(FDE_SubmissionTrackingPageObjects.AddDocument,""); }
		 */
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(FDE_SubmissionTrackingPageObjects.documents);
		CommonOperations.agwaitTillVisible(FDE_SubmissionTrackingPageObjects.DisDocheldbysender_label);
		String Filename = Multimaplibraries.getTestDataCellValue(scenarioName, "Filename");
		if (getTestDataCellValue(scenarioName, "AddLocalFiles").equalsIgnoreCase("true")) {
			agClick(FDE_SubmissionTrackingPageObjects.AddDocumentBtn);
			agSetStepExecutionDelay("6000");
			agUploadDocuments(lsmvConstants.LSMV_testDataInput + "\\" + getTestDataCellValue(scenarioName, "Filename"));
			agWaitTillInvisibilityOfElement(FDE_SubmissionTrackingPageObjects.loading);
			CommonOperations.takeScreenShot();
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify informed authority details in
	 *             Submission tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 12-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyInformedAuthority(String scenarioName) {
		IA_click();
		CommonOperations.agJavaScriptExecuctorClick(FDE_SubmissionTrackingPageObjects.InformedAuthority_Label);
		CommonOperations.agwaitTillVisible(FDE_SubmissionTrackingPageObjects.CaseVersion_Label);
		// FDE_SubmissionTrackingOperation.Reportdetails_Verification(scenarioName);
		verifyData(FDE_SubmissionTrackingPageObjects.setInputTextbox_IA("Authority/Partner ID"), scenarioName,
				"Distribute_Subtracking_IA_PartnerID");
		verifyData(FDE_SubmissionTrackingPageObjects.setInputTextbox_IA("Comments/Reason Text"), scenarioName,
				"Distribute_Subtracking_IA_Comments");
		verifyData(FDE_SubmissionTrackingPageObjects.setInputTextbox_IA("Acknowledgement Number"), scenarioName,
				"Distribute_Subtracking_IA_Ack_No");
		verifyData(FDE_SubmissionTrackingPageObjects.setInputTextbox_IA("Reference Number"), scenarioName,
				"Distribute_Subtracking_IA_Ref_No");
		verifyData(FDE_SubmissionTrackingPageObjects.setInputTextbox_IA("Follow-up No."), scenarioName,
				"Distribute_Subtracking_IA_Followup_No");
		Dates_Verification(scenarioName);
		verifyData(
				FDE_SubmissionTrackingPageObjects.setTextboxes(FDE_SubmissionTrackingPageObjects.sendersComments_label),
				scenarioName, "Distribute_Subtracking_IA_Senders_comments");
		verifyData(FDE_SubmissionTrackingPageObjects.setTextboxes(FDE_SubmissionTrackingPageObjects.EventDesc_label),
				scenarioName, "Distribute_Subtracking_IA_Event_Description");
		verifyData(FDE_SubmissionTrackingPageObjects.setTextboxes(FDE_SubmissionTrackingPageObjects.CaseSummary_label),
				scenarioName, "Distribute_Subtracking_IA_CaseSummary_Text");
		// FDE_SubmissionTrackingOperation.VerifyReporterInfo_authority(scenarioName);
		// FDE_SubmissionTrackingOperation.VerifyFollowup_checkBox(scenarioName);
	}

	public static void setMHLWTypeDropDown(String locator, String valueToSelect) {
		if (!valueToSelect.equalsIgnoreCase("#skip#")) {
			agSetStepExecutionDelay("2000");
			agClick(locator);
			agClick(FDE_SubmissionTrackingPageObjects.clickMHLWTypeDropDown(valueToSelect));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select distributed contact and
	 *             fill inform authority details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 15-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void selectDistributeContact(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		setDropDownValue(FDE_SubmissionTrackingPageObjects.contactName_Dropdown, scenarioName,
				"DistributionContactName");
		agClick(FDE_SubmissionTrackingPageObjects.selectDistributedContact);
		setMHLWTypeDropDown(FDE_SubmissionTrackingPageObjects.clickMHLWDropdown,
				getTestDataCellValue(scenarioName, "InformedAuthority_MHLW_ReportType"));
		agJavaScriptExecuctorClick(FDE_SubmissionTrackingPageObjects.completeRadioBtn);
		CommonOperations.takeScreenShot();
		FDE_SubmissionTrackingOperation.Save_IA();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify distribution status in Submission
	 *             tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 16-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySubmittedStatus(String scenarioName, String creationType) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		setDropDownValue(FDE_SubmissionTrackingPageObjects.contactName_Dropdown, scenarioName,
				"DistributionContactName");

		if (creationType.equalsIgnoreCase("JapanFDE") || creationType.equalsIgnoreCase("JapanDomWF")) {
			agAssertVisible(FDE_SubmissionTrackingPageObjects.distributedcontactstatus);
			status = agIsVisible(FDE_SubmissionTrackingPageObjects.distributedcontactstatus);
		} else {
			agAssertVisible(FDE_SubmissionTrackingPageObjects.submittedStatus_msg);
			status = agIsVisible(FDE_SubmissionTrackingPageObjects.submittedStatus_msg);
		}
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Status Verified successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Status not verified successfully", true);
		}

		CommonOperations.takeScreenShot();
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify nullification icon in
	 *             submission contacts
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 12-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyNullificationIcon() {
		// Storing Contact Names in an ArrayList
		ArrayList<String> Names = FDE_SubmissionTrackingOperation.GetContactListFromExcel();
		int count = Names.size();
		System.out.print(count);
		// loop to find contacts in each table and perform iterations if table doesnt
		// exist
		for (int i = 0; i < count; i++) {
			String Contact = Names.get(i);
			System.out.print(Contact);
			for (int j = 0; j < 9; j++) {
				if (agIsVisible(FDE_SubmissionTrackingPageObjects.ContactName(Contact)) == true) {
					System.out.print("Contact Exist");
					if (Contact == Names.get(i)) {

						status = agIsVisible(FDE_SubmissionTrackingPageObjects.checkNullificationIcon(Contact));
						if (status) {
							Reports.ExtentReportLog("", Status.INFO, "Nullification Icon is visible", true);
							break;
						} else {
							Reports.ExtentReportLog("", Status.INFO, "Nullification Icon is not visible", true);
							break;
						}

					} else {

						Reports.ExtentReportLog("", Status.INFO, "Contact is not Auto Popluated", true);
					}
				}

				else {
					// click on next table if it could able to find in first table.
					if (agIsVisible(FDE_SubmissionTrackingPageObjects.NxtTableBtn)) {
						agClick(FDE_SubmissionTrackingPageObjects.NxtTableBtn);
					}

				}
			}
			// Moved back to first table.
			agClick(FDE_SubmissionTrackingPageObjects.FirstTable);

		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify all the fields in IA screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 12-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verificationInInformedAuthority(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		FDE_SubmissionTrackingOperation.verifyData(
				FDE_SubmissionTrackingPageObjects
						.setInputTextbox_IA(FDE_SubmissionTrackingPageObjects.IA_commentsReasonLabel),
				scenarioName, "Distribute_Subtracking_IA_Comments");
		FDE_SubmissionTrackingOperation.verifyData(
				FDE_SubmissionTrackingPageObjects.setInputTextbox_IA(FDE_SubmissionTrackingPageObjects.IA_AckNoLabel),
				scenarioName, "Distribute_Subtracking_IA_Ack_No");
		FDE_SubmissionTrackingOperation.verifyData(
				FDE_SubmissionTrackingPageObjects.setInputTextbox_IA(FDE_SubmissionTrackingPageObjects.IA_RefNoLabel),
				scenarioName, "Distribute_Subtracking_IA_Ref_No");
		FDE_SubmissionTrackingOperation.verifyData(
				FDE_SubmissionTrackingPageObjects.setInputTextbox_IA(FDE_SubmissionTrackingPageObjects.IA_FollowupNo),
				scenarioName, "Distribute_Subtracking_IA_Followup_No");
		FDE_SubmissionTrackingOperation.Dates_Verification(scenarioName);
		FDE_SubmissionTrackingOperation.verifyData(
				FDE_SubmissionTrackingPageObjects.setTextboxes(FDE_SubmissionTrackingPageObjects.sendersComments_label),
				scenarioName, "Distribute_Subtracking_IA_Senders_comments");
		FDE_SubmissionTrackingOperation.verifyData(
				FDE_SubmissionTrackingPageObjects.setTextboxes(FDE_SubmissionTrackingPageObjects.EventDesc_label),
				scenarioName, "Distribute_Subtracking_IA_Event_Description");
		// FDE_SubmissionTrackingOperation.verifyData(
		// FDE_SubmissionTrackingPageObjects.setTextboxes(FDE_SubmissionTrackingPageObjects.CaseSummary_label),
		// scenarioName, "Distribute_Subtracking_IA_CaseSummary_Text");
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify view proposed distribution contacts
	 *             in more actions Submission tracking screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 21-October-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyViewProposedContactList(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("View Proposed Distribution Contacts "));
		agSetStepExecutionDelay("5000");
		agSetValue(FDE_SubmissionTrackingPageObjects.searchTextBox,
				getTestDataCellValue(scenarioName, "DistributionContactName"));
		agClick(FDE_SubmissionTrackingPageObjects.SearchIcon);
		agAssertVisible(FDE_SubmissionTrackingPageObjects.listofProposedGenerated_msg);
		if (agIsExists(FDE_SubmissionTrackingPageObjects.listofProposedGenerated_msg)) {
			Reports.ExtentReportLog("", Status.PASS, "Manual Contact is not Displayed in View Proposed Contact List ",
					true);
			System.out.print("Contact does not Exist");
		} else {
			System.out.print("Contact Exists");
			Reports.ExtentReportLog("", Status.FAIL, "Contact Exist", true);
		}
		agClick(FDE_SubmissionTrackingPageObjects.close_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify Deleting already distributed manual
	 *             contacts in a case. 
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 22-October-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDeletingDistributedContact(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		for (int i = 1; i < 10; i++) {
			agSetStepExecutionDelay("5000");
			agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
			setDropDownValue(FDE_SubmissionTrackingPageObjects.contactName_Dropdown, scenarioName,
					"DistributionContactName");
			agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);
			status = agIsVisible(FDE_SubmissionTrackingPageObjects.distributionStatus_msg);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Status Verified successfully", true);
				break;
			} else {
				Reports.ExtentReportLog("", Status.PASS, "Status not verified successfully", true);
			}
			CommonOperations.takeScreenShot();
		}
		agSetValue(FDE_SubmissionTrackingPageObjects.removalReason_txt,
				getTestDataCellValue(scenarioName, "Distribute_SubTracking_Removal_Reason"));
		agClick(FDE_SubmissionTrackingPageObjects.listSelect_checkbox);
		Reports.ExtentReportLog("", Status.INFO, "Contact is Selected", true);
		agClick(FDE_SubmissionTrackingPageObjects.DropDeleteBtn);
		CommonOperations.takeScreenShot();
		agIsVisible(FDE_SubmissionTrackingPageObjects.deleteValidationMsg);
		Reports.ExtentReportLog("", Status.PASS, "Already Distributed Contact cannot be deleted", true);
		agClick(FDE_SubmissionTrackingPageObjects.deleteValidationClose);
		agMouseHover(FDE_SubmissionTrackingPageObjects.cancelHover);
		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is verify a distribution contact in Submission
	 *             tracking screen is selected.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 22-October-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean isDistributionContactAdded(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		boolean isContactSelected = false;
		agSetStepExecutionDelay("5000");
		if (!agIsVisible(FDE_SubmissionTrackingPageObjects.clickdropdown("Contact Name"))) {
			agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		}

		agClick(FDE_SubmissionTrackingPageObjects.clickdropdown("Contact Name"));
		agSetStepExecutionDelay("2000");
		agClick(FDE_SubmissionTrackingPageObjects.clickdropdown("Contact Name"));
		agSetStepExecutionDelay("2000");
		agClick(FDE_SubmissionTrackingPageObjects.clickdropdown("Contact Name"));
		agSetStepExecutionDelay("2000");

		// setDropDownValue(FDE_SubmissionTrackingPageObjects.contactName_Dropdown,
		// scenarioName,"DistributionContactName");

		isContactSelected = agIsVisible(FDE_SubmissionTrackingPageObjects
				.selectDropdownvalue(getTestDataCellValue(scenarioName, "DistributionContactName")));
		System.out.println("isContactSelected =" + isContactSelected);
		// agIsVisible(FDE_SubmissionTrackingPageObjects.NoRecordFoundMsg);
		// CommonOperations.takeScreenShot();

		if (isContactSelected) {
			agSetStepExecutionDelay("3000");
			agClick(FDE_SubmissionTrackingPageObjects
					.selectDropdownvalue(getTestDataCellValue(scenarioName, "DistributionContactName")));
			agSetStepExecutionDelay("5000");
			agWaitTillVisibilityOfElement(FDE_SubmissionTrackingPageObjects.distpaginator);
			agGetText(FDE_SubmissionTrackingPageObjects.distpaginator);
			Reports.ExtentReportLog("", Status.PASS, "", true);
			Reports.ExtentReportLog("List of Distribution Contacts", Status.INFO,
					"Distribution Contact is selected already", false);
			isContactSelected = true;
		} else {
			Reports.ExtentReportLog("List of Distribution Contacts", Status.INFO,
					"Distribution Contact not selected yet", true);
		}

		agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		return isContactSelected;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is verify a distribution contact in Submission
	 *             tracking screen is selected.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 22-October-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addDuplicateDistributionContact(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (isDistributionContactAdded(scenarioName) == false) {
			addDistributionContact(scenarioName);
			agSetStepExecutionDelay("3000");
			agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
			isDistributionContactAdded(scenarioName);
		}

		agClick(FDE_SubmissionTrackingPageObjects.AddDistContact_Btn);
		agSetStepExecutionDelay("3000");

		agSetValue(FDE_SubmissionTrackingPageObjects.Contact_Textbox,
				getTestDataCellValue(scenarioName, "Distribute_SubTracking_DistContLookUp_Contact"));
		agSetValue(FDE_SubmissionTrackingPageObjects.ReportFormat_Textbox,
				getTestDataCellValue(scenarioName, "Distribute_SubTracking_DistContLookUp_ReportFormatName"));
		Reports.ExtentReportLog("", Status.PASS, "Contact Details entered", true);
		agClick(FDE_SubmissionTrackingPageObjects.searchContact_Btn);
		agSetStepExecutionDelay("3000");

		if (agIsVisible(FDE_SubmissionTrackingPageObjects.selectContact_Chkbox)) {
			agClick(FDE_SubmissionTrackingPageObjects.selectContact_Chkbox);
			Reports.ExtentReportLog("", Status.FAIL, "Contact available for selection", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS, "Contact not available for selection", true);
		}

		agClick(FDE_SubmissionTrackingPageObjects.cancelContact_Btn);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify the case documents/local documents
	 *             in submission tracking screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 18-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void documentsVerification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(FDE_SubmissionTrackingPageObjects.linkText(getTestDataCellValue(scenarioName, "Filename")));
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseDocumentsOperations");
		agAssertVisible(FDE_SubmissionTrackingPageObjects.linkText(getTestDataCellValue(scenarioName, "Filename")));
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify the document included for the case
	 *             documentsand adding the case/local documents for distribution
	 *             contact in submission tracking IA screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDocumentIncluded(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "BoolDistributionContact").equalsIgnoreCase("true")) {
			String contact = getTestDataCellValue(scenarioName, "DistributionContactName");
			String[] totalRecords = contact.split(",");
			agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
			for (int i = 0; i < totalRecords.length; i++) {
				agSetStepExecutionDelay("5000");
				setDistributionContact(FDE_SubmissionTrackingPageObjects.contactName_Dropdown, scenarioName,
						"DistributionContactName", totalRecords[i]);
				CommonOperations.takeScreenShot();
				agAssertVisible(FDE_SubmissionTrackingPageObjects.ContactName(totalRecords[i]));
				agClick(FDE_SubmissionTrackingPageObjects.DistributionContact(totalRecords[i]));
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

				FDE_SubmissionTrackingOperation.IA_DocumentsClick();
				FDE_SubmissionTrackingOperation.AddCase_Documents();
				FDE_SubmissionTrackingOperation.AddDeleteLocalDocuments(scenarioName);
				// FDE_SubmissionTrackingOperation.documentsVerification(scenarioName);
				FDE_SubmissionTrackingOperation.DocumentVerification(scenarioName);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to click the documents tab in IA screen.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void IA_DocumentsClick() {
		agSetStepExecutionDelay("5000");
		agJavaScriptExecuctorClick(FDE_SubmissionTrackingPageObjects.documents);
		CommonOperations.agwaitTillVisible(FDE_SubmissionTrackingPageObjects.DisDocheldbysender_label);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to used to verify the document included is
	 *             yes/no
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void DocumentVerification(String scenarioName) {
		agSetStepExecutionDelay("5000");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseDocumentsOperations");
		String caseDoc = FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "Filename");

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String fileName = FDE_SubmissionTrackingOperation.getTestDataCellValue(scenarioName, "Filename");
		String data = FDE_SubmissionTrackingOperation.getTestDataCellValue(scenarioName, "DocumentIncluded");

		List<WebElement> document = agGetElementList(FDE_SubmissionTrackingPageObjects.docNameList);
		for (int i = 0; i < document.size(); i++) {
			String file = agGetText(FDE_SubmissionTrackingPageObjects.columnHeader(Integer.toString(i + 1)));
			String docInclude = agGetText(FDE_SubmissionTrackingPageObjects.docIncluded(Integer.toString(i + 1)));
			if (file.equalsIgnoreCase(fileName)) {
				Reports.ExtentReportLog("", Status.PASS, "Filename matched " + file, true);
				if (data.equalsIgnoreCase(docInclude)) {
					Reports.ExtentReportLog("", Status.PASS, "Document included is set to Yes " + file, true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Document included is not set" + file, true);
				}

			}

			else if (file.equalsIgnoreCase(caseDoc)) {
				Reports.ExtentReportLog("", Status.PASS, "Filename matched " + file, true);
				if (data.equalsIgnoreCase(docInclude)) {
					Reports.ExtentReportLog("", Status.PASS, "Document included is set to Yes " + file, true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Document included is not set" + file, true);
				}

			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Filename not matched " + file, true);
			}
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value for the
	 *             distribution contact by passing the column name values
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 20-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDistributionContact(String label, String scenarioName, String columnName, String value) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_SubmissionTrackingPageObjects.clickdropdown(label));
			agSetStepExecutionDelay("4000");
			agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);
			agClick(FDE_SubmissionTrackingPageObjects.clickdropdown(label));
			agClick(FDE_SubmissionTrackingPageObjects.selectDropdownvalue(value));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify event description fro
	 *             contact in submission tracking screen
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyEventDescription(String eventDescNarrative) {
		agSetStepExecutionDelay("4000");
		agJavaScriptExecuctorScrollToElement(FDE_SubmissionTrackingPageObjects.localNarrativeLabel);
		agClick(FDE_SubmissionTrackingPageObjects.eventDesc);
		String eventDesc = agGetAttribute("value", FDE_SubmissionTrackingPageObjects.eventDesc);
		if (eventDescNarrative.equalsIgnoreCase(eventDesc)) {
			Reports.ExtentReportLog("", Status.PASS, "Event description matches", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Event description not matches", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: Filter the list based on contact name and select the record.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 22-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void selectRecordOnContactName(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (agIsVisible(FDE_SubmissionTrackingPageObjects.clickdropdown("Contact Name")) == false) {
			System.out.println("drop down not selected");
			agClick(FDE_SubmissionTrackingPageObjects.filter_Btn);
		}

		// clicking on drop down 3 times due to app limitation
		agClick(FDE_SubmissionTrackingPageObjects.clickdropdown("Contact Name"));
		agSetStepExecutionDelay("2000");
		agClick(FDE_SubmissionTrackingPageObjects.clickdropdown("Contact Name"));
		agSetStepExecutionDelay("2000");
		agClick(FDE_SubmissionTrackingPageObjects.clickdropdown("Contact Name"));
		agSetStepExecutionDelay("2000");

		agClick(FDE_SubmissionTrackingPageObjects
				.selectDropdownvalue(getTestDataCellValue(scenarioName, "DistributionContactName")));

		agWaitTillVisibilityOfElement(FDE_SubmissionTrackingPageObjects.paginator);
		if (agGetText(FDE_SubmissionTrackingPageObjects.recCount).startsWith("1")
				&& agGetText(FDE_SubmissionTrackingPageObjects.recCount).endsWith("1")) {
			agWaitTillVisibilityOfElement(FDE_SubmissionTrackingPageObjects.listSelect_checkbox);
			agClick(FDE_SubmissionTrackingPageObjects.listSelect_checkbox);
			Reports.ExtentReportLog("", Status.INFO, "Selected a Record", true);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "More than one record displayed, No record selected", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: To click on any of the buttons displayed on hovering More Actions
	 *             button.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 22-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void performMoreActions(String action) {
		agMouseHover(FDE_SubmissionTrackingPageObjects.moreOptionsHover);

		if (action.equalsIgnoreCase("Redistribute")) {
			agClick(FDE_SubmissionTrackingPageObjects.moreActions("Redistribute"));
			agSetStepExecutionDelay("3000");
			Reports.ExtentReportLog("", Status.INFO, action + " action performed successfully", true);
		} else if (action.equalsIgnoreCase("Redistribute(R)")) {
			agClick(FDE_SubmissionTrackingPageObjects.moreActions("Redistribute(R)"));
			agSetStepExecutionDelay("3000");
			Reports.ExtentReportLog("", Status.PASS, "", true);
			Reports.ExtentReportLog("", Status.INFO, action + " action performed successfully", true);
		} else if (action.equalsIgnoreCase("Distribution Conditions Report")) {
			agClick(FDE_SubmissionTrackingPageObjects.moreActions("Distribution Conditions Report"));
			agSetStepExecutionDelay("3000");
			Reports.ExtentReportLog("", Status.INFO, action + " action performed successfully", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: To click on any of the buttons displayed on hovering More Actions
	 *             button.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 22-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void redistributeRContact(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		selectRecordOnContactName(scenarioName);
		performMoreActions("Redistribute(R)");

		if (agIsExists(FDE_SubmissionTrackingPageObjects.redistPlaced_label)) {
			Reports.ExtentReportLog("", Status.INFO, agGetText(FDE_SubmissionTrackingPageObjects.redistPlaced_label),
					false);
			agClick(FDE_SubmissionTrackingPageObjects.redistPlaced_Ok);
		}

		else {
			Reports.ExtentReportLog("", Status.INFO, agGetText(FDE_SubmissionTrackingPageObjects.moreAct_errorMessage),
					true);
		}

		Reports.ExtentReportLog("", Status.PASS, "", true);
	}
}
