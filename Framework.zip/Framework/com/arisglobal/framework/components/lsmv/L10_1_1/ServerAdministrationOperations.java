package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AdministrationPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ServerAdministrationPageObjects;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.aventstack.extentreports.Status;

public class ServerAdministrationOperations extends ToolManager{
	public static WebElement webElement;
	static String className = ServerAdministrationOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	
	
	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in Server administration
	 * @InputParameters: pageObject
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void menuNavigation(String pageObject) {
		
		agMouseHover(AdministrationPageObjects.administrationHover);
		agClick(pageObject);
	}
	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in
	 * Administration > Server administration and verify the label name.
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void serverAdministrationNavigations(String menu) {
			switch (menu) {
			case "alerts":
				menuNavigation(ServerAdministrationPageObjects.alertsLink);
				status = agIsVisible(ServerAdministrationPageObjects.alertsLabel);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to alerts is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to alerts is Unsuccessfull", true);
				}
				break;
			case "logs":
				menuNavigation(ServerAdministrationPageObjects.logsLink);
				status = agIsVisible(ServerAdministrationPageObjects.logsLabel);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to logs is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to logs is Unsuccessfull", true);
				}
				break;
				
			case "lDAP":
				menuNavigation(ServerAdministrationPageObjects.lDAPLink);
				status = agIsVisible(ServerAdministrationPageObjects.lDAPKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to lDAP is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to lDAP is Unsuccessfull", true);
				}
				break;
				
			case "faxServer":
				menuNavigation(ServerAdministrationPageObjects.faxServerLink);
				status = agIsVisible(ServerAdministrationPageObjects.FaxServerKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to faxServer is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to faxServer is Unsuccessfull", true);
				}
				break;
			case "mailServer":
				menuNavigation(ServerAdministrationPageObjects.mailServerLink);
				status = agIsVisible(ServerAdministrationPageObjects.mailServerLabel);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to mail Server is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to mail Server is Unsuccessfull", true);
				}
				break;
			case "schedulers":
				menuNavigation(ServerAdministrationPageObjects.SchedulersLink);
				status = agIsVisible(ServerAdministrationPageObjects.SchedulersLabel);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to schedulers is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to schedulers is Unsuccessfull", true);
				}
				break;
			default:
				System.out.println("Invalid Menu Link!");
			}

	}
}