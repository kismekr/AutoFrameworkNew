package com.arisglobal.framework.components.lsmv.L10_1_1;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AdministrationDepartmentPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AdministrationDepartment extends ToolManager {

	static String className = AdministrationDepartment.class.getSimpleName();

	public static void setDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_GeneralPageObjects.selectGeneralDroprdown(label));
			agClick(FDE_GeneralPageObjects.clickDropDownValue(getTestDataCellValue(scenarioName, columnName)));

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Department.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 24-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean searchDepartment(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(AdministrationDepartmentPageObjects.keywordSearchTextbox,
				getTestDataCellValue(scenarioName, "Search Text"));
		agClick(AdministrationDepartmentPageObjects.keywordSearchButton);
		agSetStepExecutionDelay("2000");
		CommonOperations.takeScreenShot();
		String paginator = agGetText(AdministrationDepartmentPageObjects.paginator);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.PASS,
					"Search Result with '" + getTestDataCellValue(scenarioName, "Search Text") + "' exists!", true);
			return true;
		} else
			return false;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Edit Searched Administration >>
	 *             Department.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 04-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void editDepartment() {
		agClick(AdministrationDepartmentPageObjects.editIcon);
		agAssertVisible(AdministrationDepartmentPageObjects.deptNameTextbox);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create Department.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 24-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createDepartment(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(AdministrationDepartmentPageObjects.newButton);
		setDepartment(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Department data.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 24-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDepartment(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(AdministrationDepartmentPageObjects.deptNameTextbox,
				getTestDataCellValue(scenarioName, "Department Name"));
		agSetValue(AdministrationDepartmentPageObjects.contactPersonTextbox,
				getTestDataCellValue(scenarioName, "Contact Person"));
		agSetValue(AdministrationDepartmentPageObjects.phoneCountryCodeTextbox,
				getTestDataCellValue(scenarioName, "Phone Country Code"));
		agSetValue(AdministrationDepartmentPageObjects.phoneAredCodeTextbox,
				getTestDataCellValue(scenarioName, "Phone Area Code"));
		agSetValue(AdministrationDepartmentPageObjects.phoneNoTextbox,
				getTestDataCellValue(scenarioName, "Phone Number"));
		agSetValue(AdministrationDepartmentPageObjects.faxCountryCodeTextbox,
				getTestDataCellValue(scenarioName, "Fax Country Code"));
		agSetValue(AdministrationDepartmentPageObjects.faxAreaCodeTextbox,
				getTestDataCellValue(scenarioName, "Fax Area Code"));
		agSetValue(AdministrationDepartmentPageObjects.faxNoTextbox, getTestDataCellValue(scenarioName, "Fax Number"));
		agSetValue(AdministrationDepartmentPageObjects.emailIDTextbox, getTestDataCellValue(scenarioName, "Email ID"));
		CommonOperations.clickCheckBoxLeftOf("Report Notifications",
				getTestDataCellValue(scenarioName, "Bool Report Notification"));
		if (getTestDataCellValue(scenarioName, "Bool Report Notification").equalsIgnoreCase("true")) {
			CommonOperations.clickCheckBoxLeftOf("Source Document",
					getTestDataCellValue(scenarioName, "Bool Source Document"));
			CommonOperations.clickCheckBoxLeftOf("Support Document",
					getTestDataCellValue(scenarioName, "Bool Support Document"));
			CommonOperations.clickCheckBoxLeftOf("Case Summary Sheet",
					getTestDataCellValue(scenarioName, "Bool Case Summary Sheet"));
			CommonOperations.clickCheckBoxLeftOf("E2B XML", getTestDataCellValue(scenarioName, "Bool E2B XML"));
		}
		setDropDownValue(AdministrationDepartmentPageObjects.corresMailServerDropdown, scenarioName,
				"Correspondence Mail Servers");
		CommonOperations.takeScreenShot();
		agClick(AdministrationDepartmentPageObjects.saveButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Administration >>
	 *             Department.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 24-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreateDepartment(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		boolean searchResults = searchDepartment(scenarioName);
		if (searchResults == false) {
			createDepartment(scenarioName);
			CommonOperations.setAuditInfo("Create_Department");
			searchAndVerifyDepartment(scenarioName);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Search and Verify Administration
	 *             >> Department.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 24-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndVerifyDepartment(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		boolean searchResults = searchDepartment(scenarioName);
		if (searchResults == true) {
			editDepartment();
			verifyDepartment(scenarioName);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Search Result with '" + getTestDataCellValue(scenarioName, "Search Text") + "' is not found",
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Search and Updated Administration
	 *             >> Department.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 24-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndUpdateDepartment(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		boolean searchResults = searchDepartment(scenarioName);
		if (searchResults == true) {
			editDepartment();
			setDepartment(scenarioName);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit and delete department.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh S
	 * @Date : 04-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndDeleteDepartment(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		boolean searchResults = searchDepartment(scenarioName);
		if (searchResults) {
			agClick(CommonPageObjects.selectListingCheckbox(getTestDataCellValue(scenarioName, "Search Text")));
			agClick(AdministrationDepartmentPageObjects.deleteButton);
			CommonOperations.setDepartmentDeleteAuditInfo("Delete_Department");
		}
		boolean deleteSearchResults = searchDepartment(scenarioName);
		if (deleteSearchResults) {
			Reports.ExtentReportLog("", Status.FAIL,
					"Department with name " + getTestDataCellValue(scenarioName, "Search Text") + " is not deleted",
					true);
		} else {
			Reports.ExtentReportLog("", Status.PASS,
					"Department with name " + getTestDataCellValue(scenarioName, "Search Text") + " is deleted", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit and verify department.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh S
	 * @Date : 25-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDepartment(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(AdministrationDepartmentPageObjects.deptNameTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Department Name"),
				AdministrationDepartmentPageObjects.deptNameTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Contact Person"),
				AdministrationDepartmentPageObjects.contactPersonTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Phone Country Code"),
				AdministrationDepartmentPageObjects.phoneCountryCodeTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Phone Area Code"),
				AdministrationDepartmentPageObjects.phoneAredCodeTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Phone Number"),
				AdministrationDepartmentPageObjects.phoneNoTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Fax Country Code"),
				AdministrationDepartmentPageObjects.faxCountryCodeTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Fax Area Code"),
				AdministrationDepartmentPageObjects.faxAreaCodeTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Fax Number"),
				AdministrationDepartmentPageObjects.faxNoTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Email ID"),
				AdministrationDepartmentPageObjects.emailIDTextbox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Correspondence Mail Servers"),
				AdministrationDepartmentPageObjects.corresMailServerDropdown);
		CommonOperations.verifyCheckBoxLeftOf("Report Notifications",
				getTestDataCellValue(scenarioName, "Bool Report Notification"));
		if (getTestDataCellValue(scenarioName, "Bool Report Notification").equalsIgnoreCase("true")) {
			CommonOperations.verifyCheckBoxLeftOf("Source Document",
					getTestDataCellValue(scenarioName, "Bool Source Document"));
			CommonOperations.verifyCheckBoxLeftOf("Support Document",
					getTestDataCellValue(scenarioName, "Bool Support Document"));
			CommonOperations.verifyCheckBoxLeftOf("Case Summary Sheet",
					getTestDataCellValue(scenarioName, "Bool Case Summary Sheet"));
			CommonOperations.verifyCheckBoxLeftOf("E2B XML", getTestDataCellValue(scenarioName, "Bool E2B XML"));
		}
		CommonOperations.takeScreenShot();
		agClick(AdministrationDepartmentPageObjects.cancelButton);
		agIsVisible(AdministrationDepartmentPageObjects.keywordSearchTextbox);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to generate and verify record count
	 *             for Department.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh S
	 * @Date : 25-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void generateAndVerifyDepartmentData(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		exportDepartmentData(scenarioName);
		String filePath = lsmvConstants.path + "\\" + getTestDataCellValue(scenarioName, "GeneratedFileName");
		recordCountVerification(filePath);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Export Operations on
	 *             Department Listing Screen data.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh S
	 * @Date : 25-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportDepartmentData(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(AdministrationDepartmentPageObjects.downloadIcon);
		agJavaScriptExecuctorClick(
				CommonPageObjects.selectExportType(getTestDataCellValue(scenarioName, "ExportType")));
		agWaitTillVisibilityOfElement(AdministrationDepartmentPageObjects.export_Btn);
		if (agIsVisible(AdministrationDepartmentPageObjects.export_Btn) == true) {
			CommonOperations.clickCheckBoxLeftOf("Department Name",
					getTestDataCellValue(scenarioName, "Check Department Name Column"));
			CommonOperations.clickCheckBoxLeftOf("Contact Person",
					getTestDataCellValue(scenarioName, "Check Contact Person Column"));
			CommonOperations.clickCheckBoxLeftOf("Phone", getTestDataCellValue(scenarioName, "Check Phone Column"));
			CommonOperations.clickCheckBoxLeftOf("E-mail ID",
					getTestDataCellValue(scenarioName, "Check E-mail ID Column"));
			CommonOperations.clickCheckBoxLeftOf("Correspondence Mail Servers",
					getTestDataCellValue(scenarioName, "Check Correspondence Mail Servers Column"));
			CommonOperations.takeScreenShot();
			agJavaScriptExecuctorClick(AdministrationDepartmentPageObjects.export_Btn);
			CommonOperations.save_GeneratedReport(getTestDataCellValue(scenarioName, "GeneratedFileName"));
			/*
			 * try { Thread.sleep(8000); } catch (InterruptedException e) {
			 * e.printStackTrace(); }
			 * CommonOperations.save_GeneratedReport(getTestDataCellValue(scenarioName,
			 * "GeneratedFileName"));
			 */
			agClick(AdministrationDepartmentPageObjects.exportCancel_Btn);
		} else {
			Reports.ExtentReportLog("Export Pop up is not displayed", Status.INFO, "", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to compare record count in listing
	 *             screen with download excel
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void recordCountVerification(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		String count = xls.getCellData("Department", 2, 4);
		String[] Totalcount = count.split(":");
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in exported excel::" + Totalcount[1].trim(),
				false);
		String applrecordcount = agGetText(AdministrationDepartmentPageObjects.paginator);
		String[] data = applrecordcount.split(" ");
		String recordCount = data[4];
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in application::" + recordCount, false);
		if (recordCount.equalsIgnoreCase(Totalcount[1].trim())) {
			Reports.ExtentReportLog("", Status.PASS, "Record count verification is successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Record count verification is Unsuccessfull", true);
		}
	}
}
