package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;
import org.openqa.selenium.WebElement;

import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.aventstack.extentreports.Status;

public class PDFOperations extends Multimaplibraries {
	public static WebElement webElement;
	static String className = PDFOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	
	/**********************************************************************************************************
	 * @Objective: The below method is created for PDF verification for data visible
	 * @InputParameters: path, data
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void pdfverificationForVisible(String path, String data) {

		PDDocument pd;
		try {
			pd = PDDocument.load(new File(path));
			PDFTextStripper pdf = new PDFTextStripper();
			status = (pdf.getText(pd).contains(data));
			if (status) {
				Reports.ExtentReportLog("PDF Report Verification Is Successfull", Status.PASS,
						"'" + data + "' validation in PDF report is successfull", false);
			} else {
				Reports.ExtentReportLog("PDF Report Verification Is Unsuccessfull", Status.FAIL,
						"'" + data + "' validation in PDF report is Unsuccessfull ", false);
			}
		} catch (InvalidPasswordException e) {
			
			Reports.ExtentReportLog("Pdf not downloaded :", Status.FAIL,e.getMessage(), true);
		} catch (IOException e) {
			Reports.ExtentReportLog("Pdf not downloaded :", Status.FAIL,e.getMessage(), true);
		}

	}
	/**********************************************************************************************************
	 * @Objective: The below method is created for PDF verification for data not visible
	 * @InputParameters: path, data
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void pdfverificationForNotVisible(String path, String data) {

		PDDocument pd;
		try {
			pd = PDDocument.load(new File(path));
			PDFTextStripper pdf = new PDFTextStripper();
			status = (pdf.getText(pd).contains(data));
			if (status) {
				Reports.ExtentReportLog("PDF Report Verification Is Unsuccessfull", Status.FAIL,
						"'" + data + "' is Visible in PDF Report", false);
			} else {
				Reports.ExtentReportLog("PDF Report Verification Is Successfull", Status.PASS,
						"'" + data + "' is Not Visible in PDF Report", false);
			}
		} catch (InvalidPasswordException e) {
			
			Reports.ExtentReportLog("Pdf not downloaded :", Status.FAIL,e.getMessage(), true);
		} catch (IOException e) {
			Reports.ExtentReportLog("Pdf not downloaded :", Status.FAIL,e.getMessage(), true);
		}

	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to Check whether file is downloaded or not based on extension
	 * @InputParameters: dirPath, ext
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static boolean isFileDownloaded_Ext(String dirPath, String ext) {
		boolean flag = false;
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			flag = false;
		}

		for (int i = 1; i < files.length; i++) {
			if (files[i].getName().contains(ext)) {
				flag = true;
			}
		}
		return flag;
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Check whether file is downloaded or not based on file name
	 * @InputParameters: downloadPath, fileName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean isFileDownloaded(String downloadPath, String fileName) {
		boolean flag = false;
	    File dir = new File(downloadPath);
	    File[] dir_contents = dir.listFiles();
	  	    
	    for (int i = 0; i < dir_contents.length; i++) {
	        if (dir_contents[i].getName().equals(fileName))
	            return flag=true;
	            }

	    return flag;
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created for PDF verification
	 * @InputParameters: path, data
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 05-Aug-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void pdfDataverification(String path, String data) {

		PDDocument pd;
		try {
			pd = PDDocument.load(new File(path));
			PDFTextStripper pdf = new PDFTextStripper();
			status = (pdf.getText(pd).contains(data));
			if (status) {
				Reports.ExtentReportLog("", Status.INFO,
						"The reports are generated and printing of labeling records are verified.", false);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"The reports are generated and printing of labeling records are not verified.", false);
			}
		} catch (InvalidPasswordException e) {
			
			Reports.ExtentReportLog("Pdf not downloaded :", Status.FAIL,e.getMessage(), true);
		} catch (IOException e) {
			Reports.ExtentReportLog("Pdf not downloaded :", Status.FAIL,e.getMessage(), true);
		}
	}
}
