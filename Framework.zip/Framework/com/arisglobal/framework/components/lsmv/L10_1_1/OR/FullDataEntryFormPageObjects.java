package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public abstract class FullDataEntryFormPageObjects {
	public static String RCTNo = "xpath#//label[@id='adverseEventNew:recieptId']";
	public static String newCase = "xpath#//div[@id='headerForm:menuMainId']/div[@id='headerForm:cbp-spmenu-s1']/div[@id='headerForm:j_id_1g']/ul[@class='ui-menu-list ui-helper-reset']/li[@id='headerForm:adverseMenu']/ul[@class='ui-widget-content ui-menu-list ui-corner-all ui-helper-clearfix ui-menu-child ui-shadow']/li[@id='headerForm:adverseNewId']/a[@class='ui-menuitem-link ui-submenu-link ui-corner-all']/span[@class='ui-menuitem-text']";
	public static String fullDataEntryForm = "xpath#//a[@class='ui-menuitem-link ui-corner-all']/span[contains(text(),'Full data entry form')]";
	public static String SaveButton = "xpath#//a[@id='adverseEventNew:visibleSave']";
	public static String LSMVCancel = "xpath#//a[@id='adverseEventNew:cancelId']";
	public static String saveOkButton = "xpath#//div[contains(@class,'validationDialogPanel')]/following-sibling::div/button[text()='OK']";
	public static String saveOkButton_newVersion = "xpath#//input[contains(@onclick,'createNwVrsnValidation')]";
	public static String receiptNumber = "xpath#(//label[@class='validationDialogSpanSty newDesign_INFO_label'])[1]";
	public static String completeActivityvalidation = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:1:cmdinfo']";
	public static String FDElable = "xpath#//label[contains(text(),'Case Units')]";
	public static String assignToLabel = "xpath#//div[@class='col-md-4 ng-star-inserted']//label[text()='Assigned To']";
	public static String loading = "xpath#//div[@class='angularLoaderStyfda']/label[text()='Loading']";
	public static String loadingListingLevel = "xpath#//div[@class='angularLoaderStyfda']/label[text()='Loading']";
	public static String completeActivtyLoading = "xpath#//div[@id='exportXmlviewForm:statusDialogId']//label[text()='Loading']";
	public static String approvedLabel = "xpath#//label[@id='adverseEventNew:approvedImage'][text()='Approved']";
	public static String saveAndExit = "xpath#//a[text()=' Save & Exit']";
	public static String navigation_Validation = "xpath#//div[@class='ui-dialog-content ui-widget-content']/span[text()='Do you want to exit without saving?']";
	public static String navigation_Validation_YesBtn = "xpath#//button[@id='formModifyYes']/span[text()='Yes']";
	public static String ActionOkBtn = "xpath#//button[contains(@onclick,'closeValidationDialog')]";
	public static String reAssignvalue = "xpath#//input[@id='adverseEventNew:generalPanelTable:generalPanelDataTable:assignTo']/ancestor::div[@class='ui-helper-hidden-accessible']/following-sibling::label/span";
	public static String RecptNumber = "xpath#//label[@id='adverseEventNew:recieptId']";
	public static String validationCloseBtn = "xpath#//form[@id='fdeAngularForm']//div[contains(@class,'mandatoryOpenState ng-star-inserted')]/img";
	// Delete operations page objects
	public static String deleted_Lable = "xpath#//label[text()='Deleted']";
	public static String archived_Lable = "xpath#//label[text()='Out Of WF']";
	public static String active_Lable = "xpath#//label[text()='Active']";
	public static String retrieve_Btn = "xpath#//a[@id='adverseEventNew:retriveID']";
	public static String retrieveReason_Txtarea = "xpath#//input[@id='retriveReason']";
	public static String retrievePopupSubmit_Btn = "xpath#//div[@id='caseRetriveContents']/div/span[text()='Submit']";
	public static String retrieveReasonPopup_Title = "xpath#//span[text()='Retrieve Reason']";

	// public static String tabNavigation = "xpath#//div[@class='agCol
	// agTreeViewLayout treeOpenedState']//a[contains(text(),'%s')]";
	public static String tabNavigation = "xpath#//div[@class='agCol agTreeViewLayout treeOpenedState ng-star-inserted']//a[contains(text(),'%s')]";
	public static String FDE_tabNavigation = "xpath#//ul[@role='tablist']/li/a[contains(@id,'ui-tabpanel')]/span[text()='%s']";
	public static String reportGenerationWindow = "xpath#//button[@id='generateSummary']";
	public static String radioBtn_ReportGenWindow = "xpath#//label[text()='Select Blinded/UnBlinded Report']/ancestor::div/child::div//label[text()='%s']";
	public static String pdf_DataVerification = "xpath#//div[@id='pageContainer1']/div[@class='textLayer']/following::div[contains(text(),'%s')]";
	public static String pdf_iframeID = "openCaseSummaryDiolog:test_adv";
	public static String ciomosReport_iframeID = "openCiomosSummaryDiolog:test_adv";
	public static String caseEditloading = "xpath#//div[@id='adverseEventNew:angularLoader']/label[contains(@id,'adverseEventNew')][text()='Loading']";
	public static String reporterHeader = "xpath#//span[contains(@id,'SummaryDialog_title')][contains(text(),'%s')]";
	public static String withOutSaveValidation = "xpath#//div[@id='formModifiedId']/child::div/span[text()='Do you want to exit without saving?']";
	public static String yesBtn_withOutSaveValidation = "xpath#//button[@id='formModifyYes']/span[text()='Yes']";
	public static String cancel_Button = "xpath#//a[@id='adverseEventNew:cancelId']";
	public static String moreOptions_Button = "xpath#//a[@id='adverseEventNew:actionsLinkID']";
	public static String edit_Button = "xpath#//span[@class='ui-button-text ui-c'][contains(text(),'Edit')]";
	public static String rct1_Link = "xpath#//label[contains(@id,':0:multiLabel')]";
	public static String rct2_Link = "xpath#//a[contains(@id,':1:multiLink')]";
	public static String close_Link = "xpath#//a[contains(@id,'multiAEremoval')]/img";
	// public static String closeRCT2_Link =
	// "xpath#//a[contains(@id,'multiAEremoval')]/img";
	public static String checkDisablity_SenderOrgRepTxtField = "xpath#//label[@style='visibility: visible;'][contains(text(),'Sender Organization as Reported')]/ancestor::span/input[@disabled]";
	public static String receiptNo_Link = "xpath#//a[contains(@id,'multiLink')][text()='%s']";
	public static String dataAssessment_Label = "xpath#//label[text()='Initial Data Assessment Comments']";
	public static String dataAssessment_WarningPopup = "xpath#//div[@id='nonCaseWinFormMain']//div[text()='Do you want to continue with Data Assessment for Non-Case.']";
	public static String dataAssessment_WarningPopup_YesBtn = "xpath#//div[@id='nonCaseWinMain']//button[text()='Yes']";
	public static String InitialWarning = "xpath#//div[@id='followupWarning']";
	public static String InitialWarningProceedBtn = "xpath#//button[@id='initialFollowupConfirm']";
	public static String dataAssessment_links = "xpath#//div[@id='caseDetailsForAssessmentTab']/div/span[text()='%s']";
	public static String dataAssessment_header = "xpath#//div[@class='lsmv-popup-header']/span[contains(@id,'ClassifyWinTitle')]";
	public static String dataAssesComments_TxtArea = "xpath#//textarea[@id='classifyNewComments']";
	public static String classifyCase_Btn = "xpath#(//button[text()='Classify Case'])[1]";
	public static String dataAssessmentDuplicate_header = "xpath#//div[@class='lsmv-popup-header']/span[@id='dsDuplicateClassifyWinTitle']";
	// public static String editCase_Loading =
	// "xpath#//div[@id='adverseEventNew:angularLoader']/label[contains(@id,'adverseEventNew')][text()='Loading']";
	public static String editCase_Loading = "xpath#//div[@id='adverseEventNew:angularLoader']";
	public static String LoadingIcon = "xpath#//div[contains(@id,':angularLoader')]";
	public static String actions_Btn = "xpath#//a[text()='Actions']/parent::div";
	public static String Submissionlistingactions_Btn = "xpath#//span[text()='Actions']/parent::button";
	public static String completeActivity_link = "xpath#//td/a[text()='Complete Activity']";
	public static String activty_Dropdwn = "xpath#//div[contains(@id,'adverseEventNew')][contains(@class,'completeActDropDown')]";
	public static String activty_Dropdwn_label = "xpath#//select[@id='adverseEventNew:selectedTransitionId']";
	public static String activty_Dropdwn_select = "xpath#//option[text()='%s']";
	public static String completeAct_WarningLabel = "xpath#//label[contains(text(),'Do you still want to continue ?')]";
	public static String warning_YesBtn = "xpath#//button[@onclick='submitConfirmDialog()' and text()='Yes']";
	public static String warning_NoBtn = "xpath#//button[@id='mandatoryDialogform:noButton']//span[text()='No']";
	public static String actComp_ValidationError = "xpath#//span[@id='mandatoryDialogform:mandatoryID_title'][text()='Action Completed with Validation Error(s)']";
	public static String actComp_Sucessfully = "xpath#//span[contains(text(),'Action Completed Successfully')]";
	public static String case_MovedToNxtAct = "xpath#//label[contains(@id,'mandatoryDialogform:mandatoryDatatable')][contains(text(),'moved to')]";
	public static String compAct_Load = "xpath#//div[contains(@id,'adverseEventNew')]//img[contains(@src,'LoaderNew.gif')]";
	public static String workflowNavig_Loading = "xpath#//div[@id='headerForm:newOverlayLoader']//img[contains(@src,'LoaderNew')]";
	public static String actions_BtnSub = "xpath#//button[contains(@id,'submissionMessageNew')]/span[text()='Actions']";
	public static String LatenessReson = "xpath#//select[@id='latenessReasonSelect']";

	// data assessment
	public static String dataAssessNew = "xpath#//span[@id='classifyTypeNew'][text()='New']";

	// Report Header
	public static String MEDWATCH3500A_Header = "MEDWATCH 3500A Report";
	public static String MEDWATCH3500B_Header = "MEDWATCH 3500B Report";
	public static String MEDWATCH3500_Header = "MEDWATCH Report";
	public static String CIOMS_Header = "CIOMS Report";
	public static String CaseSummaryReport_Header = "Case Summary Report";

	public static String masked_radioBtn = "Masked";
	public static String unMasked_radioBtn = "UnMasked";
	public static String blinded_radioBtn = "Blinded report";
	public static String unblinded_radioBtn = "UnBlinded report";
	public static String dataAssessment_Link = "Data Assessment";
	public static String dataAssessmentNew_Link = "New";
	public static String dataAssessmentFollowup_Link = "Follow Up";
	public static String dataAssessmentDuplicate_Link = "Duplicate";

	public static String submissionTracking_Link = "Submission Tracking";
	// public static String submissionTracking_Link = "SUBMISSIONTRACKING";

	public static String DataAssessmentBtnPerf = "xpath#//a[@id='ui-tabpanel-3-label']//span[contains(text(),'Data Assessment')]";

	public static String CompleteactivityDd = "xpath#//select[@id='adverseEventNew:j_id_1ex_input']";
	public static String CompleteActivityExit = "xpath#//td/a[text()='Complete Activity & Exit']";

	public static String commonLoader = "xpath#//img[@id='headerForm:j_id_y']";
	public static String validationsWarning = "xpath#//div[@id='agMandatoryPanel']/h4";

	public static String caseReceiptNo = "xpath#//label[@id='adverseEventNew:recieptId']";
	public static String wfStatus = "xpath#//label[@id='adverseEventNew:workflowId']";

	public static String nonEditableCompanyUnit = "xpath#//label[@style='visibility: visible;'][text()='Company Unit']/ancestor::span/p-dropdown/div[contains(@class,'ui-state-disabled')]";

	public static String clickMinimizeVal = "xpath#//img[@src='../../images/fde-expand-arrow.png']";

	// rollover
	public static String initial = "Initial";
	public static String followup = "Follow-Up";
	public static String initial_Followup_RadioBtn = "xpath#//label[text()='%label%']/ancestor::td//div/span[@class='ui-radiobutton-icon ui-icon ui-icon-bullet ui-c']";
	public static String caseInformation_Link = "Case Information";
	public static String followupRef = "xpath#//input[@id='adverseEventNew:dataForFollowUpInBasi']";
	public static String fuLabel = "xpath#//label[text()='Follow-up Ref.#']";

	public static String duplicateRCTlookup = "xpath#//span[@id='classifyDuplicateReceiptNoLP']";
	public static String duplicateSpecifyReasonDropDown = "xpath#//select[@id='classifyDuplicateReasonCombo']";
	public static String duplicateSpecifyReasonDropDownValue = "xpath#//select[@id='classifyDuplicateReasonCombo']/option[text()='%value']";
	public static String duplicateAssesComments = "xpath#//textarea[@id='classifyDuplicateComments']";
	public static String duplicateRctNum = "xpath#//div[@id='targetPanelForDataLibLookup']//input[@title='Enter ReceiptNo.' or @placeholder='Search...']";
	public static String duplicateRctNumSearch = "xpath#(//span[@class='lsmv-grid-search-icon'])[last()]";
	public static String searchRctRadioButton = "xpath#(//span[@class='lsmv-grid-chk-sticky lsmv-grid-row-sel-chk lsmv-grid-sel-unchk'])[last()]";
	public static String duplicateRctSearch = "xpath#//button[@id='receiptNoForm:findButton']";
	public static String duplicateRctSearchOk = "xpath#//span[text()='Select']";
	public static String duplicateAerNumber = "xpath#//input[@id='aeClassificationForm:aer']";
	public static String RecptNumberSearchIcon = "xpath#//span[@class='lsmv-grid-search-icon']";

	// Report Generation Access
	public static String reportGenerationAccessPopUP = "xpath#//div[@id='reportaccessdialog']";
	public static String RadioBtn = "xpath#//label[text()='%label%']/span";
	public static String clickGenerateReport = "xpath#//button[@id='generateSummary']";
	public static String maskedLabel = "Masked ";
	public static String unMaskedLabel = "UnMasked";
	public static String blindedReportLabel = "Blinded report";
	public static String UnblindedReportLabel = "UnBlinded report";
	public static String generationAccess = "xpath#//div[contains(@class,'ifGenratedAccess')]";
	public static String blindedMask = "xpath#//div[contains(@class,'ifblindedMask')]";

	// split handler
	public static String splithandler = "xpath#//div[@id='qcSplitToggler']";

	// Reclassify
	public static String reclassify = "xpath#//span[text()='Reclassify']";
	public static String reclassificationpopupHeader = "xpath#//span[text()='Reclassification']";
	public static String reclassification_textArea = "xpath#//textarea[@id='reClassifyComments']";
	public static String reclassifyYesBtn = "xpath#//button[@id='reClassifyConfirm']";
	public static String reclassifySuccessMsg = "xpath#//span[text()='Case is reclassified successfully']";
	public static String aernoDisappear = "xpath#//label[@id='adverseEventNew:mappedAerNoLable']";
	public static String actionCompletePopUp = "xpath#//span[text()='Action Completed Successfully']";
	public static String okBtn = "xpath#//button[text()='OK']";

	public static String dataAssessmentHistoryTab = "xpath#(//div[@id='assessHistoryHtmlPanel']/div)[1]";
	public static String duplicateClassification = "xpath#//div[text()='Duplicate']";
	public static String histroryReceiptNo = "xpath#//div[@id='daHistReceiptNo']";
	public static String dupClassifyCase_Btn = "xpath#//div[@id='dsDuplicateClassifyMain']//button[text()='Classify Case']";
	public static String dataAssessmentLoader = "xpath#//img[@id='headerForm:j_id_1f']";
	public static String FollowUpClassification = "xpath#//div[text()='Follow-Up']";
	public static String historyAERNo = "xpath#//div[@id='daHistAerNo']";
	public static String navigateToVersionHistoryTab = "xpath#//span[text()='Version History']";
	public static String versionHistoryHeader = "xpath#//div[@class='versionHistoryPanelSty panel-heading']";

	public static String versionHistoryAerNo = "xpath#//td[@class='versionSelected']//parent::tr//a[@href='javascript:void(0)']";
	public static String caseAerNO = "xpath#//label[@id='adverseEventNew:mappedAerNoLable']";
	public static String newClassification = "xpath#//div[text()='New']";

	public static String productTypeCheckBox = "xpath#//label[contains(text(),'%s')]//preceding-sibling::p-checkbox";
	public static String SaveOk = "xpath#//button[text()='OK']";
	public static String EventOrProductCount = "xpath#//span[contains(text(),'%count')]";
	public static String RankButton = "xpath#(//a[text()='Rank'])[2]";
	public static String DontRankCheckBox = "xpath#//label[text()='Do Not Auto Rank']//following::p-checkbox";
	public static String RankOKBtn = "xpath#(//span[text()='OK'])[3]";
	public static String RankEventName = "xpath#//span[contains(text(),'Events Ranking')]//following::tbody[1]//tr[%s]/td[3]";
	public static String RankProductName = "xpath#//span[contains(text(),'Product Ranking')]//following::tbody[1]//tr[%s]/td[3]";
	public static String RankEventDrag = "xpath#//span[contains(text(),'Events Ranking')]//following::tbody[1]//tr[%s]/td[1]";
	public static String RankProductDrag = "xpath#//span[contains(text(),'Product Ranking')]//following::tbody[1]//tr[%s]/td[1]";

	public static String productCharText = "xpath#//label[contains(text(),'Product Characterization')]//following::p-dropdown[1]//div//label//span";
	public static String SeriousnessYes = "xpath#(//label[text()='Seriousness ']//following::span//p-radiobutton)[1]//div[2]";

	public static String createVersionReceiptNO = "xpath#(//div[@id='newVersionDailog']/div//div)[2]";
	public static String createVersionOkBtn = "xpath#//input[@class='btn btn-dafault']";

	public static String followupReconcileWindowClose = "xpath#//button[contains(@onclick,'closereconciliation')]";
	public static String validationArrow = "xpath#//div[contains(@class,'mandatoryOpenState')]/img";

	/**********************************************************************************************************
	 * Objective:The below method is created click radiobtn in report generation
	 * access
	 * 
	 * @author: Pooja S Date : 01-Sep-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String reportGenerationAccess(String label) {
		String value = RadioBtn.replace("%label%", label);
		return value;
	}

	public static String initial_Followup_RadioBtn(String label) {
		String value = initial_Followup_RadioBtn.replace("%label%", label);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created click data assessement link by passing
	 * link name at runtime Input Parameters: runTimeLabel Output Parameters:
	 * 
	 * @author: Avinash k Date : 26-Jul-2019 Updated by and when:
	 **********************************************************************************************************/

	public static String dataAssessment_links(String runTimeLabel) {
		String value = dataAssessment_links;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created click activity from dropdown Input
	 * Parameters: activity name Output Parameters:
	 * 
	 * @author: Kishore Date : 04-Mar-2020 Updated by and when:
	 **********************************************************************************************************/

	public static String selectActivity(String activityName) {
		String value2;
		value2 = activty_Dropdwn_select.replace("%s", activityName);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created verify reporter header in opened PDF at
	 * run time. Input Parameters: runTimeLabel Output Parameters:
	 * 
	 * @author: Avinash k Date : 26-Jul-2019 Updated by and when:
	 **********************************************************************************************************/

	public static String reporterHeader(String runTimeLabel) {
		String value = reporterHeader;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created click receiptNo_Link run time. Input
	 * Parameters: Scenario Name Output Parameters:
	 * 
	 * @author: Avinash k Date : 11-Sep-2019 Updated by and when:
	 **********************************************************************************************************/

	public static String receiptNo_Link(String runTimeLabel) {
		String value = receiptNo_Link;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created verify data in opened PDF at run time.
	 * Input Parameters: Scenario Name Output Parameters:
	 * 
	 * @author: Avinash k Date : 26-Jul-2019 Updated by and when:
	 **********************************************************************************************************/

	public static String pdf_DataVerification(String runTimeLabel) {
		String value = pdf_DataVerification;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created perform tab navigation by passing tab
	 * name at run time. Input Parameters: Scenario Name Output Parameters:
	 * 
	 * @author: Avinash k Date : 26-Jul-2019 Updated by and when:
	 **********************************************************************************************************/

	public static String tabNavigation(String runTimeLabel) {
		String value = tabNavigation;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click radio button in report
	 * Generation Window at run time. Input Parameters: Scenario Name Output
	 * Parameters:
	 * 
	 * @author: Avinash k Date : 26-Jul-2019 Updated by and when:
	 **********************************************************************************************************/

	public static String clickRadioButton(String runTimeLabel) {
		String value = radioBtn_ReportGenWindow;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created perform FDE tab navigation by passing
	 * tab name at run time. Input Parameters: Scenario Name Output Parameters:
	 * 
	 * @author: Avinash k Date : 14-Aug-2019 Updated by and when:
	 **********************************************************************************************************/

	public static String FDE_tabNavigation(String runTimeLabel) {
		String value = FDE_tabNavigation;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created perform clicking specify reason drop
	 * down value for Duplicate Data Assessment
	 * 
	 * @author: Karthikeyan Natarajan Date : 17-Jul-2020 Updated by and when:
	 **********************************************************************************************************/

	public static String SelectSpecifyReason(String runTimeLabel) {
		String value = duplicateSpecifyReasonDropDownValue;
		String value2;
		value2 = value.replace("%value", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created perform clicking specify reason drop
	 * down value for Duplicate Data Assessment
	 * 
	 * @author: Karthikeyan Natarajan Date : 17-Jul-2020 Updated by and when:
	 **********************************************************************************************************/

	public static String ProductTypeCheckBox(String runTimeLabel) {
		String value = productTypeCheckBox;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	// ISP-V0067 Validation related
	public static String validationNotification = "xpath#//div/label[contains(text(),'%eventType% : %ruleName%')]";

	/**********************************************************************************************************
	 * @Objective:The below method is created build a locator to identify
	 *                warning/Error message dynamically
	 * @author: Shamanth S
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @Date : 26-Nov-2020
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String notiftnV0067_locator(String eventType, String ruleName) {
		String value = validationNotification;
		String value1, value2;
		value1 = value.replace("%eventType%", eventType);
		value2 = value1.replace("%ruleName%", ruleName);
		return value2;
	}

	// ISP-V0067 Validation related
	public static String validationSideNotification = "xpath#//li/a[contains(text(),'%ruleName%')]";

	/**********************************************************************************************************
	 * @Objective:The below method is created build a locator to identify
	 *                warning/Error message displayed at right extreme dynamically
	 * @author: Shamanth S
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @Date : 22-Dec-2020
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String validationSideNotification(String ruleName) {
		String value = validationSideNotification;
		String value1 = value.replace("%ruleName%", ruleName);
		return value1;
	}

	public static String SelectRCT = "xpath#//table[@id='adverseEventNew:multieditGrid']//a[.='%label%']";
	public static String editRCt = "xpath#//span[.='Edit']/parent::button";
	public static String closebutton = "xpath#//table[@id='adverseEventNew:multieditGrid']//a[.='%label%']/parent::td/following-sibling::td/a/img";

	public static String RecptTablabel = "xpath#//table[@id='adverseEventNew:multieditGrid']//label";

	public static String SelectRCT(String rctNum) {
		String value = SelectRCT;
		String value2;
		value2 = value.replace("%label%", rctNum);
		return value2;
	}

	public static String CloseRCT(String rctNum) {
		String value = closebutton;
		String value2;
		value2 = value.replace("%label%", rctNum);
		return value2;
	}

	public static String latenessReasonTitle = "xpath#//div/span[@id='titleLateNess']";
	public static String latenessReasonSubmitBtn = "xpath#//span[@id='titleLateNess']/parent::div/following-sibling::div/div/button[text()='Submit']";
}
