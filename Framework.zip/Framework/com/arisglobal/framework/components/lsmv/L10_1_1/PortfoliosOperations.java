package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.PortfoliosPageObjects;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.aventstack.extentreports.Status;

public class PortfoliosOperations extends ToolManager{
	public static WebElement webElement;
	static String className = PortfoliosOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	
	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in portfolio Module 
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void menuNavigation(String menu) {
		agMouseHover(PortfoliosPageObjects.portfoliosHover);
		agClick(menu);
		}
	
	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in portfolio Module and verify the label name.
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void portfolioNavigations(String menu) {
			switch (menu) {
			case "productPortfolio":
				menuNavigation(PortfoliosPageObjects.productPortfolio);
				status = agIsVisible(PortfoliosPageObjects.productPorftKeywordSearch);
		
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to product Portfolio is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to product Portfolio is Unsuccessfull", true);
				}
				break;

			case "accountPortfolio":
				menuNavigation(PortfoliosPageObjects.accountPortfolio);
				status = agIsVisible(PortfoliosPageObjects.accountPortfKeywordSearch);
			
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to account Portfolio is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to account Portfolio is Unsuccessfull", true);
				}
				break;
			case "eventPortfolio":
				menuNavigation(PortfoliosPageObjects.eventPortfolio);
				status = agIsVisible(PortfoliosPageObjects.eventPortfKeywordSearch);
				
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to even Portfolio is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to event Portfolio is Unsuccessfull", true);
				}
				break;

			case "myAssignment":
				menuNavigation(PortfoliosPageObjects.myAssignment);
				status = agIsVisible(PortfoliosPageObjects.myAssignKeywordSearch);
			
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to myAssignment is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to myAssignment is Unsuccessfull", true);
				}
				break;
			default:
				System.out.println("Invalid Menu Link!");
			}


	}
}