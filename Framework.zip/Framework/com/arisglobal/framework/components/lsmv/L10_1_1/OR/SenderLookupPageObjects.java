package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class SenderLookupPageObjects {
	public static String sender_Label = "Sender";
	public static String companyUnit_Label = "Company Unit";
	public static String accountName_TextBox = "xpath#//input[contains(@name, 'accountName') or @name='account']";
	public static String domain_TextBox = "xpath#//input[contains(@name, 'accountDomain') or @name='domain']";
	public static String firmSiteFEINumber_TextBox = "xpath#//input[contains(@name, 'feiNumber') or @name='firm']";
	public static String accountGroup_CheckBox = "Account Group";
	
	public static String companyUnitCode_TextBox = "xpath#//label[text()= 'Company Unit Code']/following-sibling::input[contains(@type , 'text')]";
	public static String companyUnitName_TextBox = "xpath#//label[text()= 'Company Unit Name']/following-sibling::input[contains(@type , 'text')]";
	public static String type_DropDown = "";
	public static String country_DropDown = "";
	
	public static String search_Button = "xpath#//button[@id='accountLookup:findButton' or contains(@class, 'agOnEnterSearch')]/span[starts-with(text(), 'Search')]";
	public static String clear_Button = "xpath#//button[@id='accountLookup:clear']";
	public static String ok_Button = "xpath#//button[contains(@id, 'accountLookup:okButton')]";
	
	public static String okSenderPartner_Button = "xpath#//span[@class='ui-button-text ui-clickable' and text()= 'OK']";
	
	public static String selectRadioButton = "xpath#//label[text()='%radio%']/parent::*/descendant::span[contains(@class,'ui-radiobutton-icon')]";
	
	public static String selectRadioButton(String radioButtonLabel) {
		String resultLocator = selectRadioButton.replace("%radio%", radioButtonLabel);
		return resultLocator;
	}
}
