package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.DistributionContactsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.WorkFlowPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class DistributionContact extends ToolManager {
	static String className = DistributionContact.class.getSimpleName();
	public static WebElement webElement;
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in
	 *             Distribution Module
	 * @InputParameters: pageObject
	 * @OutputParameters:
	 * @author:Mythri JAIN
	 * @Date : 6-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void menuNavigation(String pageObject) {

		agMouseHover(DistributionContactsPageObjects.distributionHover);
		agClick(pageObject);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in
	 *             Distribution Module
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 6-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void distributionNavigations(String menu) {
		switch (menu) {
		case "distribution":
			menuNavigation(DistributionContactsPageObjects.distributionNew);
			status = agIsVisible(DistributionContactsPageObjects.distributionContactName_Textbox);

			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to Distribution is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Distribution is Unsuccessfull", true);
			}
			break;
		default:
			System.out.println("Invalid Menu Link!");
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 6-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(DistributionContactsPageObjects.clickdropdown(label));
			agClick(DistributionContactsPageObjects
					.selectDropdownvalue(getTestDataCellValue(scenarioName, columnName)));

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Distribution Contact
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 5-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDistributionContact(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(DistributionContactsPageObjects.new_Button);
		agSetValue(DistributionContactsPageObjects.distributionContactName_Textbox,
				getTestDataCellValue(scenarioName, "DistributionContactName"));
		// CommonOperations.setFDEDropDownValue(DistributionContactsPageObjects.receiverType_Dropdown,
		// getTestDataCellValue(scenarioName, "ReceiverType"));
		setDropDownValue(DistributionContactsPageObjects.receiverType_Dropdown, scenarioName, "ReceiverType");
		if (getTestDataCellValue(scenarioName, "ReceiverType").equalsIgnoreCase("Account")) {
			agClick(DistributionContactsPageObjects.receiverOrganization_LookupAccount);
			agSetValue(DistributionContactsPageObjects.accountName_Textbox,
					getTestDataCellValue(scenarioName, "AccountName"));
			agClick(DistributionContactsPageObjects.search_Button);
			agSetStepExecutionDelay("2000");
			CommonOperations.takeScreenShot();
			agClick(DistributionContactsPageObjects.checkFirstAccountName);
			agClick(DistributionContactsPageObjects.ok_Button);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		if (getTestDataCellValue(scenarioName, "ReceiverType").equalsIgnoreCase("Company Unit")) {
			agClick(DistributionContactsPageObjects.receiverOrganization_LookupCompanyunit);
			agSetValue(DistributionContactsPageObjects.companyUnitCode_Textbox,
					getTestDataCellValue(scenarioName, "CompanyUnitCode"));
			agClick(DistributionContactsPageObjects.search_Button);
			agSetStepExecutionDelay("2000");
			CommonOperations.takeScreenShot();
			agClick(DistributionContactsPageObjects.checkFirstCompanyUnit1);
			agClick(DistributionContactsPageObjects.ok_Button);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		if (getTestDataCellValue(scenarioName, "Pivot").equalsIgnoreCase("true")) {
			agClick(DistributionContactsPageObjects.pivot_Lookup);
			agSetValue(DistributionContactsPageObjects.ruleName_Textbox,
					getTestDataCellValue(scenarioName, "RuleName"));
			agClick(DistributionContactsPageObjects.search_Button);
			agSetStepExecutionDelay("2000");
			CommonOperations.takeScreenShot();
			agClick(DistributionContactsPageObjects.checkFirstRuleID);
			agClick(DistributionContactsPageObjects.ok_Button);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		setDropDownValue(DistributionContactsPageObjects.language_Dropdown, scenarioName, "Language");
		agSetValue(DistributionContactsPageObjects.description_Textarea,
				getTestDataCellValue(scenarioName, "Description"));
		setDropDownValue(DistributionContactsPageObjects.correspondenceMedium_Dropdown, scenarioName,
				"CorrespondenceMedium");
		agSetValue(DistributionContactsPageObjects.correspondenceMediumDetails_Textbox,
				getTestDataCellValue(scenarioName, "CorrespondenceMediumDetails"));
		agSetValue(DistributionContactsPageObjects.replytoEmailAddress_Textbox,
				getTestDataCellValue(scenarioName, "ReplytoEmailAddress"));
		agSetValue(DistributionContactsPageObjects.correspondenceCCEmailAddress_Textbox,
				getTestDataCellValue(scenarioName, "CorrespondenceCCEmailAddress"));
		setDropDownValue(DistributionContactsPageObjects.submissionDueDateCalculationBasedOn_Dropdown, scenarioName,
				"SubmissionDueDateCalculationBasedOn");
		setDropDownValue(DistributionContactsPageObjects.affiliateSubmissionDueDateCalculationBasedOn_Dropdown,
				scenarioName, "AffiliateSubmissionDueDateCalculationBasedOn");
		setDropDownValue(DistributionContactsPageObjects.mailServer_Dropdown, scenarioName, "MailServer");
		CommonOperations.clickCheckBoxLeftOf(DistributionContactsPageObjects.allowSingleEmailSubmission_label,
				getTestDataCellValue(scenarioName, "AllowSingleEmailSubmission"));
		CommonOperations.clickCheckBoxLeftOf(DistributionContactsPageObjects.allowBackReporting_label,
				getTestDataCellValue(scenarioName, "AllowBackReporting"));
		CommonOperations.clickCheckBoxLeftOf(DistributionContactsPageObjects.senderComments_label,
				getTestDataCellValue(scenarioName, "SenderComments"));
		CommonOperations.clickCheckBoxLeftOf(DistributionContactsPageObjects.eventDescription_label,
				getTestDataCellValue(scenarioName, "EventDescription"));
		CommonOperations.clickCheckBoxLeftOf(DistributionContactsPageObjects.storeLocalDatainLSMV_label,
				getTestDataCellValue(scenarioName, "StoreLocalDatainLSMV"));
		CommonOperations.clickCheckBoxLeftOf(DistributionContactsPageObjects.spainStateAccess_label,
				getTestDataCellValue(scenarioName, "SpainStateAccess"));
		CommonOperations.clickCheckBoxLeftOf(DistributionContactsPageObjects.localLabelingAccess_label,
				getTestDataCellValue(scenarioName, "LocalLabelingAccess"));
		CommonOperations.clickCheckBoxLeftOf(DistributionContactsPageObjects.allowICSRattachments_label,
				getTestDataCellValue(scenarioName, "AllowICSRattachments"));
		CommonOperations.clickCheckBoxLeftOf(DistributionContactsPageObjects.summaryandReporterCommentsAccess_label,
				getTestDataCellValue(scenarioName, "SummaryandReporterCommentsAccess"));
		agClick(DistributionContactsPageObjects.submittingUnitsAdd_Button);
		agSetValue(DistributionContactsPageObjects.companyUnitCode_Textbox,
				getTestDataCellValue(scenarioName, "CompanyUnitCode"));
		agClick(DistributionContactsPageObjects.search_Button);
		agSetStepExecutionDelay("2000");
		CommonOperations.takeScreenShot();
		agClick(DistributionContactsPageObjects.checkFirstCompanyUnit);
		agClick(DistributionContactsPageObjects.ok_Button);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.takeScreenShot();
		agClick(DistributionContactsPageObjects.save_Button);

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Distribution Contact : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to handle OK Button after save in
	 *             distribution
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 5-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	// Test
	public static String setDistributionOKValidation(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("1000");
		String msg = agGetText(DistributionContactsPageObjects.validationMessage);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(DistributionContactsPageObjects.validaionOk_Button);
		return msg;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Distribution Format
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 5-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDistributionFormat(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(DistributionContactsPageObjects.distributionFormatAdd_Button);
		agSetStepExecutionDelay("2000");
		agSetValue(DistributionContactsPageObjects.formatDisplayName_Textbox,
				getTestDataCellValue(scenarioName, "FormatDisplayName"));
		if (getTestDataCellValue(scenarioName, "FormatPivot").equalsIgnoreCase("true")) {
			agClick(DistributionContactsPageObjects.pivotFormat_Lookup);
			agSetValue(DistributionContactsPageObjects.ruleName_Textbox,
					getTestDataCellValue(scenarioName, "RuleName"));
			agClick(DistributionContactsPageObjects.search_Button);
			CommonOperations.takeScreenShot();
			agClick(DistributionContactsPageObjects.checkFirstRuleID);
			agClick(DistributionContactsPageObjects.ok_Button);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		agSetValue(DistributionContactsPageObjects.description_Textarea,
				getTestDataCellValue(scenarioName, "Formatdescription"));
		setDropDownValue(DistributionContactsPageObjects.format_Dropdown, scenarioName, "Format");
		setDropDownValue(DistributionContactsPageObjects.reportMedium_Dropdown, scenarioName, "ReportMedium");
		agSetValue(DistributionContactsPageObjects.mediumDetails_Textbox,
				getTestDataCellValue(scenarioName, "MediumDetails"));
		setDropDownValue(DistributionContactsPageObjects.OLTConfiguration_Dropdown, scenarioName, "OLTConfiguration");
		setDropDownValue(DistributionContactsPageObjects.XMLDocType_Dropdown, scenarioName, "XMLDocType");
		setDropDownValue(DistributionContactsPageObjects.MessageType_Dropdown, scenarioName, "MessageType");
		if (getTestDataCellValue(scenarioName, "boolSenderContact").equalsIgnoreCase("true")) {
			agClick(DistributionContactsPageObjects.senderContact_Lookup);
			agSetValue(DistributionContactsPageObjects.contactFirstNameTextbox,
					getTestDataCellValue(scenarioName, "SenderContactFirstName"));
			agSetValue(DistributionContactsPageObjects.contactLastNameTextbox,
					getTestDataCellValue(scenarioName, "SenderContactLastName"));
			agClick(DistributionContactsPageObjects.contactSearchButton);
			agClick(DistributionContactsPageObjects.contactCheckBox);
			agClick(DistributionContactsPageObjects.ok_Button);
		}
		if (getTestDataCellValue(scenarioName, "boolReceiverContact").equalsIgnoreCase("true")) {
			agClick(DistributionContactsPageObjects.receiverContact_Lookup);
			agSetValue(DistributionContactsPageObjects.contactFirstNameTextbox,
					getTestDataCellValue(scenarioName, "ReceiverContactFirstName"));
			agSetValue(DistributionContactsPageObjects.contactLastNameTextbox,
					getTestDataCellValue(scenarioName, "ReceiverContactLastName"));
			agClick(DistributionContactsPageObjects.contactSearchButton);
			agClick(DistributionContactsPageObjects.contactCheckBox);
			agClick(DistributionContactsPageObjects.ok_Button);
		}
		if (getTestDataCellValue(scenarioName, "boolEmailTemplate").equalsIgnoreCase("true")) {
			agClick(DistributionContactsPageObjects.emailTemplate_Lookup);
			agSetValue(DistributionContactsPageObjects.templateNameTextbox,
					getTestDataCellValue(scenarioName, "EmailTemplateName"));
			agClick(DistributionContactsPageObjects.search_Button);
			agClick(DistributionContactsPageObjects.templateselectRadio);
			agClick(DistributionContactsPageObjects.ok_Button);
		}
		if (getTestDataCellValue(scenarioName, "boolFaxTemplate").equalsIgnoreCase("true")) {
			agClick(DistributionContactsPageObjects.faxTemplate_Lookup);
			agSetValue(DistributionContactsPageObjects.templateNameTextbox,
					getTestDataCellValue(scenarioName, "FaxTemplateName"));
			agClick(DistributionContactsPageObjects.search_Button);
			agClick(DistributionContactsPageObjects.templateselectRadio);
			agClick(DistributionContactsPageObjects.ok_Button);
		}
		if (getTestDataCellValue(scenarioName, "boolCoverPageTemplate").equalsIgnoreCase("true")) {
			agClick(DistributionContactsPageObjects.coverPageTemplate_Lookup);
			agSetValue(DistributionContactsPageObjects.templateNameTextbox,
					getTestDataCellValue(scenarioName, "CoverPageTemplateName"));
			agClick(DistributionContactsPageObjects.search_Button);
			agClick(DistributionContactsPageObjects.templateselectRadio);
			agClick(DistributionContactsPageObjects.ok_Button);
		}
		setDropDownValue(DistributionContactsPageObjects.submissionWorkflow_Dropdown, scenarioName,
				"SubmissionWorkflow");
		setDropDownValue(DistributionContactsPageObjects.dataPrivacy_Dropdown, scenarioName, "DataPrivacy");
		CommonOperations.clickCheckBoxLeftOf(
				DistributionContactsPageObjects.includeLiteraturedocumentinsubmission_label,
				getTestDataCellValue(scenarioName, "IncludeLiteraturedocumentinsubmission"));
		CommonOperations.clickCheckBoxLeftOf(DistributionContactsPageObjects.blindedReport_label,
				getTestDataCellValue(scenarioName, "BlindedReport"));
		CommonOperations.clickCheckBoxLeftOf(DistributionContactsPageObjects.autoRedistributeonMinorChange_label,
				getTestDataCellValue(scenarioName, "AutoRedistributeonMinorChange"));
		CommonOperations.clickCheckBoxLeftOf(DistributionContactsPageObjects.touchlessSubmission_label,
				getTestDataCellValue(scenarioName, "TouchlessSubmission"));
		CommonOperations.clickCheckBoxLeftOf(DistributionContactsPageObjects.considerSimilarProducts_label,
				getTestDataCellValue(scenarioName, "ConsiderSimilarProducts"));
		agClick(DistributionContactsPageObjects.save_Button);

		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Distribution Format : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Distribution Anchor
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 5-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDistributionAnchor(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(DistributionContactsPageObjects.distributionAnchorAdd_Button);
		agAssertVisible(DistributionContactsPageObjects.timeline_Textbox);
		agSetStepExecutionDelay("3000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(DistributionContactsPageObjects.anchorName_Textbox,
				getTestDataCellValue(scenarioName, "AnchorName"));
		if (getTestDataCellValue(scenarioName, "AnchorPivot").equalsIgnoreCase("true")) {
			agClick(DistributionContactsPageObjects.pivotAnchor_Lookup);
			agSetValue(DistributionContactsPageObjects.ruleName_Textbox,
					getTestDataCellValue(scenarioName, "RuleName"));
			agClick(DistributionContactsPageObjects.search_Button);
			agSetStepExecutionDelay("2000");
			CommonOperations.takeScreenShot();
			agClick(DistributionContactsPageObjects.checkFirstRuleID);
			agClick(DistributionContactsPageObjects.ok_Button);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		agSetValue(DistributionContactsPageObjects.description_Textarea,
				getTestDataCellValue(scenarioName, "AnchorDescription"));
		agSetValue(DistributionContactsPageObjects.effectiveStartDateTextbox,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "EffectiveStartDate")));
		agSetValue(DistributionContactsPageObjects.effectiveEndDateTextbox,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "EffectiveEndDate")));
		setDropDownValue(DistributionContactsPageObjects.reportType_Dropdown, scenarioName, "ReportType");
		// CommonOperations.setFDEDropDownValue(DistributionContactsPageObjects.reportType_Dropdown,
		// getTestDataCellValue(scenarioName, "ReportType"));
		setDropDownValue(DistributionContactsPageObjects.ruleInclusionLogic_Dropdown, scenarioName,
				"RuleInclusionLogic");
		agSetValue(DistributionContactsPageObjects.timeline_Textbox, getTestDataCellValue(scenarioName, "Timeline"));
		agSetValue(DistributionContactsPageObjects.affiliateSubmissionDueDateTimeline_Textbox,
				getTestDataCellValue(scenarioName, "AffiliateSubmissionDueDateTimeline"));
		agClick(DistributionContactsPageObjects.save_Button);

		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Distribution Anchor : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Search Distribution Contact
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 5-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean searchDistributionContact(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(DistributionContactsPageObjects.distributionFilterExpand);
		agSetValue(DistributionContactsPageObjects.distributionFilterContactName_Textbox,
				getTestDataCellValue(scenarioName, "DistributionContactName"));
		agClick(DistributionContactsPageObjects.search_Button);
		CommonOperations.takeScreenShot();
		agClick(DistributionContactsPageObjects.distributionFilterMinimize);
		String search = "";
		if (agIsVisible(DistributionContactsPageObjects.distributionFilterSearch) == true) {
			search = agGetText(DistributionContactsPageObjects.distributionFilterSearch);
			System.out.println("Contact Name : " + search);
		}
		if (!search.equalsIgnoreCase(getTestDataCellValue(scenarioName, "DistributionContactName"))) {
			Reports.ExtentReportLog(
					"", Status.INFO, "Search Result with '"
							+ getTestDataCellValue(scenarioName, "DistributionContactName") + "' does not exists!",
					false);
			return false;
		} else {
			return true;
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is Read Distribution Contact Data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 27-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ReadDistributionContactData(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Read Distribution Contact Started " + scenarioName, true);
			String className = "DistributionContact_ConfSetting";
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetStepExecutionDelay("3000");
			for (int j = 0; j < 4; j++) {
				if ((agIsVisible(DistributionContactsPageObjects.DistributionContact(scenarioName)) == true)) {
					agClick(DistributionContactsPageObjects.DistributionContact(scenarioName));
					break;
				} else {
					agClick(DistributionContactsPageObjects.NextPage);
				}

			}
			agSetStepExecutionDelay("2000");
			agWaitTillVisibilityOfElement(DistributionContactsPageObjects.VerifyDistributionContact);
			Reports.ExtentReportLog("", Status.INFO, "Distribution Contact : " + scenarioName + "found", true);
			agClick(DistributionContactsPageObjects.distributionContactName_Textbox);
			String DistributionContact_Textbox = agGetAttribute("value",
					DistributionContactsPageObjects.distributionContactName_Textbox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DistributionContactName",
					DistributionContact_Textbox);

			String ReciverTypeDDValue = agGetText(DistributionContactsPageObjects.ReciverTypeDDValue);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiverType",
					ReciverTypeDDValue);

			agClick(DistributionContactsPageObjects.ReciverOrgTextBox);
			String ReciverOrgTextBox = agGetAttribute("value", DistributionContactsPageObjects.ReciverOrgTextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiverOrganization",
					ReciverOrgTextBox);

			agClick(DistributionContactsPageObjects.CountryTextbox);
			String CountryTextbox = agGetAttribute("value", DistributionContactsPageObjects.CountryTextbox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Country", CountryTextbox);

			agClick(DistributionContactsPageObjects.description_Textarea);
			String Description_Textbox = agGetAttribute("value", DistributionContactsPageObjects.description_Textarea);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Description",
					Description_Textbox);

			if (agIsVisible(
					DistributionContactsPageObjects.CheckedCheckBox(DistributionContactsPageObjects.Active)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ActiveCheckBox",
						"Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ActiveCheckBox", "No");
			}

			String CorrespondanceMediumDD = agGetText(DistributionContactsPageObjects.CorrespondenceMailDD);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CorrespondenceMedium",
					CorrespondanceMediumDD);

			agClick(DistributionContactsPageObjects.correspondenceMediumDetails_Textbox);
			String CorrespondenceMedium_Textbox = agGetAttribute("value",
					DistributionContactsPageObjects.correspondenceMediumDetails_Textbox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"CorrespondenceMediumDetails", CorrespondenceMedium_Textbox);

			agClick(DistributionContactsPageObjects.correspondenceCCEmailAddress_Textbox);
			String CorrespondenceCCMedium_Textbox = agGetAttribute("value",
					DistributionContactsPageObjects.correspondenceCCEmailAddress_Textbox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"CorrespondenceCCEmailAddress", CorrespondenceCCMedium_Textbox);

			agClick(DistributionContactsPageObjects.replytoEmailAddress_Textbox);
			String ReplytoEmailAddress_Textbox = agGetAttribute("value",
					DistributionContactsPageObjects.replytoEmailAddress_Textbox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReplytoEmailAddress",
					ReplytoEmailAddress_Textbox);

			String SubmissionDueDateDD = agGetText(DistributionContactsPageObjects.SubmissionDueDateDD);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"SubmissionDueDateCalculationBasedOn", SubmissionDueDateDD);

			String AffSubmissionDueDateDD = agGetText(DistributionContactsPageObjects.AffSubmissionDueDateDD);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"AffiliateSubmissionDueDateCalculationBasedOn", AffSubmissionDueDateDD);

			String MailServerDD = agGetText(DistributionContactsPageObjects.MailServerDD);
			if (MailServerDD == "-- Select --") {

			}
			{
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "MailServer",
						MailServerDD);
			}
			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.VariableContact)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"VariableContactCheckBox", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"VariableContactCheckBox", "No");
			}

			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.allowBackReporting_label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowBackReportingCheckBox", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowBackReportingCheckBox", "No");
			}

			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.allowSingleEmailSubmission_label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowSingleEmailSubmissionCheckBox", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowSingleEmailSubmissionCheckBox", "No");
			}
			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.senderComments_label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"SenderCommentsCheckBox", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"SenderCommentsCheckBox", "No");
			}
			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.eventDescription_label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EventDescriptionCheckBox", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EventDescriptionCheckBox", "No");
			}

			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.storeLocalDatainLSMV_label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"StoreLocalDatainLSMVCheckBox", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"StoreLocalDatainLSMVCheckBox", "No");
			}

			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.spainStateAccess_label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"SpainStateAccessCheckBox", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"SpainStateAccessCheckBox", "No");
			}
			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.localLabelingAccess_label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"LocalLabelingAccessCheckBox", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"LocalLabelingAccessCheckBox", "No");
			}
			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.allowICSRattachments_label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowICSRattachmentsCheckBox", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowICSRattachmentsCheckBox", "No");
			}
			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.summaryandReporterCommentsAccess_label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"SummaryandReporterCommentsAccessCBox", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"SummaryandReporterCommentsAccessCBox", "No");
			}
			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.LocalApprovalAccess_label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"LocalApprovalAcessCheckBox", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"LocalApprovalAcessCheckBox", "No");
			}
			String SubmitUnitsName = agGetText(DistributionContactsPageObjects.SubmittingUnitName);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"SubmissionUnit_CompanyName", SubmitUnitsName);

			String SubmitUnitsCode = agGetText(DistributionContactsPageObjects.SubmittingUnitCode);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CompanyUnitCode",
					SubmitUnitsCode);

			agClick(DistributionContactsPageObjects.MaximizeContact(scenarioName));
			agWaitTillVisibilityOfElement(DistributionContactsPageObjects.Format);
			agClick(DistributionContactsPageObjects.Format);
			Reports.ExtentReportLog("", Status.INFO, "Navigate to Distribution Contact : " + scenarioName + "Format ",
					true);
			agClick(DistributionContactsPageObjects.formatDisplayName_Textbox);
			String formatDisplayName_Textbox = agGetAttribute("value",
					DistributionContactsPageObjects.formatDisplayName_Textbox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DF_FormatDisplayName",
					formatDisplayName_Textbox);

			agClick(DistributionContactsPageObjects.description_Textarea);
			String DF_description_Textarea = agGetAttribute("value",
					DistributionContactsPageObjects.formatDisplayName_Textbox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DF_Description",
					DF_description_Textarea);

			String FormatDD = agGetText(DistributionContactsPageObjects.FormatDD);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DF_Format", FormatDD);

			String ReportDD = agGetText(DistributionContactsPageObjects.ReportMediumDD);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DF_ReportMedium",
					ReportDD);

			String OLTConfigDD = agGetText(DistributionContactsPageObjects.OLTConfigDD);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "OLTConfiguration",
					OLTConfigDD);

			agClick(DistributionContactsPageObjects.ExpediteTimeline);
			String ExpediteTimeline_Textbox = agGetAttribute("value", DistributionContactsPageObjects.ExpediteTimeline);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DF_ExpeditedTimeLine",
					ExpediteTimeline_Textbox);

			if (agIsVisible(DistributionContactsPageObjects.XMLDocDD) == true) {
				String XMLDocType = agGetText(DistributionContactsPageObjects.XMLDocDD);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "XMLDocType",
						XMLDocType);
			}

			if (agIsVisible(DistributionContactsPageObjects.MsgTypeDD) == true) {
				String MsgTypeDD = agGetText(DistributionContactsPageObjects.MsgTypeDD);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "MessageType",
						MsgTypeDD);
			}
			agClick(DistributionContactsPageObjects.SenderContact_TextBox);
			String SenderContact_TextBox = agGetAttribute("value",
					DistributionContactsPageObjects.SenderContact_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DF_SenderContact",
					SenderContact_TextBox);

			agClick(DistributionContactsPageObjects.receiverContactId_TextBox);
			String receiverContactId_TextBox = agGetAttribute("value",
					DistributionContactsPageObjects.receiverContactId_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DF_ReciverContact",
					receiverContactId_TextBox);

			String SubmissionWorkflowDD = agGetText(DistributionContactsPageObjects.SubmissionWfDD);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DF_SubmissionWorkflow",
					SubmissionWorkflowDD);

			String DataPrivacyDD = agGetText(DistributionContactsPageObjects.DataPrivacyDD);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DF_DataPrivacy",
					DataPrivacyDD);

			if (agIsVisible(
					DistributionContactsPageObjects.CheckedCheckBox(DistributionContactsPageObjects.Active)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DF_ActiveCheckBox",
						"Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DF_ActiveCheckBox",
						"No");
			}

			if (agIsVisible(DistributionContactsPageObjects.CheckedCheckBox(
					DistributionContactsPageObjects.includeLiteraturedocumentinsubmission_label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeLiteraturedocumentinsubmissionCheckBox", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeLiteraturedocumentinsubmissionCheckBox", "No");
			}
			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.blindedReport_label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "BlindedReportCheckBox",
						"Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "BlindedReportCheckBox",
						"No");
			}
			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.autoRedistributeonMinorChange_label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AutoRedistributeonMinorChangeCkbox", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AutoRedistributeonMinorChangeCkbox", "No");
			}

			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.touchlessSubmission_label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"TouchlessSubmissionChbox", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"TouchlessSubmissionChbox", "No");
			}
			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.considerSimilarProducts_label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ConsiderSimilarProductsChbx", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ConsiderSimilarProductsChbx", "No");
			}

			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.IncludeR2R3)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "InCludeR2inR3CheckBox",
						"Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "InCludeR2inR3CheckBox",
						"No");
			}

			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.SimilarDevices)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SimilarDeviceCheckBox",
						"Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SimilarDeviceCheckBox",
						"No");
			}

			if (agIsVisible(DistributionContactsPageObjects
					.CheckedCheckBox(DistributionContactsPageObjects.SendFinalReport)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"SendFinalReportCheckBox", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"SendFinalReportCheckBox", "No");
			}
			if (agIsVisible(DistributionContactsPageObjects.MaximizeAnchor(scenarioName)) == true) {
				agClick(DistributionContactsPageObjects.MaximizeAnchor(scenarioName));
			}
			// Report
			if (agIsVisible(DistributionContactsPageObjects.AnchorTab(scenarioName)) == true) {
				Reports.ExtentReportLog("", Status.INFO,
						"Navigation to Anchor of Distribution Contact : " + scenarioName, true);
				agClick(DistributionContactsPageObjects.AnchorTab(scenarioName));
				agClick(DistributionContactsPageObjects.anchorName_Textbox);
				String anchorName_Textbox = agGetAttribute("value", DistributionContactsPageObjects.anchorName_Textbox);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AnchorName",
						anchorName_Textbox);

				agClick(DistributionContactsPageObjects.description_Textarea);
				String ANchordescription_Textarea = agGetAttribute("value",
						DistributionContactsPageObjects.description_Textarea);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AnchorDescription",
						ANchordescription_Textarea);

				agClick(DistributionContactsPageObjects.effectiveStartDateTextbox);
				String effectiveStartDateTextbox = agGetAttribute("value",
						DistributionContactsPageObjects.effectiveStartDateTextbox);
				if (effectiveStartDateTextbox.equalsIgnoreCase("")) {
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
							"EffectiveStartDate", "#skip#");
				} else {
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
							"EffectiveStartDate", effectiveStartDateTextbox);
				}

				agClick(DistributionContactsPageObjects.effectiveEndDateTextbox);
				String effectiveEndDateTextbox = agGetAttribute("value",
						DistributionContactsPageObjects.effectiveEndDateTextbox);
				if (effectiveEndDateTextbox.equalsIgnoreCase("")) {
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EffectiveEndDate",
							"#skip#");
				} else {
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EffectiveEndDate",
							effectiveEndDateTextbox);
				}

				agClick(DistributionContactsPageObjects.timeline_Textbox);
				String timeline_Textbox = agGetAttribute("value", DistributionContactsPageObjects.timeline_Textbox);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Timeline",
						anchorName_Textbox);

				agClick(DistributionContactsPageObjects.affiliateSubmissionDueDateTimeline_Textbox);
				String affiliateSubmissionDueDateTimeline_Textbox = agGetAttribute("value",
						DistributionContactsPageObjects.affiliateSubmissionDueDateTimeline_Textbox);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AffiliateSubmissionDueDateTimeline", anchorName_Textbox);

				String InclusionDD = agGetText(DistributionContactsPageObjects.IncusionLogicDD);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "RuleInclusionLogic",
						InclusionDD);

				// String ReportType =
				// agGetText(DistributionContactsPageObjects.SubmissionReportTypeDD);
				// XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className,
				// scenarioName, "ReportType",
				// ReportType);
				Reports.ExtentReportLog("", Status.INFO, "Read Distribution Contact :Ends ", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Read Distribution Contact :fails ", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is Write Distribution Contact Data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 30-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void WriteDistributionContactData(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Write Distribution Contact Started " + scenarioName, true);
			String className = "DistributionContact_ConfSetting";
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetStepExecutionDelay("3000");
			for (int j = 0; j < 4; j++) {
				if ((agIsVisible(DistributionContactsPageObjects.DistributionContact(scenarioName)) == true)) {
					agClick(DistributionContactsPageObjects.DistributionContact(scenarioName));
					break;
				} else {
					agClick(DistributionContactsPageObjects.NextPage);
				}

			}
			agSetStepExecutionDelay("2000");
			agWaitTillVisibilityOfElement(DistributionContactsPageObjects.VerifyDistributionContact);
			Reports.ExtentReportLog("", Status.INFO, "Distribution Contact : " + scenarioName + "found", true);
			agSetValue(DistributionContactsPageObjects.distributionContactName_Textbox,
					getTestDataCellValue(scenarioName, "DistributionContactName"));
			if (getTestDataCellValue(scenarioName, "Language").equalsIgnoreCase("")
					|| getTestDataCellValue(scenarioName, "Language").equalsIgnoreCase("-- Select --")) {

			} else {
				setDropDownValue(DistributionContactsPageObjects.language_Dropdown, scenarioName, "Language");
			}

			agSetValue(DistributionContactsPageObjects.description_Textarea,
					getTestDataCellValue(scenarioName, "Description"));

			if (getTestDataCellValue(scenarioName, "ActiveCheckBox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.Active));
			}

			if (getTestDataCellValue(scenarioName, "CorrespondenceMedium").equalsIgnoreCase("")
					|| getTestDataCellValue(scenarioName, "CorrespondenceMedium").equalsIgnoreCase("-- Select --")) {

			} else {
				setDropDownValue(DistributionContactsPageObjects.correspondenceMedium_Dropdown, scenarioName,
						"CorrespondenceMedium");
			}

			agSetValue(DistributionContactsPageObjects.correspondenceMediumDetails_Textbox,
					getTestDataCellValue(scenarioName, "CorrespondenceMediumDetails"));
			agSetValue(DistributionContactsPageObjects.replytoEmailAddress_Textbox,
					getTestDataCellValue(scenarioName, "ReplytoEmailAddress"));
			agSetValue(DistributionContactsPageObjects.correspondenceCCEmailAddress_Textbox,
					getTestDataCellValue(scenarioName, "CorrespondenceCCEmailAddress"));

			if (getTestDataCellValue(scenarioName, "SubmissionDueDateCalculationBasedOn").equalsIgnoreCase("")
					|| getTestDataCellValue(scenarioName, "SubmissionDueDateCalculationBasedOn")
							.equalsIgnoreCase("-- Select --")) {

			} else {
				setDropDownValue(DistributionContactsPageObjects.submissionDueDateCalculationBasedOn_Dropdown,
						scenarioName, "SubmissionDueDateCalculationBasedOn");
			}

			if (getTestDataCellValue(scenarioName, "AffiliateSubmissionDueDateCalculationBasedOn").equalsIgnoreCase("")
					|| getTestDataCellValue(scenarioName, "AffiliateSubmissionDueDateCalculationBasedOn")
							.equalsIgnoreCase("-- Select --")) {

			} else {
				setDropDownValue(DistributionContactsPageObjects.affiliateSubmissionDueDateCalculationBasedOn_Dropdown,
						scenarioName, "AffiliateSubmissionDueDateCalculationBasedOn");

			}

			if (getTestDataCellValue(scenarioName, "MailServer").equalsIgnoreCase("")
					|| getTestDataCellValue(scenarioName, "MailServer").equalsIgnoreCase("-- Select --")) {

			} else {
				setDropDownValue(DistributionContactsPageObjects.mailServer_Dropdown, scenarioName, "MailServer");
			}

			if (getTestDataCellValue(scenarioName, "VariableContactCheckBox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.VariableContact));
			}

			if (getTestDataCellValue(scenarioName, "AllowSingleEmailSubmissionCheckBox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects
						.checkBoxLeftOf(DistributionContactsPageObjects.allowSingleEmailSubmission_label));
			}

			if (getTestDataCellValue(scenarioName, "AllowBackReportingCheckBox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.allowBackReporting_label));
			}

			if (getTestDataCellValue(scenarioName, "SenderCommentsCheckBox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.senderComments_label));
			}

			if (getTestDataCellValue(scenarioName, "EventDescriptionCheckBox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.eventDescription_label));
			}
			if (getTestDataCellValue(scenarioName, "StoreLocalDatainLSMVCheckBox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.storeLocalDatainLSMV_label));
			}
			if (getTestDataCellValue(scenarioName, "SpainStateAccessCheckBox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.spainStateAccess_label));
			}
			if (getTestDataCellValue(scenarioName, "LocalLabelingAccessCheckBox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.localLabelingAccess_label));
			}
			if (getTestDataCellValue(scenarioName, "AllowICSRattachmentsCheckBox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.allowICSRattachments_label));
			}

			if (getTestDataCellValue(scenarioName, "SummaryandReporterCommentsAccessCBox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects
						.checkBoxLeftOf(DistributionContactsPageObjects.summaryandReporterCommentsAccess_label));
			}

			if (getTestDataCellValue(scenarioName, "SummaryandReporterCommentsAccessCBox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects
						.checkBoxLeftOf(DistributionContactsPageObjects.summaryandReporterCommentsAccess_label));
			}
			if (getTestDataCellValue(scenarioName, "LocalApprovalAcessCheckBox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.LocalApprovalAccess_label));
			}
			agClick(DistributionContactsPageObjects.MaximizeContact(scenarioName));
			agWaitTillVisibilityOfElement(DistributionContactsPageObjects.Format);
			agClick(DistributionContactsPageObjects.Format);

			if (agIsVisible(DistributionContactsPageObjects.ConfirmPopUp) == true) {
				agClick(DistributionContactsPageObjects.ConfirmYesBTn);
			}
			Reports.ExtentReportLog("", Status.INFO, "Navigate to Distribution Contact : " + scenarioName + "Format ",
					true);

			agSetValue(DistributionContactsPageObjects.formatDisplayName_Textbox,
					getTestDataCellValue(scenarioName, "FormatDisplayName"));

			agSetValue(DistributionContactsPageObjects.description_Textarea,
					getTestDataCellValue(scenarioName, "Formatdescription"));

			if (getTestDataCellValue(scenarioName, "DF_ActiveCheckBox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.Active));
			}

			if (getTestDataCellValue(scenarioName, "DF_Format").equalsIgnoreCase("")
					|| getTestDataCellValue(scenarioName, "DF_Format").equalsIgnoreCase("-- Select --")) {

			} else {
				setDropDownValue(DistributionContactsPageObjects.format_Dropdown, scenarioName, "Format");

			}

			if (getTestDataCellValue(scenarioName, "DF_ReportMedium").equalsIgnoreCase("")
					|| getTestDataCellValue(scenarioName, "DF_ReportMedium").equalsIgnoreCase("-- Select --")) {

			} else {
				setDropDownValue(DistributionContactsPageObjects.reportMedium_Dropdown, scenarioName, "ReportMedium");
			}

			if (getTestDataCellValue(scenarioName, "OLTConfiguration").equalsIgnoreCase("")
					|| getTestDataCellValue(scenarioName, "OLTConfiguration").equalsIgnoreCase("-- Select --")) {

			} else {
				setDropDownValue(DistributionContactsPageObjects.OLTConfiguration_Dropdown, scenarioName,
						"OLTConfiguration");
			}
			agSetValue(DistributionContactsPageObjects.ExpediteTimeline,
					getTestDataCellValue(scenarioName, "DF_ExpeditedTimeLine"));

			if (getTestDataCellValue(scenarioName, "XMLDocType").equalsIgnoreCase("")
					|| getTestDataCellValue(scenarioName, "XMLDocType").equalsIgnoreCase("-- Select --")) {

			} else {
				setDropDownValue(DistributionContactsPageObjects.XMLDocType_Dropdown, scenarioName, "XMLDocType");
			}

			if (getTestDataCellValue(scenarioName, "MessageType").equalsIgnoreCase("")
					|| getTestDataCellValue(scenarioName, "DF_DataPrivacy").equalsIgnoreCase("-- Select --")) {

			} else {
				setDropDownValue(DistributionContactsPageObjects.MessageType_Dropdown, scenarioName, "MessageType");
			}

			if (getTestDataCellValue(scenarioName, "DF_SubmissionWorkflow").equalsIgnoreCase("")
					|| getTestDataCellValue(scenarioName, "DF_SubmissionWorkflow").equalsIgnoreCase("-- Select --")) {

			} else {
				setDropDownValue(DistributionContactsPageObjects.submissionWorkflow_Dropdown, scenarioName,
						"SubmissionWorkflow");
			}

			if (getTestDataCellValue(scenarioName, "DF_DataPrivacy").equalsIgnoreCase("")
					|| getTestDataCellValue(scenarioName, "DF_DataPrivacy").equalsIgnoreCase("-- Select --")) {

			} else {

				setDropDownValue(DistributionContactsPageObjects.dataPrivacy_Dropdown, scenarioName, "DataPrivacy");
			}

			if (getTestDataCellValue(scenarioName, "IncludeLiteraturedocumentinsubmissionCheckBox")
					.equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects
						.checkBoxLeftOf(DistributionContactsPageObjects.includeLiteraturedocumentinsubmission_label));
			}

			if (getTestDataCellValue(scenarioName, "BlindedReportCheckBox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.blindedReport_label));
			}

			if (getTestDataCellValue(scenarioName, "AutoRedistributeonMinorChangeCkbox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects
						.checkBoxLeftOf(DistributionContactsPageObjects.autoRedistributeonMinorChange_label));
			}
			if (getTestDataCellValue(scenarioName, "TouchlessSubmissionChbox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.touchlessSubmission_label));
			}
			if (agIsVisible(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.IncludeR2R3)) == true) {
				if (getTestDataCellValue(scenarioName, "InCludeR2inR3CheckBox").equalsIgnoreCase("Yes")) {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.IncludeR2R3));
				}
			}
			if (agIsVisible(
					WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.SimilarDevices)) == true) {
				if (getTestDataCellValue(scenarioName, "SimilarDeviceCheckBox").equalsIgnoreCase("Yes")) {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.SimilarDevices));
				}
			}
			if (getTestDataCellValue(scenarioName, "SendFinalReportCheckBox").equalsIgnoreCase("Yes")) {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(DistributionContactsPageObjects.SendFinalReport));
			}
			if (agIsVisible(DistributionContactsPageObjects.MaximizeAnchor(scenarioName)) == true) {
				agClick(DistributionContactsPageObjects.MaximizeAnchor(scenarioName));
			}
			// Report
			if (agIsVisible(DistributionContactsPageObjects.AnchorTab(scenarioName)) == true) {
				Reports.ExtentReportLog("", Status.INFO,
						"Navigation to Anchor of Distribution Contact : " + scenarioName, true);
				agClick(DistributionContactsPageObjects.AnchorTab(scenarioName));
				if (agIsVisible(DistributionContactsPageObjects.ConfirmPopUp) == true) {
					agClick(DistributionContactsPageObjects.ConfirmYesBTn);
				}
				agSetValue(DistributionContactsPageObjects.anchorName_Textbox,
						getTestDataCellValue(scenarioName, "AnchorName"));
				agSetValue(DistributionContactsPageObjects.description_Textarea,
						getTestDataCellValue(scenarioName, "AnchorDescription"));
				agSetValue(DistributionContactsPageObjects.effectiveStartDateTextbox,
						getTestDataCellValue(scenarioName, "EffectiveStartDate"));
				agSetValue(DistributionContactsPageObjects.effectiveEndDateTextbox,
						getTestDataCellValue(scenarioName, "EffectiveEndDate"));
				agSetValue(DistributionContactsPageObjects.timeline_Textbox,
						getTestDataCellValue(scenarioName, "Timeline"));
				agSetValue(DistributionContactsPageObjects.affiliateSubmissionDueDateTimeline_Textbox,
						getTestDataCellValue(scenarioName, "AffiliateSubmissionDueDateTimeline"));
				if (getTestDataCellValue(scenarioName, "ReportType").equalsIgnoreCase("")
						|| getTestDataCellValue(scenarioName, "ReportType").equalsIgnoreCase("-- Select --")) {

				} else {

					setDropDownValue(DistributionContactsPageObjects.reportType_Dropdown, scenarioName, "ReportType");
				}

				if (getTestDataCellValue(scenarioName, "RuleInclusionLogic").equalsIgnoreCase("")
						|| getTestDataCellValue(scenarioName, "RuleInclusionLogic").equalsIgnoreCase("-- Select --")) {

				} else {
					setDropDownValue(DistributionContactsPageObjects.ruleInclusionLogic_Dropdown, scenarioName,
							"RuleInclusionLogic");
				}
				Reports.ExtentReportLog("", Status.INFO, "Write Distribution Contact :Ends ", true);

			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Write Distribution Contact :fails ", true);
		}
	}
}
