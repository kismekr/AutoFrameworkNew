package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public abstract class ReporterPageObjects {

	public static String PrimaryReporterCheckBox = "xpath#//div[contains(@class,'agDynamicContent row ng-star-inserted')]//div[1]//span[1]//span[1]//p-checkbox[1]//div[1]//div[2]";
	public static String ReporterLastName = "xpath#//input[@id='adverseEventNew:reporterTable:idN10B93105108']";
	public static String PrimarySourceRegulatoryRadioButton_Yes = "xpath#//input[@id='adverseEventNew:reporterTable:regulatoryPurposeCode-orderByDisplayOrder-4:0']/following::div/span";
	public static String PrimarySourceRegulatoryRadioButton_No = "xpath#//input[@id='adverseEventNew:reporterTable:regulatoryPurposeCode-orderByDisplayOrder-4:1']/following::div/span";

}
