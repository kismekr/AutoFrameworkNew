package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public abstract class MedicalReviewFormPageObjects {

	public static String moreOptionsHover = "xpath#//span[contains(@class,'InqList-tooltip' )]/a[text()='More Actions']";
	public static String switchToForm = "xpath#//span/div/a[text()='Switch To Form']";
	
	public static String formType = "xpath#//div/ul/li/a[text()='%formType%']";
	public static String formType_FullDataEntry = "FULL DATA ENTRY FORM";
	public static String formType_SimpleIntake = "SIMPLE INTAKE FORM";
	public static String formType_MedicalReview = "MEDICAL REVIEW";
	
	public static String ackTitle = "xpath#//div/span[@id='ui-id-2']";
	public static String ackMessage1 = "xpath#//div/label[contains(@class,'validationDialogSpanSty')][contains(text(),'successfully')][1]";
	public static String ackMessage2 = "xpath#//div/label[contains(@class,'validationDialogSpanSty')][contains(text(),'successfully')][2]";
	public static String ackOK_Btn = "xpath#//div/button[text()='OK']";

	public static String TitleBar = "xpath#//div/p-header[text()='%tabHeader%']";
	public static String titleBar_ProductsEvents = " Products/Events ";
	public static String titleBar_MedicalHistory = " Medical History ";
	public static String titleBar_Pregnancy = " Pregnancy ";
	public static String titleBar_CurrentPregnancyOutcomes  = " Current Pregnancy Outcomes ";
	
	public static String productsEvents_Description = "xpath#(//tbody/tr/td/a[2])[1]";
	public static String productsEvents_Characterization = "xpath#//tbody/tr/td/a[text()='Auto-DOLO FRESH']/following::td[1]/div";
	
	public static String productsEvents_ExpandIcon = "xpath#//tbody/tr/td/a[text()='%prodName%']/preceding::a/i";
	public static String labelling_DropDown = "xpath#//tbody/tr/td/a[text()='Auto-DOLO FRESH']/following::tr[2]/td/p-dropdown/div";
	
	//Locator by ProdName and #td
	public static String tBodyHeaders = "xpath#//tbody/tr/td/a[text()='%ProdName%']/../../following::tr[contains(@class,'MREventsHeaderSty')]/td";
	public static String tBodyHeadersByNumber = "xpath#//tbody/tr/td/a[text()='%ProdName%']/../../following::tr[contains(@class,'MREventsHeaderSty')]/td[%num%]";
	public static String tBodyvalueByNumber = "xpath#//tbody/tr/td/a[text()='%ProdName%']/../../following::tr[contains(@class,'MREventsBodySty')]/td[%num%]";
	
	public static String causalityDropDown = "xpath#//tbody/tr/td/a[text()='%ProdName%']/../../following::tr[contains(@class,'MREventsBodySty')]/td[%num%]/span//span[text()='--Select--']";
	public static String causalityDropDown_value = "xpath#//ul/li/div/span[text()='Possible ']";
	
	public static String labelling_SelectParent = "xpath#//td/p-dropdown/div/div/select[@name='eventsLabeling_0_0']/../..";
	public static String labelling_Select = "xpath#//li/div/span[text()='Labelled ']";
	public static String labellingCountry_CBState = "xpath#//td/p-dropdown/div/div/select[@name='eventsLabeling_0_0']/following::td[1]/p-checkbox/div/div";
	public static String labellingCountry_CheckBox = "xpath#//td/p-dropdown/div/div/select[@name='eventsLabeling_0_0']/following::td[1]/p-checkbox/div/div/span";
	
	//Products-Events Table
	public static String labellingVersion_THeader = "xpath#//tr[contains(@class,'MREventsHeaderSty')]/td[text()='Labeling Version']";
	public static String assessRelaionship_THeader = "xpath#//tr[contains(@class,'MREventsHeaderSty')]/td[text()='Assess Relationship ']";

	// ISP-V0067 Validation related
	public static String formTypeLocator = "xpath#//li/a[contains(text(),'%formType%')]";
	
	/**********************************************************************************************************
	 * @Objective: 
	 * @author: Shamanth S
	 * @InputParameters: Scenario Name
	 * @Date : 04-Jan-2021
	 **********************************************************************************************************/
	public static String tBodyHeaders(String prodName) {
		String value = tBodyHeaders;
		value = value.replace("%ProdName%", prodName);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: 
	 * @author: Shamanth S
	 * @InputParameters: Scenario Name
	 * @Date : 22-Dec-2020
	 **********************************************************************************************************/
	public static String formTypeLocator(String formType) {
		String value = formTypeLocator;
		value = value.replace("%formType%", formType);
		return value;
	}
	
	/**********************************************************************************************************
	 * @Objective: 
	 * @author: Shamanth S
	 * @InputParameters: Scenario Name
	 * @Date : 04-Jan-2021
	 **********************************************************************************************************/
	public static String sectionTitleBar(String sectionTitle) {
		String value = TitleBar;
		value = value.replace("%tabHeader%", sectionTitle);
		return value;
	}
	
	/**********************************************************************************************************
	 * @Objective: 
	 * @author: Shamanth S
	 * @InputParameters: Scenario Name
	 * @Date : 04-Jan-2021
	 **********************************************************************************************************/
	public static String productsEvents_ExpandIcon(String prodName) {
		String value = productsEvents_ExpandIcon;
		value = value.replace("%prodName%", prodName);
		return value;
	}
	
	/**********************************************************************************************************
	 * @Objective: 
	 * @author: Shamanth S
	 * @InputParameters: Scenario Name
	 * @Date : 04-Jan-2021
	 **********************************************************************************************************/
	public static String tBodyHeadersByNumber(String prodName, int num) {
		String value = tBodyHeadersByNumber;
		value = value.replace("%ProdName%", prodName);
		String numString = String.valueOf(num);
		value = value.replace("%num%", numString);
		return value;
	}
	
	/**********************************************************************************************************
	 * @Objective: 
	 * @author: Shamanth S
	 * @InputParameters: Scenario Name
	 * @Date : 04-Jan-2021
	 **********************************************************************************************************/
	public static String tBodyvalueByNumber(String prodName, int num) {
		String value = tBodyvalueByNumber;
		value = value.replace("%ProdName%", prodName);
		String numString = String.valueOf(num);
		value = value.replace("%num%", numString);
		return value;
	}
	
	
	/**********************************************************************************************************
	 * @Objective: 
	 * @author: Shamanth S
	 * @InputParameters: Scenario Name
	 * @Date : 04-Jan-2021
	 **********************************************************************************************************/
	public static String causalityDropDown(String prodName, int num) {
		String value = causalityDropDown;
		value = value.replace("%ProdName%", prodName);
		String numString = String.valueOf(num);
		value = value.replace("%num%", numString);
		return value;
	}
}
