package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.DataAssessmentOperations;
import com.arisglobal.framework.components.lsmv.L10_1_1.FDE_Events;
import com.arisglobal.framework.components.lsmv.L10_1_1.FDE_General;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ResolveValidationsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ValidationPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DataBaseOperations;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.aventstack.extentreports.Status;

public class ResolveValidations extends ToolManager {

	/**********************************************************************************************************
	 * @Objective: Resolving validations
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 01-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void resolveValidation() {
		try {
			if (agIsExists(ValidationPageObjects.validationsList)) {
				Reports.ExtentReportLog("", Status.INFO, "Validation Exists", true);
				// String objectLabel = null;

				List<WebElement> ElementCount = agGetElementList(ValidationPageObjects.validationsList);
				int validationCount = 1;
				for (int i = 0; i < ElementCount.size(); i++) {
					String field = null;
					try {
	
						String validationDescription = ElementCount.get(i).getText();
						System.out.println("validationDescription:: " + validationDescription);

						// agClick(ValidationPageObjects.selectValidation(validationDescription));
						agClick(ResolveValidationsPageObjects.validationDescription(validationCount));
						Thread.sleep(5000);
						String currentValidation = agGetText(
								ResolveValidationsPageObjects.validationDescription(validationCount));
						System.out.println("currentValidation: " + currentValidation);
						if (!currentValidation.equals(validationDescription)) {
							validationCount = validationCount + 1;
						}

						agClick(ResolveValidationsPageObjects.validationDescription(validationCount));
						Thread.sleep(3000);
						// Open validation dialog
						agClick(ResolveValidationsPageObjects.openValidationDialog);

						if (validationDescription.contains("Data Assessment is required for completing the activity")) {
							DataAssessmentOperations.dataAssessAsNew("", "");
							validationCount = validationCount + 1;
							agClick(ResolveValidationsPageObjects.closeValidationDialog);
							continue;
						}

						// Get active tab name
						String activeTab = agGetText(ResolveValidationsPageObjects.activeTab);
						String[] activeTabArray = null;

						if (activeTab.contains("[")) {
							activeTabArray = activeTab.split("(s)");
							activeTab = activeTabArray[0].trim() + "s)";

						}
						agClick(ResolveValidationsPageObjects.closeValidationDialog);
						Connection dbCon = null;
						int rowCount = 0;

						
						dbCon = DataBaseOperations.getDBConnection("lsmv_validations_model", Constants.DB_UserName,
								Constants.DB_Password);
						ResultSet rs = DataBaseOperations.performRead(dbCon,
								"SELECT * FROM  validations_controller WHERE module = '" + activeTab + "'");
						// Intake and Assessment

						rs.last();
						rowCount = rs.getRow();
						if (rs.getRow() > 0) {
							rs.beforeFirst();
							for (int j = 0; j < rowCount; j++) {
								rs.next();
								String objectLabel = rs.getString("ObjectLabel");
								if(validationDescription.contains("Durg")) {
									validationDescription=validationDescription.replace("Durg", "Drug");
									System.out.println(validationDescription);
								}
								if (validationDescription.toLowerCase().contains(objectLabel.toLowerCase())) {
									field = objectLabel;
									System.out.println("field: " + field);
									break;
								}

								else if (field == null) {
									int presenceOfsubString = 0;
									String[] array = objectLabel.split(" ");
									for (int k = 0; k < array.length; k++) {
										int index = validationDescription.indexOf(array[k]);
										if (index > 0) {
											presenceOfsubString = presenceOfsubString + 1;
											if (array.length == presenceOfsubString) {
												field = objectLabel;
												System.out.println("field: " + field);
												System.out.println("all the characters are present");
											}
										}
									}

								}

							}

						}

						ResultSet rsObjValue = DataBaseOperations.performRead(dbCon,
								"SELECT * FROM  validations_controller WHERE module = '" + activeTab
										+ "' AND ObjectLabel = '" + field + "'");
						rsObjValue.beforeFirst();
						rsObjValue.next();
						String testdataValue = rsObjValue.getString("ObjectData");
						String objType = rsObjValue.getString("ObjectType");
						
						if (objType.equalsIgnoreCase("DropDown")) {
							FDE_General.setDropDownValue(field, testdataValue);
						} else if (objType.equalsIgnoreCase("RadioButton")) {
							agClick(ResolveValidationsPageObjects.radioButton(field, testdataValue));
						} else if (objType.equalsIgnoreCase("TextBox")) {
							agSetValue(ResolveValidationsPageObjects.textbox(field), testdataValue);
						} else if (objType.equalsIgnoreCase("LookupTextbox")) {

							switch (field) {
							case "Contact":
								//if (validationDescription.contains("At least one Contact is required for the AE Case")) {
									FDE_General.addContact_FDEForm("PairwiseTesting_1");
									break;
									
							case "Event MedDRA":
								FDE_Events.set_EventMedDRALLTCode(testdataValue);
								break;
								
							case "Product description":
								FDE_Products.setProductInformation("PairwiseTesting_1");
								break;
							}
						}
				
					}
						
						catch (Exception e) {
						validationCount = validationCount + 1;
						e.printStackTrace();
						Reports.ExtentReportLog("", Status.FAIL, "Failed to resolve validation", true);
						continue;
					}
				}
					
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Failed to resolve validation", true);
		}
	}

}
