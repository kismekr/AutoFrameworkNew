package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FDE_StudyLookUpPageObjects {

	public static String setData_Textfields = "xpath#//p-panel[@header='SEARCH CRITERIA']/div//label[contains(text(),'%s')]/following-sibling::input";
	public static String buttons = "xpath#//button[@label='%s']/span";
	public static String radioButton = "xpath#//td[contains(text(),'%s')]/ancestor::tr/td/p-tableradiobutton/div/child::div/span";

	// Label Names
	public static String projectNo_TextField = "xpath#//input[@name='Project']";
	public static String studyNo_TextField = "xpath#//input[@name='study']";
	public static String search_button = "xpath#//button/span[text()='Search']";
	public static String clear_button = "Clear";
	public static String cancel_button = "Cancel";
	public static String ok_button = "xpath#//div[contains(@class,'col-md-12 searchOkbtn tblserchbtn ng-star-inserted')]/button/span[text()='OK']";
	public static String Validation = "xpath#//th[contains(text(),'Study No')]";
	public static String newSearchBtn = "xpath#//button/span[text()='Search']";

	/**********************************************************************************************************
	 * Objective:The below method is created to set data in text field by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String setData_Textfields(String runTimeLabel) {
		String value = setData_Textfields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select radio button by passing study
	 * number at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String radioButton(String runTimeLabel) {
		String value = radioButton;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created click buttons by passing label name at
	 * runtime. Input Parameters: ColumnName Scenario Name Output Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String buttons(String runTimeLabel) {
		String value = buttons;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

}
