package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FDE_SubmissionTrackingPageObjects

{
	public static String AddDistContact_Btn = "xpath#//div/span[text()='Add']";

	// Distribution Contacts Lookup
	public static String Contact_Textbox = "xpath#//label[text()='Contact']//following-sibling::input[@id='discontact']";
	public static String ReportFormat_Textbox = "xpath#//label[text()='Report Format Name']//following-sibling::input[@id='reportFormatName']";
	public static String partnerType_Dropdown = "xpath#//label[text()='Partner Type']//following-sibling::select[@id='Partnertype']";
	public static String unitType_Dropdown = "xpath#//label[text()='Unit Type']//following-sibling::select[@id='authority']";
	public static String format_Dropdown = "xpath#//label[text()='Format']//following-sibling::select[@id='formatetype']";
	public static String report_Dropdown = "xpath#//label[text()='Report ']//following-sibling::select[@id='reportType']";
	public static String searchContact_Btn = "xpath#//button[@id='searchsubmissionLookupData']";
	public static String selectContact_Chkbox = "xpath#//table[@class='lookupjsondistbutiontab']//tr//input[@class='subLookupCheckBox']";
	public static String okContact_Btn = "xpath#//a[contains(@onclick,'populateSubmissionListing')]";
	public static String cancelContact_Btn = "xpath#//a[contains(@onclick,'manulSubmissionDialogClose')]";
	public static String select_Contact = "xpath#//label[text()='%s%']//..//..//preceding-sibling::div[2]//div[text()='{a}']//..//..//span[contains(@class,'chk')]";

	public static String moreOptions_Btn = "xpath#//span[contains(@class,'btnbar-more-opt')][text()='More Action']";
	public static String redistPlaced_label = "xpath#//label[text()='Redistribution Request Placed']";
	public static String redistPlaced_Ok = "xpath#//label[text()='Redistribution Request Placed']//following-sibling::div//a[text()='Ok']";

	public static String filter_Btn = "xpath#//span[contains(@class,'quick-filter-icon')]";
	public static String click_dropdown = "xpath#//div[@id='distuinnerhtml'][@class='lsmv-grid-panel mainGridCmp']//div[text()='%s']/parent::div//select";
	public static String select_value = "xpath#//select[contains(@fieldid,'FK_DDC_CONTACT_ID')]/child::option[text()='%s']";

	public static String contactName_Dropdown = "Contact Name";

	public static String distpaginator = "xpath#//span[@class='lsmv-pager-info']";

	public static String automatic_Btn = "xpath#//span[text()='A']";
	public static String ruleName = "xpath#//div[@fieldid='ruleName'][span[text()='%s%']]";
	public static String close_Btn = "xpath#//span[@id='clCancelBtnId']";
	// public static String refresh_Btn =
	// "xpath#//span[@class='lsmv-refresh-icon'][text()='Refresh']";
	public static String refresh_Btn = "xpath#//span[@class='lsmv-refresh-icon'][text()='List of Distribution Contacts']";
	public static String listGenerated_msg = "xpath#//label[@class='statusresponse']";
	public static String export_Btn = "xpath#//span[@id='clExportBtnId']";
	public static String paginator = "xpath#//div[@targetpanelid='viewDistConactsBody']/child::div/following-sibling::div/span[@class='lsmv-pager-info']";
	public static String recCount = "xpath#//div[@class='gridSearchBarRight']/div/span[@class='lsmv-pager-info']";
	public static String distFailStatus_msg = "xpath#//i[text()='Distribution Failed']";
	public static String reportFailStatus_msg = "xpath#//label[text()='Report Generation Failed ']";
	public static String listSelect_checkbox = "xpath#//div[@id='distuinnerhtml'][@class='lsmv-grid-panel mainGridCmp']/div[@class='lsmv-grid-row']/span";
	public static String moreOptionsHover = "xpath#//span[contains(@class,'more-opt')]";
	public static String moreOptionsNavigation = "xpath#//span[contains(@class,'tooltip')][@style='float:none;z-index:1;']/div/div/following-sibling::div/a[text()='%s']";
	public static String NotDistributedStatus = "xpath#//label[text()='%s']/ancestor::div[@class='lsmv-grid-row']//div[text()='Not to be Distributed']";
	public static String ExclusionListStatusRemoval = "xpath#//label[text()='%s']/ancestor::div[@class='lsmv-grid-row']//label[text()='Exclusion List']";
	public static String distribution_Btn = "xpath#//span[contains(text(),'Distribute')]";
	public static String distribution_label = "xpath#//label[text()='Redistribution Request Placed']";
	public static String removalReason_txt = "xpath#//input[@fieldid='removalReason']";
	public static String distributionConfirm_msg = "xpath#//div[@aria-hidden='false']//label[contains(text(),'Distribution Request Placed')]";

	public static String distconfirmationOkBtn = "xpath#//div[@aria-hidden='false']//a[text()='Ok']";

	public static String xmlGeneration_close = "xpath#//div[@id='lsmv-comments-close'][contains(text(),'X')][@onclick='closeErrorPopup()']";
	public static String redistributionStatus_msg = "xpath#//div[text()='Distributed to Submission Module']";
	// public static String submittedStatus_msg ="xpath#//div[text()='Submitted
	// Successfully']";
	public static String submittedStatus_msg = "xpath#//div[text()='Submission Successful']";
	// public static String distributionStatus_msg
	// ="xpath#((//div[@id='distuinnerhtml'])[2]/div/following-sibling::div/child::div[@fieldid='submissionStatus']/div)[1]";
	public static String distributionStatus_msg = "xpath#//div[text()='Distributed to Submission Module']";
	public static String loading = "xpath#//div[@class='mask-message-div']";
	public static String filterSpinner = "xpath#//div[@class='lsmv-spinner-cmp lsmv-spinner-icon']";
	public static String distributedcontactstatus = "xpath#//div[text()='Need not be Submitted']";

	public static String listofProposedGenerated_msg = "xpath#//div[@id='viewDistConactsBody']/div[2]";

	public static String docName = "xpath#(//div[@fieldid='docName']//div[contains(text(),'%filename%')])[1]";
	public static String docNameList = "xpath#(//div[@id='SubTrackDocumentsSection']//div[@class='lsmv-grid-row']/div[@fieldid='docName']//div)";
	public static String document = "xpath#(//div[@id='SubTrackDocumentsSection']//div[@class='lsmv-grid-row']/div[@fieldid='docName']//div)[%count%]";

	public static String docincluded = "xpath#(//div[@id='submissionMsgDocsGrid']//div[@class='lsmv-grid-row']//div[@fieldid='docHeldBySenderIncluded']/div)[%count%]";

	public static String eventDesc = "xpath#//textarea[@fieldid='eventDescription']";
	public static String localNarrativeLabel = "xpath#//label[contains(text(),'Local Narratives')]";

	public static String docIncluded(String count) {
		String value = docincluded.replace("%count%", count);
		return value;
	}

	public static String columnHeader(String count) {
		String value = document.replace("%count%", count);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click on link Input Parameters:
	 * Value Parameters:
	 * 
	 * @author:Pooja S Date :18-Nov-2020 Updated by and when
	 **********************************************************************************************************/
	public static String linkText(String value) {
		String actualValue = docName;
		String result = actualValue.replace("%filename%", value);
		return result;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select distribution contact from
	 *             List of Distribution Contacts in Submission tracking screen.
	 * @InputParameters: contName , format
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 13-February-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String select_Contact(String contName, String format) {
		String value = select_Contact;
		value = value.replace("%s", contName);
		String value2 = value.replace("{a}", format);

		return value2;
	}

	// Contact Delete
	public static String SubmissionTrackingBtn = "xpath#//span[contains(text(),'Submission Tracking')]//ancestor::a[@id='ui-tabpanel-7-label']";
	public static String DropDeleteBtn = "xpath#//span[contains(text(),'Drop/Delete')]";
	public static String SubmissionConfirmMsg = "xpath#//div[@aria-hidden='false']//label[contains(text(),'Submission Records Dropped/Deleted')]";
	public static String ConfirmationOkBtn = "xpath#//div[@aria-hidden='false']//a[text()='Ok']";
	public static String PageNxtBtn = "xpath#(//div[@class='lsmv-grid-pager-class']//span[@class='lsmv-last-page-icon'])[1]";
	public static String NxtTableBtn = "xpath#(//div[@class='lsmv-grid-pager-class']//span[@onclick='lsmvGridUtils.loadNextPageOfGrid(this)'])[1]";
	public static String FirstTable = "xpath#(//div[@class='lsmv-grid-pager-class']//span[@class='lsmv-first-page-icon'])[1]";
	public static String Automation_contactName = "xpath#//label[text()='%s']";
	public static String Automation_NonE2B_CheckBox = "xpath#//label[text()='%s']/ancestor::div[@fieldid='unitName']/parent::div//span[@class='lsmv-grid-row-sel-chk lsmv-grid-sel-unchk']";
	public static String RemovalReason = "xpath#//label[text()='%s']/ancestor::div[@fieldid='unitName']/parent::div//div[@fieldid='removalReason']//input";
	public static String NullificationContact = "xpath#//label[text()='%s']/ancestor::div[@fieldid='unitName']/preceding-sibling::div[@fieldid='failedDocDetails']";
	public static String isE2BEnabled = "xpath#//label[text()='%s']/ancestor::div[@class='lsmv-grid-row']//span[text()='E2B']/parent::div[@fieldid='format']";
	public static String isE2BR2FormatName = "xpath#//label[text()='%s']/ancestor::div[@class='lsmv-grid-row']//span[starts-with(text(),'E2B_R2_')]/parent::div[@fieldid='formatName']";
	public static String isE2BR3FormatName = "xpath#//label[text()='%s']/ancestor::div[@class='lsmv-grid-row']//span[starts-with(text(),'E2B_R3_')]/parent::div[@fieldid='formatName']";
	public static String DistributionFailedStatus = "xpath#//label[text()='%s']/ancestor::div[@class='lsmv-grid-row']/div[@fieldid='submissionStatus']//a[@class='failedDocs']";

	public static String ValidationMsg = "xpath#(//div[@fieldid='validation']//div[@class='lsmv-grid-col-adjust '])[1]";
	public static String TagId = "xpath#(//div[@fieldid='tagId']//div[@class='lsmv-grid-col-adjust '])[1]";
	public static String DistributionFailureCloseBtn = "xpath#//div[@id='viewDistConactsMain']//span[text()='Close']";
	public static String deleteValidationMsg = "xpath#//div[@class='lsmv-error-popup']/div/span[2]";
	public static String deleteValidationClose = "xpath#//div[@onclick='closeErrorPopup()']";
	public static String cancelHover = "xpath#//a[text()='Cancel']";

	public static String ContactName(String label) {
		String value = Automation_contactName.replace("%s", label);
		return value;
	}

	public static String CheckBox(String label) {
		String value = Automation_NonE2B_CheckBox.replace("%s", label);
		return value;
	}

	public static String RemovalReason(String label) {
		String value = RemovalReason.replace("%s", label);
		return value;
	}

	public static String NullificationContact(String label) {
		String value = NullificationContact.replace("%s", label);
		return value;
	}

	public static String IsE2BReportFormat(String label) {
		String value = isE2BEnabled.replace("%s", label);
		return value;
	}

	public static String IsE2BR2FormatName(String label) {
		String value = isE2BR2FormatName.replace("%s", label);
		return value;
	}

	public static String IsE2BR3FormatName(String label) {
		String value = isE2BR3FormatName.replace("%s", label);
		return value;
	}

	public static String DistributionFailedStatus(String label) {
		String value = DistributionFailedStatus.replace("%s", label);
		return value;
	}

	// Documents
	public static String documents = "xpath#//span[@id='documentsSection'][text()='Documents']";

	// Add and Delete Document
	public static String AddDocument = "xpath#//input[@id='adverseEventNew:sumissionTrackNewUploadDocCmp_input']";
	public static String AddDocumentBtn = "xpath#//span[@id='addDistCntNewDocBtnId']";
	public static String AddCaseDocumentBtn = "xpath#//span[@id='addCaseDocBtnId']";
	public static String DeleteDocumentBtn = "xpath#//span[@id='deleteDistCntDocBtnId']";
	public static String DocumentCheckBox = "xpath#//div[text()='File Name']/ancestor::div[@id='caseLevelDocumentRefMain']//div[@class='lsmv-grid-header']//span[@class='lsmv-grid-sel-all-chk lsmv-grid-sel-unchk']";
	public static String SelectBtn = "xpath#//span[@id='selectCaseDocBtnId']";
	public static String CloseBtn = "xpath#//span[@id='caseLevelDocumentRegGrid_btn_1']";
	public static String NoRecordFoundMsg = "xpath#//div[contains(text(),' No records to display')]";
	public static String FilePresntChkbox = "xpath#(//div[@fieldid='documentList'])[2]/ancestor::div[@class='lsmv-grid-row']//span[@class='lsmv-grid-row-sel-chk lsmv-grid-sel-unchk']";

	/**********************************************************************************************************
	 * @Objective:The below method is created to click drop down in distribution
	 *                format.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Mythri Jain Date : 18-feb-2020 Updated by and when
	 **********************************************************************************************************/

	public static String clickdropdown(String runTimeLabel) {
		String value = click_dropdown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select dropdown value by passing
	 *                value at runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Mythri Jain Date : 18-feb-2020 Updated by and when
	 **********************************************************************************************************/

	public static String selectDropdownvalue(String runTimeLabel) {
		String value = select_value;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select value by passing value at
	 *                runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Mythri Jain Date : 18-feb-2020 Updated by and when
	 **********************************************************************************************************/
	public static String ruleNameText(String label) {
		String value = ruleName.replace("%s%", label);
		return value;
	}

	// List of Proposed Distributed Contacts
	public static String Paginatoricon = "xpath#//div[@class='lsmv-field-text']/following-sibling::div[@class='lsmv-grid-pager-class']";
	public static String DistributedPopUpNxtBtn = "xpath#(//div[@class='lsmv-grid-pager-class']//span[@class='lsmv-next-page-icon'])[2]";
	public static String DistributedPopUpPreviousBtn = "xpath#(//div[@class='lsmv-grid-pager-class']//span[@class='lsmv-first-page-icon'])[2]";

	public static String searchTextBox = "xpath#//div[@class='lsmv-field-text']/input[@placeholder='Search...'][contains(@title,'Receiver Contact')]";
	public static String SearchIcon = "xpath#//input[@placeholder='Search...']/preceding-sibling::span";
	public static String DistributioncontactName = "xpath#//div[text()='%s']";

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Distributed contact Name
	 *             from List of distributed Contacts in Submission tracking screen.
	 * @InputParameters: contName , format
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 18-February-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String DistributionContact(String label) {
		String value = DistributioncontactName.replace("%s", label);
		return value;

	}

	// Submission Tracking--> Distribution Contacts
	// public static String DisContactname_Link="xpath#//label[@submissionid='%s']";
	public static String DisDocheldbysender_label = "xpath#//div[text()='Document Held By Sender']";
	public static String SubmissionDoc_Checkbox = "xpath#//div[text()='File Name']/ancestor::div[@id='submissionMsgDocsGrid']//div[@class='lsmv-grid-header']//span[@class='lsmv-grid-sel-all-chk lsmv-grid-sel-unchk']";
	public static String SubmissionDoc_Checkbox1 = "xpath#//div[@fieldid='documentList']['%s']//preceding::span[@class='lsmv-grid-row-sel-chk lsmv-grid-sel-unchk']";
	public static String Delete_Tooltip = "xpath#//span[text()='Documents were Deleted Succesfully. ']";
	public static String deleteConfirmPOPupOkBtn = "xpath#//button[@id='confirmPopupOkBtn']";
	public static String deleteConfirmPOPUp = "xpath#//div[@id='confirmPopupMain']";
	public static String docUploadMsg = "xpath#//span[text()='Document Uploaded successfully']";

	// Submission Tracking IA[Informed Authority]

	public static String InformedAuthority_Label = "xpath#//span[text()='Informed Authority']";
	public static String CaseVersion_Label = "xpath#//label[text()='Case Version #']";
	public static String IA_Report_Medium = "Report Medium";
	public static String IA_Reporting_Status = "Reporting Status";
	public static String IA_Dropdown_Click = "xpath#//div[@class='form-group']/label[@for='discontact'][contains(text(),'%s')]/following-sibling::select";
	public static String IA_Input_Textbox = "xpath#//div[@class='form-group']/label[@for='discontact'][text()='%s']/following-sibling::input";
	public static String IA_Select_Value = "xpath#//select[contains(@class,'form-control inputCmpClass')]/child::option[text()='%s']";
	public static String IA_Followup_Final_Checkbox = "xpath#//div[@class='checkBoxInputCmpClass']/div/span[text()='%s']/preceding-sibling::input";
	public static String IA_DatePick_Icon = "xpath#//label[@for='discontact'][text()='%s']//following-sibling::input[@class='form-control inputCmpClass']//following-sibling::span[@class='calendarIcon']";
	public static String IA_Date_Textbox = "xpath#//label[text()='%s']//following-sibling::span[contains(@class, 'calendarIcon')]";
	public static String Followup_Correction = "Correction";
	public static String Followup_Addtional_Info = "Additional Info";
	public static String Followup_Responseto_AuthReq = "Response to Auth. Req";
	public static String Followup_Device_Eval = "Device Eval";
	public static String Followup_Reportsentto_Mfr = "Report Sent to Mfr?";
	public static String Followup_Reportsentto_FDA = "Report Sent to FDA?";
	public static String Final = "Final";
	public static String Date_Todaybtn = "xpath#//label[text()='%s']/parent::div//input[@value='Today']";
	public static String Nullification_Amendmentradiobtn = "xpath#//div[@class='radioInputCmpClass']//span[text()='%s']//preceding::input[@name='reportForNullifnOrAmend']";
	public static String Nullification_ReasonTextbox = "xpath#//textarea[@fieldid='reasonForNullifnOrAmend']";
	public static String LocalNarrative_Textbox = "xpath#//textarea[@fieldid='%s']";

	public static String IA_DateInformedLabel = "Date Informed";
	public static String IA_DecisionDateLabel = "Decision Date";
	public static String IA_AcknowledgementRecvDateLabel = "Acknowledgement Received Date";
	public static String IA_RefNo_RecvDate = "Reference No. Received Date";
	public static String IA_DateInf_Distrbutor = "Date Informed To Distributor";
	public static String NullficationLabel = "Nullification";
	public static String AmendementLabel = "Amendment";
	public static String sendersComments_label = "companyRemarks";
	public static String EventDesc_label = "eventDescription";
	public static String CaseSummary_label = "caseSumAndRepComments";
	public static String ReporterInfo_AuthRadiobtn = "xpath#//div[@class='radioInputCmpClass']//span[text()='Yes']//preceding::input[@name='reportInformedAuthDirectly'][@value='1']";
	public static String SaveIA_Btn = "xpath#//button[text()='Save IA']";
	public static String Yeslabel = "Yes";
	public static String Nolabel = "No";
	public static String Unknownlabel = "Unknown";
	public static String IA_autorityLabel = "Authority";
	public static String IA_commentsReasonLabel = "Comments/Reason Text";
	public static String IA_AckNoLabel = "Acknowledgement Number";
	public static String IA_RefNoLabel = "Reference Number";
	public static String IA_FollowupNo = "Follow-up No.";
	public static String IA_LocallyExpeditedLabel = "Locally Expedited";
	public static String IA_LocalCriteriaLabel = "Local Criteria Report Type";

	public static String Confirm_okBtn = "xpath#//a[contains(@onclick,'dropMsgDialog')][text()='Ok']";
	public static String Date_Verificationlabel = "xpath#//input[@fieldid='%s']";

	public static String IA_dateInformed = "dateInformed";
	public static String IA_decisionDate = "decisionDate";
	public static String IA_ackReceivedDate = "ackReceivedDate";
	public static String IA_refNumReceivedDate = "refNumReceivedDate";
	public static String IA_dateInformedToDistributor = "dateInformedToDistributor";

	public static String Rep_verify = "xpath#//select[@fieldid='%s']";
	public static String reportMedium = "reportMedium";
	public static String reportingStatus = "reportingStatus";

	public static String selectDistributedContact = "xpath#//label[text()='JPN_PMDA1']";
	public static String clickMHLWDropdown = "xpath#//label[text()='MHLW Report Type']//parent::div/select";
	public static String setMHLWTdropDownValue = "xpath#//label[text()='MHLW Report Type']//parent::div/select/option[contains(text(),'%s')]";
	public static String completeRadioBtn = "xpath#//span[text()='Complete']//parent::div/input";
	public static String NullificationIcon = "xpath#(//div[@class='lsmv-grid-row']/div//a/i[@class='fa fa-exclamation-circle fa-2x'])[%count%]";
	public static String verifyNullificationIcon = "xpath#//label[text()='%s']//parent::div//parent::div//parent::div[@class='lsmv-grid-row']/div//a/i[@class='fa fa-exclamation-circle fa-2x']";

	public static String contactsAdd = "xpath#//div[@class='gridButtonBarClass']/span[text()='Add']";
	
	// dates to select
	/*
	 * public static String monthSelect_IA =
	 * "xpath#//label[text()='%s']/ancestor::div/div[@class='lsmv-calendar-box']//select[@class='calendar-month']";
	 * public static String yearSelect_IA =
	 * "xpath#//label[text()='%s']/ancestor::div/div[@class='lsmv-calendar-box']//select[@class='calendar-year']";
	 * public static String monthDropdown_IA =
	 * "xpath#//label[text()='%s']/ancestor::div/div[@class='lsmv-calendar-box']//select[@class='calendar-month']//option[contains(text(),'{@}')]";
	 * public static String yearDropdown_IA =
	 * "xpath#//label[text()='%s']/ancestor::div/div[@class='lsmv-calendar-box']//select[@class='calendar-year']//option[text()='{@}']";
	 * public static String dateSelect_IA =
	 * "xpath#//label[text()='%s']/ancestor::div/div[@class='lsmv-calendar-box']//following-sibling::td//a[text()='{@}']";
	 */

	public static String Reports_Verify(String label) {
		String value = Rep_verify.replace("%s", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to verify the dates
	 * @Input Parameters: label
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Pooja S Date : 17-March-2020 Updated by and when
	 **********************************************************************************************************/

	public static String Dates_Verify(String label) {
		String value = Date_Verificationlabel.replace("%s", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to click the radio buttons
	 * @Input Parameters: label
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Pooja S Date : 17-March-2020 Updated by and when
	 **********************************************************************************************************/

	public static String setRep_radiobtn(String label) {
		String value = ReporterInfo_AuthRadiobtn.replace("%s", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to set the dates in submission
	 *                tracking documents.
	 * @Input Parameters:
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Pooja S Date : 17-March-2020 Updated by and when
	 **********************************************************************************************************/

	public static String setDates(String label) {
		String value = Date_Todaybtn.replace("%s", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to check the check boxes to delete the
	 *                files in submission tracking documents.
	 * @Input Parameters:
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Pooja S Date : 16-March-2020 Updated by and when
	 **********************************************************************************************************/

	public static String submission_Checkbx(String label) {
		String value = SubmissionDoc_Checkbox1.replace("%s", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to locate the input text boxes in
	 *                Submission tracking Informed Authority.
	 * @Input Parameters:
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Pooja S Date : 12-March-2020 Updated by and when
	 **********************************************************************************************************/

	public static String setInputTextbox_IA(String label) {
		String value = IA_Input_Textbox.replace("%s", label);
		return value;

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to click drop down in Submission
	 *                tracking Informed Authority.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Pooja S Date : 12-March-2020 Updated by and when
	 **********************************************************************************************************/

	public static String clickdropdown_IA(String runTimeLabel) {
		String value = IA_Dropdown_Click;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select dropdown value by passing
	 *                value at runtime in Informed authority screen (Submission
	 *                tracking)
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Pooja S Date : 13-March-2020 Updated by and when
	 **********************************************************************************************************/

	public static String selectDropdownvalue_IA(String runTimeLabel) {
		String value = IA_Select_Value;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to set the check the follow up and
	 *                final check boxes in Informed authority screen (Submission
	 *                tracking)
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Pooja S Date : 13-March-2020 Updated by and when
	 **********************************************************************************************************/
	public static String followup_Checkbox(String label) {
		String value = IA_Followup_Final_Checkbox.replace("%s", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to set the dates from Date picker in
	 *                Informed authority screen (Submission tracking)
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Pooja S Date : 13-March-2020 Updated by and when
	 **********************************************************************************************************/
	/*
	 * public static String setdates_IA(String label) { String value =
	 * IA_Date_Textbox.replace("%s", label); return value; }
	 */

	public static String setDatesTextboxes_IA(String label) {
		String value = IA_DatePick_Icon.replace("%s", label);
		return value;
	}

	/*
	 * public static String monthDropdown(String month,String label) { String value
	 * = monthDropdown_IA; String value1 = monthDropdown_IA; value =
	 * value.replace("{@}", month); value1=value.replace("%s",label); return value1;
	 * }
	 * 
	 * public static String yearDropdown(String year,String label) { String value =
	 * yearDropdown_IA; String value1 = yearDropdown_IA; value =
	 * value.replace("{@}", year); value1=value.replace("%s",label); return value1;
	 * }
	 * 
	 * public static String dateSelect(String date,String label) { String value =
	 * dateSelect_IA; String value1 = dateSelect_IA; value = value.replace("{@}",
	 * date); value1=value.replace("%s",label); return value1; }
	 */
	/**********************************************************************************************************
	 * @Objective: The below method is created to select the radio button for
	 *             Nullification or Amendment radio button
	 * @InputParameters: label
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 16-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String setReportNull_Amendment(String runtimelabel) {
		String value = Nullification_Amendmentradiobtn;
		String value2;
		value2 = value.replace("%s", runtimelabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set the text boxes for sender's
	 *             comments event description and Case Summary and Reporter's
	 *             Comments
	 * @InputParameters: label
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 16-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String setTextboxes(String label) {
		String value = LocalNarrative_Textbox.replace("%s", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Distributed contact Name
	 *             from List of distributed Contacts in Submission tracking screen.
	 * @InputParameters: contName , format
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 18-February-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String ExclusionContact(String label) {
		String value = NotDistributedStatus.replace("%s", label);
		return value;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Distributed contact Name
	 *             from List of distributed Contacts in Submission tracking screen.
	 * @InputParameters: contName , format
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 18-February-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String ExclusionContactRemoval(String label) {
		String value = ExclusionListStatusRemoval.replace("%s", label);
		return value;

	}

	/**********************************************************************************************************
	 * Objective:The below method is created to moreOptions menu navigation passing
	 * link name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Mythri Jain Date :11-Mar-2020 Updated by and when
	 **********************************************************************************************************/
	public static String moreOptions(String runTimeLabel) {
		String value = moreOptionsNavigation;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String clickMHLWTypeDropDown(String data) {
		String value = setMHLWTdropDownValue.replace("%s", data);
		return value;
	}

	public static String checkNullificationIcon(String data) {
		String value = verifyNullificationIcon.replace("%s", data);
		return value;
	}
	
	public static String moreAct_errorMessage = "xpath#//div/span[@class='lsmv-error-message']";
	public static String moreActions = "xpath#//span[contains(@class,'tooltip')][@style='float:none;z-index:1;']/div/div/a[text()='%s']";
	public static String moreActions(String label) {
		String value = moreActions.replace("%s", label);
		return value;
	}
}
