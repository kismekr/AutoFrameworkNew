package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.arisglobal.framework.components.lsmv.L10_1.CommonOperations;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.BatchListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.Batch_CreateBatchPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.FileSystemOperations;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class BatchReportListingOperations extends ToolManager {
	public static WebElement webElement;
	static String className = BatchReportListingOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to search a particular record.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 15-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Boolean searchSingleBatchRecord(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(BatchListingPageObjects.searchTextArea,
				getTestDataCellValue(scenarioName, "BatchName"));
		agClick(BatchListingPageObjects.searchIcon);
		agSetStepExecutionDelay("5000");

		if (agGetText(BatchListingPageObjects.pagination_RecordCount).startsWith("1")&&agGetText(BatchListingPageObjects.pagination_RecordCount).endsWith("1")) {
			Reports.ExtentReportLog("", Status.PASS, "Batch record matching the exact keyed value retrieved successfully", true);
			return true;
		}
		else {
			Reports.ExtentReportLog("", Status.INFO, "Batch record not retrieved", true);
			return false;
		}

	}


	/**********************************************************************************************************
	 * @Objective: The below method is created to select a particular report format.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 15-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void selectRequiredReportFormats(String scenarioName) {
		if (getTestDataCellValue(scenarioName, "Report_MedWatch").equalsIgnoreCase("Yes")||getTestDataCellValue(scenarioName, "Report_MedWatch").equalsIgnoreCase("Check")) {
			agClick(Batch_CreateBatchPageObjects.report_MedWatch_CheckBox);
		}

		if (getTestDataCellValue(scenarioName, "Report_CIOMS").equalsIgnoreCase("Yes")||getTestDataCellValue(scenarioName, "Report_CIOMS").equalsIgnoreCase("Check")) {
			agClick(Batch_CreateBatchPageObjects.report_CIOMS_CheckBox);
		}

		if (getTestDataCellValue(scenarioName, "Report_IncludeAllVer").equalsIgnoreCase("Yes")||getTestDataCellValue(scenarioName, "Report_IncludeAllVer").equalsIgnoreCase("Check")) {
			agClick(Batch_CreateBatchPageObjects.report_IncludeAllVers_CheckBox);
		}

		if (getTestDataCellValue(scenarioName, "Report_SourceE2BXMLs").equalsIgnoreCase("Yes")||getTestDataCellValue(scenarioName, "Report_SourceE2BXMLs").equalsIgnoreCase("Check")) {
			agClick(Batch_CreateBatchPageObjects.report_SourceE2BXMLs_CheckBox);
		}

		if (getTestDataCellValue(scenarioName, "Report_FOIA-Compliant").equalsIgnoreCase("Yes")||getTestDataCellValue(scenarioName, "Report_FOIA-Compliant").equalsIgnoreCase("Check")) {
			agClick(Batch_CreateBatchPageObjects.report_FOIA_CheckBox);
		}

		if (getTestDataCellValue(scenarioName, "Report_IncludeAttachments").equalsIgnoreCase("Yes")||getTestDataCellValue(scenarioName, "Report_IncludeAttachments").equalsIgnoreCase("Check")) {
			agClick(Batch_CreateBatchPageObjects.report_IncludeAttachments_CheckBox);
		}
	}


	/**********************************************************************************************************
	 * @Objective: To verify the Batch Report Progress and download.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 15-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static boolean verifyBatchReportGeneration(String scenarioName) {
		Boolean isDownloaded = false;
		try {
			if (searchSingleBatchRecord(scenarioName)) {
				Boolean downloadable = false;
				for (int i = 0; i < 6; i++) {

					agSetStepExecutionDelay("3000");
					downloadable = agIsVisible(BatchListingPageObjects
							.selectBatchRecordDownload(getTestDataCellValue(scenarioName, "BatchName")));
					if (downloadable) {
						Reports.ExtentReportLog("", Status.PASS, "Batch report avaialble for download", true);
						deletePreDownloadedReport(scenarioName);
						agClick(BatchListingPageObjects
								.selectBatchRecordDownload(getTestDataCellValue(scenarioName, "BatchName")));
						Reports.ExtentReportLog("", Status.PASS, "Batch report Downloaded successfully", true);
						isDownloaded = true;
						break;

					} else {
						Reports.ExtentReportLog("", Status.INFO,
								"Batch report not available for download yet. Try Number: " + i, true);
						agClick(BatchListingPageObjects.refreshButton);
						searchSingleBatchRecord(scenarioName);
						agSetStepExecutionDelay("2000");
					}

				}

				if (downloadable == false) {
					Reports.ExtentReportLog("", Status.INFO,
							"Batch report not available for download even after one minute of waiting time", true);
					isDownloaded = false;
				}


			}
			else {
				Reports.ExtentReportLog("", Status.INFO,
						"No record available by the keyed name to perform Download operation", true);
				isDownloaded = false;
			}
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			Reports.ExtentReportLog("", Status.FAIL, "Failed to Download Batch report", true);
			e.printStackTrace();
			isDownloaded = false;
		}
		return isDownloaded;

	}

	/**********************************************************************************************************
	 * @Objective: To perform the Batch Delete Operation.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 15-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteBatchReportRecord(String scenarioName) {

		if (searchSingleBatchRecord(scenarioName)) {
			agSetStepExecutionDelay("5000");
			agWaitTillVisibilityOfElement(BatchListingPageObjects.tbHeader_SelectAllCheckBox);
			agClick(BatchListingPageObjects.tbdata_BatchRecord_checkBox);
			agClick(BatchListingPageObjects.delete_button);
			Reports.ExtentReportLog("", Status.INFO, "Delete Confirmation", true);
			agClick(BatchListingPageObjects.deleteConfirm_Button);
			agClick(BatchListingPageObjects.ackWindowInfoText);
			Reports.ExtentReportLog("", Status.INFO, agGetText(BatchListingPageObjects.ackWindowInfoText), true);
			agClick(BatchListingPageObjects.ackWindowInfoOK_button);
			searchDeleteBatchprint(scenarioName);
		}	
		else {
			Reports.ExtentReportLog("", Status.FAIL, "No record available by the keyed name to perform Delete", true);
		}
	}


	/**********************************************************************************************************
	 * @Objective: To select the cases based keyed variable.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 15-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void selectPrintByOption(String scenarioName) {

		boolean selected = false;
		switch (getTestDataCellValue(scenarioName, "PrintBy")) {

		case "Comma separated AER No.s":
			selected = agIsSelected(Batch_CreateBatchPageObjects.CSV_AERs_RadioBtn_circle);
			if (selected==false) {			
				agClick(Batch_CreateBatchPageObjects.selectPrintByRadioBtn(getTestDataCellValue(scenarioName, "PrintBy")));
				agSetStepExecutionDelay("2000");
			}
			agWaitTillVisibilityOfElement(Batch_CreateBatchPageObjects.AER_nos_TextField);
			agSetValue(Batch_CreateBatchPageObjects.AER_nos_TextField, getTestDataCellValue(scenarioName, "AERNo"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			break;

		case "Date Range":
			selected = agIsSelected(Batch_CreateBatchPageObjects.DateRange_RadioBtn_circle);
			if (selected==false) {
				agClick(Batch_CreateBatchPageObjects.selectPrintByRadioBtn(getTestDataCellValue(scenarioName, "PrintBy")));
				agSetStepExecutionDelay("2000");
			}

			agClick(Batch_CreateBatchPageObjects.dateRange_FromDate);
			agJavaScriptExecuctorSendKeys(Batch_CreateBatchPageObjects.dateRange_FromDate, getTestDataCellValue(scenarioName, "FromDate"));
			//selectDateAndTime(scenarioName, Batch_CreateBatchPageObjects.dateRange_FromDate, getTestDataCellValue(scenarioName, "FromDate"));

			agSetStepExecutionDelay("2000");

			agClick(Batch_CreateBatchPageObjects.dateRange_ToDate);
			//selectDateAndTime(scenarioName, Batch_CreateBatchPageObjects.dateRange_ToDate, getTestDataCellValue(scenarioName, "ToDate"));
			agJavaScriptExecuctorSendKeys(Batch_CreateBatchPageObjects.dateRange_ToDate, getTestDataCellValue(scenarioName, "ToDate"));

			break;

		case "AER No. range":
			selected = agIsSelected(Batch_CreateBatchPageObjects.AERRange_RadioBtn_circle);
			if (selected==false) {
				agClick(Batch_CreateBatchPageObjects.selectPrintByRadioBtn(getTestDataCellValue(scenarioName, "PrintBy")));
				agSetStepExecutionDelay("2000");
			}

			agWaitTillVisibilityOfElement(Batch_CreateBatchPageObjects.keyAERRangeFrom_TextField);
			agSetValue(Batch_CreateBatchPageObjects.keyAERRangeFrom_TextField, getTestDataCellValue(scenarioName, "AERNumberRange_From"));
			agSetValue(Batch_CreateBatchPageObjects.keyAERRangeTo_TextField, getTestDataCellValue(scenarioName, "AERNumberRange_To"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			break;

		case "Saved Searches ":
			selected = agIsSelected(Batch_CreateBatchPageObjects.SavedSearch_RadioBtn_circle);
			
			if (selected==false) {
				agClick(Batch_CreateBatchPageObjects.selectPrintByRadioBtn(getTestDataCellValue(scenarioName, "PrintBy")));
				agSetStepExecutionDelay("2000");
			}
			
			agClick(Batch_CreateBatchPageObjects.savedSearchCriteria_DropDown);
			agSetValue(Batch_CreateBatchPageObjects.savedSearchCriteria_SearchBox, getTestDataCellValue(scenarioName, "SavedSearchCriteria"));
			agClick(Batch_CreateBatchPageObjects.selectSavedSearchOption(getTestDataCellValue(scenarioName, "SavedSearchCriteria")));
			break;

		case "Upload File":
			selected = agIsSelected(Batch_CreateBatchPageObjects.UploadFile_RadioBtn_circle);
			//To be scripted
			break;	

		default:
			Reports.ExtentReportLog("", Status.FAIL, "Specified Report Type selection is incorrect. Values expected are, 'Comma separated AER No.s',"
					+ " 'Date Range', 'AER No. range', 'Saved Searches ' and 'Upload File'. Actual value read is '"+getTestDataCellValue(scenarioName, "PrintBy").toLowerCase()+"'." , true);

			break;
		}
	}

	/**********************************************************************************************************
	 * @Objective: To set the Batch Print schedule.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 17-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setBatchReportSchedule(String scenarioName) {

		String scheduleFrequency = getTestDataCellValue(scenarioName, "ScheduleType");
		agClick(Batch_CreateBatchPageObjects.scheduleType_dropdown);


		switch (scheduleFrequency.toLowerCase().trim()) {
		case "one time":
			agSetStepExecutionDelay("2000");
			agClick(Batch_CreateBatchPageObjects.selectScheduleOption("One Time"));
			agSetValue(Batch_CreateBatchPageObjects.schedule_OneTime_dateFiled, getTestDataCellValue(scenarioName, "OneTime_Date"));
			break;

		case "daily":
			agSetStepExecutionDelay("2000");
			agClick(Batch_CreateBatchPageObjects.selectScheduleOption("Daily"));
			agSetValue(Batch_CreateBatchPageObjects.schedule_OneTime_dateFiled, getTestDataCellValue(scenarioName, "OneTime_Date"));
			break;

		case "weekly":
			agSetStepExecutionDelay("2000");
			agClick(Batch_CreateBatchPageObjects.selectScheduleOption("Weekly"));
			String [] day = getTestDataCellValue(scenarioName, "Weekly_Days").split(":",7);
			System.out.print("Values selected are, ");
			for (int i = 0; i < day.length; i++) {
				System.out.print(", "+day[i]);
				agWaitTillVisibilityOfElement(Batch_CreateBatchPageObjects.checkDays(day[i]));
				agClick(Batch_CreateBatchPageObjects.checkDays(day[i]));

				//CommonOperations.verifyCheckBoxLeftOf(day[i], "check");
			}
			System.out.println();
			break;

		case "monthly":
			agSetStepExecutionDelay("2000");
			agClick(Batch_CreateBatchPageObjects.selectScheduleOption("Monthly"));
			agWaitTillVisibilityOfElement(Batch_CreateBatchPageObjects.months_DropDown);
			String [] month = getTestDataCellValue(scenarioName, "Monthly_Months").split(":",12);
			System.out.print("Values selected are");
			for (int i = 0; i < month.length; i++) {
				System.out.print(", " + month[i]);
				agWaitTillVisibilityOfElement(Batch_CreateBatchPageObjects.months_DropDown);
				agClick(Batch_CreateBatchPageObjects.months_DropDown);
				//agClick(Batch_CreateBatchPageObjects.checkMonth(month[i]));

				CommonOperations.verifyCheckBoxLeftOf(Batch_CreateBatchPageObjects.checkMonth(month[i]), "check");
			}
			System.out.println();
			break;

		case "quarterly":
			agSetStepExecutionDelay("2000");
			agClick(Batch_CreateBatchPageObjects.selectScheduleOption("Quarterly"));
			String [] quarter = getTestDataCellValue(scenarioName, "Quarterly_Value").split(":",4);
			System.out.println("Values selected are, ");
			for (int i = 0; i < quarter.length; i++) {
				System.out.print(", "+quarter[i]);
				agWaitTillVisibilityOfElement(Batch_CreateBatchPageObjects.checkQuarter(quarter[i]));
				//agClick(Batch_CreateBatchPageObjects.checkQuarter(quarter[i]));

				CommonOperations.verifyCheckBoxLeftOf(Batch_CreateBatchPageObjects.checkQuarter(quarter[i]), "check");				
			}
			System.out.println();
			break;

		default:
			break;
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created search and create batch print.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 15-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreatebatchprint(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (searchSingleBatchRecord(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Batch print record already exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "BatchName"),
					BatchListingPageObjects.selectBatchRecordName(getTestDataCellValue(scenarioName, "BatchName")));
		} else {
			agClick(BatchListingPageObjects.new_button);
			createBatchReport(scenarioName, false);

		}

	}


	/**********************************************************************************************************
	 * @Objective: To create Batch Print Record.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 15-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createBatchReport(String scenarioName, Boolean editRecord) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (editRecord==false) {
			agSetValue(Batch_CreateBatchPageObjects.batchName_TextField, getTestDataCellValue(scenarioName, "BatchName"));			
		}
		agClick(Batch_CreateBatchPageObjects.batchConfigurationName_DropDown);
		agSetStepExecutionDelay("2000");

		agJavaScriptExecuctorClick(Batch_CreateBatchPageObjects.selectConfigValue(getTestDataCellValue(scenarioName, "BatchConfigurationName")));

		if (getTestDataCellValue(scenarioName, "PrintType").equalsIgnoreCase("Paper")) {
			agClick(Batch_CreateBatchPageObjects.printType_PaperF_RadioBtn);
			agSetStepExecutionDelay("3000");
			agSetValue(Batch_CreateBatchPageObjects.noOfCopies_TextField,
					getTestDataCellValue(scenarioName, "NoOfCopies"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		else {
			if(agIsSelected(Batch_CreateBatchPageObjects.printType_PDF_RadioBtn)==false) {
				agClick(Batch_CreateBatchPageObjects.printType_PDF_RadioBtn);
			}
		}

		agSetValue(Batch_CreateBatchPageObjects.description_TextArea, getTestDataCellValue(scenarioName, "Description"));

		selectPrintByOption(scenarioName);
		selectRequiredReportFormats(scenarioName);

		if (getTestDataCellValue(scenarioName, "ScheduleCheck").equalsIgnoreCase("yes")||getTestDataCellValue(scenarioName, "ScheduleCheck").equalsIgnoreCase("check")) {
			CommonOperations.clickCheckBoxRightOf(Batch_CreateBatchPageObjects.schedule_CheckBox,"true");
			setBatchReportSchedule(scenarioName);
		}


		//Save the record
		Reports.ExtentReportLog("", Status.INFO, "Data entered in Batch print", true);
		agClick(Batch_CreateBatchPageObjects.saveButton);
		agSetStepExecutionDelay("3000");

		if (agIsVisible(Batch_CreateBatchPageObjects.saveConfirmWinTitle)) {
			agIsVisible(Batch_CreateBatchPageObjects.saveConfirmWin_Yes);
			Reports.ExtentReportLog("", Status.PASS, agGetText(Batch_CreateBatchPageObjects.saveConfirmWin_Yes), true);
			agClick(Batch_CreateBatchPageObjects.saveConfirmWin_Yes);
			agSetStepExecutionDelay("5000");
			Reports.ExtentReportLog("", Status.INFO, agGetText(BatchListingPageObjects.ackWindowInfoText), true);
			agClick(BatchListingPageObjects.ackWindowInfoOK_button);
			agIsVisible(BatchListingPageObjects.batchPrintListingBreadScrum);
			Reports.ExtentReportLog("", Status.INFO, agGetText(BatchListingPageObjects.ackWindowInfoText), true);
		}

		else if(agIsVisible(Batch_CreateBatchPageObjects.ackwindowErrorTitleText)) {
			Reports.ExtentReportLog("", Status.FAIL, agGetText(BatchListingPageObjects.ackWindowInfoText), true);
			agClick(BatchListingPageObjects.ackWindowInfoOK_button);
			ReportsOperations.menuNavigation("batchPrintListing");
			agIsVisible(BatchListingPageObjects.batchPrintListingBreadScrum);
		}

		else {
			agIsVisible(BatchListingPageObjects.ackWindowHeaderText);
			agIsVisible(BatchListingPageObjects.ackWindowInfoText);
			System.out.println(agGetText(BatchListingPageObjects.ackWindowInfoText));
			Reports.ExtentReportLog("", Status.INFO, agGetText(BatchListingPageObjects.ackWindowInfoText), true);
			agClick(BatchListingPageObjects.ackWindowInfoOK_button);
			agIsVisible(BatchListingPageObjects.batchPrintListingBreadScrum);
			Reports.ExtentReportLog("", Status.INFO, agGetText(BatchListingPageObjects.ackWindowInfoText), true);
		}



	}

	/**********************************************************************************************************
	 * @Objective: To edit the Batch Print Record.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 15-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void editBatchReport(String scenarioName) {

		try {
			if (searchSingleBatchRecord(scenarioName)) {
				if (agIsVisible(BatchListingPageObjects.tbdata_EditRecord_icon)) {
					agClick(BatchListingPageObjects.tbdata_EditRecord_icon);
					createBatchReport(scenarioName, true);
				} else {
					Reports.ExtentReportLog("", Status.INFO, "Retrieved record cannot be edited, edit option disabled.", true);
				}

			}else {
				Reports.ExtentReportLog("", Status.INFO, "No record available by Batch Name, '"+getTestDataCellValue(scenarioName, "BatchName")+"'.", true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "System fails to perform Edit Operation", false);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search for deleted batch print.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchDeleteBatchprint(String scenarioName) {
		searchSingleBatchRecord(scenarioName);
		String paginator = agGetText(BatchListingPageObjects.pagination_RecordCount);
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.FAIL, "Search for Deleted batch print: Deleted batch print is listed",
					true);
		} else {
			Reports.ExtentReportLog("", Status.PASS,
					"Search for Deleted batch print: Deleted batch print is not listed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download BatchPrint export to
	 *             excel.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 15-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportToexcel(String FileName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(BatchListingPageObjects.exportHoverButton);
		agClick(BatchListingPageObjects.exportToExcelBtn);
		agSetStepExecutionDelay("3000");
		agWaitTillVisibilityOfElement(BatchListingPageObjects.export_Btn);

		if (agIsVisible(BatchListingPageObjects.export_Btn) == true) {
			agClick(BatchListingPageObjects.export_Btn);
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			CommonOperations.move_Downloadedexcel(FileName);
			agClick(BatchListingPageObjects.cancel_Btn);
		} else {
			Reports.ExtentReportLog("Export to excel pop is not displayed", Status.INFO, "", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to compare record count with download
	 *             excel
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:Avinash K
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void recordCountVerification(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		String count = xls.getCellData("Batch Print", 2, 4);
		String[] Totalcount = count.split(":");
		System.out.println(Totalcount[1].trim());
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in exported excel::" + Totalcount[1].trim(),
				false);
		String applrecordcount = agGetText(BatchListingPageObjects.pagination_RecordCount);
		String[] data = applrecordcount.split(" ");
		String recordCount = data[4];
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in application::" + recordCount, false);
		if (recordCount.equalsIgnoreCase(Totalcount[1].trim())) {
			Reports.ExtentReportLog("", Status.PASS, "Record count verification is successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Record count verification is Unsuccessfull", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select date and Time.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 23-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void selectDateAndTime(String scenarioName, String dateField, String dateTime) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String [] dateAndTime = dateTime.split(" ", 2);
		String date = dateAndTime[0];		
		String time = dateAndTime[1];

		String [] timeSplit = time.split(":", 3);
		int hour = Integer.parseInt(timeSplit[0]);
		int min = Integer.parseInt(timeSplit[1]);
		int sec = Integer.parseInt(timeSplit[2]);

		//Set Date
		agJavaScriptExecuctorSendKeys(dateField, date);
		agSetStepExecutionDelay("1000");

		//Set Hour
		if (hour>=0 && hour<24) {
			WebElement hourSlider = driver.findElement(By.xpath("//div/dl/dd[@class='ui_tpicker_hour']/div/span"));
			agClick(Batch_CreateBatchPageObjects.dateRange_Hour);
			Actions builder1= new Actions(driver);
			for(int iCount = 0; iCount < hour ; iCount++) {
				builder1.moveToElement(hourSlider).click(hourSlider).sendKeys(Keys.ARROW_RIGHT).perform();	
			}
		}
		else {
			Reports.ExtentReportLog("", Status.INFO, "Incorrect hour value keyed", false);
		}

		//Set Minutes
		if (min>=0 && min<60) {
			WebElement minuteSlider = driver.findElement(By.xpath("//div/dl/dd[@class='ui_tpicker_minute']/div/span"));
			agClick(Batch_CreateBatchPageObjects.dateRange_Minute);
			Actions builder1= new Actions(driver);
			for(int iCount = 0; iCount < min ; iCount++) {
				builder1.moveToElement(minuteSlider).click(minuteSlider).sendKeys(Keys.ARROW_RIGHT).perform();	
			}
		}
		else {
			Reports.ExtentReportLog("", Status.INFO, "Incorrect minute value keyed", false);
		}

		//Set Seconds
		WebElement secondSlider = driver.findElement(By.xpath("//div/dl/dd[@class='ui_tpicker_second']/div/span"));
		agClick(Batch_CreateBatchPageObjects.dateRange_Second);
		Actions builder1= new Actions(driver);
		for(int iCount = 0; iCount <= sec ; iCount++) {
			builder1.moveToElement(secondSlider).click(secondSlider).sendKeys(Keys.ARROW_RIGHT).perform();	
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data is visible in downloaded report.
	 * @InputParameters: scenarioName, sheetName, columnName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 29-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyDataVisible_DownloadedReport(String filePath, String scenarioName, String sheetName,
			String columnName) {
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		PDFOperations.pdfverificationForVisible(filePath,
				getTestDataCellValue(scenarioName, columnName));
	}




	/**********************************************************************************************************
	 * @Objective: To unzip the Batch Report and return the absolute file name
	 * @InputParameters: Zip File Path, DestDirectory
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @throws IOException 
	 * @Date : 23-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String unZippedReport(String scenarioName) {
		
		String fileName = null;
		
		if (verifyBatchReportGeneration(scenarioName)==true) {
		
		agSetStepExecutionDelay("5000");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		String destDirectory = lsmvConstants.LSMV_testDataOutput + "\\" + Reports.currenttime();			
		String zipFilePath = lsmvConstants.LSMV_testDataOutput +"\\"+ getTestDataCellValue(scenarioName, "BatchName")+".zip";

		File file = new File(zipFilePath);
		
		do{			
			//System.out.println("Waiting to get the file downloaded. Iteration "+ ++i);
			agSetStepExecutionDelay("10000");	      
		}while(!file.exists());

		FileSystemOperations.unzip(zipFilePath, destDirectory);

		
		try {
			FileInputStream fis = new FileInputStream(zipFilePath);
			ZipInputStream zis = new ZipInputStream(fis);
			ZipEntry ze = zis.getNextEntry();			 
			fileName = ze.getName();
			fileName = destDirectory+"\\"+fileName;

			zis.closeEntry();
			zis.close();
			fis.close();
		} 
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("Absolute File Path is, "+fileName);		
		}
		
		else {
			Reports.ExtentReportLog("", Status.FAIL, "File not downloaded", false);
		}
		return fileName;
	}

	/**********************************************************************************************************
	 * @Objective: To verify the Batch Report Progress and download.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 30-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deletePreDownloadedReport(String scenarioName) {
		agSetStepExecutionDelay("5000");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);		
		String zipFilePath = lsmvConstants.LSMV_testDataOutput +"\\"+ getTestDataCellValue(scenarioName, "BatchName")+".zip";

		//to delete pre-existing files with same name
		try {
			File file = new File(zipFilePath);
			if (file.exists()) {
				FileUtils.forceDelete(file);
				System.out.println(zipFilePath+" file deleted successfully");
			}
			else {
				System.out.println(zipFilePath+" file not available for delete");
			}
		} 
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}