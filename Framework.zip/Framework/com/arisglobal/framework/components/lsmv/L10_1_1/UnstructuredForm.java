package com.arisglobal.framework.components.lsmv.L10_1_1;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ContactLookUpPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDEContactLookupPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.UnstructuredFormPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class UnstructuredForm extends ToolManager{
	static String className = applicationParameterOperations.class.getSimpleName();
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Basic Details in Case Management >> New Case >> Unstructured Form.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 30-April-2020
	 * @UpdatedByAndWhen: 
	 ************************************************************************************************************************/
	public static void setBasicDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.setListUnstructuredDropDownValue(UnstructuredFormPageObjects.companyUnit_DropDown, getTestDataCellValue(scenarioName, "CompanyUnit"));
		CommonOperations.setSenderPartnerLookupDetails(getTestDataCellValue(scenarioName, "SenderUnitType"), getTestDataCellValue(scenarioName, "SenderUnit"));
		CommonOperations.setListDropDownValue(UnstructuredFormPageObjects.processingUnit_DropDown, getTestDataCellValue(scenarioName, "ProcessingUnit"));
		CommonOperations.setListDropDownValue(UnstructuredFormPageObjects.reportReceivingMedium_DropDown, getTestDataCellValue(scenarioName, "ReportReceivingMedium"));
		CommonOperations.setListDropDownValue(UnstructuredFormPageObjects.reportReceivingFormat_DropDown, getTestDataCellValue(scenarioName, "ReportReceivingFormat"));
		CommonOperations.setListDropDownValue(UnstructuredFormPageObjects.priority_DropDown, getTestDataCellValue(scenarioName, "Priority"));
		CommonOperations.clickCheckBoxRightOf(UnstructuredFormPageObjects.overrideAutoCalculationRule_CheckBox, getTestDataCellValue(scenarioName, "OverrideAutoCalculationRule"));
		agSetValue(UnstructuredFormPageObjects.latestReceivedDate_TextBox, CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "LatestReceivedDate")));
		agSetValue(UnstructuredFormPageObjects.initialReceivedDate_TextBox, CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "InitialReceivedDate")));
		agSetValue(UnstructuredFormPageObjects.companyReceivedDate_TextBox, CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "CompanyReceivedDate")));
		CommonOperations.setListUnstructuredDropDownValue(UnstructuredFormPageObjects.reportType_DropDown, getTestDataCellValue(scenarioName, "ReportType"));
		CommonOperations.setListDropDownValue(UnstructuredFormPageObjects.reportClassification_DropDown, getTestDataCellValue(scenarioName, "ReportClassification"));

		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Case Management >> New Case >> Unstructured Form >> Basic Details Section", false);
	}
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Source Document(s) Details in Case Management >> New Case >> Unstructured Form.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 30-April-2020
	 * @UpdatedByAndWhen: 
	 ************************************************************************************************************************/
	public static void setSourceDocumentDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(UnstructuredFormPageObjects.sourceDocument_UploadLink, lsmvConstants.LSMV_testDataInput + "\\"+ getTestDataCellValue(scenarioName, "SourceDocumentName"));
		
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Case Management >> New Case >> Unstructured Form >> Source Document(s) Section", true);
	}
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Support Document(s) Details in Case Management >> New Case >> Unstructured Form.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 30-April-2020
	 * @UpdatedByAndWhen: 
	 ************************************************************************************************************************/
	public static void setSupportDocumentDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(UnstructuredFormPageObjects.supportDocument_UploadLink, lsmvConstants.LSMV_testDataInput + "\\"+ getTestDataCellValue(scenarioName, "SupportDocumentName"));

		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Case Management >> New Case >> Unstructured Form >> Support Document(s) Section", true);
	} 
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Assign To Details in Case Management >> New Case >> Unstructured Form.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 30-April-2020
	 * @UpdatedByAndWhen: 
	 ************************************************************************************************************************/
	public static void setAssignToDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick((UnstructuredFormPageObjects.assignTo_Radio).replace("%radioLabel%", getTestDataCellValue(scenarioName, "AssignToRadio")));
		CommonOperations.setListDropDownValue(UnstructuredFormPageObjects.assignTo_DropDown, getTestDataCellValue(scenarioName, "AssignTo"));

		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Case Management >> New Case >> Unstructured Form >> Assign To Section", true);
	} 
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Contact Details in Case Management >> New Case >> Unstructured Form.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 30-April-2020
	 * @UpdatedByAndWhen: 
	 ************************************************************************************************************************/
	public static void setContactDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "boolAddContact").equalsIgnoreCase("true")) {
			CommonOperations.clickAddDivOf(UnstructuredFormPageObjects.contact_Label);
		}
		String rowNO = "";
		if(getTestDataCellValue(scenarioName, "contactRowNo").equalsIgnoreCase("#skip#")) {
			rowNO = "0";
		}else {
			rowNO = getTestDataCellValue(scenarioName, "contactRowNo");
		}
		agClick((UnstructuredFormPageObjects.lastName_LookUpIcon).replace("%rowNo%", rowNO));
		CommonOperations.setContactLookupDetails(getTestDataCellValue(scenarioName, "FirstName"), getTestDataCellValue(scenarioName, "MiddleName"), getTestDataCellValue(scenarioName, "LastName"));
		agClick((UnstructuredFormPageObjects.caseReporter_CheckBox).replace("%rowNo%", rowNO));
		
		agJavaScriptExecuctorClick(UnstructuredFormPageObjects.contact_Div);
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Case Management >> New Case >> Unstructured Form >> Contact Section", true);
		
	}
	
	public static void AddContacts(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agIsVisible(UnstructuredFormPageObjects.contactlookUP);
		agJavaScriptExecuctorClick(UnstructuredFormPageObjects.contactlookUP);
		agClick(UnstructuredFormPageObjects.Searchfilter);
		agIsSelected(UnstructuredFormPageObjects.SearchVisible);
		setContactLookupDetails(getTestDataCellValue(scenarioName, "FirstName"), getTestDataCellValue(scenarioName, "MiddleName"), getTestDataCellValue(scenarioName, "LastName"));
	}
	
	public static void setContactLookupDetails(String firstName, String middleName, String lastName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(UnstructuredFormPageObjects.firstName, firstName);
		agSetValue(UnstructuredFormPageObjects.LastName, lastName);
		agClick(UnstructuredFormPageObjects.searchBtn);
		agClick(UnstructuredFormPageObjects.selectContact(firstName));
		agClick(UnstructuredFormPageObjects.SelectBtn);
	}


	/***********************************************************************************************************************
	 * @Objective: The below method is created to set UNSTRUCTURED FORM Details in Case Management >> New Case >> Unstructured Form.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 30-April-2020
	 * @UpdatedByAndWhen: 
	 ************************************************************************************************************************/
	public static void setUnstructuredFormDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		
		
		agJavaScriptExecuctorClick(UnstructuredFormPageObjects.unstructuredFORM_Label);
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Case Management >> New Case >> Unstructured Form >> Unstructured Form Section", true);
		
	}
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to create Unstructured Case in Case Management >> New Case >> Unstructured Form.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 30-April-2020
	 * @UpdatedByAndWhen: 
	 ************************************************************************************************************************/
	public static void setUnstructuredFormCase(String scenarioName) {
		setBasicDetails(scenarioName);
		setSourceDocumentDetails(scenarioName);
		setSupportDocumentDetails(scenarioName);
		setAssignToDetails(scenarioName);
		setContactDetails(scenarioName);
		
		//setUnstructuredFormDetails(scenarioName);
	}
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to create basic Unstructured Case in Case Management >> New Case >> Unstructured Form.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 22-Jan-2021
	 * @UpdatedByAndWhen: 
	 ************************************************************************************************************************/

	public static void SetBasicUnstructuredCaseData(String scenarioName) {
		setBasicDetails(scenarioName);
		AddContacts(scenarioName);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to save Unstructured Case
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 22-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void saveUnstructuredCase(String scenarioName ,String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(UnstructuredFormPageObjects.saveButton);
		agSetStepExecutionDelay("10000");
		agWaitTillVisibilityOfElement(UnstructuredFormPageObjects.saveConfirmationPopUp);
		agIsVisible(UnstructuredFormPageObjects.saveConfirmationPopUp);
		writeRecptNo_FDESave(scenarioName, sheetName);
		agIsVisible(UnstructuredFormPageObjects.saveOkButton);
		agJavaScriptExecuctorClick(UnstructuredFormPageObjects.saveOkButton);
		agIsVisible(UnstructuredFormPageObjects.ConfirmButton);
		agJavaScriptExecuctorClick(UnstructuredFormPageObjects.ConfirmButton);	
		agSetStepExecutionDelay("10000");
		agIsVisible(UnstructuredFormPageObjects.backToListing);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created write receipt no in excel
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 22-Jan-2021
	 * @UpdatedByAndWhen: Praveen Patil , 27-Jan-2021 
	 **********************************************************************************************************/
	public static void writeRecptNo_FDESave(String scenarioName, String sheetName) {
		CommonOperations.agwaitTillVisible(UnstructuredFormPageObjects.receiptNumber, 20, 1000);
		agIsVisible(UnstructuredFormPageObjects.receiptNumber);
		String receiptNumber = agGetText(UnstructuredFormPageObjects.receiptNumber);
		String[] arrOfStr = receiptNumber.split("Receipt number");
		arrOfStr = arrOfStr[1].split("saved successfully");
		receiptNumber = arrOfStr[0].trim();
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "ReceiptNo", receiptNumber);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to click on Confirm button in Unstructured Case 
	 * @InputParameters: NA
	 * @OutputParameters:
	 * @author: Praveen Patil 
	 * @Date : 01-Feb-2021
	 * @UpdatedByAndWhen: 
	 **********************************************************************************************************/
	public static void clikOnConfirmButton() {
		agIsVisible(UnstructuredFormPageObjects.confirmBtn);
		agClick(UnstructuredFormPageObjects.confirmBtn);
		agSetStepExecutionDelay("10000");
		String expectedWorkFlowheader = "Intake and Assessment";
		agWaitTillInvisibilityOfElement(expectedWorkFlowheader);
			
	}

}