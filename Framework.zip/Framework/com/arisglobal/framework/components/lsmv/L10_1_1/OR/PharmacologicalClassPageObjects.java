package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class PharmacologicalClassPageObjects {

	public static String new_Button = "xpath#//a[@id='listingForm:newId']";
	public static String PharmacologicalClass_lable = "xpath#//div[@class='panel-title']/label[text()='Pharmacological Class']";
	public static String keywordSearch_TxtField = "xpath#//input[@id='listingForm:searchCriteria']";
	public static String search_Icon = "xpath#//a[@id='listingForm:searchbutton']";
	public static String paginator = "xpath#//div[@id='listingForm:pharmaDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String get_ListofCode= "xpath#//tbody[@id='listingForm:pharmaDataTable_data']/ancestor::table/tbody/tr/td[3]";
	public static String columnHeader = "xpath#(//tbody[@id='listingForm:pharmaDataTable_data']/ancestor::table/tbody/tr/td[3])[{%count}]";
	public static String get_Code = "xpath#//tbody[@id='listingForm:pharmaDataTable_data']/tr/td[@class='EditIcon']/following-sibling::td[1]";
	public static String code_TxtField = "xpath#//input[@id='pharmaCologicalClassDetails:pharmaClassId']";
	public static String PharmacologicalClass_TxtField = "xpath#//input[@id='pharmaCologicalClassDetails:pharmaClass']";
	public static String save_Button = "xpath#//button[@id='pharmaCologicalClassDetails:visibleSave']";
	public static String description_TextArea = "xpath#//textarea[@id='pharmaCologicalClassDetails:pharmaDesc']";
	public static String edit_Icon= "xpath#//img[@id='listingForm:pharmaDataTable:0:editImgId']";
	public static String cancel_Button= "xpath#//button[@id='pharmaCologicalClassDetails:cancelId']";
	public static String refresh_Icon = "xpath#//a[@id='listingForm:refreshImage']";
	public static String listingScreen_CheckBoxs = "xpath#//td[text()='%s']/ancestor::tbody[@id='listingForm:pharmaDataTable_data']/tr/td/div/child::div/span";
	public static String delete_Button = "xpath#//a[@id='listingForm:deleteId']";
	public static String download_Icon = "xpath#//a[@id='listingForm:actionId']";
	public static String exporttoExcel_link = "xpath#//button[contains(@id,'listingForm')]/span[text()='Export To Excel']";
	public static String exporttoExcel_popup = "xpath#//span[@id='listingForm:columnSelectionDialogId_title']";
	public static String export_Button= "xpath#//button[@id='listingForm:submitId']";
	public static String exportexcelcancel_Button= "xpath#//button[@id='listingForm:cancelDialogId']";
	public static String deleteYes_Button= "xpath#//button[@id='listingForm:confirmation_yes']";
	
	/**********************************************************************************************************
	 * @Objective:get substance name by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:DushyanthMahesh Date :16-September-2019 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderList(String num) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}


	/**********************************************************************************************************
	 * @Objective:The below method is created to select checkbox by passing value at runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name Output
	 * @Parameters:
	 * @author:Avinash K Date :18-Oct-2019 Updated by and when   	 
	**********************************************************************************************************/		
    		
    public static String selectListingCheckbox(String runTimeLabel) {
        String value = listingScreen_CheckBoxs;
        String value2;
        value2 = value.replace("%s", runTimeLabel);
        return value2;
    }














}

