package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class UsersandRolesPageObjects {

	public static String administrationHover = "xpath#//span[contains(text(),'Administration')]";
	public static String usersLink = "xpath#//a[@id='headerForm:userId']//span[@class='ui-menuitem-text'][contains(text(),'Users')]";
	public static String usersLable = "xpath#//div[@id='userForm:searchCriteria']//label[text()='User Type']";
	public static String userGroupsLink = "xpath#//span[contains(text(),'User groups')]";
	public static String userGroupsLable = "xpath#//div[@class='CaseList_Title']/label[text()='User Groups Listings']";
	public static String rolesLink = "xpath#//span[contains(text(),'Roles')]";
	public static String rolesLable = "xpath#//div[@class='CaseList_Title']/label[text()='Role Lists']";
	public static String userKeywordSearch = "xpath#//input[@id='userForm:tabView:keyword']";
	public static String groupKeywordSearch = "xpath#//input[@id='usergroupForm:keyword']";
	public static String rolesKeywordSearch = "xpath#//input[@id='rolesListForm:keywordSearch']";

}
