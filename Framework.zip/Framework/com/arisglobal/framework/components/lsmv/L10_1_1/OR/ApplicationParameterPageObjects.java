package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class ApplicationParameterPageObjects {

	public static String clickDropdown = "xpath#//label[text()='%s']/following-sibling::div/child::div/span";
	public static String setDropdown = "xpath#//ul[contains(@id,'applicationParameterForm')]/li[text()='%s']";
	public static String save_Btn = "xpath#//button[@id='applicationParameterForm:visibleSave']";

	public static String validationPopup = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String ok_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']";
	public static String subMenulinks = "xpath#//div[@id='applicationParameterForm:applicationParameterPanel']/div//table/tbody/tr/td/a/label[contains(text(),'%s')]";
	public static String exportButton = "xpath#//button[@id='applicationParameterForm:exportApplPrefId']";
	public static String importButton = "xpath#//span[@class='ui-button-icon-left ui-icon ui-c ui-icon-plusthick']";
	public static String importMessage = "xpath#//span[@id='mandatoryDialogform:mandatoryID_title']";
	
	public static String importMessagePopup = "xpath#//div[@aria-describedby='htmlValidationDailog']/div/span";
	
	public static String disclaimerMessage_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Disclaimer Message']";
	public static String timeZonePreference = "Time Zone Preference";
	public static String dateFormat = "Date Format";
	public static String centralcodeing_Link = "Central Coding";
	

	// Set dropdown pass value at runtime

	public static String setDropdown(String label) {
		String value = setDropdown.replace("%s", label);
		return value;
	}

	// Click dropdown pass LabelName at runtime

	public static String clickDropdown(String label) {
		String value = clickDropdown.replace("%s", label);
		return value;
	}
	
	/**********************************************************************************************************
	 * @Objective:click based on link name by passing link name at run time
	 * @Parameters: 
	 * @author:Avinash k Date :27-Dec-2019 Updated by and when
	 **********************************************************************************************************/
	public static String clickLink(String num) {
		String value = subMenulinks;
		String value2;
		value2 = value.replace("%s", num);
		return value2;
	}
}
