package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FDE_PregnancyPageObjects {

	public static String click_DropDown = "xpath#//label[@style='visibility: visible;'][contains(text(),'{0}')]/ancestor::span/p-dropdown/div";
	public static String setdropDownValue = "xpath#//ul[contains(@class,'ui-dropdown-items')]/child::li/div/span[contains(text(),'%s')]";
	public static String setData_Textfields = "xpath#//label[contains(@style,'visibility: visible;')][contains(text(),'%s')]/following-sibling::input";
	public static String setData_Datesfields = "xpath#//label[contains(@style,'visibility: visible;')][contains(text(),'%s')]/following-sibling::span/input";
	public static String set_GestationalAge_TxtField = "xpath#//label[contains(@style,'visibility: visible;')][contains(text(),'%s')]/following-sibling::span/input";
	public static String set_BiologicalFatherAge_TxtField = "xpath#//label[contains(@style,'visibility: visible;')][contains(text(),'%s')]/following-sibling::span/input";
	public static String click_Checkboxs = "xpath#//label[contains(@style,'visibility: visible;')][contains(text(),'%s')]/following-sibling::p-checkbox/div/child::div/span";
	public static String select_RadioButtons = "xpath#//label[contains(@style,'visibility: visible;')][contains(text(),'%s')]/following-sibling::span/p-radiobutton/label[contains(text(),'%r')]";
	public static String click_BiologicalFatherAge = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:pregnancyDetailsTable:biologicalFatherAgeUnit']/ancestor::div[@class='ui-helper-hidden-accessible']/following-sibling::label";
	public static String clickRaceDropdown = "xpath#//input[@id='adverseEventNew:patientPanelTable:patientIdentifierTable:race_focus']/following::div[@class='ui-multiselect-label-container']/label";
	public static String ageAtEvent = "xpath#//label[contains(@style,'visibility: visible;')][contains(text(),'Age at the Time of Event')]/following-sibling::span/input";
	public static String click_embeddedDrpdwn = "xpath#//label[@style='visibility: visible;'][contains(text(),'{0}')]/ancestor::span/span/p-dropdown/div";
	public static String gestationalAgemanual_Checkbox = "xpath#(//label[text()='Gestational Age at event']/following::label[text()='Manual']/../descendant::span[contains(@class,'ui-chkbox-icon')])[1]";
	public static String biologicalFatherAge_DropDown = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:pregnancyDetailsTable:biologicalFatherAgeUnit']";
	// Label Names

	// Current Pregnancy Details
	public static String pregnancyType_DropDown = "Pregnancy Type";
	public static String testDetails_DropDown = "Test Details";
	public static String expectedDeliveryDate_Date = "Expected Delivery Date";
	public static String gestationalAgeAtEvent_Textbox = "Gestational Age at event";
	public static String gestationalAgeEvent_DropDown = "Gestational Age at event";
	public static String pregnancyConfirmed_DropDown = "How was Pregnancy Confirmed?";
	public static String dateofPregnancy_Date = "Date of Pregnancy Confirmed";
	public static String biologicalFatherAge_Textbox = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:pregnancyDetailsTable:biologicalFatherAge']";
	public static String BiologicalFatherName_Txtfield = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:pregnancyDetailsTable:partnerName']";
	public static String BiologicalFatherDOB_Date = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:pregnancyDetailsTable:partnerDob:impcalinput']";
	public static String BiologicalFatherAge_Txtfield = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:pregnancyDetailsTable:biologicalFatherAge']";
	//public static String get_BiologicalFatherAgeUnit = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:pregnancyDetailsTable:biologicalFatherAgeUnit']/ancestor::div[@class='ui-helper-hidden-accessible']/following-sibling::label";
	public static String gravida_Textbox = "Gravida";
	public static String BiologicalFatherContactDetails_Txtfield = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:pregnancyDetailsTable:partnerContactDetails']";
	public static String para_Textbox = "Para";
	public static String contraceptivesUsed_Radio = "Contraceptives Used";
	public static String get_BiologicalFatherAgeUnit = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:pregnancyDetailsTable:biologicalFatherAgeUnit']/ancestor::p-dropdown/div/label";

	// Current Pregnancy Outcomes
	public static String pregnancyOutcome_DropDown = "xpath#//select[contains(@name,'pregnancyOutcome-819_focus')]";
	public static String dateOfPregnancyOutcome_Textbox = "xpath#//input[contains(@id,'pregnancyOutcomeDate:impcalinput')]";
	public static String endOfPregnancy_Date = "xpath#//input[contains(@id,'prgnancyEndDate:impcalinput')]";
	public static String dateOfPregnancyOutcome_Date = "xpath#//input[contains(@id,'pregnancyOutcomeDate:impcalinput')]";
	public static String methodOfDelivery_DropDown = "xpath#//select[contains(@name,'methodOfDelivery')]";
	public static String liveBirthComplications_DropDown = "xpath#//select[contains(@name,'liveBirthComplications-8105_focus')]";
	public static String noOfFoetus_Textbox = "xpath#//input[contains(@id,'noOfFoetus')]";
	public static String pregnancyOutcome_Getvalue = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:pregnancyOutcomesTable:pregnancyOutcome-819_focus']/ancestor::p-dropdown/div/label";
	public static String methodOfDelivery_Getvalue = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:pregnancyOutcomesTable:prgnancyEndDate:methodOfDelivery']/ancestor::p-dropdown/div/label";
	public static String liveBirthComplications_Getvalue = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:pregnancyOutcomesTable:liveBirthComplications-8105_focus']/ancestor::p-dropdown/div/label";
	
	// Neonate
	public static String neonateWeight_Textbox = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:neonateTable:neonateWeight']";
	public static String neonateWeightUnit_Dropdown = "xpath#//select[contains(@name,'adverseEventNew:pregnancyPanelTable:neonateTable:neonateWeightUnit-48_focus0')]";
	public static String neonateWeightUnit_Getvalue = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:neonateTable:neonateWeightUnit-48_focus']/ancestor::p-dropdown/div/label";
	public static String neonateBirthLengthTextbox = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:neonateTable:neonateBirthLeng']";
	public static String neonateBirthLengthUnit_Dropdown = "xpath#//select[contains(@name,'adverseEventNew:pregnancyPanelTable:neonateTable:neonateBirthLengUnit-347_focus0')]";
	public static String neonateBirthLengthUnit_Getvalue = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:neonateTable:neonateBirthLengUnit-347_focus']/ancestor::p-dropdown/div/label";
	public static String headCircumferenceAtBirth_Textbox = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:neonateTable:headCircumBirth']";
	public static String headCircumferenceAtBirthUnit_Dropdown = "xpath#//select[contains(@name,'adverseEventNew:pregnancyPanelTable:neonateTable:headCircumBirthUnit-347_focus0')]";
	public static String headCircumferenceAtBirthUnit_Getvalue = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:neonateTable:headCircumBirthUnit-347_focus']/ancestor::p-dropdown/div/label";
	public static String APGARScore1Minute_Textbox = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:neonateTable:apgarScore']";
	public static String APGARScore5Minute_Textbox = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:neonateTable:apgarScore5Minute']";
	public static String APGARScore10Minute_Textbox = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:neonateTable:apgarScore10Minute']";
	public static String otherOutcomeDetails_Textbox = "xpath#//textarea[contains(@id,'otherOutcomeDetails')]";
	public static String otherNeonateDetails_Textbox = "xpath#//textarea[contains(@id,'otherNeonateDetails')]";
	public static String zoomTextArea_Textbox = "xpath#//textarea[@name='zoomedTextArea']";
	public static String zoomClose_Button = "xpath#//span[text()='Close']";
	

	
	//Previous Pregnancy Details
	public static String previousPregnancyOutcome_Dropdown = "xpath#//select[contains(@name,'adverseEventNew:pregnancyPanelTable:prevPregnancyList:0:prevPregOutcome-8120_focus:0')]";
	public static String pastPregnancyOutcomeDetails_Textbox = "xpath#//textarea[contains(@id,'pastPregOutcomeDetails')]";
	public static String noOfChildren_Textbox = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:prevPregnancyList:0:noOfChildren:0']";
	public static String numberOfAbortions_Textbox = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:prevPregnancyList:0:numberOfAbortions:0']";
	public static String previousPregnancyOutcome_Getvalue = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:prevPregnancyList:0:prevPregOutcome-8120_focus:0']/ancestor::p-dropdown/div/label";
	
	//Child Information
	public static String sex_Dropdown = "xpath#//select[@name='adverseEventNew:pregnancyPanelTable:pregnancyChildTable:childSex:0']";
	public static String gestationAgeUnit_Dropdown = "xpath#//select[@name='adverseEventNew:pregnancyPanelTable:pregnancyChildTable:childUnit :0']";
	public static String sex_Getvalue = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:pregnancyChildTable:childSex:0']/ancestor::p-dropdown/div/label";
	public static String gestationAgeUnit_Getvalue = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:pregnancyChildTable:childUnit :0']/ancestor::p-dropdown/div/label";
	public static String gestationAge_Textbox = "xpath#//input[@id='adverseEventNew:pregnancyPanelTable:pregnancyChildTable:childAge:0']";
	
	//Codelist Tags
	public static String CLPregnancyType = "xpath#//label[text()='[8119]']";
	public static String CLTimeToExposure = "xpath#//label[text()='[9969]']";
	public static String CLHowWasPregnancyConfirmed = "xpath#//label[text()='[8108]']";
	public static String CLPlannedpregnancy = "xpath#//label[text()='Planned pregnancy?']//parent::span/label[text()='[1002]']";
	public static String CLContraceptivesUsed = "xpath#//label[text()='Contraceptives Used']//parent::span/label[text()='[1002]']";
	public static String CLContraceptivefailure = "xpath#//label[text()='Contraceptive failure']//parent::span/label[text()='[1002]']";
	public static String CLPrePregnancyWeight= "xpath#//label[text()='[9991]']";
	public static String CLFamilyHistoryOfBirthDefects = "xpath#//label[text()='Family history of birth defects']//parent::span/label[text()='[1002]']";
	public static String CLBiologicalFatherAge = "xpath#//label[text()='[1016]']";
	public static String CLPregnancyOutcome = "xpath#//label[text()='Pregnancy Outcome ']//parent::span/label[text()='[8120]']";
	public static String CLMethodOfDelivery = "xpath#//label[text()='[9134]']";
	public static String CLLiveBirthComplications = "xpath#//label[text()='[8105]']";
	public static String CLGender = "xpath#//label[text()='[1007]']";
	public static String CLWhichPregnancy = "xpath#//label[text()='[9986]']";
	public static String CLBirthOutcome = "xpath#//label[text()='[9994]']";
	public static String CLResuscitated = "xpath#//label[text()='Resuscitated ']//parent::span/label[text()='[1002]']";
	public static String CLNICUAdmission = "xpath#//label[text()='NICU admission ']//parent::span/label[text()='[1002]']";
	public static String CLCongenitalAnomaly = "xpath#//label[text()='Congenital Anomaly ']//parent::span/label[text()='[1002]']";
	public static String CLAdmissionDuration = "xpath#//label[text()='[9987]']";
	public static String CLCongenitalAnomalyType = "xpath#//label[text()='[9988]']";
	public static String CLPreviousPregnancyOutcome = "xpath#//label[text()='Previous Pregnancy Outcome']//parent::th/label[text()='[8120]']";
	
	/**********************************************************************************************************
	 * Objective:The below method is created to Gestational Age text field by
	 * passing label name at runtime. Input Parameters: ColumnName Scenario Name
	 * Output Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String set_GestationalAge_TxtField(String runTimeLabel) {
		String value = set_GestationalAge_TxtField;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to Gestational Age text field by
	 * passing label name at runtime. Input Parameters: ColumnName Scenario Name
	 * Output Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String set_BiologicalFatherAge_TxtField(String runTimeLabel) {
		String value = set_BiologicalFatherAge_TxtField;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}
	/**********************************************************************************************************
	 * Objective:The below method is created to set data in text field by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String setData_Textfields(String runTimeLabel) {
		String value = setData_Textfields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to set data in date field by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String setData_Datesfields(String runTimeLabel) {
		String value = setData_Datesfields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click checkboxs by passing label
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String click_Checkboxs(String runTimeLabel) {
		String value = click_Checkboxs;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select radio button by passing label
	 * name and value at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String select_RadioButtons(String runTimeLabel, String valueRuntime) {
		String value = select_RadioButtons.replace("%s", runTimeLabel);
		value = value.replace("%r", valueRuntime);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click drop downs by passing label
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String click_DropDown(String label) {
		String value = click_DropDown.replace("{0}", label);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click embedded drop downs by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String click_embeddedDrpdwn(String label) {
		String value = click_embeddedDrpdwn.replace("{0}", label);
		return value;
	}

	// set Drop down value
	public static String setdropDownValue(String data) {
		String value = setdropDownValue.replace("%s", data);
		return value;
	}

}
