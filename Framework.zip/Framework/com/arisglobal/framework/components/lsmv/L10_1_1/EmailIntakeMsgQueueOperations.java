package com.arisglobal.framework.components.lsmv.L10_1_1;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.EmailIntakeMsgQueuePageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class EmailIntakeMsgQueueOperations extends ToolManager {
	static String className = EmailIntakeMsgQueueOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to search the Receipt Number by
	 *             searching the dynamic Email subject
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 06-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchRctNum(String emailSubject, String scenarioName, String sheetName) {
		agSetStepExecutionDelay("2000");
		String ProcessingStatus, EmptyRowStatus = null;
		agIsVisible(EmailIntakeMsgQueuePageObjects.searchTextBox);
		agSetValue(EmailIntakeMsgQueuePageObjects.searchTextBox, emailSubject);
		agClick(EmailIntakeMsgQueuePageObjects.searchIcon);
		EmptyRowStatus = agGetText(EmailIntakeMsgQueuePageObjects.emptyRow);
		int count = 1;
		if (agGetText(EmailIntakeMsgQueuePageObjects.emptyRow).contains("No records to display")) {
			do {
				count++;
				agClick(EmailIntakeMsgQueuePageObjects.searchIcon);
				EmptyRowStatus = agGetText(EmailIntakeMsgQueuePageObjects.emptyRow);
				agSetStepExecutionDelay("3000");
				System.out.println("waiting : " + count);
			} while (EmptyRowStatus.contains("No records to display") && count < 10);

		}

		if (EmptyRowStatus.contains("No records to display")) {
			Reports.ExtentReportLog("", Status.FAIL,
					"Given Receipt Number for scenario " + scenarioName + " fetches no records", true);
		}

		// Refresh multiples times until case visible
		do {
			agSetStepExecutionDelay("2000");
			agIsVisible(EmailIntakeMsgQueuePageObjects.searchTextBox);
			agSetValue(EmailIntakeMsgQueuePageObjects.searchTextBox, emailSubject);
			agClick(EmailIntakeMsgQueuePageObjects.searchIcon);
			// EmptyRowStatus = agGetText(EmailIntakeMsgQueuePageObjects.emptyRow);
			agAssertVisible(EmailIntakeMsgQueuePageObjects.emptyRow);
			agWaitTillVisibilityOfElement(EmailIntakeMsgQueuePageObjects.emptyRow);

			agWaitTillVisibilityOfElement(
					EmailIntakeMsgQueuePageObjects.getTextColumn(EmailIntakeMsgQueuePageObjects.status));
			agSetStepExecutionDelay("2000");
			ProcessingStatus = agGetText(
					EmailIntakeMsgQueuePageObjects.getTextColumn(EmailIntakeMsgQueuePageObjects.status));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} while (ProcessingStatus.equalsIgnoreCase("PROCESSING"));

		if (ProcessingStatus.equalsIgnoreCase("SUCCESSFUL")) {
			agJavaScriptExecuctorScrollToElement(
					EmailIntakeMsgQueuePageObjects.getTextColumn(EmailIntakeMsgQueuePageObjects.receiptNo));

			agSetStepExecutionDelay("2000");
			agWaitTillVisibilityOfElement(
					EmailIntakeMsgQueuePageObjects.getTextColumn(EmailIntakeMsgQueuePageObjects.receiptNo));
			String rctNum = agGetText(
					EmailIntakeMsgQueuePageObjects.getTextColumn(EmailIntakeMsgQueuePageObjects.receiptNo));
			CommonOperations.takeScreenShot();

			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
			String RecieptNumberPrefix = getTestDataCellValue("LSMV_ISP_Config", "ReceiptPrefix");

			if (rctNum.contains(RecieptNumberPrefix)) {
				Reports.ExtentReportLog("", Status.PASS,
						"Receipt Numbering Format - Prefix is getting Mapped With Created Reciept Number", true);

			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Receipt Numbering Format - Prefix is getting Mapped  With Created Reciept Number", true);
			}

			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "ReceiptNo", rctNum);
		} else {
			Reports.ExtentReportLog("", Status.INFO, " Receipt Number not visible " + scenarioName, true);

		}
	}

}
