package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class DocumentsPageObjects {

	public static String DocumentsHover = "xpath#//span[@class='ui-menuitem-text'][contains(text(),'Documents')]";
	public static String DocumentListing = "xpath#//a[@id='headerForm:docListId']//span[contains(text(),'Listing')]";
	public static String basicsearchTextbox = "xpath#//input[@id='documentForm:searchFieldId']";

	public static String CaseDocumentBtn = "xpath#//a//span[contains(text(),'Case Documents')]";
	public static String AddDocBtn = "xpath#//div[contains(text(),'Source Document')]//button[text()='Add']";
	public static String UploadDocument = "xpath#(//input[@type='file' and @onchange='sourceDocGetFileName(event)'])[1]";
	public static String UploadDocument1 = "xpath#(//input[@type='file' and @onchange='sourceDocGetFileName(event)'])[2]";
	public static String UploadDocument2 = "xpath#(//input[@type='file' and @onchange='sourceDocGetFileName(event)'])[3]";
	public static String filenamelink = "xpath#(//a[@id='docNmae'])[1]";
}
