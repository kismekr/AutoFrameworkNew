package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_ProductsPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;

public class CaseSignificanceScenarios extends ToolManager {

	public static WebElement webElement;
	static String className = CaseSignificanceScenarios.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: This method is created load data from excel sheet
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 09-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void loadDataToMultimap() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 09-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	public static String getCaseSignificanceVal(String scenarioName) {
		return Multimaplibraries.getTestDataCellValue(scenarioName, "General_CaseSignificance");
	}

	/**********************************************************************************************************
	 * @Objective: Below method is created to update Therapy Data
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 12-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void UpdateTherapyDate(String scenarioName, String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "AddtherapyStartDateNullFlavour").equalsIgnoreCase("YES")) {
			agClick(FDE_ProductsPageObjects.click_NFBtn(FDE_ProductsPageObjects.therapyStartDate));
			agSetStepExecutionDelay("2000");
			agIsVisible(FDE_ProductsPageObjects.nullFlavoupPopUp);
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.nullFlavoupPopUpYesButton);
		}
		if (getTestDataCellValue(scenarioName, "RemovetherapyStartDateNullFlavour").equalsIgnoreCase("YES")) {
			agClick(FDE_ProductsPageObjects.click_UndoNFBtn(FDE_ProductsPageObjects.therapyStartDate));
			agSetStepExecutionDelay("2000");
			agIsVisible(FDE_ProductsPageObjects.nullFlavoupPopUp);
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.nullFlavoupPopUpYesButton);
		}
		if (getTestDataCellValue(scenarioName, "AddtherapyStartDateNullFlavourWhenBlankData").equalsIgnoreCase("YES")) {
			agClick(FDE_ProductsPageObjects.click_NFBtn(FDE_ProductsPageObjects.therapyStartDate));
			agSetStepExecutionDelay("2000");
		}
		if (getTestDataCellValue(scenarioName, "AddtherapyEndDateNullFlavourWhenBlankData").equalsIgnoreCase("YES")) {
			agClick(FDE_ProductsPageObjects.click_NFBtn(FDE_ProductsPageObjects.therapyEndDate));
			agSetStepExecutionDelay("2000");
		}
		if (getTestDataCellValue(scenarioName, "AddtherapyEndDateNullFlavour").equalsIgnoreCase("YES")) {
			agClick(FDE_ProductsPageObjects.click_NFBtn(FDE_ProductsPageObjects.therapyEndDate));
			agSetStepExecutionDelay("2000");
			agIsVisible(FDE_ProductsPageObjects.nullFlavoupPopUp);
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.nullFlavoupPopUpYesButton);
		}
		if (getTestDataCellValue(scenarioName, "RemovetherapyEndDateNullFlavour").equalsIgnoreCase("YES")) {
			agClick(FDE_ProductsPageObjects.click_UndoNFBtn(FDE_ProductsPageObjects.therapyEndDate));
			agSetStepExecutionDelay("2000");
			agIsVisible(FDE_ProductsPageObjects.nullFlavoupPopUp);
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.nullFlavoupPopUpYesButton);
		}
		if (getTestDataCellValue(scenarioName, "therapyStartDateBlank").equalsIgnoreCase("YES")) {
			agClearText(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate));
			agSendKeyStroke(Keys.TAB);
			CommonOperations.captureScreenShot(true);
		}
		if (getTestDataCellValue(scenarioName, "therapyEndDateBlank").equalsIgnoreCase("YES")) {
			agClearText(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyEndDate));
			agSendKeyStroke(Keys.TAB);
			CommonOperations.captureScreenShot(true);
		}
		if (getTestDataCellValue(scenarioName, "AddtherapyStartDateNullFlavour").equalsIgnoreCase("YES")
				|| getTestDataCellValue(scenarioName, "AddtherapyStartDateNullFlavourWhenBlankData")
						.equalsIgnoreCase("YES")) {
			setProductNFDropDownValue(FDE_ProductsPageObjects.therapyStartDate, scenarioName, "therapyStartDateNFV",
					sheetName);
			CommonOperations.captureScreenShot(true);
		}
		if (getTestDataCellValue(scenarioName, "AddtherapyEndDateNullFlavour").equalsIgnoreCase("YES")
				|| getTestDataCellValue(scenarioName, "AddtherapyEndDateNullFlavourWhenBlankData")
						.equalsIgnoreCase("YES")) {
			setProductNFDropDownValue(FDE_ProductsPageObjects.therapyEndDate, scenarioName, "therapyEndDateNFV",
					sheetName);
			CommonOperations.captureScreenShot(true);

		} else {
			agSetValue(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate),
					getTestDataCellValue(scenarioName, "therapyStartDate"));
			agSendKeyStroke(Keys.TAB);
			agSetStepExecutionDelay("3000");
			agSetValue(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyEndDate),
					getTestDataCellValue(scenarioName, "therapyEndDate"));
			agSendKeyStroke(Keys.TAB);
			CommonOperations.captureScreenShot(true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to select Null Flavour value from dropdown
	 *             based on excel data using Sheet name
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 22-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setProductNFDropDownValue(String label, String scenarioName, String columnName,
			String SheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			// agClick(FDE_ProductsPageObjects.NFproductDropdownSelect(label));
			// agClick(FDE_GeneralPageObjects.clickDropDownValue(getTestDataCellValue(scenarioName,
			// columnName)));

			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.NFproductDropdownSelect(label));
			agJavaScriptExecuctorClick(
					FDE_GeneralPageObjects.clickDropDownValue(getTestDataCellValue(scenarioName, columnName)));
		}
	}

	/**********************************************************************************************************
	 * @Objective: Below method is created to Navigate to product
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 12-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void productNavagation(String scenarioName, String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String result = (getTestDataCellValue(scenarioName, "Products_ProductName"));
		agJavaScriptExecuctorClick(FDE_ProductsPageObjects.selectProduct(result));
		agSetStepExecutionDelay("3000");
	}

	/**********************************************************************************************************
	 * @Objective: Below method is created to update the Route Of Admin for
	 *             different products
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 24-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateRouteOfAdmin(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "RouteOfAdminNullFlavourFlag").equalsIgnoreCase("YES")) {
			agClick(FDE_ProductsPageObjects.click_NFBtn(FDE_ProductsPageObjects.routeOfAdmin_Dropdown));
			// Null flavour Pop up
			agIsVisible(FDE_ProductsPageObjects.nullFlavoupPopUp);
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.nullFlavoupPopUpYesButton);
			// Selecting the value from NF dropdown
			agClick(FDE_ProductsPageObjects.NFproductDropdownSelect(FDE_ProductsPageObjects.routeOfAdmin_Dropdown));
			agClick(FDE_GeneralPageObjects
					.clickDropDownValue(getTestDataCellValue(scenarioName, "Products_Therapies_RouteOfAdmin")));
			CommonOperations.takeScreenShot();
			agClearText(FDE_ProductsPageObjects.routeofAdministrationTermID);
		} else {
			agClick(FDE_ProductsPageObjects.click_UndoNFBtn(FDE_ProductsPageObjects.routeOfAdmin_Dropdown));
			agIsVisible(FDE_ProductsPageObjects.nullFlavoupPopUp);
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.nullFlavoupPopUpYesButton);
			FDE_Products.setProductDropDownValue(FDE_ProductsPageObjects.routeOfAdmin_Dropdown, scenarioName,
					"Products_Therapies_RouteOfAdmin");
			CommonOperations.takeScreenShot();
			agClearText(FDE_ProductsPageObjects.routeofAdministrationTermID);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Below method is created to update Product
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 26-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateProduct(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.prductNameAsReportedTxtbox),
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductNameAsReported"));
		agSendKeyStroke(Keys.TAB);
		FDE_Products.recalculatePOPUPNo();
	}

	/**********************************************************************************************************
	 * @Objective: Below method is created to update the Route Of Admin for
	 *             different products
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 26-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateFormOfAdmin(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "FormOfAdminNullFlavourFlag").equalsIgnoreCase("YES")) {
			agClick(FDE_ProductsPageObjects.click_NFBtn(FDE_ProductsPageObjects.formOfAdmin_Dropdown));
			// Null flavour Pop up
			agIsVisible(FDE_ProductsPageObjects.nullFlavoupPopUp);
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.nullFlavoupPopUpYesButton);
			// Selecting the value from NF dropdown
			agClick(FDE_ProductsPageObjects.NFproductDropdownSelect(FDE_ProductsPageObjects.formOfAdmin_Dropdown));
			agClick(FDE_GeneralPageObjects
					.clickDropDownValue(getTestDataCellValue(scenarioName, "Products_Therapies_FormOfAdmin")));
			CommonOperations.takeScreenShot();
			agClearText(FDE_ProductsPageObjects.PharmaceuticalTermID_TxtField);
		} else if (getTestDataCellValue(scenarioName, "FormOfAdminNullFlavourFlag").equalsIgnoreCase("NO")) {
			// Undoing Null Flavour
			agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.therapy);
			agJavaScriptExecuctorClick(
					FDE_ProductsPageObjects.click_UndoNFBtn(FDE_ProductsPageObjects.formOfAdmin_Dropdown));
			agIsVisible(FDE_ProductsPageObjects.nullFlavoupPopUp);
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.nullFlavoupPopUpYesButton);
			agClick(FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.formOfAdmin_Dropdown));
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects
					.clickDropDownValue(getTestDataCellValue(scenarioName, "Products_Therapies_FormOfAdmin")));
			CommonOperations.takeScreenShot();
			agClearText(FDE_ProductsPageObjects.PharmaceuticalTermID_TxtField);
		} else {
			agSetStepExecutionDelay("2000");
			agClick(FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.formOfAdmin_Dropdown));
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects
					.clickDropDownValue(getTestDataCellValue(scenarioName, "Products_Therapies_FormOfAdmin")));
			CommonOperations.takeScreenShot();
			agClearText(FDE_ProductsPageObjects.PharmaceuticalTermID_TxtField);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: Below method is created to update Therapy Information
	 * @OutputParameters:
	 * @author: Abhilash M U
	 * @Date : 29-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateTherapyinfo(String scenario) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		agSetValue(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyEndDate),
				getTestDataCellValue(scenario, "therapyEndDate"));
		// agSendKeyStroke(Keys.TAB);
		agSetStepExecutionDelay("4000");
		agSetValue(FDE_ProductsPageObjects.lotNumber_TextField, getTestDataCellValue(scenario, "LotNo"));
	}

	/*
	 * 
	 * public static void deleteConcomitantProduct(String scenario) {
	 * 
	 * }
	 */
	/**********************************************************************************************************
	 * @Objective: Below method is created to update LotNo
	 * @OutputParameters:
	 * @author: Abhilash M U
	 * @Date : 31-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void UpdateLotNo(String scenarioName, String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "LotNoNullFlavour").equalsIgnoreCase("YES")) {
			agClick(FDE_ProductsPageObjects.click_NFBtn(FDE_ProductsPageObjects.lotnumber_Dropdown));
			agSetStepExecutionDelay("2000");
			agIsVisible(FDE_ProductsPageObjects.nullFlavoupPopUp);
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.nullFlavoupPopUpYesButton);
		}
		if (getTestDataCellValue(scenarioName, "RemoveLotNoNullFlavour").equalsIgnoreCase("YES")) {
			agClick(FDE_ProductsPageObjects.click_UndoNFBtn(FDE_ProductsPageObjects.lotnumber_Dropdown));
			agSetStepExecutionDelay("2000");
			agIsVisible(FDE_ProductsPageObjects.nullFlavoupPopUp);
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.nullFlavoupPopUpYesButton);
		}
		if (getTestDataCellValue(scenarioName, "LotNoNullFlavour").equalsIgnoreCase("YES")) {
			setProductNFDropDownValue(FDE_ProductsPageObjects.lotnumber_Dropdown, scenarioName, "theLotNoNFV",
					sheetName);
			CommonOperations.captureScreenShot(true);
		} else {
			agSetStepExecutionDelay("2000");

			agSetValue(FDE_ProductsPageObjects.lotNumber_TextField, getTestDataCellValue(scenarioName, "LotNo"));
			// agSetValue(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.lotNumber_TextField),
			// getTestDataCellValue(scenarioName, "LotNo"));
			agSendKeyStroke(Keys.TAB);
			CommonOperations.captureScreenShot(true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Below method is created to update the unit dose , Unit and
	 *             frequency for different products
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 09-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateUnitDoseUnitAndFrequency(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(FDE_ProductsPageObjects.therapis_Label);
		if (getTestDataCellValue(scenarioName, "UnitDoseFlag").equalsIgnoreCase("YES")) {
			agSetValue(FDE_ProductsPageObjects.unitDose_TextField,
					getTestDataCellValue(scenarioName, "Products_Therapies_UnitDose"));
			CommonOperations.takeScreenShot();
		} else {
			agClearText(FDE_ProductsPageObjects.unitDose_TextField);
			CommonOperations.takeScreenShot();
		}
		if (!getTestDataCellValue(scenarioName, "Products_Therapies_UnitDoseUnit").equalsIgnoreCase("#skip#")) {
			FDE_Products.setProductEmbedDropDownValue(FDE_ProductsPageObjects.unitDose_dropdown, scenarioName,
					"Products_Therapies_UnitDoseUnit");
			CommonOperations.takeScreenShot();
		}
		if (!getTestDataCellValue(scenarioName, "Products_Therapies_Frequency").equalsIgnoreCase("#skip#")) {
			agSetValue(FDE_ProductsPageObjects.frequency_TextField,
					getTestDataCellValue(scenarioName, "Products_Therapies_Frequency"));
			CommonOperations.takeScreenShot();
		} else if (getTestDataCellValue(scenarioName, "Products_Therapies_Frequency").equalsIgnoreCase("")) {
			agClearText(FDE_ProductsPageObjects.frequency_TextField);
			CommonOperations.takeScreenShot();
		}
	}
}
