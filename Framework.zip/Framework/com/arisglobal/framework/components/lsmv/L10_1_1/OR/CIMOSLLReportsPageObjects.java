package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class CIMOSLLReportsPageObjects {

	public static String cimosLLReportsSearchTextbox = "xpath#//input[contains(@title,'Report Name')]";
	// public static String searchIcon =
	// "xpath#//div[@targetpanelid='targetPanelForCiomsLLHome']/div[@class='lsmv-field-text']/span[@class='lsmv-search-icon']";
	public static String searchIcon = "xpath#//div[@targetpanelid='targetPanelForCiomsLLHome']/div[@class='lsmv-field-text']/span[@class='lsmv-grid-search-icon']";
	public static String paginator = "xpath#//div[@id='targetPanelForCiomsLLHome']//div[@class='lsmv-grid-pager-class']/span[@class='lsmv-pager-info']";
	public static String ReportName_label = "xpath#//span[text()='CIOMS LL REPORT']";

	public static String refresh_icon = "xpath#//a[@id='listingForm:refreshImage']";
	public static String get_ListofReportName = "xpath#//div[@class='lsmv-grid-panel mainGridCmp']/div[@class='lsmv-grid-row'][1]/div[@class='lsmv-grid-col lsmv-tooltip '][1]";
	public static String columnHeader = "xpath#(//tbody[@id='listingForm:batchPrintDataTable_data']/tr/child::td[3])[{%count}]";

	public static String new_Btn = "xpath#//div[@targetpanelid='targetPanelForCiomsLLHome']/span[@id='newBtnId']";
	public static String delete_Btn = "xpath#//div[@targetpanelid='targetPanelForCiomsLLHome']/span[@id='deleteBtnId']";

	public static String clickdropdown = "xpath#//div[@class='gridAdvSearchFormPanel']//div[@class='form-group']/label[starts-with(text(),'%s')]/following-sibling::div/select";
	public static String setdropdown = "xpath#//select[@class='advSearchFields']/option[text()='%s']";
	public static String setdropdownprintSelectionCriteria_dropdown = "xpath#//select[@title='Print Selection Criteria']/option[text()='%s']";
	public static String setscheduledReport_dropdown = "xpath#//select[@title='Scheduled Report']/option[text()='%s']";
	public static String countryOfLabellingt_dropdown = "xpath#//select[@title='Country Of Labelling']/option[text()='%s']";

	public static String setText = "xpath#//div[@class='gridAdvSearchFormPanel']//div[@class='form-group']/label[text()='%s']/following-sibling::div/input";
	public static String reportName_Txtfield = "Report Name";
	public static String aerNo_Txtfield = "AER#";
	public static String approvalNo_Txtfield = "Approval No";

	public static String reportFormat_dropdown = "Report Format";
	public static String suspectProduct_dropdown = "Suspect Product";
	public static String approvalType_dropdown = "Approval Type";
	public static String approvalCountry_dropdown = "Approval Country";
	public static String routeOfAdmin_dropdown = "Route Of Admin";
	public static String formOfAdmin_dropdown = "Form Of Admin";
	public static String reportType_dropdown = "Report Type";
	public static String countryOfLabelling_dropdown = "Country Of Labelling";
	public static String includeUnapprovedCases_dropdown = "Include Unapproved Cases";
	public static String labelled_dropdown = "Labelled";
	public static String caseSeriousness_dropdown = "Case Seriousness";
	public static String printSelectionCriteria_dropdown = "Print Selection Criteria";
	public static String blindingType_dropdown = "Blinding Type";
	public static String scheduledReport_dropdown = "Scheduled Report";
	public static String scheduleType_dropdown = "Schedule Type";
	public static String days_dropdown = "Day(s)";
	public static String months_dropdown = "Month(s)";
	public static String date_dropdown = "Date";
	public static String drugRadioBtn = "xpath#//div/label[text()='Drug']/preceding::input[@type='radio']";
	public static String deviceRadioBtn = "xpath#(//div/label[text()='Device']/preceding::input[@type='radio'])[2]";
	public static String generate_Btn = "xpath#//div[@class='gridButtonBarClass']/span[@id='generateReportBtn']";
	public static String clearBtn = "xpath#//div[@class='gridButtonBarClass']/span[@id='clearCiomsBtn']";
	public static String closeBtn = "xpath#//div[@class='gridButtonBarClass']/span[@id='closeNotesBtn']";
	public static String criteriaName = "xpath#(//input[@class='saveFilterCriteriaInput'])[2]";

	public static String productLookupIcon = "xpath#//input[@fieldid='productDesc']/following-sibling::span[@class='lsmv-lookup-icon']";
	public static String productLookupsearchTextField = "xpath#//div[@targetpanelid='targetPanelForDataLibLookup']/div/span/following-sibling::input[@type='text']";
	public static String productLookupSearchIcon = "xpath#//div[@targetpanelid='targetPanelForDataLibLookup']/div/span[@class='lsmv-grid-search-icon']";
	public static String productLookupSelectcheckbox = "xpath#//div[@fieldid='name']/span[text()='%s']/ancestor::div[@class='lsmv-grid-row']/span";
	public static String productLookupSelectBtn = "xpath#//span[@id='selecctBtnId']";

	public static String protocolNoLookupIcon = "xpath#//input[@fieldid='protocolNumber']/following-sibling::span[@class='lsmv-lookup-icon']";
	public static String protocolNosearchTextField = "xpath#//div[@targetpanelid='targetPanelForDataLibLookup']/div/span/following-sibling::input[@type='text']";
	public static String protocolNoSearchIcon = "xpath#//div[@targetpanelid='targetPanelForDataLibLookup']/div/span[@class='lsmv-search-icon']";
	public static String protocolNoSelectcheckbox = "xpath#//div[@fieldid='studyNo']/span[text()='%s']/ancestor::div[@class='lsmv-grid-row']/span";
	public static String protocolNoSelectBtn = "xpath#//span[@id='selecctBtnId']";

	public static String monthSelect = "xpath#//label[text()='%s']/parent::div//div[@class='lsmv-calendar-box']//select[@class='calendar-month']";
	public static String yearSelect = "xpath#//label[text()='%s']/parent::div//div[@class='lsmv-calendar-box']//select[@class='calendar-year']";
	public static String monthDropdown = "xpath#//div[@class='lsmv-calendar-box']//select[@class='calendar-month']/option[starts-with(text(),'{@}')]";
	public static String yearDropdown = "xpath#//div[@class='lsmv-calendar-box']//select[@class='calendar-year']/option[text()='{@}']";
	public static String dateSelect = "xpath#//label[text()='%s']/parent::div//div[@class='lsmv-calendar-box']//a[contains(@onclick,'lsmv_calendar')][text()='{@}']";
	public static String setDatesTextboxes = "xpath#//label[text()='%s']//parent::div//span[@class='lsmv-calendarIcon']";

	public static String lrdFromDate = "LRD From Date";

	public static String lrdToDate = "LRD To Date";
	public static String dateTime = "DateTime";

	public static String downlaodIcon = "xpath#(//span[@class='download_icon'])[1]";
	public static String processIcon = "xpath#//span[@class='process_icon']";
	// public static String refresh_Btn =
	// "xpath#(//span[@class='lsmv-refresh-icon'][text()='Refresh'])[1]";
	public static String refresh_Btn = "xpath#(//span[@class='lsmv-refresh-icon'][text()='CIOMS LL Reports'])[1]";
	public static String statusQueued = "xpath#//div[text()='QUEUED']";
	public static String statusCompleted = "xpath#(//div[text()='COMPLETED'])[1]";
	public static String datesIcon = "xpath#(//label[text()='%s']//following::span[@class='lsmv-calendarIcon'])[1]";
	public static String todaySelect = "xpath#//input[@value='Today']";
	public static String reportFormat_Dropdown = "xpath#//select[@title='Report Format']";
	public static String mostSuspect_Dropdown = "xpath#//select[@title='Suspect Product']";
	public static String approvalCountry_Dropdown = "xpath#//select[@title='Approval Country']";
	public static String approvalType_Dropdown = "xpath#//select[@title='Approval Type']";
	public static String routeofAdmin_Dropdown = "xpath#//select[@title='Route Of Admin']";
	public static String formofAdmin_Dropdown = "xpath#//select[@title='Form Of Admin']";
	public static String reportType_Dropdown = "xpath#//select[@title='Report Type']";
	public static String includeUnApprovedCases_Dropdown = "xpath#//select[@title='Include Unapproved Cases']";
	public static String labelled_Dropdown = "xpath#//select[@title='Labelled']";
	public static String caseSeriousness_Dropdown = "xpath#//select[@title='Case Seriousness']";
	public static String printSelectionCriteria = "xpath#//select[@title='Print Selection Criteria']";
	public static String successfulllyMessage = "xpath#//span[text()='Successfully Saved']";
	public static String generateBtn = "xpath#//span[@id='gridgenerateReportBtn'][text()='Generate Report']";
	public static String deleteCheckBox = "xpath#//span[@class='lsmv-grid-sel-all-chk lsmv-grid-sel-unchk']";
	public static String deleteMessage = "xpath#//span[text()='Deleted Successfully']";
	public static String colHeader = "xpath#//div[@class='lsmv-grid-panel mainGridCmp']/div[@class='lsmv-grid-row'][{%count}]/div[@class='lsmv-grid-col lsmv-tooltip '][1]";
	public static String exportAllData_Radio = "xpath#//span[text()='Export All Data']/preceding::input[@value='3']";
	public static String exportToExcel_Btn = "xpath#//span[text()='Export As Excel']";
	public static String cancel_Btn = "xpath#//span[text()='Cancel']";
	public static String dataExpConfig_Text = "xpath#//span[text()='Data Export Configurations']";

	public static String datesSelect(String runTimeLabel) {
		String value = datesIcon;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String productlookupSelectAllcheckbox(String runTimeLabel) {
		String value = productLookupSelectcheckbox;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String protocolNoSelectcheckbox(String runTimeLabel) {
		String value = protocolNoSelectcheckbox;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String setTextFields(String runTimeLabel) {
		String value = setText;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String clickdropdown(String runTimeLabel) {
		String value = clickdropdown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String setdropdown(String runTimeLabel) {
		String value = setdropdown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String setdropdownprintSelectionCriteria_dropdown(String runTimeLabel) {
		String value = setdropdownprintSelectionCriteria_dropdown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String countryOfLabellingt_dropdown(String runTimeLabel) {
		String value = countryOfLabellingt_dropdown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String setscheduledReport_dropdown(String runTimeLabel) {
		String value = setscheduledReport_dropdown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String dateSelect(String label, String date) {
		String value = dateSelect;
		value = value.replace("%s", label);

		String value1 = value.replace("{@}", date);
		return value1;
	}

	public static String monthDropdown(String month) {
		String value = monthDropdown;
		value = value.replace("{@}", month);
		return value;
	}

	public static String monthClick(String month) {
		String value = monthSelect;
		value = value.replace("%s", month);
		return value;
	}

	public static String yearDropdown(String year) {
		String value = yearDropdown;
		value = value.replace("{@}", year);
		return value;
	}

	public static String yearClick(String year) {
		String value = yearSelect;
		value = value.replace("%s", year);
		return value;
	}

	public static String setDatesTextboxes(String label) {
		String value = setDatesTextboxes.replace("%s", label);
		return value;
	}

	public static String batchName_Txtfield = "xpath#//input[@id='batchPrintDetails:batchNameId']";
	public static String click_BatchConfigurationName = "xpath#//div[@id='batchPrintDetails:batchprinterId']/div/span";
	public static String set_BatchConfigName = "xpath#//ul[@id='batchPrintDetails:batchprinterId_items']/li[text()='%s']";
	public static String printBy_Radiobtns = "xpath#//label[contains(@for,'batchPrintDetails:selectOptionBatchPrinting') and text()='%s']/ancestor::td/div//span";
	public static String dateRange_RadioBtn = "Date Range";
	public static String commaseparatedAERNo_RadioBtn = "Comma separated AER No.s";
	public static String uploadFile_RadioBtn = "Upload File";
	public static String savedSearches_RadioBtn = "Saved Searches ";
	public static String description_Txtarea = "xpath#//textarea[@id='batchPrintDetails:description']";

	public static String reportType_RadioBtn = "xpath#//label[contains(@for,'batchPrintDetails:versionLabel') and text()='%s']/ancestor::td/div//span";
	public static String draft_RadioBtn = "Draft";
	public static String final_RadioBtn = "Final";

	public static String dataPrivacyTypeRadiobtns = "xpath#//label[contains(@for,'batchPrintDetails:dataPrivcyID') and text()='%s']/ancestor::td/div//span";
	public static String masked_RadioBtn = "Masked";
	public static String unmasked_RadioBtn = "UnMasked";

	public static String blindingTypeRadiobtns = "xpath#//label[contains(@for,'batchPrintDetails:blindingID') and text()='%s']/ancestor::td/div//span";
	public static String blinded_RadioBtn = "Blinded";
	public static String unblinded_RadioBtn = "Unblinded";

	public static String printTypeRadiobtns = "xpath#//label[contains(@for,'batchPrintDetails:printTypeId') and text()='%s']/ancestor::td/div//span";
	public static String pdf_RadioBtn = "PDF";
	public static String paper_RadioBtn = "Paper";
	public static String checkboxs = "xpath#//label[text()='%s']/parent::div/child::div//span";
	public static String cIOMS_checkbox = "CIOMS";
	public static String schedule_checkbox = "Schedule";
	public static String medWatch_checkbox = "MedWatch";
	public static String includeCoverPage_checkbox = "Include Cover Page";

	public static String click_ScheduleType = "xpath#//div[@id='batchPrintDetails:schedularDropDown']/div/span";
	public static String set_ScheduleType = "xpath#//ul[@id='batchPrintDetails:schedularDropDown_items']/li[text()='%s']";

	public static String fromDate = "xpath#//input[@id='batchPrintDetails:batchPrintStartDate_input']";
	public static String aerNo_Txtarea = "xpath#//textarea[@id='batchPrintDetails:caseRecordIds']";
	public static String toDate = "xpath#//input[@id='batchPrintDetails:batchPrintEndDate_input']";
	public static String getBatchConfigName = "xpath#//label[@id='batchPrintDetails:batchprinterId_label']";
	public static String getSchedularName = "xpath#//label[@id='batchPrintDetails:schedularDropDown_label']";

	public static String listingScreen_CheckBoxs = "xpath#//td/a[text()='%s']/ancestor::tbody[@id='listingForm:batchPrintDataTable_data']/tr/td/div/child::div/span";

	public static String downloadIcon = "xpath#//span[@title='Download/Export Grid Records']";
	public static String exporttoExcel_link = "xpath#//button[contains(@id,'listingForm:j_id_lr')]/span[text()='Export To Excel']";
	public static String exporttoExcel_popup = "xpath#//span[@id='listingForm:columnSelectionDialogId_title']";
	public static String export_Btn = "xpath#//button[@id='listingForm:submitId']";
	public static String exportexcelcancel_Btn = "xpath#//button[@id='listingForm:cancelDialogId']";

	public static String click_blindingTypeRadiobtns(String runTimeLabel) {
		String value = blindingTypeRadiobtns;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String set_ScheduleTypeDropdown(String runTimeLabel) {
		String value = set_ScheduleType;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String clickcheckboxs(String runTimeLabel) {
		String value = checkboxs;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String set_BatchConfigurationName(String runTimeLabel) {
		String value = set_BatchConfigName;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String click_printByRadiobtns(String runTimeLabel) {
		String value = printBy_Radiobtns;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String click_reportTypeRadioBtn(String runTimeLabel) {
		String value = reportType_RadioBtn;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String click_dataPrivacyTypeRadiobtns(String runTimeLabel) {
		String value = dataPrivacyTypeRadiobtns;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String click_printTypeRadiobtns(String runTimeLabel) {
		String value = printTypeRadiobtns;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select checkbox by passing value at
	 *                runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name Output
	 * @Parameters:
	 * @author:Avinash K Date :18-Oct-2019 Updated by and when
	 **********************************************************************************************************/

	public static String selectListingCheckbox(String runTimeLabel) {
		String value = listingScreen_CheckBoxs;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:get substance name by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:DushyanthMahesh Date :16-September-2019 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderList(String num) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:get substance name by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:DushyanthMahesh Date :16-September-2019 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderVerification(String num) {
		String value = colHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}

}