package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class CaseComparisonPageObjects {

	public static String caseDataAttributesList = "xpath#//tr[contains(@id,'ADL:safetyDataTable_node')][@aria-expanded='true']/td[contains(@class,'col-leftNew')]/div/label[@class='ui-outputlabel ui-widget']";
	public static String caseDataAttributes = "xpath#(//tr[contains(@id,'ADL:safetyDataTable_node')][@aria-expanded='true']/td[contains(@class,'col-leftNew')]/div/label[@class='ui-outputlabel ui-widget'])[{0}]";
	public static String caseColumn = "xpath#(//tr[contains(@id,'ADL:safetyDataTable_node')][@aria-expanded='true']/td/label[contains(@id,'valCol{0}')])[{%count}]";
	public static String columnHeaderList = "xpath#//thead[@id='ADL:safetyDataTable_head']/tr/th[not(contains(@style, 'display: none;'))]/span";
	public static String columnHeader = "xpath#(//thead[@id='ADL:safetyDataTable_head']/tr/th[not(contains(@style, 'display: none;'))]/span)[{%count}]";
	public static String get_ComparisonreportCheckBx = "xpath#//div[@class='compareChkBoxes']/label[contains(text(),'Comparison report')]/following::table/tbody/tr/td/div/child::div[2]";
	public static String downloadIcon = "xpath#//a[@id='ADL:caseComparisionActionId']/img";
	public static String exportToexcelLink = "xpath#//button[@id='ADL:caseComparisionexcelID']";
	public static String exportToexcelPopup = "xpath#//span[@id='ADL:dailogToExportShowHide_title']";
	public static String exportToexcelBtn = "xpath#//button[@id='ADL:caseComparisionhiddenExportIdIn']";
	public static String exportToexcel_closeicon = "xpath#//div[@id='ADL:dailogToExportShowHide']//a[@class='ui-dialog-titlebar-icon ui-dialog-titlebar-close ui-corner-all']";
	public static String highlightdiffCheckBx = "xpath#//td/label[text()='Highlight differences']/ancestor::td/input";
	public static String close_icon = "xpath#//div[@id='ADL:safetyComparisonDialog']/div/span/following-sibling::a";
	
	
	/**********************************************************************************************************
	 * Objective:get case data by column Input Parameters: Column number ColumnName
	 * Scenario Name Output Parameters:
	 * 
	 * @author:DushyanthMahesh Date :12-September-2019 Updated by and when
	 **********************************************************************************************************/
	public static String caseColumn(String columnNum, String rowNum) {
		String value = caseColumn;
		String value2;
		value2 = value.replace("{0}", columnNum);
		value2 = value2.replace("{%count}", rowNum);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:get case data attributes
	 * @Parameters:rowNum
	 * @author:DushyanthMahesh Date :12-September-2019 Updated by and when
	 **********************************************************************************************************/
	public static String caseDataAttributes(String rowNum) {
		String value = caseDataAttributes;
		String value2;
		value2 = value.replace("{0}", rowNum);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:get column name of case comparison Input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:DushyanthMahesh Date :16-September-2019 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderList(String num) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}
}
