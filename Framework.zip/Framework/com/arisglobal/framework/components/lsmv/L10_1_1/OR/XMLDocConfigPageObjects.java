package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class XMLDocConfigPageObjects {

	// ~~~~~~~~~~~~~~~~~~~~~ XML Doc Configurations Listing ~~~~~~~~~~~~~~~~~~~

	public static String e2bSettings_SaveBtn = "xpath#//button[@id='e2bSettingsListform:saveE2bId']";
	public static String e2bSettings_NewBtn = "xpath#//a[@id='e2bSettingsListform:newId']";
	public static String e2bSettings_DeleteBtn = "xpath#//a[@id='e2bSettingsListform:deleteId']";
	public static String e2bSettings_Paginator = "xpath#//div[@id='e2bSettingsListform:settingsDataTable_paginator_top']";
	public static String e2bSettingEdit_Icon = "xpath#//tbody[@id='e2bSettingsListform:settingsDataTable_data']/tr/td[3]/span[text()='%configName%']/preceding::td[1]/a";

	// ~~~~~~~~~~~~~~~~~~~~~ XML Doc Configurations New/Edit ~~~~~~~~~~~~~~~~~~~

	public static String xmlDocConfigName_TextBox = "xpath#//input[@id='e2bSettingDetailsform:j_id_me']";
	public static String postProcessingScriptImport_Dropdown = "xpath#//label[@id='e2bSettingDetailsform:importScript_label']";
	public static String preProcessingScriptExport_Dropdown = "xpath#//label[@id='e2bSettingDetailsform:exportScript_label']";
	public static String DTDName_Dropdown = "xpath#//label[@id='e2bSettingDetailsform:DTDTypeSelectMenu_label']";
	public static String DTDSchema_Dropdown = "xpath#//label[@id='e2bSettingDetailsform:DTDTypeList-9144_label']";
	public static String DTDType_Dropdown = "xpath#//label[@id='e2bSettingDetailsform:DTDTypeValueList-9145_label']";
	public static String save_Btn = "xpath#//button[@id='e2bSettingDetailsform:visibleSave']";
	public static String cancel_Btn = "xpath#//button[@id='e2bSettingDetailsform:cancelId']";
	public static String dropDownListItem = "xpath#//li[text()='{0}'][contains(@id,'{1}')]";

	// ~~~~~~~~~~~~~ XML Doc Configurations >> Tab navigation operations ~~~~~~~~~~

	public static String add_Link = "xpath#//a[text()='Add']";
	public static String delete_Link = "xpath#//a[text()='Delete']";
	public static String tabNavigation = "xpath#//a/span[text()='%s']";

	// ~~~~~~~~~~~~~~~~~~~ Import Path Configuration ~~~~~~~~~~~~~~~~~~~~~~~

	public static String schema_TextBox = "xpath#//input[@id='e2bSettingDetailsform:icsr_messagenumb_schema_ae']";
	public static String sequenceLength_TextBox = "xpath#//input[@id='e2bSettingDetailsform:icsr_messagenumb_schema_seq_ae']";
	public static String textBox = "xpath#(//label[starts-with(normalize-space(text()),'%text%')]/following::input)[1]";
	public static String XMLimportPath_Label = "XML Import Path";
	public static String XMLAckExportPath_Label = "XML ACK Export Path";
	public static String docImportPath_Label = "Document Import Path";
	public static String docImportBackPath_Label = "Document Import BackUp Path";
	public static String docAckExportPath_Label = "Document Ack Export Path";

	// ~~~~~~~~~~~~~~~~~~~ DTD XPaths ~~~~~~~~~~~~~~~~~~~~~~~

	public static String xpath_Label = "Xpath";
	public static String xpathValue_Label = "Xpath Value";
	public static String xpathValueType_Dropdown = "xpath#//label[@id='e2bSettingDetailsform:xpathValueTypeId_label']";
	public static String DTDxpath_SaveBtn = "xpath#//div[@class='HeaderBox thinHeaderBox templateDetail']/button/span[text()='Save']";
	public static String DTDxpath_CancelBtn = "xpath#//div[@class='HeaderBox thinHeaderBox templateDetail']/button/span[text()='Cancel']";
	public static String DTDxpath_EditBtn = "xpath#//tbody[@id='e2bSettingDetailsform:xpathDetailsId_data']/tr/td[3]/label[text()='%Xpath%']/preceding::td[1]/a";

	// ~~~~~~~~~~~~~~~~~~~ Export Configurations for Receviers~~~~~~~~~~~~~~~~

	public static String medraPopulationICSRXML_Dropdown = "xpath#//label[@id='e2bSettingDetailsform:icsrMeddraPopulationForExport_label']";
	public static String enableDocReport_Label = "Enable Document Export";
	public static String xmlACKImportEnabled_Label = "XML ACK Import Enabled";
	public static String docACKImportEnabled_Label = "Document ACK Import Enabled";
	public static String selectRadioButton = "xpath#//label[text()='%radioButtonLabel%']/parent::*/descendant::label[text()='%radioButtonValue%']/preceding-sibling::div/descendant::span[contains(@class,'ui-radiobutton-icon')]";
	public static String receiver_LookUp = "xpath#//img[contains(@id,'e2bSettingDetailsform:e2bAccountLookupReceiverId')]";
	public static String displayR3TagsinXMl_Label = "Display R3 Tags In XML";

	// Receiver Settings
	public static String receiverEdit_Btn = "xpath#//tbody[@id='e2bSettingDetailsform:xmlexportSettingsId_data']/tr/td[3]/label[text()='%Receiver%']/preceding::td[1]/a";

	// Search By Account for Sender/Receiver and Default Sender
	public static String acct_TextBox = "xpath#//input[@id='accountLookup:accountName']";
	public static String domain_TextBox = "xpath#//input[@id='accountLookup:accountDomain']";
	public static String firm_SiteFEINum = "xpath#//input[@id='accountLookup:feiNumber']";
	public static String acctGroup_Textbox = "xpath#//input[@id='accountLookup:accGroupName']";
	public static String accountGroup_Label = "Account Group";
	public static String searchAcct_Btn = "xpath#//button[contains(@id,'accountLookup')]/span[text()='Search ']";
	public static String clearAcct_Btn = "xpath#//button[contains(@id,'accountLookup')]/span[text()='Clear ']";

	// Search By Company Unit for Sender/Receiver and Default Sender
	public static String unitCode_TextBox = "xpath#//input[@id='accountLookup:compUnitCode']";
	public static String unitName_TextBox = "xpath#//input[@id='accountLookup:compUnit']";
	public static String type_Dropdown = "xpath#//label[@id='accountLookup:CompanyUnitLookup-9_label']";
	public static String country_Dropdown = "xpath#//label[@id='accountLookup:CompanyLookup-1_label']";
	public static String CompUnit_OkBtn = "xpath#//button[contains(@id,'accountLookup')]/span[text()='Ok']";
	public static String searchCompUnit_Btn = "xpath#//button[contains(@id,'accountLookup')]/span[text()='Search']";
	public static String clearCompUnit_Btn = "xpath#//button[contains(@id,'accountLookup')]/span[text()='Clear']";

	public static String checkBoxUnder = "xpath#//label[starts-with(normalize-space(text()),'{0}')]/../descendant::div[contains(@class,'ui-chkbox-box')]";
	public static String checkBox_select = "xpath#//tbody[contains(@id,'accountLookup')]/tr/td[1]//div/span";
	public static String CancelBtn = "xpath#//button[contains(@id,'accountLookup')]/span[text()='Cancel']";

	// Export/Import Validation Rules
	public static String ruleName_TextBox = "xpath#//input[contains(@id,'ruleBuilderLookupSearchForm:j_id_1vy')]";
	public static String ruleType_Dropdown = "xpath#//label[@id='ruleBuilderLookupSearchForm:ruleTypeList_label']";
	public static String searchRule_Btn = "xpath#//button[@id='ruleBuilderLookupSearchForm:findRules']";
	public static String selectRule_CheckBox = "xpath#//tbody[@id='ruleBuilderLookupSearchForm:rbTable:rbLookUpDataTableMulti_data']/tr/td[1]//div/span";
	public static String rule_OKBtn = "xpath#//button[contains(@id,'okButtonbottom')]";
	public static String rule_CancelBtn = "xpath#//button[contains(@id,'cancelButtonbottom')]";

	// Export/Import Submit/Cancel Buttons
	public static String submit_Btn = "xpath#//div[contains(@class,'HeaderBox')]/button[contains(@id,'e2bSettingDetailsform')]/span[text()='Submit']";
	public static String Cancel_Btn = "xpath#//div[contains(@class,'HeaderBox')]/button[contains(@id,'e2bSettingDetailsform')]/span[text()='Cancel']";

	// ~~~~~~~~~~~~~~~~~~~ Import configurations for Senders~~~~~~~~~~~~~~~~

	public static String MDNRequired_Label = "MDN Required";
	public static String ackRequired_Label = "Acknowledgement Required";
	public static String GenACkAERGeneration_Label = "Generate ACk after AER generation";
	public static String rejectCasesAssesed_Label = "Reject Cases Assessed as SD";
	public static String impSourceDocument_Label = "Import Source Document";
	public static String rejectCasesHardVal_Label = "Reject Cases for hard validations";
	public static String easyView_Label = "Easy View";
	public static String summarySheet_Label = "Summary Sheet";
	public static String radioBtn = "xpath#//label[starts-with(normalize-space(text()),'{0}')]/../descendant::div[contains(@class,'ui-radiobutton-box')]";
	public static String sourceDoc_Dropdown = "xpath#//label[@id='e2bSettingDetailsform:sourceDocument_label']";
	public static String importForm_Dropdown = "xpath#//label[@id='e2bSettingDetailsform:activeFormName_label']";
	public static String defaultSourceMedium_Dropdown = "xpath#//label[@id='e2bSettingDetailsform:A1-501_label']";
	public static String sender_LookUp = "xpath#//img[contains(@id,'e2bSettingDetailsform:e2bAccountLookupSenderId')]";

	// Sender Settings
	public static String senderEdit_Btn = "xpath#//tbody[@id='e2bSettingDetailsform:xmlimportSettingsId_data']/tr/td[3]/label[text()='%Sender%']/preceding::td[1]/a";

	// Default Receiver
	public static String defaultRecv_Lookup = "xpath#//img[contains(@id,'e2bSettingDetailsform:e2bDefaultCompanyUnitLookup')]";
	public static String defReceiverUnitCode_TextBox = "xpath#//input[contains(@id,'companyUnitlookupSearchForm:j_id_1tz')]";
	public static String defReceiverUnitName_TextBox = "xpath#//input[contains(@id,'companyUnitlookupSearchForm:j_id_1u2')]";
	public static String defReceiverCountry_Dropdown = "xpath#//label[contains(@id,'companyUnitlookupSearchForm:CompanyLookup-1015_label')]";
	public static String defReceiver_SearchBtn = "xpath#//button[contains(@id,'companySearchId')]/span[text()='Search ']";
	public static String defReceiver_ClearBtn = "xpath#//button[contains(@id,'companyClearId')]/span[text()='Clear']";
	public static String defReceiver_checkBox = "xpath#//tbody[contains(@id,'companyUnitTable')]/tr/td[1]//div/span";
	public static String defReceiver_CancelBtn = "xpath#//button[contains(@id,'bottom')]/span[text()='Cancel']";
	public static String defReceiver_OKBtn = "xpath#//button[contains(@id,'bottom')]/span[text()='OK']";

	// Default Sender
	public static String defaultSen_Lookup = "xpath#//img[contains(@id,'e2bSettingDetailsform:e2bAccountLookup:j_id_xh')]";

	// XML Doc Config

	public static String links = "xpath#//span[@class='ui-menuitem-text'][contains(text(),'%s')]";
	public static String xmlDocTable = "xpath#//table/tbody[@id='e2bSettingsListform:settingsDataTable_data']//tr";
	public static String editConfig = "xpath#//table/tbody[@id='e2bSettingsListform:settingsDataTable_data']//tr[%s]/td//img[contains(@id,'editImgId')]";
	public static String ConfigName = "xpath#//table/tbody[@id='e2bSettingsListform:settingsDataTable_data']//tr[%s]//td//span[contains(@id,'dtdSchemaName')]";
	public static String DTDSchema = "xpath#(//table/tbody[@id='e2bSettingsListform:settingsDataTable_data']//tr[%s]//td//span[contains(@id,'dtdSchema')])[2]";
	public static String DTDType = "xpath#//table/tbody[@id='e2bSettingsListform:settingsDataTable_data']//tr[%s]//td//span[contains(@id,'dtdType')]";
	public static String RootTagName = "xpath#//table/tbody[@id='e2bSettingsListform:settingsDataTable_data']//tr[%s]//td//span[contains(@id,'rootTagName')]";
	public static String NewBtn = "xpath#//a[text()='New']";
	public static String XMLDocConfigCancel = "xpath#//span[contains(text(),'Cancel')]";
	public static String Administartion = "Administration";
	public static String XMLDocConfiguration = "Xml doc configuration";
	public static String XMLDocConfigurationNameLabel = "Xml Doc Configuration Name";
	public static String RootTagNameLabel = "Root Tag Name";
	public static String ImportConfigurationForSenders = "Import configurations for Senders";
	public static String ExportConfigurationForReceivers = "Export configurations for Receivers";
	public static String ImportPathConfigurations = "Import Path Configuration";
	public static String DTDXpaths = "DTD Xpaths";

	public static String DTDNameDropDown = "xpath#//select[@id='e2bSettingDetailsform:DTDTypeSelectMenu_input']";
	public static String DTDSchemaDropDown = "xpath#//select[@id='e2bSettingDetailsform:DTDTypeList-9144_input']";
	public static String DTDTypeDropDown = "xpath#//select[@id='e2bSettingDetailsform:DTDTypeValueList-9145_input']";
	public static String PostProcessingScriptForImportDropDown = "xpath#//select[@id='e2bSettingDetailsform:importScript_input']";
	public static String PostProcessingScriptForExportDropDown = "xpath#//select[@id='e2bSettingDetailsform:exportScript_input']";

	// Import Config For Senders

	public static String ImportConfigForSendersTable = "xpath#//table//tbody[@id='e2bSettingDetailsform:xmlimportSettingsId_data']//tr";
	public static String SenderSettingsLabel = "xpath#//label[contains(text(),'Sender Settings')]";
	public static String ICFSConfigEdit = "xpath#//table//tbody[@id='e2bSettingDetailsform:xmlimportSettingsId_data']//tr[%s]//td//a//img[contains(@id,'edit')]";
	public static String ICFSSender = "xpath#//table//tbody[@id='e2bSettingDetailsform:xmlimportSettingsId_data']//tr[%s]//td//label[contains(@id,'j_id_17p')]";
	public static String ICFSDefaultSender = "xpath#//table//tbody[@id='e2bSettingDetailsform:xmlimportSettingsId_data']//tr[%s]//td//label[contains(@id,'j_id_17r')]";
	public static String ICFSDefaultReceiver = "xpath#//table//tbody[@id='e2bSettingDetailsform:xmlimportSettingsId_data']//tr[%s]//td//label[contains(@id,'j_id_17t')]";
	public static String ICFSDefaultSourceMedium = "xpath#//table//tbody[@id='e2bSettingDetailsform:xmlimportSettingsId_data']//tr[%s]//td//label[contains(@id,'j_id_17v')]";
	public static String ICFSSourceDocument = "xpath#//table//tbody[@id='e2bSettingDetailsform:xmlimportSettingsId_data']//tr[%s]//td//label[contains(@id,'j_id_17x')] | //table//tbody[@id='e2bSettingDetailsform:xmlimportSettingsId_data']//tr[%s]//td//label[contains(@id,'j_id_17y')]";
	public static String ICFSSenderTextBox = "xpath#//input[@id='e2bSettingDetailsform:e2bSenderId']";
	public static String ICFSDefaultReceiverTextBox = "xpath#//input[@id='e2bSettingDetailsform:e2bReceiver']";
	public static String ICFSDefaultSenderTextBox = "xpath#//input[@id='e2bSettingDetailsform:e2bSender']";
	public static String ICFSDefaultDefaultSourceMediumTextBox = "Default Source Medium";
	public static String ICFSSourceDocumentTextBox = "Source Document";
	public static String ICFSImportFormTextBox = "Import Form";
	public static String ICFSAcknowledgementRequiredCheckBox = "Acknowledgement Required";
	public static String ICFSPlaceAckXMLinFolderCheckBox = "Place Ack XML in Folder";
	public static String ICFSRejectCasesAssessedasSDCheckBox = "Reject Cases Assessed as SD";
	public static String ICFSMDNRequiredCheckBox = "MDN Required";
	public static String ICFSGenerateACkafterAERgenerationCheckBox = "Generate ACk after AER generation";
	public static String ICFSSDManualRejectCheckBox = "SD/Manual Reject";
	public static String ICFSRejectCasesforhardvalidationsCheckBox = "Reject Cases for hard validations";
	public static String ICFSImportSourceDocumentCheckBox = "Import Source Document";
	public static String ICFSEasyViewRadioButton = "Easy View";
	public static String ICFSSummarySheetRadioButton = "Summary Sheet";
	public static String ICFSDefaultConfigCheckBox = "Default Configuration";
	public static String ICFSDropDownText = "xpath#//label[starts-with(normalize-space(text()),'%s')]/following::input[1]//ancestor::div[1]//following::label[1]";
	public static String ICFSCancel = "xpath#//button[@id='e2bSettingDetailsform:j_id_17f']";
	public static String ICFSSubmit = "xpath#//button[@id='e2bSettingDetailsform:j_id_17e']";
	public static String ICFSNoRecordsFound = "xpath#//tbody[@id='e2bSettingDetailsform:xmlimportSettingsId_data']//tr//td[contains(text(),'No records found.')]";
	public static String ICFSAddButon = "xpath#//a[@id='e2bSettingDetailsform:addImportId']";
	public static String ICFSSenderLookUp = "xpath#//img[@id='e2bSettingDetailsform:e2bAccountLookupSenderId:j_id_p1']";
	public static String ICFSAccountName = "Account Name";
	public static String ICFSReceiverSearch = "xpath#//button[@id='accountLookup:findButton']";
	public static String ICFSReceiverRadioButton = "xpath#//table//tbody[@id='accountLookup:accountTable:accountDataTable_data']//tr//td[1]//div[2]";
	public static String ICFSReceiverSearchOK = "xpath#//button[@id='accountLookup:okButton1']";
	public static String ICFSDefaultReceiverLookUp = "xpath#//img[@id='e2bSettingDetailsform:e2bDefaultCompanyUnitLookup:j_id_ta']";
	public static String ICFSDefaultReceiverUnitCodeLabel = "Unit Code";
	public static String ICFSDefaultReceiverSearchButton = "xpath#//button[@id='companyUnitlookupSearchForm:companySearchId']";
	public static String ICFSDefaultReceiverRadioButton = "xpath#//table//tbody[@id='companyUnitlookupSearchForm:companyUnitTable:companyUnitLookUpDataTable_data']//tr[1]//td[1]//div[2]";
	public static String ICFSDefaultReceiverOkButton = "xpath#mandatoryDialogform:okButton";
	public static String ICFSDefaultSenderLookUp = "xpath#//img[@id='e2bSettingDetailsform:e2bAccountLookup:j_id_xn']";
	public static String ICFSDefaultSenderAccountName = "Account Name";
	public static String ICFSDefaultSenderrSearch = "xpath#//button[@id='accountLookup:findButton']";
	public static String ICFSDefaultSenderRadioButton = "xpath#//table//tbody[@id='accountLookup:accountTable:accountDataTable_data']//tr//td[1]//div[2]";
	public static String ICFSDefaultSenderOkButton = "xpath#//button[@id='accountLookup:okButton1']";
	public static String ICFSDefaultSourceMediumDD = "xpath#//select[@id='e2bSettingDetailsform:A1-501_input']";
	public static String ICFSSorceDocDD = "xpath#//select[@id='e2bSettingDetailsform:sourceDocument_input']";
	public static String ICFSImportFOrmDD = "xpath#//select[@id='e2bSettingDetailsform:activeFormName_input']";
	public static String ICFSSubmitButton = "xpath#//button[@id='e2bSettingDetailsform:j_id_17e']";
	// Export Config for Receivers
	public static String ReceiverSettingsLabel = "xpath#//label[contains(text(),'Receiver Settings')]";
	public static String ECFRTable = "xpath#//table//tbody[@id='e2bSettingDetailsform:xmlexportSettingsId_data']//tr";
	public static String ECFRConfigEdit = "xpath#//table//tbody[@id='e2bSettingDetailsform:xmlexportSettingsId_data']//tr[%s]//td//a//img[contains(@id,'edit')]";
	public static String receiver = "xpath#//table//tbody[@id='e2bSettingDetailsform:xmlexportSettingsId_data']//tr[%s]//td//label[contains(@id,'j_id_1i0')]";
	public static String enableDocExport = "xpath#//table//tbody[@id='e2bSettingDetailsform:xmlexportSettingsId_data']//tr[%s]//td//label[contains(@id,'j_id_1i4')]";
	public static String xmlImportACKEnabled = "xpath#//table//tbody[@id='e2bSettingDetailsform:xmlexportSettingsId_data']//tr[%s]//td//label[contains(@id,'j_id_1i7')]";
	public static String docImportACKEnabled = "xpath#//table//tbody[@id='e2bSettingDetailsform:xmlexportSettingsId_data']//tr[%s]//td//label[contains(@id,'j_id_1ia')]";
	public static String ECFRReceiver = "xpath#//input[@id='e2bSettingDetailsform:e2bReceiverId']";
	public static String ECFRMeddra = "xpath#//label[@id='e2bSettingDetailsform:icsrMeddraPopulationForExport_label']";
	public static String ECFREnableDocumentExportLabel = "Enable Document Export";
	public static String ECFRXMLACKImpotEnabledLabel = "XML ACK Import Enabled";
	public static String ECFRDocumentACKImportEnabledLabel = "Document ACK Import Enabled";
	public static String ECFRDisplayR3TagsInXMLLabel = "Display R3 Tags In XML";
	public static String ECFRRadioButton = "xpath#//label[text()='%radioButtonLabel%']/parent::*/descendant::label[text()='%radioButtonValue%']/preceding-sibling::div//div[2]";
	public static String ECFRCancelButton = "xpath#//button[@id='e2bSettingDetailsform:j_id_1hq']";
	public static String ECFRNoRecordsFound = "xpath#//tbody[@id='e2bSettingDetailsform:xmlexportSettingsId_data']//tr//td[contains(text(),'No records found.')]";
	public static String ECFRAddButton = "xpath#//a[@id='e2bSettingDetailsform:addExportId']";
	public static String ECFRReceiverLookUp = "xpath#//img[@id='e2bSettingDetailsform:e2bAccountLookupReceiverId:j_id_195']";
	public static String ECFRReceiverAccountName = "Account Name";
	public static String ECFRReceiverSearch = "xpath#//button[@id='accountLookup:findButton']";
	public static String ECFRReceiverRadioButton = "xpath#//table//tbody[@id='accountLookup:accountTable:accountDataTable_data']//tr//td[1]//div[2]";
	public static String ECFRReceiverSearchOk = "xpath#//button[@id='accountLookup:okButton1']";
	public static String ECFRMeddraDD = "xpath#//select[@id='e2bSettingDetailsform:icsrMeddraPopulationForExport_input']";
	public static String ECFRSubmitButton = "xpath#//button[@id='e2bSettingDetailsform:j_id_1hp']";
	// DTD Xpaths

	public static String DTDXPathsLabel = "xpath#//label[contains(text(),'DTD Xpaths')]";
	public static String DTDXpathTable = "xpath#//table//tbody[@id='e2bSettingDetailsform:xpathDetailsId_data']//tr";
	public static String DTDXpathEdit = "xpath#//table//tbody[@id='e2bSettingDetailsform:xpathDetailsId_data']//tr[%s]//td//a//img[contains(@id,'edit')]";
	public static String XPATH = "xpath#//table//tbody[@id='e2bSettingDetailsform:xpathDetailsId_data']//tr[%s]//td//label[contains(@id,'j_id_1ko')]";
	public static String XPATHValue = "xpath#//table//tbody[@id='e2bSettingDetailsform:xpathDetailsId_data']//tr[%s]//td//label[contains(@id,'j_id_1kq')]";
	public static String XPATHValueType = "xpath#//table//tbody[@id='e2bSettingDetailsform:xpathDetailsId_data']//tr[%s]//td//label[contains(@id,'j_id_1ks')]";
	public static String DTDXPATHNorecordsFound = "xpath#//tbody[@id='e2bSettingDetailsform:xpathDetailsId_data']//tr//td[contains(text(),'No records found.')]";
	public static String DTDXpathAddButton = "xpath#//a[@id= 'e2bSettingDetailsform:addDtdXpathId']";
	public static String DTDXpathValueTypeDD = "xpath#//select[@id='e2bSettingDetailsform:xpathValueTypeId_input']";
	public static String DTDXpathSave = "xpath#//button[@id='e2bSettingDetailsform:j_id_1kd']";
	/**********************************************************************************************************
	 * @Objective: The below method is created to edit the e2b name
	 * @InputParameters: count
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 18-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String resultLocator = null;

	public static String clickEdit(String text) {
		String value = e2bSettingEdit_Icon;
		String value1 = value.replace("%configName%", text);
		return value1;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to generate xpath based on locator
	 *             and value to select from dropdown.
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Pooja S
	 * @Date : 18-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectListDropDown(String locator, String valueToSelect) {
		String xpath[] = locator.split("'");
		String resLocator = xpath[1].replace("_label", "");
		String actualLocator = dropDownListItem;
		String tempLocator = actualLocator.replace("{0}", valueToSelect);
		String resultLocator = tempLocator.replace("{1}", resLocator);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created perform tab navigation by passing tab
	 * name at run time. Input Parameters: Scenario Name Output Parameters:
	 * 
	 * @author:Pooja S Date : 18-Sep-2020 Updated by and when:
	 **********************************************************************************************************/

	public static String FDE_tabNavigation(String runTimeLabel) {
		String value = tabNavigation;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to set the text box fields name at run
	 * time. Input Parameters: Scenario Name Output Parameters:
	 * 
	 * @author:Pooja S Date : 18-Sep-2020 Updated by and when:
	 **********************************************************************************************************/

	public static String setTextBox(String text) {
		String value = textBox;
		String value2;
		value2 = value.replace("%text%", text);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the Radio button passing
	 *             value at runtime.
	 * @InputParameters: radioButtonLabel, radioButtonValue
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Pooja S
	 * @Date : 18-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectRadioButton(String radioButtonLabel, String radioButtonValue) {
		String resultLocator, result1 = null;
		result1 = selectRadioButton.replace("%radioButtonLabel%", radioButtonLabel);
		resultLocator = result1.replace("%radioButtonValue%", radioButtonValue);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Pooja S
	 * @Date : 23-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String checkBoxUnder(String checkBoxLabel) {
		String actualLocator = checkBoxUnder;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the radio button under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Pooja S
	 * @Date : 23-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String radioButton(String radioBtnLabel) {
		String actualLocator = radioBtn;
		resultLocator = actualLocator.replace("{0}", radioBtnLabel.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the Admin and XML Doc
	 *             Config links
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String Links(String runtimeLabel) {
		String actualLocator = links;
		resultLocator = actualLocator.replace("%s", runtimeLabel.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to get the xml Doc Config table cell
	 *             values
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String XMLDocConfigTableCell(String Cell, int rowIndex) {
		String actualLocator = Cell;
		resultLocator = actualLocator.replace("%s", rowIndex + "".trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to get the text of ICFS dropdown
	 *             labe;
	 * @InputParameters: Dropdown Label
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String ICFSDropDownText(String label) {
		String actualLocator = ICFSDropDownText;
		resultLocator = actualLocator.replace("%s", label + "".trim());
		return resultLocator;
	}

	public static String ECFRRadioButton(String radioButtonLabel, String radioButtonValue) {
		String resultLocator, result1 = null;
		result1 = ECFRRadioButton.replace("%radioButtonLabel%", radioButtonLabel);
		resultLocator = result1.replace("%radioButtonValue%", radioButtonValue);
		return resultLocator;
	}

}