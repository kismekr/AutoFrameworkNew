package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.openqa.selenium.WebElement;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class XMLOperations extends Multimaplibraries {
	public static WebElement webElement;
	static String className = XMLOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();

	/**********************************************************************************************************
	 * @Objective: The Below Method is created to read the data from R2 XML
	 * @InputParameters: Scenario Name, Xpath
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void readData_R2XML(String scenarioName, String data) {

		String fieldXpath = null;
		switch (data) {
		case "firstName":
			fieldXpath = "XML_firstName";
			break;
		case "lastName":
			fieldXpath = "XML_lastName";
			break;
		case "patientinitial":
			fieldXpath = "XML_patientinitial";
			break;
		case "Productname":
			fieldXpath = "XML_productName";
			break;
		case "MessageNo":
			fieldXpath = "XML_MessageNo";
			break;
		default:
			System.out.println("Invalid Field");
		}
		if (fieldXpath != null) {
			// XlsReader excel = new XlsReader(lsmvConstants.LSMV_testData);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "xmlOperations");
			String xml_data;
			xml_data = XMLReader.getR2TagValue(
					lsmvConstants.lsmvXmlPath + getTestDataCellValue(scenarioName, "R2xmlName"),
					getTestDataCellValue(scenarioName, fieldXpath));
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "xmlOperations", scenarioName, data, xml_data);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The Below Method is created to update the message number in R2
	 *             xml
	 * @InputParameters: File Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void updateMessageNumber(String fileName) {

		try {

			String filepath = (lsmvConstants.lsmvE2EScenarioPath + "R2XML_Input\\" + fileName);
			System.out.println("Input file : " + filepath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			// Node ichicsr = doc.getFirstChild();
			Node messagenumber = doc.getElementsByTagName("ichicsrmessageheader").item(0);
			NodeList list = messagenumber.getChildNodes();

			for (int i = 0; i < list.getLength(); i++) {
				Node node = list.item(i);
				if ("messagenumb".equals(node.getNodeName())) {
					node.setTextContent("AUT-" + System.currentTimeMillis());
				}

			}
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filepath));
			transformer.transform(source, result);

			System.out.println("Done");

			Reports.ExtentReportLog("Message number is updated successfull", Status.PASS, "", false);

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (SAXException sae) {
			sae.printStackTrace();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The Below Method is created to update the MessageNumber and
	 *             SafetyReportid in R2 xml
	 * @InputParameters: File Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateTagValueR2Xml(String fileName, String tagName, String element, String value) {

		try {
			String filepath = (lsmvConstants.lsmvXmlPath + "\\" + fileName);
			System.out.println("Input file : " + filepath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			Node company = doc.getFirstChild();
			Node messagenumber = doc.getElementsByTagName(tagName).item(0);
			NodeList list = messagenumber.getChildNodes();

			for (int i = 0; i < list.getLength(); i++) {

				Node node = list.item(i);

				if (element.equals(node.getNodeName())) {
					node.setTextContent(value);
				}

			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filepath));
			transformer.transform(source, result);

			System.out.println("Done");

			Reports.ExtentReportLog("Data updated successfull", Status.PASS, "", true);

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (SAXException sae) {
			sae.printStackTrace();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The Below Method is created to update the MessageNumber in R3 xml
	 * @InputParameters: File Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateMessageNumberR3xml(String fileName) {
		try {
			String filepath = (lsmvConstants.lsmvE2EScenarioPath + "R3XML_Input\\" + fileName);
			System.out.println("Input file : " + filepath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			Node company = doc.getFirstChild();
			Node messagenumber = doc.getElementsByTagName("id").item(0);

			NamedNodeMap attr = messagenumber.getAttributes();
			Node nodeAttr = attr.getNamedItem("extension");
			nodeAttr.setTextContent("AUT-" + System.currentTimeMillis());

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filepath));
			transformer.transform(source, result);

			System.out.println("Done");

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (SAXException sae) {
			sae.printStackTrace();
		}

	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	// /**********************************************************************************************************
	// * @Objective: The Below Method is created to update the message number in R3
	// xml
	// * @InputParameters: File Name
	// * @OutputParameters:
	// * @author:Kishore K R
	// * @Date : 09-Mar-2020
	// * @UpdatedByAndWhen:
	// **********************************************************************************************************/
	//
	// public static void updateR3MessageNumber(String fileName) {
	//
	// try {
	//
	// String filepath = (lsmvConstants.lsmvXmlPath + fileName);
	// System.out.println("Input file : " + filepath);
	// DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
	// DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
	// Document doc = docBuilder.parse(filepath);
	// Node messagenumber = doc.getElementsByTagName("MCCI_IN200100UV01").item(0);
	// NodeList list = messagenumber.getChildNodes();
	// for (int i = 0; i < list.getLength(); i++) {
	// Node node = list.item(i);
	// if ("id".equals(node.getNodeName())) {
	// Element id=(Element)list.item(i);
	// id.setAttribute("extension", "AUT-" + System.currentTimeMillis());
	// }
	// }
	// TransformerFactory transformerFactory = TransformerFactory.newInstance();
	// Transformer transformer = transformerFactory.newTransformer();
	// DOMSource source = new DOMSource(doc);
	// StreamResult result = new StreamResult(new File(filepath));
	// transformer.transform(source, result);
	//
	// System.out.println("Done");
	//
	// Reports.ExtentReportLog("Message number is updated successfull", Status.PASS,
	// "", false);
	//
	// } catch (ParserConfigurationException pce) {
	// pce.printStackTrace();
	// } catch (TransformerException tfe) {
	// tfe.printStackTrace();
	// } catch (IOException ioe) {
	// ioe.printStackTrace();
	// } catch (SAXException sae) {
	// sae.printStackTrace();
	// }
	// }

	/**********************************************************************************************************
	 * @Objective: The Below Method is created to read the data from R2 XML
	 * @InputParameters: Scenario Name, Xpath
	 * @OutputParameters:
	 * @author:Kishore K R
	 * @Date : 9-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void readData_R3XML(String scenarioName, String data) {

		String fieldXpath = null;
		switch (data) {
		case "firstName":
			fieldXpath = "XML_firstName";
			break;
		case "lastName":
			fieldXpath = "XML_lastName";
			break;
		case "patientinitial":
			fieldXpath = "XML_patientinitial";
			break;
		case "Productname":
			fieldXpath = "XML_productName";
			break;
		case "MessageNo":
			fieldXpath = "XML_MessageNo";
			break;
		default:
			System.out.println("Invalid Field");
		}
		if (fieldXpath != null) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "xmlOperations");
			String xml_data;
			xml_data = XMLReader.getR2TagValue(
					lsmvConstants.lsmvXmlPath + getTestDataCellValue(scenarioName, "R2xmlName"),
					getTestDataCellValue(scenarioName, fieldXpath));
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "xmlOperations", scenarioName, data, xml_data);

		}
	}

	public static void updateMessageNumberR3EMAxml(String fileName) {
		try {
			String filepath = (lsmvConstants.lsmvXmlPath + "EMA_R3_Input_XML\\" + fileName);
			System.out.println("Input file : " + filepath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			Node company = doc.getFirstChild();
			Node messagenumber = doc.getElementsByTagName("id").item(0);

			NamedNodeMap attr = messagenumber.getAttributes();
			Node nodeAttr = attr.getNamedItem("extension");
			nodeAttr.setTextContent("AUT-" + System.currentTimeMillis());

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filepath));
			transformer.transform(source, result);

			System.out.println("Done");

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (SAXException sae) {
			sae.printStackTrace();
		}

	}

	public static void updateMessageNumberR2EMAxml(String fileName) {

		try {

			String filepath = (lsmvConstants.lsmvXmlPath + "EMA_R2_Input_XML\\" + fileName);
			System.out.println("Input file : " + filepath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			// Node ichicsr = doc.getFirstChild();
			Node messagenumber = doc.getElementsByTagName("ichicsrmessageheader").item(0);
			NodeList list = messagenumber.getChildNodes();
			for (int i = 0; i < list.getLength(); i++) {
				Node node = list.item(i);
				if ("messagenumb".equals(node.getNodeName())) {
					node.setTextContent("AUT-" + System.currentTimeMillis());
				}

			}
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filepath));
			transformer.transform(source, result);

			System.out.println("Done");

			Reports.ExtentReportLog("Message number is updated successfull", Status.PASS, "", false);

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (SAXException sae) {
			sae.printStackTrace();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The Below Method is created to update the MessageNumber in R3 xml
	 * @InputParameters: File Name
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateMessageNumberR3xmlE2E(String fileName) {
		try {
			String filepath = (lsmvConstants.lsmvXmlPath + fileName);
			System.out.println("Input file : " + filepath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			Node company = doc.getFirstChild();
			Node messagenumber = doc.getElementsByTagName("id").item(0);

			NamedNodeMap attr = messagenumber.getAttributes();
			Node nodeAttr = attr.getNamedItem("extension");
			nodeAttr.setTextContent("AUT-" + System.currentTimeMillis());

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filepath));
			transformer.transform(source, result);

			System.out.println("Done");

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (SAXException sae) {
			sae.printStackTrace();
		}

	}

	/**********************************************************************************************************
	 * @Objective: The Below Method is created to Rename xml file
	 * @InputParameters: scenarioName, sheetName, columnName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateFileName(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		Path source = Paths
				.get(lsmvConstants.lsmvXmlPath + "FDA_Input_XML\\" + getTestDataCellValue(scenarioName, "R2Xml"));
		try {

			// rename a file in the same directory
			Path NewFileName = Files.move(source, source.resolveSibling("FDA" + System.currentTimeMillis() + ".xml"));
			String file = NewFileName.getFileName().toString();
			System.out.println("New file Name : " + file);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, columnName, file);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**********************************************************************************************************
	 * @Objective: The Below Method is created to update the MessageNumber,
	 *             SafetyReport ID, in R2 xml
	 * @InputParameters: File Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void updateMessageNumberR2FDAxml(String scenarioName, String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		try {

			String filepath = (lsmvConstants.lsmvXmlPath + "FDA_Input_XML\\"
					+ getTestDataCellValue(scenarioName, "R2Xml"));
			System.out.println("Input file : " + filepath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			// Node ichicsr = doc.getFirstChild();
			Node messagenumber = doc.getElementsByTagName("ichicsrmessageheader").item(0);
			NodeList list = messagenumber.getChildNodes();
			for (int i = 0; i < list.getLength(); i++) {
				Node node = list.item(i);
				if ("messagenumb".equals(node.getNodeName())) {
					node.setTextContent("AUT-" + System.currentTimeMillis());
				}

			}
			Node safetyreport = doc.getElementsByTagName("safetyreport").item(0);
			NodeList list1 = safetyreport.getChildNodes();
			for (int i = 0; i < list1.getLength(); i++) {
				Node node = list1.item(i);
				if ("safetyreportid".equals(node.getNodeName())) {
					node.setTextContent("AUT-" + System.currentTimeMillis());
				}

			}
			Node companynum = doc.getElementsByTagName("safetyreport").item(0);
			NodeList list2 = companynum.getChildNodes();
			for (int i = 0; i < list2.getLength(); i++) {
				Node node = list2.item(i);
				if ("companynumb".equals(node.getNodeName())) {
					node.setTextContent("AUT-" + System.currentTimeMillis());
				}

			}
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filepath));
			transformer.transform(source, result);

			System.out.println("Done");

			Reports.ExtentReportLog("Message number is updated successfull", Status.PASS, "", false);

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (SAXException sae) {
			sae.printStackTrace();
		}
	}
	
	public static void updateMessageNumberR2_XML(String filePath) {

		try {

			System.out.println("Input file : " + filePath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filePath);
			// Node ichicsr = doc.getFirstChild();
			Node messagenumber = doc.getElementsByTagName("ichicsrmessageheader").item(0);
			NodeList list = messagenumber.getChildNodes();
			for (int i = 0; i < list.getLength(); i++) {
				Node node = list.item(i);
				if ("messagenumb".equals(node.getNodeName())) {
					node.setTextContent("AUT-" + System.currentTimeMillis());
				}

			}
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filePath));
			transformer.transform(source, result);

			System.out.println("Done");

			Reports.ExtentReportLog("Message number is updated successfull", Status.INFO, "", false);

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (SAXException sae) {
			sae.printStackTrace();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The Below Method is created to update the MessageNumber in R3 xml
	 * @InputParameters: File Name
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 24-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateMessageNumberR3xml(String location,String fileName) {
		try {
			String filepath = (location + "\\" + fileName);
			System.out.println("Input file : " + filepath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			Node company = doc.getFirstChild();
			Node messagenumber = doc.getElementsByTagName("id").item(0);

			NamedNodeMap attr = messagenumber.getAttributes();
			Node nodeAttr = attr.getNamedItem("extension");
			nodeAttr.setTextContent("AUT-" + System.currentTimeMillis());

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filepath));
			transformer.transform(source, result);

			System.out.println("Done");

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (SAXException sae) {
			sae.printStackTrace();
		}

	}
	
	/**********************************************************************************************************
	 * @Objective: The Below Method is created to update the message number in R2
	 *             xml
	 * @InputParameters: File Name
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date : 16-March-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateMessageNumber(String fileName,String path) {

		try {

			String filepath = (path  + fileName);
			System.out.println("Input file : " + filepath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			// Node ichicsr = doc.getFirstChild();
			Node messagenumber = doc.getElementsByTagName("ichicsrmessageheader").item(0);
			NodeList list = messagenumber.getChildNodes();

			for (int i = 0; i < list.getLength(); i++) {
				Node node = list.item(i);
				if ("messagenumb".equals(node.getNodeName())) {
					node.setTextContent("AUT-" + System.currentTimeMillis());
				}

			}
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filepath));
			transformer.transform(source, result);

			System.out.println("Done");

			Reports.ExtentReportLog("Message number is updated successfull", Status.PASS, "", false);

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (SAXException sae) {
			sae.printStackTrace();
		}
	}
	/**********************************************************************************************************
	 * @Objective: The Below Method is created to update the MessageNumber and
	 *             SafetyReportid in R2 xml
	 * @InputParameters: File Name
	 * @OutputParameters:
	 * @author:Vamsi Krishna RS
	 * @Date : 16-March-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateTagValueR2Xml(String path,String fileName, String tagName, String element, String value) {

		try {
			String filepath = (path + fileName);
			System.out.println("Input file : " + filepath);
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			Node company = doc.getFirstChild();
			Node messagenumber = doc.getElementsByTagName(tagName).item(0);
			NodeList list = messagenumber.getChildNodes();

			for (int i = 0; i < list.getLength(); i++) {

				Node node = list.item(i);

				if (element.equals(node.getNodeName())) {
					node.setTextContent(value);
				}

			}

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filepath));
			transformer.transform(source, result);

			System.out.println("Done");

			Reports.ExtentReportLog("Data updated successfull", Status.PASS, "", true);

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (SAXException sae) {
			sae.printStackTrace();
		}
	}
	/**********************************************************************************************************
	 * @Objective: The Below Method is created to read the data from R2 XML
	 * @InputParameters: Scenario Name, Xpath
	 * @OutputParameters:
	 * @author:Vamsi Krishna RS
	 * @Date : 16-March-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void readData_R2XML(String scenarioName, String data,String path) {

		String fieldXpath = null;
		switch (data) {
		case "firstName":
			fieldXpath = "XML_firstName";
			break;
		case "lastName":
			fieldXpath = "XML_lastName";
			break;
		case "patientinitial":
			fieldXpath = "XML_patientinitial";
			break;
		case "Productname":
			fieldXpath = "XML_productName";
			break;
		case "MessageNo":
			fieldXpath = "XML_MessageNo";
			break;
		default:
			System.out.println("Invalid Field");
		}
		if (fieldXpath != null) {
			// XlsReader excel = new XlsReader(lsmvConstants.LSMV_testData);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "xmlOperations");
			String xml_data;
			xml_data = XMLReader.getR2TagValue(
					path + getTestDataCellValue(scenarioName, "R2xmlName"),
					getTestDataCellValue(scenarioName, fieldXpath));
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "xmlOperations", scenarioName, data, xml_data);

		}
	}
	
}