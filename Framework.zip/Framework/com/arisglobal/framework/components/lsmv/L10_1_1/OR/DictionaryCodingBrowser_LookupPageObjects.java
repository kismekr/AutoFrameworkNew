package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class DictionaryCodingBrowser_LookupPageObjects {

	public static String searchTerm_Textbox = "xpath#//input[@name='term']";
	public static String dictionaryCode_Textbox = "xpath#//input[@name='code']";
	
	public static String searchMode_RadioBtn = "Search Mode:";
	public static String beginsWith_CheckBox = "Begins With";
	public static String endsWith_CheckBox = "Ends With";
	public static String contains_CheckBox = "Contains";
	public static String exactMatch_CheckBox = "Exact Match";
	public static String advancedSearchOptions_RadioBtn = "Advanced Search Options:";
	
	public static String search_Button = "xpath#//span[contains(@class,'ui-button-text ui-clickable')][contains(text(),'Search')]";
	public static String Ok_Button = "xpath#//span[contains(@class,'ui-button-text ui-clickable')][contains(text(),'O')]";
	
	public static String  dictionarySearchResult_Label = "xpath#//td[text() = '%label%']";
	public static String  dictionaryCode_Label = "xpath#//p-table[contains(@class, 'CodingDictionarytbl listofMedraVtaTbl commanDataTableStylesINQ' )]/descendant::td[2]";
	
	public static String sMQ_CMQName_Textbox = "xpath#//div[@id='smqcmq_lookup_dialog:smqcmqSearchPanel_content']//label[text()='SMQ/CMQ Name:']/following-sibling::input[contains(@id,'smqcmq_lookup_dialog:')]";
	
	public static String sMQCMQSearch_Button = "xpath#//button[@id='smqcmq_lookup_dialog:smqcmqSearchId']";
	public static String sMQCMQOk_Button = "xpath#//button[contains(@id,'smqcmq_lookup_dialog')]/span[text()='OK']";
	public static String sMQCMQ_Select = "xpath#//td[text()='%label%']/ancestor::tbody[@id='smqcmq_lookup_dialog:smqCmqDataTable_data']/tr/td/div//span";
	public static String sMQCMQRadio_Button = "xpath#//label[text()='%label%']/ancestor::td/div//span";
	public static String sMQ_Label = "SMQ";
	public static String cMQ_Label = "CMQ";
	
	public static String clickLevelDropdown = "xpath#//p-dropdown[@name='medraDropDown']/div/label";
	public static String setLevelDropdown = "xpath#//ul[contains(@class,'ui-dropdown-items ui-dropdown-list')]/li/span[text()='%label%']";
	
	/**********************************************************************************************************
	 * Objective: The below method is created to select Search Result Data in Dictionary Coding Browser Look Up Screen. 
	 * Input Parameters: Label Name
	 * Parameters:
	 * @author:Sanchit 
	 * Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String selectDictionarySearchResultData(String srchResultLabel) {
		String value = dictionarySearchResult_Label.replace("%label%", srchResultLabel);
		return value;
	}
	
	/**********************************************************************************************************
	 * Objective: The below method is created to select level Result Data in Dictionary Coding Browser Look Up Screen. 
	 * Input Parameters: Label Name
	 * Parameters:
	 * @author:Avinash K
	 * Date :13-Mar-2020 Updated by and when
	 **********************************************************************************************************/
	public static String setLevelDropdown(String srchResultLabel) {
		String value = setLevelDropdown.replace("%label%", srchResultLabel);
		return value;
	}
	/**********************************************************************************************************
	 * Objective: The below method is created to select Search Result Data in Dictionary Coding Browser Look Up Screen. 
	 * Input Parameters: Label Name
	 * Parameters:
	 * @author:Avinash K
	 * Date :12-Mar-2020 Updated by and when
	 **********************************************************************************************************/
	public static String sMQCMQ_Select(String srchResultLabel) {
		String value = sMQCMQ_Select.replace("%label%", srchResultLabel);
		return value;
	}
	
	/**********************************************************************************************************
	 * Objective: The below method is created to select Search Result Data in Dictionary Coding Browser Look Up Screen. 
	 * Input Parameters: Label Name
	 * Parameters:
	 * @author:Avinash K
	 * Date :12-Mar-2020 Updated by and when
	 **********************************************************************************************************/
	public static String sMQCMQRadio_Button(String srchResultLabel) {
		String value = sMQCMQRadio_Button.replace("%label%", srchResultLabel);
		return value;
	}
}
