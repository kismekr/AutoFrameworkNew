package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FDE_LiteraturePageObjects {

	public static String add_button = "xpath#//p-header/label[text()='Literature Information']/following-sibling::span/a[text()='Add']";
	public static String delete_button = "xpath#//a[text()='Delete']";
	public static String articleTitle_Textbox = "xpath#//input[@id='adverseEventNew:literaturePanelTable:literatureInfoTable:literatureInfoTableGen:idN10C3C126001']";
	public static String journalTitle_Textbox = "xpath#//input[@id='adverseEventNew:literaturePanelTable:literatureInfoTable:literatureInfoTableGen:idN10C4A126002']";
	public static String publicationDate_Textbox = "xpath#//input[@id='adverseEventNew:literaturePanelTable:literatureInfoTable:literatureInfoTableGen:idN10C5A126003:impcalinput']";
	public static String issue_Textbox = "xpath#//input[contains(@id,'issue')]";
	public static String pageFrom_Textbox = "xpath#//input[contains(@id,'126005')]";
	public static String pageTo_Textbox = "xpath#//input[contains(@id,'126006')]";
	public static String edition_Textbox = "xpath#//input[contains(@id,'126007')]";
	public static String digitalObjectIdentifier_Textbox = "xpath#//input[contains(@id,'literatureInfoTableGen:doi')]";
	public static String additionalLiteratureInfo_Textbox = "xpath#//input[contains(@id,'literatureInfoTableGen:ali')]";
	public static String literatureReference_Textbox = "xpath#//textarea[contains(@id,'literatureRef')]";
	public static String retainLiteratureReference = "xpath#//label[text()='Retain Literature Reference']/../descendant::div[contains(@class,'ui-chkbox-box')]";
//	public static String litDocNameUpload_Button = "xpath#//span[contains(@class,'ui-fileupload-choose')]/descendant::span[text()='Choose']";
	public static String litDocNameUpload_Button = "xpath#//input[@type='file'][@accept='undefined']";
	public static String literatureRefZoomed_Textbox = "xpath#//textarea[@name='zoomedTextArea']";
	public static String close_Button = "xpath#//span[text()='Close']";
	public static String formView_Btn = "xpath#//p-header/label[text()='Literature Information']/parent::p-header/span/a[text()='Form View']";
	
	 public static String navigaterClick = "xpath#//div[@class='tabCarouselSty']/following::a[@class='tabCarouselNext evAttached']";
	 public static String click_MultipleLitretature = "xpath#//div[@class='tabCarouselSty']/ul/li/a/span[starts-with(text(),'%s')]";
	 	
	//R2 Tags
	 public static String  R2LiteratureReference = "xpath#//label[text()='[A.2.2]']";
	 
	 //R3 Tags
	 public static String R3LiteratureReference = "xpath#//label[text()='[C.4.r.1]']";
	 public static String R3LiteratureDocumentName = "xpath#//label[text()='[C.4.r.2]']";
		
	 	public static String clickMultipleLitretature(String runTimeLabel) {
			String value = click_MultipleLitretature.replace("%s", runTimeLabel);
			return value;
		}
	 	
}
