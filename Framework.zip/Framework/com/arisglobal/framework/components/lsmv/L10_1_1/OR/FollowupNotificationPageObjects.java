package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public abstract class FollowupNotificationPageObjects {

	public static String followupNotified_icon = "xpath#//a/span[@class='followUpUpArrow']/i[contains(@title,'Notified')]";
	public static String followupReceived_icon = "xpath#//a/span[@class='followUpDownArrow']/i[contains(@title,'Followup Received')]";
	public static String followupTitle_header = "xpath#//div[@id='followUpNotification']/child::div//span[@id='florecptNo']";
	public static String followupColoumn_header = "xpath#//p[@id='followUpbody']/table[@class='follwupNotificationTbl']/thead/tr/th[text()='%s']";
	public static String followupDiff_highlight = "xpath#//span[contains(@id,'ADL:caseNotificationTable:0:seriousnessDataFollowUp')]/span[@style='color:red']";
	public static String parentDiff_highlight = "xpath#//span[contains(@id,'ADL:caseNotificationTable:0:seriousnessDataParent')]/span[@style='color:red']";
	public static String outCome_followupcase = "xpath#//td[@class='seriousHeighleted'][text()='Outcome : Recovered/Resolved With Sequelae']";
	public static String outCome_parentcase = "xpath#//span[@style='color:red'][text()='Outcome : ']";
	public static String followupOutcome_Verification = "xpath#//td[@class='seriousHeighleted'][contains(text(),'%s')]";

	
	public static String followupClose_link = "xpath#//span[@class='close closeCutomDilaog']";
	public static String getfollowupCase_attribute = "xpath#//a[@id='ADL:ADT:0:receiptNoIdView']/ancestor::div[@class='ui-datatable-scrollable-body']/table//div[@class='ui-chkbox ui-widget']/child::div[2]";
	public static String followupRCTColunm_Popup = "xpath#//p[@id='followUpbody']//table//tr/td//label[contains(text(),'%s')]";

	public static String seriousnessFollowUpCase_colmHeader = "SERIOUSNESS AS PER FOLLOW UP CASE";
	public static String receiptDetails_colmHeader = "RECEIPT DETAILS";
	public static String AERNo_colmHeader = "AER NO";
	public static String seriousnessMasterCase_colmHeader = "SERIOUSNESS AS PER CURRENT UNAPPROVED CASE";
	public static String followupReceiptDetails_colmHeader = "Follow up Receipt Details";
	public static String death_label = "xpath#//td[@class='seriousHeighleted'][text()='Death : %s']";
	public static String lifeThreatening_label = "xpath#//td[@class='seriousHeighleted'][text()='Life Threatening : %s']";
	public static String congenitalAnomaly_BirthDefect_label = "xpath#//td[@class='seriousHeighleted'][text()='Congenital Anomaly/Birth Defect : %s']";
	public static String caused_prolongedhospitalization_label = "xpath#//td[@class='seriousHeighleted'][text()='Caused/prolonged hospitalization : %s']";
	public static String disability_PermanentDamage_label = "xpath#//td[@class='seriousHeighleted'][text()='Disability/Permanent Damage : %s']";
	public static String otherMedicallyImportantCondition_label = "xpath#(//td[text()='Other Medically Important Condition : %s'])[1]";
	
	/**********************************************************************************************************
	 * @Objective:The below method is created to verify death value by passing
	 *                value at runtime in case listing screen.
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Feb-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String death_Lable(String ColumnName) {
		String value = death_label;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}
	/**********************************************************************************************************
	 * @Objective:The below method is created to verify lifeThreatening value by passing
	 *                value at runtime in case listing screen.
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Feb-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String lifeThreatening_label(String ColumnName) {
		String value = lifeThreatening_label;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective:The below method is created to verify congenitalAnomaly_BirthDefect value by passing
	 *                value at runtime in case listing screen.
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Feb-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String congenitalAnomaly_BirthDefect_label(String ColumnName) {
		String value = congenitalAnomaly_BirthDefect_label;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective:The below method is created to verify caused prolongedhospitalization value by passing
	 *                value at runtime in case listing screen.
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Feb-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String caused_prolongedhospitalization_label(String ColumnName) {
		String value = caused_prolongedhospitalization_label;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective:The below method is created to verify caused disability_PermanentDamage value by passing
	 *                value at runtime in case listing screen.
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Feb-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String disability_PermanentDamage_label(String ColumnName) {
		String value = disability_PermanentDamage_label;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective:The below method is created to verify caused otherMedicallyImportantCondition value by passing
	 *                value at runtime in case listing screen.
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Feb-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String otherMedicallyImportantCondition_label(String ColumnName) {
		String value = otherMedicallyImportantCondition_label;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}
	
	
	/**********************************************************************************************************
	 * @Objective:The below method is created to click on search link by passing
	 *                search name at runtime in case listing screen.
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Avinash K Date :31-Dec-2019 Updated by and when:
	 **********************************************************************************************************/
	public static String followupWindowoutcomeVerification(String ColumnName) {
		String value = followupOutcome_Verification;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}

	

	/**********************************************************************************************************
	 * @Objective:The below method is created to verify the Recepit no column value
	 *                by passing value name at runtime in case listing screen.
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Avinash K Date :23-Sep-2019 Updated by and when:
	 **********************************************************************************************************/
	public static String followupRCTColunm_verification(String ColumnName) {
		String value = followupRCTColunm_Popup;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}


	/**********************************************************************************************************
	 * @Objective:The below method is created to verify the column header by passing
	 *                header name at runtime in case listing screen.
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Avinash K Date :23-Sep-2019 Updated by and when:
	 **********************************************************************************************************/
	public static String followupColoumn_header(String ColumnName) {
		String value = followupColoumn_header;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}

	

}