package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AdvanceSearchPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.DataAssessmentPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.DocumentsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_CaseDocumentsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DataBaseOperations;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class DataAssessmentOperations extends ToolManager {
	public static WebElement webElement;
	static String className = DataAssessmentOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Data assesment as followup
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :20-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void dataAssessAsFollowup(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String RCTNo = FDE_General.getData(scenarioName, "ReceiptNo");
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptNo", RCTNo);
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.dataAssessmentLoader);
		agIsVisible(FullDataEntryFormPageObjects.dataAssessment_Label);
		if(agIsVisible(FullDataEntryFormPageObjects.reclassify)==true){
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.reclassify);
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.reclassifyYesBtn);
			agSetStepExecutionDelay("8000");
			
			agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.dataAssessmentLoader);
			agIsVisible(FullDataEntryFormPageObjects.dataAssessment_Label);
		}
		
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects
				.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentFollowup_Link));
		agSetStepExecutionDelay("5000");
		if (agIsVisible(FullDataEntryFormPageObjects.dataAssessment_WarningPopup) == true) {
			agClick(FullDataEntryFormPageObjects.dataAssessment_WarningPopup_YesBtn);
		}
		if (agIsVisible(FullDataEntryFormPageObjects.InitialWarning) == true) {
			agClick(FullDataEntryFormPageObjects.InitialWarningProceedBtn);
		}
		agIsVisible(FullDataEntryFormPageObjects.dataAssessment_header);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// agAssertContainsText(FullDataEntryFormPageObjects.dataAssessment_header,
		// getTestDataCellValue(scenarioName, "ReceiptNo"));
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Data assesment as followup
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :20-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void followupBasedOnAERNo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(DataAssessmentPageObjects.AER_Lookup);
		agSetStepExecutionDelay("5000");
		agIsVisible(DataAssessmentPageObjects.AERLookup_Header);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetStepExecutionDelay("3000");
		agSetValue(DataAssessmentPageObjects.AERNo_Textfield, getTestDataCellValue(scenarioName, "AERNo"));
		agClick(DataAssessmentPageObjects.AERLookupSearch_Btn);
		agIsVisible(DataAssessmentPageObjects.AERLookupSearchRes_label);

		agJavaScriptExecuctorClick(
				DataAssessmentPageObjects.AERLookupRadio_Btn(getTestDataCellValue(scenarioName, "AERNo")));
		CommonOperations.takeScreenShot();
		agClick(DataAssessmentPageObjects.AERLookupOk_Btn);
		agSetStepExecutionDelay("5000");
		agClick(FullDataEntryFormPageObjects.classifyCase_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.takeScreenShot();
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.loading);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.dataAssessmentLoader);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Data assesment as New
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :20-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void dataAssessAsNew(String scenarioName, String sheetName) {
		String RCTNo = agGetText(FullDataEntryFormPageObjects.RCTNo);
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.dataAssessmentLoader);
		agSetStepExecutionDelay("5000");
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptNo", RCTNo);
		agIsVisible(FullDataEntryFormPageObjects.dataAssessment_Label);
		// agClick(FullDataEntryFormPageObjects.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentNew_Link));
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.dataAssessNew);
		agSetStepExecutionDelay("5000");
		if (agIsVisible(FullDataEntryFormPageObjects.dataAssessment_WarningPopup) == true) {
			agClick(FullDataEntryFormPageObjects.dataAssessment_WarningPopup_YesBtn);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agIsVisible(FullDataEntryFormPageObjects.dataAssessment_header);
		// agSetStepExecutionDelay("3000");
		CommonOperations.agwaitTillVisible(FullDataEntryFormPageObjects.dataAssessment_header, 10, 1000);

		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.dataAssessment_header);
		// agAssertContainsText(FullDataEntryFormPageObjects.dataAssessment_header,
		// getTestDataCellValue(scenarioName, "ReceiptNo"));
		// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FullDataEntryFormPageObjects.dataAssesComments_TxtArea,
				getTestDataCellValue(scenarioName, "Comments"));
		CommonOperations.captureScreenShot(true);
		agClick(FullDataEntryFormPageObjects.classifyCase_Btn);
		agSetStepExecutionDelay("2000");
		dataAssesAsNewVerify(scenarioName, sheetName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Data assesment as followup
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :20-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void dataAssesAsFollowupVerify(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.loading);
		agSetStepExecutionDelay("30000");
		agAssertContainsText(CaseListingPageObjects.validationPopup,
				getTestDataCellValue(scenarioName, "ValidationMessage"));
		agAssertContainsText(CaseListingPageObjects.validationPopup, getTestDataCellValue(scenarioName, "ReceiptNo"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		String Validation = agGetText(CaseListingPageObjects.validationPopup);
		status = agIsVisible(CaseListingPageObjects.validationPopup);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Data assesed as Followup :: Validation-" + Validation, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Data assesed as Followup Unsuccessfull", true);
		}
		agWaitTillVisibilityOfElement(CaseListingPageObjects.PopupOkButton);
		agJavaScriptExecuctorClick(CaseListingPageObjects.PopupOkButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Data assesment as New
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :20-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void dataAssesAsNewVerify(String scenarioName, String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.write_AERNo(scenarioName, sheetName);
		// agSetStepExecutionDelay("5000");
		// agAssertContainsText(CaseListingPageObjects.validationPopup,
		// getTestDataCellValue(scenarioName, "ValidationMessage"));
		// agAssertContainsText(CaseListingPageObjects.validationPopup,
		// getTestDataCellValue(scenarioName, "ReceiptNo"));
		// String Validation = agGetText(CaseListingPageObjects.validationPopup);
		// status = agIsVisible(CaseListingPageObjects.validationPopup);
		// if (status) {
		// Reports.ExtentReportLog("", Status.PASS, "Data assesed as New :: Validation-"
		// + Validation, true);
		// } else {
		// Reports.ExtentReportLog("", Status.FAIL, "Data assesed as New Unsuccessfull",
		// true);
		// }
		//
		// agClick(CaseListingPageObjects.PopupOkButton);
		// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set the AER/RCT No in Data
	 *             assessment followup screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :21-Apr-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void FUAerNo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(DataAssessmentPageObjects.AER_Lookup);
		agSetStepExecutionDelay("5000");
		agIsVisible(DataAssessmentPageObjects.AERNo_Textfield);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(DataAssessmentPageObjects.AERNo_Textfield, DataAssessmentOperations.getData(scenarioName, "AERNo"));
		agClick(DataAssessmentPageObjects.AERLookupSearch_Btn);
		agSetStepExecutionDelay("2000");
		agClick(DataAssessmentPageObjects.AERSelect_CheckBox);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(DataAssessmentPageObjects.AERLookupOk_Btn);
		// agClick(DataAssessmentPageObjects.AERLookupRadio_Btn(getTestDataCellValue(scenarioName,
		// "AERNo")));
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: This method is to Verify the classification type button after
	 *             configuration changed (New , FollowUp , Duplicate)
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 20-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void VerifyClassificationTypes() {
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
		agAssertNotVisible(
				FullDataEntryFormPageObjects.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentNew_Link));

		if ((!agIsVisible(FullDataEntryFormPageObjects
				.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentNew_Link)) == true)) {

			Reports.ExtentReportLog("", Status.PASS, "New button is not visible", true);

		} else {

			Reports.ExtentReportLog("", Status.FAIL, "New button visible", true);
		}

		agAssertNotVisible(FullDataEntryFormPageObjects
				.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentFollowup_Link));

		if ((!agIsVisible(FullDataEntryFormPageObjects
				.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentFollowup_Link)) == true)) {

			Reports.ExtentReportLog("", Status.PASS, "FollowUp button is not visible", true);

		} else {

			Reports.ExtentReportLog("", Status.FAIL, "FollowUp button visible", true);
		}

		agAssertNotVisible(FullDataEntryFormPageObjects
				.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentDuplicate_Link));

		if ((!agIsVisible(FullDataEntryFormPageObjects
				.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentDuplicate_Link)) == true)) {

			Reports.ExtentReportLog("", Status.PASS, "Duplicate button is not visible", true);

		} else {

			Reports.ExtentReportLog("", Status.FAIL, "Duplicate button visible", true);
		}
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: This method is to Verify the classification type button after it
	 *             is reset back to as it is(New , FollowUp , Duplicate)
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 20-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyAfterRestClassificationTypes() {

		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
		agAssertVisible(
				FullDataEntryFormPageObjects.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentNew_Link));
		status = agIsVisible(
				FullDataEntryFormPageObjects.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentNew_Link));

		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "New button isvisible", true);

		} else {

			Reports.ExtentReportLog("", Status.FAIL, "New button is not visible", true);
		}

		agAssertVisible(FullDataEntryFormPageObjects
				.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentFollowup_Link));
		status = agIsVisible(FullDataEntryFormPageObjects
				.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentFollowup_Link));

		if (status) {

			Reports.ExtentReportLog("", Status.PASS, "FollowUp button is visible", true);

		} else {

			Reports.ExtentReportLog("", Status.FAIL, "FollowUp button is not visible", true);
		}

		agAssertVisible(FullDataEntryFormPageObjects
				.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentDuplicate_Link));
		status = agIsVisible(FullDataEntryFormPageObjects
				.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentDuplicate_Link));

		if (status) {

			Reports.ExtentReportLog("", Status.PASS, "Duplicate button is visible", true);

		} else {

			Reports.ExtentReportLog("", Status.FAIL, "Duplicate button is not visible", true);
		}

		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Data assessment followup
	 *             screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :21-Apr-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void dataAssessFollowUpverify(String scenarioName, String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FullDataEntryFormPageObjects.classifyCase_Btn);
		agSetStepExecutionDelay("5000");
		// String Validation = agGetText(CommonPageObjects.validationMsg);
		// status = agIsVisible(CommonPageObjects.validationMsg);
		// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// String data1 = Validation.substring(Validation.lastIndexOf(":"));
		// String AERNo = data1.substring(2, data1.length() - 1);
		// XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName,
		// scenarioName, "AERNo", AERNo.trim());
		// if (status) {
		// Reports.ExtentReportLog("", Status.PASS, "Data assesed as Follow Up ::
		// Validation-" + Validation, true);
		// } else {
		// Reports.ExtentReportLog("", Status.FAIL, "Data assesed as Follow Up
		// Unsuccessfull", true);
		// }
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify followup notification POP
	 *             up for un approved case
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :21-Apr-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void FollowUpNotificationPOPup(String scenarioName, String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FullDataEntryFormPageObjects.classifyCase_Btn);
		agSetStepExecutionDelay("5000");
		String Validation = agGetText(CommonPageObjects.FUNotificationPOPUP);
		status = agIsVisible(CommonPageObjects.FUNotificationPOPUP);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		String data1 = Validation.substring(Validation.lastIndexOf(":"));
		String AERNo = data1.substring(2, data1.length() - 1);
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "AERNo", AERNo.trim());
		if (status) {
			Reports.ExtentReportLog("", Status.PASS,
					"Data assesed as Follow Up and has been notified successfully for Follow-up :: Validation-"
							+ Validation,
					true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Data assesed as Follow Up notification Unsuccessfull", true);
		}
		agClick(CommonPageObjects.FUNotifictionOKBtn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify case summary sheet
	 *             checkbox,source ,support docs for approved case in Data
	 *             assessment followup screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :22-Apr-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCaseSummarySheetAndDocuments(String scenarioName) {
		verifyCaseSummarySheetcheckbox();
		FDE_CaseDocumentsOperations.verifydocuments(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify case summary sheet checkbox
	 *             for unapproved case in Data assessment followup screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :21-Apr-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyCaseSummarySheetcheckbox() {

		if (agIsVisible(DataAssessmentPageObjects.caseSymmarySheetCheckbox_Left) == true) {
			Reports.ExtentReportLog("Case Summary sheet check box checked for Unapproved Case", Status.PASS, "", true);
		} else {
			Reports.ExtentReportLog("Case Summary sheet check box not checked for Unapproved Case", Status.FAIL, "",
					true);
		}

		if (agIsVisible(DataAssessmentPageObjects.CaseSumamrysheetchckbox) == true) {
			Reports.ExtentReportLog("Case Summary sheet check box checked for Approved Case", Status.PASS, "", true);
		} else {
			Reports.ExtentReportLog("Case Summary sheet check box not checked for Approved Case", Status.FAIL, "",
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Data assesment as
	 *             Duplicate
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date :30-April-2020
	 * @UpdatedByAndWhen: Karthikeyan Natarajan, 17-Jul-20
	 **********************************************************************************************************/

	public static void dataAssessAsDuplicate(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// String RCTNo = FDE_General.getData(scenarioName, "ReceiptNo");
		// XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className,
		// scenarioName, "ReceiptNo", RCTNo);
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.dataAssessment_Label);
		agIsVisible(FullDataEntryFormPageObjects.dataAssessment_Label);

		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects
				.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentDuplicate_Link));
		agSetStepExecutionDelay("5000");
		if (agIsVisible(FullDataEntryFormPageObjects.dataAssessment_WarningPopup) == true) {
			agClick(FullDataEntryFormPageObjects.dataAssessment_WarningPopup_YesBtn);
		}
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.dataAssessment_header);
		agIsVisible(FullDataEntryFormPageObjects.dataAssessment_header);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (scenarioName.contains("QBEBasedonCaseDocuments")) {
			agSetStepExecutionDelay("5000");
			CommonOperations.captureScreenShot(true);
			agClick(FullDataEntryFormPageObjects.duplicateRCTlookup);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.duplicateRctNum);
			agSetValue(FullDataEntryFormPageObjects.duplicateRctNum, getTestDataCellValue(scenarioName, "ReceiptNo"));
			agClick(FullDataEntryFormPageObjects.RecptNumberSearchIcon);
			agSetStepExecutionDelay("5000");
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.searchRctRadioButton);
			agClick(FullDataEntryFormPageObjects.searchRctRadioButton);
			agJavaScriptExecuctorClick(DataAssessmentPageObjects.SelectBtn);
			// agClick(FullDataEntryFormPageObjects.duplicateRctSearchOk);
			// String dupAerNo = agGetAttribute("value",
			// FullDataEntryFormPageObjects.duplicateAerNumber);
			// System.out.println(dupAerNo);
			// agClick(FullDataEntryFormPageObjects.duplicateSpecifyReasonDropDown);
			// agClick(FullDataEntryFormPageObjects
			// .SelectSpecifyReason(getTestDataCellValue(scenarioName,
			// "DuplicateSpecifyReason")));
			// agSetValue(FullDataEntryFormPageObjects.duplicateAssesComments,
			// getTestDataCellValue(scenarioName, "DuplicateAssesComments"));

			agClick(FullDataEntryFormPageObjects.classifyCase_Btn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agWaitTillVisibilityOfElement(CaseListingPageObjects.PopupOkButton);
			agJavaScriptExecuctorClick(CaseListingPageObjects.PopupOkButton);
		} else {
			agAssertContainsText(FullDataEntryFormPageObjects.dataAssessment_header,
					getTestDataCellValue(scenarioName, "ReceiptNo"));
			agSetStepExecutionDelay("5000");
			agClick(FullDataEntryFormPageObjects.duplicateRCTlookup);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.duplicateRctNum);
			agSetValue(FullDataEntryFormPageObjects.duplicateRctNum,
					getTestDataCellValue(scenarioName, "DuplicateRCTNum"));
			agClick(FullDataEntryFormPageObjects.duplicateRctSearch);
			agClick(FullDataEntryFormPageObjects.searchRctRadioButton);
			agClick(FullDataEntryFormPageObjects.duplicateRctSearchOk);
			String dupAerNo = agGetAttribute("value", FullDataEntryFormPageObjects.duplicateAerNumber);
			System.out.println(dupAerNo);
			agClick(FullDataEntryFormPageObjects.duplicateSpecifyReasonDropDown);
			agClick(FullDataEntryFormPageObjects
					.SelectSpecifyReason(getTestDataCellValue(scenarioName, "DuplicateSpecifyReason")));
			agSetValue(FullDataEntryFormPageObjects.duplicateAssesComments,
					getTestDataCellValue(scenarioName, "DuplicateAssesComments"));
			Reports.ExtentReportLog("", Status.INFO, "Duplicate Data Assessment", true);
			agClick(FullDataEntryFormPageObjects.classifyCase_Btn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			dataAssesAsDuplicateVerify(scenarioName);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created Classify the case as a FOLLOW-UP of
	 *             an APPROVED case (Parent case)
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date :14-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ClassifyFollowUpBasedOnApprovedCase(String scenarioName) {

		DataAssessmentOperations.dataAssessAsFollowup(scenarioName);
		DataAssessmentOperations.followupBasedOnAERNo(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Data assesment based on
	 *             aer no in duplicate
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date :30-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void duplicateBasedOnAERNo(String scenarioName, String scenarioName1) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.dataAssessment_Label);
		agIsVisible(FullDataEntryFormPageObjects.dataAssessment_Label);
		agClick(FullDataEntryFormPageObjects
				.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentDuplicate_Link));
		agSetStepExecutionDelay("5000");
		if (agIsVisible(FullDataEntryFormPageObjects.dataAssessment_WarningPopup) == true) {
			agClick(FullDataEntryFormPageObjects.dataAssessment_WarningPopup_YesBtn);
		}
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.dataAssessmentDuplicate_header);
		agIsVisible(FullDataEntryFormPageObjects.dataAssessmentDuplicate_header);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetStepExecutionDelay("5000");
		agClick(DataAssessmentPageObjects.dupAERLookUP);
		agIsVisible(DataAssessmentPageObjects.libraryListHeader);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetStepExecutionDelay("5000");
		agSetValue(DataAssessmentPageObjects.AERNo_Textfield, getTestDataCellValue(scenarioName, "AERNo"));
		agClick(DataAssessmentPageObjects.AERLookupSearch_Btn);
		// agIsVisible(DataAssessmentPageObjects.AERLookupSearchRes_label);
		agSetStepExecutionDelay("5000");
		agClick(DataAssessmentPageObjects.AERLookupRadio_Btn(getTestDataCellValue(scenarioName, "AERNo")));
		CommonOperations.takeScreenShot();
		agClick(DataAssessmentPageObjects.AERLookupOk_Btn);
		agSetStepExecutionDelay("5000");
		agClick(FullDataEntryFormPageObjects.duplicateSpecifyReasonDropDown);
		agClick(FullDataEntryFormPageObjects
				.SelectSpecifyReason(getTestDataCellValue(scenarioName1, "DuplicateSpecifyReason")));
		agSetValue(FullDataEntryFormPageObjects.duplicateAssesComments,
				getTestDataCellValue(scenarioName1, "DuplicateComment"));
		Reports.ExtentReportLog("", Status.INFO, "Duplicate Data Assessment", true);
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.dupClassifyCase_Btn);
		agClick(FullDataEntryFormPageObjects.dupClassifyCase_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.actionCompletePopUp);
		agIsVisible(FullDataEntryFormPageObjects.actionCompletePopUp);
		agClick(FullDataEntryFormPageObjects.okBtn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created Classify the case as a FOLLOW-UP of
	 *             an UNAPPROVED case (Parent case)
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date :12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ClassifyFollowUpBasedOnUnapprovedCase(String scenarioName, String sheetName) {

		DataAssessmentOperations.dataAssessAsFollowup(scenarioName);
		DataAssessmentOperations.FUAerNo(scenarioName);
		DataAssessmentOperations.dataAssessFollowUpverify(scenarioName, sheetName);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Data assessment as
	 *             Duplicate
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :07-July-2020
	 * @UpdatedByAndWhen: Karthikeyan Natarajan, 17-Jul-20
	 **********************************************************************************************************/
	public static void dataAssesAsDuplicateVerify(String scenarioName) {
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.loading);
		String validationMessage = "Receipt Item '" + getTestDataCellValue(scenarioName, "ReceiptNo")
				+ "' classified as duplicate of '" + getTestDataCellValue(scenarioName, "DuplicateRCTNum")
				+ "' and Out of workflow.";
		agAssertContainsText(CaseListingPageObjects.validationPopup, validationMessage);
		// agAssertContainsText(CaseListingPageObjects.validationPopup,
		// getTestDataCellValue(scenarioName, "ReceiptNo"));
		String Validation = agGetText(CaseListingPageObjects.validationPopup);
		status = agIsVisible(CaseListingPageObjects.validationPopup);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Data assesed as Duplicate :: Validation-" + Validation, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Data assesed as Duplicate Unsuccessfull", true);
		}
		agWaitTillVisibilityOfElement(CaseListingPageObjects.PopupOkButton);
		agJavaScriptExecuctorClick(CaseListingPageObjects.PopupOkButton);

		AdvanceSearchOperations.outofWorkflowSearch(scenarioName);
		CaseManagementOperations.editCase();
		String label = agGetText(CaseListingPageObjects.lbl_deletedWorkflow);
		if (label.equalsIgnoreCase("DELETED"))
			Reports.ExtentReportLog("", Status.PASS, "Case is Deleted and moved out of worklow", true);
		else
			Reports.ExtentReportLog("", Status.FAIL, "Case is not deleted", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Data assesment as
	 *             Duplicate
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date :30-April-2020
	 * @UpdatedByAndWhen: Karthikeyan Natarajan , 17-Jul-20
	 **********************************************************************************************************/

	public static String dataAssessAsDuplicate(String scenarioName, String duplicateParentCase) {
		String workflowStatus = "";
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// String RCTNo = FDE_General.getData(scenarioName, "ReceiptNo");
		// XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className,
		// scenarioName, "ReceiptNo", RCTNo);
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.dataAssessment_Label);
		agIsVisible(FullDataEntryFormPageObjects.dataAssessment_Label);
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects
				.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentDuplicate_Link));
		agSetStepExecutionDelay("5000");
		if (agIsVisible(FullDataEntryFormPageObjects.dataAssessment_WarningPopup) == true) {
			agClick(FullDataEntryFormPageObjects.dataAssessment_WarningPopup_YesBtn);
		}
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.dataAssessment_header);
		agIsVisible(FullDataEntryFormPageObjects.dataAssessment_header);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// agAssertContainsText(FullDataEntryFormPageObjects.dataAssessment_header,
		// getTestDataCellValue(scenarioName, "ReceiptNo"));
		agSetStepExecutionDelay("5000");
		agSelectByVisibleText(FullDataEntryFormPageObjects.duplicateSpecifyReasonDropDown,
				getTestDataCellValue(scenarioName, "DuplicateSpecifyReason"));
		agClick(FullDataEntryFormPageObjects.duplicateRCTlookup);
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.duplicateRctNum);
		agSetValue(FullDataEntryFormPageObjects.duplicateRctNum, duplicateParentCase);
		agClick(FullDataEntryFormPageObjects.duplicateRctNumSearch);
		agClick(FullDataEntryFormPageObjects.searchRctRadioButton);
		agClick(FullDataEntryFormPageObjects.duplicateRctSearchOk);
		// String dupAerNo = agGetAttribute("value",
		// FullDataEntryFormPageObjects.duplicateAerNumber);
		// System.out.println(dupAerNo);
		/*
		 * agClick(FullDataEntryFormPageObjects.duplicateSpecifyReasonDropDown);
		 * agClick(FullDataEntryFormPageObjects
		 * .SelectSpecifyReason(getTestDataCellValue(scenarioName,
		 * "DuplicateSpecifyReason")));
		 */
		agSetValue(FullDataEntryFormPageObjects.duplicateAssesComments,
				getTestDataCellValue(scenarioName, "DuplicateAssesComments"));
		Reports.ExtentReportLog("", Status.INFO, "Duplicate Data Assessment", true);
		agClick(FullDataEntryFormPageObjects.classifyCase_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		workflowStatus = dataAssesAsDuplicateVerify(scenarioName, duplicateParentCase);

		return workflowStatus;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Data assessment as
	 *             Duplicate
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :07-July-2020
	 * @UpdatedByAndWhen: Karthikeyan Natarajan, 17-Jul-20
	 **********************************************************************************************************/
	public static String dataAssesAsDuplicateVerify(String scenarioName, String duplicateParentCase) {
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.loading);
		// String validationMessage = "Receipt Item '" +
		// getTestDataCellValue(scenarioName, "ReceiptNo")
		// + "' classified as duplicate of '" + duplicateParentCase + "' and Out of
		// workflow.";
		// agAssertContainsText(CaseListingPageObjects.validationPopup,
		// validationMessage);
		// agAssertContainsText(CaseListingPageObjects.validationPopup,
		// getTestDataCellValue(scenarioName, "ReceiptNo"));
		agSetStepExecutionDelay("3000");
		agIsVisible(CaseListingPageObjects.DupDeleteValidationPopUp);
		String Validation = agGetText(CaseListingPageObjects.DupDeleteValidationPopUp);
		status = agIsVisible(CaseListingPageObjects.DupDeleteValidationPopUp);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Data assesed as Duplicate :: Validation-" + Validation, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Data assesed as Duplicate Unsuccessfull", true);
		}
		agWaitTillVisibilityOfElement(CaseListingPageObjects.PopupOkButton);
		agJavaScriptExecuctorClick(CaseListingPageObjects.PopupOkButton);

		// AdvanceSearchOperations.outofWorkflowSearch(scenarioName);
		AdvanceSearchOperations.navigateToAdvanceSearch();
		agWaitTillVisibilityOfElement(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.caseDetails_link));
//		agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.caseDetails_link));
//		CommonOperations.agwaitTillVisible(AdvanceSearchPageObjects.displayCases_Label, 2, 1000);
		agSetStepExecutionDelay("3000");
//		agJavaScriptExecuctorClick(AdvanceSearchPageObjects.outofworkflow_RadioBtnCheck);
		AdvanceSearchOperations.receiptNumberSearch(scenarioName);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CaseManagementOperations.editCase();
		agWaitTillVisibilityOfElement(CaseListingPageObjects.lbl_deletedWorkflow);
		String label = agGetText(CaseListingPageObjects.lbl_deletedWorkflow);
		return label;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to do Data assessment as Duplicate in
	 *             E2E Scenario
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date :09-Oct-2020
	 **********************************************************************************************************/

	public static void E2EDataAssesasDuplicate(String scenarioName, String dupScenarioName) {

		Reports.ExtentReportLog("", Status.INFO, "E2E Duplicate Data Assessment Started", false);
		try {

			Connection dbCon = null;
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);
			String stmt = "Select * from lsmv_wpa_controller where scenario='" + dupScenarioName + "'";
			ResultSet dupRs = DataBaseOperations.performRead(dbCon, stmt);
			dupRs.beforeFirst();
			dupRs.next();
			String duplicateRctNum = dupRs.getString("Receipt_Number");

			String workFlowStatus = DataAssessmentOperations.dataAssessAsDuplicate(scenarioName, duplicateRctNum);

			if (workFlowStatus.equalsIgnoreCase("Rejected Case"))
				Reports.ExtentReportLog("", Status.PASS, "Case is Deleted and moved out of worklow", true);
			else
				Reports.ExtentReportLog("", Status.FAIL, "Case is not deleted", true);

			DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set Workflow_Status= '" + workFlowStatus
					+ "' where Scenario='" + scenarioName + "'");
			dbCon.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Reports.ExtentReportLog("", Status.INFO, "E2E Duplicate Data Assessment Ended", false);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to do Data assessment as Follow Up in
	 *             E2E Scenario
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date :09-Oct-2020
	 **********************************************************************************************************/

	public static void E2EDataAssessAsFollowUp(String scenarioName, String baseScenarioName) {

		Reports.ExtentReportLog("", Status.INFO, "E2E Followup Data Assessment Started", false);
		try {
			Connection dbCon = null;
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);

			DataAssessmentOperations.dataAssessAsFollowup(scenarioName);
			DataAssessmentOperations.followupBasedOnAERNo(baseScenarioName);
			// DataAssessmentOperations.dataAssesAsFollowupVerify(scenarioName);
			CaseListingOperations.searchCaseAndEdit(scenarioName, "lsmv_wpa_controller", "Receipt_Number");
			ReconciliationOperations.reconcileNotificationVerification(scenarioName);
			ReconciliationOperations.reconciliationSubmitWithChanges(scenarioName);
			FDE_Operations.LSMVSaveReconsile();
			ResultSet FUAERNo = DataBaseOperations.performRead(dbCon,
					"Select * from dataassessmentoperations where scenario='" + baseScenarioName + "'");

			FUAERNo.last();
			// rowCount = FUAERNo.getRow();
			FUAERNo.beforeFirst();
			FUAERNo.next();
			String fuAERNO = FUAERNo.getString("AERNo");

			DataBaseOperations.performWrite(dbCon, "update dataassessmentoperations set AERNo= '" + fuAERNO
					+ "' where Scenario='" + scenarioName + "'");
			dbCon.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		CaseListingOperations.searchCaseAndEdit(scenarioName, "lsmv_wpa_controller", "Receipt_Number");
		Reports.ExtentReportLog("", Status.INFO, "E2E Followup Data Assessment Ended", false);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to do Data assessment as Duplicate in
	 *             E2E Scenario
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date :09-Oct-2020
	 **********************************************************************************************************/

	public static void E2EDataAssessment(String scenarioName, String dataAssessment, String dupOrFollowUpScenario) {
		Reports.ExtentReportLog("", Status.INFO, "Data Assessment Started", false);
		switch (dataAssessment) {
		case "New":
			DataAssessmentOperations.dataAssessAsNew(scenarioName, "dataassessmentoperations");
			break;
		case "Followup":
			DataAssessmentOperations.E2EDataAssessAsFollowUp(scenarioName, dupOrFollowUpScenario);
			break;
		case "Duplicate":
			DataAssessmentOperations.E2EDataAssesasDuplicate(scenarioName, dupOrFollowUpScenario);
			LSMVLogin.Logout();
			Constants.extentReport.attachReporter(Constants.htmlReporter);
			Constants.extentReport.flush();
			break;
		}
		Reports.ExtentReportLog("", Status.INFO, "Data Assessment Ended", false);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to reclassify Case and verify aer no
	 *             is disappear after reclassification
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date :16-Oct-2020
	 **********************************************************************************************************/
	public static void ReClassifyCase(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
		agSetStepExecutionDelay("5000");
		agIsVisible(FullDataEntryFormPageObjects.reclassify);
		agClick(FullDataEntryFormPageObjects.reclassify);
		agIsVisible(FullDataEntryFormPageObjects.reclassificationpopupHeader);
		agSetValue(FullDataEntryFormPageObjects.reclassification_textArea,
				getTestDataCellValue(scenarioName, "ReclassificationComments"));
		agClick(FullDataEntryFormPageObjects.reclassifyYesBtn);

		status = agIsVisible(FullDataEntryFormPageObjects.reclassifySuccessMsg);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Case is reclassified successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Case is not reclassified successfully", true);
		}
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.dataAssessmentLoader);
		agSetStepExecutionDelay("5000");
		status = agIsVisible(FullDataEntryFormPageObjects.aernoDisappear);
		if (status) {
			Reports.ExtentReportLog("", Status.FAIL, "Aer No is not disappeared successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS, "Aer No is disappeared successfully", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify reclassification details in
	 *             Data Assessment History
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date :19-Oct-2020
	 **********************************************************************************************************/
	public static void VerifyReclassificationDetails(String scenarioName, String sheetName, String columnName) {
		agSetStepExecutionDelay("6000");
		agClick(CaseListingPageObjects.receiptNumberlink);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.dataAssessmentLoader);
		agSetStepExecutionDelay("5000");
		agIsVisible(FullDataEntryFormPageObjects.dataAssessmentHistoryTab);
		agAssertExists(FullDataEntryFormPageObjects.duplicateClassification);
		String HistoryReceiptNo = agGetText(FullDataEntryFormPageObjects.histroryReceiptNo);

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		if (HistoryReceiptNo.equalsIgnoreCase(getTestDataCellValue(scenarioName, columnName))) {
			Reports.ExtentReportLog("", Status.PASS, "ReceiptNo Matched successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "ReceiptNo not Matched successfully", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify reclassification as new
	 *             details in Data Assessment History
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date :06-Nov-2020
	 **********************************************************************************************************/
	public static void VerifyReclassificationAsNewDetails(String scenarioName, String sheetName, String columnName) {
		agIsVisible(FullDataEntryFormPageObjects.dataAssessmentHistoryTab);
		agAssertExists(FullDataEntryFormPageObjects.newClassification);
		String HistoryReceiptNo = agGetText(FullDataEntryFormPageObjects.histroryReceiptNo);

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		if (HistoryReceiptNo.equalsIgnoreCase(getTestDataCellValue(scenarioName, columnName))) {
			Reports.ExtentReportLog("", Status.PASS, "ReceiptNo Matched successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "ReceiptNo not Matched successfully", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to move duplicate Case to new case
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date :19-Oct-2020
	 **********************************************************************************************************/

	public static void moveDuplicateCasetoNewCase() {
		agSetStepExecutionDelay("6000");
		agClick(CaseListingPageObjects.receiptNumberlink);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
		agSetStepExecutionDelay("5000");

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify classified details for
	 *             followUp case in Data Assessment History
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date :23-Oct-2020
	 **********************************************************************************************************/
	public static void verifyDataAssessmentHistoryOfFollowUpCase(String scenarioName, String sheetName,
			String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.dataAssessmentLoader);
		agSetStepExecutionDelay("5000");
		agIsVisible(FullDataEntryFormPageObjects.dataAssessmentHistoryTab);
		agAssertExists(FullDataEntryFormPageObjects.FollowUpClassification);
		String HistoryReceiptNo = agGetText(FullDataEntryFormPageObjects.histroryReceiptNo);

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		if (HistoryReceiptNo.equalsIgnoreCase(getTestDataCellValue(scenarioName, columnName))) {
			Reports.ExtentReportLog("", Status.PASS, "ReceiptNo Matched successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "ReceiptNo not Matched successfully", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Navigation from history tab
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date :23-Oct-2020
	 **********************************************************************************************************/
	public static void navigatetoCaseFromHistoryTab() {
		agClick(FullDataEntryFormPageObjects.navigateToVersionHistoryTab);
		agIsVisible(FullDataEntryFormPageObjects.versionHistoryHeader);
		agClick(FullDataEntryFormPageObjects.versionHistoryAerNo);

		status = agIsVisible(FullDataEntryFormPageObjects.caseAerNO);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Navigated to case successfully from HistoryTab", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Not Navigated to case  successfully from HistoryTab", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Data assesment as followup
	 *             based on Receipt No
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date :28-Oct-2020
	 * @UpdatedByAndWhen:WajahatUmar S on 15-Dec-2020
	 **********************************************************************************************************/
	public static void followupBasedOnReceiptNo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(DataAssessmentPageObjects.receiptNo_followupLookup);
		agSetStepExecutionDelay("5000");
		agIsVisible(DataAssessmentPageObjects.AERLookup_Header);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetStepExecutionDelay("3000");
		agSetValue(DataAssessmentPageObjects.AERNo_Textfield, getTestDataCellValue(scenarioName, "ReceiptNo"));
		agClick(DataAssessmentPageObjects.AERLookupSearch_Btn);
		agIsVisible(DataAssessmentPageObjects.AERLookupSearchRes_label);
		agSetStepExecutionDelay("15000");
		agWaitTillVisibilityOfElement(
				DataAssessmentPageObjects.AERLookup_CheckBox(getTestDataCellValue(scenarioName, "ReceiptNo")));
		agClick(DataAssessmentPageObjects.AERLookup_CheckBox(getTestDataCellValue(scenarioName, "ReceiptNo")));
		CommonOperations.takeScreenShot();
		agClick(DataAssessmentPageObjects.AERLookupOk_Btn);
		agSetStepExecutionDelay("10000");
		if (getTestDataCellValue(scenarioName, "MergeCheckBox").equalsIgnoreCase("True")) {
			agClick(DataAssessmentPageObjects.MergeDocumentCheckBox);
		}
		agClick(FullDataEntryFormPageObjects.classifyCase_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.takeScreenShot();
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.loading);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.dataAssessmentLoader);
		agSetStepExecutionDelay("8000");
		status = agIsVisible(CaseListingPageObjects.validationPopup);
		if (status) {
			agWaitTillVisibilityOfElement(CaseListingPageObjects.PopupOkButton);
			agJavaScriptExecuctorClick(CaseListingPageObjects.PopupOkButton);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search based on custom search and
	 *             verify result
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date :11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void customSearch(String scenarioName) {
		agClick(DataAssessmentPageObjects.customRadio);
		agIsVisible(DataAssessmentPageObjects.searchBtn);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		agClick(DataAssessmentPageObjects.productDescLookUp);
		agIsVisible(DataAssessmentPageObjects.listOfproductHeader);
		agSetValue(DataAssessmentPageObjects.productName,
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"));
		agClick(DataAssessmentPageObjects.productSearchBtn);
		agJavaScriptExecuctorClick(DataAssessmentPageObjects.checkSearchedProduct);
		agClick(DataAssessmentPageObjects.productOkBtn);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		agSetValue(DataAssessmentPageObjects.safetyReportId,
				getTestDataCellValue(scenarioName, "Gen_CaseReferences_SafetyReportID"));
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
		agSetValue(DataAssessmentPageObjects.reportedTerm,
				getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Patient");
		agSetValue(DataAssessmentPageObjects.patientId,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_PatientID"));
		agClick(DataAssessmentPageObjects.searchBtn);
		agWaitTillInvisibilityOfElement(DataAssessmentPageObjects.loader);
		status = agIsVisible(DataAssessmentPageObjects.noRecordFound);

		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Duplicate record not found Successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Duplicate record found Successfully", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click custom search
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :13-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void customSearchinDataAssessment() {
		agSetStepExecutionDelay("2000");
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.dataAssessmentLoader);
		agSetStepExecutionDelay("5000");
		agJavaScriptExecuctorClick(DataAssessmentPageObjects.customRadio);
		agIsVisible(DataAssessmentPageObjects.searchBtn);
		Reports.ExtentReportLog("", Status.INFO, "Navigate to Custom Search in Data Assessment", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search all fields based on custom
	 *             search and verify result
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :13-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setAllFieldsForCustomSearch(String scenarioName) {
		agSetStepExecutionDelay("3000");
		setProductDetails(scenarioName);
		setGeneralDetails(scenarioName);
		setEventsDetails(scenarioName);
		setLiteratureDetails(scenarioName);
		setPatientDetails(scenarioName);
		setSourceDetails(scenarioName);
		setStudyDetails(scenarioName);
		setReporterDetails(scenarioName);
		agClick(DataAssessmentPageObjects.searchBtn);
		agJavaScriptExecuctorScrollToElement(DataAssessmentPageObjects.otherSafetyRefNoLabel);
		Reports.ExtentReportLog("", Status.INFO, "Custom/Duplicate Search in Data Assessment", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Product details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 13-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setProductDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		agSetStepExecutionDelay("2000");
		agClick(DataAssessmentPageObjects.productDescLookUp);
		agIsVisible(DataAssessmentPageObjects.listOfproductHeader);
		agSetValue(DataAssessmentPageObjects.productName,
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"));
		agClick(DataAssessmentPageObjects.productSearchBtn);
		agJavaScriptExecuctorClick(DataAssessmentPageObjects.checkSearchedProduct);
		agClick(DataAssessmentPageObjects.productOkBtn);
		agSelectByVisibleText(DataAssessmentPageObjects.productChaacterzation_Dropdown,
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductCharacterization"));
		Reports.ExtentReportLog("", Status.INFO, "Product details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set unBlindProduct details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 13-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setUnBlindProductDetails(String scenarioName) {
		agSetStepExecutionDelay("2000");
		agClick(DataAssessmentPageObjects.productDescLookUp);
		agIsVisible(DataAssessmentPageObjects.listOfproductHeader);

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "Product_LookupOperations");
		agSetValue(DataAssessmentPageObjects.productName,
				getTestDataCellValue(scenarioName, "ProductLibraryProductName"));
		agClick(DataAssessmentPageObjects.productSearchBtn);
		agJavaScriptExecuctorClick(DataAssessmentPageObjects.checkSearchedProduct);
		CommonOperations.takeScreenShot();
		agClick(DataAssessmentPageObjects.productOkBtn);
		agClick(DataAssessmentPageObjects.searchBtn);
		agJavaScriptExecuctorScrollToElement(DataAssessmentPageObjects.otherSafetyRefNoLabel);
		Reports.ExtentReportLog("", Status.INFO, "UnBlind Product details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set general details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 13-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setGeneralDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		agSetStepExecutionDelay("2000");
		agSetValue(DataAssessmentPageObjects.safetyReportId,
				getTestDataCellValue(scenarioName, "Gen_CaseReferences_SafetyReportID"));
		// agSetValue(DataAssessmentPageObjects.authorityNo,
		// getTestDataCellValue(scenarioName,
		// "Gen_CaseReferences_AuthorityNoCompNumber"));
		// agSetValue(DataAssessmentPageObjects.LRDFromRecvDate, CommonOperations
		// .returnDateTime(getTestDataCellValue(scenarioName,
		// "Gen_CaseDates_LatestReceivedDate")));
		// agSetValue(DataAssessmentPageObjects.LRDToRecvDate, CommonOperations
		// .returnDateTime(getTestDataCellValue(scenarioName,
		// "Gen_CaseDates_LatestReceivedDate")));
		agSelectByVisibleText(DataAssessmentPageObjects.primarySourceCountry_Dropdown,
				getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_PrimarySourceCountry"));
		agSelectByVisibleText(DataAssessmentPageObjects.reportType_Dropdown,
				getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportType"));
		agSelectByVisibleText(DataAssessmentPageObjects.countryDetection_Dropdown,
				getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_CountryOfDetection"));
		Reports.ExtentReportLog("", Status.INFO, "General details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set events details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 13-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setEventsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
		agSetStepExecutionDelay("2000");
		// agSetValue(DataAssessmentPageObjects.onsetDate, CommonOperations
		// .returnDateTime(getTestDataCellValue(scenarioName,
		// "Events_EventInformation_OnsetDate")));
		agSetValue(DataAssessmentPageObjects.reportedTerm,
				getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		Reports.ExtentReportLog("", Status.INFO, "Event details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set literature details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 13-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setLiteratureDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Literature");
		agSetStepExecutionDelay("2000");
		agSetValue(DataAssessmentPageObjects.articleTitle,
				getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_ArticleTitle"));
		agSetValue(DataAssessmentPageObjects.journalTitle,
				getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_JournalTitle"));
		// agSetValue(DataAssessmentPageObjects.literatureRef,
		// getTestDataCellValue(scenarioName,
		// "Literature_LiteratureInformation_LiteratureReference"));
		Reports.ExtentReportLog("", Status.INFO, "Literature details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set patient details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 13-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setPatientDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Patient");
		agSetStepExecutionDelay("2000");
		// agSetValue(DataAssessmentPageObjects.patientDOB, CommonOperations
		// .returnDateTime(getTestDataCellValue(scenarioName,
		// "Patient_PatientIdentifiers_PatientDOB")));
		// agSetValue(DataAssessmentPageObjects.ageTimeEvent,
		// getTestDataCellValue(scenarioName,
		// "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent"));
		agSetValue(DataAssessmentPageObjects.patientID,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_PatientID"));
		agSetValue(DataAssessmentPageObjects.hospitalRecordNo,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_HospitalRecordNumber"));
		agSetValue(DataAssessmentPageObjects.GPrecordNo,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_GPMedicalRecordNumber"));
		agSelectByVisibleText(DataAssessmentPageObjects.gender_dropDown,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_Gender"));

		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,
		// "DuplicateCheckPolicyOperations");
		// agSelectByVisibleText(DataAssessmentPageObjects.patientAgeUnit_Dropdown,
		// getTestDataCellValue(scenarioName, "AgeAtTheTimeOfEvent_Units"));
		Reports.ExtentReportLog("", Status.INFO, "Patient details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set source details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 13-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSourceDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Source");
		agSetStepExecutionDelay("2000");
		agSetValue(DataAssessmentPageObjects.referenceNum,
				getTestDataCellValue(scenarioName, "Source_ReferenceNumber"));
		agSelectByVisibleText(DataAssessmentPageObjects.referenceType_Dropdown,
				getTestDataCellValue(scenarioName, "Source_ReferenceType"));
		Reports.ExtentReportLog("", Status.INFO, "Source details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set study details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 13-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setStudyDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Study");
		// agClick(DataAssessmentPageObjects.ProtocolNoLookup);
		// agWaitTillVisibilityOfElement(DataAssessmentPageObjects.searchTextBox);
		// agSetValue(DataAssessmentPageObjects.searchTextBox,
		// getTestDataCellValue(scenarioName, "Study_StudyLookup_StudyNo"));
		// agClick(DataAssessmentPageObjects.ProtocolSearchIcon);
		// agSetStepExecutionDelay("2000");
		// agClick(DataAssessmentPageObjects.ProductRadioBtn);
		// agClick(DataAssessmentPageObjects.studyOkBtn);
		agSetValue(DataAssessmentPageObjects.centerNo,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_CenterNumber"));
		agSetValue(DataAssessmentPageObjects.subjectID,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_SubjectID"));
		Reports.ExtentReportLog("", Status.INFO, "Study details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set reporter details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 13-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setReporterDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Reporter");
		agSetStepExecutionDelay("2000");
		agSetValue(DataAssessmentPageObjects.firstName, getTestDataCellValue(scenarioName, "Reporter_FirstName"));
		agSetValue(DataAssessmentPageObjects.LastName, getTestDataCellValue(scenarioName, "Reporter_LastName"));
		agSetValue(DataAssessmentPageObjects.state, getTestDataCellValue(scenarioName, "Reporter_State"));
		agSetValue(DataAssessmentPageObjects.postalCode, getTestDataCellValue(scenarioName, "Reporter_PostalCode"));
		agSelectByVisibleText(DataAssessmentPageObjects.country_Dropdown,
				getTestDataCellValue(scenarioName, "Reporter_Country"));
		Reports.ExtentReportLog("", Status.INFO, "Reporter details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify the RCT number result shown
	 *             based on custom search
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 13-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyRCTNumber(String scenarioName) {
		String data = FDE_General.getData(scenarioName, "ReceiptNo");
		int fileCount = 0;
		int i;
		ArrayList<String> receiptnum = DataAssessmentOperations.receiptNoList();
		List<WebElement> rctNum = agGetElementList(DataAssessmentPageObjects.receiptNoList);
		if (receiptnum.size() > 0) {

			for (i = 0; i < rctNum.size(); i++) {
				if (data.equalsIgnoreCase(receiptnum.get(i))) {
					System.out.println("Available Receipt numbers : " + i + receiptnum.get(i));
					System.out.println(receiptnum.get(i));
					fileCount++;
					break;
				}
			}

			if (fileCount > 0) {
				Reports.ExtentReportLog("", Status.PASS,
						"Irrespective of Previleges the cases with blinded and unblinded results are searched in Duplicate search  "
								+ receiptnum.get(i),
						true);
			}
			if (fileCount == 0) {
				Reports.ExtentReportLog("", Status.FAIL,
						"Irrespective of Previleges the cases with blinded and unblinded results are not searched in Duplicate search  "
								+ receiptnum.get(i),
						true);
			}
		} else {
			Reports.ExtentReportLog("", Status.FAIL, " Receipt numbers not visible ", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify the RCT number result shown
	 *             based on custom search
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 17-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> receiptNoList() {
		ArrayList Al = new ArrayList<>();
		if (agIsVisible(DataAssessmentPageObjects.receiptNoList) == true) {
			List<WebElement> receiptNo = agGetElementList(DataAssessmentPageObjects.receiptNoList);
			for (int i = 0; i < receiptNo.size(); i++) {
				String rctNo = agGetText(
						DataAssessmentPageObjects.receiptNo.replace("%count%", Integer.toString(i + 1)));
				List<String> list = Arrays.asList(rctNo.toString());
				Al.addAll(list);
			}

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Receipt numbers list not visible ", true);
		}
		return Al;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Follow-up response - Append to
	 *             Existing
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :13-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void FollowupresponseAppendtoExisting(String scenarioName, String scenarioName1) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Follow up response Append to Existing Started", true);

			// Creation of a Parent case
			CreateCase(scenarioName);
			Reports.ExtentReportLog("", Status.INFO, "Creation of a Parent Case", true);
			DataAssessmentOperations.dataAssessAsNew(scenarioName, "DataAssessmentOperations");

			// Creation of a Child case
			CreateCase(scenarioName1);
			Reports.ExtentReportLog("", Status.INFO, "Creation of a Child Case", true);
			CaseListingOperations.searchCaseAndEdit(scenarioName1, "FDE_General", "ReceiptNo");
			DataAssessmentOperations.dataAssessAsFollowup(scenarioName);
			DataAssessmentOperations.followupBasedOnAERNo(scenarioName);
			DataAssessmentOperations.dataAssesAsFollowupVerify(scenarioName);

			// Verify that the Child case is in non-editable mode
			CaseListingOperations.searchCase(scenarioName1, "FDE_General", "ReceiptNo");
			CaseListingOperations.VerifyChildCaseInNonEditableMode();

			// Edit the Parent Case
			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
			ReconciliationOperations.followupAlertWindowVerify("CaseFollowup_DataAssessedFollowup");
			ReconciliationOperations.reconciliationWindowVerification();

			// APPEND TO EXISTING in the Compare and Reconcile window
			ReconciliationOperations.appendtoExistingVerification(scenarioName);

			// Verify the data and the documents which are copied into the Parent case
			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
			CaseDataVerification(scenarioName1);

			// Verify that the Child case is moved to Out-of-Workflow
			String data = FDE_General.getData(scenarioName1, "ReceiptNo");
			AdvanceSearchOperations.setData(scenarioName1, "ReceiptNo", data);
			CaseListingOperations.navigateToCaseListing();
			AdvanceSearchOperations.outofWorkflowSearch(scenarioName1);
			FDE_Operations.verifyCaseOutOfWorkflow("Out Of WF");

			Reports.ExtentReportLog("", Status.INFO, "Follow up response Append to Existing Ended", true);
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Follow up response Append to Existing Failed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Create a case
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :13-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void CreateCase(String scenarioName) {
		try {
			CaseManagementOperations.caseManagement_MenuNavigations("fullDataEntryForm");
			FDE_General.LSMVSetGeneralBasicDetails(scenarioName);
			FDE_Operations.tabNavigation("Reporter");
			FDE_Reporter.set_ReporterData(scenarioName);
			FDE_Operations.tabNavigation("Study");
			FDE_Study.set_StudyData(scenarioName);
			FDE_Operations.tabNavigation("Patient");
			FDE_Patient.set_Patient(scenarioName);
			FDE_Operations.tabNavigation("Product(s)");
			FDE_Products.setProductData(scenarioName);
			FDE_Operations.tabNavigation("Event(s)");
			FDE_Events.set_Events(scenarioName);
			FDE_Operations.tabNavigation("Causality");
			FDE_Causality.CausalityInformation(scenarioName);
			FDE_Operations.tabNavigation("Lab Data");
			FDE_LabData.set_TestsData(scenarioName);
			FDE_Operations.LSMVSave(scenarioName, "FDE_General");
			UploadSingleSourceDocument();
			FDE_Operations.LSMVSave(scenarioName, "FDE_General");
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Case Creation Failed", true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method Upload Source Document(one files)
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :17-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void UploadSingleSourceDocument() {
		try {
			agClick(DocumentsPageObjects.CaseDocumentBtn);
			agClick(DocumentsPageObjects.AddDocBtn);
			agSetStepExecutionDelay("3000");
			agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile("1"),
					lsmvConstants.LSMV_testDataInput + "\\" + "LSMV_1MB.pdf");
			agSetStepExecutionDelay("5000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully) == true) {
				agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.actComp_Sucessfully);
				agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.ActionOkBtn);
				agClick(FullDataEntryFormPageObjects.ActionOkBtn);
			}
			agWaitTillVisibilityOfElement(FDE_CaseDocumentsPageObjects.filenameLink);
			Reports.ExtentReportLog("Document Uploaded", Status.PASS, "Document Uploaded successfull ::", true);
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Upload Document failed", true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Verify a case
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :17-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void CaseDataVerification(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Verification of Case data and Document Started", true);
			FDE_Operations.tabNavigation("General");
			FDE_General.generalDetails_Verification(scenarioName);
			FDE_Operations.tabNavigation("Study");
			FDE_Study.verify_StudyData(scenarioName);
			// FDE_Operations.tabNavigation("Patient");
			// FDE_Patient.patientData_Verification(scenarioName);
			FDE_Operations.tabNavigation("Product(s)");
			FDE_Products.productData_Verification(scenarioName);
			FDE_Operations.tabNavigation("Event(s)");
			FDE_Events.verify_Event(scenarioName);
			FDE_Operations.tabNavigation("Lab Data");
			FDE_LabData.testsData_Verification(scenarioName);
			agClick(DocumentsPageObjects.CaseDocumentBtn);
			FDE_SplitCase.sourceDocumentsVerification();
			FDE_Operations.FDE_Navigations("Case Information");
			FDE_Operations.LSMVSaveReconsile();
			Reports.ExtentReportLog("", Status.INFO, "Verification of Case data and Document is Completed", true);
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Case Verification Failed", true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Write data into excel sheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to verify duplicate cases
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Padmapriya
	 * @Date : 14-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyForDuplicateCases() {
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
		agSetStepExecutionDelay("5000");
		if (agIsVisible(FullDataEntryFormPageObjects.duplicateAerNumber)) {
			Reports.ExtentReportLog("", Status.FAIL, "Duplicate cases found", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS, "Duplicate cases not found", true);
		}

	}

}
