package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CaseListingDeletePageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDEMoreOptionsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.OutofWorkFlowPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class CaseDeleteOperations extends ToolManager{
	public static WebElement webElement;
	static String className = CaseDeleteOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	

	/**********************************************************************************************************
	 * @Objective: The below method is created to set data in delete reason Popup.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 26-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void setDeleteReason(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(CaseListingDeletePageObjects.clickdeleteReasonCodeDropdown);
		agClick(CaseListingDeletePageObjects.selectdeleteReasonCode);
		agSetValue(CaseListingDeletePageObjects.deleteAuditReason_Textarea,
				getTestDataCellValue(scenarioName, "DeleteReason"));
		agClick(CaseListingDeletePageObjects.deleteAuditReasonSubmit_Btn);
		Reports.ExtentReportLog("", Status.INFO, "Delete Audit Reason Popup is displayed", true);
		//CommonOperations.agwaitTillVisible(CaseListingDeletePageObjects.validationPopup);
		
		
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to select the case and perform delete
	 * operation from case listing
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 26-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/		
	
	public static void deleteCase(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String RCTNo=FDE_General.getData(scenarioName, "ReceiptNo");
		System.out.println("ReceiptNo::"+RCTNo);
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptNo", RCTNo);
		agClick(CaseListingPageObjects.clickCheckBox(getTestDataCellValue(scenarioName, "ReceiptNo")));
		CaseListingOperations.caseListing_Moreoptions(CaseListingPageObjects.delete_link);
		setCaselistingDeleteReason(scenarioName);
        agCheckPropertyText(getTestDataCellValue(scenarioName, "MSG"),CaseListingPageObjects.get_deleteValidationMSG);
        agClick(CaseListingPageObjects.deletePopup_YesBtn);
         agSetStepExecutionDelay("3000");
		 status = agIsVisible(CaseListingPageObjects.validationPopup);
		 agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (status) {
		String validation = agGetText(CaseListingPageObjects.validationPopup);
		agAssertContainsText(CaseListingPageObjects.validationPopup, "deleted successfully");
			Reports.ExtentReportLog("Case is deleted successfully", Status.PASS, "Validation : " + validation, true);
			
		}else
			{
				Reports.ExtentReportLog("Case is not deleted successfully", Status.FAIL, "", true);
			}
		        agClick(CaseListingPageObjects.PopupOkButton);
		}
	/**********************************************************************************************************
	 * @Objective: The below method is created to case Level delete
	 * operation
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 30-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/		
	
	public static void caseLeveldelete(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String RCTNo=FDE_General.getData(scenarioName, "ReceiptNo");
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptNo", RCTNo);
		FDE_Operations.MoreOptionsLinksNavigation(FDEMoreOptionsPageObjects.moreOptions(FDEMoreOptionsPageObjects.delete_Link));
		agSetStepExecutionDelay("5000");
		agClick(FDEMoreOptionsPageObjects.deleteOkButton);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		setDeleteReason(scenarioName);
		agSetStepExecutionDelay("5000");
		status = agIsVisible(CaseListingDeletePageObjects.validationPopup);
		if (status) {
		String validation = agGetText(CaseListingDeletePageObjects.validationPopup);
		agAssertContainsText(CaseListingDeletePageObjects.validationPopup, getTestDataCellValue(scenarioName, "CaseLevelDeleteMSG"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("Case is deleted successfully", Status.PASS, "Validation : " + validation, true);
		}else
		{
			Reports.ExtentReportLog("Case is not deleted successfully", Status.FAIL, "", true);
		}
		agClick(CaseListingDeletePageObjects.validationPopupOkBtn);
        
		}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify deleted case in case listing and in outofWorkFlow listing.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 26-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void verifyDeletedcase(String scenarioName){
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CaseListingOperations.searchCreatedCase("Deletecase","CaseDeleteOperations","ReceiptNo");
		agAssertContainsText(CaseListingPageObjects.noRecordFound, "No records found.");
		OutofWorkflowListingOperations.outofWorkFlowSearch(scenarioName);
		 status = agIsVisible(OutofWorkFlowPageObjects.outofWorkFlowGetReceiptID);
		if(status)
		{
		agCheckPropertyValue("title", getTestDataCellValue(scenarioName, "ReceiptNo"), CaseListingPageObjects.getReceiptNumber);
		String receptno =agGetText(CaseListingPageObjects.getReceiptNumber);
		Reports.ExtentReportLog("Deleted case is displayed in out of WorkFlow listing successfully", Status.PASS,
					"Receipt Number : " + receptno, true);
		} 
		else {
			Reports.ExtentReportLog("Deleted case is not displayed in out of WorkFlow listing", Status.FAIL,"", true);

		}

	}
	
	/**********************************************************************************************************
	 * @Objective: This method is created to move to delete activity.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 31-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	

	public static void movetoDeleteActivity(String scenarioName){
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(CaseListingPageObjects.workflowlink(CaseListingPageObjects.caseDeletion_WFlink));
		agSetStepExecutionDelay("3000");
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, "ReceiptNo"));
		agClick(CaseListingPageObjects.searchButton);
		CommonOperations.waitTillCaseVisible();
		Reports.ExtentReportLog("", Status.INFO,"Case is successfully listed in Case deletion activity", true);
		agClick(CaseListingPageObjects.receiptNumberlink);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		  agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
		agMouseHover(FullDataEntryFormPageObjects.actions_Btn);
		Reports.ExtentReportLog("", Status.INFO,"Case is successfully moved to::"+getTestDataCellValue(scenarioName, "WorkflowActivity") +"::activity", true);
		agClick(FullDataEntryFormPageObjects.completeActivity_link);
		agSetStepExecutionDelay("5000");
		status = agIsVisible(CaseListingPageObjects.validationPopup);
		if (status) {
		String validation = agGetText(CaseListingPageObjects.validationPopup);
		agAssertContainsText(FullDataEntryFormPageObjects.receiptNumber, getTestDataCellValue(scenarioName, "WorkflowLevelDeleteMSG"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("Case is deleted successfully", Status.PASS, "Validation : " + validation, true);
		}else
		{
			Reports.ExtentReportLog("Case is not deleted successfully", Status.FAIL, "", true);
		}
		agClick(FullDataEntryFormPageObjects.saveOkButton);
	}
	
	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	

	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
	
	/**********************************************************************************************************
	 * @Objective: This method is created to delete case
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 07-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void caseDeletion(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Delete"));
		if(agIsVisible(CaseListingPageObjects.ConfirmationMessage)) {
			agClick(CaseListingPageObjects.OkButton);
		}
		setDeleteReason(scenarioName);
        //agCheckPropertyText(getTestDataCellValue(scenarioName, "MSG"),CaseListingPageObjects.get_deleteValidationMSG);
        //agClick(CaseListingPageObjects.deletePopup_YesBtn);
         agSetStepExecutionDelay("3000");
		 status = agIsVisible(CaseListingPageObjects.validationPopup);
		 agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (status) {
		String validation = agGetText(CaseListingPageObjects.validationPopup);
		agAssertContainsText(CaseListingPageObjects.validationPopup, "deleted successfully");
			Reports.ExtentReportLog("Case is deleted successfully", Status.PASS, "Validation : " + validation, true);
			
		}else
			{
				Reports.ExtentReportLog("Case is not deleted successfully", Status.FAIL, "", true);
			}
		        agClick(CaseListingPageObjects.PopupOkButton);
		}
	/**********************************************************************************************************
	 * @Objective: This method is created to move to reject activity.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 13-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void movetoRejectActivity(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(CaseListingPageObjects.workflowlink(CaseListingPageObjects.caseDeletion_WFlink));
		agSetStepExecutionDelay("3000");
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, "ReceiptNo"));
		agClick(CaseListingPageObjects.searchButton);
		CommonOperations.waitTillCaseVisible();
		Reports.ExtentReportLog("", Status.INFO,"Case is successfully listed in Case deletion activity", true);
		agClick(CaseListingPageObjects.receiptNumberlink);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
		agSetStepExecutionDelay("5000");
		CommonOperations.setActivity("Reject Deletion");
		agMouseHover(FullDataEntryFormPageObjects.actions_Btn);
		Reports.ExtentReportLog("", Status.INFO,"Case is successfully moved to::"+getTestDataCellValue(scenarioName, "WorkflowActivity") +"::activity", true);
		agClick(FullDataEntryFormPageObjects.completeActivity_link);
		agSetStepExecutionDelay("5000");
		setRejectReason(scenarioName);	
		status = agIsVisible(CaseListingPageObjects.validationPopup);
		if (status) {
		String validation = agGetText(CaseListingPageObjects.validationPopup);
		agAssertContainsText(FullDataEntryFormPageObjects.receiptNumber, getTestDataCellValue(scenarioName, "WorkflowLevelRejectedMSG"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("Case is rejected successfully", Status.PASS, "Validation : " + validation, true);
		}else
		{
			Reports.ExtentReportLog("Case is not rejected successfully", Status.FAIL, "", true);
		}
		agClick(FullDataEntryFormPageObjects.saveOkButton);
	}
	

	/**********************************************************************************************************
	 * @Objective: This method is created to search deleted case delete activity.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 15-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void searchDeletedCase(String scenarioName){
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(CaseListingPageObjects.workflowlink(CaseListingPageObjects.caseDeletion_WFlink));
		agSetStepExecutionDelay("3000");
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, "ReceiptNo"));
		agClick(CaseListingPageObjects.searchButton);
		CommonOperations.waitTillCaseVisible();
		Reports.ExtentReportLog("", Status.INFO,"Case is successfully listed in Case deletion activity", true);
		agClick(CaseListingPageObjects.receiptNumberlink);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		  agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to set data in reject reason Popup.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 27-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void setRejectReason(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(CaseListingDeletePageObjects.clickRejectReasonCodeDropdown);
		agClick(CaseListingDeletePageObjects.selectRejectReasonCode);
		agSetValue(CaseListingDeletePageObjects.rejectAuditReason_Textarea,
				getTestDataCellValue(scenarioName, "RejectReason"));
		agClick(CaseListingDeletePageObjects.rejectAuditReasonSubmit_Btn);
		Reports.ExtentReportLog("", Status.INFO, "Reject Audit Reason Popup is displayed", true);
	}
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to retriveDeleteCase.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Vamsi krishan RS
	 * @Date : 26-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void retriveDeleteCase(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (agIsVisible(CaseListingPageObjects.receiptNumberlink)) {
			agClick(CaseListingPageObjects.receiptNumberlink);
		}
		agSetStepExecutionDelay("3000");
		agClick(CaseListingDeletePageObjects.retriveButton);
		agSetValue(CaseListingDeletePageObjects.retriveReasonCodeTextarea,
				 getTestDataCellValue(scenarioName, "RetriveReason"));
		agClick(CaseListingDeletePageObjects.retriveConfirmButton);
		status = agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (status) {
			String validation = agGetText(CaseListingPageObjects.validationPopup);
			agAssertContainsText(CaseListingPageObjects.validationPopup, "retrieved successfully");
			Reports.ExtentReportLog("", Status.PASS, "<br />"+"Case is retrieved  successfully " + "<br />" +validation, true);

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "<br />"+"Case is not retrieved successfully", true);
		}
		agClick(FullDataEntryFormPageObjects.ActionOkBtn);

		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	/************************************
	* @Objective: The below method is created to set data in delete reason Popup.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 26-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void setCaselistingDeleteReason(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(CaseListingDeletePageObjects.clickCasedeleteReasonCodeDropdown);
		agClick(CaseListingDeletePageObjects.selectCasedeleteReasonCode(getTestDataCellValue(scenarioName, "DeleteReasonCode")));
		agSetValue(CaseListingDeletePageObjects.deleteCaseReason_Textarea,
				getTestDataCellValue(scenarioName, "DeleteReason"));
		agClick(CaseListingDeletePageObjects.deleteCaseReasonSubmit_Btn);
		Reports.ExtentReportLog("", Status.INFO, "Delete Audit Reason Popup is displayed", true);
		//CommonOperations.agwaitTillVisible(CaseListingDeletePageObjects.validationPopup);
		
		
	}
}