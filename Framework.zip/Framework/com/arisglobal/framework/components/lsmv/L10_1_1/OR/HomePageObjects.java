package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public abstract class HomePageObjects {
	
	public static String headerSettingBlock = "xpath#//div[@id='headerForm:settingsBlock']";    
    
}
