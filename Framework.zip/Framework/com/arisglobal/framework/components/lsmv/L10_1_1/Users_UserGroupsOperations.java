package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.UserGroupsPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Users_UserGroupsOperations extends ToolManager {
	public static WebElement webElement;
	static String className = Users_UserGroupsOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit and update user group.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateUserGroup(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(UserGroupsPageObjects.edit_Icon);
		createUserGroup(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify User group exist or not
	 *             based on Group name
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Boolean verifysearchData(String scenarioName) {
		Boolean falg = false;
		String paginator = agGetText(UserGroupsPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			List<WebElement> list = agGetElementList(UserGroupsPageObjects.get_UserGroups);
			String columnHeader = null;
			for (int j = 1; j <= list.size(); j++) {
				columnHeader = agGetText(UserGroupsPageObjects.columnHeaderList(Integer.toString(j)));
				if (getTestDataCellValue(scenarioName, "UserGroups").equalsIgnoreCase(columnHeader)) {
					falg = true;
					break;
				}
			}
		}
		return falg;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set User Group Details.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createUserGroup(String scenarioName) {
		agAssertVisible(UserGroupsPageObjects.userGroupNew_label);
		agSetValue(UserGroupsPageObjects.userGroup_TxtField, getTestDataCellValue(scenarioName, "UserGroups"));
		agSetValue(UserGroupsPageObjects.emailAddress_TxtField, getTestDataCellValue(scenarioName, "Email"));
		agSetValue(UserGroupsPageObjects.description_Txtarea, getTestDataCellValue(scenarioName, "Description"));
		agClick(UserGroupsPageObjects.clickGroupTypeDropdown);
		agSetStepExecutionDelay("1000");
		agClick(UserGroupsPageObjects.setGroupType(getTestDataCellValue(scenarioName, "GroupType")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Data entred in User Group Details", true);
		agClick(UserGroupsPageObjects.save_Btn);
		CommonOperations.setAuditInfo(scenarioName);
		agIsVisible(UserGroupsPageObjects.groupKeywordSearch);
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search User Group.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void search(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(UserGroupsPageObjects.groupKeywordSearch, getTestDataCellValue(scenarioName, "UserGroups"));
		agClick(UserGroupsPageObjects.search_Icon);
		agIsVisible(UserGroupsPageObjects.paginator);
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created search and User Group.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreateUserGroup(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		if (verifysearchData(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS, "User Group already exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "UserGroups"), UserGroupsPageObjects.get_UserGroups);
		} else {
			agClick(UserGroupsPageObjects.new_Btn);
			createUserGroup(scenarioName);
			search(scenarioName);
			verifyUserGroup(scenarioName);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify user group.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyUserGroup(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(UserGroupsPageObjects.edit_Icon);
		agIsVisible(UserGroupsPageObjects.userGroupNew_label);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "UserGroups"),
				UserGroupsPageObjects.userGroup_TxtField);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Email"),
				UserGroupsPageObjects.emailAddress_TxtField);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Description"),
				UserGroupsPageObjects.description_Txtarea);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "GroupType"), UserGroupsPageObjects.get_GroupType);
		Reports.ExtentReportLog("", Status.INFO, "Data verification in User Group Details", true);
		agClick(UserGroupsPageObjects.cancel_Btn);
		agIsVisible(UserGroupsPageObjects.groupKeywordSearch);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search for deleted user group.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchDeleteUserGroup(String scenarioName) {
		search(scenarioName);
		String paginator = agGetText(UserGroupsPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.FAIL, "Search for User Group: Deleted User Group is listed", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS, "Search for Deleted User Group: Deleted User Group is not listed",
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search user group.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchUserGroup(String scenarioName) {
		search(scenarioName);
		String paginator = agGetText(UserGroupsPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "UserGroups"), UserGroupsPageObjects.get_UserGroups);
			Reports.ExtentReportLog("", Status.PASS, "Search User Group: User Group Listed", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Search User Group: User Group Not Listed", true);
		}
		agClick(UserGroupsPageObjects.refresh_Icon);
		agIsVisible(UserGroupsPageObjects.groupKeywordSearch);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete User Group.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void delete(String scenarioName) {
		agClick(UserGroupsPageObjects.delete_Btn);
		CommonOperations.setDeleteAuditInfo(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete User Group.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteUserGroup(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		String paginator = agGetText(UserGroupsPageObjects.paginator);
		System.out.println(paginator);
		if (paginator != null && paginator.startsWith("1")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "UserGroups"), UserGroupsPageObjects.get_UserGroups);
			Reports.ExtentReportLog("", Status.PASS, "User Group Found", true);
			agClick(UserGroupsPageObjects.selectListingCheckbox(getTestDataCellValue(scenarioName, "UserGroups")));
			delete(scenarioName);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "User Group Not Found", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download User group export to
	 *             excel.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 15-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportToexcel(String FileName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(UserGroupsPageObjects.downloadIcon);
		agClick(UserGroupsPageObjects.exporttoExcel_link);
		if (agIsVisible(UserGroupsPageObjects.export_Btn) == true) {
			agClick(UserGroupsPageObjects.export_Btn);
			try {
				Thread.sleep(8000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			CommonOperations.move_Downloadedexcel(FileName);
			agClick(UserGroupsPageObjects.exportexcelcancel_Btn);
		} else {
			Reports.ExtentReportLog("Export to excel pop is not displayed", Status.INFO, "", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to compare record count with download
	 *             excel
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:Avinash K
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void recordCountVerification(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		String count = xls.getCellData("Group", 2, 4);
		String[] Totalcount = count.split(":");
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in exported excel::" + Totalcount[1].trim(),
				false);
		String applrecordcount = agGetText(UserGroupsPageObjects.paginator);
		String[] data = applrecordcount.split(" ");
		String recordCount = data[4];
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in application::" + recordCount, false);
		if (recordCount.equalsIgnoreCase(Totalcount[1].trim())) {
			Reports.ExtentReportLog("", Status.PASS, "Record count verification is successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Record count verification is Unsuccessfull", true);
		}
	}

}