package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FDEFormLinkCasesWindowPageObjects {
	public static String Linkreceiptno = "xpath#//input[@name='emailId1']";
	public static String looklabel = "xpath#//span[text()='AdverseEventLookup']";
	public static String link = "xpath#//a[text()='Link']";
	public static String receiptno = "xpath#//input[@name='receiptNumber']";
	public static String search = "xpath#//button/span[text()='Search']";
	public static String checkbox = "xpath#//td[@class='agproSelcetRad']//div[@class='ui-chkbox-box ui-widget ui-state-default']";
	public static String ok = "xpath#//div[@class='col-md-12 searchOkbtn tblserchbtn']//button/span[text()='OK']";
	public static String linkedReasonDropdownClick = "xpath#//label[text()='Linked Reason']/parent::div[@class='ui-dialog-content ui-widget-content']//p-dropdown/div";
	public static String selectDropDownValue = "xpath#//ul/li/div/span[contains(text(),'%s')]";
	public static String descriptionTextArea = "xpath#//textarea[@name='description']";
	public static String submitButton = "xpath#//div[@class='searchOkbtn']//span[text()='Submit']";
	public static String verifyRCPTNo_ReferredAECase = "xpath#//input[@id='adverseEventNew:linkedCasesDataTable:0:receiptNo_input']";
	public static String deLinkcase = "xpath#//input[@title='%s']/ancestor::tr/td/p-tablecheckbox/div//span";
	
	
	public static String deLinkcasesingle = "xpath#(//p-tablecheckbox//div/span)[1]";
	
	
	public static String deLinkbutton = "xpath#//a[@title='Delink']";
	public static String okbutton = "xpath#//form[@id='fdeAngularForm']/div/p-confirmdialog/div/div[3]/button//span[text()='Yes']";

	public static String linkLabel = "xpath#//*[@id='ui-panel-16']/div[1]/p-header/span/a[1]";
	public static String adverseEventlookTextfileds = "xpath#//label[contains(text(),'%s')]/following-sibling::input[contains(@id,'adverseEventlookupSearchForm')]";
	public static String searchButton = "xpath#//span[@class='ui-button-text ui-c'][contains(text(),'Search')]";
	public static String adverseEventlookupcheckBox = "xpath#//tbody[contains(@id,'adverseEventlookupSearchForm:adverseEventTable:adverseEventLookUpDataTableMulti_data')]/tr/td/div/child::div/span";
	public static String lookupOkButton = "xpath#//button[@id='adverseEventlookupSearchForm:bottomOkButton']//span[@class='ui-button-text ui-c'][contains(text(),'OK')]";
	public static String deLink = "xpath#//a[@id='linkedAEForm:deletereference']";
	public static String linkReasonVerification = "xpath#//tbody[@id='linkedAEForm:linkedDataTable_data']/tr/td/label[contains(@id,'linkedAEForm:linkedDataTable:0:j_id_7w')]";
	public static String closeLink = "xpath#//div[@id='linkedAEForm:linkedAEDialog']/div/a";
	public static String validationOkButton = "xpath#//button[@id='mandatoryDialogform:okButton']//span[@class='ui-button-text ui-c'][contains(text(),'OK')]";
	public static String validationPopup = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String deLinkCheckBox = "xpath#//tbody[@id='linkedAEForm:linkedDataTable_data']/tr/td/div/child::div/span";
	public static String delinkYesButton = "xpath#//div[@id='linkedAEForm:deleteLinkAEconfirm']/child::div/button/span[contains(text(),'Yes')]";
	public static String referredAECaseLabel = "xpath#//div[@id='linkedAEForm:linkReferredAEPanel_header']/span/div/label[text()='Referred AE Case(s)']";

	/**********************************************************************************************************
	 * Objective:The below method is created to set Data in AdverseEvent LookUp by
	 * passing label name at runtime. Input Parameters: ColumnName Scenario Name
	 * Output Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String setDataAdverseEventLookUp(String runTimeLabel) {
		String value = adverseEventlookTextfileds;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select linked Reason by passing
	 * value at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String selectlinkedReason(String runTimeLabel) {
		String value = selectDropDownValue;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to recptNo by passing recptNo at
	 * runtime. Input Parameters: ColumnName Scenario Name Output Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String recptNoVerify(String runTimeLabel) {
		String value = verifyRCPTNo_ReferredAECase;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to verify link reason by passing value
	 * at runtime. Input Parameters: ColumnName Scenario Name Output Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String linkReasonVerification(String runTimeLabel) {
		String value = linkReasonVerification;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String deLinkcase(String runTimeLabel) {
		String value = deLinkcase;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

}
