package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ReconciliationPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class ReconciliationOperations extends ToolManager {

	static String className = ReconciliationOperations.class.getSimpleName();
	public static WebElement webElement;
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to download Excel in case
	 *             Reconciliation window.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 14-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downloadExcel(String FileName) {

		agMouseHover(ReconciliationPageObjects.downloadIcon);
		agMouseHover(ReconciliationPageObjects.exportToexcelLink);
		agClick(ReconciliationPageObjects.exportToexcelLink);
		if (agIsVisible(ReconciliationPageObjects.exportToexcelBtn) == true) {
			agClick(ReconciliationPageObjects.exportToexcelBtn);
			CommonOperations.takeScreenShot();
			agSetStepExecutionDelay("5000");
			agMouseHover(ReconciliationPageObjects.exportToexcel_closeicon);
			agClick(ReconciliationPageObjects.exportToexcel_closeicon);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CommonOperations.move_Downloadedexcel(FileName);

		} else {
			Reports.ExtentReportLog("Export to excel pop is not displayed", Status.INFO, "", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is set values in reconcilation window
	 *             Reconciliation window.
	 * @InputParameters:scenarioname
	 * @OutputParameters:
	 * @author:rashmi
	 * @Date : 14-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void reconciliationSubmitUncheck(String scenarioName) {
		agSetStepExecutionDelay("3000");
		agWaitTillVisibilityOfElement(ReconciliationPageObjects.submit_Btn);
		if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
			agClick(ReconciliationPageObjects.showMore_link);
		}
		CommonOperations.takeScreenShot();
		if (scenarioName.contains("CaseSignificance15")) {
			// uncheckReconcilecheckbox("Medically Confirmed");
			// uncheckReconcilecheckbox("Seriousness");
			// uncheckReconcilecheckbox("Death?");
			// uncheckReconcilecheckbox("Primary Source for Regulatory Purposes");
			// uncheckReconcilecheckbox("Qualification");
			// uncheckReconcilecheckbox("Health professional");
			// uncheckReconcilecheckbox("Gender");
			// uncheckReconcilecheckbox("Autopsy Done?");
			// uncheckReconcilecheckbox("Manual");
			// uncheckReconcilecheckbox("Event Description");
			//
			// uncheckReconcilecheckbox("Product Flag");
			// uncheckReconcilecheckbox("Preferred Product Description");
			// uncheckReconcilecheckbox("WHO DD Code","5");
			// uncheckReconcilecheckbox("Action Taken With Drug");
			// uncheckReconcilecheckbox("Coding Class");
			// uncheckReconcilecheckbox("Indications (MedDRA PT Code)");
			// uncheckReconcilecheckbox("Additional Information","3");
			//

		} else {
			uncheckReconcilecheckbox("Patient ID");
			uncheckReconcilecheckbox("Gender");
			uncheckReconcilecheckbox("Event Description");
			uncheckReconcilecheckbox("Seriousness");
		}

		CommonOperations.takeScreenShot();
		unSelectBlankRecords(scenarioName);
		agClick(ReconciliationPageObjects.showmoreLink);
		agSetStepExecutionDelay("2000");
		CommonOperations.takeScreenShot();
		agClick(ReconciliationPageObjects.submit_Btn);
		Reports.ExtentReportLog("", Status.PASS, "Reconciled is Successfull:", true);
		agWaitTillInvisibilityOfElement(ReconciliationPageObjects.submit_Btn);
		agSetStepExecutionDelay("10000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (agIsVisible(ReconciliationPageObjects.validationOk_Btn) == true)
			agWaitTillVisibilityOfElement(ReconciliationPageObjects.validationOk_Btn);
		agJavaScriptExecuctorClick(ReconciliationPageObjects.validationOk_Btn);
	}

	public static void uncheckReconcilecheckbox(String labelname) {
		agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.Reconcilecheckbox(labelname));
		agClick(ReconciliationPageObjects.Reconcilecheckbox(labelname));

	}

	public static void uncheckReconcilecheckbox(String labelname, String div) {
		agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.Reconcilecheckbox(labelname, div));
		agClick(ReconciliationPageObjects.Reconcilecheckbox(labelname, div));

	}

	public static void reconciliationCreateNewVersion(String scenarioName) {
		agSetStepExecutionDelay("3000");
		agWaitTillVisibilityOfElement(ReconciliationPageObjects.submit_Btn);
		if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
			agClick(ReconciliationPageObjects.showMore_link);
		}
		agClick(ReconciliationPageObjects.showmoreLink);
		CommonOperations.takeScreenShot();
		if (scenarioName.contains("CaseSignificance15")) {
			// uncheckReconcilecheckbox("Medically Confirmed");
			// uncheckReconcilecheckbox("Seriousness");
			// uncheckReconcilecheckbox("Death?");
			// uncheckReconcilecheckbox("Primary Source for Regulatory Purposes");
			// uncheckReconcilecheckbox("Qualification");
			// uncheckReconcilecheckbox("Health professional");
			// uncheckReconcilecheckbox("Gender");
			// uncheckReconcilecheckbox("Autopsy Done?");
			// uncheckReconcilecheckbox("Manual");
			// uncheckReconcilecheckbox("Event Description");
			//
			// uncheckReconcilecheckbox("Product Flag");
			// uncheckReconcilecheckbox("Preferred Product Description");
			// uncheckReconcilecheckbox("WHO DD Code","5");
			// uncheckReconcilecheckbox("Action Taken With Drug");
			// uncheckReconcilecheckbox("Coding Class");
			// uncheckReconcilecheckbox("Indications (MedDRA PT Code)");
			// uncheckReconcilecheckbox("Additional Information","3");

		} else {
			uncheckReconcilecheckbox("Patient ID");
			uncheckReconcilecheckbox("Gender");
			uncheckReconcilecheckbox("Event Description");
			uncheckReconcilecheckbox("Seriousness");
		}

		CommonOperations.takeScreenShot();
		//
		unselectBlankRecordsInParent(scenarioName);

		// uncheckReconcilecheckbox("Product(s) # 2");

		agSetStepExecutionDelay("2000");
		CommonOperations.takeScreenShot();
		agClick(ReconciliationPageObjects.ParentCreateNewVersionbutton);
		Reports.ExtentReportLog("", Status.PASS, "Reconciled is Successfull:", true);
		agWaitTillInvisibilityOfElement(ReconciliationPageObjects.submit_Btn);
		agSetStepExecutionDelay("10000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (agIsVisible(ReconciliationPageObjects.validationOk_Btn) == true)
			agWaitTillVisibilityOfElement(ReconciliationPageObjects.validationOk_Btn);
		agJavaScriptExecuctorClick(ReconciliationPageObjects.validationOk_Btn);
	}

	public static void unselectBlankRecordsInParent(String scenarioName) {

		agClick(ReconciliationPageObjects.showmoreLink);
		agSetStepExecutionDelay("1000");
		agClick(ReconciliationPageObjects.hideCommonCheckbox);
		agSetStepExecutionDelay("2000");

		if (scenarioName.contains("CaseSignificance15")) {

			agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.ParentRejectRecordCheckbox("Therapies # 2"));
			agClick(ReconciliationPageObjects.ParentRejectRecordCheckbox("Therapies # 2"));
			// agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.ParentRejectRecordCheckbox("Approval
			// # 2"));
			// agClick(ReconciliationPageObjects.ParentRejectRecordCheckbox("Approval #
			// 2"));
			//

			// agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.ParentRejectRecordCheckbox("Event(s)
			// # 2"));
			// agClick(ReconciliationPageObjects.ParentRejectRecordCheckbox("Event(s) #
			// 2"));
			// agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.ParentRejectRecordCheckbox("Ingredients
			// # 5"));
			// agClick(ReconciliationPageObjects.ParentRejectRecordCheckbox("Ingredients #
			// 5"));

			//
			// agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.ParentRejectRecordCheckbox("Approval
			// # 2"));
			// agClick(ReconciliationPageObjects.ParentRejectRecordCheckbox("Approval #
			// 2"));
			//
			// agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.ParentRejectRecordCheckbox("Reported
			// Cause(s) of Death # 3"));
			// agClick(ReconciliationPageObjects.ParentRejectRecordCheckbox("Reported
			// Cause(s) of Death # 3"));

		} else {
			agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.ParentRejectRecordCheckbox("Event(s) # 2"));
			agClick(ReconciliationPageObjects.ParentRejectRecordCheckbox("Event(s) # 2"));
			agJavaScriptExecuctorScrollToElement(
					ReconciliationPageObjects.ParentRejectRecordCheckbox("Product(s) # 2"));
			agClick(ReconciliationPageObjects.ParentRejectRecordCheckbox("Product(s) # 2"));

		}

	}

	public static void unSelectBlankRecords(String scenarioName) {

		agClick(ReconciliationPageObjects.showmoreLink);
		agSetStepExecutionDelay("1000");
		agClick(ReconciliationPageObjects.hideCommonCheckbox);
		agSetStepExecutionDelay("2000");
		// agClick(ReconciliationPageObjects.showmoreLink);
		if (scenarioName.contains("CaseSignificance15")) {
			agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.ParentRejectRecordCheckbox("Therapies # 2"));
			agClick(ReconciliationPageObjects.ParentRejectRecordCheckbox("Therapies # 2"));
			// agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.ParentRejectRecordCheckbox("Approval
			// # 2"));
			// agClick(ReconciliationPageObjects.ParentRejectRecordCheckbox("Approval #
			// 2"));

			// agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.ParentRejectRecordCheckbox("Event(s)
			// # 2"));
			// agClick(ReconciliationPageObjects.ParentRejectRecordCheckbox("Event(s) #
			// 2"));
			// agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.ParentRejectRecordCheckbox("Ingredients
			// # 5"));
			// agClick(ReconciliationPageObjects.ParentRejectRecordCheckbox("Ingredients #
			// 5"));
			// agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.ParentRejectRecordCheckbox("Therapies
			// # 2"));
			// agClick(ReconciliationPageObjects.ParentRejectRecordCheckbox("Therapies #
			// 2"));
			//
			// agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.ParentRejectRecordCheckbox("Approval
			// # 2"));
			// agClick(ReconciliationPageObjects.ParentRejectRecordCheckbox("Approval #
			// 2"));
			//
			// agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.ParentRejectRecordCheckbox("Reported
			// Cause(s) of Death # 3"));
			// agClick(ReconciliationPageObjects.ParentRejectRecordCheckbox("Reported
			// Cause(s) of Death # 3"));
			//

		} else {
			agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.RejectRecordCheckbox("Event(s) # 2"));
			agClick(ReconciliationPageObjects.RejectRecordCheckbox("Event(s) # 2"));
			agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.RejectRecordCheckbox("Product(s) # 2"));
			agClick(ReconciliationPageObjects.RejectRecordCheckbox("Product(s) # 2"));
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify followup alert window
	 *             popup.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 23-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void followupAlertWindowVerify(String scenarioName) {
		agIsVisible(ReconciliationPageObjects.followupAlert_header);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// agAssertContainsText(ReconciliationPageObjects.followupAlert_Window,
		// getTestDataCellValue(scenarioName, "FollowupAlertMsg")
		// + FDE_General.getData(scenarioName, "ReceiptNo"));
		agSetStepExecutionDelay("10000");
		agAssertVisible(ReconciliationPageObjects.yes_Btn);
		agAssertVisible(ReconciliationPageObjects.no_Btn);
		String message = agGetText(ReconciliationPageObjects.followupAlert_Window);
		status = agIsVisible(ReconciliationPageObjects.followupAlert_Window);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Validation:" + message, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Followup Notification is Unsuccessfully", true);

		}
		agSetStepExecutionDelay("5000");
		agClick(ReconciliationPageObjects.yes_Btn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify reconcile alert window
	 *             popup.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 14-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void reconcileNotificationVerification(String scenarioName) {
		agSetStepExecutionDelay("8000");
		agWaitTillVisibilityOfElement(ReconciliationPageObjects.reconcileNotification_header);
		agIsVisible(ReconciliationPageObjects.reconcileNotification_header);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "reconcileNotificationMSG"),
				ReconciliationPageObjects.reconcileNotification_Window);
		String message = agGetText(ReconciliationPageObjects.reconcileNotification_Window);
		status = agIsVisible(ReconciliationPageObjects.reconcileNotification_Window);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Validation:" + message, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Reconcile Notification is Unsuccessfully", true);

		}
		agSetStepExecutionDelay("8000");
		if (agIsVisible(ReconciliationPageObjects.ReconsileYesBtn) == true) {
			agClick(ReconciliationPageObjects.ReconsileYesBtn);
		} else {

			agClick(ReconciliationPageObjects.ok_Btn);
			agWaitTillInvisibilityOfElement(ReconciliationPageObjects.loadingIcon);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify reconciliation Window
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 23-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void reconciliationWindowVerification() {
		agSetStepExecutionDelay("8000");

		status = agIsExists(ReconciliationPageObjects.reconciliation_Header);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Reconciliation Window is displayed", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Reconciliation Window is not displayed", true);
		}

		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		/*
		 * verify_HideCommonDataCheckBx(); verify_HighlightdiffCheckBx();
		 */ /* Updated by avinash- Status is not updating for check and uncheck */
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify reconciliation icon.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void reconciliationIconVerfication() {
		agSetStepExecutionDelay("2000");
		agIsVisible(ReconciliationPageObjects.reconciliationIcon);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(ReconciliationPageObjects.reconciliationIcon);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to submit the case.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void reconciliationSubmit(String scenarioName) {
		agClick(ReconciliationPageObjects.submit_Btn);
		agWaitTillInvisibilityOfElement(ReconciliationPageObjects.loadingIcon);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertContainsText(ReconciliationPageObjects.validationPopup,
				getTestDataCellValue(scenarioName, "Validationmessage"));
		agAssertContainsText(ReconciliationPageObjects.validationPopup,
				E2BMessageQueueOperations.getData(scenarioName, "ReceiptNo"));
		String message = agGetText(ReconciliationPageObjects.validationPopup);
		status = agIsVisible(ReconciliationPageObjects.validationPopup);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Validation:" + message, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Reconciled is Unsuccessfully", true);

		}
		if (agIsVisible(ReconciliationPageObjects.validationOk_Btn) == true) {
			agClick(ReconciliationPageObjects.validationOk_Btn);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to submit the case.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 02-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void EMAreconciliationSubmit(String scenarioName) {
		agSetStepExecutionDelay("2000");
		agClick(ReconciliationPageObjects.ReporterPrimarySource_Checkbox);
		agClick(ReconciliationPageObjects.ReporterTitle_Checkbox);
		agClick(ReconciliationPageObjects.ReporterFirstname_Checkbox);
		agClick(ReconciliationPageObjects.ReporterLastname_Checkbox);
		agClick(ReconciliationPageObjects.ReporterHospitalname_Checkbox);
		agClick(ReconciliationPageObjects.ReporterCity_Checkbox);
		agClick(ReconciliationPageObjects.ReporterCountry_Checkbox);
		agClick(ReconciliationPageObjects.ReporterQualification_Checkbox);
		agClick(ReconciliationPageObjects.showMore_link);
		CommonOperations.takeScreenShot();
		agClick(ReconciliationPageObjects.submit_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillInvisibilityOfElement(ReconciliationPageObjects.loadingIcon);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertContainsText(ReconciliationPageObjects.validationPopup,
				getTestDataCellValue(scenarioName, "Validationmessage"));
		agAssertContainsText(ReconciliationPageObjects.validationPopup,
				ImportOperations.getData(scenarioName, "ReceiptNo"));
		String message = agGetText(ReconciliationPageObjects.validationPopup);
		status = agIsVisible(ReconciliationPageObjects.validationPopup);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Validation:" + message, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Reconciled is Unsuccessfully", true);

		}
		agClick(ReconciliationPageObjects.validationOk_Btn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to submit the case.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 02-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void EMA1reconciliationSubmit(String scenarioName) {
		agSetStepExecutionDelay("2000");
		agClick(ReconciliationPageObjects.EventOutcome_Checkbox);
		agClick(ReconciliationPageObjects.EventSeriouness_Checkbox);
		agClick(ReconciliationPageObjects.EventProlongedHosp_Checkbox);
		agClick(ReconciliationPageObjects.showMore_link);
		CommonOperations.takeScreenShot();
		agClick(ReconciliationPageObjects.submit_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillInvisibilityOfElement(ReconciliationPageObjects.loadingIcon);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertContainsText(ReconciliationPageObjects.validationPopup,
				getTestDataCellValue(scenarioName, "Validationmessage"));
		agAssertContainsText(ReconciliationPageObjects.validationPopup,
				ImportOperations.getData(scenarioName, "ReceiptNo"));
		String message = agGetText(ReconciliationPageObjects.validationPopup);
		status = agIsVisible(ReconciliationPageObjects.validationPopup);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Validation:" + message, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Reconciled is Unsuccessfully", true);

		}
		agClick(ReconciliationPageObjects.validationOk_Btn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to submit the case.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Umar
	 * @Date : 07-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void reconciliationSubmitSimple(String scenarioName) {
		agSetStepExecutionDelay("3000");
		agWaitTillVisibilityOfElement(ReconciliationPageObjects.submit_Btn);
		if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
			agClick(ReconciliationPageObjects.showMore_link);
		}

		agSetStepExecutionDelay("3000");
		if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
			agClick(ReconciliationPageObjects.showMore_link);
		}
		agClick(ReconciliationPageObjects.submit_Btn);
		// agWaitTillVisibilityOfElement(ReconciliationPageObjects.validationPopup);
		//
		// String message = agGetText(ReconciliationPageObjects.validationPopup);
		// status = agIsVisible(ReconciliationPageObjects.validationPopup);
		// if (status) {
		// Reports.ExtentReportLog("", Status.PASS, "Validation:" + message, true);
		// } else {
		// Reports.ExtentReportLog("", Status.FAIL, "Reconciled is Unsuccessfully",
		// true);
		//
		// }
		Reports.ExtentReportLog("", Status.PASS, "Reconciled is Successfull:", true);
		agWaitTillInvisibilityOfElement(ReconciliationPageObjects.submit_Btn);
		agWaitTillInvisibilityOfElement(ReconciliationPageObjects.loading);
		agSetStepExecutionDelay("5000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (agIsVisible(ReconciliationPageObjects.validationOk_Btn) == true)
			agWaitTillVisibilityOfElement(ReconciliationPageObjects.validationOk_Btn);
		agJavaScriptExecuctorClick(ReconciliationPageObjects.validationOk_Btn);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Hide common Data checkbox
	 *             is selected in compare window.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 23-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_HideCommonDataCheckBx() {
		String value = agGetAttribute("class",
				ReconciliationPageObjects.reconcilitionCheckBox(ReconciliationPageObjects.hidecommonData_Checkbox));
		if (value.contains("ui-state-active")) {
			Reports.ExtentReportLog("", Status.PASS, "Hide common Data CheckBox is selected", false);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Hide commonData CheckBox is not selected", true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Highlight differences
	 *             checkbox is selected in compare window.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 23-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_HighlightdiffCheckBx() {
		String value = agGetAttribute("class",
				ReconciliationPageObjects.reconcilitionCheckBox(ReconciliationPageObjects.highlightdif_Checkbox));
		if (value.contains("ui-state-active")) {
			Reports.ExtentReportLog("", Status.PASS, "Highlight differences checkbox is selected", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Highlight differences checkbox is not selected", true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Append to Existing verification
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 23-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void appendtoExistingVerification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Reports.ExtentReportLog("", Status.INFO, "Append to Existing", true);
		agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.showMore_link);
		agClick(ReconciliationPageObjects.showMore_link);
		agClick(ReconciliationPageObjects.appendtoExisting_Btn);
		agWaitTillInvisibilityOfElement(ReconciliationPageObjects.appendtoExisting_Loadingicon);
		agSetStepExecutionDelay("8000");
		FDE_Operations.LSMVSaveReconsile();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		/*
		 * agAssertContainsText(CommonPageObjects.validationPopup,
		 * getTestDataCellValue(scenarioName, "Validationmessage"));
		 * agSetStepExecutionDelay(String.valueOf(Constants.
		 * defaultGlobalStepExecutionDelay)); String message =
		 * agGetText(CommonPageObjects.validationPopup); status =
		 * agIsVisible(CommonPageObjects.validationPopup); if (status) {
		 * Reports.ExtentReportLog("", Status.PASS, "Validation:" + message, true); }
		 * else { Reports.ExtentReportLog("", Status.FAIL,
		 * "Append to Existing is Unsuccessfully", true);
		 * 
		 * } //agClick(ReconciliationPageObjects.validationOk_Btn);
		 */ }

	/**********************************************************************************************************
	 * @Objective: The below method is created to Append to Existing verification
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createNewVerification(String scenarioName, String SheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(ReconciliationPageObjects.createNewVersion_Btn);
		agWaitTillInvisibilityOfElement(ReconciliationPageObjects.appendtoExisting_Loadingicon);
		agSetStepExecutionDelay("8000");
		agAssertContainsText(ReconciliationPageObjects.validationPopup,
				getTestDataCellValue(scenarioName, "Validationmessage"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		String message = agGetText(ReconciliationPageObjects.validationPopup);
		status = agIsVisible(ReconciliationPageObjects.validationPopup);
		CommonOperations.write_CreateNewVersionRCTNo(scenarioName, SheetName);
		CommonOperations.write_AERNoVersion(scenarioName, SheetName);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Validation:" + message, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Create New Version is Unsuccessfull", true);

		}
		agClick(ReconciliationPageObjects.validationOk_Btn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Create New Version
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 22-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createNewVersion() {
		Reports.ExtentReportLog("", Status.INFO, "Create New Version Started", true);
		try {

			agSetStepExecutionDelay("3000");
			// agIsVisible(ReconciliationPageObjects.followupAlert_header);
			agWaitTillVisibilityOfElement(ReconciliationPageObjects.followupAlert_header);
			agClick(ReconciliationPageObjects.yes_Btn);

			agSetStepExecutionDelay("8000");
			if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
				agJavaScriptExecuctorClick(ReconciliationPageObjects.showMore_link);
			}
			agWaitTillVisibilityOfElement(ReconciliationPageObjects.createNewVersionBtn);
			Actions actions = new Actions(driver);
			WebElement element = driver.findElement(By.xpath(
					"//div[@id='compareReconcileDialogModel']/div//button[@class='createNewVersionClass i18n' and contains(text(),'Create New Version')]"));
			agSetStepExecutionDelay("2000");
			actions.doubleClick(element).perform();

			// agClick(ReconciliationPageObjects.createNewVersionBtn);
			Reports.ExtentReportLog("", Status.INFO, "Create New Version", true);
			agWaitTillInvisibilityOfElement(ReconciliationPageObjects.createNewVersionBtn);
			agWaitTillVisibilityOfElement(ReconciliationPageObjects.validationOk_Btn);
			agSetStepExecutionDelay("5000");
			agJavaScriptExecuctorClick(ReconciliationPageObjects.validationOk_Btn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} catch (Exception e) {
			e.printStackTrace();
		}
		Reports.ExtentReportLog("", Status.INFO, "Create New Version Completed", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Submit Reconcilation with changes
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 17-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void reconciliationSubmitWithChanges(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Reconsilation Submit Started", true);
		agSetStepExecutionDelay("3000");
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agWaitTillVisibilityOfElement(ReconciliationPageObjects.submit_Btn);
			if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
				agClick(ReconciliationPageObjects.showMore_link);
			}
			if (getTestDataCellValue(scenarioName, "AlwaysSerious").equalsIgnoreCase("No"))
				agClick(ReconciliationPageObjects.alwaysSeriousChkBox);
			agClick(ReconciliationPageObjects.submit_Btn);

			// agWaitTillVisibilityOfElement(ReconciliationPageObjects.validationPopup);

			// String message = agGetText(ReconciliationPageObjects.validationPopup);
			// status = agIsVisible(ReconciliationPageObjects.validationPopup);
			// if (status) {
			// Reports.ExtentReportLog("", Status.PASS, "Validation:" + message, true);
			// } else {
			// Reports.ExtentReportLog("", Status.FAIL, "Reconciled is Unsuccessfully",
			// true);
			//
			// }
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			// agWaitTillVisibilityOfElement(ReconciliationPageObjects.validationOk_Btn);
			// agJavaScriptExecuctorClick(ReconciliationPageObjects.validationOk_Btn);

			Reports.ExtentReportLog("", Status.PASS, "Reconciled is Successfull:", true);
			agWaitTillInvisibilityOfElement(ReconciliationPageObjects.submit_Btn);
			agSetStepExecutionDelay("5000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} catch (Exception ex) {
			Reports.ExtentReportLog("", Status.FAIL, "Reconsilation Submit Failed", true);
			if (agIsVisible(ReconciliationPageObjects.click_cancel)) {
				agClick(ReconciliationPageObjects.click_cancel);
			}
		}
		Reports.ExtentReportLog("", Status.INFO, "Reconsilation Submit Completed", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to handle follow up alert window
	 *             popup.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Kishore k R
	 * @Date : 19-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void followupAlertWindowHandle(String scenarioName) {
		agIsVisible(ReconciliationPageObjects.followupAlert_header);
		getTestData(lsmvConstants.LSMV_testData, className);
		agAssertContainsText(ReconciliationPageObjects.followupAlert_Window,
				getTestDataCellValue(scenarioName, "FollowupAlertMsg")
						+ FDE_General.getData(scenarioName, "ReceiptNo"));
		// agAssertVisible(ReconciliationPageObjects.yes_Btn);
		String message = agGetText(ReconciliationPageObjects.followupAlert_Window);
		status = agIsVisible(ReconciliationPageObjects.followupAlert_Window);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "AER opened with FollowUp Notification:" + message, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Followup Notification is Unsuccessfully", true);

		}
		getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "FollowupAlertYesOrNo").equalsIgnoreCase("No")) {
			agClick(ReconciliationPageObjects.no_Btn);
			CommonOperations.incremAlmStepNo("True", "Pass", "Clicked on No and AER is opened", true);
		} else {
			agClick(ReconciliationPageObjects.yes_Btn);
			CommonOperations.incremAlmStepNo("True", "Pass", "Clicked on Yes and Reconcilation is opened", true);
			agSetStepExecutionDelay("3000");
			agWaitTillVisibilityOfElement(ReconciliationPageObjects.submit_Btn);
			if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
				agClick(ReconciliationPageObjects.showMore_link);
			}
			agClick(ReconciliationPageObjects.submit_Btn);
			agWaitTillInvisibilityOfElement(ReconciliationPageObjects.submit_Btn);
			String message2 = agGetText(ReconciliationPageObjects.validationPopup);
			status = agIsVisible(ReconciliationPageObjects.validationPopup);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Reconciliation is Successfull:" + message2, true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Reconciliation is Unsuccessfull", true);

			}

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to handle follow up alert window
	 *             popup.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Kishore k R
	 * @Date : 19-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createNewVersionFollwUpIcon(String scenarioName) {
		try {

			agSetStepExecutionDelay("3000");
			// agIsVisible(ReconciliationPageObjects.followupAlert_header);
			agJavaScriptExecuctorClick(ReconciliationPageObjects.followUpIcon);
			CommonOperations.incremAlmStepNo("True", "Pass", "Reconcilation box is opened", true);
			agSetStepExecutionDelay("3000");
			if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
				agJavaScriptExecuctorClick(ReconciliationPageObjects.showMore_link);
			}
			CommonOperations.incremAlmStepNo();
			// verify_HideCommonDataCheckBx();
			CommonOperations.incremAlmStepNo("True", "Pass", "Uncommon data of followup case is selected", true);
			agWaitTillVisibilityOfElement(ReconciliationPageObjects.createNewVersionBtn);
			Actions actions = new Actions(driver);
			WebElement element = driver.findElement(By.xpath(
					"//div[@id='compareReconcileDialogModel']//div//button[contains(@class,'createNewVersionClass') and contains(text(),'Create New Version')]"));
			actions.doubleClick(element).perform();

			// agClick(ReconciliationPageObjects.createNewVersionBtn);

			agWaitTillInvisibilityOfElement(ReconciliationPageObjects.appendtoExisting_Loadingicon);
			// getTestData(lsmvConstants.LSMV_testData, className);
			// agSetStepExecutionDelay("8000");
			// agAssertContainsText(ReconciliationPageObjects.validationPopup,getTestDataCellValue(scenarioName,
			// "Validationmessage"));
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			String message = agGetText(ReconciliationPageObjects.validationMsg);
			status = agIsVisible(ReconciliationPageObjects.validationMsg);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Create New Version Successfull:" + message, true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Create New Version is Unsuccessfull", true);

			}
			// agClick(ReconciliationPageObjects.validationOk_Btn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} catch (Exception e) {
			e.printStackTrace();
		}
		Reports.ExtentReportLog("", Status.INFO, "Create New Version Completed", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to handle reconcilation alert window
	 *             popup.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Kishore k R
	 * @Date : 9-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void reconcileSubmitHandle(String scenarioName) {

		agWaitTillVisibilityOfElement(ReconciliationPageObjects.reconcileNotification_header);
		agIsVisible(ReconciliationPageObjects.reconcileNotification_header);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "reconcileNotificationMSG"),
				ReconciliationPageObjects.reconcileNotification_Window);
		String message = agGetText(ReconciliationPageObjects.reconcileNotification_Window);
		status = agIsVisible(ReconciliationPageObjects.reconcileNotification_Window);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Reconcilation Notification:" + message, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Reconcile Notification is Unsuccessfully", true);

		}
		agSetStepExecutionDelay("5000");
		if (getTestDataCellValue(scenarioName, "ReconcileAlertYesOrNo").equalsIgnoreCase("No")) {
			agClick(ReconciliationPageObjects.noR_Btn);
			CommonOperations.incremAlmStepNo("True", "Pass", "Clicked on No and AER is opened in readonly mode", true);
		} else {
			agClick(ReconciliationPageObjects.yesR_Btn);
			CommonOperations.incremAlmStepNo("True", "Pass", "Clicked on Yes and Reconcilation window is opened", true);
			agSetStepExecutionDelay("3000");
			agWaitTillVisibilityOfElement(ReconciliationPageObjects.submit_Btn);
			if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
				agClick(ReconciliationPageObjects.showMore_link);
			}
			CommonOperations.incremAlmStepNo("True", "Pass", "Uncommon data of followup case is selected", true);
			agClick(ReconciliationPageObjects.submit_Btn);
			agWaitTillInvisibilityOfElement(ReconciliationPageObjects.submit_Btn);
			String message2 = agGetText(ReconciliationPageObjects.validationMsg);
			status = agIsVisible(ReconciliationPageObjects.validationMsg);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Reconciliation is Successfull:" + message2, true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Reconciliation is Unsuccessfull", true);

			}

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click on reject record for
	 *             specific
	 *             scenario(LSMV_OQ_CaseSignificance_AutoDerivation_Scenario4)
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 23-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void casesignificentAutoDerivationScenario4RejectRecord(String scenarioName) {
		agSetStepExecutionDelay("8000");
		agWaitTillVisibilityOfElement(ReconciliationPageObjects.submit_Btn);
		if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
			agClick(ReconciliationPageObjects.showMore_link);
		}
		if (scenarioName.equalsIgnoreCase("LSMV_CaseSignificance_AutoDerivation_Scenario4_C2")) {
			agSetStepExecutionDelay("2000");
			agClick(ReconciliationPageObjects.rejectRecord1);
			agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.rejectRecord2);
			agClick(ReconciliationPageObjects.rejectRecord2);
			agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.rejectRecord3);
			agClick(ReconciliationPageObjects.rejectRecord3);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} else {
			agSetStepExecutionDelay("2000");
			agClick(ReconciliationPageObjects.rejectRecord2_1);
			agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.rejectRecord1);
			agClick(ReconciliationPageObjects.rejectRecord1);
			// agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.rejectRecord2_3);
			// agClick(ReconciliationPageObjects.rejectRecord2_3);
			agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.rejectRecord2_4);
			agClick(ReconciliationPageObjects.rejectRecord2_4);
			agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.rejectRecord3);
			agClick(ReconciliationPageObjects.rejectRecord3);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click on reject record for
	 *             specific
	 *             scenario(LSMV_OQ_CaseSignificance_AutoDerivation_Scenario3)
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 23-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void casesignificentAutoDerivationScenario3RejectRecord() {
		agSetStepExecutionDelay("8000");
		agWaitTillVisibilityOfElement(ReconciliationPageObjects.submit_Btn);
		if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
			agClick(ReconciliationPageObjects.showMore_link);
		}
		agSetStepExecutionDelay("2000");
		agClick(ReconciliationPageObjects.rejectRecord_study);
		agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.rejectRecord_therapies);
		agClick(ReconciliationPageObjects.rejectRecord_therapies);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Rejecting incorect records", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Create New Version of a Followup
	 *             case
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 25-May-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createNewVersionByManipulating(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Create New Version Started", true);
		try {

			agSetStepExecutionDelay("3000");
			// agIsVisible(ReconciliationPageObjects.followupAlert_header);
			agWaitTillVisibilityOfElement(ReconciliationPageObjects.followupAlert_header);
			agClick(ReconciliationPageObjects.yes_Btn);

			agSetStepExecutionDelay("6000");
			if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
				agJavaScriptExecuctorClick(ReconciliationPageObjects.showMore_link);
			}

			if (scenarioName.toLowerCase().contains(("LSMV_CaseSignificance_scenario7").toLowerCase())
					|| scenarioName.toLowerCase().contains(("LSMV_CaseSignificance_scenario18").toLowerCase())) {
				ReconciliationOperations.casesignificentAutoDerivationScenario3RejectRecord();
			}

			agWaitTillVisibilityOfElement(ReconciliationPageObjects.createNewVersionBtn);
			Actions actions = new Actions(driver);
			WebElement element = driver.findElement(By.xpath(
					"//div[@id='compareReconcileDialogModel']/div//button[@class='createNewVersionClass i18n' and contains(text(),'Create New Version')]"));
			actions.doubleClick(element).perform();

			// agClick(ReconciliationPageObjects.createNewVersionBtn);
			Reports.ExtentReportLog("", Status.INFO, "Create New Version", true);
			agWaitTillInvisibilityOfElement(ReconciliationPageObjects.createNewVersionBtn);
			agWaitTillVisibilityOfElement(ReconciliationPageObjects.validationOk_Btn);
			agSetStepExecutionDelay("5000");
			agJavaScriptExecuctorClick(ReconciliationPageObjects.validationOk_Btn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} catch (Exception e) {
			e.printStackTrace();
		}
		Reports.ExtentReportLog("", Status.INFO, "Create New Version Completed", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click on reject record for
	 *             specific scenario
	 *             LSMV_OQ_CaseSignificance_AutoDerivation_Scenario10
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 24-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void casesignificentAutoDerivationScenarioRejectRecordTherapies(String scenarioName,
			String SheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, SheetName);
		agSetStepExecutionDelay("8000");
		agWaitTillVisibilityOfElement(ReconciliationPageObjects.submit_Btn);
		if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
			agClick(ReconciliationPageObjects.showMore_link);
		}
		agSetStepExecutionDelay("2000");
		agClick(ReconciliationPageObjects.therapyRecordProd(
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName")));
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click on reject record for
	 *             specific
	 *             scenario(LSMV_OQ_CaseSignificance_AutoDerivation_Scenario09 )
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 24-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void casesignificentAutoDerivationScenario09RejectRecordData() {
		agSetStepExecutionDelay("8000");
		agWaitTillVisibilityOfElement(ReconciliationPageObjects.submit_Btn);
		if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
			agClick(ReconciliationPageObjects.showMore_link);
		}
		agSetStepExecutionDelay("2000");
		// agClick(ReconciliationPageObjects.prodcheckbox);
		// 2nd therapy record
		agClick(ReconciliationPageObjects.rejectRecord_therapies);
		agClick(ReconciliationPageObjects.ingredientsChecbox);
		// 4th therapy record
		agClick(ReconciliationPageObjects.secTherapyReject);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to handle follow up alert window and
	 *             proceed with Append To Existing option.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Abhisek Ghosh
	 * @Date : 30-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void followupAlert_appendToExisting() {

		Reports.ExtentReportLog("", Status.INFO, "Follow Up Alert to Append To Existing Started", true);
		agSetStepExecutionDelay("3000");
		agWaitTillVisibilityOfElement(ReconciliationPageObjects.followupAlert_header);
		agIsVisible(ReconciliationPageObjects.followupAlert_header);
		agClick(ReconciliationPageObjects.yes_Btn);

		agWaitTillVisibilityOfElement(ReconciliationPageObjects.appendtoExisting_Btn);

		if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
			agJavaScriptExecuctorClick(ReconciliationPageObjects.showMore_link);
		}
		agSetStepExecutionDelay("3000");
		if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
			agJavaScriptExecuctorClick(ReconciliationPageObjects.showMore_link);
		}
		Reports.ExtentReportLog("", Status.INFO, "Append To Existing Clicked", true);
		agClick(ReconciliationPageObjects.appendtoExisting_Btn);
		agWaitTillInvisibilityOfElement(ReconciliationPageObjects.appendtoExisting_Btn);

	}

	/**********************************************************************************************************
	 * @Objective:Handling reconcilation window option.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Chithuraj R
	 * @Date : 30-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void reconciliationSubmitWithMatchingCases_Case12(String scenarioName, int i) {

		Reports.ExtentReportLog("", Status.INFO, "Reconsilation Submit Started", true);
		agSetStepExecutionDelay("3000");
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agWaitTillVisibilityOfElement(ReconciliationPageObjects.submit_Btn);

			if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
				agClick(ReconciliationPageObjects.showMore_link);
			}

			if (i == 1) {
				// agClick(ReconciliationPageObjects.nullificationcheckBox);
				agClick(ReconciliationPageObjects.safetyReportIdCheckBox);
				agJavaScriptExecuctorMouseHover(ReconciliationPageObjects.therapycheckBox);
				agJavaScriptExecuctorClick(ReconciliationPageObjects.therapycheckBox);
			} else {
				agClick(ReconciliationPageObjects.safetyReportIdCheckBox);
				agClick(ReconciliationPageObjects.approval1);
				agClick(ReconciliationPageObjects.approval2);
				agJavaScriptExecuctorMouseHover(ReconciliationPageObjects.therapycheckBox);
				agJavaScriptExecuctorClick(ReconciliationPageObjects.therapycheckBox);
			}
			Reports.ExtentReportLog("", Status.PASS, "Reconciled is Successfull:", true);
			agClick(ReconciliationPageObjects.submit_Btn);
			agSetStepExecutionDelay("5000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} catch (Exception ex) {
			Reports.ExtentReportLog("", Status.FAIL, "Reconsilation Submit Failed", true);
			if (agIsVisible(ReconciliationPageObjects.click_cancel)) {
				agClick(ReconciliationPageObjects.click_cancel);
			}
		}
		Reports.ExtentReportLog("", Status.INFO, "Reconsilation Submit Completed", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click on reject record for
	 *             specific
	 *             scenario(LSMV_OQ_CaseSignificance_AutoDerivation_Scenario14)
	 *             Therapies and LotNo
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Abhilash M U
	 * @Date : 30-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void casesignificentAutoDerivationScenario14RejectRecordTherapies_LotNo() {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, SheetName);
		agSetStepExecutionDelay("8000");
		agWaitTillVisibilityOfElement(ReconciliationPageObjects.submit_Btn);
		if (agIsVisible(ReconciliationPageObjects.showMore_link) == true) {
			agClick(ReconciliationPageObjects.showMore_link);
		}
		agSetStepExecutionDelay("8000");
		agJavaScriptExecuctorScrollToElement(ReconciliationPageObjects.therapyRejectRecd);
		agJavaScriptExecuctorClick(ReconciliationPageObjects.therapyRejectRecd);
		agJavaScriptExecuctorClick(ReconciliationPageObjects.RejectRecdLotno);

		if (agIsVisible(ReconciliationPageObjects.RejectEventDesc) == true) {
			agJavaScriptExecuctorClick(ReconciliationPageObjects.RejectEventDesc);
		}
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
}
