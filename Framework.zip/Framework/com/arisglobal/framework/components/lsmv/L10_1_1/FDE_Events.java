package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.arisglobal.framework.components.lsmv.L10_1_1.CommonOperations;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AppParameters_CaseManagementPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_EventsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_MedraLookUpPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_PatientPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_ProductsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_SourcePageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_StudyPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.Lib_AlwaysSeriousEvent_PageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.Lib_IMEDME_PageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.WorkFlowPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_Events extends ToolManager {
	static String className = FDE_Events.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	static boolean statusSerious;
	static String[] skipData={"#skip#"};

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: scenarioName, columnName, label
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_EventsPageObjects.click_DropDown(label));
			agClick(FDE_EventsPageObjects.setdropDownValue(getTestDataCellValue(scenarioName, columnName)));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to close existing term popup from the
	 *             application
	 * @InputParameters: label
	 * @OutputParameters:NA
	 * @author: Avinash k
	 * @Date : 10-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void closeExistingTermPopup() {
		agSetStepExecutionDelay("3000");
		if (agIsVisible(FDE_EventsPageObjects.existingTermconformationPopup) == true) {
			agClick(FDE_EventsPageObjects.existingTermconformationPopup_OkBtn);
		}

		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown in meddra lookup
	 * @InputParameters: scenarioName, columnName, label
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDownValue_MedDRAlookup(String label, String scenarioName, String columnName) {
		agClick(FDE_MedraLookUpPageObjects.clickDropDown(label));
		agClick(FDE_MedraLookUpPageObjects.SetdropDownValue(getTestDataCellValue(scenarioName, columnName)));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in text field value
	 * @InputParameters: scenarioName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyData(String object, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(object);
			agCheckPropertyValue("title", getTestDataCellValue(scenarioName, columnName), object);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Event MedDRA LLT Code in event
	 *             tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_EventMedDRALLTCode(String scenarioName) {
		if (getTestDataCellValue(scenarioName, "Events_EventInformation_EventMedDRALLTCodeLookup")
				.equalsIgnoreCase("Yes")) {
			agClick(FDE_EventsPageObjects.eventMedDRALLTCode_Lookup);

			if (agIsVisible(FDE_MedraLookUpPageObjects.MedraLanguagePopUpClick) == true) {
				agClick(FDE_MedraLookUpPageObjects.MedraLanguagePopUpClick);
				agClick(FDE_MedraLookUpPageObjects.MeraLanguageDropdownValue);
			}

			agIsVisible(FDE_MedraLookUpPageObjects.searchTerm_Textfields);
			agSetValue(FDE_MedraLookUpPageObjects.searchTerm_Textfields,
					getTestDataCellValue(scenarioName, "Events_EventInformation_EventMedDRALLTCode_SearchTerm"));
			// agSetValue(FDE_MedraLookUpPageObjects.dictionaryCode_Textfields,
			// getTestDataCellValue(scenarioName, "DictionaryCode"));
			// setDropDownValue_MedDRAlookup(FDE_MedraLookUpPageObjects.level_DropDown,
			// scenarioName, "Level");
			agClick(FDE_MedraLookUpPageObjects.search_Button);
			agSetStepExecutionDelay("5000");
			CommonOperations.takeScreenShot();
			agClick(FDE_MedraLookUpPageObjects.ok_Button);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (agIsVisible(FDE_MedraLookUpPageObjects.yesButton))
				agClick(FDE_MedraLookUpPageObjects.yesButton);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Event Information fields in
	 *             event tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_EventInformation_Data(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agJavaScriptExecuctorClick(FDE_EventsPageObjects.eventInfo_Label);
		agSetStepExecutionDelay("3000");
		agSetValue(FDE_EventsPageObjects.reportedTerm_Textfield,
				getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		agSetStepExecutionDelay("8000");
		agSendKeyStroke(Keys.TAB);
		CommonOperations.captureScreenShot(true);
		set_EventMedDRALLTCode(scenarioName);
		agSetStepExecutionDelay("3000");
		if (getTestDataCellValue(scenarioName, "Events_EventInformation_OnsetDate_NF")
				.equalsIgnoreCase("Yes")) {
			agClick(FDE_EventsPageObjects.eventDateAsNullButton("Onset date"));
			setNullFlavourDropDownValue(FDE_EventsPageObjects.onsetDate_Date, scenarioName, "Events_EventInformation_OnsetDate");

		}
		else {
			if (getTestDataCellValue(scenarioName, "CustomDateFlag").equalsIgnoreCase("YES")) {
				agSetValue(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date),
						getTestDataCellValue(scenarioName, "Events_EventInformation_OnsetDate"));
				CommonOperations.captureScreenShot(true);
			} else {
				agSetValue(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date), CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Events_EventInformation_OnsetDate")));
			}
		}
	
	
		if (getTestDataCellValue(scenarioName, "Events_EventInformation_CessationDate_NF")
				.equalsIgnoreCase("Yes")) {
			agClick(FDE_EventsPageObjects.eventDateAsNullButton("Cessation date"));
			setNullFlavourDropDownValue(FDE_EventsPageObjects.cessationdate_Date, scenarioName, "Events_EventInformation_CessationDate");
		}
		else {
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.cessationdate_Date), CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Events_EventInformation_CessationDate")));
		
		}
		setDropDownValue(FDE_EventsPageObjects.eventType_DropDown, scenarioName, "Events_EventInformation_EventType");
		setDropDownValue(FDE_EventsPageObjects.severity_DropDown, scenarioName, "Events_EventInformation_Severity");
		setDropDownValue(FDE_EventsPageObjects.outCome_DropDown, scenarioName, "Events_EventInformation_Outcome");
		status = agIsVisible(FDE_EventsPageObjects.eventOutcomeValue);
		if (status) {
			CommonOperations.captureScreenShot(true);
		}
		if(getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}
		agSetValue(FDE_EventsPageObjects.setData_Textfields(FDE_EventsPageObjects.reportedTermLanguage_Textbox),
				getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTermInNativeLanguage"));
		setDropDownValue(FDE_EventsPageObjects.nativeLanguage_DropDown, scenarioName,
				"Events_EventInformation_NativeLanguage");
		setDropDownValue(FDE_EventsPageObjects.countryDetection_DropDown, scenarioName,
				"Events_EventInformation_CountryOfDetection");
		if (getTestDataCellValue(scenarioName, "Events_EventInformation_Duration_Manual").equalsIgnoreCase("Check")) {
			agClick(FDE_EventsPageObjects.durationManual_Checkbox);
			agSetStepExecutionDelay("4000");
			agSetValue(FDE_EventsPageObjects.setData_Textfields(FDE_EventsPageObjects.duration_Textbox),
					getTestDataCellValue(scenarioName, "Events_EventInformation_Duration"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			setDropDownValue(FDE_EventsPageObjects.duration_Textbox, scenarioName,
					"Events_EventInformation_DurationUnit");
		}
		setDropDownValue(FDE_EventsPageObjects.termHighlighted_DropDown, scenarioName,
				"Events_EventInformation_TermHighlighted");
		agClick(FDE_EventsPageObjects.causedByDrugInteraction_Radiobtn(
				getTestDataCellValue(scenarioName, "Events_EventInformation_CausedByDrugInteraction")));
		agClick(FDE_EventsPageObjects.causedByLackOfEffect_Radiobtn(
				getTestDataCellValue(scenarioName, "Events_EventInformation_CausedByLackOfEffect")));
		// setDropDownValue(FDE_EventsPageObjects.severity_DropDown, scenarioName,
		// "Events_EventInformation_Severity");
		// agSetStepExecutionDelay("5000");
		// CommonOperations.captureScreenShot(true);
		agClick(FDE_EventsPageObjects.medicallyConfirmed_Radiobtn(
				getTestDataCellValue(scenarioName, "Events_EventInformation_MedicallyConfirmed")));
		agSetValue(FDE_EventsPageObjects.setData_Textfields(FDE_EventsPageObjects.AEInformation_Textbox),
				getTestDataCellValue(scenarioName, "Events_EventInformation_AEAdditionalInformation"));
		String[] ColumnName = {"Events_EventInformation_ReportedTerm", "Events_EventInformation_OnsetDate", "Events_EventInformation_Outcome"};
		String[] ColumnTitles = {FDE_EventsPageObjects.reportedTerm_Textbox, FDE_EventsPageObjects.onsetDate_Date, FDE_EventsPageObjects.outCome_DropDown};
		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, skipData);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Event >> Event Information Section : Scenario Name::" + scenarioName, false);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add multiple Event Information in
	 *             event tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void add_MultipleEventInformation(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Event_MultipleData").equalsIgnoreCase("True")) {
			agClick(FDE_EventsPageObjects.eventsAdd_Button);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Event Seriousness in event tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_EventSeriousness(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(FDE_EventsPageObjects.eventSerious_Label);
		agJavaScriptExecuctorClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.seriousness_Radiobtn,
				getTestDataCellValue(scenarioName, "Events_EventSeriousness_Seriousness")));
		agClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.death_Radiobtn,
				getTestDataCellValue(scenarioName, "Events_EventSeriousness_Death")));
		agClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.lifeThreatening_Radiobtn,
				getTestDataCellValue(scenarioName, "Events_EventSeriousness_LifeThreatening")));
		if(getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}
		agClick(FDE_EventsPageObjects.select_RadioButtons(
				FDE_EventsPageObjects.caused_prolongedhospitalization_Radiobtn,
				getTestDataCellValue(scenarioName, "Events_EventSeriousness_CausedProlongedHospitalization")));
		agClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.disability_PermanentDamage_Radiobtn,
				getTestDataCellValue(scenarioName, "Events_EventSeriousness_DisabilityPermanentDamage")));
		agClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.congenitalAnomalyBirthDefect_Radiobtn,
				getTestDataCellValue(scenarioName, "Events_EventSeriousness_CongenitalAnomalyBirthDefect")));
		agClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.OtherMedicallyCondition_Radiobtn,
				getTestDataCellValue(scenarioName, "Events_EventSeriousness_OtherMedicallyImportantCondition")));
		agClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.requiredIntervenation_Radiobtn,
				getTestDataCellValue(scenarioName, "Events_EventSeriousness_RequiredIntervention")));

		if (getTestDataCellValue(scenarioName, "Events_EventSeriousness_CausedProlongedHospitalization")
				.equalsIgnoreCase("Yes")) {
			agSetValue(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.HospitalizationFrom_Date),
					CommonOperations.returnDateTime(
							getTestDataCellValue(scenarioName, "Events_EventSeriousness_HospitalizationDateFrom")));
			agSetValue(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.HospitalizationTo_Date),
					CommonOperations.returnDateTime(
							getTestDataCellValue(scenarioName, "Events_EventSeriousness_HospitalizationDateTo")));
		}
		if (getTestDataCellValue(scenarioName, "Events_EventSeriousness_OtherMedicallyImportantCondition")
				.equalsIgnoreCase("Yes")) {
			agSetValue(FDE_EventsPageObjects.OtherMedicallyCondition_Textarea,
					getTestDataCellValue(scenarioName, "Events_EventSeriousness_OtherMedicallyImportantConditionInfo"));
			agSendKeyStroke(Keys.TAB);
		}

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Event >> Event Seriousness Section : Scenario Name::" + scenarioName, false);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Latency and treatment in event
	 *             tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_LatencyTreatment(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(FDE_EventsPageObjects.latency_Label);
		if (getTestDataCellValue(scenarioName, "Events_Latency_StartLatency_Manual").equalsIgnoreCase("Check")) {
			agClick(FDE_EventsPageObjects.startLatencyManual_Checkbox);
			agSetStepExecutionDelay("1000");
			agSetValue(FDE_EventsPageObjects.startLatency_Textfield,
					getTestDataCellValue(scenarioName, "Events_Latency_StartLatency"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			setDropDownValue(FDE_EventsPageObjects.startLatency_DropDown, scenarioName,
					"Events_Latency_StartLatencyUnit");
		}
		if (getTestDataCellValue(scenarioName, "Events_Latency_EndLatency_Manual").equalsIgnoreCase("Check")) {
			agClick(FDE_EventsPageObjects.endLatencyManual_Checkbox);
			agSetStepExecutionDelay("1000");
			agSetValue(FDE_EventsPageObjects.endLatency_Textfield,
					getTestDataCellValue(scenarioName, "Events_Latency_EndLatency"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			setDropDownValue(FDE_EventsPageObjects.endLatency_DropDown, scenarioName, "Events_Latency_EndLatencyUnit");
		}

		setDropDownValue(FDE_EventsPageObjects.treatmentPerformed_DropDown, scenarioName,
				"Events_Treatment_TreatmentPerformed");
		agSetValue(FDE_EventsPageObjects.treatmentDescription_Textarea,
				getTestDataCellValue(scenarioName, "Events_Treatment_TreatmentDescription"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Event >> Latency and Treatment Section : Scenario Name::" + scenarioName, false);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Event Information data in
	 *             event tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void eventInformation_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(FDE_EventsPageObjects.eventInfo_Label);
		verifyData(FDE_EventsPageObjects.setData_Textfields(FDE_EventsPageObjects.reportedTerm_Textbox), scenarioName,
				"Events_EventInformation_ReportedTerm");
		verifyData(FDE_EventsPageObjects.eventMedDRALLTCode, scenarioName,
				"Events_EventInformation_EventMedDRALLTCode");
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Events_EventInformation_EventMedDRALLTCode_SearchTerm"),
				FDE_EventsPageObjects.getData_eventMedDRALLTCode);

		agClick(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date));
		agCheckPropertyValue("title",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Events_EventInformation_OnsetDate")),
				FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date));
		agClick(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.cessationdate_Date));
		agCheckPropertyValue("title",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Events_EventInformation_CessationDate")),
				FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.cessationdate_Date));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Events_EventInformation_EventType"),
				FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.eventType_DropDown));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome"),
				FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.outCome_DropDown));
		verifyData(FDE_EventsPageObjects.setData_Textfields(FDE_EventsPageObjects.reportedTermLanguage_Textbox),
				scenarioName, "Events_EventInformation_ReportedTermInNativeLanguage");

		agCheckPropertyText(getTestDataCellValue(scenarioName, "Events_EventInformation_NativeLanguage"),
				FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.nativeLanguage_DropDown));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Events_EventInformation_CountryOfDetection"),
				FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.countryDetection_DropDown));
		if (getTestDataCellValue(scenarioName, "Events_EventInformation_Duration_Manual").equalsIgnoreCase("Check")) {
			CommonOperations.verifyCheckBoxUnder(FDE_EventsPageObjects.durationManual_checkbox,
					getTestDataCellValue(scenarioName, "Events_EventInformation_Duration_Manual"));
			verifyData(FDE_EventsPageObjects.setData_Textfields(FDE_EventsPageObjects.duration_Textbox), scenarioName,
					"Events_EventInformation_Duration");
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Events_EventInformation_DurationUnit"),
					FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.duration_Textbox));
		}
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Events_EventInformation_TermHighlighted"),
				FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.termHighlighted_DropDown));
		CommonOperations.verifyRadioButton(FDE_EventsPageObjects.causedByDrugInteractionRadioBtn_Label,
				getTestDataCellValue(scenarioName, "Events_EventInformation_CausedByDrugInteraction"));
		CommonOperations.verifyRadioButton(FDE_EventsPageObjects.causedByLackOfEffectRadioBtn_Label,
				getTestDataCellValue(scenarioName, "Events_EventInformation_CausedByLackOfEffect"));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Events_EventInformation_Severity"),
				FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.severity_DropDown));
		CommonOperations.captureScreenShot(true);
		CommonOperations.verifyRadioButton(FDE_EventsPageObjects.medicallyConfirmedRadioBtn_Label,
				getTestDataCellValue(scenarioName, "Events_EventInformation_MedicallyConfirmed"));
		verifyData(FDE_EventsPageObjects.setData_Textfields(FDE_EventsPageObjects.AEInformation_Textbox), scenarioName,
				"Events_EventInformation_AEAdditionalInformation");
		CommonOperations.verifyCheckBoxUnder(FDE_EventsPageObjects.isAlwaysSeriousEvent_checkbox,
				getTestDataCellValue(scenarioName, "Events_EventInformation_IsAlwaysSeriousEvent"));
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Event >> Event Information Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Event Seriousness data in
	 *             event tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void eventSeriousness_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(FDE_EventsPageObjects.eventSerious_Label);
		CommonOperations.verifyRadioButton(FDE_EventsPageObjects.seriousness_Radiobtn,
				getTestDataCellValue(scenarioName, "Events_EventSeriousness_Seriousness"));
		CommonOperations.verifyRadioButton(FDE_EventsPageObjects.death_Radiobtn,
				getTestDataCellValue(scenarioName, "Events_EventSeriousness_Death"));
		CommonOperations.verifyRadioButton(FDE_EventsPageObjects.lifeThreatening_Radiobtn,
				getTestDataCellValue(scenarioName, "Events_EventSeriousness_LifeThreatening"));
		CommonOperations.verifyRadioButton(FDE_EventsPageObjects.caused_prolongedhospitalization_Radiobtn,
				getTestDataCellValue(scenarioName, "Events_EventSeriousness_CausedProlongedHospitalization"));
		CommonOperations.verifyRadioButton(FDE_EventsPageObjects.disability_PermanentDamage_Radiobtn,
				getTestDataCellValue(scenarioName, "Events_EventSeriousness_DisabilityPermanentDamage"));
		CommonOperations.verifyRadioButton(FDE_EventsPageObjects.congenitalAnomalyBirthDefect_Radiobtn,
				getTestDataCellValue(scenarioName, "Events_EventSeriousness_CongenitalAnomalyBirthDefect"));
		CommonOperations.verifyRadioButton(FDE_EventsPageObjects.OtherMedicallyCondition_Radiobtn,
				getTestDataCellValue(scenarioName, "Events_EventSeriousness_OtherMedicallyImportantCondition"));
		CommonOperations.verifyRadioButton(FDE_EventsPageObjects.requiredIntervenation_Radiobtn,
				getTestDataCellValue(scenarioName, "Events_EventSeriousness_RequiredIntervention"));

		if (getTestDataCellValue(scenarioName, "Events_EventSeriousness_CausedProlongedHospitalization")
				.equalsIgnoreCase("Yes")) {
			agClick(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.HospitalizationFrom_Date));
			agCheckPropertyValue("title",
					CommonOperations.returnDateTime(
							getTestDataCellValue(scenarioName, "Events_EventSeriousness_HospitalizationDateFrom")),
					FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.HospitalizationFrom_Date));
			agClick(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.HospitalizationTo_Date));
			agCheckPropertyValue("title",
					CommonOperations.returnDateTime(
							getTestDataCellValue(scenarioName, "Events_EventSeriousness_HospitalizationDateTo")),
					FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.HospitalizationTo_Date));
		}
		if (getTestDataCellValue(scenarioName, "Events_EventSeriousness_OtherMedicallyImportantCondition")
				.equalsIgnoreCase("Yes")) {
			agClick(FDE_EventsPageObjects.OtherMedicallyCondition_Textarea);
			agCheckPropertyValue("value",
					getTestDataCellValue(scenarioName, "Events_EventSeriousness_OtherMedicallyImportantConditionInfo"),
					FDE_EventsPageObjects.OtherMedicallyCondition_Textarea);
		}

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Event >> Event Seriousness Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Event Latency and treatment
	 *             data in event tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void latencyTreatment_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(FDE_EventsPageObjects.latency_Label);
		if (getTestDataCellValue(scenarioName, "Events_Latency_StartLatency_Manual").equalsIgnoreCase("Check")) {
			verifyData(FDE_EventsPageObjects.startLatency_Textfield, scenarioName, "Events_Latency_StartLatency");
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Events_Latency_StartLatencyUnit"),
					FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.startLatency_DropDown));
		}
		if (getTestDataCellValue(scenarioName, "Events_Latency_EndLatency_Manual").equalsIgnoreCase("Check")) {
			verifyData(FDE_EventsPageObjects.endLatency_Textfield, scenarioName, "Events_Latency_EndLatency");
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Events_Latency_EndLatencyUnit"),
					FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.endLatency_DropDown));

		}

		agCheckPropertyText(getTestDataCellValue(scenarioName, "Events_Treatment_TreatmentPerformed"),
				FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.treatmentPerformed_DropDown));
		agClick(FDE_EventsPageObjects.treatmentDescription_Textarea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Events_Treatment_TreatmentDescription"),
				FDE_EventsPageObjects.treatmentDescription_Textarea);

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Event >> Latency and Treatment Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Events in event tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_Events(String scenarioName) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,
		// "ConfigurationSettings");
		// if (getTestDataCellValue(scenarioName, "FDE_Events").equalsIgnoreCase("Yes"))
		// {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Multimaplibraries.getTestDataCellLength(scenarioName, "Events_EventInformation_ReportedTerm");

		for (int j = 1; j <= Constants.testDataParentLength; j++) {
			Constants.testDataChildLoopCount = j;

			if (j > 1) {
				agClick(FDE_EventsPageObjects.addButton);
				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			set_EventInformation_Data(scenarioName);
			set_EventSeriousness(scenarioName);
			set_LatencyTreatment(scenarioName);
			Reports.ExtentReportLog("", Status.INFO, "~~~~~~~Event Creation_00" + j + "~~~~~~~~", false);
		}
	}
	// }

	/**********************************************************************************************************
	 * @Objective: To navigate to 1st record
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Avinash K
	 * @Date : 29-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void navigateToParentEvent() {
		if (agIsVisible(FDE_ProductsPageObjects.forwardNavigaterClick) == true) {
			List<WebElement> list = agGetElementList(FDE_EventsPageObjects.getListOfEvents);
			System.out.println("Event Length::" + list.size());
			for (int i = 1; i <= list.size(); i++) {
				agJavaScriptExecuctorClick(FDE_EventsPageObjects.prevNavigaterClick);
				try {
					Thread.sleep(3000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Event data in event tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void agClickMultipleEvent(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(FDE_EventsPageObjects
				.clickMultipleEvents(getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm")));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Event data in event tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_Event(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		Multimaplibraries.getTestDataCellLength(scenarioName, "Events_EventInformation_ReportedTerm");

		navigateToParentEvent();

		for (int j = 1; j <= Constants.testDataParentLength; j++) {
			Constants.testDataChildLoopCount = j;

			if (j >= 1) {

				if (!agIsVisible(FDE_EventsPageObjects.clickMultipleEvents(
						getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm")))) {
					agJavaScriptExecuctorClick(FDE_EventsPageObjects.forwardNavigaterClick);
				} else if (!agIsVisible(FDE_EventsPageObjects.clickMultipleEvents(
						getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm")))) {
					agJavaScriptExecuctorClick(FDE_EventsPageObjects.prevNavigaterClick);
				}
				agJavaScriptExecuctorClick(FDE_EventsPageObjects.clickMultipleEvents(
						getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm")));
				System.out.println("Product Name:" + agGetXpath(FDE_EventsPageObjects.clickMultipleEvents(
						getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"))));
				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			eventInformation_Verification(scenarioName);
			eventSeriousness_Verification(scenarioName);
			latencyTreatment_Verification(scenarioName);
			Reports.ExtentReportLog("", Status.INFO, "~~~~~~~Event Verification_00" + j + "~~~~~~~~", false);
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	/**********************************************************************************************************
	 * @Objective: To Clcik Second Event tab
	 * @InputParameters: EventName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 26-Apr-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clcikSecondEvent(String EventName) {
		agSetStepExecutionDelay("5000");
		agClick(FDE_EventsPageObjects.clickSecondEvent(EventName));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Verify AutoCalculation of Start Latency
	 *             and End Latency
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @throws ParseException
	 * @Date : 14-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AutoCalculationofStartAndEndLatency() throws ParseException {
		Reports.ExtentReportLog("", Status.INFO, "Auto Calculation of Start And End Latency Begins", true);
		try {
			FDE_Operations.tabNavigation("Product(s)");
			agSetStepExecutionDelay("3000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agClick(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate));
			String ThearpyStartDate = agGetAttribute("title",
					FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate));
			agClick(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyEndDate));
			String ThearpyEndDate = agGetAttribute("title",
					FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyEndDate));
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
			if (ThearpyStartDate.equals("") || ThearpyEndDate.equals("")) {
				Reports.ExtentReportLog("", Status.INFO, "No Data Found to Calculate Start and End Latency", true);
			} else {
				Date firstDate = sdf.parse(ThearpyStartDate);
				Date secondDate = sdf.parse(ThearpyEndDate);

				FDE_Operations.tabNavigation("Event(s)");
				agClick(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date));
				String OnSetDate = agGetAttribute("title",
						FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date));
				Date OnsetDate = sdf.parse(OnSetDate);

				int diffStartYear = Math.abs(OnsetDate.getYear() - firstDate.getYear());
				int diffStartMonth = diffStartYear * 12 + OnsetDate.getMonth() - firstDate.getMonth();
				long diffStartDay = Math.abs(OnsetDate.getDay() - firstDate.getDay())+1;
				long Startweeks = diffStartDay / 7;
				long diffStart = OnsetDate.getTime() - firstDate.getTime();
				long diffSecondsStart = diffStart / 1000;
				long diffMinutesStart = diffStart / (60 * 1000);
				long diffHoursStart = diffStart / (60 * 60 * 1000);

				int diffEndYear = Math.abs(OnsetDate.getYear() - secondDate.getYear());
				int diffEndMonth = diffEndYear * 12 + OnsetDate.getMonth() - secondDate.getMonth();
				long diffEndDay = Math.abs(OnsetDate.getDay() - secondDate.getDay())+1;
				long Endweeks = diffEndDay / 7;
				long diffEnd = OnsetDate.getTime() - firstDate.getTime();
				long diffSecondsEnd = diffEnd / 1000;
				long diffMinutesEnd = diffEnd / (60 * 1000);
				long diffHoursEnd = diffEnd / (60 * 60 * 1000);

				String StartLatencyDropdown = agGetText(
						FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.startLatency_DropDown));
				agClick(FDE_EventsPageObjects.startLatency_Textfield);
				String StartLatencyTextBox = agGetAttribute("title", FDE_EventsPageObjects.startLatency_Textfield);
				String EndLatencyDropdown = agGetText(
						FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.endLatency_DropDown));
				agClick(FDE_EventsPageObjects.endLatency_Textfield);
				String EndLatencyTextBox = agGetAttribute("title", FDE_EventsPageObjects.endLatency_Textfield);

				// Start Latency
				if (StartLatencyDropdown.equalsIgnoreCase("Day")) {
					if (StartLatencyTextBox.equalsIgnoreCase(String.valueOf(diffStartDay))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Start Latency  in Days Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Start Latency  in Days Doesnt Matches",
								true);
					}
				} else if (StartLatencyDropdown.equalsIgnoreCase("Month")) {
					if (StartLatencyTextBox.equalsIgnoreCase(String.valueOf(diffStartMonth))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Start Latency  in Month Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Start Latency  in Month Doesnt Matches",
								true);
					}
				} else if (StartLatencyDropdown.equalsIgnoreCase("Year")) {
					if (StartLatencyTextBox.equalsIgnoreCase(String.valueOf(diffStartYear))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Start Latency  in Year Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Start Latency  in Year Doesnt Matches",
								true);
					}
				} else if (StartLatencyDropdown.equalsIgnoreCase("Week")) {
					if (StartLatencyTextBox.equalsIgnoreCase(String.valueOf(Startweeks))) {
						Reports.ExtentReportLog("Calculated Start Latency  in Week Matches", Status.PASS, "", true);
					} else {
						Reports.ExtentReportLog("Calculated Start Latency  in Week Doesnt Matches", Status.FAIL, "",
								true);
					}
				} else if (StartLatencyDropdown.equalsIgnoreCase("Hour")) {
					if (StartLatencyTextBox.equalsIgnoreCase(String.valueOf(diffHoursStart))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Start Latency  in Hour Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Start Latency  in Hour Doesnt Matches",
								true);
					}
				} else if (StartLatencyDropdown.equalsIgnoreCase("Minute")) {
					if (StartLatencyTextBox.equalsIgnoreCase(String.valueOf(diffMinutesStart))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Start Latency  in Minute Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Start Latency  in Minute Doesnt Matches",
								true);
					}
				} else if (StartLatencyDropdown.equalsIgnoreCase("Second")) {
					if (StartLatencyTextBox.equalsIgnoreCase(String.valueOf(diffMinutesStart))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Start Latency  in Second Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Start Latency  in Second Doesnt Matches",
								true);
					}
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Start Latency is not getting AutoCalculated", true);
				}

				if(EndLatencyDropdown.equalsIgnoreCase("--Select--")) {
					Reports.ExtentReportLog("", Status.INFO, "No data Found", true);
				}else {
				// End Latency
				if (EndLatencyDropdown.equalsIgnoreCase("Day")) {
					if (EndLatencyTextBox.equalsIgnoreCase(String.valueOf(diffEndDay))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated End Latency  in Days Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated End Latency  in Days Doesnt Matches",
								true);
					}
				} else if (EndLatencyDropdown.equalsIgnoreCase("Month")) {
					if (EndLatencyTextBox.equalsIgnoreCase(String.valueOf(diffEndMonth))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated End Latency  in Month Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated End Latency  in Month Doesnt Matches",
								true);
					}
				} else if (EndLatencyDropdown.equalsIgnoreCase("Year")) {
					if (EndLatencyTextBox.equalsIgnoreCase(String.valueOf(diffEndYear))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated End Latency  in Year Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated End Latency  in Year Doesnt Matches",
								true);
					}
				} else if (EndLatencyDropdown.equalsIgnoreCase("Week")) {
					if (EndLatencyTextBox.equalsIgnoreCase(String.valueOf(Endweeks))) {
						Reports.ExtentReportLog("Calculated End Latency  in Week Matches", Status.PASS, "", true);
					} else {
						Reports.ExtentReportLog("Calculated End Latency  in Week Doesnt Matches", Status.FAIL, "",
								true);
					}
				} else if (EndLatencyDropdown.equalsIgnoreCase("Hour")) {
					if (EndLatencyTextBox.equalsIgnoreCase(String.valueOf(diffHoursEnd))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated End Latency  in Hour Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated End Latency  in Hour Doesnt Matches",
								true);
					}
				} else if (EndLatencyDropdown.equalsIgnoreCase("Minute")) {
					if (EndLatencyTextBox.equalsIgnoreCase(String.valueOf(diffMinutesEnd))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated End Latency  in Minute Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated End Latency  in Minute Doesnt Matches",
								true);
					}
				} else if (EndLatencyDropdown.equalsIgnoreCase("Second")) {
					if (EndLatencyTextBox.equalsIgnoreCase(String.valueOf(diffMinutesEnd))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated End Latency  in Second Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated End Latency  in Second Doesnt Matches",
								true);
					}
				} 
				else {
					Reports.ExtentReportLog("", Status.FAIL, "End Latency is not getting AutoCalculated", true);
				}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Auto Calculation of Start And End Latency Fails", true);
		}
		Reports.ExtentReportLog("", Status.INFO, "Auto Calculation of Start And End Latency Ends", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Verify AutoCalculation of Reaction
	 *             Duration
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @throws ParseException
	 * @Date : 14-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AutoCalculationofReacionDuration() throws ParseException {
		Reports.ExtentReportLog("", Status.INFO, "Auto Calculation of Reaction duration Begins", true);
		try {
			FDE_Operations.tabNavigation("Event(s)");
			String checkBoxStatus = agGetAttribute("class",
					FDE_EventsPageObjects.ManualdurationChkbox);
			
			if(checkBoxStatus.contains("pi-check")) {
				Reports.ExtentReportLog("", Status.INFO, "Unable to Calculate as Data is Improper", true);
			}
			else {
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
			agClick(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date));
			String OnSetDate = agGetAttribute("title",
					FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date));
			agClick(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.cessationdate_Date));
			String CessationDate = agGetAttribute("title",
					FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.cessationdate_Date));
			if (OnSetDate.equals("") || CessationDate.equals("")) {
				Reports.ExtentReportLog("", Status.INFO, "No Data Found to Calculate Reaction Duration", true);
			} else {
				Date OnsetDate = sdf.parse(OnSetDate);
				Date Cessationdate = sdf.parse(CessationDate);
				int diffYear = Math.abs(Cessationdate.getYear() - OnsetDate.getYear());
				int diffMonth = diffYear * 12 + Cessationdate.getMonth() - OnsetDate.getMonth();
				long diffDay = Math.abs(Cessationdate.getDay() - OnsetDate.getDay());
				long weeks = diffDay / 7;
				long diff = Cessationdate.getTime() - OnsetDate.getTime();
				long diffSeconds = diff / 1000;
				long diffMinutes = diff / (60 * 1000);
				long diffHours = diff / (60 * 60 * 1000);

				String DurationDropdown = agGetText(
						FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.duration_Textbox));
				agClick(FDE_EventsPageObjects.setData_Textfields(FDE_EventsPageObjects.duration_Textbox));
				String DurationTextBox = agGetAttribute("title",
						FDE_EventsPageObjects.setData_Textfields(FDE_EventsPageObjects.duration_Textbox));

				if (DurationDropdown.equalsIgnoreCase("Day")) {
					if (DurationTextBox.equalsIgnoreCase(String.valueOf(diffDay))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Therapy Duration  in Days Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Therapy Duration  in Days Doesnt Matches",
								true);
					}
				} else if (DurationDropdown.equalsIgnoreCase("Month")) {
					if (DurationTextBox.equalsIgnoreCase(String.valueOf(diffMonth))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Therapy Duration  in Month Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Therapy Duration  in Month Doesnt Matches",
								true);
					}
				} else if (DurationDropdown.equalsIgnoreCase("Year")) {
					if (DurationTextBox.equalsIgnoreCase(String.valueOf(diffYear))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Therapy Duration  in Year Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Therapy Duration  in Year Doesnt Matches",
								true);
					}
				} else if (DurationDropdown.equalsIgnoreCase("Week")) {
					if (DurationTextBox.equalsIgnoreCase(String.valueOf(diffDay))) {
						Reports.ExtentReportLog("Calculated Therapy Duration  in Week Matches", Status.PASS, "", true);
					} else {
						Reports.ExtentReportLog("Calculated Therapy Duration  in Week Doesnt Matches", Status.FAIL, "",
								true);
					}
				} else if (DurationDropdown.equalsIgnoreCase("Hour")) {
					if (DurationTextBox.equalsIgnoreCase(String.valueOf(diffHours))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Therapy Duration  in Hour Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Therapy Duration  in Hour Doesnt Matches",
								true);
					}
				} else if (DurationDropdown.equalsIgnoreCase("Minute")) {
					if (DurationTextBox.equalsIgnoreCase(String.valueOf(diffMinutes))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Therapy Duration  in Minute Matches",
								true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL,
								"Calculated Therapy Duration  in Minute Doesnt Matches", true);
					}
				} else if (DurationDropdown.equalsIgnoreCase("Second")) {
					if (DurationTextBox.equalsIgnoreCase(String.valueOf(diffSeconds))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Therapy Duration  in Second Matches",
								true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL,
								"Calculated Therapy Duration  in Second Doesnt Matches", true);
					}
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Therapy Duration is not getting AutoCalculated", true);
				}
			}
		}
		}catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Auto Calculation of Reaction duration Fails", true);
		}
		Reports.ExtentReportLog("", Status.INFO, "Auto Calculation of Reaction duration Ends", true);

	}


	/**********************************************************************************************************
	 * @Objective: The below method is to Verify isAlways Serious Event check box is
	 *             checked based on below conditions Event present in
	 *             library[isAlwaySeriousEvent] should be similar in case , Event
	 *             Seriousness=Yes, Other Medically Important Condition=Yes
	 * @InputParameters: ScenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 05-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyIsAlwaysEventSeriousCheckbox(String rctNumber) {
		Reports.ExtentReportLog("", Status.INFO, "Verification of Always serious event started", true);
		try {
			String getPTTerm = null;
			FDE_Operations.tabNavigation("Event(s)");
			agSetStepExecutionDelay("2000");
			String eventReportedTerm = agGetAttribute("value", FDE_EventsPageObjects.reportedTerm_Textfield);
			System.out.println(eventReportedTerm);
			String eventMedraPTCode = agGetText(FDE_EventsPageObjects.eventMedraPTCode);
			System.out.println(eventMedraPTCode);
			if (!eventReportedTerm.isEmpty() && !eventMedraPTCode.isEmpty()) {
				Reports.ExtentReportLog("", Status.INFO, "eventMedraPTCode and eventReportedTerm is Present ", true);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.aeAdditionalInfoLabel);
				status = agIsVisible(FDE_EventsPageObjects
						.radioBtnVerification(FDE_EventsPageObjects.OtherMedicallyCondition_Radiobtn));
				statusSerious = agIsVisible(
						FDE_EventsPageObjects.radioBtnVerification(FDE_EventsPageObjects.seriousness_Radiobtn));
				CommonOperations.takeScreenShot();
				FDE_Operations.saveAndExit();
				LibrariesOperations.menuNavigation("alwaysSeriousEvent");
				agSetValue(Lib_AlwaysSeriousEvent_PageObjects.keywordSearch_Textbox, eventMedraPTCode);
				agClick(Lib_AlwaysSeriousEvent_PageObjects.search_Icon);
				agSetStepExecutionDelay("3000");
				String aePaginator = agGetText(Lib_AlwaysSeriousEvent_PageObjects.aepaginator);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				if (aePaginator != null && aePaginator.startsWith("1")) {
					getPTTerm = agGetText(Lib_AlwaysSeriousEvent_PageObjects.get_PtTerm);
					Reports.ExtentReportLog("", Status.PASS, "Always Serious Event Exists::", true);
					System.out.println(getPTTerm);
				} else {
					Reports.ExtentReportLog("", Status.INFO, "Always Serious Event doesnt Exists::", true);
				}
				CaseManagementOperations.caseManagement_MenuNavigations("caseListing");
				CaseListingOperations.searchCase(rctNumber);
				CaseListingOperations.searchEdit();
				FDE_Operations.tabNavigation("Event(s)");
				agSetStepExecutionDelay("2000");
				if (getPTTerm == null) {
					boolean alwaysSeriousCheck = agIsVisible(FDE_EventsPageObjects
							.checkboxVerification(FDE_EventsPageObjects.isAlwaysSeriousEvent_checkbox));
					if (alwaysSeriousCheck == false) {
						Reports.ExtentReportLog("", Status.PASS, "Always serious event Check box Unchecked", true);
						CommonOperations.takeScreenShot();
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Always serious event Check box checked", true);
					}
				} else if (status && statusSerious && eventMedraPTCode.equalsIgnoreCase(getPTTerm)) {
					boolean alwaysSeriousCheck = agIsVisible(FDE_EventsPageObjects
							.checkboxVerification(FDE_EventsPageObjects.isAlwaysSeriousEvent_checkbox));
					if (alwaysSeriousCheck) {
						Reports.ExtentReportLog("", Status.PASS, "Always serious event Check box checked", true);
						CommonOperations.takeScreenShot();
					}
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Always serious event Check box Unchecked", true);
				}
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			} else
				Reports.ExtentReportLog("", Status.INFO, "eventMedraPTCode is Empty", true);
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Always serious event Check box verifiication is not verified" + e,
					true);
		}

		Reports.ExtentReportLog("", Status.INFO, "Verification of Always serious event ended", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Verify IS DME and IS IME Event check box
	 *             is checked based on below conditions Event(DME Checked) present
	 *             in library[IS IME/DME Management]is same in case - Check both IME
	 *             and DME else check only IME Event not present in library and same
	 *             event created for case- both check box(IME/DME) is not checked
	 * @InputParameters: ScenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 05-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyIMEDMECheckbox(String rctNumber) {
		FDE_Operations.tabNavigation("Event(s)");
		String eventReportedTerm = agGetAttribute("value", FDE_EventsPageObjects.reportedTerm_Textfield);
		System.out.println(eventReportedTerm);
		// FDE_Operations.saveAndExit();
		LibrariesOperations.menuNavigation("iMEDMEManagement");
		agSetStepExecutionDelay("2000");
		agClick(Lib_IMEDME_PageObjects.eventVersion(Lib_IMEDME_PageObjects.version));
		agSetValue(Lib_IMEDME_PageObjects.keywordSearch_Textbox, eventReportedTerm);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(Lib_IMEDME_PageObjects.edit_Icon);
		String eventPTTerm = agGetText(Lib_IMEDME_PageObjects.get_IMDMEEventMedDRAPTTerm);
		System.out.println(eventPTTerm); // Pyrexia
		status = agIsVisible(CommonPageObjects.checkBoxUnder(Lib_IMEDME_PageObjects.isDME_Checkbox));
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "PT Term Exists:: Is DME checked", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS, "PT Term Exists:: Is DME not checked", true);
		}
		CaseManagementOperations.caseManagement_MenuNavigations("caseListing");
		CaseListingOperations.searchCase(rctNumber);
		CaseListingOperations.searchEdit();
		FDE_Operations.tabNavigation("Event(s)");
		if (eventPTTerm.equalsIgnoreCase(eventReportedTerm)) {
			if (status) {
				verificationOfCheckBox(FDE_EventsPageObjects.iME_Checkbox);
				verificationOfCheckBox(FDE_EventsPageObjects.dME_Checkbox);
				CommonOperations.takeScreenShot();
			} else {
				Reports.ExtentReportLog("", Status.PASS, "IME Check box checked", true);
			}
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Event Doesnt Exists in case:: IME and DME Check box not checked",
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Check/Uncheck Operation
	 *             from the application
	 * @InputParameters: label
	 * @OutputParameters:NA
	 * @author: Pooja S
	 * @Date : 10-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verificationOfCheckBox(String label) {
		if (!label.trim().contains("#skip#")) {
			String checkBoxStatus = agGetAttribute("class", FDE_EventsPageObjects.checkBoxUnder(label));
			if (checkBoxStatus.contains("ui-state-active")) {
				Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is checked", true);
			} else {
				Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is not checked", true);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Check Box Not Selected
	 *             Operation from the application
	 * @InputParameters: label
	 * @OutputParameters:NA
	 * @author: Avinash k
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCheckBoxNotSelected(String label) {
		if (!label.trim().contains("#skip#")) {
			String checkBoxStatus = agGetAttribute("class", FDE_EventsPageObjects.checkBoxUnder(label));
			if (checkBoxStatus.contains("ui-state-active")) {
				Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is checked", true);
			} else {
				Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is not checked", true);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Click Nullfalvor Button
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 09-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickNullfalvorBtn() {
		agClick(FDE_EventsPageObjects.clickNF_Btn);
		agWaitTillVisibilityOfElement(FDE_EventsPageObjects.eventConfirmationPopUp_Message);
		status = agIsVisible(FDE_EventsPageObjects.eventConfirmationPopUp_Message);
		if (status) {
			CommonOperations.takeScreenShot();
			agClick(FDE_EventsPageObjects.eventConfirmationPopUpYes_Btn);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verify rollover from Seriousness As Per Company [A.5.1][R2] to
	 *             Seriousness event level [E.i.3.2][R3] upon save, import and
	 *             export of the case..
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Wajahatumar S
	 * @Date : 18-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySeriousnessasperCompanyToEventLevel_RollOver() {
		Reports.ExtentReportLog("", Status.INFO, "verify Seriousness as per Company To Event Level RollOver Begins",
				true);
		// Medically informed verification is done only for one event
		try {
			FDE_Operations.tabNavigation("Event(s)");
			agSetStepExecutionDelay("3000");
			ArrayList<String> Al = new ArrayList<>();
			ArrayList<String> Al1 = new ArrayList<>();
			ArrayList<String> Names = FDE_Events.GetEventRadioBtnList();
			ArrayList<String> Names1 = FDE_Events.GetGeneralRadioBtnList();

			int count = Names.size();
			int count1 = Names1.size();
			System.out.print(count);
			for (int i = 0; i < count; i++) {
				String RadioBtn = Names.get(i).toString();
				if (agIsVisible(FDE_EventsPageObjects.NoInformation(RadioBtn)) == true
						|| (!agIsVisible(FDE_EventsPageObjects.radioBtnVerification(RadioBtn)) == true)) {
					Reports.ExtentReportLog("", Status.INFO, RadioBtn + " RadioButton not Selected in Event Tab", true);
					Al.add(i, RadioBtn.trim());
				} else if (agIsVisible(FDE_EventsPageObjects.radioBtnVerification(RadioBtn)) == true) {
					agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.radioBtnVerification(RadioBtn));
					Reports.ExtentReportLog("", Status.PASS, RadioBtn + " RadioButton is Selected in Event Tab", true);
					Al.add(i, RadioBtn.trim());

				}

			}

			FDE_Operations.tabNavigation("General");
			agSetStepExecutionDelay("3000");

			for (int i = 0; i < count1; i++) {
				String RadioBtn1 = Names1.get(i).toString();
				if (agIsVisible(FDE_EventsPageObjects.NoInformation(RadioBtn1.trim())) == true
						|| (!agIsVisible(FDE_EventsPageObjects.radioBtnVerification(RadioBtn1.trim())) == true)) {
					Reports.ExtentReportLog("", Status.INFO, RadioBtn1 + " RadioButton not Selected in General Tab",
							true);
					Al1.add(i, RadioBtn1);
				} else if (agIsVisible(FDE_EventsPageObjects.radioBtnVerification(RadioBtn1.trim())) == true) {
					agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.radioBtnVerification(RadioBtn1.trim()));
					Reports.ExtentReportLog("", Status.PASS, RadioBtn1 + " RadioButton is Selected in General Tab",
							true);
					Al1.add(i, RadioBtn1);
				}

			}
			String Value = Al.toString();
			String Value1 = Al1.toString();
			if (Value.equalsIgnoreCase(Value1)) {
				Reports.ExtentReportLog("", Status.PASS,
						"RadioButtons Selected are Matches in Both Event and General Tab(Case Seriousness)", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"RadioButtons Selected Doesnt Match in Both Event and General Tab(Case Seriousness)", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "verify Seriousness as per Company To Event Level RollOver Fails",
					true);
		}
		Reports.ExtentReportLog("", Status.INFO, "verify Seriousness as per Company To Event Level RollOver Ends",
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Get list of Radio Buttons from Event
	 *             Seriousness
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 22-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> GetEventRadioBtnList() {
		ArrayList Al = new ArrayList<>();
		String Value = "Seriousness ,Required Intervention ,Death? ,Life Threatening? ,Congenital Anomaly/Birth Defect? ,Caused/prolonged hospitalization ,Disability/Permanent Damage? ,Other Medically Important Condition ";
		List<String> list = Arrays.asList(Value.split(","));
		for (int i = 0; i < 8; i++) {
			Al.add(i, list.get(i));
		}
		return Al;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Get list of Radio Buttons from General
	 *             Seriousness
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 22-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> GetGeneralRadioBtnList() {
		ArrayList Al = new ArrayList<>();
		String Value = "Seriousness,Required Intervention,Death?,Life Threatening?,Congenital Anomaly/Birth Defect?,Caused/Prolonged Hospitalization,Disability/Permanent Damage?,Other Medically Important Condition";
		List<String> list = Arrays.asList(Value.split(","));
		for (int i = 0; i < 8; i++) {
			Al.add(i, list.get(i));
		}
		return Al;
	}

	/**********************************************************************************************************
	 * @Objective: Verify rollover from Medically Confirmed [A.1.14] to Medically
	 *             Confirmed [E.i.8] of all events available upon save, import and
	 *             export of the case.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Wajahatumar S
	 * @Date : 18-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyMedicallyConfirmed_RollOver() {
		Reports.ExtentReportLog("", Status.INFO, "verify Medically Confirmed RollOver Started", true);
		// Medically informed verification is done only for one event
		try {
			FDE_Operations.tabNavigation("General");
			agSetStepExecutionDelay("3000");
			if (agIsVisible(FDE_GeneralPageObjects.MedicallyConfirmedEnabled) == true) {
				Reports.ExtentReportLog("", Status.PASS, "Medically Confirmed is Enabled in General Tab", true);
				FDE_Operations.tabNavigation("Event(s)");
				if (agIsVisible(FDE_GeneralPageObjects.MedicallyConfirmedEnabled) == true) {
					Reports.ExtentReportLog("", Status.PASS, "Medically Confirmed is Enabled in Event Tab", true);
				} else {
					Reports.ExtentReportLog("", Status.INFO, "Medically Confirmed not Enabled in Event Tab", true);
				}

			} else {
				Reports.ExtentReportLog("", Status.INFO, "Medically Confirmed not Enabled in Event Tab", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "verify Medically Confirmed RollOver Fails", true);
		}
		Reports.ExtentReportLog("", Status.INFO, "verify Medically Confirmed RollOver Ends", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify rollover from Country of Detection [A.2] to Country
	 *             [E.i.9] for each reaction upon save, import and export of the
	 *             case.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 17-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCountryDetection_RollOver() {
		// Country detection verification is done only for one event
		Reports.ExtentReportLog("", Status.INFO,
				"Auto Rollover verification of Country detection from General to Country Detection in Event tab is started",
				true);
		try {
			FDE_Operations.tabNavigation("General");
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.caseSpecificInfo);
			String countryDetectioninGen = agGetText(
					FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.countryOfDetection));
			CommonOperations.takeScreenShot();
			System.out.println(countryDetectioninGen);
			FDE_Operations.tabNavigation("Event(s)");
			String countryDetectioninEvents = agGetText(
					FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.countryDetection_DropDown));
			CommonOperations.takeScreenShot();
			System.out.println(countryDetectioninEvents);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (countryDetectioninGen.equalsIgnoreCase(countryDetectioninEvents)) {
				Reports.ExtentReportLog("", Status.PASS,
						"Auto Rollover verification of Country detection from General to Country Detection in Event tab is matched: Country Detection = "
								+ countryDetectioninEvents,
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Auto Rollover verification of Country detection from General to Country Detection in Event tab not matched: Country Detection = "
								+ countryDetectioninEvents,
						true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Auto Rollover verification of Country detection from General to Country Detection in Event tab is not verified "
							+ e,
					true);
		}
		Reports.ExtentReportLog("", Status.INFO,
				"Auto Rollover verification of Country detection from General to Country Detection in Event tab is ended",
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify event is coded or not.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void CodedEventVerification() {
		List<WebElement> getProdCode = agGetElementList(FDE_EventsPageObjects.suspectEventCodedlist);
		for (int i = 0; i < getProdCode.size(); i++) {
			String prodCode = agGetAttribute("class", FDE_EventsPageObjects.getEventCode(Integer.toString(i + 1)));
			if (prodCode.contains("reactionTabSDLautoCoded")) {
				Reports.ExtentReportLog("", Status.PASS, "Event is coded ", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Event is not Coded ", true);
			}
			CommonOperations.takeScreenShot();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify event is coded or not.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 06-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void NotCodedEventVerification() {
		List<WebElement> getProdCode = agGetElementList(FDE_EventsPageObjects.suspectEventNotCodedlist);
		for (int i = 0; i < getProdCode.size(); i++) {
			String prodCode = agGetAttribute("class", FDE_EventsPageObjects.getEventNotCode(Integer.toString(i + 1)));
			if (prodCode.contains("reactionTabSDLnotAutoCoded")) {
				Reports.ExtentReportLog("", Status.FAIL, "Event is not coded ", true);
			} else {
				Reports.ExtentReportLog("", Status.PASS, "Event is Coded ", true);
			}
			CommonOperations.takeScreenShot();
		}
	}

	public static void eventAddbutton() {
		agSetStepExecutionDelay("5000");
		agIsVisible(FDE_EventsPageObjects.addButton);
		agClick(FDE_EventsPageObjects.addButton);
	}
	
	public static void EnableFlagManualCheckBoxExist() {
		try {
			if(agIsVisible(FDE_EventsPageObjects.IMEDMEManualCheckBox)==true){
				Reports.ExtentReportLog("", Status.PASS, "IME DME Manual CheckBox is Present", true);
				agClick(FDE_EventsPageObjects.IMEDMEManualCheckBox);
				agWaitTillVisibilityOfElement(FDE_EventsPageObjects.IMEDEMDowngradePopUp);
				agClick(FDE_EventsPageObjects.SubmitBtnDowngrade);
				FDE_Operations.saveCase();
				FDE_Operations.clickSaveOKBtn();
				if(agIsVisible(FDE_EventsPageObjects.IMEUnchecked)==true && agIsVisible(FDE_EventsPageObjects.DMEUnchecked)==true ) {
					Reports.ExtentReportLog("", Status.PASS, "IME DME Checkboxes are Edited", true);
				}else {
					Reports.ExtentReportLog("", Status.FAIL, "IME DME Checkboxes are not Edited", true);
				}
			}else {
				Reports.ExtentReportLog("", Status.FAIL, "IME DME Manual CheckBox is not Present", true);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void EnableFlagManualCheckBoxNotExist() {
		try {
			if(!(agIsVisible(FDE_EventsPageObjects.IMEDMEManualNoCheckBox)==true)){
				Reports.ExtentReportLog("", Status.PASS, "IME DME Manual CheckBox is Not Present", true);
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**********************************************************************************************************
	 * @Objective: Verify R2 tags in Event tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 20-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyEventR2Tags() {
		Reports.ExtentReportLog("", Status.INFO, "********Event R2 tag verification Started*******", true);
		agAssertVisible(FDE_EventsPageObjects.R2ReportedTerm);
		agAssertVisible(FDE_EventsPageObjects.R2EventMedDRALLTCode);
		agAssertVisible(FDE_EventsPageObjects.R2EventMedDRAPTCode);
		agAssertVisible(FDE_EventsPageObjects.R2TermHighlighted);
		agAssertVisible(FDE_EventsPageObjects.R2OnsetDate);
		agAssertVisible(FDE_EventsPageObjects.R2CessationDate);
		agAssertVisible(FDE_EventsPageObjects.R2Duration);
		agAssertVisible(FDE_EventsPageObjects.R2Outcome);
		agAssertVisible(FDE_EventsPageObjects.R2StartLatency);
		agAssertVisible(FDE_EventsPageObjects.R2EndLatency);
		Reports.ExtentReportLog("", Status.INFO, "********Event R2 tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify R3 tags in Event tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 20-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyEventR3Tags() {
		Reports.ExtentReportLog("", Status.INFO, "********Event R3 tag verification Started*******", true);
		agAssertVisible(FDE_EventsPageObjects.R3ReportedTerm);
		agAssertVisible(FDE_EventsPageObjects.R3EventMedDRALLTCode);
		agAssertVisible(FDE_EventsPageObjects.R3ReportedTermInNativeLanguage);
		agAssertVisible(FDE_EventsPageObjects.R3NativeLanguage);
		agAssertVisible(FDE_EventsPageObjects.R3TermHighlighted);
		agAssertVisible(FDE_EventsPageObjects.R3OnsetDate);
		agAssertVisible(FDE_EventsPageObjects.R3CessationDate);
		agAssertVisible(FDE_EventsPageObjects.R3Duration);
		agAssertVisible(FDE_EventsPageObjects.R3CountryOfDetection);
		agAssertVisible(FDE_EventsPageObjects.R3MedicallyConfirmed);
		agAssertVisible(FDE_EventsPageObjects.R3Outcome);
		agAssertVisible(FDE_EventsPageObjects.R3Seriousness);
		agAssertVisible(FDE_EventsPageObjects.R3Death);
		agAssertVisible(FDE_EventsPageObjects.R3LifeThreatening);
		agAssertVisible(FDE_EventsPageObjects.R3Caused_ProlongedHospitalization);
		agAssertVisible(FDE_EventsPageObjects.R3Disability_PermanentDamage);
		agAssertVisible(FDE_EventsPageObjects.R3CongenitalAnomaly_BirthDefect);
		agAssertVisible(FDE_EventsPageObjects.R3OtherMedicallyImportantCondition);
		agAssertVisible(FDE_EventsPageObjects.R3RequiredIntervention);
		Reports.ExtentReportLog("", Status.INFO, "********Event R3 tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify Codelist tags in Event tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 20-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyEventCodeList() {
		Reports.ExtentReportLog("", Status.INFO, "********Event Codelist tag verification Started*******", true);
		agAssertVisible(FDE_EventsPageObjects.CLCodingType);
		agAssertVisible(FDE_EventsPageObjects.CLNativeLanguage);
		agAssertVisible(FDE_EventsPageObjects.ClHighlightTerm);
		agAssertVisible(FDE_EventsPageObjects.CLDuration);
		agAssertVisible(FDE_EventsPageObjects.CLCountryOfDetection);
		agAssertVisible(FDE_EventsPageObjects.CLMedicallyConfirmed);
		agAssertVisible(FDE_EventsPageObjects.CLEventType);
		agAssertVisible(FDE_EventsPageObjects.CLSeverity);
		agAssertVisible(FDE_EventsPageObjects.CLOutcome);
		agAssertVisible(FDE_EventsPageObjects.CLCausedbyLackofEffect);
		agAssertVisible(FDE_EventsPageObjects.CLCausedByDrugInteraction);
		agAssertVisible(FDE_EventsPageObjects.CLReactionSite);
		agAssertVisible(FDE_EventsPageObjects.CLExemptedEvents);
		agAssertVisible(FDE_EventsPageObjects.CLAnticipatedEvents);
		agAssertVisible(FDE_EventsPageObjects.CLSeriousness);
		agAssertVisible(FDE_EventsPageObjects.CLDeath);
		agAssertVisible(FDE_EventsPageObjects.CLLifeThreatening);
		agAssertVisible(FDE_EventsPageObjects.CLCaused_prolongedHospitalization);
		agAssertVisible(FDE_EventsPageObjects.CLDisability_PermanentDamage);
		agAssertVisible(FDE_EventsPageObjects.CLCongenitalAnomaly_BirthDefect);
		agAssertVisible(FDE_EventsPageObjects.CLOtherMedicallyImportantCondition);
		agAssertVisible(FDE_EventsPageObjects.CLRequiredIntervention);
		agAssertVisible(FDE_EventsPageObjects.CLTreatmentPerformed);
		agAssertVisible(FDE_EventsPageObjects.CLStartLatency);
		agAssertVisible(FDE_EventsPageObjects.CLEndLatency);
		// agAssertVisible(FDE_EventsPageObjects.CLUnanticipatedSeriousdeteriorationinstateofHealt);
		// agAssertVisible(FDE_EventsPageObjects.CLSeriousPublicHealthThreat);
		// agAssertVisible(FDE_EventsPageObjects.CLLocationWhereEventNotOccured);
		// agAssertVisible(FDE_EventsPageObjects.CLIMDRFCodesUsedForIdentifyingSimilarIncidents);
		// agAssertVisible(FDE_EventsPageObjects.CLBasisOfSimilarIncidentIdentification);
		// agAssertVisible(FDE_EventsPageObjects.CLCriteriaForDevicesInMarket);
		Reports.ExtentReportLog("", Status.INFO, "********Event Codelist tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Event Name and OnSet Date
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 14-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setEventNameAndOnSetDateAsText(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(FDE_EventsPageObjects.eventInfo_Label);
		agSetValue(FDE_EventsPageObjects.reportedTerm_Textfield,
				getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		agSetValue(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date),
				getTestDataCellValue(scenarioName, "Events_EventInformation_OnsetDate"));

		/*Reports.ExtentReportLog("", Status.PASS, "Event Reported Term" + ": "
				+ getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"), true);
		Reports.ExtentReportLog("", Status.PASS,
				"Event Onset Date" + ": " + getTestDataCellValue(scenarioName, "Events_EventInformation_OnsetDate"),
				true);*/

		Reports.ExtentReportLog("", Status.PASS, "", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit Event Name and OnSet Date
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 14-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void editEventNameAndOnSetDateAsText(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(FDE_EventsPageObjects.eventInfo_Label);

		agSetValue(FDE_EventsPageObjects.reportedTerm_Textfield,
				getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		agClearText(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date));
		agSetValue(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date),
				getTestDataCellValue(scenarioName, "Events_EventInformation_OnsetDate"));

		Reports.ExtentReportLog("", Status.PASS, "", true);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to click on Add button
	 * @InputParameters: 
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 14-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AddEventBtn() {
		if (agIsVisible(FDE_EventsPageObjects.addButton)) {
			agClick(FDE_EventsPageObjects.addButton);
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Duration,Latency and Meddra
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Kishore K R
	 * @Date : 4-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void eventDurationLatencyVerification(String scenarioName) {
		getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(FDE_EventsPageObjects.clickMultipleEvents(getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm")));
		CommonOperations.verifyData(FDE_EventsPageObjects.eventMedDRALLTCode, scenarioName,"Events_EventInformation_EventMedDRALLTCode","title");
		CommonOperations.verifyData(FDE_EventsPageObjects.setData_Textfields(FDE_EventsPageObjects.duration_Textbox), scenarioName,
				"Events_EventInformation_Duration","title");
		CommonOperations.verifyData(FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.duration_Textbox),scenarioName,"Events_EventInformation_DurationUnit","text");
		agJavaScriptExecuctorClick(FDE_EventsPageObjects.latency_Label);
		CommonOperations.verifyData(FDE_EventsPageObjects.startLatency_Textfield, scenarioName, "Events_Latency_StartLatency","title");
		CommonOperations.verifyData(FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.startLatency_DropDown),scenarioName,"Events_Latency_StartLatencyUnit","text");
		CommonOperations.verifyData(FDE_EventsPageObjects.endLatency_Textfield, scenarioName, "Events_Latency_EndLatency","title");
		CommonOperations.verifyData(FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.endLatency_DropDown),scenarioName,"Events_Latency_EndLatencyUnit","text");
		
	}
	
	/**********************************************************************************************************
	 * @Objective: Verify Exempted Events Checkbox is selected in Events Tab.
	 *             
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Abhisek Ghosh
	 * @Date : 8-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyExemptedEvents_checkbox() {
		Reports.ExtentReportLog("", Status.INFO, "verify Exempted Events Checkbox Selection", true);
		
		//FDE_Operations.tabNavigation("Event(s)");	
		agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.exemptedEvents_Label);
		String checkBoxStatus = agGetAttribute("class", FDE_EventsPageObjects.exemptedEvents_checkbox);
		if (checkBoxStatus.contains("ui-state-active")) {
			Reports.ExtentReportLog("Exempted Events Checkbox", Status.PASS, "Exempted Events Checkbox is Selected", true);
		} else {
			Reports.ExtentReportLog("Exempted Events Checkbox", Status.FAIL, "Exempted Events Checkbox is not Selected", true);
		}
		
		
	}
	
	/**********************************************************************************************************
	 * @Objective: Verify Anticipated Events Checkbox is selected in Events Tab.
	 *             
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Abhisek Ghosh
	 * @Date : 8-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyAnticipatedEvents_checkbox() {
		Reports.ExtentReportLog("", Status.INFO, "verify Anticipated Events Checkbox Selection", true);
		
		//FDE_Operations.tabNavigation("Event(s)");
		agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.anticipatedEvents_Label);
		String checkBoxStatus = agGetAttribute("class", FDE_EventsPageObjects.anticipatedEvents_checkbox);
		if (checkBoxStatus.contains("ui-state-active")) {
			Reports.ExtentReportLog("Anticipated Events Checkbox", Status.PASS, "Anticipated Events Checkbox is Selected", true);
		} else {
			Reports.ExtentReportLog("Anticipated Events Checkbox", Status.FAIL, "Anticipated Events Checkbox is not Selected", true);
		}
				
	}	
	
	/**********************************************************************************************************
	 * @Objective: To verify Medically Confirmed in Patient tab
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Abhisek Ghosh
	 * @Date : 10-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_MedicallyConfirmed() {
		
		//FDE_Operations.tabNavigation("Event(s)");
		agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.eventMedicallyConfirmed_Label);
		if (agIsVisible(FDE_EventsPageObjects.radioBtnVerification(FDE_EventsPageObjects.medicallyConfirmedRadioBtn_Label)) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Medically Confirmed is Enabled in Event Tab", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Medically Confirmed not Enabled in Event Tab", true);
		}
	}



	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify the functionality of Manual Checkbox for Event Medically Confirmed 
	 * 			   field which is enabled at Application Parametre at case level.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :09-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void eventMdicallyConfirmed_ManualFlagEnabled() {
		
		String No = agGetAttribute("class",
				FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.medicallyConfirmedRadioBtn_Label, "No"));
		String Yes = agGetAttribute("class",
				FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.medicallyConfirmedRadioBtn_Label, "Yes"));
		
		if (Yes.contains("active")) {
			
			agClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.medicallyConfirmedRadioBtn_Label, "No"));
			FDE_Operations.LSMVSaveTheCase();
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.eventMedicallyConfirmed_Label);
			
			String NoBtn = agGetAttribute("class",
					FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.medicallyConfirmedRadioBtn_Label, "No"));
			if (NoBtn.contains("active")) {
				Reports.ExtentReportLog("Medically Confirmed - No - radio button selected on save", Status.PASS, "Medically Confirmed -No- radio is selected", true);
			} else {
				Reports.ExtentReportLog("Medically Confirmed - No - radio button selected on save", Status.FAIL, "Medically Confirmed -No- radio is not selected", true);

			}
			
			
			
			agClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.medicallyConfirmedRadioBtn_Label, "Yes"));
			FDE_Operations.LSMVSaveTheCase();
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.eventMedicallyConfirmed_Label);
			
			String YesBtn = agGetAttribute("class",
					FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.medicallyConfirmedRadioBtn_Label, "Yes"));
			if (YesBtn.contains("active")) {
				Reports.ExtentReportLog("Medically Confirmed - Yes - radio button selected on save", Status.PASS, "Medically Confirmed -Yes- radio is selected", true);
			} else {
				Reports.ExtentReportLog("Medically Confirmed - Yes - radio button selected on save", Status.FAIL, "Medically Confirmed -Yes- radio is not selected", true);

			}
			agSetStepExecutionDelay("3000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Operations.LSMVSaveTheCase(); 
			
		}
		
		else if (No.contains("active")) {
			
			agClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.medicallyConfirmedRadioBtn_Label, "Yes"));
			FDE_Operations.LSMVSaveTheCase();
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.eventMedicallyConfirmed_Label);
			
			String YesBtn = agGetAttribute("class",
					FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.medicallyConfirmedRadioBtn_Label, "Yes"));
			if (YesBtn.contains("active")) {
				Reports.ExtentReportLog("Medically Confirmed - Yes - radio button selected on save", Status.PASS, "Medically Confirmed -Yes- radio is selected", true);
			} else {
				Reports.ExtentReportLog("Medically Confirmed - Yes - radio button selected on save", Status.FAIL, "Medically Confirmed -Yes- radio is not selected", true);

			}
			
			agClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.medicallyConfirmedRadioBtn_Label, "No"));
			FDE_Operations.LSMVSaveTheCase();
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.eventMedicallyConfirmed_Label);
			
			String NoBtn = agGetAttribute("class",
					FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.medicallyConfirmedRadioBtn_Label, "No"));
			if (NoBtn.contains("active")) {
				Reports.ExtentReportLog("Medically Confirmed - No - radio button selected on save", Status.PASS, "Medically Confirmed -No- radio is selected", true);
			} else {
				Reports.ExtentReportLog("Medically Confirmed - No - radio button selected on save", Status.FAIL, "Medically Confirmed -No- radio is not selected", true);

			}
			
			agSetStepExecutionDelay("3000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Operations.LSMVSaveTheCase();
			
		}
		
		else {
		
		agClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.medicallyConfirmedRadioBtn_Label, "No"));
		FDE_Operations.LSMVSaveTheCase();
		agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.eventMedicallyConfirmed_Label);
		
		String NoBtn = agGetAttribute("class",
				FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.medicallyConfirmedRadioBtn_Label, "No"));
		if (NoBtn.contains("active")) {
			Reports.ExtentReportLog("Medically Confirmed - No - radio button selected on save", Status.PASS, "Medically Confirmed -No- radio is selected", true);
		} else {
			Reports.ExtentReportLog("Medically Confirmed - No - radio button selected on save", Status.FAIL, "Medically Confirmed -No- radio is not selected", true);

		}
		
		
		
		agClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.medicallyConfirmedRadioBtn_Label, "Yes"));
		FDE_Operations.LSMVSaveTheCase();
		agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.eventMedicallyConfirmed_Label);
		
		String YesBtn = agGetAttribute("class",
				FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.medicallyConfirmedRadioBtn_Label, "Yes"));
		if (YesBtn.contains("active")) {
			Reports.ExtentReportLog("Medically Confirmed - Yes - radio button selected on save", Status.PASS, "Medically Confirmed -Yes- radio is selected", true);
		} else {
			Reports.ExtentReportLog("Medically Confirmed - Yes - radio button selected on save", Status.FAIL, "Medically Confirmed -Yes- radio is not selected", true);

		}
		agSetStepExecutionDelay("3000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		FDE_Operations.LSMVSaveTheCase(); 
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify the functionality of Manual Checkbox for Exempted Events  
	 * 			   field which is enabled at Application Parametre at case level.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :09-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void exemptedEvent_ManualFlagEnabled() {
		
		String checkBoxStatus = agGetAttribute("class", FDE_EventsPageObjects.exemptedEvents_checkbox);
		
		if (checkBoxStatus.contains("ui-state-active")) {
			
			agClick(FDE_EventsPageObjects.exemptedEvents_checkbox);
			FDE_Operations.LSMVSaveTheCase();
			
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.exemptedEvents_Label);
			
			Reports.ExtentReportLog("", Status.INFO, "verify Exempted Events Checkbox Selection", true);
			
			String checkBoxStatus1 = agGetAttribute("class", FDE_EventsPageObjects.exemptedEvents_checkbox);
			if (checkBoxStatus1.contains("ui-state-active")) {
				Reports.ExtentReportLog("Exempted Events Checkbox", Status.FAIL, "Exempted Events Checkbox is Selected", true);
			} else {
				Reports.ExtentReportLog("Exempted Events Checkbox", Status.PASS, "Exempted Events Checkbox is not Selected", true);
			}
			
			agClick(FDE_EventsPageObjects.exemptedEvents_checkbox);
			FDE_Operations.LSMVSaveTheCase();
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.exemptedEvents_Label);
			
			Reports.ExtentReportLog("", Status.INFO, "verify Exempted Events Checkbox Selection", true);
			String checkBoxStatus2 = agGetAttribute("class", FDE_EventsPageObjects.exemptedEvents_checkbox);
			if (checkBoxStatus2.contains("ui-state-active")) {
				Reports.ExtentReportLog("Exempted Events Checkbox", Status.PASS, "Exempted Events Checkbox is Selected", true);
			} else {
				Reports.ExtentReportLog("Exempted Events Checkbox", Status.FAIL, "Exempted Events Checkbox is not Selected", true);
			}
			agSetStepExecutionDelay("3000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Operations.LSMVSaveTheCase();
			
		}
		
		else if (!checkBoxStatus.contains("ui-state-active")) {
			
			agClick(FDE_EventsPageObjects.exemptedEvents_checkbox);
			FDE_Operations.LSMVSaveTheCase();
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.exemptedEvents_Label);
			
			Reports.ExtentReportLog("", Status.INFO, "verify Exempted Events Checkbox Selection", true);
			String checkBoxStatus2 = agGetAttribute("class", FDE_EventsPageObjects.exemptedEvents_checkbox);
			if (checkBoxStatus2.contains("ui-state-active")) {
				Reports.ExtentReportLog("Exempted Events Checkbox", Status.PASS, "Exempted Events Checkbox is Selected", true);
			} else {
				Reports.ExtentReportLog("Exempted Events Checkbox", Status.FAIL, "Exempted Events Checkbox is not Selected", true);
			}
			
			agClick(FDE_EventsPageObjects.exemptedEvents_checkbox);
			FDE_Operations.LSMVSaveTheCase();
			
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.exemptedEvents_Label);
			
			Reports.ExtentReportLog("", Status.INFO, "verify Exempted Events Checkbox Selection", true);
			
			String checkBoxStatus1 = agGetAttribute("class", FDE_EventsPageObjects.exemptedEvents_checkbox);
			if (checkBoxStatus1.contains("ui-state-active")) {
				Reports.ExtentReportLog("Exempted Events Checkbox", Status.FAIL, "Exempted Events Checkbox is Selected", true);
			} else {
				Reports.ExtentReportLog("Exempted Events Checkbox", Status.PASS, "Exempted Events Checkbox is not Selected", true);
			}
			
			agSetStepExecutionDelay("3000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Operations.LSMVSaveTheCase();
			
		}
			
		else {
			agClick(FDE_EventsPageObjects.exemptedEvents_checkbox);
			FDE_Operations.LSMVSaveTheCase();
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.exemptedEvents_Label);
			
			Reports.ExtentReportLog("", Status.INFO, "verify Exempted Events Checkbox Selection", true);
			String checkBoxStatus2 = agGetAttribute("class", FDE_EventsPageObjects.exemptedEvents_checkbox);
			if (checkBoxStatus2.contains("ui-state-active")) {
				Reports.ExtentReportLog("Exempted Events Checkbox", Status.PASS, "Exempted Events Checkbox is Selected", true);
			} else {
				Reports.ExtentReportLog("Exempted Events Checkbox", Status.FAIL, "Exempted Events Checkbox is not Selected", true);
			}
			
			agClick(FDE_EventsPageObjects.exemptedEvents_checkbox);
			FDE_Operations.LSMVSaveTheCase();
			
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.exemptedEvents_Label);
			
			Reports.ExtentReportLog("", Status.INFO, "verify Exempted Events Checkbox Selection", true);
			
			String checkBoxStatus1 = agGetAttribute("class", FDE_EventsPageObjects.exemptedEvents_checkbox);
			if (checkBoxStatus1.contains("ui-state-active")) {
				Reports.ExtentReportLog("Exempted Events Checkbox", Status.FAIL, "Exempted Events Checkbox is Selected", true);
			} else {
				Reports.ExtentReportLog("Exempted Events Checkbox", Status.PASS, "Exempted Events Checkbox is not Selected", true);
			}
			
			agSetStepExecutionDelay("3000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Operations.LSMVSaveTheCase();
			
		}
		
	}	
		

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify the functionality of Manual Checkbox for Exempted Events  
	 * 			   field which is enabled at Application Parametre at case level.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :09-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void anticipatedEvent_ManualFlagEnabled() {
		
		String checkBoxStatus = agGetAttribute("class", FDE_EventsPageObjects.anticipatedEvents_checkbox);
		if (checkBoxStatus.contains("ui-state-active")) {
			
			agClick(FDE_EventsPageObjects.anticipatedEvents_checkbox);
			FDE_Operations.LSMVSaveTheCase();
			
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.anticipatedEvents_Label);
			
			Reports.ExtentReportLog("", Status.INFO, "verify Anticipated Events Checkbox Selection", true);
			String checkBoxStatus1 = agGetAttribute("class", FDE_EventsPageObjects.anticipatedEvents_checkbox);
			if (checkBoxStatus1.contains("ui-state-active")) {
				Reports.ExtentReportLog("Anticipated Events Checkbox", Status.FAIL, "Anticipated Events Checkbox is Selected", true);
			} else {
				Reports.ExtentReportLog("Anticipated Events Checkbox", Status.PASS, "Anticipated Events Checkbox is not Selected", true);
			}
			
			agClick(FDE_EventsPageObjects.anticipatedEvents_checkbox);
			FDE_Operations.LSMVSaveTheCase();
			
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.anticipatedEvents_Label);
			
			Reports.ExtentReportLog("", Status.INFO, "verify Anticipated Events Checkbox Selection", true);
			String checkBoxStatus2 = agGetAttribute("class", FDE_EventsPageObjects.anticipatedEvents_checkbox);
			if (checkBoxStatus2.contains("ui-state-active")) {
				Reports.ExtentReportLog("Anticipated Events Checkbox", Status.PASS, "Anticipated Events Checkbox is Selected", true);
			} else {
				Reports.ExtentReportLog("Anticipated Events Checkbox", Status.FAIL, "Anticipated Events Checkbox is not Selected", true);
			}
			agSetStepExecutionDelay("3000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Operations.LSMVSaveTheCase();			
		}
		
		else if (!checkBoxStatus.contains("ui-state-active")) {
			
			agClick(FDE_EventsPageObjects.anticipatedEvents_checkbox);
			FDE_Operations.LSMVSaveTheCase();
			
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.anticipatedEvents_Label);
			
			Reports.ExtentReportLog("", Status.INFO, "verify Anticipated Events Checkbox Selection", true);
			String checkBoxStatus1 = agGetAttribute("class", FDE_EventsPageObjects.anticipatedEvents_checkbox);
			if (checkBoxStatus1.contains("ui-state-active")) {
				Reports.ExtentReportLog("Anticipated Events Checkbox", Status.PASS, "Anticipated Events Checkbox is Selected", true);
			} else {
				Reports.ExtentReportLog("Anticipated Events Checkbox", Status.FAIL, "Anticipated Events Checkbox is not Selected", true);
			}
			
			agClick(FDE_EventsPageObjects.anticipatedEvents_checkbox);
			FDE_Operations.LSMVSaveTheCase();
			
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.anticipatedEvents_Label);
			
			Reports.ExtentReportLog("", Status.INFO, "verify Anticipated Events Checkbox Selection", true);
			String checkBoxStatus2 = agGetAttribute("class", FDE_EventsPageObjects.anticipatedEvents_checkbox);
			if (checkBoxStatus2.contains("ui-state-active")) {
				Reports.ExtentReportLog("Anticipated Events Checkbox", Status.FAIL, "Anticipated Events Checkbox is Selected", true);
			} else {
				Reports.ExtentReportLog("Anticipated Events Checkbox", Status.PASS, "Anticipated Events Checkbox is not Selected", true);
			}
			agSetStepExecutionDelay("3000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Operations.LSMVSaveTheCase();
		}
		
		else {
			
			agClick(FDE_EventsPageObjects.anticipatedEvents_checkbox);
			FDE_Operations.LSMVSaveTheCase();
			
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.anticipatedEvents_Label);
			
			Reports.ExtentReportLog("", Status.INFO, "verify Anticipated Events Checkbox Selection", true);
			String checkBoxStatus1 = agGetAttribute("class", FDE_EventsPageObjects.anticipatedEvents_checkbox);
			if (checkBoxStatus1.contains("ui-state-active")) {
				Reports.ExtentReportLog("Anticipated Events Checkbox", Status.PASS, "Anticipated Events Checkbox is Selected", true);
			} else {
				Reports.ExtentReportLog("Anticipated Events Checkbox", Status.FAIL, "Anticipated Events Checkbox is not Selected", true);
			}
			
			agClick(FDE_EventsPageObjects.anticipatedEvents_checkbox);
			FDE_Operations.LSMVSaveTheCase();
			
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.anticipatedEvents_Label);
			
			Reports.ExtentReportLog("", Status.INFO, "verify Anticipated Events Checkbox Selection", true);
			String checkBoxStatus2 = agGetAttribute("class", FDE_EventsPageObjects.anticipatedEvents_checkbox);
			if (checkBoxStatus2.contains("ui-state-active")) {
				Reports.ExtentReportLog("Anticipated Events Checkbox", Status.FAIL, "Anticipated Events Checkbox is Selected", true);
			} else {
				Reports.ExtentReportLog("Anticipated Events Checkbox", Status.PASS, "Anticipated Events Checkbox is not Selected", true);
			}
			agSetStepExecutionDelay("3000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Operations.LSMVSaveTheCase();
		}
		
	}	
		
		/*agClick(FDE_EventsPageObjects.anticipatedEvents_checkbox);
		FDE_Operations.LSMVSaveTheCase();
		
		agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.anticipatedEvents_Label);
		
		Reports.ExtentReportLog("", Status.INFO, "verify Anticipated Events Checkbox Selection", true);
		String checkBoxStatus1 = agGetAttribute("class", FDE_EventsPageObjects.anticipatedEvents_checkbox);
		if (checkBoxStatus1.contains("ui-state-active")) {
			Reports.ExtentReportLog("Anticipated Events Checkbox", Status.PASS, "Anticipated Events Checkbox is Selected", true);
		} else {
			Reports.ExtentReportLog("Anticipated Events Checkbox", Status.PASS, "Anticipated Events Checkbox is not Selected", true);
		}
		
		
		agClick(FDE_EventsPageObjects.anticipatedEvents_checkbox);
		FDE_Operations.LSMVSaveTheCase();
		
		agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.anticipatedEvents_Label);
		
		Reports.ExtentReportLog("", Status.INFO, "verify Anticipated Events Checkbox Selection", true);
		String checkBoxStatus2 = agGetAttribute("class", FDE_EventsPageObjects.anticipatedEvents_checkbox);
		if (checkBoxStatus2.contains("ui-state-active")) {
			Reports.ExtentReportLog("Anticipated Events Checkbox", Status.PASS, "Anticipated Events Checkbox is Selected", true);
		} else {
			Reports.ExtentReportLog("Anticipated Events Checkbox", Status.PASS, "Anticipated Events Checkbox is not Selected", true);
		}
		agSetStepExecutionDelay("3000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		FDE_Operations.LSMVSaveTheCase();
	}*/
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify the Exempted Events - Application Parametre at case level.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :09-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyExemptedEvents_AppParameters_CaseLevel(String scenarioName) {
		agSetStepExecutionDelay("5000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		 Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
         String boolExemptedEvents =getTestDataCellValue(scenarioName, "EnableExemptedEvents");
         System.out.println(boolExemptedEvents);
         if(boolExemptedEvents.equalsIgnoreCase("true"))
         {
        	 agSetStepExecutionDelay("5000");
        	 agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
        	 CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
        	 agSetStepExecutionDelay("10000");
        	 agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
        	 FDE_Operations.tabNavigation("Event(s)");
        	 
        	 agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.exemptedEvents_Label);
        	 
     		Reports.ExtentReportLog("", Status.INFO, "verify Manual Flag for Exempted Events at Case Level", true);
     		if (agIsVisible(FDE_EventsPageObjects.ExemptedEvents_Manual_checkbox) == true) {
    			Reports.ExtentReportLog("Manual Flag for Exempted Events Checkbox field", Status.PASS, "Manual Flag for Exempted Events Checkbox field is displayed at case level",
    					true);
    			
    			if((agGetAttribute("class", FDE_EventsPageObjects.ExemptedEvents_Manual_checkbox)).contains("active"))
    			{
       				FDE_Events.exemptedEvent_ManualFlagEnabled();
        		}
    			
    			else 
    			{
    				agClick(FDE_EventsPageObjects.ExemptedEvents_Manual_checkbox);
    				FDE_Events.exemptedEvent_ManualFlagEnabled();
    				agClick(FDE_EventsPageObjects.ExemptedEvents_Manual_checkbox);
    				FDE_Operations.LSMVSaveTheCase();
    			}
    		}
     		else
     		{
     			Reports.ExtentReportLog("Manual Flag for Exempted Events Checkbox field", Status.FAIL, "Manual Flag for Exempted Events Checkbox field is not displayed at case level",
    					true);
     		}
     		
         }
         
         else {
        	 agSetStepExecutionDelay("5000");
        	 agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
        	 CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
        	 agSetStepExecutionDelay("10000");
        	 agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
        	 FDE_Operations.tabNavigation("Event(s)");
        	 
        	 agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.exemptedEvents_Label);
        	 
     		Reports.ExtentReportLog("", Status.INFO, "verify Manual Flag for Exempted Events at Case Level when flag is disabled as App Parametre level", 
     				true);
     		if (agIsVisible(FDE_EventsPageObjects.ExemptedEvents_Manual_checkbox) == true) 
     		{
    			Reports.ExtentReportLog("Manual Flag for Exempted Events Checkbox field when flag is disabled as App Parametre level", 
    					Status.FAIL, "Manual Flag for Exempted Events Checkbox field is displayed at case level when flag is disabled as App Parametre level",
    					true);
     		}
     		else {
     			Reports.ExtentReportLog("Manual Flag for Exempted Events Checkbox field when flag is disabled as App Parametre level", 
    					Status.PASS, "Manual Flag for Exempted Events Checkbox field is not displayed at case level when flag is disabled as App Parametre level",
    					true);
     		}
        	 SystemAdministrationOperations.systemAdministrationNavigations("applicationParameters");
        	 SystemAdministrationOperations.systemAdministrationNavigations("CaseManagement");
        	 
        	 agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
        	 
        	 agClick(WorkFlowPageObjects
     				.CheckedCheckBox2(AppParameters_CaseManagementPageObjects.enableExemptedEvents_CheckBox));
        	agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.Save);
 			agWaitTillVisibilityOfElement(AppParameters_CaseManagementPageObjects.SaveOkBtn);
 			agSetStepExecutionDelay("8000");
 			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
 			Reports.ExtentReportLog("Exempted Events flag enabled at App Parametre level", Status.PASS, "Exempted Events Flag enabled successfully at Application Parametre Level", true);
 			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.SaveOkBtn);
 			
 			AppParameters_CaseManagement.verifyAppParameters_ExemptedEvents_CaseManagementTabDetails(scenarioName); 
        	 
 			agSetStepExecutionDelay("5000");
 			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
 			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
 			agSetStepExecutionDelay("10000");
 			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
 			FDE_Operations.tabNavigation("Event(s)");
 			
 			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.exemptedEvents_Label);
 			
     		Reports.ExtentReportLog("", Status.INFO, "verify Manual Flag for Exempted Events at Case Level", true);
     		if (agIsVisible(FDE_EventsPageObjects.ExemptedEvents_Manual_checkbox) == true) {
    			Reports.ExtentReportLog("Manual Flag for Exempted Events Checkbox field", Status.PASS, "Manual Flag for Exempted Events Checkbox field is displayed at case level",
    					true);
    			
    			if((agGetAttribute("class", FDE_EventsPageObjects.ExemptedEvents_Manual_checkbox)).contains("active"))
    			{
    				FDE_Events.exemptedEvent_ManualFlagEnabled();
    			}
    			
    			else 
    			{
    				agClick(FDE_EventsPageObjects.ExemptedEvents_Manual_checkbox);
    				FDE_Events.exemptedEvent_ManualFlagEnabled();
    				agClick(FDE_EventsPageObjects.ExemptedEvents_Manual_checkbox);
    				FDE_Operations.LSMVSaveTheCase();
    			}
     		}
     		else
     		{
     			Reports.ExtentReportLog("Manual Flag for Exempted Events Checkbox field", Status.FAIL, "Manual Flag for Exempted Events Checkbox field is not displayed at case level",
    					true);
     		}
         }		
	}
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify the Anticipated Events - Application Parametre at case level.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :09-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyAnticipatedEvents_AppParameters_CaseLevel(String scenarioName) {
		agSetStepExecutionDelay("5000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		 Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
         String boolAnticipatedEvents =getTestDataCellValue(scenarioName, "EnableAnticipatedEvents");
         System.out.println(boolAnticipatedEvents);
         if(boolAnticipatedEvents.equalsIgnoreCase("true"))
         {
        	 agSetStepExecutionDelay("5000");
        	 agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
        	 CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
        	 agSetStepExecutionDelay("10000");
        	 agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
        	 FDE_Operations.tabNavigation("Event(s)");
        	 
        	 agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.anticipatedEvents_Label);
        	 
     		Reports.ExtentReportLog("", Status.INFO, "verify Manual Flag for Anticipated Events at Case Level", true);
     		if (agIsVisible(FDE_EventsPageObjects.AnticipatedEvents_Manual_checkbox) == true) {
    			Reports.ExtentReportLog("Manual Flag for Anticipated Events Checkbox field", Status.PASS, "Manual Flag for Anticipated Events Checkbox field is displayed at case level",
    					true);
    			
    			if((agGetAttribute("class", FDE_EventsPageObjects.AnticipatedEvents_Manual_checkbox)).contains("active"))
    			{
    				FDE_Events.anticipatedEvent_ManualFlagEnabled();
        		}
    			
    			else 
    			{
    				agClick(FDE_EventsPageObjects.AnticipatedEvents_Manual_checkbox);
    				FDE_Events.anticipatedEvent_ManualFlagEnabled();
    				agClick(FDE_EventsPageObjects.AnticipatedEvents_Manual_checkbox);
    				FDE_Operations.LSMVSaveTheCase();
        		}
     		}
     		else
     		{
     			Reports.ExtentReportLog("Manual Flag for Anticipated Events Checkbox field", Status.FAIL, "Manual Flag for Anticipated Events Checkbox field is not displayed at case level",
    					true);
     		}
         }
         
         else {
        	 agSetStepExecutionDelay("5000");
        	 agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
        	 CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
        	 agSetStepExecutionDelay("10000");
        	 agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
        	 FDE_Operations.tabNavigation("Event(s)");
        	 
        	 agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.anticipatedEvents_Label);
        	 
     		Reports.ExtentReportLog("", Status.INFO, "verify Manual Flag for Anticipated Events at Case Level when flag is disabled as App Parametre level", 
     				true);
     		if (agIsVisible(FDE_EventsPageObjects.AnticipatedEvents_Manual_checkbox) == true) 
     		{
    			Reports.ExtentReportLog("Manual Flag for Anticipated Events Checkbox field when flag is disabled at App Parametre level", 
    					Status.FAIL, "Manual Flag for Anticipated Events Checkbox field is displayed at case level when flag is disabled as App Parametre level",
    					true);
     		}
     		else {
     			Reports.ExtentReportLog("Manual Flag for Anticipated Events Checkbox field when flag is disabled at App Parametre level", 
    					Status.PASS, "Manual Flag for Anticipated Events Checkbox field is not displayed at case level when flag is disabled as App Parametre level",
    					true);
     		}
        	 SystemAdministrationOperations.systemAdministrationNavigations("applicationParameters");
        	 SystemAdministrationOperations.systemAdministrationNavigations("CaseManagement");
        	 
        	 agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
        	 
        	 agClick(WorkFlowPageObjects
     				.CheckedCheckBox2(AppParameters_CaseManagementPageObjects.enableAnticipatedEvents_CheckBox));
        	agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.Save);
 			agWaitTillVisibilityOfElement(AppParameters_CaseManagementPageObjects.SaveOkBtn);
 			agSetStepExecutionDelay("8000");
 			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
 			Reports.ExtentReportLog("Anticipated Events flag enabled at App Parametre level", Status.PASS, "Anticipated Events Flag enabled successfully at Application Parametre Level", true);
 			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.SaveOkBtn);
 			
 			AppParameters_CaseManagement.verifyAppParameters_AnticipatedEvents_CaseManagementTabDetails(scenarioName); 
 			agSetStepExecutionDelay("5000");
 			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
 			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
 			agSetStepExecutionDelay("10000");
 			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
 			FDE_Operations.tabNavigation("Event(s)");
 			
 			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.anticipatedEvents_Label);
 			
     		Reports.ExtentReportLog("", Status.INFO, "verify Manual Flag for Anticipated Events at Case Level", true);
     		if (agIsVisible(FDE_EventsPageObjects.AnticipatedEvents_Manual_checkbox) == true) {
    			Reports.ExtentReportLog("Manual Flag for Anticipated Events Checkbox field", Status.PASS, "Manual Flag for Anticipated Events Checkbox field is displayed at case level",
    					true);
    			
    			
    			if((agGetAttribute("class", FDE_EventsPageObjects.AnticipatedEvents_Manual_checkbox)).contains("active"))
    			{
    				FDE_Events.anticipatedEvent_ManualFlagEnabled();
        		}
    			else 
    			{
    				agClick(FDE_EventsPageObjects.AnticipatedEvents_Manual_checkbox);
    				FDE_Events.anticipatedEvent_ManualFlagEnabled();
    				agClick(FDE_EventsPageObjects.AnticipatedEvents_Manual_checkbox);
    				FDE_Operations.LSMVSaveTheCase();
    			}
     		}
     		else
     		{
     			Reports.ExtentReportLog("Manual Flag for Anticipated Events Checkbox field", Status.FAIL, "Manual Flag for Anticipated Events Checkbox field is not displayed at case level",
    					true);
     		}
         }
	}        											
	
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify the Event Medically Confirmed - Application Parametre at case level.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :09-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyMedicallyConfirmed_AppParameters_CaseLevel(String scenarioName) {
		agSetStepExecutionDelay("5000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		 Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
         String boolMedicallyConfirmed =getTestDataCellValue(scenarioName, "EnableEventMedicallyConfirmed");
         System.out.println(boolMedicallyConfirmed);
         if(boolMedicallyConfirmed.equalsIgnoreCase("true"))
         {
        	 agSetStepExecutionDelay("5000");
        	 agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
        	 CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
        	 agSetStepExecutionDelay("10000");
        	 agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
        	 FDE_Operations.tabNavigation("Event(s)");
        	 
        	 agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.eventMedicallyConfirmed_Label);
        	 
     		Reports.ExtentReportLog("", Status.INFO, "verify Manual Flag for Event Medically Confirmed at Case Level", true);
     		if (agIsVisible(FDE_EventsPageObjects.medicallyConfirmed_Manual_checkbox) == true) {
    			Reports.ExtentReportLog("Manual Flag for Event Medically Confirmed field", Status.PASS, "Manual Flag for Event Meically Confirmed field is displayed at case level",
    					true);
    			
    			if((agGetAttribute("class", FDE_EventsPageObjects.medicallyConfirmed_Manual_checkbox)).contains("active"))
    			{
    				FDE_Events.eventMdicallyConfirmed_ManualFlagEnabled();
    				
    			}
    			else
    			{
    				agClick(FDE_EventsPageObjects.medicallyConfirmed_Manual_checkbox);
    				FDE_Events.eventMdicallyConfirmed_ManualFlagEnabled();
    				agClick(FDE_EventsPageObjects.medicallyConfirmed_Manual_checkbox);
    				FDE_Operations.LSMVSaveTheCase(); 
    			}
     		}
     		else
     		{
     			Reports.ExtentReportLog("Manual Flag for Event Medically Confirmed field", Status.FAIL, "Manual Flag for Event Meically Confirmed field is not displayed at case level",
    					true);
     		}
     		
         }
         
         else {
        	 
        	 agSetStepExecutionDelay("5000");
        	 agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
        	 CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
        	 agSetStepExecutionDelay("10000");
        	 agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
        	 FDE_Operations.tabNavigation("Event(s)");
        	 
        	 agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.eventMedicallyConfirmed_Label);
        	 
     		Reports.ExtentReportLog("", Status.INFO, "verify Manual Flag for Event Medically Confirmed at Case Level when flag is disabled at Application Parametre Level", 
     				true);
     		if (agIsVisible(FDE_EventsPageObjects.medicallyConfirmed_Manual_checkbox) == true) 
     		{
    			Reports.ExtentReportLog("Manual Flag for Event Medically Confirmed field when flag is disabled at Application Parametre Level", 
    					Status.FAIL, "Manual Flag for Event Medically Confirmed field is displayed at case level when flag is disabled at Application Parametre Level",
    					true);
     		}
     		
     		else {
     			Reports.ExtentReportLog("Manual Flag for Event Medically Confirmed field when flag is disabled at Application Parametre Level", 
    					Status.PASS, "Manual Flag for Event Medically Confirmed field is not displayed at case level when flag is disabled at Application Parametre Level",
    					true);
     		}
        	 SystemAdministrationOperations.systemAdministrationNavigations("applicationParameters");
        	 SystemAdministrationOperations.systemAdministrationNavigations("CaseManagement");
        	 
        	 agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
        	 
        	 agClick(WorkFlowPageObjects
     				.CheckedCheckBox2(AppParameters_CaseManagementPageObjects.enableEventMedicallyConfirmed_CheckBox));
        	agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.Save);
 			agWaitTillVisibilityOfElement(AppParameters_CaseManagementPageObjects.SaveOkBtn);
 			agSetStepExecutionDelay("8000");
 			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
 			Reports.ExtentReportLog("Event Medically Confirmed flag enabled at App Parametre level", Status.PASS, "Event Medically Flag enabled successfully at Application Parametre Level", true);
 			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.SaveOkBtn);
 			
 			AppParameters_CaseManagement.verifyAppParameters_EventMedicallyConfirmed_CaseManagementTabDetails(scenarioName); 
 			agSetStepExecutionDelay("5000");
 			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
 			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
 			agSetStepExecutionDelay("10000");
 			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
 			 FDE_Operations.tabNavigation("Event(s)");
 			 
 			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.eventMedicallyConfirmed_Label);
 			 
      		Reports.ExtentReportLog("", Status.INFO, "verify Manual Flag for Event Medically Confirmed at Case Level", true);
      		if (agIsVisible(FDE_EventsPageObjects.medicallyConfirmed_Manual_checkbox) == true) {
     			Reports.ExtentReportLog("Manual Flag for Event Medically Confirmed field", Status.PASS, "Manual Flag for Event Meically Confirmed field is displayed at case level",
     					true);
     			
     			if((agGetAttribute("class", FDE_EventsPageObjects.medicallyConfirmed_Manual_checkbox)).contains("active"))
     			{
     				FDE_Events.eventMdicallyConfirmed_ManualFlagEnabled();
     			}
     			
     			else 
     			{
     				agClick(FDE_EventsPageObjects.medicallyConfirmed_Manual_checkbox);
     				FDE_Events.eventMdicallyConfirmed_ManualFlagEnabled();
    				agClick(FDE_EventsPageObjects.medicallyConfirmed_Manual_checkbox);
    				FDE_Operations.LSMVSaveTheCase(); 
       			}
     		}
      		
     		else
     		{
     			Reports.ExtentReportLog("Manual Flag for Event Medically Confirmed field", Status.FAIL, "Manual Flag for Event Meically Confirmed field is not displayed at case level",
     					true);  			
      		}
     		}
         }
	
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify the Always Serious Event is selected at case level.
	 * @InputParameters: NA
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :18-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verify_AlwaysSeriousEventSelection_checkbox() {
		Reports.ExtentReportLog("", Status.INFO, "verify Always Serious Event Checkbox Selection", true);
		
		agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.alwaysSeriousEvent_Label);
		String checkBoxStatus = agGetAttribute("class", FDE_EventsPageObjects.alwaysSeriousEvent_checkbox);
		if (checkBoxStatus.contains("ui-state-active")) {
			Reports.ExtentReportLog("Always Serious Event Checkbox", Status.PASS, "Always Serious Event Checkbox is Selected", true);
		} else {
			Reports.ExtentReportLog("Always Seriuos Event Checkbox", Status.PASS, "Always Serious Event Checkbox is not Selected", true);
		}
		
	}
	
	
	public static void verify_AlwaysSeriousEventManual_checkbox() {
		Reports.ExtentReportLog("", Status.INFO, "verify Manual Flag for Always Serious Event at Case Level", true);
		
		agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.alwaysSeriousEvent_Label);
		
 		if (agIsVisible(FDE_EventsPageObjects.AlwaysSeriousEvent_Manual_checkbox) == true) {
			
 			Reports.ExtentReportLog("Manual Flag for Always Serious Event Checkbox field", Status.PASS, "Manual Flag for Always Serious Event Checkbox field is displayed at case level",
					true);
		} 
 		
 		else
 		{
 			Reports.ExtentReportLog("Manual Flag for Always Serious Event Checkbox field", Status.FAIL, "Manual Flag for Always Serious Event Checkbox field is not displayed at case level",
					true);
 		}
		
	}
	
	public static void AlwaysSeriousEventManual_checkbox_TurnOnOff(String scenarioName) {
		
		String checkBoxStatus = agGetAttribute("class", WorkFlowPageObjects
				.CheckedCheckBox2(AppParameters_CaseManagementPageObjects.allowManualSelectionofIsAlwaysSeriousEvent_CheckBox));
		
		if (checkBoxStatus.contains("ui-state-active")) 
		{
		/*SystemAdministrationOperations.systemAdministrationNavigations("applicationParameters");
   	 SystemAdministrationOperations.systemAdministrationNavigations("CaseManagement");*/
   	 
   	 agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
   	 
   	 agClick(WorkFlowPageObjects
				.CheckedCheckBox2(AppParameters_CaseManagementPageObjects.allowManualSelectionofIsAlwaysSeriousEvent_CheckBox));
   	agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.Save);
		agWaitTillVisibilityOfElement(AppParameters_CaseManagementPageObjects.SaveOkBtn);
		//agSetStepExecutionDelay("8000");
		//agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("Always Serious Event flag enabled at App Parametre level", Status.PASS, "Always Serious Event Flag enabled successfully at Application Parametre Level", true);
		agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.SaveOkBtn);
		
		AppParameters_CaseManagement.verifyAppParameters_AlwaysSeriousEventSelection_CaseManagementTabDetails(scenarioName);
		}
		
		else
		{
			/*SystemAdministrationOperations.systemAdministrationNavigations("applicationParameters");
	   	 SystemAdministrationOperations.systemAdministrationNavigations("CaseManagement");*/
	   	 
	   	 agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
	   	 
	   	 agClick(WorkFlowPageObjects
					.CheckedCheckBox2(AppParameters_CaseManagementPageObjects.allowManualSelectionofIsAlwaysSeriousEvent_CheckBox));
	   	agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.Save);
			agWaitTillVisibilityOfElement(AppParameters_CaseManagementPageObjects.SaveOkBtn);
			//agSetStepExecutionDelay("8000");
			//agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("Always Serious Event flag enabled at App Parametre level", Status.PASS, "Always Serious Event Flag enabled successfully at Application Parametre Level", true);
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.SaveOkBtn);
			
			AppParameters_CaseManagement.verifyAppParameters_AlwaysSeriousEventSelection_CaseManagementTabDetails(scenarioName);
		}
		
	}
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify the Exempted Events - Application Parametre at case level.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :19-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyAlwaysSeriousEvent_AppParameters_CaseLevel(String scenarioName) {
		//agSetStepExecutionDelay("5000");
		//agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		 Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
         String boolAlwaysSeriousEvent =getTestDataCellValue(scenarioName, "AllowManualSelectionofIsAlwaysSeriousEvent");
         System.out.println(boolAlwaysSeriousEvent);
         if(boolAlwaysSeriousEvent.equalsIgnoreCase("true"))
         {
        	 //agSetStepExecutionDelay("5000");
        	 //agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
        	 CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
        	 //agSetStepExecutionDelay("10000");
        	 //agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
        	 FDE_Operations.tabNavigation("Event(s)");
        	 
        	 agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.alwaysSeriousEvent_Label);
        	 
     		Reports.ExtentReportLog("", Status.INFO, "verify Manual Flag for Always Serious Event at Case Level", true);
     		if (agIsVisible(FDE_EventsPageObjects.AlwaysSeriousEvent_Manual_checkbox) == true) {
    			
     			Reports.ExtentReportLog("Manual Flag for Always Serious Event Checkbox field", Status.PASS, "Manual Flag for Always Serious Event Checkbox field is displayed at case level",
    					true);
    			
    			
     				//agJavaScriptExecuctorClick(FDE_EventsPageObjects.AlwaysSeriousEvent_Manual_checkbox);
     				agClick(FDE_EventsPageObjects.AlwaysSeriousEvent_Manual_checkbox);
    				agWaitTillVisibilityOfElement(FDE_EventsPageObjects.alwaysSeriousEvent_confirmationBox);
    				agClick(FDE_EventsPageObjects.alwaysSeriousEvent_confirmationBox_Submit);
    				agClick(FDE_EventsPageObjects.AlwaysSeriousEvent_Manual_checkbox);
    				agSetStepExecutionDelay("5000");
    	        	agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
    	        	verify_AlwaysSeriousEventSelection_checkbox();
    	     		FDE_Operations.LSMVSaveTheCase();
    				
    				/*Reports.ExtentReportLog("Always Serious Event Checkbox", Status.PASS, 
    						"Always Serious Event Checkbox is updated", true);
    				
    				verify_AlwaysSeriousEventSelection_checkbox();*/
    		}
     		else
     		{
     			Reports.ExtentReportLog("Manual Flag for Always Serious Event Checkbox field", Status.FAIL, "Manual Flag for Always Serious Event Checkbox field is not displayed at case level",
    					true);
     		}
     		
         }
         
         else {
        	 //agSetStepExecutionDelay("5000");
        	 //agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
        	 CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
        	 //agSetStepExecutionDelay("10000");
        	 //agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
        	 FDE_Operations.tabNavigation("Event(s)");
        	 
        	 agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.alwaysSeriousEvent_Label);
        	 
     		Reports.ExtentReportLog("", Status.INFO, "verify Manual Flag for Always Serious Event at Case Level when flag is disabled as App Parametre level", 
     				true);
     		if (agIsVisible(FDE_EventsPageObjects.AlwaysSeriousEvent_Manual_checkbox) == true) 
     		{
    			Reports.ExtentReportLog("Manual Flag for Always Serious Event Checkbox field when flag is disabled as App Parametre level", 
    					Status.FAIL, "Manual Flag for Always Serious Event Checkbox field is displayed at case level when flag is disabled as App Parametre level",
    					true);
     		}
     		else {
     			Reports.ExtentReportLog("Manual Flag for Always Serious Event Checkbox field when flag is disabled as App Parametre level", 
    					Status.PASS, "Manual Flag for Always Serious Event Checkbox field is not displayed at case level when flag is disabled as App Parametre level",
    					true);
     		}
        	 SystemAdministrationOperations.systemAdministrationNavigations("applicationParameters");
        	 SystemAdministrationOperations.systemAdministrationNavigations("CaseManagement");
        	 
        	 agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
        	 
        	 agClick(WorkFlowPageObjects
     				.CheckedCheckBox2(AppParameters_CaseManagementPageObjects.allowManualSelectionofIsAlwaysSeriousEvent_CheckBox));
        	agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.Save);
 			agWaitTillVisibilityOfElement(AppParameters_CaseManagementPageObjects.SaveOkBtn);
 			//agSetStepExecutionDelay("8000");
 			//agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
 			Reports.ExtentReportLog("Always Serious Event flag enabled at App Parametre level", Status.PASS, "Always Serious Event Flag enabled successfully at Application Parametre Level", true);
 			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.SaveOkBtn);
 			
 			AppParameters_CaseManagement.verifyAppParameters_AlwaysSeriousEventSelection_CaseManagementTabDetails(scenarioName); 
        	 
 			//agSetStepExecutionDelay("5000");
 			//agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
 			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
 			//agSetStepExecutionDelay("10000");
 			//agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
       	 FDE_Operations.tabNavigation("Event(s)");
    	 
       	 agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.alwaysSeriousEvent_Label);
       	 
    		Reports.ExtentReportLog("", Status.INFO, "verify Manual Flag for Always Serious Event at Case Level", true);
    		if (agIsVisible(FDE_EventsPageObjects.AlwaysSeriousEvent_Manual_checkbox) == true) {
   			
    			Reports.ExtentReportLog("Manual Flag for Always Serious Event Checkbox field", Status.PASS, "Manual Flag for Always Serious Event Checkbox field is displayed at case level",
   					true);
   			
   			
   				//agJavaScriptExecuctorClick(FDE_EventsPageObjects.AlwaysSeriousEvent_Manual_checkbox);
    			agClick(FDE_EventsPageObjects.AlwaysSeriousEvent_Manual_checkbox);
   				agWaitTillVisibilityOfElement(FDE_EventsPageObjects.alwaysSeriousEvent_confirmationBox);
   				agClick(FDE_EventsPageObjects.alwaysSeriousEvent_confirmationBox_Submit);
   				agClick(FDE_EventsPageObjects.AlwaysSeriousEvent_Manual_checkbox);
   				verify_AlwaysSeriousEventSelection_checkbox();
	     		FDE_Operations.LSMVSaveTheCase();
   				
   				/*Reports.ExtentReportLog("Always Serious Event Checkbox", Status.PASS, 
						"Always Serious Event Checkbox is updated", true);
   				
   				verify_AlwaysSeriousEventSelection_checkbox();*/
   		}
    		else
    		{
    			Reports.ExtentReportLog("Manual Flag for Always Serious Event Checkbox field", Status.FAIL, "Manual Flag for Always Serious Event Checkbox field is not displayed at case level",
   					true);
    		}
	}	
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to delete Event Information in
	 *             event tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Abhisek Ghosh
	 * @Date : 24-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void delete_EventInformation(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Event_DeleteData").equalsIgnoreCase("True")) {
			agClick(FDE_EventsPageObjects.eventsDelete_Button);
			agWaitTillVisibilityOfElement(FDE_EventsPageObjects.eventsDelete_YesButton);
			agClick(FDE_EventsPageObjects.eventsDelete_YesButton);
			
		}
	}
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to key date as text in LMP Date
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 25-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void keyCessationDateAsText(String sheetName, String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		System.out.println("Scenario Name: " + scenarioName);
		try {
			System.out.println("Event Cessation Date: " + getTestDataCellValue(scenarioName, "Cessation_Date"));
			agClearText(FDE_EventsPageObjects.cessationDateAsText);
			agSetValue(FDE_EventsPageObjects.cessationDateAsText, getTestDataCellValue(scenarioName, "Cessation_Date"));
			agSendKeyStroke(Keys.TAB);
			agSetStepExecutionDelay("2000");
			Reports.ExtentReportLog("", Status.PASS, "Data Keyed successfully", true);
			FDE_Operations.LSMVSaveReconsile();
		} catch (Exception e) {
			Reports.ExtentReportLog("", Status.FAIL, "<br />" + "Failed to key Patient's details for scenario.", false);
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 25-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void validateEventDuration(String scenarioName) {
		agClick(FDE_EventsPageObjects.medicalHistoryDurationValue);
		System.out.print("Actual Event Duration: " + agGetAttribute("title", FDE_EventsPageObjects.medicalHistoryDurationValue).trim());
		if (agGetAttribute("title", FDE_EventsPageObjects.medicalHistoryDurationValue).trim()
				.equalsIgnoreCase(getTestDataCellValue(scenarioName, "MedicalHistoryDuration"))) {
			Reports.ExtentReportLog("", Status.PASS, "Expected MedicalHistoryDuration value", true);
		}else {
			Reports.ExtentReportLog("", Status.FAIL, "Incorrect MedicalHistoryDuration value", true);
		}

		System.out.println(" " + agGetAttribute("title", FDE_EventsPageObjects.medicalHistoryDurationUnit).trim());
		if (agGetText(FDE_EventsPageObjects.medicalHistoryDurationUnit).trim()
				.equalsIgnoreCase(getTestDataCellValue(scenarioName, "MedicalHistoryDuration_Units"))) {
			Reports.ExtentReportLog("", Status.PASS, "Expected MedicalHistoryDuration_Units value", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Incorrect MedicalHistoryDuration_Units value", true);
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 25-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void validateStartAndEndLatency(String scenarioName) {
		agClick(FDE_EventsPageObjects.startLatency_Textfield);
		System.out.print("Actual Start Latency: " + agGetAttribute("title", FDE_EventsPageObjects.startLatency_Textfield).trim());
		if (agGetAttribute("title", FDE_EventsPageObjects.startLatency_Textfield).trim()
				.equalsIgnoreCase(getTestDataCellValue(scenarioName, "Event_StartLatency"))) {
			Reports.ExtentReportLog("", Status.PASS, "Expected Event_StartLatency value", true);
		}else {
			Reports.ExtentReportLog("", Status.FAIL, "Incorrect Event_StartLatency value", true);
		}
		
		if (agGetText(FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.startLatency_DropDown)).trim()
				.equalsIgnoreCase(getTestDataCellValue(scenarioName, "Event_StartLatency_Units"))) {
			Reports.ExtentReportLog("", Status.PASS, "Expected Event_StartLatency_Units value", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Incorrect Event_StartLatency_Units value", true);
		}
		
		
		agClick(FDE_EventsPageObjects.endLatency_Textfield);
		System.out.print("Actual End Latency: " + agGetAttribute("title", FDE_EventsPageObjects.endLatency_Textfield).trim());
		if (agGetAttribute("title", FDE_EventsPageObjects.endLatency_Textfield).trim()
				.equalsIgnoreCase(getTestDataCellValue(scenarioName, "Event_EndLatency"))) {
			Reports.ExtentReportLog("", Status.PASS, "Expected Event_EndLatency value", true);
		}else {
			Reports.ExtentReportLog("", Status.FAIL, "Incorrect Event_EndLatency value", true);
		}
		
		if (agGetText(FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.endLatency_DropDown)).trim()
				.equalsIgnoreCase(getTestDataCellValue(scenarioName, "Event_EndLatency_Units"))) {
			Reports.ExtentReportLog("", Status.PASS, "Expected Event_EndLatency_Units value", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Incorrect Event_EndLatency_Units value", true);
		}
	}
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to key date as text in LMP Date
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 04-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void keyEventOnset_CessationDateAsText(String scenarioName) {
		System.out.println("Scenario Name: " + scenarioName);
		
		try {
			//Event Onset Date
			agClearText(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date));
			agSetValue(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date),
					getTestDataCellValue(scenarioName, "Event_OnsetDate_AsText"));
			agSendKeyStroke(Keys.TAB);
			agSetStepExecutionDelay("2000");
			
			//Cessation Date
			agClearText(FDE_EventsPageObjects.cessationDateAsText);
			agSetValue(FDE_EventsPageObjects.cessationDateAsText, getTestDataCellValue(scenarioName, "Event_CessationDate"));
			agSendKeyStroke(Keys.TAB);
			agSetStepExecutionDelay("2000");
			
			
			Reports.ExtentReportLog("", Status.PASS, "Data Keyed successfully", true);
			FDE_Operations.LSMVSaveReconsile();
		} catch (Exception e) {
			Reports.ExtentReportLog("", Status.FAIL, "<br />" + "Failed to key Event details for scenario.", false);
		}
	}
	
	//added by rashmi'
	
	public static void setNullFlavourDropDownValue(String label, String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agSetStepExecutionDelay("2000");
			agJavaScriptExecuctorClick(FDE_EventsPageObjects.NullFlavourDropDown(label));
			agSetStepExecutionDelay("2000");
			System.out.println(getTestDataCellValue(scenarioName, columnName));
			agClick(FDE_EventsPageObjects.setdropDownValue(getTestDataCellValue(scenarioName, columnName)));

		}
	}
	

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteEvent(){
		agSetStepExecutionDelay("3000");
		agJavaScriptExecuctorClick(FDE_EventsPageObjects.DeleteEvent);
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorClick(FDE_EventsPageObjects.YesBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to key date as text in LMP Date
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Padmapriya
	 * @Date : 10-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void DeleteCessationDate() {
			agClearText(FDE_EventsPageObjects.cessationDateAsText);
			Reports.ExtentReportLog("", Status.PASS, "Cessation Date deleted successfully", true);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to downgrade Always Seriou Event and set Other Medical History to No.
	 * @InputParameters: 
	 * @OutputParameters:
	 * @author: Abhisek
	 * @Date : 22-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setOtherMedicalHistory_No() {
		
		if(agIsVisible(FDE_EventsPageObjects.alwaysSeriousEvent_checkbox)) {
			String checkBoxStatus = agGetAttribute("class", FDE_EventsPageObjects.alwaysSeriousEvent_checkbox);
			if (checkBoxStatus.contains("ui-state-active")) {
				
				agClick(FDE_EventsPageObjects.AlwaysSeriousEvent_Manual_checkbox);
				agWaitTillVisibilityOfElement(FDE_EventsPageObjects.alwaysSeriousEvent_confirmationBox);
				agClick(FDE_EventsPageObjects.alwaysSeriousEvent_confirmationBox_Submit);
				//agClick(FDE_EventsPageObjects.AlwaysSeriousEvent_Manual_checkbox);
				agSetStepExecutionDelay("5000");
		    	agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		 		agClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.OtherMedicallyCondition_Radiobtn, "No"));
		 		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			} 
			
			else {
				
				agClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.OtherMedicallyCondition_Radiobtn, "No"));
			}

		}
		
		else {
			
			Reports.ExtentReportLog("", Status.FAIL, "Always Serious Event Manual Flag not enabled at Application Parametre Level",
					true);
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to Navigate to events 
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 22-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void eventNavagation(String scenarioName , String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agJavaScriptExecuctorClick(FDE_EventsPageObjects.clickEventRecord(getTestDataCellValue(scenarioName, columnName)));
		agSetStepExecutionDelay("3000");
	}
	

	/***********************************************************************************************************************
	 * @Objective: The below method is to set Event Outcome
	 *             Date
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 22-Mar-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setEventOutcome(String scenarioName) {
		
		if (!getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome").equalsIgnoreCase("#skip#")) {
				
				agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.IME_Label);
				setDropDownValue(FDE_EventsPageObjects.outCome_DropDown, scenarioName, "Events_EventInformation_Outcome");
				agSetStepExecutionDelay("5000");
				agCheckPropertyText(getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome"),
						FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.outCome_DropDown));
				Reports.ExtentReportLog("", Status.PASS, "Event Outcome set to "+getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome"),
						true);
			}
	}
	
	/***********************************************************************************************************************
	 * @Objective: The below method is to Update Event data
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 22-Mar-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void UpdateEventData(String scenarioName,String Condition) {
		
		if(Condition.equalsIgnoreCase("UpdateEvent")) {
		//	agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.SecondEvent);
			
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			Reports.ExtentReportLog("", Status.INFO, "",
					true);
			agJavaScriptExecuctorClick(FDE_EventsPageObjects.eventInfo_Label);
			agSetValue(FDE_EventsPageObjects.reportedTerm_Textfield,
					getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
			agSendKeyStroke(Keys.TAB);
			agSetStepExecutionDelay("5000");
			if(agIsVisible(FDE_EventsPageObjects.YesBtn)) {
				agJavaScriptExecuctorClick(FDE_EventsPageObjects.YesBtn);
			}
			agSetStepExecutionDelay("5000");
			set_EventMedDRALLTCode(scenarioName);
			agSetStepExecutionDelay("3000");
			
			FDE_Operations.LSMVSaveReconsile();
			Reports.ExtentReportLog("", Status.PASS, "The data is updated as per test data and case is saved",
					true);
			
		}
		if(Condition.equalsIgnoreCase("Outcome")) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			Reports.ExtentReportLog("", Status.INFO, "",
					true);
			agSetStepExecutionDelay("3000");
			Actions actions = new Actions(driver);
			WebElement element = driver.findElement(By.xpath(
					"//a//span[@class='ui-tabview-title' and contains(text(),'2.')]"));
			actions.doubleClick(element).perform();
			agSetStepExecutionDelay("5000");
			setDropDownValue(FDE_EventsPageObjects.outCome_DropDown, scenarioName, "Events_EventInformation_Outcome");
			FDE_Operations.LSMVSaveReconsile();
			Reports.ExtentReportLog("", Status.PASS, "The data is updated as per test data and case is saved",
					true);
		}
		if(Condition.equalsIgnoreCase("DeleteEvent")) {
			Reports.ExtentReportLog("", Status.INFO, "",
					true);
			agSetStepExecutionDelay("3000");
			
			agJavaScriptExecuctorClick(FDE_EventsPageObjects.DeleteEvent);
			
			agSetStepExecutionDelay("5000");	
			
			if(agIsVisible(FDE_EventsPageObjects.YesBtn)) {
				agJavaScriptExecuctorClick(FDE_EventsPageObjects.YesBtn);
			}
			agSetStepExecutionDelay("5000");
			FDE_Operations.LSMVSaveReconsile();
			Reports.ExtentReportLog("", Status.PASS, "The data is updated as per test data and case is saved",
					true);
			
		}
		
		
	}


	
	public static void setNullFlavourDropDownValue(String label, String scenarioName, String columnName,String sheetname) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetname);
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agSetStepExecutionDelay("2000");
			agJavaScriptExecuctorClick(FDE_EventsPageObjects.NullFlavourDropDown(label));
			agSetStepExecutionDelay("2000");
			System.out.println(getTestDataCellValue(scenarioName, columnName));
			agClick(FDE_EventsPageObjects.setdropDownValue(getTestDataCellValue(scenarioName, columnName)));
		}
	}
	
	
	

	
}
