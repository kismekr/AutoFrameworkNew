package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class ReconciliationPageObjects {

	public static String followupAlert_header = "xpath#//span[text()='Follow-Up Notification Alert']";
	public static String reconcileNotification_header = "xpath#//div[@id='followupReconciliationId']//span[text()='Reconciliation Notification Alert']";
	public static String followupAlert_Window = "xpath#//div[@id='followupNotificationAlertId']";
	public static String reconcileNotification_Window = "xpath#//div[@id='followupReconciliationAlertId']";
	public static String yes_Btn = "xpath#//div[@id='followupNotificationId']/div//button[contains(text(),'Yes')]";
	public static String no_Btn = "xpath#//div[@id='followupNotificationId']/div//button[contains(text(),'No')]";
	public static String yesR_Btn = "xpath#//div[@id='followupReconciliationId']//button[contains(text(),'Yes')]";
	public static String noR_Btn = "xpath#//div[@id='followupReconciliationId']//button[contains(text(),'No')]";
	public static String ok_Btn = "xpath#//button[contains(@id,'adverseEventNew')]/span[text()='OK']";
	public static String reconciliation_Header = "xpath#(//div[@id='compareReconcileDialogModel']/div/div/span[text()='Reconciliation'])[1]";
	public static String reconcilitionCheckBox = "xpath#//td/label[text()='%s']/ancestor::td/div/child::div[2]";
	public static String appendtoExisting_Btn = "xpath#//button[text()='Append To Existing']";
	public static String appendtoExisting_Loadingicon = "xpath#//div[@id='headerForm:angularLoader']/img";
	public static String validationPopup = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String validationMsg = "xpath#//span[contains(@class,'lsmv-info-message')]";
	public static String validationOk_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']/span[text()='OK']";
	public static String columnHeaderList = "xpath#//thead[@id='adverseFollowupID:safetyDataTable_head']/tr/th[contains(@id,'adverseFollowupID:safetyDataTable')]/span/label[2]";
	public static String reconciliationIcon = "xpath#//a[@id='adverseEventNew:reconcilation']/img";
	// public static String submit_Btn = "xpath#//button/span[text()='Submit']";
	public static String submit_Btn = "xpath#//button[text()='Submit']";
	public static String loadingIcon = "xpath#//div[@id='exportXmlviewForm:statusDialogId']/child::div/label";
	public static String createNewVersion_Btn = "xpath#//button[@id='adverseFollowupID:validateCreateNewVersion']/span[text()='Create New Version']";

	public static String loading = "xpath#//div[@id='headerForm:angularLoader']/img";

	public static String showmoreLink = "xpath#//div[@id='showMoreReconcileRecsLink']";

	public static String downloadIcon = "xpath#//a[@id='adverseFollowupID:caseComparisionActionId']/img";
	public static String exportToexcelLink = "xpath#//button[@id='adverseFollowupID:caseComparisionexcelID']";
	public static String exportToexcelPopup = "xpath#//span[@id='adverseFollowupID:dailogToExportShowHide_title']";
	public static String exportToexcelBtn = "xpath#//button[@id='adverseFollowupID:caseComparisionhiddenExportIdIn']";

	public static String exportToexcel_closeicon = "xpath#//div[@id='adverseFollowupID:dailogToExportShowHide']//a[@aria-label='Close']";

	public static String columnHeader = "xpath#(//thead[@id='adverseFollowupID:safetyDataTable_head']/tr/th[contains(@id,'adverseFollowupID:safetyDataTable')]/span/label[2])[{0}]";
	public static String caseDataAttributesList = "xpath#//tbody[@id='adverseFollowupID:safetyDataTable_data']/tr[not(contains(@class,'hiddenRowStyle'))]/td[contains(@class,'col-leftNew recocolleft')]";
	public static String caseDataAttributes = "xpath#(//tbody[@id='adverseFollowupID:safetyDataTable_data']/tr[not(contains(@class,'hiddenRowStyle'))]/td[contains(@class,'col-leftNew recocolleft')]/div/label[@class='ui-outputlabel ui-widget'])[{0}]";
	public static String followUpCase = "xpath#(//tbody[@id='adverseFollowupID:safetyDataTable_data']/tr[@role='row'][not(contains(@class, 'hiddenRowStyle'))]/td//div/label[contains(@id,'valCol1')])[{0}]";
	public static String masterCase = "xpath#(//tbody[@id='adverseFollowupID:safetyDataTable_data']/tr[@role='row'][not(contains(@class, 'hiddenRowStyle'))]/td[not(contains(@style,'display : none'))][contains(@class,'uncheckHideContent0')])[{0}]";
	public static String mergedCase = "xpath#(//tbody[@id='adverseFollowupID:safetyDataTable_data']/tr[@role='row'][not(contains(@class, 'hiddenRowStyle'))]/td[not(contains(@style,'display : none'))][contains(@class,'uncheckHideContent1')])[{0}]";
	public static String closeButton = "xpath#//span[@id='adverseFollowupID:safetyComparisonDialog_title']/ancestor::div/a[@role='button'][@aria-label='Close']";

	public static String ReconciliationChkboxes = "xpath#//label[contains(text(),'%s')]/input[@type='checkbox']";
	public static String PopUpValidation = "xpath#//label[contains(text(),'Highlight differences')]";
	public static String ReconsileYesBtn = "xpath#//div[@id='followupReconciliationId']//button[text()='Yes']";
	public static String ReconsileNoBtn = "xpath#//div[@id='followupReconciliationId']//button[text()='No']";
	// Labels
	public static String highlightdif_Checkbox = "Highlight differences";
	public static String hidecommonData_Checkbox = "Hide common Data";

	public static String ReporterPrimarySource_Checkbox = "xpath#(//input[@fieldid='105058'])[1]";
	public static String ReporterTitle_Checkbox = "xpath#(//input[@fieldid='105102'])[1]";
	public static String ReporterFirstname_Checkbox = "xpath#(//input[@fieldid='105104'])[1]";
	public static String ReporterLastname_Checkbox = "xpath#(//input[@fieldid='105108'])[1]";
	public static String ReporterHospitalname_Checkbox = "xpath#(//input[@fieldid='105110'])[1]";
	public static String ReporterCity_Checkbox = "xpath#(//input[@fieldid='105116'])[1]";
	public static String ReporterCountry_Checkbox = "xpath#(//input[@fieldid='105122'])[1]";
	public static String ReporterQualification_Checkbox = "xpath#(//input[@fieldid='105614'])[1]";
	public static String showMore_link = "xpath#//div[text()='Show More']";
	public static String click_cancel = "xpath#//button[@id='adverseEventNew:j_id_1a0']/span[text()='Cancel']";
	public static String EventOutcome_Checkbox = "xpath#(//input[@fieldid='111127'])[1]";
	public static String EventSeriouness_Checkbox = "xpath#(//input[@fieldid='111159'])[1]";
	public static String EventProlongedHosp_Checkbox = "xpath#(//input[@fieldid='111152'])[1]";
	public static String createNewVersionBtn = "xpath#//div[@id='compareReconcileDialogModel']/div//button[@class='createNewVersionClass' and contains(text(),'Create New Version')]";
	public static String alwaysSeriousChkBox = "xpath#(//div[@id='compareReconcileDialogModel']//td[contains(text(),'Seriousness')]//parent::tr//td[2]//div//input)[1]";
	public static String followUpIcon = "xpath#//a[@id='adverseEventNew:fallowupActionId1']";

	public static String rejectRecord1 = "xpath#//div[@id='reconcileTbodyCmp']/div[6]/div[2]/div/div[2]/div[2]/div/div[4]/div[2]/div/div[2]/div[1]/div[2]/span[text()='Reject Record']";
	public static String rejectRecord2 = "xpath#//div[@id='reconcileTbodyCmp']/div[6]/div[2]/div/div[3]/div[2]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/span[text()='Reject Record']";
	public static String rejectRecord3 = "xpath#//div[@id='reconcileTbodyCmp']/div[6]/div[2]/div/div[3]/div[2]/div[1]/div[5]/div[2]/div/div[2]/div[1]/div[2]/span[text()='Reject Record']";

	public static String rejectRecord2_1 = "xpath#//div[@id='reconcileTbodyCmp']/div[6]/div[2]/div/div[1]/div[2]/div/div[5]/div[2]/div/div[2]/div[1]/div/span[text()='Reject Record']";
	public static String rejectRecord2_3 = "xpath#//div[@id='reconcileTbodyCmp']/div[6]/div[2]/div/div[2]/div[2]/div/div[5]/div[2]/div/div[2]/div[1]/div[2]/span[text()='Reject Record']";
	public static String rejectRecord2_4 = "xpath#//div[@id='reconcileTbodyCmp']/div[6]/div[2]/div/div[3]/div[2]/div/div[4]/div[2]/div/div[2]/div[1]/div[2]/span[text()='Reject Record']";

	// Case Significance scenario#3
	public static String rejectRecord_study = "xpath#(//span/span[contains(text(),'Approved for ')])[2]/parent::span/../following::div[1]/span";
	public static String rejectRecord_therapies = "xpath#(//span/span[contains(text(),'Therapies')])[3]/parent::span/../following::div[1]/span";

	// Case Significance scenario#10
	public static String therapyRejectRec = "xpath#//span[contains(text(),'%prodName%')]//following::div[@class='childNodePanel diffDataPanel'][2]//div[@class='lsmv-node-main rep-rec-object'][2]//span[text()='Reject Record']";

	// CaseSignificance scneario09
	public static String prodcheckbox = "xpath#//span[@flpath='aerInfo.safetyReport.patient.drugCollection$.reportedMedicinalProduct']";
	public static String ingredientsChecbox = "xpath#(//span/span[contains(text(),'Ingredients')]/parent::span/../following::div[1]/span)[2]";
	public static String secTherapyReject = "xpath#(//span/span[contains(text(),'Therapies')]/parent::span/../following::div[1]/span)[4]";

	public static String nullificationcheckBox = "xpath#//*[contains(@flpath,'nullificationReason')]";
	public static String safetyReportIdCheckBox = "xpath#//*[contains(@flpath,'safetyReportId')]";
	public static String therapycheckBox = "xpath#(//*[contains(@flpath,'drugTherapyCollection')]//span[text()='Reject Record'])[2]";
	public static String approval1 = "xpath#(//*[text()='Reject Record'])[19]";
	public static String approval2 = "xpath#(//*[text()='Reject Record'])[19]";

	// Case Significance scenario#14
	public static String therapyRejectRecd = "xpath#(//span[contains(text(),'AEROSPAN')]//following::div[@class='childNodePanel diffDataPanel'][2]//div[@class='lsmv-node-main rep-rec-object'][2]//span[text()='Reject Record'])[1]";
	public static String RejectRecdLotno = "xpath#(//span[contains(text(),'AEROSPAN')]//following::div[@class='childNodePanel diffDataPanel'][2]//div[@class='lsmv-node-main rep-rec-object'][2]//span[text()='Reject Record'])[2]";
	public static String RejectEventDesc = "xpath#//*[@id=\"reconcileTbodyCmp\"]/div[8]/div[2]/div/div[1]/div[2]/div/div/div[2]/span[1]";

	public static String therapyRecordProd(String prodName) {
		String value = therapyRejectRec;
		String value2;
		value2 = value.replace("%prodName%", prodName);
		return value2;
	}

	// added by rashmi
	public static String reconcilecheckbox = "xpath#//div/span[contains(text(),'%s')]/../following-sibling::div/span";
	public static String hideCommonCheckbox = "xpath#//div/label[contains(text(),'Hide common Data')]/../input";
	public static String RejectRecordCheckbox = "xpath#//div/span/span[contains(text(),'%s')]/../../following-sibling::div/span";
	// (//div/span[contains(text(),'WHO DD
	// Code')])[5]/../following-sibling::div/span
	public static String reconcilecheckboxIfMany = "xpath#(//div/span[contains(text(),'%s')])[%div]/../following-sibling::div/span";

	public static String ParentCaseRejectRecordCheckbox = "xpath#//span/span[contains(text(),'%s')]/../../following-sibling::div/span";

	public static String ParentCreateNewVersionbutton = "xpath#//button[contains(text(),'Create New Version')]";

	/**********************************************************************************************************
	 * @Objective:get master case data attributes
	 * @Parameters:rowNum
	 * @author:RAshmi Date :09-MAr-2021 Updated by and when
	 **********************************************************************************************************/
	public static String Reconcilecheckbox(String fieldname) {
		String value = reconcilecheckbox;
		String value2;
		value2 = value.replace("%s", fieldname);
		return value2;
	}

	public static String Reconcilecheckbox(String fieldname, String divnumber) {
		String value = reconcilecheckboxIfMany;
		String value2;
		value2 = value.replace("%s", fieldname);
		String value3;
		value3 = value2.replace("%div", divnumber);
		return value3;
	}

	public static String RejectRecordCheckbox(String label) {
		String value = RejectRecordCheckbox;
		String value2;
		value2 = value.replace("%s", label);
		return value2;
	}

	public static String ParentRejectRecordCheckbox(String label) {
		String value = ParentCaseRejectRecordCheckbox;
		String value2;
		value2 = value.replace("%s", label);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:get case data attributes
	 * @Parameters:rowNum
	 * @author:DushyanthMahesh Date :12-September-2019 Updated by and when
	 **********************************************************************************************************/
	public static String caseDataAttributes(String rowNum) {
		String value = caseDataAttributes;
		String value2;
		value2 = value.replace("{0}", rowNum);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:get follow case data attributes
	 * @Parameters:rowNum
	 * @author:DushyanthMahesh Date :09-October-2019 Updated by and when
	 **********************************************************************************************************/
	public static String followupCaseDataAttributes(String rowNum) {
		String value = followUpCase;
		String value2;
		value2 = value.replace("{0}", rowNum);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:get master case data attributes
	 * @Parameters:rowNum
	 * @author:DushyanthMahesh Date :09-October-2019 Updated by and when
	 **********************************************************************************************************/
	public static String masterCaseDataAttributes(String rowNum) {
		String value = masterCase;
		String value2;
		value2 = value.replace("{0}", rowNum);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:get merged case data attributes
	 * @Parameters:rowNum
	 * @author:DushyanthMahesh Date :09-October-2019 Updated by and when
	 **********************************************************************************************************/
	public static String mergedCaseDataAttributes(String rowNum) {
		String value = mergedCase;
		String value2;
		value2 = value.replace("{0}", rowNum);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:get merged case data attributes
	 * @Parameters:rowNum
	 * @author:DushyanthMahesh Date :09-October-2019 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeader(String rowNum) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{0}", rowNum);
		return value2;
	}

	/**********************************************************************************************************
	 * @ Objective: Pass check box label name at runtime
	 * 
	 * @Input Parameters:
	 * @Output Parameters:
	 * @author:Avinash k
	 * @Date :23-September-2019
	 * @Updated by and when
	 **********************************************************************************************************/
	public static String reconcilitionCheckBox(String runTimeLabel) {
		String value = reconcilitionCheckBox;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @ Objective: Pass check box label name at runtime
	 * 
	 * @Input Parameters:
	 * @Output Parameters:
	 * @author:WajahatUmar S
	 * @Date :21-Feb-2019
	 * @Updated by and when
	 **********************************************************************************************************/
	public static String reconcilitionCheckBoxPerfm(String runTimeLabel) {
		String value = ReconciliationChkboxes;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

}
