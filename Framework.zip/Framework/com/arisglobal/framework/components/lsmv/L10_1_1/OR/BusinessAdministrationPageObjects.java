package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import org.openqa.selenium.By;

public class BusinessAdministrationPageObjects {
	
	public static String companyUnitLink  = "xpath#//span[contains(text(),'Company unit')]";
	public static String companyUnitLabel = "xpath#//div[@class='CaseList_Title']/label[text()='Company Unit Lists']";
	public static String departmentLink = "xpath#//span[contains(text(),'Department')]";
	public static String departmentLabel = "xpath#//label[@id='deptListform:depttitleId']";
	public static String announcementLink = "xpath#//span[@class='ui-menuitem-text'][contains(text(),'Announcement')]";
	public static String announcementLabel= "xpath#//label[@id='annolists:accessLabel3']";
	public static String codelistLink = "xpath#//a[@id='headerForm:codelistId']//span[@class='ui-menuitem-text'][contains(text(),'Codelist')]";
	public static String codelistLabel = "xpath#//label[@id='codeListform:accessLabel3']";
	public static String codelistMappingLink = "xpath#//span[contains(text(),'Codelist mapping')]";
	public static String codelistMappingLabel = "xpath#//label[@id='codelistMappingListForm:codeListLabel']";
	public static String indexesLink = "xpath#//span[contains(text(),'Indexes')]";
	public static String indexesLabel = "xpath#//label[@id='indexList:accessLabel3']";
	public static String dataPrivacyMaintenanceLink = "xpath#//span[contains(text(),'Data privacy maintenance')]";
	public static String dataPrivacyMaintenanceLabel = "xpath#//label[@id='privacyPolicyListform:privacyPolicyTitle']";
	public static String territoryLink = "xpath#//a[@id='headerForm:terId']/span[text()='Territory']";
	public static String territoryLabel = "xpath#//label[@id='territoryListing:title2']";
	public static String postalCodeLink = "xpath#//span[contains(text(),'Postal code')]";
	public static String postalCodeLabel = "xpath#//label[@id='postalCodeListForm:title2']";
	public static String regionLink = "xpath#//span[contains(text(),'Region')]";
	public static String regionLabel = "xpath#//label[@id='regionListform:accessLabel3']";
	public static String companyGroupLink = "xpath#//span[contains(text(),'Company group')]";
	public static String companyGroupLabel = "xpath#//label[@id='companyUserGroupForm:headertxt2']";
	public static String reporterFormsLink = "xpath#//span[contains(text(),'Reporter forms')]";
	public static String reporterFormsLabel = "xpath#//td[@class='PageTitPoc']/label[text()='Reporter Forms']";
	public static String companyUnitKeywordSearch = "xpath#//input[@id='partnerForm:keyword']";
	public static String departmentKeywordSearch = "xpath#//input[@id='deptListform:keywordSearch']";
	public static String announcementKeywordSearch = "xpath#//input[@id='annolists:searchText']";
	public static String codelistKeywordSearch = "xpath#//input[@id='codeListform:searchText']";
	public static String codeMappingKeywordSearch = "xpath#//input[@id='codelistMappingListForm:keyword']";
	public static String indexKeywordSearch = "xpath#//input[@id='indexList:searchText']";
	public static String dataPrivacyKeywordSearch = "xpath#//input[@id='privacyPolicyListform:keywordSearch']";
	public static String territoryKeywordSearch = "xpath#//input[@id='territoryListing:searchcriteria']";
	public static String postalCodeKeywordSearch = "xpath#//input[@id='postalCodeListForm:searchId']";
	public static String regionKeywordSearch = "xpath#//input[@id='regionListform:searchText']";
	public static String companyGroupKeywordSearch = "xpath#//a[@id='companyUserGroupForm:newId']";
	public static String reporterFormKeywordSearch = "xpath#//input[@id='rfListing:keyword']";
	
	
	
}
