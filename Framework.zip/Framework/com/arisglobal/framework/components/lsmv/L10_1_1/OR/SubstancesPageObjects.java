package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class SubstancesPageObjects {

	public static String keywordSearch_Textbox = "xpath#//input[@id='ingredientslistForm:searchCriteria']";
	public static String activemoietySearch_Textbox = "xpath#//input[@id='activeMoietyLookupForm:keywordId']";
	public static String searchBtn_activeMoietywindow = "xpath#//button[@id='activeMoietyLookupForm:subSearchButton']";
	public static String okBtn_activeMoietywindow = "xpath#//button[@id='activeMoietyLookupForm:okButtonBottom']";
	public static String checkbox_activeMoietywindow = "xpath#//td/span[text()='%s']/ancestor::td/preceding::td[@class='ui-selection-column']/div/child::div/span";
	public static String strength_confirmationpopup = "xpath#//span[@id='ingredientForm:unstructedText']";
	public static String yes_BtnStrengthconfPopup = "xpath#//button[@id='ingredientForm:fileuploadValidationButton']";
	public static String search_Icon = "xpath#//a[@id='ingredientslistForm:searchbutton']";
	public static String paginator = "xpath#//div[@id='listingForm:ingredientDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String refresh_Icon = "xpath#//a[@id='listingForm:refreshImage']";
	public static String new_Btn="xpath#//a[@id='listingForm:newId']";
	public static String delete_Btn = "xpath#//a[@id='listingForm:deleteId']";
	public static String substanceNameTextbox = "xpath#//input[@id='ingredientForm:subName']";
	public static String substanceCodeTextbox = "xpath#//input[@id='ingredientForm:subCode']";
	public static String strengthTextbox = "xpath#//input[@id='ingredientForm:stregthId']";
	public static String strengthSelect = "xpath#//select[@id='ingredientForm:C1-1018_input']";
	public static String EUTCTCodeTextbox = "xpath#//input[@id='ingredientForm:euTctCode']";
	public static String substanceIDTextbox = "xpath#//input[@id='ingredientForm:substanceId']";
	public static String substanceTermIDTextbox = "xpath#//input[@id='ingredientForm:substanceTermId']";
	public static String classOfIngredientTextbox = "xpath#//input[@id='ingredientForm:classOfIng']";
	public static String activeMoietyLookup = "xpath#//img[@id='ingredientForm:activeMoietyLookup:j_id_ym']";
	public static String activeMoietyTextbox = "xpath#//input[@id='ingredientForm:pharma_auto_input']";
	public static String synonymAddButton = "xpath#//a[@id='ingredientForm:addSearchField2']";
	public static String synonymTextarea = "xpath#//textarea[@id='ingredientForm:verbatiumDataTable:0:verbatiumTerm']";
	public static String unstructuredStrengthTextbox = "xpath#//input[@id='ingredientForm:unstructuredID']";
	public static String FDASubstanceCodeTextbox = "xpath#//input[@id='ingredientForm:fdaSubCode']";
	public static String preferredWHODDTextbox = "xpath#//input[@id='ingredientForm:prefWHODD']";
	public static String preferredWHODDLookup = "xpath#//img[@id='ingredientForm:whoodLookup:j_id_nm']";
	public static String substanceSpecifiedSubstanceTermIDVersionDateNumber = "xpath#//input[@id='ingredientForm:substanceVersionDateNumber']";
	public static String ATCCode = "xpath#//input[@id='ingredientForm:aTCCode']";
	public static String manufacturerName_Textfield = "xpath#//input[@id='ingredientForm:mfName']";
	public static String saveButton = "xpath#//button[@id='ingredientForm:visibleSave']";
	public static String cancelButton = "xpath#//button[@id='ingredientForm:cancelId']";
	public static String substance_Lable = "xpath#//div[@class='HeaderBox']/label[text()='Substances Lists']";
 	public static String get_substancename = "xpath#//tbody[@id='listingForm:ingredientDataTable_data']/tr/td[@class='EditIcon']/following-sibling::td[1]";
 	public static String generalCommonDropdownSelect = "xpath#//label[@style='visibility: visible;'][contains(text(),'{0}')]/ancestor::span/p-dropdown/div";
 	public static String setdropDownValue = "xpath#//ul[contains(@class,'ui-selectonemenu-items')]/child::li[contains(text(),'%s')]";
 	public static String strength_radioBtn = "xpath#//label[text()='%s']/ancestor::td/div[@class='ui-radiobutton ui-widget']/child::div/span";
 	public static String validationOk_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']";
 	public static String validation_Popup = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
 	public static String edit_Icon= "xpath#//img[@id='listingForm:ingredientDataTable:0:editImgId']";
 	public static String substanceRole_drpDown= "xpath#//label[@id='ingredientForm:C1-7049_label']";
 	public static String strengthunit_drpDown= "xpath#//label[@id='ingredientForm:C1-1018_label']";
 	public static String get_activtyMoiety= "xpath#//label[@id='ingredientForm:activeMoietyDataTable:%s:tName']";
 	public static String get_ListofSubstance= "xpath#//th[@id='listingForm:ingredientDataTable:substancesId']/ancestor::table/tbody/tr/td[3]";
 	public static String columnHeader = "xpath#(//th[@id='listingForm:ingredientDataTable:substancesId']/ancestor::table/tbody/tr/td[3])[{%count}]";
 	public static String deletevalidation_Popup ="xpath#//span[@class='ui-confirm-dialog-message']";
 	public static String deletePopupYes_Btn ="xpath#//button[@id='listingForm:confirmation_yes']";
 	public static String listingScreen_CheckBoxs = "xpath#//label[text()='%s']/ancestor::tbody[@id='listingForm:ingredientDataTable_data']/tr/td/div/child::div/span";
 	public static String downloadIcon = "xpath#//a[@id='ingredientslistForm:actionId']";
	public static String exporttoExcel_link = "xpath#//button[contains(@id,'ingredientslistForm')]/span[text()='Export To Excel']";
	public static String exporttoExcel_popup = "xpath#//span[@id='listingForm:columnSelectionDialogId_title']";
	public static String export_Btn= "xpath#//button[@id='listingForm:submitId']";
	public static String exportexcelcancel_Btn= "xpath#//button[@id='listingForm:cancelDialogId']";
 	
 	
 	
 	
 	
 	
 	
 	
 	public static String substanceRole_Dropdown  = "Substance Role";
 	public static String structuredStrength_RadioBtn  = "Structured Strength";
 	public static String unstructuredStrength_RadioBtn  = "Unstructured Strength";
 	public static String strength_Dropdown  = "Strength";
 	
	/**********************************************************************************************************
	 * @Objective:get substance name by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:DushyanthMahesh Date :16-September-2019 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderList(String num) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}


	/**********************************************************************************************************
	 * Objective:The below method is created to send value by passing value at runtime.
	 * Input Parameters: runTimeLabel
	 * Scenario Name Output
	 * Parameters:
	 * @author:Avinash K Date :17-Oct-2019 Updated by and when   	 
	**********************************************************************************************************/		
    		
    public static String selectCheckbox(String runTimeLabel) {
        String value = checkbox_activeMoietywindow;
        String value2;
        value2 = value.replace("%s", runTimeLabel);
        return value2;
    }
	/**********************************************************************************************************
	 * Objective:The below method is created to select checkbox by passing value at runtime.
	 * Input Parameters: runTimeLabel
	 * Scenario Name Output
	 * Parameters:
	 * @author:Avinash K Date :18-Oct-2019 Updated by and when   	 
	**********************************************************************************************************/		
    		
    public static String selectListingCheckbox(String runTimeLabel) {
        String value = listingScreen_CheckBoxs;
        String value2;
        value2 = value.replace("%s", runTimeLabel);
        return value2;
    }
	/**********************************************************************************************************
	 * Objective:The below method is created to send index at runtime.
	 * Input Parameters: runTimeLabel
	 * Scenario Name Output
	 * Parameters:
	 * @author:Avinash K Date :23-Oct-2019 Updated by and when   	 
	**********************************************************************************************************/		
    		
    public static String getActivtyMoiety(String runTimeLabel) {
        String value = get_activtyMoiety;
        String value2;
        value2 = value.replace("%s", runTimeLabel);
        return value2;
    }
 	/**********************************************************************************************************
	 * @Objective:  The below method is created to click strength radion button by passing label name at runtime
	 * @InputParameters: label name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 23-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
    public static String setStrength(String label) {
        String value = strength_radioBtn.replace("%s", label);
        return value;
    }
 	/**********************************************************************************************************
	 * @Objective:  The below method is created to click dropdown by passing label name at runtime
	 * @InputParameters: label name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 23-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
    public static String selectGeneralDroprdown(String label) {
        String value = generalCommonDropdownSelect.replace("{0}", label);
        return value;
    }
    /**********************************************************************************************************
	 * @Objective:  The below method is created to select dropdown by passing value at runtime
	 * @InputParameters: value
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 23-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
    public static String clickDropDownValue(String data) {
        String value = setdropDownValue.replace("%s", data);
        return value;
    }
}
