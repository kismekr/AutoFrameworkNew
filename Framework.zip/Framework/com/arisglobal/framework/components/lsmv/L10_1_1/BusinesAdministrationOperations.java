package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AdministrationPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.BusinessAdministrationPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.aventstack.extentreports.Status;

public class BusinesAdministrationOperations extends ToolManager{
	public static WebElement webElement;
	static String className = BusinesAdministrationOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	
	
	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in Business administration.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void menuNavigation(String pageObject) {
		
		agMouseHover(AdministrationPageObjects.administrationHover);
		agClick(pageObject);
		
	}
		
	
	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in
	 * Administration > Business administration and verify the label name
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void  businessAdministrationNavigations(String menu){
			switch (menu) {
			case "companyUnit":
				menuNavigation(BusinessAdministrationPageObjects.companyUnitLink);
				CommonOperations.agwaitTillVisible(BusinessAdministrationPageObjects.companyUnitKeywordSearch);
				status = agIsVisible(BusinessAdministrationPageObjects.companyUnitKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to company Unit is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to company Unit is Unsuccessfull", true);
				}
				break;
			case "department":
				menuNavigation(BusinessAdministrationPageObjects.departmentLink);
				agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
				agAssertVisible(BusinessAdministrationPageObjects.departmentKeywordSearch);
				status = agIsVisible(BusinessAdministrationPageObjects.departmentKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to department is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to department is Unsuccessfull", true);
				}
				break;
			case "announcement":
				menuNavigation(BusinessAdministrationPageObjects.announcementLink);
				agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
				agWaitTillVisibilityOfElement(BusinessAdministrationPageObjects.announcementKeywordSearch);
				agAssertVisible(BusinessAdministrationPageObjects.announcementKeywordSearch);
				status = agIsVisible(BusinessAdministrationPageObjects.announcementKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to announcement is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to announcement is Unsuccessfull", true);
				}
				break;
				
			case "codelist":
				menuNavigation(BusinessAdministrationPageObjects.codelistLink);
				status = agIsVisible(BusinessAdministrationPageObjects.codelistKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
					Reports.ExtentReportLog("", Status.INFO,"<br />"+ "The Administration > Business Administration > Codelist screen is displayed.", false);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "The Administration > Business Administration > Codelist screen is not displayed.", true);
				}
				break;
			case "indexes":
				menuNavigation(BusinessAdministrationPageObjects.indexesLink);
				status = agIsVisible(BusinessAdministrationPageObjects.indexKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to indexes is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to indexes is Unsuccessfull", true);
				}
				break;
			case "codelistMapping":
				menuNavigation(BusinessAdministrationPageObjects.codelistMappingLink);
				status = agIsVisible(BusinessAdministrationPageObjects.codeMappingKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to codelist Mapping is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to codelist Mapping is Unsuccessfull", true);
				}
				break;
			case "dataPrivacyMaintenance":
				menuNavigation(BusinessAdministrationPageObjects.dataPrivacyMaintenanceLink);
				status = agIsVisible(BusinessAdministrationPageObjects.dataPrivacyKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to data Privacy Maintenance is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to data Privacy Maintenance is Unsuccessfull", true);
				}
				break;
			case "territory":
				menuNavigation(BusinessAdministrationPageObjects.territoryLink);
				status = agIsVisible(BusinessAdministrationPageObjects.territoryKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to territory is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to territory is Unsuccessfull", true);
				}
				break;
			case "postalCode":
				menuNavigation(BusinessAdministrationPageObjects.postalCodeLink);
				status = agIsVisible(BusinessAdministrationPageObjects.postalCodeKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to postal Code is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to postal Code is Unsuccessfull", true);
				}
				break;
			case "region":
				menuNavigation(BusinessAdministrationPageObjects.regionLink);
				status = agIsVisible(BusinessAdministrationPageObjects.regionKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to region is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to region is Unsuccessfull", true);
				}
				break;
			case "companyGroup":
				menuNavigation(BusinessAdministrationPageObjects.companyGroupLink);
				status = agIsVisible(BusinessAdministrationPageObjects.companyGroupKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to company Group is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to company Group is Unsuccessfull", true);
				}
				break;
			case "reporterForms":
				menuNavigation(BusinessAdministrationPageObjects.reporterFormsLink);
				status = agIsVisible(BusinessAdministrationPageObjects.reporterFormKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to reporter Forms is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to reporter Forms is Unsuccessfull", true);
				}
				break;
			default:
				System.out.println("Invalid Menu Link!");
			}
	

	}
}