package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class ProductsPageObjects {

	public static String ProductHoverNew = "xpath#//a[@class='ui-menuitem-link ui-submenu-link ui-corner-all']//span[text()='Product']";
	public static String productHover = "xpath#//span[contains(text(),'Products')]";
	public static String productNew = "xpath#//a[@id='headerForm:prodNewId']//span[@class='ui-menuitem-text'][contains(text(),'New')]";
	public static String productNewButton = "xpath#//a[@id='productListForm:newId']";
	public static String productID = "xpath#//input[@id='productForm:productId']";
	public static String ListingkeywordSearchTextbox = "xpath#//input[@id='productListForm:keyword']";
	public static String ListingkeywordSearchIcon = "xpath#//a[@id='productListForm:searchProduct']";
	public static String unverifiedKeywordSearchTextbox = "xpath#//input[@id='stagingProductListForm:keyword']";
	public static String productNewLable = "xpath#//div[@id='productForm:panel_content']//label[text()='Product']";
	public static String productListing = "xpath#//a[@id='headerForm:prodListId']//span[contains(text(),'Listing')]";
	public static String productListingLable = "xpath#//div[@id='productListForm:searchPanel']//label[text()='Product Lists']";
	public static String unverifiedProducts = "xpath#//span[contains(text(),'Unverified products')]";
	public static String unverifiedProductsLable = "xpath#//div[@id='stagingProductListForm:searchPanel']//label[text()='UnVerified Products Lists']";
	public static String paginator = "xpath#//div[@id='productListForm:productDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String edit_Icon = "xpath#//img[@id='productListForm:productDataTable:0:editIcon']";
	public static String saveButton = "xpath#//button[@id='productForm:visibleSave']";
	public static String deleteButton = "xpath#//a[@id='productListForm:deleteId']";
	public static String cancelButton = "xpath#//button[@id='productForm:cancelId']";
	public static String saveAndExit = "xpath#//button[@id='productForm:saveAndExitId']";

	//////////////////////////////////////////////// Basic Details Page
	//////////////////////////////////////////////// ////////////////////////////////////////////////////////

	public static String product_Div = "xpath#//label[contains(@id, 'productForm:') and text()= 'Product']";
	public static String mpidCrossReference_Div = "xpath#//label[contains(@id, 'productForm:') and text()= '(I)MPID Cross Reference']";
	public static String productActiveIngredient_Div = "xpath#//label[contains(@id, 'productForm:') and text()= 'Product Active Ingredient']";

	public static String productTypeDropDown = "xpath#//label[@id='productForm:A1-5015_label']";
	public static String productIDTextBox = "xpath#//input[@id='productForm:productId']";
	public static String preferredProductDescTextBox = "xpath#//input[@name='productForm:preferredProductName']";
	public static String globalProductTextBox = "xpath#//input[@id='productForm:baseProdName_auto_input']";
	public static String globalProductLookUp = "xpath#//img[contains(@id, 'productForm:name') and contains(@src, 'Lookup_Selection')]";
	public static String futureProductTextBox = "xpath#//input[@id='productForm:futureProduct_auto_input']";
	public static String productClassDropDown = "xpath#//label[@id='productForm:A1-5039_label']";
	public static String routeOfAdminDropDown = "xpath#//label[@id='productForm:A1-1020_label']";
	public static String routeOfAdminTermIDTextBox = "xpath#//input[@id='productForm:routeAdministrationTermId']";
	public static String formOfAdminDropDown = "xpath#//label[@id='productForm:A1-805_label']";
	public static String pharmaceuticalDoseFormTermIDTextBox = "xpath#//input[@id='productForm:pharmaceuticalDoseFormTermId']";
	public static String genericNameTextBox = "xpath#//input[@id='productForm:genericName']";
	public static String activeRadio = "Active";
	public static String descriptionTextArea = "xpath#//textarea[@id='productForm:description']";
	public static String MPIDcrossReferenceTextBox = "xpath#//input[@id='productForm:crossRef']";
	public static String fdaTextBox = "xpath#//input[@id='productForm:fdaRegistrationNumber']";
	public static String manufacturerNameTextBox = "xpath#//input[@id='productForm:manufacturerName']";
	public static String manufacturerNameLookUp = "xpath#//img[contains(@id, 'productForm:manufacturerForm') and contains(@src, 'Lookup_Selection')]";
	public static String manufacturerGroupTextBox = "xpath#//input[@id='productForm:manufacturerGroup']";
	public static String manufacturerGroupLookUp = "xpath#//img[contains(@id, 'productForm:manufacturerGroup') and contains(@src, 'Lookup_Selection')]";
	public static String internationalBirthDateTextBox = "xpath#//input[@id='productForm:internationalBirthDate_input']";
	public static String combinedCdcTextBox = "xpath#//input[@id='productForm:combinedCdc']";
	public static String combinedPharmaceuticalDoseTextBox = "xpath#//input[@id='productForm:combinedPharmaDose']";
	public static String productGroupDropDown = "xpath#//label[@id='productForm:A1-9741_label']";
	public static String productKeywordsTextArea = "xpath#//textarea[@id='productForm:productKeywords']";
	public static String productActiveIngredientTextArea = "xpath#//textarea[@id='productForm:pai']";
	public static String whoDDTextBox = "xpath#//input[@id='productForm:wHODD']";
	public static String whoDDLookUp = "xpath#//img[contains(@id, 'productForm:wHODDId') and contains(@src, 'Lookup_Selection')]";
	public static String madeByDropDown = "xpath#//label[@id='productForm:A1-816_label']";
	public static String companyProductRadio = "Company Product";
	public static String subjectToRiskManagementRadio = "Subject to Risk Management";
	public static String internalCodeTextBox = "xpath#//input[@id='productForm:internalCode']";
	public static String productUsedInDropDown = "xpath#//label[@id='productForm:A1-7033_label']";
	public static String atcCodeTextBox = "xpath#//input[@id='productForm:aTCCode']";
	public static String atcCodeLookUp = "xpath#//img[contains(@id, 'productForm:atc') and contains(@src, 'Lookup_Selection')]";

	// Strength
	// public static String strength_Div = "xpath#//label[contains(@id,
	// 'productForm:') and text()= 'Strength name']";
	public static String Strength_No = "xpath#//label[text()='Strength(Number)']";
	public static String Strength_Unit = "xpath#//label[text()='Unit']";
	public static String strength_Div = "xpath#//span[@class='ui-panel-title']/label[contains(@id, 'productForm:')][contains(text(),'Strength')]";
	public static String strengthRadio = "xpath#//table[@id='productForm:structureSelector']//label[contains(text(),'%radio%')]";
	public static String strengthTextBox = "xpath#//input[@id='productForm:prodStrength']";
	public static String strengthUnitDropDown = "xpath#//label[@id='productForm:A1-9070_label']";
	public static String productURLTextBox = "xpath#//input[@id='productForm:productURL']";
	public static String unStructuredStrengthTextBox = "xpath#//input[@id='productForm:unstructuredStrength']";

	// Substances >> LookUp
	public static String substanceNameTextBox = "xpath#//input[@id='substanceLookupForm:subNameId']";
	public static String subLookUpSearchButton = "xpath#//button[@id='substanceLookupForm:subSearchButton']";
	public static String subLookUpdataSelect = "xpath#//span[contains(@id,'substanceLookupForm:substanceTable:substanceLookUpDataTableMulti')][text()='{@}']";
	public static String subLookUpOkButton = "xpath#//button[@id='substanceLookupForm:okButtonBottom']";
	public static String subLookUpCancelButton = "xpath#//button[@id='substanceLookupForm:cancelButtonBottom']";
	public static String subLookUpDataSelectCheckBOx = "xpath#//span[text() = '%s%']/ancestor::tbody[@id='substanceLookupForm:substanceTable:substanceLookUpDataTableMulti_data']/tr/td/div/child::div/span";

	// Substances >> List View
	public static String substances_Div = "xpath#//label[contains(@id, 'productForm:') and text()= 'Substances']";
	public static String substancesAddLink = "xpath#//a[contains(@id, 'substanceLookup')]";
	public static String substanceNameLabelListView = "xpath#//label[contains(@id, 'productForm:substancesDataTable:%rowNo%:')][text()='%subName%']";
	public static String subStrengthListViewTextBox = "xpath#//label[text()='%s%']/parent::td/following-sibling::td[1]/input";
	public static String subStrengthUnitListViewDropDown = "xpath#//label[@id='productForm:substancesDataTable:%rowNo%:A3-1018_label']";
	public static String subSubstanceRoleListViewDropDown = "xpath#//label[@id='productForm:substancesDataTable:%rowNo%:A1-7049_label']";

	// Substances >> Form View
	public static String substanceFormViewTextBox = "xpath#//input[@id='productForm:activeIngredientSubstance']";
	public static String subStrengthFormViewTextBox = "xpath#//input[@id='productForm:vetStrength1']";
	public static String subStrengthUnitFormViewDropDown = "xpath#//label[@id='productForm:A3-1018_label']";
	public static String subSubstanceRoleFormViewDropDown = "xpath#//label[@id='productForm:A1-7049_label']";
	public static String subMeasurementPointFormViewTextBox = "xpath#//input[@id='productForm:measurementPoint']";
	public static String subIngredientTypeFormViewDropDown = "xpath#//label[@id='productForm:A1-9093_label']";

	// Substances >> Synonyms >> List View
	public static String subSynonymsAddLink = "xpath#//div[@id='productForm:productVerbatiumTermsHeaderPanel']/a[contains(@id, 'productForm:addSearch')]";
	public static String subSynonymsTextArea = "xpath#//textarea[@id='productForm:prverbatiumTermsDataTable:%rowNo%:verbatiumTerms']";

	// Additional Details
	public static String productNameParts_Div = "xpath#//label[contains(@id, 'productForm:') and text()= 'Product Name Parts']";
	public static String packageDescriptionTextBox = "xpath#//input[@id='productForm:packageDescription']";
	public static String unitOfRepresentationDropDown = "xpath#//label[@id='productForm:A1-9095_label']";
	public static String pharmaceuticalDoseFormPartTextBox = "xpath#//input[@id='productForm:pharmaceutical_doseform_part']";
	public static String formulationPartTextBox = "xpath#//input[@id='productForm:formulation_part']";
	public static String containerOrPackPartTextBox = "xpath#//input[@id='productForm:pack_part']";
	public static String trademarkOrCompanyNamePartTextBox = "xpath#//input[@id='productForm:formulation_Part']";
	public static String languageDropDown = "xpath#//label[@id='productForm:A1-534_label']";
	public static String targetPopulationPpartTextBox = "xpath#//input[@id='productForm:target_population_part']";

	// Therapeutic Area
	public static String therapeuticArea_Div = "xpath#//label[contains(@id, 'productForm:') and text()= 'Therapeutic Area']";
	public static String therapeuticAreaAddLink = "xpath#//a[@id='productForm:addSearchField1:therapeuticLookup']";
	public static String therapeuticAreaDataSelect = "xpath#(//span[contains(@id,'therapeuticLookupForm:therapeuticTable:therapeuticLookUpDataTableMulti')][text()='{@}'])[1]";
	public static String therapeuticAreaPriorityDropDown = "xpath#//label[@id='productForm:therapeuticDataTable:%rowNo%:A1-145_label']";
	public static String therapeuticAreaDataSelectCheckBOx = "xpath#//span[text()='%s%']/parent::td/preceding-sibling::td/descendant::span[contains(@class,'blank')]";
	public static String therapeuticAreaLookUpOkButton = "xpath#//button[@id='therapeuticLookupForm:okButtonBottom']";
	public static String therapeuticAreaLabel = "xpath#//label[contains(@id, 'productForm:therapeuticDataTable:%rowNo%:')][text()='%therapName%']";

	// Indications
	public static String indications_Div = "xpath#//label[contains(@id, 'productForm:') and text()= 'Indications']";
	public static String indicationsAddLink = "xpath#//div[@id='productForm:indicationsHeaderPanel']/a[contains(@id, 'productForm:addSearch')]";
	public static String lltTermLookUpIcon = "xpath#//a[@id='productForm:indicationsDataTable:%rowNo%:aeMeddraLookup']/img[contains(@src, 'icon-lookup.gif')]";
	public static String lltTermTextBox = "xpath#//input[@id='productForm:indicationsDataTable:%rowNo%:indLltTerm_input']";
	public static String lltTermTextSuggestion = "xpath#//li[contains(@class, 'ui-autocomplete-list-item')][@data-item-value ='$term$']";
	public static String lltCodeTextBox = "xpath#//input[@id='productForm:indicationsDataTable:%rowNo%:indLltCode']";
	public static String ptTermTextBox = "xpath#//input[@id='productForm:indicationsDataTable:%rowNo%:indPtTerm']";
	public static String ptCodeTextBox = "xpath#//input[@id='productForm:indicationsDataTable:%rowNo%:indPtCode']";
	public static String icdCODETextBox = "xpath#//input[@id='productForm:indicationsDataTable:%rowNo%:icdCode']";
	public static String medDRaVersionTextBox = "xpath#//input[@id='productForm:indicationsDataTable:%rowNo%:medraVersion']";

	// Product Characteristics
	public static String productCharacteristics_Div = "xpath#//label[contains(@id, 'productForm:') and text()= 'Product Characteristics']";
	public static String characteristicsAddLink = "xpath#//div[@id='productForm:productCharacteristicHeaderPanel']/a[contains(@id, 'productForm:addSearch')]";
	public static String productCharacSystemDropDown = "xpath#//label[@id='productForm:productCharacteristicDataTable:%rowNo%:A1-9090_label']";
	public static String productCharacValueDropDown = "xpath#//label[@id='productForm:productCharacteristicDataTable:%rowNo%:A1-9091_label']";

	// PhPID Set

	///////////////////////////////////////////// Trade Names Page
	///////////////////////////////////////////// //////////////////////////////////////////////////////////////////

	// Trade Names Page >> List View
	public static String tradeNames_Div = "xpath#//label[contains(@id, 'productForm:') and text()= 'Trade Names']";
	public static String approvalStartDate_Div = "xpath#//label[contains(@id, 'productForm:') and text()= 'Approval Start Date']";
	public static String marketingStatus_Div = "xpath#//label[contains(@id, 'productForm:') and text()= 'Marketing Status']";
	public static String tradeNameLink = "xpath#//span[contains(text(),'Trade Names')]";
	public static String tradeNameViewButton = "xpath#//div[@id='productForm:tradeNameMenuTabId']//div//span[text()='%view%']";
	public static String toggleViewButton = "xpath#//label[text()='%divName%']/ancestor::span[@class='ui-panel-title']/descendant::span[text()='%view%']";
	public static String tradeNameAddLink = "xpath#//a[@id='productForm:addSearchFieldList']";
	public static String tradeBrandNameListViewTextBox = "xpath#//input[@id='productForm:tradeNamesDataTable:%rowNo%:inputNameId']";
	public static String prodTypeTradeNmeListViewDropDown = "xpath#//label[@id='productForm:tradeNamesDataTable:%rowNo%:A3-5015_label']";
	public static String ndcNoListViewTextBox = "xpath#//input[@id='productForm:tradeNamesDataTable:%rowNo%:ndcId']";
	public static String approvalNoListViewTextBox = "xpath#//input[@id='productForm:tradeNamesDataTable:%rowNo%:approvalNoId']";
	public static String approvalTypeListViewDropDown = "xpath#//label[@id='productForm:tradeNamesDataTable:%rowNo%:A1-709_label']";
	public static String marketingAuthHolderListViewTextBox = "xpath#//input[@id='productForm:tradeNamesDataTable:%rowNo%:mahNameId']";
	public static String agentDistributorListViewTextBox = "xpath#//input[@id='productForm:tradeNamesDataTable:%rowNo%:agentName1']";
	public static String sourceListViewDropDown = "xpath#//label[contains(@id,'productForm:tradeNamesDataTable:%rowNo%:A1-9100_label')]";
	// public static String authorizationCountryListViewDropDown =
	// "xpath#//label[contains(@id,'productForm:tradeNamesDataTable:%rowNo%:a1-9744_1015')]";
	public static String authorizationCountryListViewDropDown = "xpath#//label[contains(@id,'productForm:tradeNamesDataTable:%rowNo%:c1-1015_label')]";
	public static String submissionTypeListViewDropDown = "xpath#//label[@id='productForm:tradeNamesDataTable:%rowNo%:A1-8013_label']";
	public static String atcCodeTradeNmeListViewTextBox = "xpath#//thead[@id='productForm:tradeNamesDataTable_head']/following-sibling::tbody/tr/td[11]/input[contains(@id,'productForm:tradeNamesDataTable:%rowNo%:')]";
	public static String copyApprovalsListViewCheckBox = "xpath#//div[@id='productForm:tradeNamesDataTable:%rowNo%:copyApprovalcheck']";
	public static String dataSheetNameListViewDropDown = "xpath#//label[@id='productForm:tradeNamesDataTable:%rowNo%:tradeDataSheetName_label']";

	// Trade Names Page >> Form View
	public static String tradeBrandNameFormViewTextBox = "xpath#//input[@id='productForm:TradeorBrandNameForm']";
	public static String prodTypeTradeNmeFormViewDropDown = "xpath#//label[@id='productForm:A2-5015_label']";
	public static String submissionTypeFormViewDropDown = "xpath#//label[@id='productForm:A1-8013_label']";
	public static String atcCodeTradeNmeFormViewTextBox = "xpath#//input[@id='productForm:ATCCodeForm']";
	public static String marketingAuthHolderFormViewTextBox = "xpath#//input[@id='productForm:marketingAuthorizationHolderForm']";
	public static String agentDistributorFormViewTextBox = "xpath#//input[@id='productForm:agentorDistributorForm']";
	public static String authorizationCountryFormViewDropDown = "xpath#//label[@id='productForm:A1-1015_label']";
	public static String approvalNoFormViewTextBox = "xpath#//input[@id='productForm:approvalorAuthorizationNoForm']";
	public static String codeNameINDFormViewTextBox = "xpath#//input[@id='productForm:codeName']";
	public static String bioReferenceNameRLDFormViewTextBox = "xpath#//input[@id='productForm:bioRefName']";
	public static String otcFormViewTextBox = "xpath#//input[@id='productForm:OTCForm']";
	public static String approvalTypeFormViewDropDown = "xpath#//label[@id='productForm:A1-709_label']";
	public static String approvalStartDateFormViewTextBox = "xpath#//input[@id='productForm:approvalStartDate_input']";
	public static String approvalEndDateFormViewTextBox = "xpath#//input[@id='productForm:approvalDateEndDate_input']";
	public static String approvalDescriptionFormViewTextArea = "xpath#//textarea[@id='productForm:approvalDescription']";
	public static String ndcNoFormViewTextBox = "xpath#//input[@id='productForm:NDCNoForm']";
	public static String medicinalProductNameFormViewTextBox = "xpath#//input[@id='productForm:mdProNmForm']";
	public static String internalProductIDFormViewTextBox = "xpath#//input[@id='productForm:internalproIdForm']";
	public static String marketedDateFormViewTextBox = "xpath#//input[@id='productForm:marketedDateForm']";
	public static String mpidFormViewTextBox = "xpath#//input[@id='productForm:mpID']";
	public static String versionDateFormViewTextBox = "xpath#//input[@id='productForm:mpIdVerDate_input']";
	public static String versionNumberFormViewTextBox = "xpath#//input[@id='productForm:mpIdVerNumber']";
	public static String marketingCategoryFormViewDropDown = "xpath#//label[@id='productForm:A1-9098_label']";
	public static String proprietaryNameSuffixFormViewDropDown = "xpath#//label[@id='productForm:A1-9099_label']";
	public static String marketingStatusFormViewRadio = "Marketing Status";
	public static String containerTypeFormViewTextBox = "xpath#//input[@id='productForm:containerType']";
	public static String verifiedFormViewRadio = "Verified";
	public static String licenseIdFormViewTextBox = "xpath#//input[@id='productForm:licenseId']";
	public static String licenseStatusFormViewTextBox = "xpath#//input[@id='productForm:licenseStatus']";
	public static String licenseStatusFormViewDropDown = "xpath#//label[@id='productForm:A1-5061_label']";
	public static String dataSheetNameFormViewDropDown = "xpath#//label[@id='productForm:formDataSheetName_label']";

	// Trade Names Page >> Form View >> Lot/Batch Information
	public static String lotBatchInformation_Div = "xpath#//label[contains(@id, 'productForm:') and text()= 'Lot/Batch Information']";
	public static String lotBatchInformationAddLink = "xpath#//div[@id='productForm:lotorBatchHeaderPanel']/a[contains(@id, 'productForm:addSearch')]";
	public static String lotBatchNoTextBox = "xpath#//thead[@id='productForm:lotorBatchDataTable_head']/following-sibling::tbody/tr/td[2]/input[contains(@id,'productForm:lotorBatchDataTable:%rowNo%:')]";
	public static String manufactureDateTextBox = "xpath#//input[@id='productForm:lotorBatchDataTable:%rowNo%:manufacturingDate_input']";
	public static String expiryDateTextBox = "xpath#//input[@id='productForm:lotorBatchDataTable:%rowNo%:expiryDate_input']";
	public static String materialDescriptionTextBox = "xpath#//thead[@id='productForm:lotorBatchDataTable_head']/following-sibling::tbody/tr/td[5]/input[contains(@id,'productForm:lotorBatchDataTable:%rowNo%:')]";
	public static String manufacturingPlantNameTextBox = "xpath#//thead[@id='productForm:lotorBatchDataTable_head']/following-sibling::tbody/tr/td[6]/input[contains(@id,'productForm:lotorBatchDataTable:%rowNo%:')]";
	public static String materialTextBox = "xpath#//thead[@id='productForm:lotorBatchDataTable_head']/following-sibling::tbody/tr/td[7]/input[contains(@id,'productForm:lotorBatchDataTable:%rowNo%:')]";
	public static String ndcNoTextBox = "xpath#//thead[@id='productForm:lotorBatchDataTable_head']/following-sibling::tbody/tr/td[8]/input[contains(@id,'productForm:lotorBatchDataTable:%rowNo%:')]";

	// Trade Names Page >> Form View >> Product Category Type
	public static String productAttributes_Div = "xpath#//label[contains(@id, 'productForm:') and text()= 'Product Attributes']";
	public static String productCategoryTypeAddLink = "xpath#//a[@id='productForm:addSearchFieldPro']";
	public static String prodCategoryTypeDropDown = "xpath#//label[@id='productForm:productCategoryDataTable:%rowNo%:A1-9151_label']";
	public static String prodCategoryStartDateTextBox = "xpath#//input[@id='productForm:productCategoryDataTable:%rowNo%:startDate_input']";
	public static String prodCategoryEndDateTextBox = "xpath#//input[@id='productForm:productCategoryDataTable:%rowNo%:endDate_input']";

	// a[@id='productForm:addDataSheet']
	////////////////////////////////////// Synonyms Page
	// /////////////////////////////////////////////////////////////////

	public static String synonymsLink = "xpath#//span[@class='ui-menuitem-text'][contains(text(),'Synonyms')]";
	public static String synonymsAddLink = "xpath#//div[@id='productForm:verbatiumTermsHeaderPanel']/a[contains(@id, 'productForm:addSearch')]";
	public static String synonymsTextBox = "xpath#//input[@id='productForm:verbatiumTermsDataTable:%rowNo%:verbatiumTerms']";

	/////////////////////////////////////////// Labeling Page
	/////////////////////////////////////////// /////////////////////////////////////////////////////////////////

	public static String selectedCountriesLink = "xpath#//span[contains(text(),'Selected Countries')]";
	public static String selectedCountriesAddLink = "xpath#//a[@id='productForm:addLabeledcountry']";
	public static String selectedCountriesCountryNameTextbox = "xpath#//input[@id='countryLookupForm:countryNameId']";
	public static String selectedCountriesSearchButton = "xpath#//button[@id='countryLookupForm:countrySearchButton']";
	public static String countrySelect = "xpath#//label[contains(@id,'countryLookupForm:contryDataTable')][text()='{@}']";
	public static String countrySelectCheckBox = "xpath#//label[text() = '%s%']/ancestor::tbody[@id='countryLookupForm:contryDataTable_data']/tr/td/div/child::div/span";
	public static String selectedCountriesOkButton = "xpath#//button[@id='countryLookupForm:okButton']";
	public static String labelingLink = "xpath#//span[contains(text(),'Labeling')]";
	public static String labelingAddLink = "xpath#//a[@id='productForm:addDataSheet']";
	public static String labelingDeleteLink = "xpath#//a[@id='productForm:deleteDataSheets']";
	public static String labelingCopyLink = "xpath#//a[@id='productForm:copyDataSheet']";
	public static String labelingDataSheetNameTextBox = "xpath#//input[@id='productForm:dataSheetName']";
	public static String labelingCountryDropDown = "xpath#//label[@id='productForm:A3-9744_1015_label']";
	public static String labelingCountryGetvalue = "xpath#//input[@id='productForm:A3-9744_1015_focus']/ancestor::div/label";
	public static String labelingDocumentNumberIncludingVersionTextBox = "xpath#//input[@id='productForm:labelVersion']";
	public static String labelingEfflabelingDate = "xpath#//input[@id='productForm:effLabelingDateId_input']";
	public static String labelingTermsAddLink = "xpath#//a[@id='productForm:addSearchFieldeventterms']";
	public static String labelingTermsImportLink = "xpath#//span[@id='productForm:excelImport_label']";
	public static String labelingTermsExportLink = "xpath#//a[@id='productForm:excelExport']";
	public static String labelingTermsDownloadLink = "xpath#//a[@id='productForm:downloadStdtemplatelnk']";
	public static String labelingTermsPTTermTextBox = "xpath#//input[@id='productForm:autoCompleteEvents_input']";
	public static String labelingTermsPTTermGetvalue = "xpath#//label[@id='productForm:eventtermsDataTable:0:j_id_3m6']";
	public static String labelingTermsPTTermLookup = "xpath#//a[@id='productForm:meddraLLTLookup']/img";
	public static String labelingTermsPTTermSuggestion = "xpath#//li[contains(@class, 'ui-autocomplete-list-item')][@data-item-value ='$term$']";
	public static String labelingTermsPTCodeTextBox = "xpath#//input[@id='productForm:ptCode']";
	public static String labelingTermsPTCodeGetvalue = "xpath#//label[@id='productForm:eventtermsDataTable:0:j_id_3m8']";
	public static String labelingTermsLLTTermTextBox = "xpath#//input[@id='productForm:lltDecode']";
	public static String labelingTermsLLTTermGetvalue = "xpath#//label[@id='productForm:eventtermsDataTable:0:j_id_3ma']";
	public static String labelingTermsLLTCodeTextBox = "xpath#//input[@id='productForm:lltCode']";
	public static String labelingTermsLLTCodeGetvalue = "xpath#//label[@id='productForm:eventtermsDataTable:0:j_id_3mc']";
	public static String labelingTermsLabeledRadio = "xpath#//table[@id='productForm:labeledId']//label[contains(text(),'%radio%')]";
	public static String labelingTermsLabeledGetvalue = "xpath#//label[@id='productForm:eventtermsDataTable:0:j_id_3mi']";
	public static String labelingTermsConditionalLabelingCheckbox = "Conditional Labeling?";
	public static String labelingTermsIncludeFatalEventGetvalue = "xpath#//label[@id='productForm:eventtermsDataTable:0:j_id_3mk']";
	public static String labelingTermsIncludeFatalEventCheckbox = "Include Fatal Event?";
	public static String labelingTermsConditionalLabelingGetvalue = "xpath#//label[@id='productForm:eventtermsDataTable:0:j_id_3me']";
	public static String labelingTermsConditionaLabelingCommentsTextBox = "xpath#//textarea[@id='productForm:labeltermsComments']";
	public static String labelingTermsOKButton = "xpath#//button[@id='productForm:listProSrcId']";
	public static String labelingTermsCancelButton = "xpath#//button[@id='productForm:listProClearId']";
	public static String labelingAddAttrRouteOfAdminDropDown = "xpath#//label[@id='productForm:additionalAttributesDataTable:0:A2-1020_label']";
	public static String labelingAddAttrRouteOfAdminGetvalue = "xpath#//input[@id='productForm:additionalAttributesDataTable:0:A2-1020_focus']/ancestor::div/label";
	public static String labelingAddAttrFormOfAdminDropDown = "xpath#//label[@id='productForm:additionalAttributesDataTable:0:A3-805_label']";
	public static String labelingAddAttrFormOfAdminGetvalue = "xpath#//input[@id='productForm:additionalAttributesDataTable:0:A3-805_focus']/ancestor::div/label";
	public static String labelingProtocolNoTextbox = "xpath#//input[@id='productForm:additionalAttributesDataTable:0:protocolNo']";
	public static String labelingProtocolNoLookup = "xpath#//a[@id='productForm:additionalAttributesDataTable:0:addStudy:studyLookup']/img";
	public static String labelingStudyLookupProjectNoTextBox = "xpath#//input[@id='studyLookupForm:prjctId']";
	public static String labelingStudyLookupStudyNoTextBox = "xpath#//input[@id='studyLookupForm:studyNoSearch']";
	public static String labelingStudyLookupSearchButton = "xpath#//button[@id='studyLookupForm:studySearchButton']";
	public static String labelingStudyLookupClearButton = "xpath#//button[@id='studyLookupForm:j_id_625']";
	public static String labelingStudyLookupSearchSelectButton = "xpath#//tbody[@id='studyLookupForm:studyTable:studyLookUpDataTable_data']/descendant::span[@class='ui-radiobutton-icon ui-icon ui-icon-blank ui-c']";
	public static String labelingStudyLookupOkButton = "xpath#//button[@id='studyLookupForm:okButtonBottom']";
	public static String labelingStudyLookupCancelButton = "xpath#//button[@id='studyLookupForm:cancelButtonBottom']";
	public static String labelingStudyLookupLabelingReferenceTextBox = "xpath#//input[@id='productForm:additionalAttributesDataTable:0:labelingrefId']";
	public static String labelingIndicationAddIndicationLink = "xpath#//a[@id='productForm:addIndications']";
	public static String labelingIndicationAttachedIndicationLink = "xpath#//a[@id='productForm:addAttachedIndication']";
	public static String sMQCMQCodeLookup = "xpath#//a[@id='productForm:smqcmqLookupForProductLabel:smqcmqLookup']/img";
	public static String labelingTermPopUpHeader = "xpath#//span[text()='Labelling Terms']";
	public static String StrengthNumberLabel = "xpath#//span[text()='Strength(Number)']";
	public static String BasicDetails = "xpath#//a//span[contains(text(),'Basic Details')]";

	public static String StrengthNumber = "xpath#//input[@id='productForm:additionalAttributesDataTable:0:labelStrength']";
	public static String StrengthDD = "xpath#//label[@id='productForm:additionalAttributesDataTable:0:A1-9070_label']";
	///////////////////////////////////// AE's of Special Interest
	///////////////////////////////////// Page//////////////////////////////////////////////////////////////

	public static String aeOfSpecialInterestLink = "xpath#//span[contains(text(),\"AE's of Special Interest\")]";
	public static String aeOfSpecialInterestAddLink = "xpath#//a[@id='productForm:addaeSpecialIntrest']";
	public static String aeOfSpecialInterestDeleteLink = "xpath#//a[@id='productForm:deleteaeSpecialIntrest']";
	public static String aeOfSpecialInterestImportLink = "xpath#//span[@id='productForm:importaeSpecialIntrest_label']";
	public static String aeOfSpecialInterestExportLink = "xpath#//a[@id='productForm:exportaeSpecialIntrest']";
	public static String aeOfSpecialInterestDownloadTempLink = "xpath#//a[@id='productForm:tempaeSpecialIntrest']";
	public static String aeOfSpecialInterestMedraLookup = "xpath#//a[@id='productForm:aeSpecialIntrestDataTbl:%rowNo%:aeSIMeddraLookup']/img[contains(@src, 'icon-lookup.gif')]";
	public static String aeOfSpecialInterestPTTermTextBox = "xpath#//input[@id='productForm:aeSpecialIntrestDataTbl:%rowNo%:pptterm_input']";
	public static String aeOfSpecialInterestPTTermSuggestion = "xpath#//li[contains(@class, 'ui-autocomplete-list-item')][@data-item-value ='$term$']";
	public static String aeOfSpecialInterestPTCodeTextBox = "xpath#//input[@id='productForm:aeSpecialIntrestDataTbl:%rowNo%:siPtcode']";
	public static String aeOfSpecialInterestLLTTermTextBox = "xpath#//input[@id='productForm:aeSpecialIntrestDataTbl:%rowNo%:lltName']";
	public static String aeOfSpecialInterestLLTCodeTextBox = "xpath#//input[@id='productForm:aeSpecialIntrestDataTbl:%rowNo%:aeLltCode']";
	public static String aeOfSpecialInterestSOCNameTextBox = "xpath#//input[@id='productForm:aeSpecialIntrestDataTbl:%rowNo%:socName']";
	public static String aeOfSpecialInterestMedraVersionTextBox = "xpath#//input[@id='productForm:aeSpecialIntrestDataTbl:%rowNo%:medVersion']";
	public static String aePaginator = "xpath#//div[@id='productForm:aeSpecialIntrestDataTbl_paginator_top']";

	public static String aesigetLLTTerm = "xpath#//tbody[@id='productForm:aeSpecialIntrestDataTbl_data']/ancestor::table/tbody/tr/td[5]";
	public static String aesigetLLTTermList = "xpath#(//tbody[@id='productForm:aeSpecialIntrestDataTbl_data']/ancestor::table/tbody/tr/td[5])[{%count}]";

	public static String saveConfirmationPopup = "xpath#//span[text()='Action  Completed Successfully']";
	public static String ConfirmationOkBtn = "xpath#//button[@id='mandatoryDialogform:okButton']/span[text()='OK']";

	public static String labellingName = "xpath#//span[text()='%s']";
	public static String deleteLabellingDatasheet = "xpath#//a[@id='productForm:deleteDataSheets']";
	public static String deleteLabellingConfirmationPopUP = "xpath#//label[text()='Are you sure you want to delete the selected Data Sheet ?']";
	public static String YesBtn = "xpath#//button[@id='productForm:commonDeleteConfirmId']";

	// company unit
	public static String companyUnit_Label = "xpath#//label[text()='Company Unit Lookup']";
	public static String companyUnitRadioBtn = "xpath#//div[@id='manufaclookupSearchForm:manufacturingFacilityRadio']//tbody/tr/td//label[text()='Company Unit']/preceding::span[contains(@class,'ui-icon-bullet ui-c')]";
	public static String unitCode = "xpath#//input[@id='manufaclookupSearchForm:companyUnitCode']";
	public static String searchBtn = "xpath#//button[@id='manufaclookupSearchForm:companySearchId']";
	public static String selectRadioBtn = "xpath#//tbody[@id='manufaclookupSearchForm:companyUnitTable:companyUnitLookUpDataTable_data']/tr/td[1]/div//span";
	public static String okBtn = "xpath#//button[@id='manufaclookupSearchForm:bottomOkButton']/span";

	public static String productLabelingTab = "xpath#//a[@id='productForm:listednessTabId']/span[text()='Labeling']";

	/**********************************************************************************************************
	 * @Objective:get Question name by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:Pooja S Date :08-May-2020 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderList(String num) {
		String value = aesigetLLTTermList;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}

	///////////////////////////////////////////// Run Time X-Path Generation
	///////////////////////////////////////////// //////////////////////////////////

	/**********************************************************************************************************
	 * @Objective: The below method is created to pass Strength Radio Button Label
	 *             to be selected.
	 * @InputParameters: Radio Button Label
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String strengthRadioBtn(String label) {
		String value = strengthRadio.replace("%radio%", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Substance from Substance
	 *             LookUp Search Result
	 * @InputParameters: Substance Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String substanceSelectLookUp(String subName) {
		String value = subLookUpdataSelect.replace("{@}", subName);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to pass Substance Name for Check Box
	 *             Selection in Substance LookUp Search Result.
	 * @InputParameters: Substance Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectSubstanceLookUpCheckBox(String runTimeLabel) {
		String value = subLookUpDataSelectCheckBOx.replace("%s%", runTimeLabel);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Substance from Substance
	 *             LookUp Search Result
	 * @InputParameters: Substance Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String therapeuticAreaSelectLookUp(String subName) {
		String value = therapeuticAreaDataSelect.replace("{@}", subName);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to pass Substance Name for Check Box
	 *             Selection in Substance LookUp Search Result.
	 * @InputParameters: Substance Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String therapeuticAreaLookUpCheckBox(String runTimeLabel) {
		String value = therapeuticAreaDataSelectCheckBOx.replace("%s%", runTimeLabel);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to pass Strength Details in Substance
	 *             List View.
	 * @InputParameters: Substance Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String subStrengthLstViewTextBox(String subName) {
		String value = subStrengthListViewTextBox.replace("%s%", subName);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to pass Substance Name in Substance
	 *             List View.
	 * @InputParameters: Substance Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String substanceNameLstViewTextBox(String subName, String rowNo) {
		String value = substanceNameLabelListView.replace("%subName%", subName);
		value = value.replace("%rowNo%", rowNo);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to pass Substance Name in Substance
	 *             List View.
	 * @InputParameters: Substance Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String therapeuticAreaLabel(String therapName, String rowNo) {
		String value = therapeuticAreaLabel.replace("%therapName%", therapName);
		value = value.replace("%rowNo%", rowNo);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to pass PT Term in Labeling Terms
	 *             suggestion list.
	 * @InputParameters: PT Term
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 06-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String PTTermSuggestion(String PTTerm) {
		String value = labelingTermsPTTermSuggestion.replace("$term$", PTTerm);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to pass Labeled Radio Button Label to
	 *             be selected.
	 * @InputParameters: Radio Button Label
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 06-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String labeledRadioBtn(String label) {
		String value = labelingTermsLabeledRadio.replace("%radio%", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Country from Countries
	 *             search criteria in labeling -> Selected countries
	 * @InputParameters: Country
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 14-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String countriesSearchCriteria(String country) {
		String value = countrySelect.replace("{@}", country);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to pass Country for Check Box
	 *             Selection in Countries search criteria in labeling -> Selected
	 *             countries
	 * @InputParameters: Country
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 14-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String countriesSearchCriteriaCheckBox(String runTimeLabel) {
		String value = countrySelectCheckBox.replace("%s%", runTimeLabel);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to pass labeling name in product
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 09-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String labelingSheet(String Label) {
		String value = labellingName.replace("%s", Label);
		return value;
	}
}
