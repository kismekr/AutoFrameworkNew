package com.arisglobal.framework.components.lsmv.L10_1_1;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ApplicationConfig_WorkFlowPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.RuleBuilderBFCRules_PageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class RuleBuilderBFCRulesOperations extends ToolManager {
	
	static String className = RuleBuilderBFCRulesOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();


	/**********************************************************************************************************
	 * @Objective: To ensure a Rule is Active
	 * @InputParameters: Rule Builder Name, ISP Rule Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date: 24-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchEditCheckRules(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		System.out.println("ClassName: "+className);
		System.out.println("scenarioName "+scenarioName);
		if (agIsExists(RuleBuilderBFCRules_PageObjects.ruleBuilder_BreadCrumb)) {
			Reports.ExtentReportLog("", Status.INFO, "User is in RuleBuilderListing page already", true);
		} else {
			ApplicationConfigOperations.applicationConfigurationsNavigations("ruleBuilder");
			Reports.ExtentReportLog("", Status.INFO, "User is directed to RuleBuilderListing page", true);
		}
		
		agWaitTillVisibilityOfElement(RuleBuilderBFCRules_PageObjects.selectBuilderEditIcon(getTestDataCellValue(scenarioName, "RuleBuilderName")));
		agClick(RuleBuilderBFCRules_PageObjects.selectBuilderEditIcon(getTestDataCellValue(scenarioName, "RuleBuilderName")));
		
		agWaitTillVisibilityOfElement(RuleBuilderBFCRules_PageObjects.search_TextBox);
		agSetValue(RuleBuilderBFCRules_PageObjects.search_TextBox, getTestDataCellValue(scenarioName, "RuleName"));
		agClick(RuleBuilderBFCRules_PageObjects.search_Icon);

		agWaitTillVisibilityOfElement(RuleBuilderBFCRules_PageObjects.selectRuleEditIcon(getTestDataCellValue(scenarioName, "RuleName")));
		Reports.ExtentReportLog("", Status.PASS, "<br />"+ getTestDataCellValue(scenarioName, "RuleName") 
				+ " validation is listed under Edit-check rules.", true);
	}
	

	/**********************************************************************************************************
	 * @Objective: To ensure a Rule is Active
	 * @InputParameters: Rule Builder Name, ISP Rule Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date: 24-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void enableRule(String scenarioName) {
		agWaitTillVisibilityOfElement(RuleBuilderBFCRules_PageObjects.selectRuleEditIcon(getTestDataCellValue(scenarioName, "RuleName")));
		agClick(RuleBuilderBFCRules_PageObjects.selectRuleEditIcon(getTestDataCellValue(scenarioName, "RuleName")));
		
		CommonOperations.clickCheckBoxLeftOf(RuleBuilderBFCRules_PageObjects.active_Label, "true");
		agSetStepExecutionDelay("2000");
		Reports.ExtentReportLog("", Status.PASS, "", true);
		
		agClick(RuleBuilderBFCRules_PageObjects.save_Btn);
		agWaitTillVisibilityOfElement(RuleBuilderBFCRules_PageObjects.confirmationWinTitle);
		System.out.println("Acknowledgement after Save: "+agGetText(RuleBuilderBFCRules_PageObjects.confirmationWinInfo_Text));
		Reports.ExtentReportLog("", Status.PASS, "As Expected", false);
		Reports.ExtentReportLog("", Status.PASS, "<br />" + "Rule is Active", true);
		agClick(RuleBuilderBFCRules_PageObjects.confirmationWinOK_Btn);
	}

}
