package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class UsersPageObjects {

	public static String searchListing_TextBox = "xpath#//input[@id='userForm:tabView:keyword']";
	public static String search_Icon = "xpath#//img[contains(@id, 'userForm:') and contains(@src, 'search_icon.png')]";
	public static String paginator = "xpath#//div[@id='userForm:tabView:userDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String edit_Icon = "xpath#//img[contains(@id,':editIcon')]";
	public static String newButton = "xpath#//a[@id='userForm:tabView:newId']";
	public static String deleteButton = "xpath#//a[@id='userForm:deleteId']";
	public static String saveButton = "xpath#//button[@id='userDetailsForm:visibleSave']";
	public static String cancelButton = "xpath#//button[@id='userDetailsForm:cancelId']";

	/////////////////////////////////// Administration >> Users >> General User
	/////////////////////////////////// Details
	/////////////////////////////////// ////////////////////////////////////////////////////////

	public static String userType_RadioBtn = "User Type";
	public static String title_DropDown = "xpath#//label[@id='userDetailsForm:C6-5014_label']";
	public static String firstName_TextBox = "xpath#//input[@id='userDetailsForm:firstname']";
	public static String middleName_TextBox = "xpath#//input[@id='userDetailsForm:middlename']";
	public static String lastName_TextBox = "xpath#//input[@id='userDetailsForm:lastname']";
	public static String designation_TextBox = "xpath#//input[@id='userDetailsForm:designation']";
	public static String department_DropDown = "xpath#//label[@id='userDetailsForm:department_label']";
	public static String userName_TextBox = "xpath#//input[@id='userDetailsForm:username']";
	public static String ssoUser_CheckBox = "SSO User";
	public static String webServiceUser_CheckBox = "Web Service User";
	public static String ldapDomain_DropDown = "xpath#//label[@id='userDetailsForm:ldapdomain_label']";
	public static String companyUnit_DropDown = "xpath#//label[@id='userDetailsForm:companyUnit_label']";
	public static String degree_TextBox = "xpath#//input[@id='userDetailsForm:degree']";
	public static String emailId_TextBox = "xpath#//input[@id='userDetailsForm:emailid']";
	public static String mobileId_TextBox = "xpath#//input[@id='userDetailsForm:mobileid']";
	public static String phoneCntryCode_TextBox = "xpath#//input[@id='userDetailsForm:phoneCntryCode']";
	public static String phoneAreaCode_TextBox = "xpath#//input[@id='userDetailsForm:phoneAreaCode']";
	public static String phoneNo_TextBox = "xpath#//input[@id='userDetailsForm:phoneNo']";
	public static String faxCntryCode_TextBox = "xpath#//input[@id='userDetailsForm:faxCntryCOde']";
	public static String faxAreaCode_TextBox = "xpath#//input[@id='userDetailsForm:faxAreaCode']";
	public static String faxNumber_TextBox = "xpath#//input[@id='userDetailsForm:fax']";
	public static String batchPrintLimit_TextBox = "xpath#//input[@id='userDetailsForm:batchPrintLimit']";
	public static String batchPrintRunningCount_TextBox = "xpath#//input[@id='userDetailsForm:batchPrintRunningCount']";
	public static String accountLocked_CheckBox = "Account Locked";
	public static String active_CheckBox = "Active";
	public static String alsoPortalUser_CheckBox = "Also A Portal User";
	public static String deleteAccess_CheckBox = "Delete Access";
	public static String multiDatabaseAccess_CheckBox = "Multi Database Access";
	public static String loginUnderMaintenance_CheckBox = "Login Under Maintenance";

	// Portal Settings
	public static String studyManager_CheckBox = "Study Manager";
	public static String adverseEvent_CheckBox = "Adverse Event";
	public static String adverseEventListing_CheckBox = "Adverse Event Listing";
	public static String adverseEventFollowUp_CheckBox = "Adverse Event Follow-up";
	public static String documents_CheckBox = "Documents";
	public static String hcpDocumentSearch_CheckBox = "HCP Document Search";
	public static String FAQs_CheckBox = "FAQs";
	public static String reporterOffLineAccess_CheckBox = "Reporter OffLine Access";

	///////////////////////////////////// Password Settings
	///////////////////////////////////// /////////////////////////////////////////////////////////////////////////////////////////

	public static String passwordSettings_div = "xpath#//label[contains(@id, 'userDetailsForm:') and text()= 'Password Settings']";
	public static String password_TextBox = "xpath#//input[@id='userDetailsForm:password']";
	public static String confirmPassword_TextBox = "xpath#//input[@id='userDetailsForm:confirmPassword']";

	//////////////////////////////////// Company Unit(s) / Processing Unit(s)
	//////////////////////////////////// ////////////////////////////////////////////////////////////////////////

	public static String companyUnitProcessingUnit_Label = "xpath#//label[contains(@id, 'userDetailsForm:') and text()= 'Company Unit(s) / Processing Unit(s)']";
	public static String caseListingAccess_RadioBtn = "xpath#//label[text()= '%labelName%']/preceding-sibling::div/descendant::span[contains(@class, 'ui-radiobutton-icon')]";

	public static String allCompanyUnits_label = "All Company Units";
	public static String allCompanyUnits_DropDown = "xpath#//label[@id='userDetailsForm:CU-529_label']";
	public static String default_DropDown = "xpath#//label[@id='userDetailsForm:defaultCuId_label']";
	public static String allCompUnitsRead_RadioBtn = "xpath#//label[contains(@id, 'userDetailsForm:cuDataTable') and text() = '%recordName%']/ancestor::tr/descendant::span[contains(@class,'ui-radiobutton')][1]";
	public static String allCompUnitsDefault_RadioBtn = "xpath#//label[contains(@id, 'userDetailsForm:cuDataTable') and text() = '%recordName%']/ancestor::tr/descendant::span[contains(@class,'ui-radiobutton')][2]";

	public static String allProcessingUnits_label = "All Processing Units";
	public static String allProcessingUnits_DropDown = "xpath#//label[@id='userDetailsForm:PU-529_label']";
	public static String allProcessingUnitsRead_RadioBtn = "xpath#//label[contains(@id, 'userDetailsForm:puDataTable') and text() = '%recordName%']/ancestor::tr/descendant::span[contains(@class,'ui-radiobutton')]";

	//////////////////////////////// Distribution Units/Contacts ID
	//////////////////////////////// ////////////////////////////////////////////////////////////////////////////

	public static String DistributionUnitsContactsID_Label = "xpath#//label[contains(@id, 'userDetailsForm:') and text()= 'Distribution Units/Contacts ID']";
	public static String allUnitsContactsID_label = "All Units/Contacts ID";
	public static String allUnitsContactsID_DropDown = "xpath#//label[@id='userDetailsForm:CID-529_label']";
	//// public static String contactNameRead_RadioBtn =
	//// "xpath#//table[contains(@id,
	//// 'userDetailsForm:subContactIdDataTable:%rowNo%:')]/descendant::span[contains(@class,
	//// 'ui-icon-blank')]";

	//////////////////////////////// Submitting Units
	//////////////////////////////// ////////////////////////////////////////////////////////////////////////////////////////

	public static String submittingUnits_Label = "xpath#//label[contains(@id, 'userDetailsForm:') and text()= 'Submitting Units']";
	public static String allSubmittingUnits_label = "All Submitting Units";
	public static String allSubmittingUnits_DropDown = "xpath#//label[@id='userDetailsForm:SUID-529_label']";

	// Submission Contact Lookup
	public static String contactName_TextBox = "xpath#//input[@id='subContactaLookupForm:contactName']";
	public static String searchSubContactLookup_Button = "xpath#//button[@id='subContactaLookupForm:subContactSearchButton']";
	public static String okSubContactLookup_Button = "xpath#//button[@id='subContactaLookupForm:okButtonBottom']";

	//////////////////////////////// Roles
	//////////////////////////////// //////////////////////////////////////////////////////////////////////////////////////////////////////

	public static String roles_div = "xpath#//label[contains(@id, 'userDetailsForm:') and text()= 'Roles']";
	public static String roles_label = "Roles";
	public static String roleName_TextBox = "xpath#//input[@id='rolesLookupSearchForm:roleName']";
	public static String searchRolesLookup_Button = "xpath#//button[@id='rolesLookupSearchForm:findRoles']";
	public static String okRolesLookup_Button = "xpath#//button[@id='rolesLookupSearchForm:okButtonbottom']";
	//// public static String rolesDefault_RadioBtn = "xpath#//table[contains(@id,
	//// 'userDetailsForm:rolesDataTable:%rowNo%:')]/descendant::span[contains(@class,
	//// 'ui-icon-blank')]";

	//////////////////////////////// Group
	//////////////////////////////// //////////////////////////////////////////////////////////////////////////////////////////////////////////

	public static String group_div = "xpath#//label[contains(@id, 'userDetailsForm:') and text()= 'Group']";
	public static String group_label = "Group";
	public static String groupName_TextBox = "xpath#//input[@id='userGroupLookupForm:userGroupKeyword']";
	public static String searchGroupLookup_Button = "xpath#//button[@id='userGroupLookupForm:findButtonForGroup']";
	public static String okGroupLookup_Button = "xpath#//button[@id='userGroupLookupForm:okButtonBottomForGroup']";

	//////////////////////////////// Other Details Tab
	//////////////////////////////// //////////////////////////////////////////////////////////////////////////////////////////////

	public static String maxNoOfCasesDayUser_TextBox = "xpath#//input[@id='userDetailsForm:cases']";
	public static String accessAllEligibleProducts_CheckBox = "Access All Eligible Products";
	public static String generateApiKey_Button = "xpath#//span[contains(text(),'Generate Api Key')]";

	////////////////////////////// Common Object for User Screen
	////////////////////////////// //////////////////////////////////////////////////////////////////////////////////

	public static String divAdd_Button = "xpath#//label[text()='%divName%']/ancestor::span[@class='ui-panel-title']/*/a[text()='Add']";
	public static String select_RadioButton = "xpath#//label[text() = '%divName%']/ancestor::tr/descendant::span[contains(@class,'ui-radiobutton')]";
	public static String otherDetails_Tab = "xpath#//a[@id = 'userDetailsForm:sourceDocMenuId']/span[contains(text(),'Other Details')]";

	/**********************************************************************************************************
	 * @Objective: The below method is created to click on Add button of specified
	 *             Div label passing value at runtime.
	 * @InputParameters: divName
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Sanchit
	 * @Date : 10-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String clickAddButtonOf(String divName) {
		String actualLocator = divAdd_Button;
		String resultLocator = actualLocator.replace("%divName%", divName);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click on Case Listing Access Radio
	 *             Button
	 * @InputParameters: divName
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Sanchit
	 * @Date : 11-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String caseListingAccessRadioBtn(String labelName) {
		String actualLocator = caseListingAccess_RadioBtn;
		String resultLocator = actualLocator.replace("%labelName%", labelName);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click on Read or Default Radio
	 *             Button in grids
	 * @InputParameters: divName
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Sanchit
	 * @Date : 11-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectGridRadioButton(String labelName) {
		String actualLocator = select_RadioButton;
		String resultLocator = actualLocator.replace("%divName%", labelName);
		return resultLocator;
	}
}
