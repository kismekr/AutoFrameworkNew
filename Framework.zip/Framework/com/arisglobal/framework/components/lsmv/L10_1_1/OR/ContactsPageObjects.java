package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class ContactsPageObjects {

	public static String contactsNewLable = "xpath#//div[@class='panel-title']/label[text()='Contact Details']";
	public static String contactsListingLable = "xpath#//span[@id='contactListform:header']/label[text()='Listing']";
	public static String unresolvedCorrespondence = "xpath#//a[@id='headerForm:unresolvedCorrespondenceContactId']//span[@class='ui-menuitem-text'][contains(text(),'Unresolved correspondence')]";
	public static String unresolvedCorrespondenceLable = "xpath#//div[@id='unresolvedCorrespondenceForm:header']//label[text()='Unresolved Correspondence']";
	public static String paginator = "xpath#//div[@id='contactListform:tabView:contactDataTable_paginator_top']/span[@class='ui-paginator-current']";

	public static String saveButton = "xpath#//button[@id='addNewPerson:visibleSave'][@title='CTRL + S']";
	public static String saveExitButton = "xpath#//button[@id='addNewPerson:saveAndExitId'][@title='CTRL + SHIFT + S']";
	public static String cancelButton = "xpath#//button[@id='addNewPerson:cancelId']";
	public static String deleteButton = "xpath#//a[@id='contactListform:tabView:deleteId']";
	public static String contactCreatedMsg = "xpath#//div[contains(@id,'mandatoryDialogform')]//label[contains(text(),'Saved Successfully')]";
	public static String okButton = "xpath#//button[@id='mandatoryDialogform:okButton']";
	public static String searchRecEdit = "xpath#//span[text()='%s']//parent::a[@id='contactListform:tabView:contactDataTable:0:contactViewId']//parent::td//preceding-sibling::td//img[contains(@src,'Edit')]";

	// Contacts Module Menu Navigation Validation point
	public static String contactsHover = "xpath#//span[contains(text(),'Contacts')]";
	public static String contactsNew = "xpath#//a[@id='headerForm:contactNewId']";
	public static String contactsListing = "xpath#//a[@id='headerForm:contactListId']//span[@class='ui-menuitem-text'][contains(text(),'Listing')]";
	public static String contactsListingKeywordsearch = "xpath#//input[@id='contactListform:tabView:searchcriteria']";
	public static String ContactunresolvedCorrespondence = "xpath#//a[@id='headerForm:unresolvedCorrespondenceContactId']//span[@class='ui-menuitem-text'][contains(text(),'Unresolved correspondence')]";
	public static String ContactunresolvedCorresKeywordsearch = "xpath#//input[@id='unresolvedCorrespondenceForm:keyword']";
	public static String contactsListingKeywordsearchIcon = "xpath#//img[contains(@id,'contactListform')][contains(@alt,'Search')]";

	// Advansearch
	public static String advanceSearchBtn = "xpath#//a[@id='contactListform:tabView:featuredSearch']";
	public static String advaSrchContactIDTxtFeild = "xpath#//input[@id='contactListform:tabView:contactId']";
	public static String advSearchBtn = "xpath#//button[@id='contactListform:tabView:cntSearch']";

	// Export to excel button

	public static String downloadIcon = "xpath#//a[@id='contactListform:tabView:actionId']";
	public static String exporttoExcel_link = "xpath#//button[contains(@id,'contactListform:tabView:excel')]/span[text()='Export To Excel']";
	public static String exporttoExcel_popup = "xpath#//span[@id='contactListform:tabView:columnSelectionDialogId_title']";
	public static String export_Btn = "xpath#//button[@id='contactListform:tabView:submitId']";
	public static String exportexcelcancel_Btn = "xpath#//button[@id='contactListform:tabView:cancelDialogId']";
	public static String get_contact = "xpath#//tbody[@id='listingForm:moietyDataTable_data']/tr/td[@class='EditIcon']/following-sibling::td[1]";
	// ContactListingcsreen
	public static String searchedContactRecordId = "xpath#//span[@id='contactListform:contactDataTable:0:contactId']";
	public static String searchedContactRecordfName = "xpath#//span[@id='contactListform:contactDataTable:0:contactFnameId']";
	public static String searchedContactRecordlName = "xpath#//span[@id='contactListform:contactDataTable:0:contactLnameId']";
	public static String searchedContactRecordmName = "xpath#//span[@id='contactListform:contactDataTable:0:contactMnameId']";
	public static String searchedContactRecordemailId = "xpath#//span[@id='contactListform:contactDataTable:0:contactEmailId']";

	// New-ContactDetails
	public static String titleDropdownLabel = "xpath#//label[@id='addNewPerson:tabView:C-5014_label']";
	public static String contactsFirstName = "xpath#//input[@id='addNewPerson:tabView:fn1']";
	public static String contactsLastName = "xpath#//input[contains(@id,'addNewPerson:tabView:ln1')]";
	public static String contactsMiddleName = "xpath#//input[contains(@id,'addNewPerson:tabView:mn1')]";
	public static String suffixLabel = "xpath#//label[contains(@id,'addNewPerson:tabView:C-5036_label')]";
	public static String preferredContactMedium = "xpath#//label[contains(@id,'addNewPerson:tabView:communi_label')]";
	public static String doNotContactLabel = "xpath#//label[contains(@id,'addNewPerson:tabView:j_id_pi')]";
	public static String companyUnitLabel = "xpath#//label[contains(@id,'addNewPerson:tabView:companyUnit_label')]";
	public static String senderTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:accountName_lookup')]";

	// SenderLookUp>
	public static String senderLookupIcon = "xpath#//img[contains(@id,'addNewPerson:tabView:account')][@title='Sender Lookup']";
	public static String searchByAccountLabel = "xpath#//label[contains(@for,'accountLookup:librarySearchFlag:0')][text()='Search By Account']";
	public static String searchByCompanyUnitLabel = "xpath#//label[contains(@for,'accountLookup:librarySearchFlag:1')][text()='Search By Company Unit']";
	public static String accountNameTextbox = "xpath#//input[contains(@id,'accountLookup:accountName')][contains(@title,'Account Name')]";
	public static String domainTextbox = "xpath#//input[contains(@id,'accountLookup:accountDomain')][contains(@title,'Domain')]";
	public static String FEINumberTextbox = "xpath#//input[contains(@id,'accountLookup:feiNumber')][contains(@title,'Firm/Site FEI Number')]";
	public static String accountGroupName = "xpath#//input[contains(@id,'accountLookup:accGroupName')]";
	public static String unitCodeTextbox = "xpath#//input[contains(@id,'accountLookup:compUnitCode')]";
	public static String unitNameTextbox = "xpath#//input[contains(@id,'accountLookup:compUnit')][@title='Unit Name']";
	public static String typeLabel = "xpath#//label[contains(@id,'accountLookup:CompanyUnitLookup-9_label')]";
	public static String countryLabel = "xpath#//label[contains(@id,'accountLookup:CompanyLookup-1_label')]";
	public static String searchSenderButton = "xpath#//button[contains(@id,'accountLookup:findButton')]";
	public static String clearButton = "xpath#//button[contains(@id,'accountLookup:clear')]";
	public static String okSenderbyAccountButton = "xpath#//button[contains(@id,'accountLookup:okButton1')]";
	public static String cancelSenderButton = "xpath#//button[contains(@id,'accountLookup:cancelButton2')]";
	public static String searchBycompanyUnitButton = "xpath#//button[@id='accountLookup:companySearchId']";
	public static String clearsearchBycompanyUnitButton = "xpath#//button[@id='accountLookup:companyClearId']";
	public static String selectRadioRecord = "xpath#//tr[@data-ri='0']/td/div/div[2]/span[1]";
	public static String okSenderbyCUnitButton = "xpath#//button[contains(@id,'//button[contains(@id,'accountLookup:bottomOkButton')]')]";
	public static String senderSuggestionListItem = "xpath#//li[@class='ui-autocomplete-item ui-autocomplete-list-item ui-corner-all ui-state-highlight']";
	public static String clickDepartment_DropDwn = "xpath#//tr[@data-ri='0']/td/div/div[2]/span[1]";

	public static String phCountryCodeTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:countrycode1')][contains(@title,'Country Code')]";
	public static String phAreaCode = "xpath#//input[contains(@id,'addNewPerson:tabView:extno')][contains(@title,'Area Code')]";
	public static String phNumberTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:officeno')][contains(@title,'Number')]";
	public static String extensionNumber = "xpath#//input[contains(@id,'addNewPerson:tabView:extnno')][contains(@title,'Extension Number')]";
	public static String faxCountryCodeTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:countrycode2')][contains(@title,'Country Code')]";
	public static String faxAreaCode = "xpath#//input[contains(@id,'addNewPerson:tabView:extno1')][contains(@title,'Area Code')]";
	public static String faxNumberTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:faxno')][contains(@title,'Number')]";
	public static String faxExtNumberTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:extnumberFax')][contains(@title,'Number')]";
	public static String emailAddressTextarea = "xpath#//textarea[contains(@id,'addNewPerson:tabView:emailid')][contains(@title,'Email Address')]";
	public static String otherPhoneNumberTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:resi1')][contains(@title,'Other Phone Number')]";
	public static String degreeTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:degree')][contains(@title,'Degree')]";
	public static String genderLabel = "xpath#//label[contains(@id,'addNewPerson:tabView:C-5032_label')]";
	public static String contactCategoryLabel = "xpath#//label[contains(@id,'addNewPerson:tabView:requesterTyperadio_label')]";
	public static String contactSubCategoryLabel = "xpath#//label[contains(@id,'addNewPerson:tabView:reqCategory_label')]";
	public static String Specialization_Label = "xpath#//label[contains(@id, 'addNewPerson:tabView:') and text() ='Specialization']";
	public static String SpecializationLabel = "xpath#//label[contains(@id,'addNewPerson:tabView:C-345_label')]";
	public static String otherSpecializationTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:others')]";
	public static String primaryAccountTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:organizeid_input')]";
	public static String departmentLabel = "xpath#//label[@id='addNewPerson:tabView:department_label']";
	public static String activeCheckLabel = "xpath#//label[contains(@id,'addNewPerson:tabView:active')][text()='Active']";
	public static String publicCheckLabel = "xpath#//label[contains(@id,'addNewPerson:tabView:public')][text()='Public']";
	public static String consentToCaptureDetailsCheckLabel = "xpath#//label[contains(@id,'addNewPerson:tabView:consent')][text()='Consent to Capture Details']";
	public static String consentToShareCheckLabel = "xpath#//label[contains(@id,'addNewPerson:tabView:consentshare')][text()='Consent to Share']";
	public static String setDepartmentValue = "xpath#//ul[@id='addNewPerson:tabView:department_items']/li[contains(text(),'%s')]";
	public static String clickGenderDrpdown = "xpath#//label[@id='addNewPerson:tabView:C-5032_label']/following-sibling::div/span";
	public static String setGenderDrpdown = "xpath#//ul[@id='addNewPerson:tabView:C-5032_items']/li[text()='%s']";

	// New-E2BDetails

	public static String e2bDetails_Div = "xpath#//label[contains(@id, 'addNewPerson:tabView:') and text() ='E2B Details']";
	public static String dateInformedLabel = "xpath#//label[contains(@id,'addNewPerson:tabView:dateInformed_label')]";
	public static String archiveBasedOnDateInformedCheckLabel = "xpath#//label[contains(@id,'addNewPerson:tabView:j_id_xh')]";
	public static String icsrAckRequiredCheckLabel = "xpath#//label[contains(@id,'addNewPerson:tabView:j_id_xl')][text()='ICSR ACK Required']";
	public static String archiveBasedOnDateInformed_Label = "Archive based on Date Informed";
	public static String icsrACKRequired_Label = "ICSR ACK Required";

	// New-Addresses

	public static String addresses_Div = "xpath#//label[contains(@id, 'addNewPerson:tabView:') and text() ='Addresses']";
	public static String addAddressLink = "xpath#//a[contains(@id,'addNewPerson:tabView:Add')][text()='Add']";
	public static String addressCountryLabel = "xpath#//label[contains(@id,'addNewPerson:tabView:C-1015_label')]";
	public static String postalCodeBrickTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:postalCode')]";
	public static String postalCodeZipcodeTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:zipcode')]";
	public static String houseOrAptNumberTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:houseNumber')]";
	public static String streetAddressTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:streetAddress')][contains(@title,'Street Address')]";
	public static String addressTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:address1')][contains(@title,'Address1')]";
	public static String address2Textbox = "xpath#//input[contains(@id,'addNewPerson:tabView:address2')][contains(@title,'Address2')]";
	public static String cityTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:cityname')][contains(@title,'City')]";
	public static String stateTextbox = "xpath#//input[contains(@id,'addNewPerson:tabView:statename')][contains(@title,'State')]";
	public static String typelabel = "xpath#//label[contains(@id,'addNewPerson:tabView:C-9021_label')]";
	public static String primaryaddresslabel = "xpath#//label[contains(@id,'addNewPerson:tabView:defaultContactAddress')][text()='Primary Address']";

	// Company Unit Tab
	public static String companyUnit_Link = "xpath#//a[contains(@href, 'tabView:companyUnitTab') and text() = 'Company Unit']";

	public static String allCompanyUnit_CheckBox = "All Company Units";
	public static String companyUnit_LookUpIcon = "xpath#//a[@id = 'addNewPerson:tabView:contactCompanyUnit:companyUnitLookup']/img[contains(@src, 'Lookup_Selection')]";

	// Account Tab

	public static String account_Link = "xpath#//a[contains(@href, '#addNewPerson:tabView:accountsTab') and text() = 'Accounts']";
	public static String allAccount_CheckBox = "All Accounts";

	public static String setDepartmentValue(String dept) {
		String value = setDepartmentValue.replace("%s", dept);
		return value;
	}

	public static String searchRecEdit(String contactId) {
		String value = searchRecEdit.replace("%s", contactId);
		return value;
	}

	public static String setGender(String gender) {
		String value = setGenderDrpdown.replace("%s", gender);
		return value;
	}

}
