
package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class JP_EvaluationPageObjects {
	
	//JP.Evalution General information
	public static String japaneseCounterMeasurement = "xpath#//textarea[@id='adverseEventNew:basicDetailsDataTable:japaneseCounterMeasure-102920_input']";
	public static String otherComments = "xpath#//textarea[@id='adverseEventNew:basicDetailsDataTable:japaneseOtherCommnets-102920_input']";	
	public static String centerGridloader = "xpath#//div[@id='adverseEventNew:angularLoader']/img";
	public static String JpnDomesticFDE = "xpath#//span[@id='adverseEventNew:jaFDEId']";
	public static String jpEvaluation = "xpath#//li/a[text()='JP. Evaluation']";
	public static String jpnRegClockStartDate = "xpath#//input[@id='adverseEventNew:general:regClockStartDateJap']";
	public static String commentOnRegStartDate = "xpath#//textarea[@id='adverseEventNew:general:regClockStartDateComment']";
	public static String genInformationtab = "xpath#//a[text()='General information']";
	public static String retrospectiveSurveyOfInfection = "xpath#//textarea[@id='adverseEventNew:basicDetailsDataTable:retroSurveyOfInfection-114655_input']";
}
