package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ActiveMoietyPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.LibrariesPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.PharmacologicalClassPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Libraries_ActiveMoiety extends ToolManager {
	static String className = Libraries_ActiveMoiety.class.getSimpleName();

	static boolean status;

	/********************************************************************************************************
	 * @Objective: The below method is created to add Pharmacological Class from
	 *             lookup.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 17-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addPharmacologicalClass(String scenarioName) {

		String excelData = getTestDataCellValue(scenarioName, "PHARMACOLOGICALCLASSCODE");
		String[] data = excelData.split(",");
		for (int i = 1; i < data.length; i++) {
			agClick(ActiveMoietyPageObjects.pharmacologicalClass_Lookupicon);
			agSetStepExecutionDelay("3000");
			agAssertVisible(ActiveMoietyPageObjects.pharmacologicalClass_label);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agSetValue(ActiveMoietyPageObjects.keywordSearchLookup_TxtField, data[i]);
			agClick(ActiveMoietyPageObjects.lookupsearch_Btn);
			agClick(ActiveMoietyPageObjects.selectCheckbox(data[i]));
			CommonOperations.takeScreenShot();
			agClick(ActiveMoietyPageObjects.lookupOk_Btn);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit and update active moiety.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateActiveMoiety(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(ActiveMoietyPageObjects.edit_Icon);
		createActiveMoiety(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit and verify active moiety.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 21-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyActiveMoiety(String scenarioName) {
		agClick(ActiveMoietyPageObjects.edit_Icon);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ActiveMoiety"),
				ActiveMoietyPageObjects.activeMoiety_TxtField);
		String excelData = getTestDataCellValue(scenarioName, "PHARMACOLOGICALCLASSNAME");
		String[] data = excelData.split(",");
		for (int i = 0; i < data.length; i++) {
			agCheckPropertyText(data[i], ActiveMoietyPageObjects.getPHARMACOLOGICALCLASS(Integer.toString(i)));
		}
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Description"),
				ActiveMoietyPageObjects.description_TextArea);
		CommonOperations.takeScreenShot();
		agClick(ActiveMoietyPageObjects.cancel_Btn);
		agIsVisible(ActiveMoietyPageObjects.paginator);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search active moiety.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 17-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void search(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(ActiveMoietyPageObjects.keywordSearch_TxtField, getTestDataCellValue(scenarioName, "ActiveMoiety"));
		agClick(ActiveMoietyPageObjects.search_Icon);
		agIsVisible(ActiveMoietyPageObjects.paginator);
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search active moiety.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 17-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreateActiveMoiety(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		if (verifysearchData(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Activity Moiety already exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "ActiveMoiety"),
					ActiveMoietyPageObjects.get_activtemoiety);
		} else {
			agClick(ActiveMoietyPageObjects.new_Btn);
			createActiveMoiety(scenarioName);
			search(scenarioName);
			VerifyActiveMoiety(scenarioName);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search active moiety.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 03-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreateActiveMoietyRecord(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		if (verifysearchData(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Activity Moiety already exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "ActiveMoiety"),
					ActiveMoietyPageObjects.get_activtemoiety);
		} else {
			agClick(ActiveMoietyPageObjects.new_Btn);
			createActiveMoiety(scenarioName);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Active Moiety exist or not
	 *             based on ActiveMoiety name
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 23-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Boolean verifysearchData(String scenarioName) {
		Boolean falg = false;
		String paginator = agGetText(ActiveMoietyPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			List<WebElement> list = agGetElementList(ActiveMoietyPageObjects.get_ListofActiveMoiety);
			String columnHeader = null;
			for (int j = 1; j <= list.size(); j++) {
				columnHeader = agGetText(ActiveMoietyPageObjects.columnHeaderList(Integer.toString(j)));
				if (getTestDataCellValue(scenarioName, "ActiveMoiety").equalsIgnoreCase(columnHeader)) {
					falg = true;
					break;
				}
			}
		}
		return falg;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search active moiety.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 17-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchActiveMoiety(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		String paginator = agGetText(ActiveMoietyPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "ActiveMoiety"),
					ActiveMoietyPageObjects.get_activtemoiety);
			Reports.ExtentReportLog("", Status.PASS, "Search Activity Moiety: Activity Moiety Listed", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Search Activity Moiety: Activity Moiety Not Listed", true);
		}
		// agClick(ActiveMoietyPageObjects.refresh_Icon);
		agIsVisible(LibrariesPageObjects.activeMoietyKeywordSearch);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search for deleted active moiety.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 18-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchDeleteActiveMoiety(String scenarioName) {
		search(scenarioName);
		String paginator = agGetText(ActiveMoietyPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.FAIL,
					"Search for Deleted Activity Moiety: Deleted Activity Moiety is listed", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS,
					"Search for Deleted Activity Moiety: Deleted Activity Moiety is not listed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete active moiety.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 18-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void delete(String scenarioName) {
		agClick(ActiveMoietyPageObjects.delete_Btn);
		agSetStepExecutionDelay("5000");
		agClick(PharmacologicalClassPageObjects.deleteYes_Button);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.verifyMessage(scenarioName);
		CommonOperations.agClick(CommonPageObjects.validaionOk_Btn);
		//CommonOperations.setDeleteAuditInfo(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete active moiety.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 18-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteActiveMoiety(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		String paginator = agGetText(ActiveMoietyPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "ActiveMoiety"),
					ActiveMoietyPageObjects.get_activtemoiety);
			Reports.ExtentReportLog("", Status.PASS, "Activity Moiety Found", true);
			agClick(ActiveMoietyPageObjects.selectListingCheckbox(getTestDataCellValue(scenarioName, "ActiveMoiety")));
			delete(scenarioName);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Activity Moiety Not Found", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download active moiety export to
	 *             excel.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 18-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportToexcel(String FileName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(ActiveMoietyPageObjects.downloadIcon);
		agClick(ActiveMoietyPageObjects.exporttoExcel_link);
		agWaitTillVisibilityOfElement(ActiveMoietyPageObjects.export_Btn);
		if (agIsVisible(ActiveMoietyPageObjects.export_Btn) == true) {
			agClick(ActiveMoietyPageObjects.export_Btn);
			try {
				Thread.sleep(8000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			CommonOperations.move_Downloadedexcel(FileName);
			agClick(ActiveMoietyPageObjects.exportexcelcancel_Btn);
		} else {
			Reports.ExtentReportLog("Export to excel pop is not displayed", Status.INFO, "", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to compare record count with download
	 *             excel
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:Avinash K
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void recordCountVerification(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		String count = xls.getCellData("ActiveMoiety", 2, 4);
		String[] Totalcount = count.split(":");
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in exported excel::" + Totalcount[1].trim(),
				false);
		String applrecordcount = agGetText(ActiveMoietyPageObjects.paginator);
		String[] data = applrecordcount.split(" ");
		String recordCount = data[4];
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in application::" + recordCount, false);
		if (recordCount.equalsIgnoreCase(Totalcount[1].trim())) {
			Reports.ExtentReportLog("", Status.PASS, "Record count verification is successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Record count verification is Unsuccessfull", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create active moiety.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 17-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createActiveMoiety(String scenarioName) {

		agAssertVisible(ActiveMoietyPageObjects.activeMoiety_Lable);
		agSetValue(ActiveMoietyPageObjects.activeMoiety_TxtField, getTestDataCellValue(scenarioName, "ActiveMoiety"));
		if (getTestDataCellValue(scenarioName, "PharmacologicalClass").equalsIgnoreCase("True")) {
			addPharmacologicalClass(scenarioName);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Pharmacological Class is not added", true);
		}
		agSetValue(ActiveMoietyPageObjects.description_TextArea, getTestDataCellValue(scenarioName, "Description"));
		CommonOperations.takeScreenShot();
		agClick(ActiveMoietyPageObjects.save_Btn);
		CommonOperations.setAuditInfo(scenarioName);
		agIsVisible(LibrariesPageObjects.activeMoietyLable);
		CommonOperations.takeScreenShot();
	}
}
