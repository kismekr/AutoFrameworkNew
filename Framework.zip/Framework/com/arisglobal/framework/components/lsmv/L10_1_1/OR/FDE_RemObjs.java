package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import com.arisglobal.framework.lib.main.ToolManager;

public class FDE_RemObjs extends ToolManager
{
	//CaseUnits
	public static String senderOrganizationAsCodedTextBox = "xpath#//input[contains(@id,'adverseEventNew:basicDetailsDataTable:accountName_lookup_input')]";
	public static String senderOrganizationAsReportedTextBox = "xpath#//input[contains(@id,'adverseEventNew:basicDetailsDataTable:reportedSenderId')]";
	public static String processingUnitDropDown = "xpath#//p-dropdown/div/label[contains(@class,'ng-tns-c3-66')]";
	//Case dates is done 
	//CaseSeriousness
	public static String seriousnessRadiobtn  = "Seriousness";
	public static String deathRadiobtn  = "Death?";
	public static String lifeThreateningRadiobtn  = "Life Threatening?";
	public static String causedOrProlongedHospitalizationRadiobtn  = "Caused/Prolonged Hospitalization";
	public static String disabilityOrPermanentDamageRadiobtn  = "Disability/Permanent Damage?";
	public static String congenitalAnomalyOrBirthDefectRadiobtn  = "Congenital Anomaly/Birth Defect?";
	public static String otherMedicallyImportantConditionRadiobtn  = "Other Medically Important Condition";
	public static String requiredInterventionRadiobtn = "public static String";
	//LastNameContactsLookUp
	public static String contactIdTextbox = "xpath#//input[@name='contactid']";
	public static String firstNameTextbox = "xpath#//input[@name='firstName']";
	public static String middleNameTextbox = "xpath#//input[@name='middleName']";
	public static String lastNameTextbox = "xpath#//input[@name='lastName']";
	public static String phCountryCodeTextbox = "xpath#//input[@name='phoneCountryCode']";
	public static String phAreaCodeTextbox = "xpath#//input[@name='phAreaCode']";
	public static String contactEmailTextBox = "xpath#//input[@name='email'][@class='ng-untouched ng-pristine ng-valid']";
	public static String contactDegreeTextBox = "xpath#//input[@name='degree'][@class='ng-untouched ng-pristine ng-valid']";
	public static String contactOtherPhoneTextBox = "xpath#//input[@name='otherPhone'][@class='ng-untouched ng-pristine ng-valid']";
	public static String ifOtherTextbox = "xpath#//input[@name='otherOrg']";
	public static String primaryAccountTextBox = "xpath#//div[2]/input[@name='primarypostalCode']";
	public static String PostalCodeTextBox = "xpath#//div[1]/input[@name='primarypostalCode']";
	public static String customerMasterIdTextBox = "xpath#//input[@name='customerId']";
	public static String contactSearchButton = "xpath#//div[@class='searchOkbtn']//button[contains(@class,'agOnEnterSearch')]";
	public static String contactClearButton = "xpath#//div[@class='searchOkbtn']/button[2]";
	public static String contactCancelButton = "xpath#//div[@class='searchOkbtn']//button[contains(@class,'ui-button-secondary')]";
	
	public static String specificationDropDown  = "Specification";
	public static String departmentDropDown = "DropDown";
	public static String contactCountryDropDown = "Country";
	//CaseReferences
	public static String initialSenderDropDown = "Initial Sender";
	public static String safetyReportIdTextBox = "xpath#//input[@id='adverseEventNew:generalPanelTable:administrativeDetailsDataTable:idN100CB10614411']";
	public static String authorityNoOrCompNumberTextBox = "xpath#//input[@id='adverseEventNew:generalPanelTable:administrativeDetailsDataTable:idN10149102128']";
	public static String SafetyReportIdAsExportedTextBox =  "xpath#//input[@id='adverseEventNew:generalPanelTable:administrativeDetailsDataTable:idN10149102997']";
	//E2B Case References in Previous Transmissions
	public static String duplicateSourceTextBox = "xpath#//input[@id='adverseEventNew:generalPanelTable:generalPreviouslyReportedTable:idN1027B103102:0']";
	public static String duplicateNumberTextBox = "xpath#//input[@id='adverseEventNew:generalPanelTable:generalPreviouslyReportedTable:idN1028B103104:0']";
	public static String caseRefAddLink = "xpath#//a[@class='agMultiAddLink'][@title='Add']";
	public static String caseRefDeleteLink = "xpath#//span[2][@class='agAddDeleteBlock ng-star-inserted']//a[@class='agMultiDeleteLink'][@title='Delete']";
	//Additional Documents Available
	public static String listOfDocumentsHeldByTheSenderTextArea = "xpath#//textarea[@id='adverseEventNew:generalPanelTable:documentDetailsDataTable:listOfDocsHeldBySender:0']";
	public static String documentNametextBox = "xpath#//input[@id='adverseEventNew:generalPanelTable:documentDetailsDataTable:fileName:0']";
	
	
	//CaseDocs(Source)
	public static String addSourceDocLink = "xpath#//a[@id='adverseEventNew:sourceadd']";
	public static String deleteSourceDocLink = "xpath#//a[@id='adverseEventNew:sourceDelete']";
	public static String sourceDocDescriptionTextBox = "xpath#//input[@id='adverseEventNew:j_id_2gq_t:%rowNo%:description']";
	public static String sourceDocUploadButton = "xpath#//input[@id='adverseEventNew:j_id_2gq_t:%rowNo%:sourceUpload_input']";
	public static String sourceDocVerImage = "xpath#//img[@id='adverseEventNew:j_id_2gq_t:%rowNo%:j_id_2gq_1d']";
	public static String sourceDocCategoryDropdown = "xpath#//label[contains(@id,'%rowNo%:A1-316')]";
	public static String srcDocCheckInOutImg = "xpath#//img[@id='adverseEventNew:j_id_2gq_t:%rowNo%:j_id_2gq_1k']";
	public static String isLocalSourceDocCheckBox = "xpath#//div[contains(@id, '%rowNo%:isLocalDoc')]//span[contains(@class,  'ui-icon-blank ui-c')]";
	public static String isIncludedSourceDocCheckBox = "xpath#//div[contains(@id,'adverseEventNew:j_id_2gq_t:%rowNo%:isIncluded')]//span";
	public static String literatureSourceDocCheckBox = "xpath#//div[contains(@id,'%rowNo%:literatureDoc')]//span";
	public static String viewSourceFileLink = "xpath#//a[contains(@id,'%rowNo%:viewFileLink')]";
	public static String deletesourceDocImg = "xpath#//img[contains(@id,'%rowNo%:j_id_2gq_19')]";
	public static String sourcDocDateLabel = "xpath#//label[contains(@id,'%rowNo%:date-SYSD')]";	
	public static String sourcDocFileSize = "xpath#//label[contains(@id,'%rowNo%:fileSize')]";
	public static String redactDocImg = "xpath#//img[contains(@id,'%rowNo%:j_id_2gq_25')]";
	
	//CaseDocs(Supp)
	public static String addSuppDocLink = "xpath#//a[@id='adverseEventNew:supportadd']";
	public static String deleteSuppDocLink = "xpath#//a[@id='adverseEventNew:supDelete']";
	public static String suppDocDescriptionTextBox = "xpath#//input[@id='adverseEventNew:SupportDoc:%rowNo%:description']";
	public static String suppDocUploadButton = "xpath#//input[@id='adverseEventNew:SupportDoc:%rowNo%:supportDocUpload_input']";
	public static String suppDocVerImage = "xpath#//img[@id='adverseEventNew:SupportDoc:%rowNo%:j_id_2gq_3v']";
	public static String suppDocCategoryDropdown = "xpath#//label[contains(@id,'%rowNo%:C-316_label')]";
	public static String suppDocCheckInOutImg = "xpath#//img[@id='adverseEventNew:SupportDoc:%rowNo%:j_id_2gq_46']";
	public static String isLocalSuppDocCheckBox = "xpath#//div[contains(@id, '%rowNo%:supportisLocalDoc')]//span[contains(@class,  'ui-icon-blank ui-c')]";
	public static String isIncludedSuppDocCheckBox = "xpath#//div[contains(@id,'%rowNo%:isIncludedsupport')]//span";
	public static String literatureSuppDocCheckBox = "xpath#//div[contains(@id,'%rowNo%:supportliteratureDoc')]//span";
	public static String viewSuppFileLink = "xpath#//a[contains(@id,'%rowNo%:viewAttachFileLink')]";
	public static String deletesuppDocImg = "xpath#//img[contains(@id,'%rowNo%:j_id_2gq_3s')]";
	public static String suppDocDateLabel = "xpath#//label[contains(@id,'%rowNo%:supDocDate-SYSD')]";
	public static String suppDocFileSize = "xpath#//label[contains(@id,'%rowNo%:supDocFileSize')]";
	
			
	public static String sourceDocDescriptionTextBox(String rowNO) {
	     String value = sourceDocDescriptionTextBox.replace("%rowNo%", rowNO);
	     return value;
	 }
	public static String suppDocDescriptionTextBox(String rowNO) {
	     String value = suppDocDescriptionTextBox.replace("%rowNo%", rowNO);
	     return value;
	 }
	
	
	public static String sourceDocUploadButton(String rowNO) {
	     String value = sourceDocUploadButton.replace("%rowNo%", rowNO);
	     return value;
	 }
	public static String suppDocUploadButton(String rowNO) {
	     String value = suppDocUploadButton.replace("%rowNo%", rowNO);
	     return value;
	}
	
	
	public static String sourceDocVerImage(String rowNO) {
	     String value = sourceDocVerImage.replace("%rowNo%", rowNO);
	     return value;
	}
	public static String suppDocVerImage(String rowNO) {
	     String value = suppDocVerImage.replace("%rowNo%", rowNO);
	     return value;
	}
	
	
	public static String sourceDocCategoryDropdown(String rowNO) {
	     String value = sourceDocCategoryDropdown.replace("%rowNo%", rowNO);
	     return value;
	}
	public static String suppDocCategoryDropdown(String rowNO) {
	     String value = suppDocCategoryDropdown.replace("%rowNo%", rowNO);
	     return value;
	}
	
	
	public static String srcDocCheckInOutImg(String rowNO) {
	     String value = srcDocCheckInOutImg.replace("%rowNo%", rowNO);
	     return value;
	}
	public static String suppDocCheckInOutImg(String rowNO) {
	     String value = suppDocCheckInOutImg.replace("%rowNo%", rowNO);
	     return value;
	}
	
	
	public static String isLocalSourceDocCheckBox(String rowNO) {
	     String value = isLocalSourceDocCheckBox.replace("%rowNo%", rowNO);
	     return value;
	 }
	 
	 public static String isLocalSuppDocCheckBox(String rowNO) {
	     String value = isLocalSuppDocCheckBox.replace("%rowNo%", rowNO);
	     return value;
	 }
	 
	 
	 public static String isIncludedSourceDocCheckBox(String rowNO) {
	     String value = isIncludedSourceDocCheckBox.replace("%rowNo%", rowNO);
	     return value;
	 }
	 
	 public static String isIncludedSuppDocCheckBox(String rowNO) {
	     String value = isIncludedSuppDocCheckBox.replace("%rowNo%", rowNO);
	     return value;
	 }
	 
	 
	 public static String viewSourceFileLink(String rowNO) {
	     String value = viewSourceFileLink.replace("%rowNo%", rowNO);
	     return value;
	 }
	 
	 public static String viewSuppFileLink(String rowNO) {
	     String value = viewSuppFileLink.replace("%rowNo%", rowNO);
	     return value;
	 }
	 
	 
	 public static String deletesourceDocImg(String rowNO) {
	     String value = deletesourceDocImg.replace("%rowNo%", rowNO);
	     return value;
	 }
	 public static String deletesuppDocImg(String rowNO) {
	     String value = deletesuppDocImg.replace("%rowNo%", rowNO);
	     return value;
	 }
	 
	 
	 public static String sourcDocDateLabel(String rowNO) {
	     String value = sourcDocDateLabel.replace("%rowNo%", rowNO);
	     return value;
	 }
	 public static String suppDocDateLabel(String rowNO) {
	     String value = suppDocDateLabel.replace("%rowNo%", rowNO);
	     return value;
	 }
	 
	 
	 public static String sourcDocFileSize(String rowNO) {
	     String value = sourcDocFileSize.replace("%rowNo%", rowNO);
	     return value;
	 }
	 public static String suppDocFileSize(String rowNO) {
	     String value = suppDocFileSize.replace("%rowNo%", rowNO);
	     return value;
	 }
	 
	 
	 public static String redactDocImg(String rowNO) {
	     String value = redactDocImg.replace("%rowNo%", rowNO);
	     return value;
	 }
	 
	 
	 	/**************************************SourcePageObjects***********************************************************/
	 
	 	public static String senderOrganizationTextBox = "xpath#//input[@id='adverseEventNew:sourcePanelTable:originatingAccount']";
	 	public static String ReferenceNumberTextBox = "xpath#//input[@id='adverseEventNew:sourcePanelTable:identificationNo']";
	 	public static String DescriptionTextBox = "xpath#//input[@id='adverseEventNew:sourcePanelTable:srcDescription']";
	 	public static String sourceDropdown = "xpath#//select[@name = 'adverseEventNew:sourceTable:idN12419112104-346_focus0']";
	 	public static String referenceTypeDropdown = "xpath#//select[@name='adverseEventNew:sourcePanelTable:referenceType-9060_focus0']";
	 	public static String dateReceivedTextBox = "xpath#//input[@id='adverseEventNew:sourceTable:srcDateReceived:impcalinput']";
	 	public static String primarySourceCheckBox = "xpath#//label[text()='Primary Source ']";	
	 	public static String senderOrganizationLookUpIcon = "xpath#//a[@class='agLookupLink']/img";
	 
	 	//Sender Org Lookup Objects 
		 public static String accountNameTextBox = "xpath#//label[text()='Account Name']//following::input[1]";
		 public static String domainTextBox = "xpath#//label[text()='Domain']//following::input[1]";
		 public static String firmOrSiteFEINumberTextBox = "xpath#//label[text()='Firm/Site FEI Number']//following::input[1]";
		 public static String searchSenderButton = "xpath#//button[contains(@class,'agOnEnterSearch')]";
		 public static String clearSenderButton = "xpath#//button[contains(@class,'agOnEnterSearch')]//following::button[1]";
		 public static String selectBySenderRecRadioBtn	 = "xpath#//td[@class='ClassAccountName']//preceding::span[1]";
		 public static String senderOkBtn = "xpath#//div[contains(@class,'searchOkbtn')]//button[1]//span[text()='OK']";
		 
		 public static String companyUnitCodeTextBox = "xpath#//label[text()='Company Unit Code']//following::input[1]";
		 public static String companyUnitNameTextBox = "xpath#//label[text()='Company Unit Name']//following::input[1]";
		 public static String selectByCompanyUnitRecRadioBtn = "#xpath(//td[@class='tblEditRow']//div[1]//div[2]//span)[1]";
		 public static String typeLabel = "Type";
		 public static String countryLabel = "Country";
		 
		 public static String senderRadiobtn  = "xpath#//label[text()='Sender']";
		 public static String companyUnitRadiobtn  = "xpath#//label[text()='Company Unit']";
		 
		 /**************************************ReporterPageObjects***********************************************************/
		 
		 public static String titleDropDown  = "Title";
		 public static String countryDropDown  = "Country";
		 
		 public static String firstNameTextBox = "xpath#//input[@id='adverseEventNew:reporterTable:idN10B75105104']";
		 public static String middleNameTextBox = "xpath#//input[@id='adverseEventNew:reporterTable:idN10B83105106']";
		 public static String lastNameTextBox = "xpath#//input[@id='adverseEventNew:reporterTable:idN10B93105108']";
		 public static String hospitalOrOrganizationNameTextBox = "xpath#//input[@id='adverseEventNew:reporterTable:idN10C15105110']";
		 public static String departmentTextBox = "xpath#//input[@id='adverseEventNew:reporterTable:idN10C07105112']";
		 public static String streetTextBox = "xpath#//input[@id='adverseEventNew:reporterTable:idN10BB2105114']";
		 public static String cityTextBox = "xpath#//input[@id='adverseEventNew:reporterTable:idN10BCA105116']";
		 public static String stateTextBox = "xpath#//input[@id='adverseEventNew:reporterTable:idN10BD8105118']";
		 public static String postalCodeTextBox = "xpath#//input[@id='adverseEventNew:reporterTable:idN10BE8105120']";
		 public static String telephoneTextBox = "xpath#//input[@id='adverseEventNew:reporterTable:personalPhone']";
		 public static String faxTextBox = "xpath#//input[@id='adverseEventNew:reporterTable:idN10B75105141']";
		 public static String emailIdTextBox = "xpath#//input[@id='adverseEventNew:reporterTable:mailIdText']";
		 
		 public static String specializationDropDown  = "Specialization";
		 public static String qualificationDropDown  = "Qualification";
		 public static String occupationDropDown = "Occupation";
		 
		 public static String primaryReporterCheckBox = "xpath#//label[text()='Primary Reporter ']";
		 public static String protectConfidentialityCheckBox = "xpath#//label[text()='Protect Confidentiality ']";
		 public static String manualCheckBox = "xpath#//label[text()='Manual']";
		 
		 public static String consentToContactRadioBtn = "Consent To Contact";
		 public static String primarySourceForRegulatoryPurposesRadioBtn = "Primary Source For Regulatory Purposes";
		 public static String personTypeRadioBtn = "Person Type";
		 public static String healthProfessionalRadioBtn = "Health Professional";
		 public static String reporterInformedAuthorityDirectlyRadioBtn = "Reporter Informed Authority Directly";		 
}
	