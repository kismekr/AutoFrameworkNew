package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.CommonOperations;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.BatchPrintListingPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class BatchPrintListingOperations extends ToolManager {
	public static WebElement webElement;
	static String className = BatchPrintListingOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to search and edit the batch print.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndEdit(String scenarioName, Boolean edit) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(BatchPrintListingPageObjects.batchPrintListingSearchTextbox,
				getTestDataCellValue(scenarioName, "BatchName"));
		agClick(BatchPrintListingPageObjects.searchIcon);
		agIsVisible(BatchPrintListingPageObjects.paginator);
		CommonOperations.takeScreenShot();
		if (edit == true) {
			agClick(BatchPrintListingPageObjects.editIcon);
			agSetStepExecutionDelay("3000");
			agIsVisible(BatchPrintListingPageObjects.batchname_label);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CommonOperations.takeScreenShot();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search batch print.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchBatchPrint(String scenarioName) {
		searchAndEdit(scenarioName, false);
		String paginator = agGetText(BatchPrintListingPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "BatchName"),
					BatchPrintListingPageObjects.get_ListofBatchName);
			Reports.ExtentReportLog("", Status.FAIL, "Search batch print: batch print Listed", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS, "Search batch print: batch print Not Listed", true);
		}
		agClick(BatchPrintListingPageObjects.refresh_icon);
		agIsVisible(BatchPrintListingPageObjects.batchPrintListingSearchTextbox);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created search and create batch print.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreatebatchprint(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		searchAndEdit(scenarioName, false);
		if (verifysearchData(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Batch print already exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "BatchName"),
					BatchPrintListingPageObjects.get_ListofBatchName);
		} else {
			agClick(BatchPrintListingPageObjects.new_Btn);
			createBatchPrint(scenarioName);
			CommonOperations.setAuditInfo(scenarioName);
			agIsVisible(BatchPrintListingPageObjects.batchPrintListingSearchTextbox);
			CommonOperations.takeScreenShot();
			searchAndEdit(scenarioName, true);
			verifyBatchPrint(scenarioName);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Batch Name exist or not
	 *             based on Batch Name
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Boolean verifysearchData(String scenarioName) {
		Boolean falg = false;
		agWaitTillVisibilityOfElement(BatchPrintListingPageObjects.paginator);
		String paginator = agGetText(BatchPrintListingPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			List<WebElement> list = agGetElementList(BatchPrintListingPageObjects.get_ListofBatchName);
			String columnHeader = null;
			for (int j = 1; j <= list.size(); j++) {
				columnHeader = agGetText(BatchPrintListingPageObjects.columnHeaderList(Integer.toString(j)));
				if (getTestDataCellValue(scenarioName, "BatchName").equalsIgnoreCase(columnHeader)) {
					falg = true;
					break;
				}
			}
		}
		return falg;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create account.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 07-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createBatchPrint(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(BatchPrintListingPageObjects.batchName_Txtfield, getTestDataCellValue(scenarioName, "BatchName"));
		agClick(BatchPrintListingPageObjects.click_BatchConfigurationName);
		agSetStepExecutionDelay("2000");
		
		agJavaScriptExecuctorClick(BatchPrintListingPageObjects
				.set_BatchConfigurationName(getTestDataCellValue(scenarioName, "BatchConfigurationName")));
		agClick(BatchPrintListingPageObjects.click_printTypeRadiobtns(getTestDataCellValue(scenarioName, "PrintType")));
		if (getTestDataCellValue(scenarioName, "PrintType").equalsIgnoreCase("Paper")) {
			agSetStepExecutionDelay("2000");
			agSetValue(BatchPrintListingPageObjects.noOfcopies_TxtField,
					getTestDataCellValue(scenarioName, "NoOfCopies"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}

		agSetValue(BatchPrintListingPageObjects.description_Txtarea, getTestDataCellValue(scenarioName, "Description"));
		agClick(BatchPrintListingPageObjects.click_printByRadiobtns(getTestDataCellValue(scenarioName, "PrintBy")));
		if (getTestDataCellValue(scenarioName, "PrintBy").equalsIgnoreCase("Date Range")) {
			agSetStepExecutionDelay("2000");
			agSetValue(BatchPrintListingPageObjects.fromDate,
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "FromDate")));
			agSetValue(BatchPrintListingPageObjects.toDate,
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "ToDate")));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		if (getTestDataCellValue(scenarioName, "PrintBy").equalsIgnoreCase("Comma separated AER No.s")) {
			agSetStepExecutionDelay("2000");
			agWaitTillVisibilityOfElement(BatchPrintListingPageObjects.aerNo_Txtarea);
			agSetValue(BatchPrintListingPageObjects.aerNo_Txtarea, getTestDataCellValue(scenarioName, "AERNo"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}

		agClick(BatchPrintListingPageObjects
				.click_reportTypeRadioBtn(getTestDataCellValue(scenarioName, "ReportType")));
		agClick(BatchPrintListingPageObjects
				.click_dataPrivacyTypeRadiobtns(getTestDataCellValue(scenarioName, "DataPrivacyType")));
		agClick(BatchPrintListingPageObjects
				.click_blindingTypeRadiobtns(getTestDataCellValue(scenarioName, "BlindingType")));
		agClick(BatchPrintListingPageObjects.clickcheckboxs(BatchPrintListingPageObjects.cIOMS_checkbox));
		agClick(BatchPrintListingPageObjects.clickcheckboxs(BatchPrintListingPageObjects.medWatch_checkbox));
		agClick(BatchPrintListingPageObjects.clickcheckboxs(BatchPrintListingPageObjects.includeCoverPage_checkbox));
//		agClick(BatchPrintListingPageObjects.clickcheckboxs(BatchPrintListingPageObjects.schedule_checkbox));
//		 agClick(BatchPrintListingPageObjects.click_ScheduleType);
//		 agClick(BatchPrintListingPageObjects.set_ScheduleTypeDropdown(getTestDataCellValue(scenarioName,
//		 "ScheduleType")));

		Reports.ExtentReportLog("", Status.INFO, "Data entered in Batch print", true);
		agClick(BatchPrintListingPageObjects.save_Btn);
		agSetStepExecutionDelay("2000");
		agIsVisible(BatchPrintListingPageObjects.batchPrintListingSearchTextbox);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Batch Print.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyBatchPrint(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "BatchName"),
				BatchPrintListingPageObjects.batchName_Txtfield);
//		agCheckPropertyText(getTestDataCellValue(scenarioName, "BatchConfigurationName"),
//				BatchPrintListingPageObjects.getBatchConfigName);
		agClick(BatchPrintListingPageObjects.description_Txtarea);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Description"),
				BatchPrintListingPageObjects.description_Txtarea);
		CommonOperations.verifyCheckBoxLeftOf(BatchPrintListingPageObjects.cIOMS_checkbox, "true");
		CommonOperations.verifyCheckBoxLeftOf(BatchPrintListingPageObjects.medWatch_checkbox, "true");
		CommonOperations.verifyCheckBoxLeftOf(BatchPrintListingPageObjects.includeCoverPage_checkbox, "true");
		// CommonOperations.verifyCheckBoxLeftOf(BatchPrintListingPageObjects.schedule_checkbox,
		// "true");
		// agCheckPropertyText(getTestDataCellValue(scenarioName, "ScheduleType"),
		// BatchPrintListingPageObjects.getSchedularName);
		Reports.ExtentReportLog("", Status.INFO, "Data verified entered in Batch print", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete Batch Print.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteBatchPrint(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		searchAndEdit(scenarioName, false);
		String paginator = agGetText(BatchPrintListingPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "BatchName"),
					BatchPrintListingPageObjects.get_ListofBatchName);
			Reports.ExtentReportLog("", Status.PASS, "Batch Name Found", true);
			agClick(BatchPrintListingPageObjects
					.selectListingCheckbox(getTestDataCellValue(scenarioName, "BatchName")));
			delete(scenarioName);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Batch Name Not Found", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete account.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void delete(String scenarioName) {
		agClick(BatchPrintListingPageObjects.delete_Btn);
		CommonOperations.setDeleteAuditInfo(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search for deleted batch print.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchDeleteBatchprint(String scenarioName) {
		searchAndEdit(scenarioName, false);
		String paginator = agGetText(BatchPrintListingPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.FAIL, "Search for Deleted batch print: Deleted batch print is listed",
					true);
		} else {
			Reports.ExtentReportLog("", Status.PASS,
					"Search for Deleted batch print: Deleted batch print is not listed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download BatchPrint export to
	 *             excel.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 15-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportToexcel(String FileName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(BatchPrintListingPageObjects.downloadIcon);
		agClick(BatchPrintListingPageObjects.exporttoExcel_link);
		agWaitTillVisibilityOfElement(BatchPrintListingPageObjects.export_Btn);
		if (agIsVisible(BatchPrintListingPageObjects.export_Btn) == true) {
			agClick(BatchPrintListingPageObjects.export_Btn);
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			CommonOperations.move_Downloadedexcel(FileName);
			agClick(BatchPrintListingPageObjects.exportexcelcancel_Btn);
		} else {
			Reports.ExtentReportLog("Export to excel pop is not displayed", Status.INFO, "", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to compare record count with download
	 *             excel
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:Avinash K
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void recordCountVerification(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		String count = xls.getCellData("Batch Print", 2, 4);
		String[] Totalcount = count.split(":");
		System.out.println(Totalcount[1].trim());
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in exported excel::" + Totalcount[1].trim(),
				false);
		String applrecordcount = agGetText(BatchPrintListingPageObjects.paginator);
		String[] data = applrecordcount.split(" ");
		String recordCount = data[4];
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in application::" + recordCount, false);
		if (recordCount.equalsIgnoreCase(Totalcount[1].trim())) {
			Reports.ExtentReportLog("", Status.PASS, "Record count verification is successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Record count verification is Unsuccessfull", true);
		}
	}

}