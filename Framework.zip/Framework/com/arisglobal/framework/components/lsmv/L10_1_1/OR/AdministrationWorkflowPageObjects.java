package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class AdministrationWorkflowPageObjects {

	public static String editISPWorkflow = "xpath#//label[text()='ISP Case Processing Workflow']//parent::td//parent::tr/td//img[contains(@id,'editIcon')]";
	public static String ISPCaseProcessingBreadcrumb = "xpath#//label[@id='configForm:wfNameBreadcrumb']";
	public static String clickConfiguration = "xpath#//a[@id='configForm:wfconfigIdTab']";
	public static String activityAndTransactions = "xpath#//label[text()='Activities and Transitions']";
	public static String clickIntakeAndAssessment = "xpath#//span[text()='%s']";
	public static String intakeAndAssessmentBreadcrumb = "xpath#//label[text()='WorkFlow Activity > Intake and Assessment']";
	public static String selectActivity = "xpath#//span[text()='%s']";
	public static String assessmentType = "xpath#//label[text()='%s']//parent::td//div[@class='ui-radiobutton-box ui-widget ui-corner-all ui-state-default']";
	public static String saveConfiguration = "xpath#//button[@id='configForm:wfSaveId']";
	public static String processingLoader = "xpath#//div[@id='configForm:statusDialogId']";
	public static String popUpHeader = "xpath#//span[@id='mandatoryDialogform:mandatoryID_title']";
	public static String saveMessage = "xpath#//label[text()='Workflow ISP Case Processing Workflow updated successfully. ']";
	public static String okButton = "xpath#//button[@id='mandatoryDialogform:okButton']";
	public static String ISPCaseProcessingWorkflow = "xpath#//label[text()='ISP Case Processing Workflow']";
	public static String NextPage = "xpath#//a[@aria-label='Next Page']";

	/**********************************************************************************************************
	 * Objective:The below method is created to select Section Name by passing name
	 * at runtime. Input Parameters: ColumnName Scenario Name Output Parameters:
	 * 
	 * @author:Yashwanth Naidu Date :21-April-2020 Updated by and when
	 **********************************************************************************************************/
	public static String setSectionName(String label) {
		String value = clickIntakeAndAssessment;
		String value1 = value.replace("%s", label);
		return value1;

	}

	/**********************************************************************************************************
	 * Objective:The below method is created to set Activity by passing activity
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Yashwanth Naidu Date :21-April-2020 Updated by and when
	 **********************************************************************************************************/
	public static String SetActivity(String label) {
		String value = selectActivity;
		String value1 = value.replace("%s", label);
		return value1;

	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select Assessment type by passing
	 * type at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Yashwanth Naidu Date :21-April-2020 Updated by and when
	 **********************************************************************************************************/
	public static String SelectAssessmentType(String label) {
		String value = assessmentType;
		String value1 = value.replace("%s", label);
		return value1;
	}
}
