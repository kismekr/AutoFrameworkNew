package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AdministrationPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AppParameters_CallLogPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AppParameters_CaseManagementPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AppParameters_CentralCodingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AppParameters_ComplaintPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AppParameters_DMSPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AppParameters_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AppParameters_MedDRASettingsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AppParameters_NLPSettingsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AppParameters_SubmissionPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.SystemAdministrationPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.aventstack.extentreports.Status;

public class SystemAdministrationOperations extends ToolManager {
	public static WebElement webElement;
	static String className = SystemAdministrationOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in System
	 *             administration
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void menuNavigation(String menu) {
		agMouseHover(AdministrationPageObjects.administrationHover);
		agClick(menu);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in
	 *             Administration > System administration and verify the label name.
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void systemAdministrationNavigations(String menu) {
		switch (menu) {
		case "sessionUser":
			menuNavigation(SystemAdministrationPageObjects.sessionUserLink);
			status = agIsVisible(SystemAdministrationPageObjects.sessionUserLabel);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to session User is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to session User is Unsuccessfull", true);
			}
			break;
		case "activeSessions":
			menuNavigation(SystemAdministrationPageObjects.activeSessionsLink);
			status = agIsVisible(SystemAdministrationPageObjects.activeSessionsLabel);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to active Sessions is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to active Sessions is Unsuccessfull", true);
			}
			break;
		case "lockInfo":
			menuNavigation(SystemAdministrationPageObjects.lockInfoLink);
			status = agIsVisible(SystemAdministrationPageObjects.lockInfoLabel);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to lock Info is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to lock Info is Unsuccessfull", true);
			}
			break;
		case "applicationParameters":
			menuNavigation(SystemAdministrationPageObjects.applicationParametersLink);
			agSetStepExecutionDelay("6000");
			status = agIsVisible(SystemAdministrationPageObjects.applicationParametersLabel);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "", true);
				Reports.ExtentReportLog("", Status.INFO, "Navigation to application Parameters is successfull.",
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to application Parameters is Unsuccessfull.",
						true);
			}
			break;

		case "General":
			agClick(SystemAdministrationPageObjects.general_Link);
			agSetStepExecutionDelay("6000");
			status = agIsVisible(AppParameters_GeneralPageObjects.companyName_TextBox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS,
						"Navigation to Application Parameters >> General Screen is Successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Navigation to Application Parameters >> General Screen is Unsuccessfull", true);
			}
			break;
		case "CaseManagement":
			agClick(SystemAdministrationPageObjects.caseManagement_Link);
			agSetStepExecutionDelay("6000");
			status = agIsVisible(AppParameters_CaseManagementPageObjects.receiptPrefix_TextBox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "", true);
				Reports.ExtentReportLog("", Status.INFO,
						"Application Parameters > Case Management page displayed.", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Application Parameters > Case Management page not displayed.", true);
			}
			break;
		case "CallLog":
			agClick(SystemAdministrationPageObjects.callLog_Link);
			agSetStepExecutionDelay("6000");
			status = agIsVisible(AppParameters_CallLogPageObjects.callLogNumberingFormat_TextBox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS,
						"Navigation to Application Parameters >> Call Log Screen is Successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Navigation to Application Parameters >> Call Log Screen is Unsuccessfull", true);
			}
			break;
		case "Submission":
			agClick(SystemAdministrationPageObjects.submission_Link);
			agSetStepExecutionDelay("6000");
			status = agIsVisible(AppParameters_SubmissionPageObjects.outOfWorkflowSubmissionsOlderThan_TextBox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS,
						"Navigation to Application Parameters >> Submission Screen is Successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Navigation to Application Parameters >> Submission Screen is Unsuccessfull", true);
			}
			break;
		case "Complaint":
			agClick(SystemAdministrationPageObjects.complaint_Link);
			agSetStepExecutionDelay("6000");
			status = agIsVisible(AppParameters_ComplaintPageObjects.complaintNumberingFormat_TextBox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS,
						"Navigation to Application Parameters >> Complaint Screen is Successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Navigation to Application Parameters >> Complaint Screen is Unsuccessfull", true);
			}
			break;
		case "CentralCoding":
			agClick(SystemAdministrationPageObjects.centralCoding_Link);
			agSetStepExecutionDelay("6000");
			status = agIsVisible(AppParameters_CentralCodingPageObjects.advancedSynonymsThesaurusName_TextBox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS,
						"Navigation to Application Parameters >> Central Coding Screen is Successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Navigation to Application Parameters >> Central Coding Screen is Unsuccessfull", true);
			}
			break;
		case "DMS":
			agClick(SystemAdministrationPageObjects.dms_Link);
			agSetStepExecutionDelay("6000");
			status = agIsVisible(AppParameters_DMSPageObjects.dmsType_DropDown);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS,
						"Navigation to Application Parameters >> DMS Screen is Successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Navigation to Application Parameters >> DMS Screen is Unsuccessfull", true);
			}
			break;
		case "ExternalApplication":
			agClick(SystemAdministrationPageObjects.externalApplication_Link);
			agSetStepExecutionDelay("6000");
			status = agIsVisible(SystemAdministrationPageObjects.applicationID_TextBox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS,
						"Navigation to Application Parameters >> External Application Screen is Successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Navigation to Application Parameters >> External Application Screen is Unsuccessfull", true);
			}
			break;
		case "MedDRASettings":
			agClick(SystemAdministrationPageObjects.medDRASettings_Link);
			agSetStepExecutionDelay("6000");
			status = agIsVisible(AppParameters_MedDRASettingsPageObjects.hostName_TextBox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS,
						"Navigation to Application Parameters >> MedDRA Settings Screen is Successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Navigation to Application Parameters >> MedDRA Settings Screen is Unsuccessfull", true);
			}
			break;
		case "NLPSettings":
			agClick(SystemAdministrationPageObjects.nlpSettings_Link);
			agSetStepExecutionDelay("6000");
			status = agIsVisible(AppParameters_NLPSettingsPageObjects.nlpConfigurationPath_TextBox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS,
						"Navigation to Application Parameters >> NLP Settings Screen is Successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Navigation to Application Parameters >> NLP Settings Screen is Unsuccessfull", true);
			}
			break;
		default:
			System.out.println("Invalid Menu Link!");
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set data in Application Parameters
	 *             Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 20-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setApplicationParameters(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Set/Write Application Parameters Started", true);
		systemAdministrationNavigations("applicationParameters");
		systemAdministrationNavigations("General");
		AppParameters_General.setAppParameters_GeneralTabDetails(scenarioName);
		systemAdministrationNavigations("CaseManagement");
		AppParameters_CaseManagement.setAppParameters_CaseManagementTabDetails(scenarioName);
		systemAdministrationNavigations("CallLog");
		AppParameters_CallLog.setAppParameters_CallLogTabDetails(scenarioName);
		systemAdministrationNavigations("Submission");
		AppParameters_Submission.setAppParameters_SubmissionTabDetails(scenarioName);
		systemAdministrationNavigations("Complaint");
		AppParameters_Complaint.setAppParameters_ComplaintTabDetails(scenarioName);
		systemAdministrationNavigations("CentralCoding");
		AppParameters_CentralCoding.setAppParameters_CentralCodingTabDetails(scenarioName);
		systemAdministrationNavigations("DMS");
		AppParameters_DMS.setAppParameters_DMSTabDetails(scenarioName);
		systemAdministrationNavigations("MedDRASettings");
		AppParameters_MedDRASettings.setAppParameters_MedDRASettingsTabDetails(scenarioName);
		systemAdministrationNavigations("ExternalApplication");
		AppParameters_ExternalApplication.setAppParameters_ExternalApplicationTabDetails(scenarioName);
		// systemAdministrationNavigations("NLPSettings");
		// AppParameters_NLPSettings.setAppParameters_NLPSettingsTabDetails(scenarioName);
		// agClick(SystemAdministrationPageObjects.save_Button);
		Reports.ExtentReportLog("", Status.INFO, "Set/Write Application Parameters End", true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read data in Application
	 *             Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 27-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadApplicationParameters(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Read Application Parameters Started", true);
		systemAdministrationNavigations("applicationParameters");
		systemAdministrationNavigations("General");
		AppParameters_General.ReadAppParameters_GeneralTabDetails(scenarioName);
		systemAdministrationNavigations("CaseManagement");
		AppParameters_CaseManagement.ReadAppParameters_CaseManagementTabDetails(scenarioName);
		systemAdministrationNavigations("CallLog");
		AppParameters_CallLog.ReadAppParameters_CallLogTabDetails(scenarioName);
		systemAdministrationNavigations("Submission");
		AppParameters_Submission.ReadAppParameters_SubmissionTabDetails(scenarioName);
		systemAdministrationNavigations("Complaint");
		AppParameters_Complaint.ReadAppParameters_ComplaintTabDetails(scenarioName);
		systemAdministrationNavigations("CentralCoding");
		AppParameters_CentralCoding.ReadAppParameters_CentralCodingTabDetails(scenarioName);
		systemAdministrationNavigations("DMS");
		AppParameters_DMS.ReadAppParameters_DMSTabDetails(scenarioName);
		systemAdministrationNavigations("MedDRASettings");
		AppParameters_MedDRASettings.ReadAppParameters_MedDRASettingsTabDetails(scenarioName);
		systemAdministrationNavigations("ExternalApplication");
		AppParameters_ExternalApplication.ReadAppParameters_ExternalApplicationTabDetails(scenarioName);
		// systemAdministrationNavigations("NLPSettings");
		// AppParameters_NLPSettings.setAppParameters_NLPSettingsTabDetails(scenarioName);
		// agClick(SystemAdministrationPageObjects.save_Button);
		Reports.ExtentReportLog("", Status.INFO, "Read Application Parameters Ended", true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify data in Application
	 *             Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 20-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyApplicationParameters(String scenarioName) {
		/*
		 * systemAdministrationNavigations("applicationParameters");
		 * systemAdministrationNavigations("General");
		 * AppParameters_General.verifyAppParameters_GeneralTabDetails(scenarioName);
		 * systemAdministrationNavigations("CaseManagement");
		 * AppParameters_CaseManagement.verifyAppParameters_CaseManagementTabDetails(
		 * scenarioName); systemAdministrationNavigations("CallLog");
		 * AppParameters_CallLog.verifyAppParameters_CallLogTabDetails(scenarioName);
		 * systemAdministrationNavigations("Submission");
		 * AppParameters_Submission.verifyAppParameters_SubmissionTabDetails(
		 * scenarioName); systemAdministrationNavigations("Complaint");
		 * AppParameters_Complaint.verifyAppParameters_ComplaintTabDetails(scenarioName)
		 * ; systemAdministrationNavigations("CentralCoding");
		 * AppParameters_CentralCoding.verifyAppParameters_CentralCodingTabDetails(
		 * scenarioName); systemAdministrationNavigations("DMS");
		 * AppParameters_DMS.verifyAppParameters_DMSTabDetails(scenarioName);
		 * systemAdministrationNavigations("MedDRASettings");
		 * AppParameters_MedDRASettings.verifyAppParameters_MedDRASettingsTabDetails(
		 * scenarioName); systemAdministrationNavigations("NLPSettings");
		 * AppParameters_NLPSettings.verifyAppParameters_NLPSettingsTabDetails(
		 * scenarioName);
		 */		
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify data in Application
	 *             Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 09-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyDataApplicationParameters(String scenarioName) {
				
		systemAdministrationNavigations("applicationParameters");
		systemAdministrationNavigations("CaseManagement");
		agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
		//AppParameters_CaseManagement.verifyCaseManagementDetails(scenarioName)
		//AppParameters_CaseManagement.setCaseManagementDetails(scenarioName);
		AppParameters_CaseManagement.verifyAppParameters_AutopsyDone_CaseManagementTabDetails(scenarioName);
		AppParameters_CaseManagement.verifyAppParameters_ExemptedEvents_CaseManagementTabDetails(scenarioName);
		AppParameters_CaseManagement.verifyAppParameters_AnticipatedEvents_CaseManagementTabDetails(scenarioName);
		AppParameters_CaseManagement.verifyAppParameters_EventMedicallyConfirmed_CaseManagementTabDetails(scenarioName);
		/*systemAdministrationNavigations("CaseManagement");
		AppParameters_CaseManagement.setAppParameters_CaseManagementTabDetails(scenarioName);*/
		
	}	
	
	/***********************************************************************************************************************
	 * @Objective: The below method is to verify the Application Parametre 
	 *             Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 09-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void AppParameters_CaseLevel(String scenarioName) {
				

		FDE_Patient.verifyAutopsyDone_AppParameters_CaseLevel(scenarioName);
		FDE_Events.verifyMedicallyConfirmed_AppParameters_CaseLevel(scenarioName);
		FDE_Events.verifyExemptedEvents_AppParameters_CaseLevel(scenarioName);
		FDE_Events.verifyAnticipatedEvents_AppParameters_CaseLevel(scenarioName);
		
	}	
	
	
	/***********************************************************************************************************************
	 * @Objective: To Enable a particular Configuration by checkbox click. Save
	 *             button not clicked.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 11-Dec-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void enableConfiguration(String configLabel) {
		agWaitTillVisibilityOfElement(SystemAdministrationPageObjects.save_Button);
		agMouseHover(SystemAdministrationPageObjects.configurationLabel(configLabel));
		CommonOperations.clickCheckBoxLeftOf(configLabel, "true");
		Reports.ExtentReportLog("", Status.PASS, "", true);
	}

	/***********************************************************************************************************************
	 * @Objective: To save the changes made.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 11-Dec-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void saveAndAcknowledge() {
		agClick(SystemAdministrationPageObjects.save_Button);

		agWaitTillVisibilityOfElement(SystemAdministrationPageObjects.ackOK_Btn);
		agSetStepExecutionDelay("2000");
		agMouseHover(SystemAdministrationPageObjects.ackOK_Btn);
		Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
		Reports.ExtentReportLog("", Status.INFO,
				"Action Completed Successfully.<br />" + "INFO : Application Parameter Saved Successfully.<br />", false);
		agClick(SystemAdministrationPageObjects.ackOK_Btn);
	}
}