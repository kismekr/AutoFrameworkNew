package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import com.arisglobal.framework.lib.main.ToolManager;

public class FDE_SplitCasePageObjects extends ToolManager {
	public static String PageNoTextBox = "xpath#//textarea[@id='splitsForm:pageNoId']";
	public static String SubmitBtn = "xpath#//span[@class='aeCopySavbtn']//button";
	public static String CancelBtn = "xpath#//button[@id='splitsForm:j_id_4ed_am']//span[contains(text(),'Cancel')]";

	public static String VerifyReciptNumber = "xpath#//div[@class='modal-content']//span[starts-with(text(),'Split Document >')]";
	public static String SplitCaseReceiptNumber = "xpath#(//label[@class='validationDialogSpanSty newDesign_INFO_label'])[1]";
	public static String okButton = "xpath#//button[@class='buttonBg' and text()='OK']";
	public static String CommentTextBox = "xpath#//textarea[@id='splitsForm:splitCommentsId']";

	public static String SplitBySourceDocument = "xpath#//label[text()='Split By Source Document']/following-sibling::input";

	// Label names
	public static String receiptDetails_CheckBox = "Receipt Details";
	public static String Correspondence_CheckBox = "Correspondence";
	public static String Notes_CheckBox = "Notes";
	public static String LinkedCases_CheckBox = "xpath#//input[@id='splitsForm:linkedFlagID']";

	public static String Retain_Classfication_Checkbox = "Retain Classification";
	public static String Supporting_DocumentsCheckbox = "Supporting Documents";
	public static String OutofWorkflow_Checkbox = "Out of workflow Case";
	public static String General_CheckBox = "General";
	public static String Source_CheckBox = "Source";

	public static String Reporter_CheckBox = "Reporter";
	public static String Study_CheckBox = "Study";

	public static String Patient_CheckBox = "Patient";
	public static String Parent_CheckBox = "Parent";
	public static String Product_CheckBox = "Product(s)";
	public static String Event_CheckBox = "Event(s)";
	public static String Narrative_CheckBox = "Narrative";

	public static String Pregnancy_CheckBox = "Pregnancy";
	public static String LabData_CheckBox = "Lab Data";
	public static String Literature_CheckBox = "Literature";

}
