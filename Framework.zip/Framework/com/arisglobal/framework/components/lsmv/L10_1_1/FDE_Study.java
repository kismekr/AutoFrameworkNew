package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_ProductsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_StudyLookUpPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_StudyPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_Study extends ToolManager {
	static String className = FDE_Study.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: scenarioName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setRegCountryDropDownValue(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_StudyPageObjects.click_RegCountryDropDown);
			agClick(FDE_StudyPageObjects.setdropDownValue(getTestDataCellValue(scenarioName, columnName)));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: scenarioName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDownValue(String label, String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_StudyPageObjects.clickDroprdown(label));
			agClick(FDE_StudyPageObjects.setdropDownValue(getTestDataCellValue(scenarioName, columnName)));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in text field value
	 * @InputParameters: scenarioName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyData(String object, String scenarioName, String columnName) {
		agClick(object);
		agCheckPropertyValue("title", getTestDataCellValue(scenarioName, columnName), object);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to handle Validation Messages in
	 *             Study Screen.
	 * @InputParameters: NA
	 * @OutputParameters:NA
	 * @author:Sanchit
	 * @Date : 13-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void handleValidationMessage() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agWaitTillVisibilityOfElement(FDE_StudyPageObjects.studyConfirmationPopUp_Message);
		status = agIsVisible(FDE_StudyPageObjects.studyConfirmationPopUp_Message);
		if (status) {
			CommonOperations.takeScreenShot();
			agClick(FDE_StudyPageObjects.studyConfirmationPopUpYes_Btn);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Protocol in study tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:Sanchit on 28-Nov-2019
	 **********************************************************************************************************/
	public static void set_Protocol(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Study_StudyInformation_ProtocolNo_Lookup").equalsIgnoreCase("Yes")) {
			agClick(FDE_StudyPageObjects.protocolNo_Lookup);
			agSetStepExecutionDelay("3000");
			if(agIsVisible(FDE_GeneralPageObjects.ReportTypeChangeConfirmation)) {
				
				agClick(FDE_GeneralPageObjects.ReportTypeChangeConfirmation_Yes);
			}
			agSetStepExecutionDelay("3000");
			// agSetValue(FDE_StudyLookUpPageObjects.projectNo_TextField,
			// getTestDataCellValue(scenarioName, "Study_StudyInformation_ProjectNo"));
			agSetValue(FDE_StudyLookUpPageObjects.studyNo_TextField,
					getTestDataCellValue(scenarioName, "Study_StudyLookup_StudyNo"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agClick(FDE_StudyLookUpPageObjects.search_button);
			agSetStepExecutionDelay("4000");
			agClick(FDE_StudyLookUpPageObjects
					.radioButton(getTestDataCellValue(scenarioName, "Study_StudyLookup_StudyNo")));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.INFO,
					"Data Selected in Study >> Study Protocol LookUp Windpw : Scenario Name::" + scenarioName, false);
			agClick(FDE_StudyLookUpPageObjects.ok_button);
			agWaitTillInvisibilityOfElement(FDE_StudyLookUpPageObjects.ok_button);
		} else {
			agSetValue(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.protocolNo_Textbox),
					getTestDataCellValue(scenarioName, "Study_StudyLookup_StudyNo"));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Study Information Details in
	 *             Study Tab.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 26-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_StudyInformationDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// handleValidationMessage();		
		setDropDownValue(FDE_StudyPageObjects.studyType_DropDown, scenarioName, "Study_StudyInformation_StudyType");
		handleValidationMessage();
		agSetValue(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.projectNo_Textbox),
				getTestDataCellValue(scenarioName, "Study_StudyInformation_ProjectNo"));
		setDropDownValue(FDE_StudyPageObjects.studyPhase_DropDown, scenarioName, "Study_StudyInformation_StudyPhase");
		setDropDownValue(FDE_StudyPageObjects.studyDesign_DropDown, scenarioName, "Study_StudyInformation_StudyDesign");
		agSetValue(FDE_StudyPageObjects.studyName_Textbox,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyName"));
		agSetValue(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.enrollmentStatus_Textbox),
				getTestDataCellValue(scenarioName, "Study_StudyInformation_EnrollmentStatus"));
		agSetValue(FDE_StudyPageObjects.setData_Datesfields(FDE_StudyPageObjects.enrollmentDate_Datefield),
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Study_StudyInformation_EnrollmentDate")));
		agSetValue(FDE_StudyPageObjects.setData_Datesfields(FDE_StudyPageObjects.withdrawnDate_Datefield),
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Study_StudyInformation_WithdrawDate")));
		agSetValue(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.eudraCTNumber_Textbox),
				getTestDataCellValue(scenarioName, "Study_StudyInformation_EudraCTNumber"));
		agSetValue(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.randomizationNumber_Textbox),
				getTestDataCellValue(scenarioName, "Study_StudyInformation_RandomizationNumber"));
		agSetValue(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.centerNumber_Textbox),
				getTestDataCellValue(scenarioName, "Study_StudyInformation_CenterNumber"));
		agSetValue(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.subjectID_Textbox),
				getTestDataCellValue(scenarioName, "Study_StudyInformation_SubjectID"));
		agSetValue(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.investigatorNumber_Textbox),
				getTestDataCellValue(scenarioName, "Study_StudyInformation_InvestigatorNumber"));

		// setDropDownValue(FDE_StudyPageObjects.caseCodeBroken_DropDown, scenarioName,
		// "Study_StudyInformation_CaseCodeBroken");

		// added by Pooja on 24-Apr-2020 , if case code is broken is Code Broken, then
		// the confirmation pop up should be displayed
		 setCaseCodeBroken(scenarioName);
		setDropDownValue(FDE_StudyPageObjects.studyCodeBroken_DropDown, scenarioName,
				"Study_StudyInformation_StudyCodeBroken");
		
		agSetValue(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.primaryIND_Textbox),
				getTestDataCellValue(scenarioName, "Study_StudyInformation_PrimaryIND"));	 
		  agSetValue(FDE_StudyPageObjects.caseCodeBrokenOn_Datefield, CommonOperations
					.returnDateTime(getTestDataCellValue(scenarioName, "Study_StudyInformation_CaseCodeBrokenOn")));	
		  CommonOperations.captureScreenShot(true);
		setDropDownValue(FDE_StudyPageObjects.queryContact_DropDown, scenarioName,
				"Study_StudyInformation_QueryContact");
		setDropDownValue(FDE_StudyPageObjects.studyCompletionStatus_DropDown, scenarioName,
				"Study_StudyInformation_StudyCompletionStatus");
		agSetValue(FDE_StudyPageObjects.setData_TextAreafields(FDE_StudyPageObjects.protocolDetails_TextArea),
				getTestDataCellValue(scenarioName, "Study_StudyInformation_ProtocolDetails"));
		setDropDownValue(FDE_StudyPageObjects.studyDiscontinueReason_DropDown, scenarioName,
				"Study_StudyInformation_StudyDiscontinueReason");

		agSetValue(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.studyAcronym_Textbox),
				getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyAcronym"));

		CommonOperations.clickCheckBoxUnder(FDE_StudyPageObjects.IIS_CheckBox,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_IIS"));
		CommonOperations.clickCheckBoxUnder(FDE_StudyPageObjects.EUCTRegulation_CheckBox,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_EUCTRegulation2019"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Study >> Study Information Section : Scenario Name::" + scenarioName, false);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Study Registration in study
	 *             tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen: Sanchit on 28-Nov-2019
	 **********************************************************************************************************/
	// Below Hard Coded Value done for Data Modeling executions.
	static String rowNo_RegistrationNumber = "0"; // getTestDataCellValue(scenarioName, "RowNo_RegistrationNumber");
	static String boolAdd_RegistrationNumber = "#skip#"; // getTestDataCellValue(scenarioName, "MultipleStudyRegNo");

	public static void set_StudyRegistration(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (boolAdd_RegistrationNumber.equalsIgnoreCase("true")) {
			agClick(FDE_StudyPageObjects.add_Delete_Buttons(FDE_StudyPageObjects.studyReg_label,
					FDE_StudyPageObjects.addButton));
		}
		agSetValue((FDE_StudyPageObjects.registrationNumber_Textbox).replace("%rowNo%", rowNo_RegistrationNumber),
				getTestDataCellValue(scenarioName, "Study_StudyRegistration_RegistrationNumber"));
		CommonOperations.setFDEDropDownValue(
				(FDE_StudyPageObjects.registrationCountry_Dropdown).replace("%rowNo%", rowNo_RegistrationNumber),
				getTestDataCellValue(scenarioName, "Study_StudyRegistration_RegistrationCountry"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Study >> Study Registration Section : Scenario Name::" + scenarioName, false);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Study Registration in study
	 *             tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 28-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_StudyRegistration(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Study_StudyRegistration_RegistrationNumber"),
				(FDE_StudyPageObjects.registrationNumber_Textbox).replace("%rowNo%", rowNo_RegistrationNumber));
		CommonOperations.verifyFDEDropDownValue(
				(FDE_StudyPageObjects.registrationCountry_Dropdown).replace("%rowNo%", rowNo_RegistrationNumber),
				getTestDataCellValue(scenarioName, "Study_StudyRegistration_RegistrationCountry"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Study >> Study Registration Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Cross Referenced IND(s) in
	 *             study tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen: Sanchit on 28-Nov-2019
	 **********************************************************************************************************/
	// Below Hard Coded Value done for Data Modeling executions.
	static String rowNo_CrossReferencedNo = "0"; // getTestDataCellValue(scenarioName, "RowNo_CrossReferencedNo");
	static String boolAdd_CrossReferencedNo = "#skip#"; // getTestDataCellValue(scenarioName,
														// "MultipleCrossReferencedNo");

	public static void set_CrossReferencedNo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (boolAdd_CrossReferencedNo.equalsIgnoreCase("true")) {
			agClick(FDE_StudyPageObjects.add_Delete_Buttons(FDE_StudyPageObjects.crossRef_Label,
					FDE_StudyPageObjects.addButton));
		}
		agSetValue((FDE_StudyPageObjects.crossReferencedIND_Textbox).replace("%rowNo%", rowNo_CrossReferencedNo),
				getTestDataCellValue(scenarioName, "Study_StudyRegistration_CrossReferencedINDs"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Study >> Cross Referenced IND(s) Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Cross Referenced IND(s) in
	 *             study tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 28-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_CrossReferencedNo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Study_StudyRegistration_CrossReferencedINDs"),
				(FDE_StudyPageObjects.crossReferencedIND_Textbox).replace("%rowNo%", rowNo_CrossReferencedNo));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Study >> Cross Referenced IND(s) Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in Study Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen: Sanchit on 28-Nov-2019
	 **********************************************************************************************************/
	public static void studyData_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		verifyData(FDE_StudyPageObjects.get_ProtocolNo, scenarioName, "Study_StudyLookup_StudyNo");
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyType"),
				FDE_StudyPageObjects.get_DropDownValue(FDE_StudyPageObjects.studyType_DropDown));
		verifyData(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.projectNo_Textbox), scenarioName,
				"Study_StudyInformation_ProjectNo");
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyPhase"),
				FDE_StudyPageObjects.get_DropDownValue(FDE_StudyPageObjects.studyPhase_DropDown));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyDesign"),
				FDE_StudyPageObjects.get_DropDownValue(FDE_StudyPageObjects.studyDesign_DropDown));
		verifyData(FDE_StudyPageObjects.studyName_Textbox, scenarioName, "Study_StudyInformation_StudyName");
		verifyData(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.enrollmentStatus_Textbox), scenarioName,
				"Study_StudyInformation_EnrollmentStatus");
		agCheckPropertyValue("value",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Study_StudyInformation_EnrollmentDate")),
				FDE_StudyPageObjects.setData_Datesfields(FDE_StudyPageObjects.enrollmentDate_Datefield));
		agCheckPropertyValue("value",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Study_StudyInformation_WithdrawDate")),
				FDE_StudyPageObjects.setData_Datesfields(FDE_StudyPageObjects.withdrawnDate_Datefield));
		verifyData(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.eudraCTNumber_Textbox), scenarioName,
				"Study_StudyInformation_EudraCTNumber");
		verifyData(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.randomizationNumber_Textbox),
				scenarioName, "Study_StudyInformation_RandomizationNumber");
		verifyData(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.centerNumber_Textbox), scenarioName,
				"Study_StudyInformation_CenterNumber");
		verifyData(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.subjectID_Textbox), scenarioName,
				"Study_StudyInformation_SubjectID");
		verifyData(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.investigatorNumber_Textbox),
				scenarioName, "Study_StudyInformation_InvestigatorNumber");
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Study_StudyInformation_CaseCodeBroken"),
				FDE_StudyPageObjects.get_DropDownValue(FDE_StudyPageObjects.caseCodeBroken_DropDown));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyCodeBroken"),
				FDE_StudyPageObjects.get_DropDownValue(FDE_StudyPageObjects.studyCodeBroken_DropDown));
		verifyData(FDE_StudyPageObjects.primaryIND_Textfield, scenarioName, "Study_StudyInformation_PrimaryIND");
		CommonOperations.verifyCheckBoxUnder(FDE_StudyPageObjects.EUCTRegulation_CheckBox,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_EUCTRegulation2019"));
		if (getTestDataCellValue(scenarioName, "Study_StudyInformation_CaseCodeBroken")
				.equalsIgnoreCase("Code broken")) {
			agClick(FDE_StudyPageObjects.caseCodeBrokenOn_Datefield);
			agCheckPropertyValue("title",
					CommonOperations.returnDateTime(
							getTestDataCellValue(scenarioName, "Study_StudyInformation_CaseCodeBrokenOn")),
					FDE_StudyPageObjects.caseCodeBrokenOn_Datefield);

		}

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Study >> Study Information Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set data in study Tab tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen: Sanchit on 28-Nov-2019
	 **********************************************************************************************************/
	public static void set_StudyData(String scenarioName) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,
		// "ConfigurationSettings");
		// if (getTestDataCellValue(scenarioName, "FDE_Study").equalsIgnoreCase("Yes"))
		// {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		handleValidationMessage();
		if (FDE_General.getData(scenarioName, "Gen_CaseReport_ReportType").equalsIgnoreCase("Report from study")) {
			set_Protocol(scenarioName);
			set_StudyInformationDetails(scenarioName);
			set_StudyRegistration(scenarioName);
			set_CrossReferencedNo(scenarioName);
		}
		// }
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in study Tab tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_StudyData(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (FDE_General.getData(scenarioName, "Gen_CaseReport_ReportType").equalsIgnoreCase("Report from study")) {
			studyData_Verification(scenarioName);
			verify_StudyRegistration(scenarioName);
			verify_CrossReferencedNo(scenarioName);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in Study Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void studyData_BasicDetailsVerify(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_StudyPageObjects.get_ProtocolNo);
		String StudyNo = agGetAttribute("title", FDE_StudyPageObjects.get_ProtocolNo);
		status = agCheckPropertyValue("title", getTestDataCellValue(scenarioName, "Study_StudyLookup_StudyNo"),
				FDE_StudyPageObjects.get_ProtocolNo);
		if (status) {
			Reports.ExtentReportLog("Study Number Verification is Successfull", Status.PASS,
					"Study Number : " + StudyNo, true);
		} else {
			Reports.ExtentReportLog("Study Number Verification is Unsuccessfull", Status.FAIL,
					"Study Number: " + StudyNo, true);
		}
		String StudyType = agGetText(FDE_StudyPageObjects.get_DropDownValue(FDE_StudyPageObjects.studyType_DropDown));
		status = agCheckPropertyText(getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyType"),
				FDE_StudyPageObjects.get_DropDownValue(FDE_StudyPageObjects.studyType_DropDown));
		if (status) {
			Reports.ExtentReportLog("Study Type Verification is Successfull", Status.PASS, "Study Type : " + StudyType,
					true);
		} else {
			Reports.ExtentReportLog("Study Type Verification is Unsuccessfull", Status.FAIL,
					"Study Type : " + StudyType, true);
		}
		String CaseCode = agGetText(
				FDE_StudyPageObjects.get_DropDownValue(FDE_StudyPageObjects.caseCodeBroken_DropDown));
		status = agCheckPropertyText(getTestDataCellValue(scenarioName, "Study_StudyInformation_CaseCodeBroken"),
				FDE_StudyPageObjects.get_DropDownValue(FDE_StudyPageObjects.caseCodeBroken_DropDown));
		if (status) {
			Reports.ExtentReportLog("Case Code Broken Verification is Successfull", Status.PASS,
					"Case Code Broken : " + CaseCode, true);
		} else {
			Reports.ExtentReportLog("Case Code Broken Verification is Unsuccessfull", Status.FAIL,
					"Case Code Broken :" + CaseCode, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to copy product in Study Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void copy_Product(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_StudyPageObjects.study_Navigation(FDE_StudyPageObjects.studyProduct_tab));
		agAssertExists(FDE_StudyPageObjects.studyProduct_Label);
		agClick(FDE_StudyPageObjects.selectProduct(getTestDataCellValue(scenarioName, "BlindedProduct_1")));
		agJavaScriptExecuctorClick(FDE_StudyPageObjects.copyProduct_Buttons);
		if (agIsVisible(FDE_StudyPageObjects.productcopyPopupWindow) == true) {
			agClick(FDE_StudyPageObjects.productcopyPopupWindow_Okbutton);
		}

		agClick(FDE_StudyPageObjects.selectProduct(getTestDataCellValue(scenarioName, "StudyProduct_2")));
		agClick(FDE_StudyPageObjects.copyProduct_Buttons);
		if (agIsVisible(FDE_StudyPageObjects.productcopyPopupWindow) == true) {
			agClick(FDE_StudyPageObjects.productcopyPopupWindow_Okbutton);
		}
		CommonOperations.agwaitTillVisible(FDE_ProductsPageObjects.productCount_Visible, 3, 1000);
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify product in Study Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_ProductData(String scenarioName, String runTimeLabel, String columnName, String Rownum,
			String ColNum) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyText(getTestDataCellValue(scenarioName, columnName),
				FDE_StudyPageObjects.verify_ProductData(runTimeLabel, Rownum, ColNum));
		agJavaScriptExecuctorScrollToElement(FDE_StudyPageObjects.verify_ProductData(runTimeLabel, Rownum, ColNum));
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to set case code broken to NO
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCaseCodeBroken(String scenarioName) {
		setDropDownValue(FDE_StudyPageObjects.caseCodeBroken_DropDown, scenarioName,
				"Study_StudyInformation_CaseCodeBroken");
		if (agIsVisible(FDE_StudyPageObjects.confirmationPopup) == true) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "PopUpMessage"), FDE_StudyPageObjects.popUp_Message);
			agClick(FDE_StudyPageObjects.yesButton_PopupWindow);
			if (getTestDataCellValue(scenarioName, "Study_StudyInformation_CaseCodeBroken")
					.equalsIgnoreCase("Code broken")) {
				agSetValue(FDE_StudyPageObjects.caseCodeBrokenOn_Datefield, CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Study_StudyInformation_CaseCodeBrokenOn")));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is enhanced to copy multiple products from Study
	 *             Tab to ProductTab using Copy Products Button
	 * @InputParameters: scenarioName, noOfProducts
	 * @OutputParameters:
	 * @author: MP Ramkumar
	 * @Date : 18-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void copy_multipleProducts_fromStudyTab(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_StudyPageObjects.study_Navigation(FDE_StudyPageObjects.studyProduct_tab));
		int noOfProducts = Integer.parseInt(getTestDataCellValue(scenarioName, "NoOfProducts"));
		for (int i = 1; i <= noOfProducts; i++) {
			agAssertExists(FDE_StudyPageObjects.studyProduct_Label);
			agClick(FDE_StudyPageObjects.selectProduct(getTestDataCellValue(scenarioName, "Product_" + i)));
			agClick(FDE_StudyPageObjects.copyProduct_Buttons);
			if (agIsVisible(FDE_StudyPageObjects.productcopyPopupWindow))
				agClick(FDE_StudyPageObjects.productcopyPopupWindow_Okbutton);
		}
		CommonOperations.agwaitTillVisible(FDE_ProductsPageObjects.productCount_Visible, 3, 1000);
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to handle Validation Messages in
	 *             Study Screen.
	 * @InputParameters: NA
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 24-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void handleValidationMessageforNonStudy() {
		agWaitTillVisibilityOfElement(FDE_StudyPageObjects.studyConfirmationPopUp_Message);
		status = agIsVisible(FDE_StudyPageObjects.studyConfirmationPopUp_Message);
		if (status) {
			CommonOperations.takeScreenShot();
			agClick(FDE_StudyPageObjects.studyConfirmationPopUpOK_Btn);
			Reports.ExtentReportLog("", Status.INFO, "Report type in General is not set to Report from study", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to copy product in Study Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void copy_OneProduct(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_StudyPageObjects.study_Navigation(FDE_StudyPageObjects.studyProduct_tab));
		agAssertExists(FDE_StudyPageObjects.studyProduct_Label);
		agClick(FDE_StudyPageObjects.selectProduct(getTestDataCellValue(scenarioName, "BlindedProduct_1")));
		agJavaScriptExecuctorClick(FDE_StudyPageObjects.copyProduct_Buttons);
		if (agIsVisible(FDE_StudyPageObjects.productcopyPopupWindow) == true) {
			agClick(FDE_StudyPageObjects.productcopyPopupWindow_Okbutton);
		}
		CommonOperations.agwaitTillVisible(FDE_ProductsPageObjects.productCount_Visible, 3, 1000);
		CommonOperations.takeScreenShot();
	}

/**********************************************************************************************************
	 * @Objective: Verify R2 tags in Study tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 18-NOv-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyStudyR2Tags() {
		Reports.ExtentReportLog("", Status.INFO,"********Study R2 tag verification Started*******", true);
		agAssertVisible(FDE_StudyPageObjects.R2SponsorStudyNo);
		agAssertVisible(FDE_StudyPageObjects.R2StudyType);
		agAssertVisible(FDE_StudyPageObjects.R2StudyName);
		agAssertVisible(FDE_StudyPageObjects.R2CrossRefStudyName);
//		agAssertVisible(FDE_StudyPageObjects.R2Title);
//		agAssertVisible(FDE_StudyPageObjects.R2FirstName);
//		agAssertVisible(FDE_StudyPageObjects.R2MiddleName);
//		agAssertVisible(FDE_StudyPageObjects.R2LastName);
//		agAssertVisible(FDE_StudyPageObjects.R2Hospital_OrganizationName);
//		agAssertVisible(FDE_StudyPageObjects.R2Department);
//		agAssertVisible(FDE_StudyPageObjects.R2Street);
//		agAssertVisible(FDE_StudyPageObjects.R2City);
//		agAssertVisible(FDE_StudyPageObjects.R2State);
//		agAssertVisible(FDE_StudyPageObjects.R2PostalCode);
//		agAssertVisible(FDE_StudyPageObjects.R2Country);
//		agAssertVisible(FDE_StudyPageObjects.R2EmailId);
//		agAssertVisible(FDE_StudyPageObjects.R2SpanishState);
//		agAssertVisible(FDE_StudyPageObjects.R2Qualification);
		Reports.ExtentReportLog("", Status.INFO,"********Study R2 tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify R3 tags in Study tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 18-NOv-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyStudyR3Tags() {
		Reports.ExtentReportLog("", Status.INFO,"********Study R3 tag verification Started*******", true);
		agAssertVisible(FDE_StudyPageObjects.R3SponsorStudyNo);
		agAssertVisible(FDE_StudyPageObjects.R3StudyType);
		agAssertVisible(FDE_StudyPageObjects.R3StudyPhase);
		agAssertVisible(FDE_StudyPageObjects.R3StudyName);
		agAssertVisible(FDE_StudyPageObjects.R3PrimaryIND);
		agAssertVisible(FDE_StudyPageObjects.R3Panda);
		agAssertVisible(FDE_StudyPageObjects.R3RegistrationNumber);
		agAssertVisible(FDE_StudyPageObjects.R3RegistrationCountry);
		agAssertVisible(FDE_StudyPageObjects.R3CrossReferencedIND);
//		agAssertVisible(FDE_StudyPageObjects.R3Title);
//		agAssertVisible(FDE_StudyPageObjects.R3FirstName);
//		agAssertVisible(FDE_StudyPageObjects.R3MiddleName);
//		agAssertVisible(FDE_StudyPageObjects.R3LastName);
//		agAssertVisible(FDE_StudyPageObjects.R3Hospital_OrganizationName);
//		agAssertVisible(FDE_StudyPageObjects.R3Department);
//		agAssertVisible(FDE_StudyPageObjects.R3Street);
//		agAssertVisible(FDE_StudyPageObjects.R3City);
//		agAssertVisible(FDE_StudyPageObjects.R3State);
//		agAssertVisible(FDE_StudyPageObjects.R3PostalCode);
//		agAssertVisible(FDE_StudyPageObjects.R3Country);
//		agAssertVisible(FDE_StudyPageObjects.R3Telephone);
//		agAssertVisible(FDE_StudyPageObjects.R3EmailID);
//		agAssertVisible(FDE_StudyPageObjects.R3SpanishState);
//		agAssertVisible(FDE_StudyPageObjects.R3Qualification);	
		Reports.ExtentReportLog("", Status.INFO,"********Study R3 tag verification Completed*******", true);
	}
	
	/**********************************************************************************************************
	 * @Objective: Verify Codelist tags in Study tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 18-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyStudyCodeList() {
		Reports.ExtentReportLog("", Status.INFO,"********Study Codelist tag verification Started*******", true);
		Reports.ExtentReportLog("", Status.INFO,"********Study Codelist tag verification Started*******", true);
		agAssertVisible(FDE_StudyPageObjects.CLStudyType);	
		agAssertVisible(FDE_StudyPageObjects.CLStudyPhase);	
		agAssertVisible(FDE_StudyPageObjects.CLStudyDesign);
		agAssertVisible(FDE_StudyPageObjects.CLBlindingTechnique);
		agAssertVisible(FDE_StudyPageObjects.CLCaseCodeBroken);
		agAssertVisible(FDE_StudyPageObjects.CLStudyCodeBroken);
		agAssertVisible(FDE_StudyPageObjects.CLStudyCompletionStatus);
		agAssertVisible(FDE_StudyPageObjects.CLStudyDiscontinueReason);
		agAssertVisible(FDE_StudyPageObjects.CLEUCTRegulation2019);
		agAssertVisible(FDE_StudyPageObjects.CLRegistrationCountry);
//		agAssertVisible(FDE_StudyPageObjects.CLTitle);
//		agAssertVisible(FDE_StudyPageObjects.CLCountry);
//		agAssertVisible(FDE_StudyPageObjects.CLSpanishState);
//		agAssertVisible(FDE_StudyPageObjects.CLSpecialization);
//		agAssertVisible(FDE_StudyPageObjects.CLQualification);
//		agAssertVisible(FDE_StudyPageObjects.CLHealthProfessional);
//		agAssertVisible(FDE_StudyPageObjects.CLOccupation);
//		agAssertVisible(FDE_StudyPageObjects.CLReporterInformedAuthorityDirectly);
		Reports.ExtentReportLog("", Status.INFO,"********Study Codelist tag verification Completed*******", true);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to copy products in Study Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 31-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void copyAllStudyProducts() {		
		agClick(FDE_StudyPageObjects.study_Navigation(FDE_StudyPageObjects.studyProduct_tab));
		agAssertExists(FDE_StudyPageObjects.studyProduct_Label);
		List<WebElement> studyProductsList = agGetElementList(FDE_StudyPageObjects.productsList);
		int noOfRecords = studyProductsList.size();
		
		for (int recNum=1; recNum<=noOfRecords; recNum++) {			
			agClick(FDE_StudyPageObjects.selectProductRecord(String.valueOf(recNum)));
			agJavaScriptExecuctorClick(FDE_StudyPageObjects.copyProduct_Buttons);
			if (agIsVisible(FDE_StudyPageObjects.productcopyPopupWindow) == true) {
				agClick(FDE_StudyPageObjects.productcopyPopupWindow_Okbutton);
				agWaitTillInvisibilityOfElement(FDE_StudyPageObjects.productcopyPopupWindow);
			}			
		}		
	}
	
	/**********************************************************************************************************
	 * @Objective: Set Study Type
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Chithuraj R
	 * @Date : 31-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_StudyTYpe(String scenarioName) {
		
		setDropDownValue(FDE_StudyPageObjects.studyType_DropDown, scenarioName, "Study_StudyInformation_StudyType");
		handleValidationMessage();
	
	}
	
}