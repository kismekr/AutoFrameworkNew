package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1.OR.CaseManagementPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.CommonOperations;
import com.arisglobal.framework.components.lsmv.L10_1_1.FDE_Operations;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AutomationReviewPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.DataAssessmentPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AutomationReview extends ToolManager{

	static Boolean status;
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify duplicate check policy and verify rule and found counts.
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDuplicateCheckPolicy() {
		agClick(AutomationReviewPageObjects.automationReviewTab);
		agWaitTillInvisibilityOfElement(AutomationReviewPageObjects.loader);
		status = agIsVisible(AutomationReviewPageObjects.duplicatePolicy);
		if(status) {
			Reports.ExtentReportLog("", Status.PASS, "Duplicate policy verified successfully", true);
		}else {
			Reports.ExtentReportLog("", Status.FAIL, "Duplicate policy not verified successfully", true);
		}
		
		List<WebElement> levelCount = agGetElementList(AutomationReviewPageObjects.Levellist);		
		for (int i = 1; i <= levelCount.size(); i++) {
			
			String LevelType = agGetText(AutomationReviewPageObjects.listOfLevelIndex(Integer.toString(i)));
			System.out.println(LevelType);
			Reports.ExtentReportLog("", Status.INFO, "Level Type ::" + LevelType , true);
			
			String foundCaseLevelCounts = agGetText(AutomationReviewPageObjects.foundCaseAtLevel(Integer.toString(i)));
			System.out.println(foundCaseLevelCounts);		
			Reports.ExtentReportLog("", Status.INFO, "Case Level count ::" + foundCaseLevelCounts , true);
			
		}		
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.dataAssessmentLoader);
		agSetStepExecutionDelay("5000");
		
		status = agIsVisible(AutomationReviewPageObjects.listOfCase);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "No record found is visible successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "No record found is not visibe successfull", true);
		}		
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify duplicate check policy and verify rule and found counts.
	 * @OutputParameters: Integer of count
	 * @author:Kishore K R
	 * @Date : 13-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static int verifyDuplicateCheckPolicyCaseCount() {
		int expCount=0;
		String expLevel="";
		Boolean dupFound=verifyDuplicateCheckPolicyCase("found");
//		agClick(AutomationReviewPageObjects.dupToggler);
		if(dupFound) {
			List<WebElement> levelCount = agGetElementList(AutomationReviewPageObjects.rowsCount);		
			for (int iC = 1; iC <= levelCount.size(); iC++) {
				if(!agGetText(AutomationReviewPageObjects.caseCountLbl(iC)).contains("NA")) {
					System.out.println(agGetText(AutomationReviewPageObjects.dupLevelLbl(iC)));
					expLevel=agGetText(AutomationReviewPageObjects.dupLevelLbl(iC));
					expCount=Integer.parseInt(agGetText(AutomationReviewPageObjects.caseCountLbl(iC)));
				}
			}
			if(expCount>0) {
				Reports.ExtentReportLog("", Status.PASS,"Duplicate Check count found:"+Integer.toString(expCount)+" in Level "+expLevel, true);
			}
			else {
				Reports.ExtentReportLog("", Status.FAIL, "Duplicate Check count not found", true);
			}
		}
		return expCount;
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify duplicate check policy counts with Data Assessment
	 * @InputParameters: expect count, scenario Name and Sheet name where AER is available
	 * @OutputParameters:
	 * @author:Kishore K R
	 * @Date : 13-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void verifyDataAssessementCaseCount(int expCount,String scenarioName,String sheetName) {
		
		Boolean dupFound=verifyDataAssessmentCase("found");
		if(dupFound) {
			List<WebElement> dupRowsCount = agGetElementList(AutomationReviewPageObjects.dataAssesRowsCount);
			getTestData(lsmvConstants.LSMV_testData, sheetName);
			String AERNo=getTestDataCellValue(scenarioName, "AERNo");
			for (int iC = 1; iC <= dupRowsCount.size(); iC++) {
				if(agGetText(AutomationReviewPageObjects.dataAssessAER(iC)).contains(AERNo)) {
					CommonOperations.incremAlmStepNo("True", "Pass", AERNo+" found in data assessment", true);
				}
			}
			if (expCount==dupRowsCount.size()) {
				Reports.ExtentReportLog("", Status.PASS, Integer.toString(expCount)+" records found matching with Automation Review", true);
			} 
			else {
				Reports.ExtentReportLog("", Status.FAIL, "Records not matching with Automation Review", true);
			}	
		}
			
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify duplicate check policy and verify count not available.
	 * @OutputParameters: boolean
	 * @author:Kishore K R
	 * @Date : 23-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static boolean verifyDuplicateCheckPolicyCase(String dupCheck) {
		
		agClick(AutomationReviewPageObjects.automationReviewTab);
		agWaitTillInvisibilityOfElement(AutomationReviewPageObjects.loader);
		agWaitTillVisibilityOfElement(AutomationReviewPageObjects.dupCheckHeader);
		status = agIsVisible(AutomationReviewPageObjects.dupCheckHeader);
		if(status) {
			Reports.ExtentReportLog("", Status.PASS, agGetText(AutomationReviewPageObjects.dupCheckHeader)+" verified successfully", true);
		}else {
			Reports.ExtentReportLog("", Status.FAIL, "Duplicate policy not verified successfully", true);
		}
		status = agIsExists(AutomationReviewPageObjects.rowsCount);
		if(status&&dupCheck.equalsIgnoreCase("found")) {
			
			Reports.ExtentReportLog("", Status.PASS, "Duplicate Check count found", true);
			return true;
		}
		else if(!status&&!dupCheck.equalsIgnoreCase("found")) {
			Reports.ExtentReportLog("", Status.PASS, "Duplicate Check count not found", true);
			return true;
		}
		else {
			Reports.ExtentReportLog("", Status.FAIL, "Duplicate Check count mismatch", true);
			return false;
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify data assessment count not available.
	 * @OutputParameters: boolean
	 * @author:Kishore K R
	 * @Date : 23-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static boolean verifyDataAssessmentCase(String dataAssessCheck) {
		
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.dataAssessmentLoader);
		agSetStepExecutionDelay("5000");
		status = agIsExists(AutomationReviewPageObjects.noRecrdsDiv);
		if(!status&&dataAssessCheck.equalsIgnoreCase("found")) {
			
			Reports.ExtentReportLog("", Status.PASS, "Data assessment records found", true);
			return true;
		}
		else if(status&&!dataAssessCheck.equalsIgnoreCase("found")) {
			Reports.ExtentReportLog("", Status.PASS, "Data assessment records not found", true);
			return true;
		}
		else {
			Reports.ExtentReportLog("", Status.FAIL, "Data assessment records mismatch", true);
			return false;
		}
	}

	/**********************************************************************************************************
	 * @Objective: Duplicate check policy in Automation review and Data Management 
	 * @InputParameters: Policy Name,Case 
	 * @OutputParameters:
	 * @author:Chithuraj
	 * @Date : 16-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void dupCheckPolicyVerificationInCaseManagement(String receipt,String policy) {
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ApplicationConfigSearchPolices");
		
		agWaitTillInvisibilityOfElement(CaseListingPageObjects.caseListingLoading);
		agSetStepExecutionDelay("5000");
		agSetValue(CaseListingPageObjects.searchInputbox, receipt);
		agSendKeyStroke(Keys.ENTER);
		
		agClick(CaseListingPageObjects.clickReceipt(receipt));
		agClick(AutomationReviewPageObjects.automationReviewTab);
		agWaitTillInvisibilityOfElement(AutomationReviewPageObjects.loader);
		agWaitTillVisibilityOfElement(AutomationReviewPageObjects.dupCheckHeader);
		
		String getPolicyApplied=agGetText(AutomationReviewPageObjects.duplicatePolicy).split(":")[1].replace("))", "").trim();
		Assert.assertEquals(policy, getPolicyApplied);
		Reports.ExtentReportLog("", Status.INFO, "Policy Applied :" + getPolicyApplied , true);
		List<WebElement> levelCount = agGetElementList(AutomationReviewPageObjects.Levellist);		
		int caseCount=0;
		for (int i = 1; i <= levelCount.size(); i++) {
			
			String LevelType = agGetText(AutomationReviewPageObjects.listOfLevelIndex(Integer.toString(i)).replace(" - Rule 1", ""));
			Reports.ExtentReportLog("", Status.INFO, "Level :" + LevelType , true);
	
			String getCaseAttributeDataSheet=ApplicationConfigSearchPolices.getTestDataCellValue(getPolicyApplied, "CASE ATTRIBUTES").replace(":\n", "").trim();
			List<WebElement> getCriteriaAppliedList=agGetElementList(AutomationReviewPageObjects.criteriaApplied);
			String criteriaApplied="";
			
			for(WebElement getCriteriaAppliedElement:getCriteriaAppliedList) {	
				criteriaApplied=criteriaApplied+getCriteriaAppliedElement.getText();
			}

			Assert.assertEquals(getCaseAttributeDataSheet, criteriaApplied);
			Reports.ExtentReportLog("", Status.INFO, "Criteria Applied :" + criteriaApplied , true);
			if (agGetText(AutomationReviewPageObjects.caseCountLbl(i))=="NA"){
					continue;
			}
			caseCount=caseCount+Integer.parseInt(agGetText(AutomationReviewPageObjects.caseCountLbl(i)));
					
		}
		
		FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.dataAssessmentLoader);
		agSetStepExecutionDelay("10000");
		int dataAssesmentCaseCount=Integer.parseInt(agGetText(DataAssessmentPageObjects.totalcasecount).split("OF ")[1]);
		Reports.ExtentReportLog("", Status.INFO, "Case Count :" + dataAssesmentCaseCount , true);
		Assert.assertEquals(caseCount, dataAssesmentCaseCount);
	}
}
