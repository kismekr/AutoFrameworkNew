package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.WebElement;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AdminConfigRuleBuilderPageObject;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AdminConfigRuleBuilder extends ToolManager {

	static AdminConfigRuleBuilderPageObject admRulePageObj = new AdminConfigRuleBuilderPageObject();

	static String className = AdminConfigRuleBuilder.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: The below method is Search Rule Type in Rule Builder List Page
	 *             and Click edit Open the Rules Page.
	 * @InputParameters: NA
	 * @OutputParameters: NA
	 * @author: MP Ramkumar
	 * @Date : 05-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void searchEditRuleType(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String ruleType = getTestDataCellValue(scenarioName, "SearchRuleType");
		editRuleBuilderType(ruleType);
		String ruleName = getTestDataCellValue(scenarioName, "SearchRuleName");
		if (ruleName != "#skip#") {
			agSetValue(AdminConfigRuleBuilderPageObject.keywordSearchTextbox, ruleName);
			agClick(AdminConfigRuleBuilderPageObject.searckeywordSearchIcon);
			agSetStepExecutionDelay("2000");
			editRuleBuilderName(ruleName);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below methods are created for Cancel and Save buttons on Rule
	 *             Details Page.
	 * @InputParameters: NA
	 * @OutputParameters: NA
	 * @author: MP Ramkumar
	 * @Date : 05-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ruleDetailsCancelbtn() {
		agClick(AdminConfigRuleBuilderPageObject.ruleDetailsCancelbtn);
		agSetStepExecutionDelay("2000");
	}

	public static void ruleDetailsSavebtn() {
		agClick(AdminConfigRuleBuilderPageObject.ruleDetailsSavebtn);
		agSetStepExecutionDelay("2000");
	}

	/**********************************************************************************************************
	 * @Objective: The below methods are created for New and Cancel buttons on Rule
	 *             Builder List Page.
	 * @InputParameters: NA
	 * @OutputParameters: NA
	 * @author: MP Ramkumar
	 * @Date : 05-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ruleBuilderCancelbtn() {
		agClick(AdminConfigRuleBuilderPageObject.ruleBuilderListformCancelbtn);
		agSetStepExecutionDelay("2000");
	}

	public static boolean VerifyRuleData() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		return false;

	}

	/**********************************************************************************************************
	 * @Objective: Used to navigate to any edit link on Rule Builder-> Rule Type
	 *             Page.
	 * @InputParameters: String RuleType
	 * @OutputParameters: NA
	 * @author: Kishore K R
	 * @Date : 11-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void editRuleBuilderType(String RuleType) {
		List<WebElement> ruleRows = agGetElementList(AdminConfigRuleBuilderPageObject.ruleTableRows);
		int rowSize = ruleRows.size();
		int foundRow = 0;
		String spanText = null;
		for (int iRow = 1; iRow <= rowSize; iRow++) {
			spanText = agGetText(AdminConfigRuleBuilderPageObject.ruleTableSpan(iRow));
			if (RuleType.equalsIgnoreCase(spanText)) {
				foundRow = iRow;
				break;
			}
		}
		if(foundRow!= 0) {
			agClick(AdminConfigRuleBuilderPageObject.ruleTableLink(foundRow));
			Reports.ExtentReportLog("Rule Builder", Status.PASS,"Navigation Passed",true);
		}
		else {
			agClick(AdminConfigRuleBuilderPageObject.ruleTableLink(foundRow));
			Reports.ExtentReportLog("Rule Builder", Status.FAIL,"Navigation Failed",true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: Used to navigate to any edit link on Rule Builder-> Rule Name
	 *             Page.
	 * @InputParameters: String RuleName
	 * @OutputParameters: NA
	 * @author: Kishore K R
	 * @Date : 11-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void editRuleBuilderName(String RuleName) {
		List<WebElement> ruleRows = agGetElementList(AdminConfigRuleBuilderPageObject.ruleTableRows);
		int rowSize = ruleRows.size();
		int foundRow = 0;
		String spanText = null;
		for (int iRow = 1; iRow <= rowSize; iRow++) {
			spanText = agGetText(AdminConfigRuleBuilderPageObject.ruleTableNameSpan(iRow));
			if (RuleName.equalsIgnoreCase(spanText)) {
				foundRow = iRow;
				break;
			}
		}
		if(foundRow!= 0) {
			agClick(AdminConfigRuleBuilderPageObject.ruleTableLink(foundRow));
			Reports.ExtentReportLog("Rule Builder", Status.PASS,"Navigation Passed",true);
		}
		else {
			agClick(AdminConfigRuleBuilderPageObject.ruleTableLink(foundRow));
			Reports.ExtentReportLog("Rule Builder", Status.FAIL,"Navigation Failed",true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: Used to read all the rule fields
	 * @InputParameters: String scenario name
	 * @OutputParameters: NA
	 * @author: Kishore K R
	 * @throws Exception
	 * @Date : 25-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyAlertRuleFlds(String scenarioName) throws Exception {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "RuleVerification");

		ArrayList<String> obj = getTestDataRowValue("Scenario");
		for (int i = 0; i <= obj.size() - 1; i++) {
			if (!getTestDataCellValue(scenarioName, obj.get(i)).isEmpty()) {
				String objName[] = obj.get(i).split("_");
				if (objName[1].equalsIgnoreCase("input")) {
					agCheckPropertyValue("value", getTestDataCellValue(scenarioName, obj.get(i)),
							admRulePageObj.setInput(admRulePageObj.getFields(admRulePageObj, objName[0])));
				} else if (objName[1].equalsIgnoreCase("select")) {
					agCheckPropertyText(getTestDataCellValue(scenarioName, obj.get(i)),
							admRulePageObj.selectDroprdown(admRulePageObj.getFields(admRulePageObj, objName[0])));
				} else if (objName[1].equalsIgnoreCase("chkLeftOf")) {
					CommonOperations.verifyCheckBoxLeftOf(admRulePageObj.getFields(admRulePageObj, objName[0]),
							getTestDataCellValue(scenarioName, obj.get(i)));
				} else if (objName[1].equalsIgnoreCase("chkRightOf")) {
					CommonOperations.verifyCheckBoxRightOf(admRulePageObj.getFields(admRulePageObj, objName[0]),
							getTestDataCellValue(scenarioName, obj.get(i)));
				} else if (objName[1].equalsIgnoreCase("radio")) {
					CommonOperations.verifyRadioButton(admRulePageObj.getFields(admRulePageObj, objName[0]),
							admRulePageObj.getFields(admRulePageObj, objName[0]),
							getTestDataCellValue(scenarioName, obj.get(i)));
				} else if (objName[1].equalsIgnoreCase("textarea")) {
					agCheckPropertyText(getTestDataCellValue(scenarioName, obj.get(i)),
							admRulePageObj.setTextArea(admRulePageObj.getFields(admRulePageObj, objName[0])));
				} else {
					agCheckPropertyValue("value", getTestDataCellValue(scenarioName, obj.get(i)),
							admRulePageObj.getFields(admRulePageObj, obj.get(i)));
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: Used to read all the Template fields
	 * @InputParameters: String scenario name
	 * @OutputParameters: NA
	 * @author: Kishore K R
	 * @throws Exception
	 * @Date : 25-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyTemplateFlds(String scenarioName) throws Exception {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "TemplateVerification");

		ArrayList<String> obj = getTestDataRowValue("Scenario");
		for (int i = 0; i <= obj.size() - 1; i++) {
			if (!getTestDataCellValue(scenarioName, obj.get(i)).isEmpty()) {
				String objName[] = obj.get(i).split("_");
				if (objName[1].equalsIgnoreCase("input")) {
					agCheckPropertyValue("value", getTestDataCellValue(scenarioName, obj.get(i)),
							admRulePageObj.setInput(admRulePageObj.getFields(admRulePageObj, objName[0])));
				} else if (objName[1].equalsIgnoreCase("select")) {
					agCheckPropertyText(getTestDataCellValue(scenarioName, obj.get(i)),
							admRulePageObj.selectDroprdown(admRulePageObj.getFields(admRulePageObj, objName[0])));
				} else if (objName[1].equalsIgnoreCase("chkLeftOf")) {
					CommonOperations.verifyCheckBoxLeftOf(admRulePageObj.getFields(admRulePageObj, objName[0]),
							getTestDataCellValue(scenarioName, obj.get(i)));
				}
				else if (objName[1].equalsIgnoreCase("body")) {
					agSwitchFrameByIndex(0);
					agCheckPropertyText(getTestDataCellValue(scenarioName, obj.get(i)),admRulePageObj.getFields(admRulePageObj, objName[0]));
					agSwitchToDefaultFrame();
				}
				else  {
					agCheckPropertyValue("value", getTestDataCellValue(scenarioName, obj.get(i)),admRulePageObj.getFields(admRulePageObj, obj.get(i)));
				}
			}
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is Search and edit Rule Type in Rule Builder List Page
	 *            
	 * @InputParameters: scenarioName
	 * @OutputParameters: NA
	 * @author: Pooja S
	 * @Date : 13-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndEditRuleType(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String ruleType = getTestDataCellValue(scenarioName, "SearchRuleType");
		editRuleBuilderType(ruleType);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	
}

