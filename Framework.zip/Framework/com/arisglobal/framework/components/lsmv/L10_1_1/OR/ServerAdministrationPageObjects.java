package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import org.openqa.selenium.By;

public abstract class ServerAdministrationPageObjects {
	
	public static String alertsLink  = "xpath#//span[contains(text(),'Alerts')]";
	public static String logsLink = "xpath#//span[contains(text(),'Logs')]";
	public static String lDAPLink = "xpath#//span[contains(text(),'LDAP')]";
	public static String lDAPLabel = "xpath#//label[@id='ldapSettingForm:adminldaplabel']";
	public static String faxServerLink = "xpath#//span[contains(text(),'Fax server')]";
	public static String faxServerLabel = "xpath#//label[@id='faxForm:faxLabel']";
	public static String mailServerLink = "xpath#//span[contains(text(),'Mail server')]";
	public static String mailServerLabel = "xpath#//label[@id='mailServerlisting:mailservera']";
	public static String SchedulersLink = "xpath#//a[@id='headerForm:schedulersId']/span[text()='Schedulers']";
	public static String alertsLabel = "xpath#//span[@class='ui-column-title'][contains(text(),'Alert')]";
	public static String logsLabel = "xpath#//span[text()='Logs']";
	public static String lDAPKeywordSearch = "xpath#//input[@id='ldapSettingForm:keyword']";
	public static String FaxServerKeywordSearch = "xpath#//input[@id='faxForm:keyword']";
	public static String SchedulersLabel = "xpath#//a[@id='schlistForm:submission']//span[@class='ui-menuitem-text'][contains(text(),'Submission')]";
	
	
	
	
	
	
}
