package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.Random;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.DictionaryCodingBrowser_LookupPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ProductsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ReportsPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class ProductsOperations extends ToolManager {
	static String className = ProductsOperations.class.getSimpleName();
	public static WebElement webElement;
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**************************************************
	 * s********************************************************
	 * 
	 * @Objective: The below Method is create to perform menu navigations in Product
	 *             Module
	 * @InputParameters: pageObject
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen: s
	 ***************************************************/
	public static void menuNavigation(String pageObject) {
		agMouseHover(ProductsPageObjects.ProductHoverNew);
		agSetStepExecutionDelay("3000");
		agMouseHover(ProductsPageObjects.productHover);
		agClick(pageObject);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in
	 *             products Module and verify the label name.
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void productsNavigations(String menu) {
		switch (menu) {
		case "productsNew":

			menuNavigation(ProductsPageObjects.productNew);
			status = agIsVisible(ProductsPageObjects.productID);

			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "Navigation to products New is successfull", false);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to products New is Unsuccessfull", true);
			}
			break;
		case "productsListing":

			menuNavigation(ProductsPageObjects.productListing);
			status = agIsVisible(ProductsPageObjects.ListingkeywordSearchTextbox);

			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "", false);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to products Listing is Unsuccessfull", true);
			}
			break;
		case "unverifiedProducts":
			menuNavigation(ProductsPageObjects.unverifiedProducts);
			status = agIsVisible(ProductsPageObjects.unverifiedKeywordSearchTextbox);

			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "Navigation to unverified Products is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to unverified Products is Unsuccessfull", true);
			}
			break;
		case "tradeNames":
			menuNavigation(ProductsPageObjects.tradeNameLink);
			CommonOperations.agwaitTillVisible(ProductsPageObjects.tradeNameAddLink, 3, 1000);
			status = agIsVisible(ProductsPageObjects.tradeNameAddLink);

			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "Navigation to Trade Names is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Trade Names is Unsuccessfull", true);
			}
			break;
		case "synonyms":
			menuNavigation(ProductsPageObjects.synonymsLink);
			status = agIsVisible(ProductsPageObjects.synonymsAddLink);

			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "Navigation to Synonyms is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Synonyms is Unsuccessfull", true);
			}
			break;
		case "labeling":
			menuNavigation(ProductsPageObjects.labelingLink);
			status = agIsVisible(ProductsPageObjects.labelingAddLink);

			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "", false);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Labeling is Unsuccessfull", true);
			}
			break;
		case "AE'sOfSpecialInterest":
			menuNavigation(ProductsPageObjects.aeOfSpecialInterestLink);
			status = agIsVisible(ProductsPageObjects.aeOfSpecialInterestAddLink);

			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "Navigation to AE's Of Special Interest is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to AE's Of Special Interest is Unsuccessfull",
						true);
			}
			break;
		case "SelectedCountries":
			menuNavigation(ProductsPageObjects.selectedCountriesLink);
			status = agIsVisible(ProductsPageObjects.selectedCountriesAddLink);

			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "Navigation to Selected Countries is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Selected Countries is Unsuccessfull", true);
			}
			break;
		default:
			System.out.println("Invalid Menu Link!");
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Product.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean searchProduct(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("4000");
		if (scenarioName.contains("LSMV_OQ_AutoLabellingFunctionality")) {

		} else {
			agAssertVisible(ProductsPageObjects.ListingkeywordSearchTextbox);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(ProductsPageObjects.ListingkeywordSearchTextbox, getTestDataCellValue(scenarioName, "SearchText"));
		agClick(ProductsPageObjects.ListingkeywordSearchIcon);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay("5000");
		String paginator = agGetText(ProductsPageObjects.paginator);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.PASS, "", true);
			return true;
		} else {
			return false;
		}
	}

	public static boolean searchTheProduct(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		agAssertVisible(ProductsPageObjects.ListingkeywordSearchTextbox);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(ProductsPageObjects.ListingkeywordSearchTextbox, getTestDataCellValue(scenarioName, "SearchText"));
		agClick(ProductsPageObjects.ListingkeywordSearchIcon);
		agSetStepExecutionDelay("5000");
		String paginator = agGetText(ProductsPageObjects.paginator);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.INFO, "", true);
			return true;
		} else {
			return false;
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click on New Button in Product
	 *             Listing Screen.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 9-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickNewButton() {
		agClick(ProductsPageObjects.productNewButton);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit Product.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void editProduct() {
		agClick(ProductsPageObjects.edit_Icon);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to save Product.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 9-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void saveProduct(String scenarioName) {
		agClick(ProductsPageObjects.saveButton);
		CommonOperations.setAuditInfo(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Product Basic Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setBasicDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
		agSetStepExecutionDelay("2000");
		CommonOperations.setListDropDownValue(ProductsPageObjects.productTypeDropDown,
				getTestDataCellValue(scenarioName, "ProductType"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// agSetValue(ProductsPageObjects.productIDTextBox,
		// getTestDataCellValue(scenarioName, "ProductID"));
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorSendKeys(ProductsPageObjects.preferredProductDescTextBox,
				getTestDataCellValue(scenarioName, "PreferredProductDescription"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		if (getTestDataCellValue(scenarioName, "boolGlobalProductLookUp").equalsIgnoreCase("true")) {
			// Lookup Method need to be implemented
		} else {
			agSetValue(ProductsPageObjects.globalProductTextBox, getTestDataCellValue(scenarioName, "GlobalProduct"));
		}
		if (getTestDataCellValue(scenarioName, "boolFutureProductLookUp").equalsIgnoreCase("true")) {
			// Lookup Method need to be implemented
		} else {
			agSetValue(ProductsPageObjects.futureProductTextBox, getTestDataCellValue(scenarioName, "FutureProduct"));
		}
		agSetStepExecutionDelay("2000");
		CommonOperations.setListDropDownValue(ProductsPageObjects.productClassDropDown,
				getTestDataCellValue(scenarioName, "ProductClass"));
		CommonOperations.setListDropDownValue(ProductsPageObjects.routeOfAdminDropDown,
				getTestDataCellValue(scenarioName, "RouteOfAdmin"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(ProductsPageObjects.routeOfAdminTermIDTextBox,
				getTestDataCellValue(scenarioName, "RouteOfAdminTermID"));
		agSetStepExecutionDelay("2000");
		CommonOperations.setListDropDownValue(ProductsPageObjects.formOfAdminDropDown,
				getTestDataCellValue(scenarioName, "FormOfAdmin"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(ProductsPageObjects.pharmaceuticalDoseFormTermIDTextBox,
				getTestDataCellValue(scenarioName, "PharmaceuticalDoseFormTermID"));
		agSetValue(ProductsPageObjects.genericNameTextBox, getTestDataCellValue(scenarioName, "GenericName"));
		CommonOperations.clickRadioButton(ProductsPageObjects.activeRadio,
				getTestDataCellValue(scenarioName, "Active"));
		agSetStepExecutionDelay("2000");
		agSetValue(ProductsPageObjects.descriptionTextArea, getTestDataCellValue(scenarioName, "Description"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.product_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Basic Details Section 1 : Scenario Name:: " + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify Product Basic Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyBasicDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ProductType"), ProductsPageObjects.productTypeDropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ProductID"),
				ProductsPageObjects.productIDTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PreferredProductDescription"),
				ProductsPageObjects.preferredProductDescTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "GlobalProduct"),
				ProductsPageObjects.globalProductTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FutureProduct"),
				ProductsPageObjects.futureProductTextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ProductClass"),
				ProductsPageObjects.productClassDropDown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "RouteOfAdmin"),
				ProductsPageObjects.routeOfAdminDropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "RouteOfAdminTermID"),
				ProductsPageObjects.routeOfAdminTermIDTextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "FormOfAdmin"), ProductsPageObjects.formOfAdminDropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PharmaceuticalDoseFormTermID"),
				ProductsPageObjects.pharmaceuticalDoseFormTermIDTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "GenericName"),
				ProductsPageObjects.genericNameTextBox);
		CommonOperations.verifyRadioButton(ProductsPageObjects.activeRadio,
				getTestDataCellValue(scenarioName, "Active"));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Description"),
				ProductsPageObjects.descriptionTextArea);

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.product_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Basic Details Section 1 : Scenario Name:: " + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Product Basic Other Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setBasicOtherDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
		agSetValue(ProductsPageObjects.MPIDcrossReferenceTextBox,
				getTestDataCellValue(scenarioName, "MPIDCrossReference"));
		// agSetValue(ProductsPageObjects.fdaTextBox, getTestDataCellValue(scenarioName,
		// "FDA"));
		if (getTestDataCellValue(scenarioName, "boolManufacNameLookUp").equalsIgnoreCase("true")) {
			// Lookup Method need to be implemented
		} else {
			agSetValue(ProductsPageObjects.manufacturerNameTextBox,
					getTestDataCellValue(scenarioName, "ManufacturerName"));
		}
		if (getTestDataCellValue(scenarioName, "boolManufacGroupLookUp").equalsIgnoreCase("true")) {
			// Lookup Method need to be implemented
		} else {
			agSetValue(ProductsPageObjects.manufacturerGroupTextBox,
					getTestDataCellValue(scenarioName, "ManufacturerGroup"));
		}
		agSetValue(ProductsPageObjects.internationalBirthDateTextBox,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "InternationalBirthDate")));
		agClick(CommonPageObjects.applicationLogo);
		agSetValue(ProductsPageObjects.combinedCdcTextBox, getTestDataCellValue(scenarioName, "CombinedCdc"));
		agSetValue(ProductsPageObjects.combinedPharmaceuticalDoseTextBox,
				getTestDataCellValue(scenarioName, "CombinedPharmaceuticalDose"));
		agSetStepExecutionDelay("2000");
		CommonOperations.setListDropDownValue(ProductsPageObjects.productGroupDropDown,
				getTestDataCellValue(scenarioName, "ProductGroup"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(ProductsPageObjects.productKeywordsTextArea, getTestDataCellValue(scenarioName, "ProductKeywords"));
		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.mpidCrossReference_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Basic Details Section 2 : Scenario Name:: " + scenarioName, true);

		agSetValue(ProductsPageObjects.productActiveIngredientTextArea,
				getTestDataCellValue(scenarioName, "ProductActiveIngredient"));
		if (getTestDataCellValue(scenarioName, "boolWHODDLookUp").equalsIgnoreCase("true")) {
			// Lookup Method need to be implemented
		} else {
			agSetValue(ProductsPageObjects.whoDDTextBox, getTestDataCellValue(scenarioName, "WHODD"));
		}
		agSetStepExecutionDelay("2000");
		CommonOperations.setListDropDownValue(ProductsPageObjects.madeByDropDown,
				getTestDataCellValue(scenarioName, "MadeBy"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.clickRadioButton(ProductsPageObjects.companyProductRadio,
				getTestDataCellValue(scenarioName, "CompanyProduct"));
		CommonOperations.clickRadioButton(ProductsPageObjects.subjectToRiskManagementRadio,
				getTestDataCellValue(scenarioName, "SubjectToRiskManagement"));
		agSetStepExecutionDelay("2000");
		agSetValue(ProductsPageObjects.internalCodeTextBox, getTestDataCellValue(scenarioName, "InternalCode"));
		CommonOperations.setListDropDownValue(ProductsPageObjects.productUsedInDropDown,
				getTestDataCellValue(scenarioName, "ProductUsedIn"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (getTestDataCellValue(scenarioName, "boolATCCodeLookUp").equalsIgnoreCase("true")) {
			// Lookup Method need to be implemented
		} else {
			agSetValue(ProductsPageObjects.atcCodeTextBox, getTestDataCellValue(scenarioName, "ATCCode"));
		}

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.productActiveIngredient_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Basic Details Section 3 : Scenario Name:: " + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify Product Basic Other
	 *             Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyBasicOtherDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MPIDCrossReference"),
				ProductsPageObjects.MPIDcrossReferenceTextBox);
		// agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FDA"),
		// ProductsPageObjects.fdaTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ManufacturerName"),
				ProductsPageObjects.manufacturerNameTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ManufacturerGroup"),
				ProductsPageObjects.manufacturerGroupTextBox);
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "InternationalBirthDate")),
				ProductsPageObjects.internationalBirthDateTextBox);
		agClick(CommonPageObjects.applicationLogo);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "CombinedCdc"),
				ProductsPageObjects.combinedCdcTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "CombinedPharmaceuticalDose"),
				ProductsPageObjects.combinedPharmaceuticalDoseTextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ProductGroup"),
				ProductsPageObjects.productGroupDropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ProductKeywords"),
				ProductsPageObjects.productKeywordsTextArea);

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.mpidCrossReference_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Basic Details Section 2 : Scenario Name:: " + scenarioName, true);

		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ProductActiveIngredient"),
				ProductsPageObjects.productActiveIngredientTextArea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "WHODD"), ProductsPageObjects.whoDDTextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "MadeBy"), ProductsPageObjects.madeByDropDown);
		CommonOperations.verifyRadioButton(ProductsPageObjects.companyProductRadio,
				getTestDataCellValue(scenarioName, "CompanyProduct"));
		CommonOperations.verifyRadioButton(ProductsPageObjects.subjectToRiskManagementRadio,
				getTestDataCellValue(scenarioName, "SubjectToRiskManagement"));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "InternalCode"),
				ProductsPageObjects.internalCodeTextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ProductUsedIn"),
				ProductsPageObjects.productUsedInDropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ATCCode"),
				ProductsPageObjects.atcCodeTextBox);

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.productActiveIngredient_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Basic Details Section 3 : Scenario Name:: " + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Product Strength Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setStrengthDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
		switch (getTestDataCellValue(scenarioName, "Strength")) {
		case "Structured Strength":
			agClick(ProductsPageObjects.strengthRadioBtn(getTestDataCellValue(scenarioName, "Strength")));
			agSetValue(ProductsPageObjects.strengthTextBox, getTestDataCellValue(scenarioName, "StructuredStrength"));
			CommonOperations.setListDropDownValue(ProductsPageObjects.strengthUnitDropDown,
					getTestDataCellValue(scenarioName, "StructuredStrengthUnit"));

			break;
		case "Unstructured Strength":
			agClick(ProductsPageObjects.strengthRadioBtn(getTestDataCellValue(scenarioName, "Strength")));
			agSetValue(ProductsPageObjects.unStructuredStrengthTextBox,
					getTestDataCellValue(scenarioName, "UnstructuredStrength"));
			break;
		}
		agSetValue(ProductsPageObjects.productURLTextBox, getTestDataCellValue(scenarioName, "ProductURL"));

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.strength_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Basic Details >> Strength Section : Scenario Name:: " + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify Product Strength Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyStrengthDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
		switch (getTestDataCellValue(scenarioName, "Strength")) {
		case "Structured Strength":
			// agClick(ProductsPageObjects.strengthRadioBtn(getTestDataCellValue(scenarioName,
			// "Strength")));
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "StructuredStrength"),
					ProductsPageObjects.strengthTextBox);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "StructuredStrengthUnit"),
					ProductsPageObjects.strengthUnitDropDown);
			break;
		case "Unstructured Strength":
			// agClick(ProductsPageObjects.strengthRadioBtn(getTestDataCellValue(scenarioName,
			// "Strength")));
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "UnstructuredStrength"),
					ProductsPageObjects.unStructuredStrengthTextBox);
			break;
		}
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ProductURL"),
				ProductsPageObjects.productURLTextBox);

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.strength_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Basic Details >> Strength Section : Scenario Name:: " + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Product Additional or Product
	 *             Name Parts Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setAdditionalDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
		// agSetValue(ProductsPageObjects.packageDescriptionTextBox,
		// getTestDataCellValue(scenarioName, "PackageDescription"));
		agSetStepExecutionDelay("2000");
		CommonOperations.setListDropDownValue(ProductsPageObjects.unitOfRepresentationDropDown,
				getTestDataCellValue(scenarioName, "UnitOfRepresentation"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(ProductsPageObjects.pharmaceuticalDoseFormPartTextBox,
				getTestDataCellValue(scenarioName, "PharmaceuticalDoseFormPart"));
		agSetValue(ProductsPageObjects.formulationPartTextBox, getTestDataCellValue(scenarioName, "FormulationPart"));
		agSetValue(ProductsPageObjects.containerOrPackPartTextBox,
				getTestDataCellValue(scenarioName, "ContainerPackPart"));
		agSetValue(ProductsPageObjects.trademarkOrCompanyNamePartTextBox,
				getTestDataCellValue(scenarioName, "TrademarkCompanyNamePart"));
		agSetStepExecutionDelay("2000");
		CommonOperations.setListDropDownValue(ProductsPageObjects.languageDropDown,
				getTestDataCellValue(scenarioName, "Language"));
		agSetValue(ProductsPageObjects.targetPopulationPpartTextBox,
				getTestDataCellValue(scenarioName, "TargetPopulationPart"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.productNameParts_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Basic Details >> Product Name Parts Section : Scenario Name:: "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify Product Additional Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyAdditionalDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
		// agCheckPropertyValue("value", getTestDataCellValue(scenarioName,
		// "PackageDescription"),
		// ProductsPageObjects.packageDescriptionTextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "UnitOfRepresentation"),
				ProductsPageObjects.unitOfRepresentationDropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PharmaceuticalDoseFormPart"),
				ProductsPageObjects.pharmaceuticalDoseFormPartTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FormulationPart"),
				ProductsPageObjects.formulationPartTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ContainerPackPart"),
				ProductsPageObjects.containerOrPackPartTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "TrademarkCompanyNamePart"),
				ProductsPageObjects.trademarkOrCompanyNamePartTextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Language"), ProductsPageObjects.languageDropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "TargetPopulationPart"),
				ProductsPageObjects.targetPopulationPpartTextBox);

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.productNameParts_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Basic Details >> Product Name Parts Section : Scenario Name:: "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Product Substances from
	 *             Substances LookUp.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void selectSubstancesDetailsFromLookUp(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
		String subName = getTestDataCellValue(scenarioName, "SubstanceName");
		String[] totalRecords = subName.split(",");
		String rowNO = "";
		for (int i = 0; i < totalRecords.length; i++) {
			agClick(ProductsPageObjects.substancesAddLink);
			agAssertVisible(ProductsPageObjects.substanceNameTextBox);
			agSetValue(ProductsPageObjects.substanceNameTextBox, totalRecords[i]);
			agClick(ProductsPageObjects.subLookUpSearchButton);
			agAssertVisible(ProductsPageObjects.substanceSelectLookUp(totalRecords[i]));
			agClick(ProductsPageObjects.selectSubstanceLookUpCheckBox(totalRecords[i]));
			CommonOperations.takeScreenShot();
			agClick(ProductsPageObjects.subLookUpOkButton);
			agWaitTillInvisibilityOfElement(ProductsPageObjects.subLookUpOkButton);
			Constants.highlightObjects = false;
			agSetValue(ProductsPageObjects.subStrengthLstViewTextBox(totalRecords[i]),
					getTestDataCellValue(scenarioName, "StrengthSubstance"));
			if (getTestDataCellValue(scenarioName, "substanceRowNo").equalsIgnoreCase("#skip#")) {
				rowNO = Integer.toString(i);
			} else {
				rowNO = getTestDataCellValue(scenarioName, "substanceRowNo");
			}
			CommonOperations.setListDropDownValue(
					(ProductsPageObjects.subStrengthUnitListViewDropDown).replace("%rowNo%", rowNO),
					getTestDataCellValue(scenarioName, "StrengthUnitSubstance"));
			CommonOperations.setListDropDownValue(
					(ProductsPageObjects.subSubstanceRoleListViewDropDown).replace("%rowNo%", rowNO),
					getTestDataCellValue(scenarioName, "SubstanceRoleSubstance"));
			Constants.highlightObjects = true;

		}
		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.substances_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Basic Details >> Substances Section : Scenario Name:: " + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Product Substances Details in
	 *             Substances List View.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSubstancesDetailsListView(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Constants.highlightObjects = false;
		agSetValue(ProductsPageObjects.subStrengthLstViewTextBox(getTestDataCellValue(scenarioName, "SubstanceName")),
				getTestDataCellValue(scenarioName, "StrengthSubstance"));
		CommonOperations.setListDropDownValue(
				(ProductsPageObjects.subStrengthUnitListViewDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "substanceRowNo")),
				getTestDataCellValue(scenarioName, "StrengthUnitSubstance"));
		CommonOperations.setListDropDownValue(
				(ProductsPageObjects.subSubstanceRoleListViewDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "substanceRowNo")),
				getTestDataCellValue(scenarioName, "SubstanceRoleSubstance"));
		Constants.highlightObjects = true;

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.substances_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Basic Details >> Substances Section : Scenario Name:: " + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Product Substances Details
	 *             in Substances List View.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySubstancesDetailsListView(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Constants.highlightObjects = false;
		agAssertVisible(
				ProductsPageObjects.substanceNameLstViewTextBox(getTestDataCellValue(scenarioName, "SubstanceName"),
						getTestDataCellValue(scenarioName, "substanceRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "StrengthSubstance"),
				ProductsPageObjects.subStrengthLstViewTextBox(getTestDataCellValue(scenarioName, "SubstanceName")));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "StrengthUnitSubstance"),
				(ProductsPageObjects.subStrengthUnitListViewDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "substanceRowNo")));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "SubstanceRoleSubstance"),
				(ProductsPageObjects.subSubstanceRoleListViewDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "substanceRowNo")));
		Constants.highlightObjects = true;

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.substances_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Basic Details >> Substances Section : Scenario Name:: "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Product Substances Details in
	 *             Substances Form View.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSubstancesDetailsFormView(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.subStrengthFormViewTextBox);
		agSetValue(ProductsPageObjects.subStrengthFormViewTextBox,
				getTestDataCellValue(scenarioName, "StrengthSubstance"));
		CommonOperations.setListDropDownValue(ProductsPageObjects.subStrengthUnitFormViewDropDown,
				getTestDataCellValue(scenarioName, "StrengthUnitSubstance"));
		CommonOperations.setListDropDownValue(ProductsPageObjects.subSubstanceRoleFormViewDropDown,
				getTestDataCellValue(scenarioName, "SubstanceRoleSubstance"));
		agSetValue(ProductsPageObjects.subMeasurementPointFormViewTextBox,
				getTestDataCellValue(scenarioName, "MeasurementPoint"));
		CommonOperations.setListDropDownValue(ProductsPageObjects.subIngredientTypeFormViewDropDown,
				getTestDataCellValue(scenarioName, "IngredientType"));

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.substances_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Basic Details >> Substances Form View : Scenario Name:: " + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Product Substances Details
	 *             in Substances Form View.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySubstancesDetailsFormView(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.subStrengthFormViewTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "SubstanceName"),
				ProductsPageObjects.substanceFormViewTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "StrengthSubstance"),
				ProductsPageObjects.subStrengthFormViewTextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "StrengthUnitSubstance"),
				ProductsPageObjects.subStrengthUnitFormViewDropDown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "SubstanceRoleSubstance"),
				ProductsPageObjects.subSubstanceRoleFormViewDropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MeasurementPoint"),
				ProductsPageObjects.subMeasurementPointFormViewTextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "IngredientType"),
				ProductsPageObjects.subIngredientTypeFormViewDropDown);

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.substances_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Basic Details >> Substances Form View : Scenario Name:: "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Synonyms Details under Product
	 *             Substances in Form View.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSubstanceSynonymsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.subStrengthFormViewTextBox);
		String subSynonyms = getTestDataCellValue(scenarioName, "SubstanceSynonyms");
		String[] totalRecords = subSynonyms.split(",");
		for (int i = 0; i < totalRecords.length; i++) {
			if (agIsVisible((ProductsPageObjects.subSynonymsTextArea).replace("%rowNo%",
					getTestDataCellValue(scenarioName, "subSynonymsRowNo"))) == false) {
				agClick(ProductsPageObjects.subSynonymsAddLink);
			}
			Constants.highlightObjects = false;
			agSetValue((ProductsPageObjects.subSynonymsTextArea).replace("%rowNo%",
					getTestDataCellValue(scenarioName, "subSynonymsRowNo")), totalRecords[i]);
			Constants.highlightObjects = true;
		}

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.substances_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Basic Details >> Substances >> Synonyms : Scenario Name:: " + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Synonyms Details under
	 *             Product Substances in Form View.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySubstanceSynonymsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.subStrengthFormViewTextBox);
		Constants.highlightObjects = false;
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "SubstanceSynonyms"),
				(ProductsPageObjects.subSynonymsTextArea).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "subSynonymsRowNo")));
		Constants.highlightObjects = true;

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.substances_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Basic Details >> Substances >> Synonyms : Scenario Name:: "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Therapeutic Area Details in
	 *             Products.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setTherapeuticAreaDetailsFromLookUp(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
		String therapeuticArea = getTestDataCellValue(scenarioName, "TherapeuticArea");
		if (!therapeuticArea.equalsIgnoreCase("#skip#")) {
			String[] totalRecords = therapeuticArea.split(",");
			String rowNO = "";
			for (int i = 0; i < totalRecords.length; i++) {
				agClick(ProductsPageObjects.therapeuticAreaAddLink);

				agAssertVisible(ProductsPageObjects.therapeuticAreaSelectLookUp(totalRecords[i]));
				agClick(ProductsPageObjects.therapeuticAreaLookUpCheckBox(totalRecords[i]));
				if (agIsVisible(ProductsPageObjects.therapeuticAreaLookUpCheckBox(totalRecords[i])) == true) {
					agClick(ProductsPageObjects.therapeuticAreaLookUpCheckBox(totalRecords[i]));
				}
				agSetStepExecutionDelay("1000");
				agClick(ProductsPageObjects.therapeuticAreaLookUpOkButton);
				Constants.highlightObjects = false;
				if (getTestDataCellValue(scenarioName, "TherapeuticAreaRowNo").equalsIgnoreCase("#skip#")) {
					rowNO = Integer.toString(i);
				} else {
					rowNO = getTestDataCellValue(scenarioName, "TherapeuticAreaRowNo");
				}
				CommonOperations.setListDropDownValue(
						(ProductsPageObjects.therapeuticAreaPriorityDropDown).replace("%rowNo%", rowNO),
						getTestDataCellValue(scenarioName, "Priority"));
				Constants.highlightObjects = true;
			}
			agJavaScriptExecuctorScrollToElement(ProductsPageObjects.therapeuticArea_Div);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Products >> Basic Details >> Therapeutic Area Section : Scenario Name:: "
							+ scenarioName,
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Therapeutic Area Details List
	 *             View in Products.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setTherapeuticAreaDetailsListView(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Constants.highlightObjects = false;
		CommonOperations.setListDropDownValue(
				(ProductsPageObjects.therapeuticAreaPriorityDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TherapeuticAreaRowNo")),
				getTestDataCellValue(scenarioName, "Priority"));
		Constants.highlightObjects = true;

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.therapeuticArea_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Basic Details >> Therapeutic Area Section : Scenario Name:: "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Therapeutic Area Details
	 *             List View in Products.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyTherapeuticAreaDetailsListView(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Constants.highlightObjects = false;
		if (!getTestDataCellValue(scenarioName, "TherapeuticArea").equalsIgnoreCase("#skip#")) {
			agAssertVisible(
					ProductsPageObjects.therapeuticAreaLabel(getTestDataCellValue(scenarioName, "TherapeuticArea"),
							getTestDataCellValue(scenarioName, "TherapeuticAreaRowNo")));
		}
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Priority"),
				(ProductsPageObjects.therapeuticAreaPriorityDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TherapeuticAreaRowNo")));
		Constants.highlightObjects = true;

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.therapeuticArea_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Basic Details >> Therapeutic Area Section : Scenario Name:: "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Indications Details in
	 *             Products.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setIndicationsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
		if (getTestDataCellValue(scenarioName, "boolIndicationAdd").equalsIgnoreCase("true")) {
			agClick(ProductsPageObjects.indicationsAddLink);
		}
		Constants.highlightObjects = false;
		if (getTestDataCellValue(scenarioName, "boolLLTtermLookUp").equalsIgnoreCase("true")) {
			agClick((ProductsPageObjects.lltTermLookUpIcon).replace("%rowNo%",
					getTestDataCellValue(scenarioName, "IndicationRowNo")));
			CommonOperations.setDictionaryCodingBrowserDetails(getTestDataCellValue(scenarioName, "IndicationLLTterm"));
		} else {
			agSetValue(
					(ProductsPageObjects.lltTermTextBox).replace("%rowNo%",
							getTestDataCellValue(scenarioName, "IndicationRowNo")),
					getTestDataCellValue(scenarioName, "IndicationLLTterm"));
			agClick((ProductsPageObjects.lltTermTextSuggestion).replace("$term$",
					getTestDataCellValue(scenarioName, "IndicationLLTterm")));
		}
		agSetValue(
				(ProductsPageObjects.lltCodeTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "IndicationRowNo")),
				getTestDataCellValue(scenarioName, "IndicationLLTCode"));
		agSetValue(
				(ProductsPageObjects.ptTermTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "IndicationRowNo")),
				getTestDataCellValue(scenarioName, "IndicationPTterm"));
		agSetValue(
				(ProductsPageObjects.ptCodeTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "IndicationRowNo")),
				getTestDataCellValue(scenarioName, "IndicationPTCode"));
		agSetValue(
				(ProductsPageObjects.icdCODETextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "IndicationRowNo")),
				getTestDataCellValue(scenarioName, "IndicationICDCode"));
		agSetValue(
				(ProductsPageObjects.medDRaVersionTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "IndicationRowNo")),
				getTestDataCellValue(scenarioName, "IndicationMedDRaVersion"));
		Constants.highlightObjects = true;

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.indications_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Basic Details >> Indications Section : Scenario Name:: " + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Indications Details in
	 *             Products.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyIndicationsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
		Constants.highlightObjects = false;
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "IndicationLLTterm"),
				(ProductsPageObjects.lltTermTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "IndicationRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "IndicationLLTCode"),
				(ProductsPageObjects.lltCodeTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "IndicationRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "IndicationPTterm"),
				(ProductsPageObjects.ptTermTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "IndicationRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "IndicationPTCode"),
				(ProductsPageObjects.ptCodeTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "IndicationRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "IndicationICDCode"),
				(ProductsPageObjects.icdCODETextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "IndicationRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "IndicationMedDRaVersion"),
				(ProductsPageObjects.medDRaVersionTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "IndicationRowNo")));
		Constants.highlightObjects = true;

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.indications_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Basic Details >> Indications Section : Scenario Name:: "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Product Characteristics
	 *             Details in Products.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setProductCharacteristicsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
		if (getTestDataCellValue(scenarioName, "boolProdCharacAdd").equalsIgnoreCase("true")) {
			agClick(ProductsPageObjects.characteristicsAddLink);
		}
		Constants.highlightObjects = false;
		CommonOperations.setListDropDownValue(
				(ProductsPageObjects.productCharacSystemDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "ProdCharacRowNo")),
				getTestDataCellValue(scenarioName, "ProductCharacteristicCodeSystem"));
		CommonOperations.setListDropDownValue(
				(ProductsPageObjects.productCharacValueDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "ProdCharacRowNo")),
				getTestDataCellValue(scenarioName, "ProductCharacteristicValue"));
		Constants.highlightObjects = true;

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.productCharacteristics_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Basic Details >> Product Characteristics Section : Scenario Name:: "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Product Characteristics
	 *             Details in Products.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyProductCharacteristicsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
		Constants.highlightObjects = false;
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ProductCharacteristicCodeSystem"),
				(ProductsPageObjects.productCharacSystemDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "ProdCharacRowNo")));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ProductCharacteristicValue"),
				(ProductsPageObjects.productCharacValueDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "ProdCharacRowNo")));
		Constants.highlightObjects = true;

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.productCharacteristics_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Basic Details >> Product Characteristics Section : Scenario Name:: "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Trade Names Details List View
	 *             in Products Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setTradeNamesDetailsListView(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.tradeNameAddLink);
		if (getTestDataCellValue(scenarioName, "boolTradeNameAdd").equalsIgnoreCase("true")) {
			agClick(ProductsPageObjects.tradeNameAddLink);
			agSetStepExecutionDelay("3000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		Constants.highlightObjects = false;
		CommonOperations.agwaitTillVisible((ProductsPageObjects.tradeBrandNameListViewTextBox).replace("%rowNo%",
				getTestDataCellValue(scenarioName, "TradeNameRowNo")), 1, 1000);
		agSetValue(
				(ProductsPageObjects.tradeBrandNameListViewTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")),
				getTestDataCellValue(scenarioName, "TradeBrandName"));
		agSetValue(
				(ProductsPageObjects.tradeBrandNameListViewTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")),
				getTestDataCellValue(scenarioName, "TradeBrandName"));
		CommonOperations.setListDropDownValue(
				(ProductsPageObjects.prodTypeTradeNmeListViewDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")),
				getTestDataCellValue(scenarioName, "ProductTypeTradeName"));
		if (agIsVisible((ProductsPageObjects.ndcNoListViewTextBox).replace("%rowNo%",
				getTestDataCellValue(scenarioName, "TradeNameRowNo"))) == true) {
			agSetValue(
					(ProductsPageObjects.ndcNoListViewTextBox).replace("%rowNo%",
							getTestDataCellValue(scenarioName, "TradeNameRowNo")),
					getTestDataCellValue(scenarioName, "NDCNo"));
		}
		agSetValue(
				(ProductsPageObjects.approvalNoListViewTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")),
				getTestDataCellValue(scenarioName, "ApprovalNo"));
		CommonOperations.setListDropDownValue(
				(ProductsPageObjects.approvalTypeListViewDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")),
				getTestDataCellValue(scenarioName, "ApprovalType"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Trade Names List View Section 1 : Scenario Name:: " + scenarioName, true);

		if (getTestDataCellValue(scenarioName, "boolMarketAuthHolderLookUp").equalsIgnoreCase("true")) {
			// Lookup Method need to be implemented
		} else {
			agSetValue(
					(ProductsPageObjects.marketingAuthHolderListViewTextBox).replace("%rowNo%",
							getTestDataCellValue(scenarioName, "TradeNameRowNo")),
					getTestDataCellValue(scenarioName, "MarketingAuthHolder"));
		}
		if (agIsVisible((ProductsPageObjects.sourceListViewDropDown).replace("%rowNo%",
				getTestDataCellValue(scenarioName, "TradeNameRowNo"))) == true) {
			CommonOperations.setListDropDownValue(
					(ProductsPageObjects.sourceListViewDropDown).replace("%rowNo%",
							getTestDataCellValue(scenarioName, "TradeNameRowNo")),
					getTestDataCellValue(scenarioName, "Source"));
		}
		if (getTestDataCellValue(scenarioName, "boolAgentDistributorLookUp").equalsIgnoreCase("true")) {
			// Lookup Method need to be implemented
		} else {
			agSetValue(
					(ProductsPageObjects.agentDistributorListViewTextBox).replace("%rowNo%",
							getTestDataCellValue(scenarioName, "TradeNameRowNo")),
					getTestDataCellValue(scenarioName, "AgentDistributor"));
		}
		CommonOperations.setListDropDownValue(
				(ProductsPageObjects.authorizationCountryListViewDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")),
				getTestDataCellValue(scenarioName, "AuthorizationCountry"));
		CommonOperations.setListDropDownValue(
				(ProductsPageObjects.submissionTypeListViewDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")),
				getTestDataCellValue(scenarioName, "SubmissionType"));
		agSetValue(
				(ProductsPageObjects.atcCodeTradeNmeListViewTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")),
				getTestDataCellValue(scenarioName, "ATCCodeTradeName"));
		CommonOperations.setListDropDownValue(
				(ProductsPageObjects.dataSheetNameListViewDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")),
				getTestDataCellValue(scenarioName, "DataSheetName"));
		Constants.highlightObjects = true;

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Trade Names List View Section 2 : Scenario Name:: " + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Trade Names Details List
	 *             View in Products Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyTradeNamesDetailsListView(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.tradeNameAddLink);
		Constants.highlightObjects = false;
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "TradeBrandName"),
				(ProductsPageObjects.tradeBrandNameListViewTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ProductTypeTradeName"),
				(ProductsPageObjects.prodTypeTradeNmeListViewDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ApprovalNo"),
				(ProductsPageObjects.approvalNoListViewTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ApprovalType"),
				(ProductsPageObjects.approvalTypeListViewDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MarketingAuthHolder"),
				(ProductsPageObjects.marketingAuthHolderListViewTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "AgentDistributor"),
				(ProductsPageObjects.agentDistributorListViewTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "AuthorizationCountry"),
				(ProductsPageObjects.authorizationCountryListViewDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "SubmissionType"),
				(ProductsPageObjects.submissionTypeListViewDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ATCCodeTradeName"),
				(ProductsPageObjects.atcCodeTradeNmeListViewTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "SubmissionType"),
				(ProductsPageObjects.submissionTypeListViewDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "DataSheetName"),
				(ProductsPageObjects.dataSheetNameListViewDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "TradeNameRowNo")));
		Constants.highlightObjects = true;

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Trade Names List View : Scenario Name:: " + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Trade Names Details Form View
	 *             in Products Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setTradeNamesDetailsFormView(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.tradeBrandNameFormViewTextBox);
		if (getTestDataCellValue(scenarioName, "boolTradeNameAdd").equalsIgnoreCase("true")) {
			agClick(ProductsPageObjects.tradeNameAddLink);
		}
		agSetValue(ProductsPageObjects.tradeBrandNameFormViewTextBox,
				getTestDataCellValue(scenarioName, "TradeBrandName"));
		CommonOperations.setListDropDownValue(ProductsPageObjects.prodTypeTradeNmeFormViewDropDown,
				getTestDataCellValue(scenarioName, "ProductTypeTradeName"));
		CommonOperations.setListDropDownValue(ProductsPageObjects.submissionTypeFormViewDropDown,
				getTestDataCellValue(scenarioName, "SubmissionType"));
		agSetValue(ProductsPageObjects.atcCodeTradeNmeFormViewTextBox,
				getTestDataCellValue(scenarioName, "ATCCodeTradeName"));
		if (getTestDataCellValue(scenarioName, "boolMarketAuthHolderLookUp").equalsIgnoreCase("true")) {
			// Lookup Method need to be implemented
		} else {
			agSetValue(ProductsPageObjects.marketingAuthHolderFormViewTextBox,
					getTestDataCellValue(scenarioName, "MarketingAuthHolder"));
		}
		if (getTestDataCellValue(scenarioName, "boolAgentDistributorLookUp").equalsIgnoreCase("true")) {
			// Lookup Method need to be implemented
		} else {
			agSetValue(ProductsPageObjects.agentDistributorFormViewTextBox,
					getTestDataCellValue(scenarioName, "AgentDistributor"));
		}
		CommonOperations.setListDropDownValue(ProductsPageObjects.authorizationCountryFormViewDropDown,
				getTestDataCellValue(scenarioName, "AuthorizationCountry"));
		agSetValue(ProductsPageObjects.approvalNoFormViewTextBox, getTestDataCellValue(scenarioName, "ApprovalNo"));
		agSetValue(ProductsPageObjects.codeNameINDFormViewTextBox, getTestDataCellValue(scenarioName, "CodeName"));
		agSetValue(ProductsPageObjects.bioReferenceNameRLDFormViewTextBox,
				getTestDataCellValue(scenarioName, "BioReferenceName(RLD)"));
		agSetValue(ProductsPageObjects.otcFormViewTextBox, getTestDataCellValue(scenarioName, "OTC"));
		CommonOperations.setListDropDownValue(ProductsPageObjects.approvalTypeFormViewDropDown,
				getTestDataCellValue(scenarioName, "ApprovalType"));

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.tradeNames_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Trade Names Form View Section 1 : Scenario Name:: " + scenarioName, true);

		agSetValue(ProductsPageObjects.approvalStartDateFormViewTextBox,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "ApprovalStartDate")));
		agSetValue(ProductsPageObjects.approvalEndDateFormViewTextBox,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "ApprovalEndDate")));
		agClick(CommonPageObjects.applicationLogo);
		agSetValue(ProductsPageObjects.approvalDescriptionFormViewTextArea,
				getTestDataCellValue(scenarioName, "ApprovalDescription"));
		agSetValue(ProductsPageObjects.ndcNoFormViewTextBox, getTestDataCellValue(scenarioName, "NDCNo"));
		agSetValue(ProductsPageObjects.medicinalProductNameFormViewTextBox,
				getTestDataCellValue(scenarioName, "MedicinalProductName"));
		agSetValue(ProductsPageObjects.internalProductIDFormViewTextBox,
				getTestDataCellValue(scenarioName, "InternalProductID"));
		agSetValue(ProductsPageObjects.marketedDateFormViewTextBox, getTestDataCellValue(scenarioName, "MarketedDate"));
		agSetValue(ProductsPageObjects.mpidFormViewTextBox, getTestDataCellValue(scenarioName, "MPID"));
		// agSetValue(ProductsPageObjects.versionDateFormViewTextBox,
		// CommonOperations.returnDateTime(getTestDataCellValue(scenarioName,
		// "VersionDate")));
		agClick(CommonPageObjects.applicationLogo);
		agSetValue(ProductsPageObjects.versionNumberFormViewTextBox,
				getTestDataCellValue(scenarioName, "VersionNumber"));
		CommonOperations.setListDropDownValue(ProductsPageObjects.marketingCategoryFormViewDropDown,
				getTestDataCellValue(scenarioName, "MarketingCategory"));
		CommonOperations.setListDropDownValue(ProductsPageObjects.proprietaryNameSuffixFormViewDropDown,
				getTestDataCellValue(scenarioName, "ProprietaryNameSuffix"));

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.approvalStartDate_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Trade Names Form View Section 2 : Scenario Name:: " + scenarioName, true);

		CommonOperations.clickRadioButton(ProductsPageObjects.marketingStatusFormViewRadio,
				getTestDataCellValue(scenarioName, "MarketingStatus"));
		agSetValue(ProductsPageObjects.containerTypeFormViewTextBox,
				getTestDataCellValue(scenarioName, "ContainerType"));
		CommonOperations.clickRadioButton(ProductsPageObjects.verifiedFormViewRadio,
				getTestDataCellValue(scenarioName, "Verified"));
		agSetValue(ProductsPageObjects.licenseIdFormViewTextBox, getTestDataCellValue(scenarioName, "LicenseId"));
		if (agIsVisible(ProductsPageObjects.licenseStatusFormViewTextBox) == true) {
			agSetValue(ProductsPageObjects.licenseStatusFormViewTextBox,
					getTestDataCellValue(scenarioName, "LicenseStatus"));
		} else {
			CommonOperations.setListDropDownValue(ProductsPageObjects.licenseStatusFormViewDropDown,
					getTestDataCellValue(scenarioName, "LicenseStatus"));
		}
		CommonOperations.setListDropDownValue(ProductsPageObjects.dataSheetNameFormViewDropDown,
				getTestDataCellValue(scenarioName, "DataSheetName"));

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.marketingStatus_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Trade Names Form View Section 3 : Scenario Name:: " + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Trade Names Details Form
	 *             View in Products Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyTradeNamesDetailsFormView(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.tradeBrandNameFormViewTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "TradeBrandName"),
				ProductsPageObjects.tradeBrandNameFormViewTextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ProductTypeTradeName"),
				ProductsPageObjects.prodTypeTradeNmeFormViewDropDown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "SubmissionType"),
				ProductsPageObjects.submissionTypeFormViewDropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ATCCodeTradeName"),
				ProductsPageObjects.atcCodeTradeNmeFormViewTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MarketingAuthHolder"),
				ProductsPageObjects.marketingAuthHolderFormViewTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "AgentDistributor"),
				ProductsPageObjects.agentDistributorFormViewTextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "AuthorizationCountry"),
				ProductsPageObjects.authorizationCountryFormViewDropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ApprovalNo"),
				ProductsPageObjects.approvalNoFormViewTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "CodeName"),
				ProductsPageObjects.codeNameINDFormViewTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "BioReferenceName(RLD)"),
				ProductsPageObjects.bioReferenceNameRLDFormViewTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "OTC"),
				ProductsPageObjects.otcFormViewTextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ApprovalType"),
				ProductsPageObjects.approvalTypeFormViewDropDown);

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.tradeNames_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Trade Names Form View Section 1 : Scenario Name:: " + scenarioName,
				true);

		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "ApprovalStartDate")),
				ProductsPageObjects.approvalStartDateFormViewTextBox);
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "ApprovalEndDate")),
				ProductsPageObjects.approvalEndDateFormViewTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ApprovalDescription"),
				ProductsPageObjects.approvalDescriptionFormViewTextArea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "NDCNo"),
				ProductsPageObjects.ndcNoFormViewTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MedicinalProductName"),
				ProductsPageObjects.medicinalProductNameFormViewTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "InternalProductID"),
				ProductsPageObjects.internalProductIDFormViewTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MarketedDate"),
				ProductsPageObjects.marketedDateFormViewTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MPID"),
				ProductsPageObjects.mpidFormViewTextBox);
		// agCheckPropertyValue("value",
		// CommonOperations.returnDateTime(getTestDataCellValue(scenarioName,
		// "VersionDate")), ProductsPageObjects.versionDateFormViewTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "VersionNumber"),
				ProductsPageObjects.versionNumberFormViewTextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "MarketingCategory"),
				ProductsPageObjects.marketingCategoryFormViewDropDown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ProprietaryNameSuffix"),
				ProductsPageObjects.proprietaryNameSuffixFormViewDropDown);

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.approvalStartDate_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Trade Names Form View Section 2 : Scenario Name:: " + scenarioName,
				true);

		CommonOperations.verifyRadioButton(ProductsPageObjects.marketingStatusFormViewRadio,
				getTestDataCellValue(scenarioName, "MarketingStatus"));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ContainerType"),
				ProductsPageObjects.containerTypeFormViewTextBox);
		CommonOperations.verifyRadioButton(ProductsPageObjects.verifiedFormViewRadio,
				getTestDataCellValue(scenarioName, "Verified"));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "LicenseId"),
				ProductsPageObjects.licenseIdFormViewTextBox);
		if (agIsVisible(ProductsPageObjects.licenseStatusFormViewTextBox) == true) {
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "LicenseStatus"),
					ProductsPageObjects.licenseStatusFormViewTextBox);
		} else {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "LicenseStatus"),
					ProductsPageObjects.licenseStatusFormViewDropDown);
		}
		agCheckPropertyText(getTestDataCellValue(scenarioName, "DataSheetName"),
				ProductsPageObjects.dataSheetNameFormViewDropDown);

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.marketingStatus_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Trade Names Form View Section 3 : Scenario Name:: " + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Lot/BatchInformation Details
	 *             in Products Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setLotBatchInformationDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.lotBatchInformationAddLink);
		if (getTestDataCellValue(scenarioName, "boolLotBatchInfoAdd").equalsIgnoreCase("true")) {
			agClick(ProductsPageObjects.lotBatchInformationAddLink);
		}
		Constants.highlightObjects = false;
		agSetValue(
				(ProductsPageObjects.lotBatchNoTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "LotBatchInfoRowNo")),
				getTestDataCellValue(scenarioName, "LotBatchNo"));
		agSetValue(
				(ProductsPageObjects.manufactureDateTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "LotBatchInfoRowNo")),
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "ManufactureDate")));
		agClick(CommonPageObjects.applicationLogo);
		agSetValue(
				(ProductsPageObjects.expiryDateTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "LotBatchInfoRowNo")),
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "ExpiryDate")));
		agClick(CommonPageObjects.applicationLogo);
		agSetValue(
				(ProductsPageObjects.materialDescriptionTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "LotBatchInfoRowNo")),
				getTestDataCellValue(scenarioName, "MaterialDescription"));
		agSetValue(
				(ProductsPageObjects.manufacturingPlantNameTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "LotBatchInfoRowNo")),
				getTestDataCellValue(scenarioName, "ManufacturingPlantName"));
		agSetValue(
				(ProductsPageObjects.materialTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "LotBatchInfoRowNo")),
				getTestDataCellValue(scenarioName, "Material"));
		agSetValue(
				(ProductsPageObjects.ndcNoTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "LotBatchInfoRowNo")),
				getTestDataCellValue(scenarioName, "NDCNoLotBatchInfo"));
		Constants.highlightObjects = true;

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.lotBatchInformation_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Trade Names >> Lot/Batch Information Section : Scenario Name:: "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Lot/BatchInformation
	 *             Details in Products Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyLotBatchInformationDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.lotBatchInformationAddLink);
		Constants.highlightObjects = false;
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "LotBatchNo"),
				(ProductsPageObjects.lotBatchNoTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "LotBatchInfoRowNo")));
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "ManufactureDate")),
				(ProductsPageObjects.manufactureDateTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "LotBatchInfoRowNo")));
		agCheckPropertyValue("value", CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "ExpiryDate")),
				(ProductsPageObjects.expiryDateTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "LotBatchInfoRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MaterialDescription"),
				(ProductsPageObjects.materialDescriptionTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "LotBatchInfoRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ManufacturingPlantName"),
				(ProductsPageObjects.manufacturingPlantNameTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "LotBatchInfoRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Material"),
				(ProductsPageObjects.materialTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "LotBatchInfoRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "NDCNoLotBatchInfo"),
				(ProductsPageObjects.ndcNoTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "LotBatchInfoRowNo")));
		Constants.highlightObjects = true;

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.lotBatchInformation_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Trade Names >> Lot/Batch Information Section : Scenario Name:: "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Product Category Type or
	 *             Product Attributes Details in Products Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setProductCategoryTypeDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.productCategoryTypeAddLink);
		if (getTestDataCellValue(scenarioName, "boolProdCatTypeAdd").equalsIgnoreCase("true")) {
			agClick(ProductsPageObjects.productCategoryTypeAddLink);
		}
		Constants.highlightObjects = false;
		CommonOperations.setListDropDownValue(
				(ProductsPageObjects.prodCategoryTypeDropDown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "ProdCatTypeRowNo")),
				getTestDataCellValue(scenarioName, "Type"));
		agSetValue(
				(ProductsPageObjects.prodCategoryStartDateTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "ProdCatTypeRowNo")),
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "StartDate")));
		agSetValue(
				(ProductsPageObjects.prodCategoryEndDateTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "ProdCatTypeRowNo")),
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "EndDate")));
		Constants.highlightObjects = true;

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.productAttributes_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Trade Names >> Product Attributes Section : Scenario Name:: "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Product Category Type or
	 *             Product Attributes Details in Products Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyProductCategoryTypeDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.productCategoryTypeAddLink);
		Constants.highlightObjects = false;
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Type"), (ProductsPageObjects.prodCategoryTypeDropDown)
				.replace("%rowNo%", getTestDataCellValue(scenarioName, "ProdCatTypeRowNo")));
		agCheckPropertyValue("value", CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "StartDate")),
				(ProductsPageObjects.prodCategoryStartDateTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "ProdCatTypeRowNo")));
		agCheckPropertyValue("value", CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "EndDate")),
				(ProductsPageObjects.prodCategoryEndDateTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "ProdCatTypeRowNo")));
		agClick(CommonPageObjects.applicationLogo);
		Constants.highlightObjects = true;

		agJavaScriptExecuctorScrollToElement(ProductsPageObjects.productAttributes_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Trade Names >> Product Attributes Section : Scenario Name:: "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Synonyms Details in Products
	 *             Synonyms Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSynonymsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.synonymsAddLink);
		if (getTestDataCellValue(scenarioName, "boolSynonymsAdd").equalsIgnoreCase("true")) {
			agClick(ProductsPageObjects.synonymsAddLink);
		}
		Constants.highlightObjects = false;
		agSetValue(
				(ProductsPageObjects.synonymsTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "SynonymsRowNo")),
				getTestDataCellValue(scenarioName, "Synonyms"));
		Constants.highlightObjects = true;

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> Synonyms Tab : Scenario Name:: " + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Synonyms Details in
	 *             Products Synonyms Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySynonymsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.synonymsAddLink);
		Constants.highlightObjects = false;
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Synonyms"),
				(ProductsPageObjects.synonymsTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "SynonymsRowNo")));
		Constants.highlightObjects = true;

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> Synonyms Tab : Scenario Name:: " + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set AE's of Special Interest
	 *             Details in Products AE's of Special Interest Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setAEofSpecialInterestDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.aeOfSpecialInterestAddLink);
		if (getTestDataCellValue(scenarioName, "boolAEofSpecialInterestAdd").equalsIgnoreCase("true")) {
			agClick(ProductsPageObjects.aeOfSpecialInterestAddLink);
		}
		Constants.highlightObjects = false;
		if (getTestDataCellValue(scenarioName, "boolAEofSpecialIntPTtermLookUp").equalsIgnoreCase("true")) {
			agClick((ProductsPageObjects.aeOfSpecialInterestMedraLookup).replace("%rowNo%",
					getTestDataCellValue(scenarioName, "AEofSpecialIntRowNo")));
			CommonOperations.setDictionaryCodingBrowserDetails(
					getTestDataCellValue(scenarioName, "AEofSpecialIntPTTerm"),
					getTestDataCellValue(scenarioName, "labelingTerms_Level"));
		} else {
			agSetValue(
					(ProductsPageObjects.aeOfSpecialInterestPTTermTextBox).replace("%rowNo%",
							getTestDataCellValue(scenarioName, "AEofSpecialIntRowNo")),
					getTestDataCellValue(scenarioName, "AEofSpecialIntPTTerm"));
			agClick((ProductsPageObjects.aeOfSpecialInterestPTTermSuggestion).replace("$term$",
					getTestDataCellValue(scenarioName, "AEofSpecialIntPTTerm")));
		}
		agSetValue(
				(ProductsPageObjects.aeOfSpecialInterestPTCodeTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "AEofSpecialIntRowNo")),
				getTestDataCellValue(scenarioName, "AEofSpecialIntPTCode"));
		agSetValue(
				(ProductsPageObjects.aeOfSpecialInterestLLTTermTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "AEofSpecialIntRowNo")),
				getTestDataCellValue(scenarioName, "AEofSpecialIntLLTTerm"));
		agSetValue(
				(ProductsPageObjects.aeOfSpecialInterestLLTCodeTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "AEofSpecialIntRowNo")),
				getTestDataCellValue(scenarioName, "AEofSpecialIntLLTCode"));
		agSetValue(
				(ProductsPageObjects.aeOfSpecialInterestSOCNameTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "AEofSpecialIntRowNo")),
				getTestDataCellValue(scenarioName, "AEofSpecialIntSOCName"));
		agSetValue(
				(ProductsPageObjects.aeOfSpecialInterestMedraVersionTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "AEofSpecialIntRowNo")),
				getTestDataCellValue(scenarioName, "AEofSpecialIntMedDRaVersion"));
		Constants.highlightObjects = true;

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Products >> AE's of Special Interest Tab : Scenario Name:: " + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify AE's of Special Interest
	 *             Details in Products AE's of Special Interest Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyAEofSpecialInterestDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.aeOfSpecialInterestAddLink);

		Constants.highlightObjects = false;
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "AEofSpecialIntPTTerm"),
				(ProductsPageObjects.aeOfSpecialInterestPTTermTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "AEofSpecialIntRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "AEofSpecialIntPTCode"),
				(ProductsPageObjects.aeOfSpecialInterestPTCodeTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "AEofSpecialIntRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "AEofSpecialIntLLTTerm"),
				(ProductsPageObjects.aeOfSpecialInterestLLTTermTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "AEofSpecialIntRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "AEofSpecialIntLLTCode"),
				(ProductsPageObjects.aeOfSpecialInterestLLTCodeTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "AEofSpecialIntRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "AEofSpecialIntSOCName"),
				(ProductsPageObjects.aeOfSpecialInterestSOCNameTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "AEofSpecialIntRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "AEofSpecialIntMedDRaVersion"),
				(ProductsPageObjects.aeOfSpecialInterestMedraVersionTextBox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "AEofSpecialIntRowNo")));
		Constants.highlightObjects = true;

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Products >> AE's of Special Interest Tab : Scenario Name:: " + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete Products.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 15-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndDeleteProducts(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		boolean searchResults = searchProduct(scenarioName);
		if (searchResults) {
			agClick(CommonPageObjects.selectListingCheckbox(getTestDataCellValue(scenarioName, "SearchText")));
			agClick(ProductsPageObjects.deleteButton);
			CommonOperations.setDeleteAuditInfo("Delete_Product");
		}
		boolean deleteSearchResults = searchProduct(scenarioName);
		if (deleteSearchResults) {
			Reports.ExtentReportLog("", Status.FAIL,
					"Product : " + getTestDataCellValue(scenarioName, "SearchText") + " is not deleted", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS,
					"Product : " + getTestDataCellValue(scenarioName, "SearchText") + " is deleted", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Product Substances Details in
	 *             Substances List or Form View
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSubstancesDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		switch (getTestDataCellValue(scenarioName, "SubstancesView")) {
		case "ListView":
			selectSubstancesDetailsFromLookUp(scenarioName);
			break;
		case "FormView":
			selectSubstancesDetailsFromLookUp(scenarioName);
			agJavaScriptExecuctorClick((CommonPageObjects.toggleViewButton("Substances", "Form View")));
			setSubstancesDetailsFormView(scenarioName);
			setSubstanceSynonymsDetails(scenarioName);
			break;
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Product Substances Details
	 *             in Substances List or Form View
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySubstancesDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		switch (getTestDataCellValue(scenarioName, "SubstancesView")) {
		case "ListView":
			verifySubstancesDetailsListView(scenarioName);
			break;
		case "FormView":
			agJavaScriptExecuctorClick((CommonPageObjects.toggleViewButton("Substances", "Form View")));
			verifySubstancesDetailsFormView(scenarioName);
			verifySubstanceSynonymsDetails(scenarioName);
			break;
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Trade Name in List or Form
	 *             View
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setTradeNameDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		productsNavigations("tradeNames");
		switch (getTestDataCellValue(scenarioName, "TradeNameView")) {
		case "ListView":
			setTradeNamesDetailsListView(scenarioName);
			break;
		case "FormView":
			agJavaScriptExecuctorClick((CommonPageObjects.toggleViewButton("Trade Names", "Form View")));
			setTradeNamesDetailsFormView(scenarioName);
			// setLotBatchInformationDetails(scenarioName);
			// setProductCategoryTypeDetails(scenarioName);
			break;
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Trade Name in List or Form
	 *             View
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyTradeNameDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		productsNavigations("tradeNames");
		switch (getTestDataCellValue(scenarioName, "TradeNameView")) {
		case "ListView":
			verifyTradeNamesDetailsListView(scenarioName);
			break;
		case "FormView":
			agJavaScriptExecuctorClick((CommonPageObjects.toggleViewButton("Trade Names", "Form View")));
			verifyTradeNamesDetailsFormView(scenarioName);
			// verifyLotBatchInformationDetails(scenarioName);
			// verifyProductCategoryTypeDetails(scenarioName);
			// agJavaScriptExecuctorClick((CommonPageObjects.toggleViewButton("Trade Names",
			// "List View")));//Work Arround
			break;
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create new product
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createProduct(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (scenarioName.contains("SMV_OQ_AutoLabellingFunctionality")) {

		} else {
			agClick(ProductsPageObjects.productNewButton);
		}
		setBasicDetails(scenarioName);
		setBasicOtherDetails(scenarioName);
		setStrengthDetails(scenarioName);
		setSubstancesDetails(scenarioName);
		setAdditionalDetails(scenarioName);
		setTherapeuticAreaDetailsFromLookUp(scenarioName);
		setIndicationsDetails(scenarioName);
		setProductCharacteristicsDetails(scenarioName);

		if (getTestDataCellValue(scenarioName, "boolTradeNameData").equalsIgnoreCase("true")) {
			productsNavigations("tradeNames");
			setTradeNameDetails(scenarioName);
		}
		if (getTestDataCellValue(scenarioName, "boolSynonymsData").equalsIgnoreCase("true")) {
			productsNavigations("synonyms");
			setSynonymsDetails(scenarioName);
		}
		if (getTestDataCellValue(scenarioName, "boolAEofSpecialIntData").equalsIgnoreCase("true")) {
			productsNavigations("AE'sOfSpecialInterest");
			// setAEofSpecialInterestDetails(scenarioName);
		}

		if (getTestDataCellValue(scenarioName, "boolLabelingAdd").equalsIgnoreCase("true")) {
			productsNavigations("labeling");
			setLabelingDetails(scenarioName);
		}

		agClick(ProductsPageObjects.saveButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Product Details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyProductDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		searchProduct(scenarioName);
		editProduct();
		verifyBasicDetails(scenarioName);
		verifyBasicOtherDetails(scenarioName);
		verifyStrengthDetails(scenarioName);
		verifySubstancesDetails(scenarioName);
		verifyAdditionalDetails(scenarioName);
		setTherapeuticAreaDetailsListView(scenarioName);
		verifyIndicationsDetails(scenarioName);
		verifyProductCharacteristicsDetails(scenarioName);

		if (getTestDataCellValue(scenarioName, "boolTradeNameData").equalsIgnoreCase("true")) {
			productsNavigations("tradeNames");
			verifyTradeNameDetails(scenarioName);
		}
		if (getTestDataCellValue(scenarioName, "boolSynonymsData").equalsIgnoreCase("true")) {
			productsNavigations("synonyms");
			verifySynonymsDetails(scenarioName);
		}
		if (getTestDataCellValue(scenarioName, "boolAEofSpecialIntData").equalsIgnoreCase("true")) {
			productsNavigations("AE'sOfSpecialInterest");
			// verifyAEofSpecialInterestDetails(scenarioName);
		}
		// if(getTestDataCellValue(scenarioName,
		// "boolLabelingAdd").equalsIgnoreCase("true")) {
		// productsNavigations("labeling");
		// verifyLabelingDetails(scenarioName);
		// }
		agClick(ProductsPageObjects.cancelButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to update existing product
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateProduct(String scenarioName) {
		searchProduct(scenarioName);
		editProduct();
		setBasicDetails(scenarioName);
		setBasicOtherDetails(scenarioName);
		setStrengthDetails(scenarioName);
		setAdditionalDetails(scenarioName);
		setSubstancesDetails(scenarioName);
		setTherapeuticAreaDetailsFromLookUp(scenarioName);
		setIndicationsDetails(scenarioName);
		setProductCharacteristicsDetails(scenarioName);

		if (getTestDataCellValue(scenarioName, "boolTradeNameData").equalsIgnoreCase("true")) {
			productsNavigations("tradeNames");
			setTradeNameDetails(scenarioName);
		}
		if (getTestDataCellValue(scenarioName, "boolSynonymsData").equalsIgnoreCase("true")) {
			productsNavigations("synonyms");
			setSynonymsDetails(scenarioName);
		}
		if (getTestDataCellValue(scenarioName, "boolAEofSpecialIntData").equalsIgnoreCase("true")) {
			productsNavigations("AE'sOfSpecialInterest");
			setAEofSpecialInterestDetails(scenarioName);
		}
		if (getTestDataCellValue(scenarioName, "boolLabelingAdd").equalsIgnoreCase("true")) {
			productsNavigations("labeling");
			setLabelingDetails(scenarioName);
		}
		agClick(ProductsPageObjects.saveButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Labeling Details in Products
	 *             Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 08-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setLabelingDetails(String scenarioName) {
		setLabelingDatasheet(scenarioName);
		setLabelingTerms(scenarioName);
		setLabelingAdditionalAttributes(scenarioName);
		setLabelingIndications(scenarioName);
		if (getTestDataCellValue(scenarioName, "boolSelectedCountriesAdd").equalsIgnoreCase("true")) {
			productsNavigations("SelectedCountries");
			selectLabelingSelectedCountries(scenarioName);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Labeling Details in
	 *             Products Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 13-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyLabelingDetails(String scenarioName) {
		verifyLabelingDatasheet(scenarioName);
		verifyLabelingTerms(scenarioName);
		verifyLabelingAdditionalAttributes(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify Data sheet Details in
	 *             Products -> Labeling Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 09-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyLabelingDatasheet(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "labelingDataSheetName"),
				(ProductsPageObjects.labelingDataSheetNameTextBox));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "labelingCountry"),
				ProductsPageObjects.labelingCountryGetvalue);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "labelingDocumentNumberIncludingVersion"),
				(ProductsPageObjects.labelingDocumentNumberIncludingVersionTextBox));
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "labelingEfflabeling")),
				ProductsPageObjects.labelingEfflabelingDate);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Data sheet Details in Products
	 *             -> Labeling Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 08-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setLabelingDatasheet(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.agwaitTillVisible(ProductsPageObjects.labelingDocumentNumberIncludingVersionTextBox, 3, 1000);
		if (getTestDataCellValue(scenarioName, "boolLabelingAdd").equalsIgnoreCase("true")) {
			agClick(ProductsPageObjects.labelingAddLink);
		}
		agWaitTillVisibilityOfElement(ProductsPageObjects.labelingDataSheetNameTextBox);
		agSetStepExecutionDelay("5000");
		agSetValue(ProductsPageObjects.labelingDataSheetNameTextBox,
				getTestDataCellValue(scenarioName, "labelingDataSheetName"));
		CommonOperations.setListDropDownValue(ProductsPageObjects.labelingCountryDropDown,
				getTestDataCellValue(scenarioName, "labelingCountry"));
		agSetValue(ProductsPageObjects.labelingDocumentNumberIncludingVersionTextBox,
				getTestDataCellValue(scenarioName, "labelingDocumentNumberIncludingVersion"));
		agSetValue(ProductsPageObjects.labelingEfflabelingDate,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "labelingEfflabeling")));
		CommonOperations.captureScreenShot(true);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Product >> Labelling >> LabelingDatasheet Section : Scenario Name:: " + scenarioName,
				false);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Labeling Terms Details in
	 *             Products -> Labeling Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 08-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setLabelingTerms(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "labelingSMQCMQ").equalsIgnoreCase("True")) {
			setLabelingTerms_SMQ_CMQ(scenarioName);
		} else {
			String level = getTestDataCellValue(scenarioName, "labelingTerms_Level");
			String[] levelRecords = level.split(",");
			String subName = getTestDataCellValue(scenarioName, "labelingTermsPTTerm");
			String[] totalRecords = subName.split(",");
			String fatalEvent = getTestDataCellValue(scenarioName, "labelingTermsIncludeFatalEvent");
			String[] totalfatalEventRecords = fatalEvent.split(",");
			String conditionalLabeling = getTestDataCellValue(scenarioName, "labelingTermsConditionalLabeling");
			String[] totalconditionalLabeling = conditionalLabeling.split(",");
			for (int i = 0; i < totalRecords.length; i++) {
				agJavaScriptExecuctorClick(ProductsPageObjects.labelingTermsAddLink);
				CommonOperations.agwaitTillVisible(ProductsPageObjects.labelingTermsPTCodeTextBox, 2, 1000);
				agWaitTillVisibilityOfElement(ProductsPageObjects.labelingTermPopUpHeader);
				agClick(ProductsPageObjects.labelingTermsPTTermLookup);
				CommonOperations.setDictionaryCodingBrowserDetails(totalRecords[i], levelRecords[i]);
				for (int j = i; j <= i; j++) {
					CommonOperations.clickCheckBoxUnder(ProductsPageObjects.labelingTermsIncludeFatalEventCheckbox,
							totalfatalEventRecords[j]);
					CommonOperations.clickCheckBoxUnder(ProductsPageObjects.labelingTermsConditionalLabelingCheckbox,
							totalconditionalLabeling[j]); // add by avinash
					agSetValue(ProductsPageObjects.labelingTermsConditionaLabelingCommentsTextBox,
							getTestDataCellValue(scenarioName, "labelingTermsConditionaLabelingComments"));
				}
				agClick(ProductsPageObjects.labelingTermsOKButton);
				agWaitTillInvisibilityOfElement(ProductsPageObjects.labelingTermsOKButton);

			}

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Labeling Terms SMQ and CMQ
	 *             Details in Products -> Labeling Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Avinash k
	 * @Date : 12-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setLabelingTerms_SMQ_CMQ(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "labelingSMQorCMQFlag").equalsIgnoreCase("YES")) {

			String subName = getTestDataCellValue(scenarioName, "labelingSMQorCMQ");

			String[] totalRecords = subName.split(",");
			String smqcmqName = getTestDataCellValue(scenarioName, "labelingSMQorCMQNames");
			String[] smqcmqNametRecords = smqcmqName.split(",");
			for (int i = 0; i < totalRecords.length; i++) {
				agClick(ProductsPageObjects.labelingTermsAddLink);
				agWaitTillVisibilityOfElement(ProductsPageObjects.sMQCMQCodeLookup);
				agClick(ProductsPageObjects.sMQCMQCodeLookup);
				agWaitTillVisibilityOfElement(DictionaryCodingBrowser_LookupPageObjects.sMQ_CMQName_Textbox);
				agClick(DictionaryCodingBrowser_LookupPageObjects.sMQCMQRadio_Button(totalRecords[i]));
				CommonOperations.set_SMQ_CMQ_DictionaryCodingBrowser(smqcmqNametRecords[i]);
				agClick(ProductsPageObjects.labelingTermsOKButton);
				agWaitTillInvisibilityOfElement(ProductsPageObjects.labelingTermsOKButton);

			}
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Product >> Labelling >> LabelingTerms Section : Scenario Name:: " + scenarioName,
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify Labeling Terms Details in
	 *             Products -> Labeling Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 13-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyLabelingTerms(String scenarioName) {
		agCheckPropertyText(getTestDataCellValue(scenarioName, "labelingTermsPTTerm"),
				(ProductsPageObjects.labelingTermsPTTermGetvalue));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "labelingTermsPTCode"),
				(ProductsPageObjects.labelingTermsPTCodeGetvalue));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "labelingTermsLLTTerm"),
				(ProductsPageObjects.labelingTermsLLTTermGetvalue));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "labelingTermsLLTCode"),
				(ProductsPageObjects.labelingTermsLLTCodeGetvalue));
		// agCheckPropertyText(getTestDataCellValue(scenarioName,
		// "labelingTermsConditionalLabeling"),(ProductsPageObjects.labelingTermsConditionalLabelingGetvalue));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "labelingTermsLabeled"),
				(ProductsPageObjects.labelingTermsLabeledGetvalue));
		// agCheckPropertyText(getTestDataCellValue(scenarioName,
		// "labelingTermsIncludeFatalEvent"),(ProductsPageObjects.labelingTermsIncludeFatalEventGetvalue));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Additional Attributes Details
	 *             in Products -> Labeling Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 08-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setLabelingAdditionalAttributes(String scenarioName) {
		CommonOperations.setListDropDownValue(ProductsPageObjects.labelingAddAttrRouteOfAdminDropDown,
				getTestDataCellValue(scenarioName, "labelingAddAttrRouteOfAdmin"));
		CommonOperations.setListDropDownValue(ProductsPageObjects.labelingAddAttrFormOfAdminDropDown,
				getTestDataCellValue(scenarioName, "labelingAddAttrFormOfAdmin"));
		if (getTestDataCellValue(scenarioName, "boollabelingProtocolNoLookup").equalsIgnoreCase("true")) {
			agClick(ProductsPageObjects.labelingProtocolNoLookup);
			agSetValue(ProductsPageObjects.labelingStudyLookupProjectNoTextBox,
					getTestDataCellValue(scenarioName, "labelingStudyLookupProjectNo"));
			agSetValue(ProductsPageObjects.labelingStudyLookupStudyNoTextBox,
					getTestDataCellValue(scenarioName, "labelingStudyLookupStudyNo"));
			agClick(ProductsPageObjects.labelingStudyLookupSearchButton);
			agClick(ProductsPageObjects.labelingStudyLookupSearchSelectButton);
			// CommonOperations.takeScreenShot();
			agClick(ProductsPageObjects.labelingStudyLookupOkButton);
		} else {
			agSetValue(ProductsPageObjects.labelingProtocolNoTextbox,
					getTestDataCellValue(scenarioName, "labelingProtocolNo"));
		}
		agSetValue(ProductsPageObjects.labelingStudyLookupLabelingReferenceTextBox,
				getTestDataCellValue(scenarioName, "labelingStudyLookupLabelingReference"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Product >> Labelling >> AdditionalAttributes Section : Scenario Name:: "
						+ scenarioName,
				false);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify Additional Attributes
	 *             Details in Products -> Labeling Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 13-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyLabelingAdditionalAttributes(String scenarioName) {
		agCheckPropertyText(getTestDataCellValue(scenarioName, "labelingAddAttrRouteOfAdmin"),
				ProductsPageObjects.labelingAddAttrRouteOfAdminGetvalue);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "labelingAddAttrFormOfAdmin"),
				ProductsPageObjects.labelingAddAttrFormOfAdminGetvalue);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "labelingProtocolNo"),
				(ProductsPageObjects.labelingProtocolNoTextbox));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "labelingStudyLookupLabelingReference"),
				(ProductsPageObjects.labelingStudyLookupLabelingReferenceTextBox));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Protocol no lookup Details in
	 *             Additional Attributes -> Products -> Labeling Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 08-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setLabelingStudyLookup(String scenarioName) {
		agSetValue(ProductsPageObjects.labelingStudyLookupProjectNoTextBox,
				getTestDataCellValue(scenarioName, "labelingStudyLookupProjectNo"));
		agSetValue(ProductsPageObjects.labelingStudyLookupStudyNoTextBox,
				getTestDataCellValue(scenarioName, "labelingStudyLookupStudyNo"));
		agClick(ProductsPageObjects.labelingStudyLookupSearchButton);
		agClick(ProductsPageObjects.labelingStudyLookupSearchSelectButton);
		CommonOperations.takeScreenShot();
		agClick(ProductsPageObjects.labelingStudyLookupOkButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Indication Details in
	 *             Additional Attributes -> Products -> Labeling Trade Names Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 08-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setLabelingIndications(String scenarioName) {
		if (getTestDataCellValue(scenarioName, "boollabelingIndicationAddIndication").equalsIgnoreCase("true")) {
			agClick(ProductsPageObjects.labelingIndicationAddIndicationLink);
			CommonOperations.setDictionaryCodingBrowserDetails(
					getTestDataCellValue(scenarioName, "labelingIndicationAddIndication"),
					getTestDataCellValue(scenarioName, "LabelingIndication_Level"));
			CommonOperations.takeScreenShot();

			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Product >> Labelling >> Indications Section : Scenario Name:: " + scenarioName,
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Country from countries
	 *             search criteria in selected countries link
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 14-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void selectLabelingSelectedCountries(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(ProductsPageObjects.selectedCountriesAddLink);
		String subName = getTestDataCellValue(scenarioName, "SelectedCountriesCountryName");
		String[] totalRecords = subName.split(",");
		for (int i = 0; i < totalRecords.length; i++) {
			agClick(ProductsPageObjects.selectedCountriesAddLink);
			agAssertVisible(ProductsPageObjects.selectedCountriesCountryNameTextbox);
			agSetValue(ProductsPageObjects.selectedCountriesCountryNameTextbox, totalRecords[i]);
			agClick(ProductsPageObjects.selectedCountriesSearchButton);
			agAssertVisible(ProductsPageObjects.countriesSearchCriteria(totalRecords[i]));
			agClick(ProductsPageObjects.countriesSearchCriteriaCheckBox(totalRecords[i]));
			CommonOperations.takeScreenShot();
			agClick(ProductsPageObjects.selectedCountriesOkButton);
			agWaitTillInvisibilityOfElement(ProductsPageObjects.selectedCountriesOkButton);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add product labelling for DSUR
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addProductLabellingForDSUR(String scenarioName) {
		ProductsOperations.productsNavigations("productsListing");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		searchTheProduct(scenarioName);
		CommonOperations.captureScreenShot(true);
		editProduct();
		agClick(ProductsPageObjects.productLabelingTab);
		// productsNavigations("labeling");
		setLabelingDatasheet(scenarioName);
		setLabelingTerms(scenarioName);
		if (getTestDataCellValue(scenarioName, "LabelingTermFlag").equalsIgnoreCase("YES")) {
			setLabelingTerms(scenarioName);
		}
		// setLabelingTerms_SMQ_CMQ(scenarioName);
		setLabelingAdditionalAttributes(scenarioName);
		agIsVisible(ProductsPageObjects.saveButton);
		agJavaScriptExecuctorClick(ProductsPageObjects.saveButton);
		agSetStepExecutionDelay("5000");
		agIsVisible(ProductsPageObjects.saveConfirmationPopup);
		agIsVisible(ProductsPageObjects.ConfirmationOkBtn);
		CommonOperations.captureScreenShot(true);
		agClick(ProductsPageObjects.ConfirmationOkBtn);
		agSetStepExecutionDelay("5000");
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete product labelling for DSUR
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void removeLabellingForDSUR(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		searchTheProduct(scenarioName);
		editProduct();
		productsNavigations("labeling");
		agClick(ProductsPageObjects.labelingSheet(getTestDataCellValue(scenarioName, "labelingDataSheetName")));
		agClick(ProductsPageObjects.deleteLabellingDatasheet);
		agIsVisible(ProductsPageObjects.deleteLabellingConfirmationPopUP);
		agClick(ProductsPageObjects.YesBtn);
		// status = agIsVisible(
		// ProductsPageObjects.labelingSheet(getTestDataCellValue(scenarioName,
		// "labelingDataSheetName")));
		// if (status) {
		// Reports.ExtentReportLog("", Status.FAIL, "Labelled not deleted successfully",
		// true);
		// } else {
		// Reports.ExtentReportLog("", Status.PASS, "Labelled deleted successfully",
		// true);
		// }
		agIsVisible(ProductsPageObjects.saveButton);
		agJavaScriptExecuctorClick(ProductsPageObjects.saveButton);
		CommonOperations.agwaitTillVisible(ProductsPageObjects.saveConfirmationPopup, 2, 1000);
		agIsVisible(ProductsPageObjects.ConfirmationOkBtn);
		agClick(ProductsPageObjects.ConfirmationOkBtn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create new product for OQ
	 *             Scenarios
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 04-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createProductOQ(String scenarioName, String auditScenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(ProductsPageObjects.productNewButton);
		setBasicDetails(scenarioName);
		setIndicationsDetails(scenarioName);
		if (getTestDataCellValue(scenarioName, "boolTradeNameData").equalsIgnoreCase("true")) {
			setTradeNameDetails(scenarioName);
			setLabelingAdditionalAttributes(scenarioName);
		}
		agClick(ProductsPageObjects.saveButton);
		agSetStepExecutionDelay("2000");
		if (agIsVisible(ReportsPageObjects.auditInfo_Label) == true) {
			ReportsOperations.handelAuditInfo(auditScenarioName);
		}
		agWaitTillVisibilityOfElement(ReportsPageObjects.productInfoMsg);
		agClick(ReportsPageObjects.prodOKbtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit and update product for OQ
	 *             Scenarios
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :07-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void EditandUpdate() {

		agClick(ProductsPageObjects.edit_Icon);
		agAssertVisible(ProductsPageObjects.productIDTextBox);
		String ProductName = "ABC" + new Random().nextInt(100);
		agJavaScriptExecuctorSendKeys(ProductsPageObjects.preferredProductDescTextBox, ProductName);
		agClick(ProductsPageObjects.saveButton);
		agWaitTillVisibilityOfElement(CommonPageObjects.validaionOk_Btn);
		CommonOperations.agClick(CommonPageObjects.validaionOk_Btn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify the Audit trail for changes
	 *             made.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :07-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void GenerateAuditTrailReportData() {
		try {
			agSetStepExecutionDelay("3000");
			CommonOperations.setListDropDownValue(ReportsPageObjects.messageTypeSelect, "Product");

			agClick(ReportsPageObjects.operationType);
			agClick(ReportsPageObjects.operationTypeDropdown("Insert"));

			Reports.ExtentReportLog("", Status.PASS, "As Expected"+
					"<br />"+ "Message Type: Product" + 
					"<br />"+ "Operation Type: Insert",
					true);

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, " Verify the Audit trail for changes made Fails", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify the Audit trail for changes
	 *             made.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :07-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void GenerateAuditTrailReportandVerifyProductDetails() {
		try {

			agClick(ReportsPageObjects.auditTrialGenerateReportButton);

			if (agIsVisible(ReportsPageObjects.Insert) == true) {
				String IS_LABELED = agGetText(ReportsPageObjects.InsertOpeartionType(ReportsPageObjects.IS_LABELED));
				String LABELLED_COUNTRY = agGetText(
						ReportsPageObjects.InsertOpeartionType(ReportsPageObjects.LABELLED_COUNTRY));
				String STRENGTH = agGetText(ReportsPageObjects.InsertOpeartionType(ReportsPageObjects.STRENGTH));
				String STRENGTH_UNIT = agGetText(
						ReportsPageObjects.InsertOpeartionType(ReportsPageObjects.STRENGTH_UNIT));
				String AUTO_LABELLING_ACTIVE = agGetText(
						ReportsPageObjects.InsertOpeartionType(ReportsPageObjects.AUTO_LABELLING_ACTIVE));
				String PRODUCT_ACTIVE = agGetText(
						ReportsPageObjects.InsertOpeartionType(ReportsPageObjects.PRODUCT_ACTIVE));
				String LLT_CODE = agGetText(ReportsPageObjects.InsertOpeartionType(ReportsPageObjects.LLT_CODE));

				if (IS_LABELED.equalsIgnoreCase("1") && LABELLED_COUNTRY.equalsIgnoreCase("CU")
						&& STRENGTH.equalsIgnoreCase("12") && STRENGTH_UNIT.equalsIgnoreCase("15")
						&& AUTO_LABELLING_ACTIVE.equalsIgnoreCase("1") && PRODUCT_ACTIVE.equalsIgnoreCase("1")
						&& LLT_CODE.equalsIgnoreCase("10007050")) {
					agJavaScriptExecuctorScrollToElement(
							ReportsPageObjects.InsertOpeartionType(ReportsPageObjects.AUTO_LABELLING_ACTIVE));
					CommonOperations.captureScreenShot(true);
					agJavaScriptExecuctorScrollToElement(
							ReportsPageObjects.InsertOpeartionType(ReportsPageObjects.STRENGTH_UNIT));
					CommonOperations.captureScreenShot(true);
					agJavaScriptExecuctorScrollToElement(
							ReportsPageObjects.InsertOpeartionType(ReportsPageObjects.PRODUCT_ACTIVE));
					CommonOperations.captureScreenShot(true);
					agJavaScriptExecuctorScrollToElement(
							ReportsPageObjects.InsertOpeartionType(ReportsPageObjects.LABELLED_COUNTRY));
					CommonOperations.captureScreenShot(true);

					Reports.ExtentReportLog("", Status.PASS,
							"<br />"+"As Expected"+
					"<br />"+"Product:ABC", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL,
							"Product details of product <ABC> is captured in audit trial not Inserted Successfully",
							true);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, " Verify the Audit trail for changes made Fails", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify the Audit trail for changes
	 *             made.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :07-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void GenerateAdminAuditTrail() {
		try {
			agSetStepExecutionDelay("3000");
			agClick(ReportsPageObjects.SectionType);
			agClick(ReportsPageObjects.SectionTypeDropDown("Application Parameters"));

			agClick(ReportsPageObjects.auditTrialGenerateReportButton);
			Reports.ExtentReportLog("", Status.PASS,
					"As Expected"+
					"<br />"+ "Section: Application Parameters <br/>", true);

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, " Verify the Audit trail for changes made Fails", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify the Audit trail for changes
	 *             made.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :07-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void GenerateAdminAuditTrailReportandVerifyProductDetails() {
		try {

			if (agIsVisible(ReportsPageObjects.UpdatedValue) == true) {

				Reports.ExtentReportLog("", Status.PASS,
						"As Expected",
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"In audit trial report updation of 'Default Labeling for Datasheet' parameter is captured. not Updated Successfully",
						true);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, " Verify the Audit trail for changes made Fails", true);
		}

	}

	public static void createNewOQProduct(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(ProductsPageObjects.BasicDetails);
		agSetStepExecutionDelay("3000");
		agJavaScriptExecuctorSendKeys(ProductsPageObjects.preferredProductDescTextBox,
				getTestDataCellValue(scenarioName, "PreferredProductDescription"));
		ProductsOperations.productsNavigations("labeling");
		setLabelingDatasheet(scenarioName);
		setLabelingTerms(scenarioName);
		agJavaScriptExecuctorSendKeys(ProductsPageObjects.StrengthNumber, "12");
		CommonOperations.setListDropDownValue(ProductsPageObjects.StrengthDD, "Dram");
		Reports.ExtentReportLog("", Status.PASS, "As Expected"+
				"<br />"+"STRENGTH(NUMBER): 12 "+
				"<br />"+"STRENGTH UNIT: Dram "+
				"<br />"+"Labelling Term: Cancer "+
				"<br />"+"Labeled: Yes "+
				"<br />"+"Country: CUBA "+
				"<br />"+"Enable Auto-labeling: Checked"+
				"<br />"+"Active: Checked"+
				"<br />"+"Product :ABC", true);
		agClick(ProductsPageObjects.saveButton);
	}

	public static void createNewProduct(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(ProductsPageObjects.productNewButton);
		setBasicDetails(scenarioName);
		agClick(ProductsPageObjects.saveButton);
		agSetStepExecutionDelay("5000");
		agIsVisible(ProductsPageObjects.saveConfirmationPopup);
		agIsVisible(ProductsPageObjects.ConfirmationOkBtn);
		CommonOperations.captureScreenShot(true);
		agClick(ProductsPageObjects.ConfirmationOkBtn);
		agSetStepExecutionDelay("5000");
	}

}
