package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1.FDE_General;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.DataAssessmentPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_CaseDocumentsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_CaseDocumentsOperations extends ToolManager {
	public static WebElement webElement;
	static String className = FDE_CaseDocumentsOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below Method is verify Source Documents in FDE form
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 16-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void sourceDocumentsVerification() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		FDE_Operations.FDE_Navigations("Case Documents");
		agSetStepExecutionDelay("5000");
		status = agIsExists(FDE_CaseDocumentsPageObjects.fileName_Link);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Source document is displayed", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Source document is not displayed", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// agCheckPropertyText(getTestDataCellValue(scenarioName, "Filename"),
		// FDE_CaseDocumentsPageObjects.fileName_SourceDoc(index));

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is verify support Documents in FDE form
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 16-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void supportDocumentsVerification(String scenarioName, String index) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyText(E2BMessageQueueOperations.getData(scenarioName, "ReceiptNo") + "_Summary Document.pdf",
				FDE_CaseDocumentsPageObjects.supportDocs_DocVer(index));

	}

	// public static void otherVersionVerification(String scenarioName, String
	// index) {
	// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
	// agJavaScriptExecuctorScrollToElement(FDE_CaseDocumentsPageObjects.supportDocs_label);
	// agCheckPropertyText(E2BMessageQueueOperations.getData(scenarioName,
	// "ReceiptNo") + "_Summary Document.pdf",
	// FDE_CaseDocumentsPageObjects.supportDocs_DocVer(index));
	// CommonOperations.takeScreenShot();
	// }

	/**********************************************************************************************************
	 * @Objective: The below Method is create to Add Source Documents in in Case
	 *             Documents Section.
	 * @InputParameters: scenarioName, index
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 18-Feb-2020
	 * @UpdatedByAndWhen:WajahatUmar S on 11-Dec-2020
	 **********************************************************************************************************/

	public static void addSourceDocuments(String scenarioName, String index) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			String fileName = Multimaplibraries.getTestDataCellValue(scenarioName, "Filename");
			CommonOperations.captureScreenShot(true);
			// FDE_Operations.FDE_Navigations("Case Documents");

			if (getTestDataCellValue(scenarioName, "AddSourceDocuments").equals("true")) {
				agSetStepExecutionDelay("5000");
				agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.sourceDocuments_AddButton);
				agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_DocDesc(index),
						getTestDataCellValue(scenarioName, "SourceDocs_DocDescription"));
				agSetStepExecutionDelay("4000");
				if (index.equalsIgnoreCase("3")) {

					agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile("1"),
							lsmvConstants.LSMV_testDataInput + "\\" + fileName);
				} else if (index.equalsIgnoreCase("4")) {
					index = "2";
					agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile("2"),
							lsmvConstants.LSMV_testDataInput + "\\" + fileName);
				}  else if (index.equalsIgnoreCase("0")) {
					//index = "1";
					agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile("1"),
							lsmvConstants.LSMV_testDataInput + "\\" + fileName);
				} else {
					agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile(index),
							lsmvConstants.LSMV_testDataInput + "\\" + fileName);
				}

				agWaitTillInvisibilityOfElement(FDE_CaseDocumentsPageObjects.uploadfile_label);
				// agClick(FDE_CaseDocumentsPageObjects.sourceDocuments_OKButton);
				// agAssertVisible(CommonPageObjects.linkText(fileName));

				agSetStepExecutionDelay("6000");
				// CommonOperations.setFDEDropDownValue(FDE_CaseDocumentsPageObjects.sourceDocuments_DocCategory(index),
				// getTestDataCellValue(scenarioName, "SourceDocs_DocCategory"));
				if (getTestDataCellValue(scenarioName, "Merge").equalsIgnoreCase("true")) {
					int indexValue = Integer.parseInt(index) + Integer.parseInt("1");
					agSelectByVisibleText(
							FDE_CaseDocumentsPageObjects.sourceDocuments_DocCategory(String.valueOf(indexValue)),
							getTestDataCellValue(scenarioName, "SourceDocs_DocCategory"));

				} else {
					agSelectByVisibleText(FDE_CaseDocumentsPageObjects.sourceDocuments_DocCategory(index),
							getTestDataCellValue(scenarioName, "SourceDocs_DocCategory"));
				}
				if (getTestDataCellValue(scenarioName, "SourceDocs_IsLocal").equalsIgnoreCase("true")
						|| getTestDataCellValue(scenarioName, "SourceDocs_IsLocal").equalsIgnoreCase("check")) {
					Integer i = Integer.parseInt(index);
					Integer x = i + 1;
					agJavaScriptExecuctorClick(
							FDE_CaseDocumentsPageObjects.sourceDocuments_IsLocalCheck(Integer.toString(x)));
				}
				if (getTestDataCellValue(scenarioName, "SourceDocs_IsIncluded").equalsIgnoreCase("true")
						|| getTestDataCellValue(scenarioName, "SourceDocs_IsIncluded").equalsIgnoreCase("check")) {
					agClick(FDE_CaseDocumentsPageObjects.sourceDocuments_IsIncludedCheck(index));
				}
				if (getTestDataCellValue(scenarioName, "SourceDocs_LiteratureDoc").equalsIgnoreCase("true")
						|| getTestDataCellValue(scenarioName, "SourceDocs_LiteratureDoc").equalsIgnoreCase("check")) {
					agClick(FDE_CaseDocumentsPageObjects.sourceDocuments_LiteratureDocCheck(index));
				}
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				// CommonOperations.captureScreenShot(true);
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to Add Source Documents in in Case
	 *             Documents Section.
	 * @InputParameters: scenarioName, index
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 10-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void addSourceDocuments1(String scenarioName, String index) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String fileName = Multimaplibraries.getTestDataCellValue(scenarioName, "SourceDocs_DocDescription1");
		FDE_Operations.FDE_Navigations("Case Documents");
		CommonOperations.agwaitTillVisible(FDE_CaseDocumentsPageObjects.sourceDocuments_Label);

		if (getTestDataCellValue(scenarioName, "AddSourceDocuments").equals("true")) {
			agClick(FDE_CaseDocumentsPageObjects.sourceDocuments_AddButton);
			agSetStepExecutionDelay("5000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_DocDesc(index),
					getTestDataCellValue(scenarioName, "SourceDocs_DocDescription1"));
			// agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile(index),
			// getTestDataCellValue(scenarioName, "SourceDocs_DocPath"));
			agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile(index),
					lsmvConstants.LSMV_testDataInput + "\\" + fileName);
			// agSetStepExecutionDelay("5000");
			agWaitTillVisibilityOfElement(FDE_CaseDocumentsPageObjects.uploadfile_label);
			agClick(FDE_CaseDocumentsPageObjects.sourceDocuments_OKButton);
			// agAssertVisible(CommonPageObjects.linkText(fileName));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agClick(FDE_CaseDocumentsPageObjects.clickDocumentCategoryFile2);
			agClick(FDE_CaseDocumentsPageObjects
					.setDocumentCategoryFile2(getTestDataCellValue(scenarioName, "SourceDocs_DocCategory")));
			// CommonOperations.setFDEDropDownValue(FDE_CaseDocumentsPageObjects.sourceDocuments_DocCategory(index),
			// getTestDataCellValue(scenarioName, "SourceDocs_DocCategory"));

			if (getTestDataCellValue(scenarioName, "SourceDocs_IsLocal").equalsIgnoreCase("true")
					|| getTestDataCellValue(scenarioName, "SourceDocs_IsLocal").equalsIgnoreCase("check")) {
				agClick(FDE_CaseDocumentsPageObjects.sourceDocuments_IsLocalCheck(index));
			}
			if (getTestDataCellValue(scenarioName, "SourceDocs_IsIncluded").equalsIgnoreCase("true")
					|| getTestDataCellValue(scenarioName, "SourceDocs_IsIncluded").equalsIgnoreCase("check")) {
				agClick(FDE_CaseDocumentsPageObjects.sourceDocuments_IsIncludedCheck(index));
			}
			if (getTestDataCellValue(scenarioName, "SourceDocs_LiteratureDoc").equalsIgnoreCase("true")
					|| getTestDataCellValue(scenarioName, "SourceDocs_LiteratureDoc").equalsIgnoreCase("check")) {
				agClick(FDE_CaseDocumentsPageObjects.sourceDocuments_LiteratureDocCheck(index));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to verify added Source Document in
	 *             Case Documents Section.
	 * @InputParameters: scenarioName, index
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 19-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifySourceDocuments(String scenarioName, String index) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		// agCheckPropertyValue("DocDescription", getTestDataCellValue(scenarioName,
		// "SourceDocs_DocDescription"),
		// FDE_CaseDocumentsPageObjects.sourceDocuments_DocDesc(index));
		// agCheckPropertyText(getTestDataCellValue(scenarioName,
		// "SourceDocs_DocCategory"),
		// FDE_CaseDocumentsPageObjects.sourceDocuments_DocCategory(index + 1));
		// agAssertVisible(CommonPageObjects.linkText(getTestDataCellValue(scenarioName,
		// "SourceDocs_FileName")));
		agAssertVisible(CommonPageObjects.linkText(getTestDataCellValue(scenarioName, "Filename")));

		// verifyInRowCheckBoxes(FDE_CaseDocumentsPageObjects.sourceDocuments_IsLocalCheck(index),
		// getTestDataCellValue(scenarioName, "SourceDocs_IsLocal"));
		// verifyInRowCheckBoxes(FDE_CaseDocumentsPageObjects.sourceDocuments_IsIncludedCheck(index
		// + 1),
		verifyIsIncludedCheckbox(index + Integer.toString(1));
		// getTestDataCellValue(scenarioName, "SourceDocs_IsIncluded"));
		// verifyInRowCheckBoxes(FDE_CaseDocumentsPageObjects.sourceDocuments_LiteratureDocCheck(index),
		// getTestDataCellValue(scenarioName, "SourceDocs_LiteratureDoc"));
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to Add Supporting Documents in in Case
	 *             Documents Section.
	 * @InputParameters: scenarioName, index
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 18-Feb-2020
	 * @UpdatedByAndWhen:Pooja S on 21-Apr-2020,WajahatUmar S on 11-Dec-2020
	 **********************************************************************************************************/
	public static void addSupportDocuments(String scenarioName, String index) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			String SupportFilename = Multimaplibraries.getTestDataCellValue(scenarioName, "SupportFilename");
			// FDE_Operations.FDE_Navigations("Case Documents");
			CommonOperations.agwaitTillVisible(FDE_CaseDocumentsPageObjects.supportDocs_label);
			if (getTestDataCellValue(scenarioName, "AddSupportDocuments").equals("true")) {
				agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.supportDocs_AddButton);
				agSetStepExecutionDelay("3000");
				agSetValue(FDE_CaseDocumentsPageObjects.supportDocs_DocDesc(index),
						getTestDataCellValue(scenarioName, "SupportDocs_DocDescription"));
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				agSetStepExecutionDelay("3000");
				if (index.equalsIgnoreCase("3")) {
					index = "1";
					agSetValue(FDE_CaseDocumentsPageObjects.supportDocs_UploadFile("1"),
							lsmvConstants.LSMV_testDataInput + "\\" + SupportFilename);
				} else if (index.equalsIgnoreCase("4")) {
					index = "2";
					agSetValue(FDE_CaseDocumentsPageObjects.supportDocs_UploadFile("2"),
							lsmvConstants.LSMV_testDataInput + "\\" + SupportFilename);
				} else {
					agSetValue(FDE_CaseDocumentsPageObjects.supportDocs_UploadFile(index),
							lsmvConstants.LSMV_testDataInput + "\\" + SupportFilename);
				}

				// agUploadDocuments(lsmvConstants.LSMV_testDataInput + "\\" + SupportFilename);
				agWaitTillVisibilityOfElement(FDE_CaseDocumentsPageObjects.uploadfile_label);
				// agClick(FDE_CaseDocumentsPageObjects.sourceDocuments_OKButton);
				// agAssertVisible(CommonPageObjects.linkText(SupportFilename));
				// agJavaScriptExecuctorClick(
				// FDE_CaseDocumentsPageObjects.supportDocs_DocCategory(index +
				// Integer.toString(1)));
				agSetStepExecutionDelay("6000");

				if (getTestDataCellValue(scenarioName, "Merge").equalsIgnoreCase("true")) {

					int indexValue = Integer.parseInt(index) + Integer.parseInt("1");
					agSelectByVisibleText(
							FDE_CaseDocumentsPageObjects.supportDocs_DocCategory(String.valueOf(indexValue)),
							getTestDataCellValue(scenarioName, "SupportDocs_DocCategory"));
				} else {
					agSelectByVisibleText(FDE_CaseDocumentsPageObjects.supportDocs_DocCategory(index),
							getTestDataCellValue(scenarioName, "SourceDocs_DocCategory"));
				}
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				if (getTestDataCellValue(scenarioName, "SupportDocs_IsLocal").equalsIgnoreCase("true")
						|| getTestDataCellValue(scenarioName, "SupportDocs_IsLocal").equalsIgnoreCase("check")) {
					agSetStepExecutionDelay("2000");
					if (scenarioName.contains("QBEBasedonCaseDocuments_016")
							|| scenarioName.contains("QBEBasedonCaseDocuments_017")) {
						index = "3";
						agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.supportDocs_IsLocalCheck(index));
					} else {
						agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.supportDocs_IsLocalCheck(index));
					}
				}
				if (getTestDataCellValue(scenarioName, "SupportDocs_IsIncluded").equalsIgnoreCase("true")
						|| getTestDataCellValue(scenarioName, "SupportDocs_IsIncluded").equalsIgnoreCase("check")) {
					agClick(FDE_CaseDocumentsPageObjects.supportDocs_IsIncludedCheck(index + Integer.toString(1)));
				}
				if (getTestDataCellValue(scenarioName, "SupportDocs_LiteratureDoc").equalsIgnoreCase("true")
						|| getTestDataCellValue(scenarioName, "SupportDocs_LiteratureDoc").equalsIgnoreCase("check")) {
					agClick(FDE_CaseDocumentsPageObjects.supportDocs_LiteratureDocCheck(index + Integer.toString(1)));
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to verify added Support Document in
	 *             Case Documents Section.
	 * @InputParameters: scenarioName, index
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 19-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifySupportDocuments(String scenarioName, String index) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("DocDescription", getTestDataCellValue(scenarioName, "SupportDocs_DocDescription"),
				FDE_CaseDocumentsPageObjects.supportDocs_DocDesc(index));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "SupportDocs_DocCategory"),
				FDE_CaseDocumentsPageObjects.supportDocs_DocCategory(index));
		agAssertVisible(CommonPageObjects.linkText(getTestDataCellValue(scenarioName, "SupportDocs_FileName")));

		verifyInRowCheckBoxes(FDE_CaseDocumentsPageObjects.supportDocs_IsLocalCheck(index),
				getTestDataCellValue(scenarioName, "SupportDocs_IsLocal"));
		verifyInRowCheckBoxes(FDE_CaseDocumentsPageObjects.supportDocs_IsIncludedCheck(index),
				getTestDataCellValue(scenarioName, "SupportDocs_IsIncluded"));
		verifyInRowCheckBoxes(FDE_CaseDocumentsPageObjects.supportDocs_LiteratureDocCheck(index),
				getTestDataCellValue(scenarioName, "SupportDocs_LiteratureDoc"));

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to verify added Source Document in
	 *             Case Documents Section after Split.
	 * @InputParameters: scenarioName, index
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @Date : 19-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifySourceUploadDocumentSplit(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (FDE_CaseDocumentsPageObjects.filenameLink
				.contains(getTestDataCellValue(scenarioName, "SupportDocs_DocCategory")) == true) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "SupportDocs_DocCategory"),
					FDE_CaseDocumentsPageObjects.filenameLink);
			Reports.ExtentReportLog("", Status.PASS, "Source document one is displayed", true);

		} else if (FDE_CaseDocumentsPageObjects.filenameLink
				.contains(getTestDataCellValue(scenarioName, "SupportDocs_DocCategory")) == true) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "SupportDocs_DocCategory1"),
					FDE_CaseDocumentsPageObjects.filenameLink);
			Reports.ExtentReportLog("", Status.PASS, "Source document two is displayed", true);

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Source document doesnt Exist", true);

		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify In-Row CheckBoxes under a
	 *             table.
	 * @InputParameters: label, boolChk
	 * @OutputParameters:NA
	 * @author:Mithun M p
	 * @Date : 19-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyInRowCheckBoxes(String label, String boolChk) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		String checkStatus = ToolManager.agGetAttribute("class", label);

		if (boolChk.equalsIgnoreCase("true") || boolChk.equalsIgnoreCase("check")) {
			if (checkStatus.contains("check")) {
				Reports.ExtentReportLog("Checkbox", Status.PASS, "Checkbox is checked", true);
			} else {
				Reports.ExtentReportLog("Checkbox", Status.FAIL, "Checkbox is not checked", true);
			}
		} else if (boolChk.equalsIgnoreCase("false") || boolChk.equalsIgnoreCase("uncheck")) {
			if (checkStatus.contains("blank")) {
				Reports.ExtentReportLog("Checkbox", Status.PASS, "Checkbox is not checked", true);
			} else {
				Reports.ExtentReportLog("Checkbox", Status.FAIL, "Checkbox is checked", true);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify case sumamry sheet appended
	 *             in case documents screen for unapproved case
	 * @InputParameters:
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 22-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCaseSummarySheet(String scenarioName) {
		if (scenarioName.equalsIgnoreCase("VerifyCaseSummaryFU_ChildcaseUnApprove")) {
			CaseSummarySheetVerification(scenarioName);
		}
		if (scenarioName.equalsIgnoreCase("VerifyCaseSummaryFU_ParentcaseApprove")) {
			CaseSummarySheetVerification(scenarioName);
		}
		agSetStepExecutionDelay("2000");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(CommonPageObjects.linkText(getTestDataCellValue(scenarioName, "Filename")));
		agAssertVisible(CommonPageObjects.linkText(getTestDataCellValue(scenarioName, "SupportFilename")));
		agSetStepExecutionDelay(String.valueOf((Constants.defaultGlobalStepExecutionDelay)));
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to verify source document category in data
	 *             assessment followup screen
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 21-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifydocuments(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		List<WebElement> filenameList = agGetElementList(
				(DataAssessmentPageObjects.docList).replace("%id%", DataAssessmentPageObjects.fileName));

		if (scenarioName.equalsIgnoreCase("VerifyCaseSummaryFU_ChildcaseUnApprove")) {
			for (int i = 1; i <= filenameList.size(); i++) {
				if (i == 1) {
					agCheckPropertyText(getTestDataCellValue("VerifyCaseSummaryFU_ChildcaseUnApprove", "Filename"),
							DataAssessmentPageObjects.verifyDocs(Integer.toString(i),
									DataAssessmentPageObjects.fileName));
				} else {
					agCheckPropertyText(
							getTestDataCellValue("VerifyCaseSummaryFU_ChildcaseUnApprove", "SupportFilename"),
							DataAssessmentPageObjects.verifyDocs(Integer.toString(i),
									DataAssessmentPageObjects.fileName));
				}

			}
		}
		if (scenarioName.equalsIgnoreCase("VerifyCaseSummaryFU_ParentcaseApprove")) {
			for (int i = 1; i <= filenameList.size(); i++) {
				if (i == 1) {
					agCheckPropertyText(getTestDataCellValue("VerifyCaseSummaryFU_ParentcaseApprove", "Filename"),
							DataAssessmentPageObjects.verifyDocs(Integer.toString(i),
									DataAssessmentPageObjects.fileName));
					agJavaScriptExecuctorClick((DataAssessmentPageObjects.docCheckBox_Source));
				} else {
					agCheckPropertyText(
							getTestDataCellValue("VerifyCaseSummaryFU_ParentcaseApprove", "SupportFilename"),
							DataAssessmentPageObjects.verifyDocs(Integer.toString(i),
									DataAssessmentPageObjects.fileName));
					agJavaScriptExecuctorClick((DataAssessmentPageObjects.docCheckBox_Support));
				}
			}
		}

		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify isIncluded check box
	 *             checked or not
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :11-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyIsIncludedCheckbox(String index) {
		String value="";
		if(agIsVisible(FDE_CaseDocumentsPageObjects.sourceDocuments_IsIncludedCheck(index))){
			 value = agGetAttribute("value", FDE_CaseDocumentsPageObjects.sourceDocuments_IsIncludedCheck(index));
		}
		
		if (value.equalsIgnoreCase("true")) {
			Reports.ExtentReportLog("", Status.PASS, "IsIncludedCheckbox Checked", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "IsIncludedCheckbox not Checked", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify attached Source Documents
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date :21-Sept-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SourceDocumentsVerification(String scenarioName) {
		FDE_Operations.FDE_Navigations("Case Documents");
		agIsVisible(FDE_CaseDocumentsPageObjects.sourceDoc);
		String SourceDoc = agGetText(FDE_CaseDocumentsPageObjects.sourceDoc);
		trimExtension(SourceDoc, scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to trim the extension of source
	 *             document and verify Source Documents
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date :21-Sept-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void trimExtension(String SourceDoc, String scenarioName) {

		String[] doc = SourceDoc.split("[.]", 0);
		String SourcedocName = doc[0];

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "dataassessmentoperations");
		String Result = DataAssessmentOperations.getData(scenarioName, "AERNo");

		if (Result.equalsIgnoreCase(SourcedocName)) {
			Reports.ExtentReportLog("", Status.PASS, "Source Document Name Matched:", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Source Doucument Name not Matched:", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify attached Source Documents
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date :21-Sept-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void CaseSummarySheetVerification(String scenarioName) {
		agIsVisible(FDE_CaseDocumentsPageObjects.supportDoc);
		String caseSummaryDoc = agGetText(FDE_CaseDocumentsPageObjects.supportDoc);
		trimPdf(caseSummaryDoc, scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to trim the extension of source
	 *             document and verify Source Documents
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date :21-Sept-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void trimPdf(String supportDoc, String scenarioName) {

		String[] doc = supportDoc.split("[_]", 0);
		String caseSummaryDoc = doc[0];

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		String Result = FDE_General.getData(scenarioName, "ReceiptNo");

		if (Result.equalsIgnoreCase(caseSummaryDoc)) {
			Reports.ExtentReportLog("", Status.PASS, "Parent Case Summary Sheet Matched : " + caseSummaryDoc, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Parent Case Summary Sheet not Matched:" + caseSummaryDoc, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to Checkout Source Documents in in
	 *             Case Documents Section.
	 * @InputParameters: scenarioName, index
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void checkOutSourceDocuments(String scenarioName, String index) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agSetStepExecutionDelay("5000");
		agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.sourceDocuments_CheckOut(index));
		CommonOperations.takeScreenShot();
		agIsVisible(FDE_CaseDocumentsPageObjects.CheckOutConfirmMsg);
		agClick(FDE_CaseDocumentsPageObjects.ConfirmationOkBtn);
		try {
			Thread.sleep(8000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		agGetCurrentWindow();
		agSetStepExecutionDelay("5000");
		CommonOperations.takeScreenShot();
		agCloseCurrentWindow();
		agGetWindowControlByInstance(1);
		agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.sourceDocuments_CheckIn(index));
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay("7000");
		agClick(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadChekoutFile);
		agUploadDocuments(lsmvConstants.LSMV_testDataInput + "\\"
				+ getTestDataCellValue(scenarioName, "SourceDocs_CheckoutDocDescription"));
		agAssertVisible(
				CommonPageObjects.linkText(getTestDataCellValue(scenarioName, "SourceDocs_CheckoutDocDescription")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetStepExecutionDelay("5000");
		agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.sourceDocuments_CheckOut);
		CommonOperations.takeScreenShot();
		agIsVisible(FDE_CaseDocumentsPageObjects.CheckOutConfirmMsg);
		agClick(FDE_CaseDocumentsPageObjects.ConfirmationOkBtn);
		try {
			Thread.sleep(8000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		agGetCurrentWindow();
		agSetStepExecutionDelay("5000");
		CommonOperations.takeScreenShot();
		agCloseCurrentWindow();
		agGetWindowControlByInstance(1);
		agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.sourceDocuments_CheckIn);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay("7000");
		agClick(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadChekoutFile);
		agUploadDocuments(lsmvConstants.LSMV_testDataInput + "\\"
				+ getTestDataCellValue(scenarioName, "SourceDocs_CheckoutDocDescription"));
		agAssertVisible(
				CommonPageObjects.linkText(getTestDataCellValue(scenarioName, "SourceDocs_CheckoutDocDescription")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Delete Souce and Support documnets
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :14-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void DeleteSourceandSupportDocuments(String index) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		FDE_Operations.FDE_Navigations("Case Documents");
		agSetStepExecutionDelay("3000");
		CommonOperations.captureScreenShot(true);

		agClick(FDE_CaseDocumentsPageObjects.CheckSourceFile(index));
		agSetStepExecutionDelay("2000");
		agClick(FDE_CaseDocumentsPageObjects.DeleteBtnSourceDocument);
		agWaitTillVisibilityOfElement(FDE_CaseDocumentsPageObjects.DeleteOkBtn);
		agClick(FDE_CaseDocumentsPageObjects.DeleteOkBtn);
		agWaitTillVisibilityOfElement(FDE_CaseDocumentsPageObjects.DeleteYesBtn);
		agClick(FDE_CaseDocumentsPageObjects.DeleteYesBtn);

		if (agIsVisible(FDE_CaseDocumentsPageObjects.CheckSourceFile(index)) == true) {
			Reports.ExtentReportLog("", Status.FAIL, "Source File Not Deleted", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS, "Source File Deleted", true);
		}

		agClick(FDE_CaseDocumentsPageObjects.CheckSuportFile(index));
		agSetStepExecutionDelay("2000");
		agClick(FDE_CaseDocumentsPageObjects.DeleteBtnSupportDocument);
		agWaitTillVisibilityOfElement(FDE_CaseDocumentsPageObjects.DeleteOkBtn);
		agClick(FDE_CaseDocumentsPageObjects.DeleteOkBtn);

		if (agIsVisible(FDE_CaseDocumentsPageObjects.CheckSuportFile(index)) == true) {
			Reports.ExtentReportLog("", Status.FAIL, "Support File Not Deleted", true);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Support File Deleted", true);
		}
		CommonOperations.captureScreenShot(true);
		FDE_Operations.saveCase();
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to Checkout Support Documents in in
	 *             Case Documents Section.
	 * @InputParameters: scenarioName, index
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen
	 **********************************************************************************************************/

	public static void checkOutSupportDocuments(String scenarioName, String index) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.supportDocuments_CheckOut);
		CommonOperations.takeScreenShot();
		agIsVisible(FDE_CaseDocumentsPageObjects.CheckOutConfirmMsg);
		agClick(FDE_CaseDocumentsPageObjects.SupportConfirmationOkBtn);
		try {
			Thread.sleep(8000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		agGetCurrentWindow();
		agSetStepExecutionDelay("5000");
		CommonOperations.takeScreenShot();
		agCloseCurrentWindow();
		agGetWindowControlByInstance(1);
		agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.supportDocuments_CheckIn);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay("7000");
		agClick(FDE_CaseDocumentsPageObjects.supportDocuments_UploadChekoutFile);
		agUploadDocuments(lsmvConstants.LSMV_testDataInput + "\\"
				+ getTestDataCellValue(scenarioName, "SupportDocs_CheckoutDocDescription"));
		agAssertVisible(
				CommonPageObjects.linkText(getTestDataCellValue(scenarioName, "SupportDocs_CheckoutDocDescription")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify attached Source Documents
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date :21-Sept-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void docIsDisabled() {
		agIsVisible(FDE_CaseDocumentsPageObjects.docIsDisabled);
		System.out.print("Document is Disabled");
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to Add Source Documents in in Case
	 *             Documents Section.
	 * @InputParameters: scenarioName, index
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 18-Feb-2020
	 * @UpdatedByAndWhen:WajahatUmar S on 11-Dec-2020
	 **********************************************************************************************************/

	public static void addSourceSupportDocuments(String scenarioName, String index) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			String fileName = Multimaplibraries.getTestDataCellValue(scenarioName, "Filename");
			// FDE_Operations.FDE_Navigations("Case Documents");

			if (getTestDataCellValue(scenarioName, "AddSourceDocuments").equals("true")) {
				agSetStepExecutionDelay("5000");
				agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.sourceDocuments_AddButton);
				agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_DocDesc(index),
						getTestDataCellValue(scenarioName, "SourceDocs_DocDescription"));
				agSetStepExecutionDelay("3000");
				if (index.equalsIgnoreCase("3")) {
					index = "1";
					agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile(index),
							lsmvConstants.LSMV_testDataInput + "\\" + fileName);
				} else if (index.equalsIgnoreCase("4")) {
					index = "2";
					agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile(index),
							lsmvConstants.LSMV_testDataInput + "\\" + fileName);
				} else {
					agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile(index),
							lsmvConstants.LSMV_testDataInput + "\\" + fileName);
				}

				agWaitTillInvisibilityOfElement(FDE_CaseDocumentsPageObjects.uploadfile_label);
				agAssertVisible(CommonPageObjects.linkText(fileName));

				agSetStepExecutionDelay("3000");

				agSelectByVisibleText(FDE_CaseDocumentsPageObjects.sourceDocuments_DocCategory(index),
						getTestDataCellValue(scenarioName, "SourceDocs_DocCategory"));
				if (getTestDataCellValue(scenarioName, "SourceDocs_IsLocal").equalsIgnoreCase("true")
						|| getTestDataCellValue(scenarioName, "SourceDocs_IsLocal").equalsIgnoreCase("check")) {
					Integer i = Integer.parseInt(index);
					Integer x = i + 1;
					agJavaScriptExecuctorClick(
							FDE_CaseDocumentsPageObjects.sourceDocuments_IsLocalCheck(Integer.toString(x)));
				}

				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
				String SupportFilename = Multimaplibraries.getTestDataCellValue(scenarioName, "SupportFilename");
				CommonOperations.agwaitTillVisible(FDE_CaseDocumentsPageObjects.supportDocs_label);
				if (getTestDataCellValue(scenarioName, "AddSupportDocuments").equals("true")) {
					agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.supportDocs_AddButton);
					agSetStepExecutionDelay("3000");
					agSetValue(FDE_CaseDocumentsPageObjects.supportDocs_DocDesc(index),
							getTestDataCellValue(scenarioName, "SupportDocs_DocDescription"));
					agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

					agSetValue(FDE_CaseDocumentsPageObjects.supportDocs_UploadFile(index),
							lsmvConstants.LSMV_testDataInput + "\\" + SupportFilename);
					agWaitTillVisibilityOfElement(FDE_CaseDocumentsPageObjects.uploadfile_label);
					agAssertVisible(CommonPageObjects.linkText(SupportFilename));

					agSetStepExecutionDelay("2000");
					agSelectByVisibleText(FDE_CaseDocumentsPageObjects.supportDocs_DocCategory(index),
							getTestDataCellValue(scenarioName, "SupportDocs_DocCategory"));

					agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
					if (getTestDataCellValue(scenarioName, "SupportDocs_IsLocal").equalsIgnoreCase("true")
							|| getTestDataCellValue(scenarioName, "SupportDocs_IsLocal").equalsIgnoreCase("check")) {
						agClick(FDE_CaseDocumentsPageObjects.supportDocs_IsLocalCheck(index + Integer.toString(1)));
					}

				}
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Add Souce and Support documnets
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :09-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AddSourceandSupportDocuments(String scenarioName, String scenarioName1, String index) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Add Source/Support Document Started", true);
			FDE_Operations.FDE_Navigations("Case Documents");
			agSetStepExecutionDelay("2000");

			if (index.equalsIgnoreCase("2")) {
				index = "0";
				int j = Integer.valueOf(index);
				for (int i = 1; i < 3; i++) {
					if (i == 2) {
						addSourceDocuments(scenarioName1, String.valueOf(i));
						addSupportDocuments(scenarioName1, String.valueOf(i));
						break;
					}
					addSourceDocuments(scenarioName, index + i);
					addSupportDocuments(scenarioName, index + i);

				}
			} else if (index.equalsIgnoreCase("3")) {
				int i = Integer.valueOf(index);
				if (i == 3) {
					addSourceDocuments(scenarioName1, String.valueOf(i));
					addSupportDocuments(scenarioName1, String.valueOf(i));
					i++;
					addSourceDocuments(scenarioName, String.valueOf(i));
					addSupportDocuments(scenarioName, String.valueOf(i));
				}
			} else if (index.equalsIgnoreCase("0")) {
				int i = Integer.valueOf("3");

				addSourceDocuments(scenarioName, String.valueOf(i));
				addSupportDocuments(scenarioName, String.valueOf(i));

			} else {

				addSourceDocuments(scenarioName, index);
				addSupportDocuments(scenarioName, index);
			}
			Reports.ExtentReportLog("", Status.INFO, "Add Source/Support Document Ended", true);
			// CommonOperations.captureScreenShot(true);
			agSetStepExecutionDelay("4000");
			FDE_Operations.saveCase();
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);
		} catch (

		NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set source document description
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :29-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSourceDocDesc(String scenarioName, String index) {
		agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_DocDesc(index),
				getTestDataCellValue(scenarioName, "SourceDocs_DocDescription"));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add source documents without
	 *             source document description
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :29-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addSourceDocs(String scenarioName, String index) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			String fileName = Multimaplibraries.getTestDataCellValue(scenarioName, "Filename");

			if (getTestDataCellValue(scenarioName, "AddSourceDocuments").equals("true")) {
				agSetStepExecutionDelay("5000");
				agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.sourceDocuments_AddButton);

				agSetStepExecutionDelay("3000");

				agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile(index),
						lsmvConstants.LSMV_testDataInput + "\\" + fileName);

				agWaitTillInvisibilityOfElement(FDE_CaseDocumentsPageObjects.uploadfile_label);
				agAssertVisible(CommonPageObjects.linkText(fileName));

				agSetStepExecutionDelay("3000");
				// CommonOperations.setFDEDropDownValue(FDE_CaseDocumentsPageObjects.sourceDocuments_DocCategory(index),
				// getTestDataCellValue(scenarioName, "SourceDocs_DocCategory"));

				agSelectByVisibleText(FDE_CaseDocumentsPageObjects.sourceDocuments_DocCategory(index),
						getTestDataCellValue(scenarioName, "SourceDocs_DocCategory"));
				if (getTestDataCellValue(scenarioName, "SourceDocs_IsLocal").equalsIgnoreCase("true")
						|| getTestDataCellValue(scenarioName, "SourceDocs_IsLocal").equalsIgnoreCase("check")) {
					agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.sourceDocuments_IsLocalCheck((index)));
				}
				if (getTestDataCellValue(scenarioName, "SourceDocs_IsIncluded").equalsIgnoreCase("true")
						|| getTestDataCellValue(scenarioName, "SourceDocs_IsIncluded").equalsIgnoreCase("check")) {
					agClick(FDE_CaseDocumentsPageObjects.sourceDocuments_IsIncludedCheck(index));
				}
				if (getTestDataCellValue(scenarioName, "SourceDocs_LiteratureDoc").equalsIgnoreCase("true")
						|| getTestDataCellValue(scenarioName, "SourceDocs_LiteratureDoc").equalsIgnoreCase("check")) {
					agClick(FDE_CaseDocumentsPageObjects.sourceDocuments_LiteratureDocCheck(index));
				}
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to Add Supporting Documents in in Case
	 *             Documents Section with put support document description
	 * @InputParameters: scenarioName, index
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 29-DEc-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addSupportDocs(String scenarioName, String index) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			String SupportFilename = Multimaplibraries.getTestDataCellValue(scenarioName, "SupportFilename");
			// FDE_Operations.FDE_Navigations("Case Documents");
			CommonOperations.agwaitTillVisible(FDE_CaseDocumentsPageObjects.supportDocs_label);
			if (getTestDataCellValue(scenarioName, "AddSupportDocuments").equals("true")) {
				agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.supportDocs_AddButton);
				agSetStepExecutionDelay("3000");
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

				agSetValue(FDE_CaseDocumentsPageObjects.supportDocs_UploadFile(index),
						lsmvConstants.LSMV_testDataInput + "\\" + SupportFilename);

				// agUploadDocuments(lsmvConstants.LSMV_testDataInput + "\\" + SupportFilename);
				agWaitTillVisibilityOfElement(FDE_CaseDocumentsPageObjects.uploadfile_label);
				// agClick(FDE_CaseDocumentsPageObjects.sourceDocuments_OKButton);
				agAssertVisible(CommonPageObjects.linkText(SupportFilename));
				// agJavaScriptExecuctorClick(
				// FDE_CaseDocumentsPageObjects.supportDocs_DocCategory(index +
				// Integer.toString(1)));
				agSetStepExecutionDelay("2000");
				agSelectByVisibleText(FDE_CaseDocumentsPageObjects.supportDocs_DocCategory(index),
						getTestDataCellValue(scenarioName, "SupportDocs_DocCategory"));

				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				if (getTestDataCellValue(scenarioName, "SupportDocs_IsLocal").equalsIgnoreCase("true")
						|| getTestDataCellValue(scenarioName, "SupportDocs_IsLocal").equalsIgnoreCase("check")) {
					agClick(FDE_CaseDocumentsPageObjects.supportDocs_IsLocalCheck(index + Integer.toString(1)));
				}
				if (getTestDataCellValue(scenarioName, "SupportDocs_IsIncluded").equalsIgnoreCase("true")
						|| getTestDataCellValue(scenarioName, "SupportDocs_IsIncluded").equalsIgnoreCase("check")) {
					agClick(FDE_CaseDocumentsPageObjects.supportDocs_IsIncludedCheck(index + Integer.toString(1)));
				}
				if (getTestDataCellValue(scenarioName, "SupportDocs_LiteratureDoc").equalsIgnoreCase("true")
						|| getTestDataCellValue(scenarioName, "SupportDocs_LiteratureDoc").equalsIgnoreCase("check")) {
					agClick(FDE_CaseDocumentsPageObjects.supportDocs_LiteratureDocCheck(index + Integer.toString(1)));
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set support document description
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :29-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AddDocuments(String scenarioName) {
		FDE_Operations.FDE_Navigations("Case Documents");
		FDE_Operations.FDE_Navigations("Case Information");
		FDE_Operations.FDE_Navigations("Case Documents");
		agSetStepExecutionDelay("5000");
		CommonOperations.captureScreenShot(true);
		if (scenarioName.contains("1")) {

			agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.sourceDocuments_AddButton);
			agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile("1"),
					lsmvConstants.LSMV_testDataInput + "\\" + "wfg.pdf");
			agSetStepExecutionDelay("5000");
			agSelectByVisibleText(FDE_CaseDocumentsPageObjects.sourceDocuments_DocCategory("3"),
					"Adverse Event Report/Form");
			agSetStepExecutionDelay("2000");
			agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.supportDocs_AddButton);
			agSetValue(FDE_CaseDocumentsPageObjects.supportDocs_UploadFile("1"),
					lsmvConstants.LSMV_testDataInput + "\\" + "swfg.xls");
			agSetStepExecutionDelay("4000");
			agSelectByVisibleText(FDE_CaseDocumentsPageObjects.supportDocs_DocCategory("3"),
					"Adverse Event Report/Form");
			CommonOperations.captureScreenShot(true);
		} else if (scenarioName.contains("2")) {
			agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.sourceDocuments_AddButton);
			agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile("1"),
					lsmvConstants.LSMV_testDataInput + "\\" + "xyz.pdf");
			agSetStepExecutionDelay("5000");
			agSelectByVisibleText(FDE_CaseDocumentsPageObjects.sourceDocuments_DocCategory("2"),
					"Adverse Event Report/Form");
			agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.supportDocs_AddButton);
			agSetStepExecutionDelay("2000");
			agSetValue(FDE_CaseDocumentsPageObjects.supportDocs_UploadFile("1"),
					lsmvConstants.LSMV_testDataInput + "\\" + "sxyz.pdf");
			agSetStepExecutionDelay("4000");

			ToolManager.agSelectByVisibleText(FDE_CaseDocumentsPageObjects.supportDocs_DocCategory("2"),
					"Adverse Event Report/Form");
			CommonOperations.captureScreenShot(true);
		} else {
			agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.sourceDocuments_AddButton);
			agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile("1"),
					lsmvConstants.LSMV_testDataInput + "\\" + "local1.pdf");
			agSetStepExecutionDelay("5000");
			agSelectByVisibleText(FDE_CaseDocumentsPageObjects.sourceDocuments_DocCategory("3"), "E2B summary sheet");
			agSetStepExecutionDelay("2000");
			agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.supportDocs_AddButton);
			agSetValue(FDE_CaseDocumentsPageObjects.supportDocs_UploadFile("1"),
					lsmvConstants.LSMV_testDataInput + "\\" + "slocal1.bmp");
			agSetStepExecutionDelay("5000");
			agSelectByVisibleText(FDE_CaseDocumentsPageObjects.supportDocs_DocCategory("3"), "E2B summary sheet");
			agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.sourceDocuments_AddButton);
			agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile("2"),
					lsmvConstants.LSMV_testDataInput + "\\" + "local2.pdf");
			agSetStepExecutionDelay("5000");
			agSelectByVisibleText(FDE_CaseDocumentsPageObjects.sourceDocuments_DocCategory("4"), "E2B summary sheet");
			agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.supportDocs_AddButton);
			agSetStepExecutionDelay("2000");
			agSetValue(FDE_CaseDocumentsPageObjects.supportDocs_UploadFile("2"),
					lsmvConstants.LSMV_testDataInput + "\\" + "slocal2.jpeg");
			agSetStepExecutionDelay("5000");
			agSelectByVisibleText(FDE_CaseDocumentsPageObjects.supportDocs_DocCategory("4"), "Log Sheet");

			agClick(FDE_CaseDocumentsPageObjects.supportDocs_IsLocalCheck("3"));
			agSetStepExecutionDelay("2000");
			agClick(FDE_CaseDocumentsPageObjects.sourceDocuments_IsLocalCheck("3"));
			CommonOperations.captureScreenShot(true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set support document
	 *             description(Scenario Specific)
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :18-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyIsLocal() {
		FDE_Operations.FDE_Navigations("Case Documents");

		if (agIsVisible(FDE_CaseDocumentsPageObjects.disableLink) == true) {
			Reports.ExtentReportLog("", Status.PASS, "As Expected" + "<br />"
					+ "The user is Able to view the added local documents under case Documents.", true);
			agJavaScriptExecuctorClick(FDE_CaseDocumentsPageObjects.disableLink);
			agSetStepExecutionDelay("3000");
			agGetCurrentWindow();
			agSetStepExecutionDelay("6000");
			CommonOperations.captureScreenShot(true);
			agCloseCurrentWindow();
			agGetWindowControlByInstance(1);
			agSetStepExecutionDelay("4000");

		} else {
			Reports.ExtentReportLog("", Status.PASS, "As Expected" + "<br />"
					+ "The user is Unable to view the added local documents under case Documents", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set support document description
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :29-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSupportDocDesc(String scenarioName, String index) {
		agSetValue(FDE_CaseDocumentsPageObjects.supportDocs_DocDesc(index),
				getTestDataCellValue(scenarioName, "SupportDocs_DocDescription"));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the case summary sheet
	 *             appended in case documents based on the Generate case summary
	 *             sheet checkbox [Check/Uncheck] at workflow level
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :02-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verificationOfAutoCaseSummarySheet(String scenarioName, String Activity, String SendToActivity) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "WorkflowConfigurations");
		String caseSummaryStatus = getTestDataCellValue(scenarioName, "GenerateCaseSummaryCheckBox");
		FDE_Operations.FDE_Navigations("Case Documents");
		agSetStepExecutionDelay("2000");
		CommonOperations.agwaitTillVisible(FDE_CaseDocumentsPageObjects.supportDocs_label);
		if (caseSummaryStatus.equalsIgnoreCase("Yes")) {
			ArrayList<String> pdfName = fileNameList();
			if (pdfName.size() > 0) {
				List<WebElement> fileName = agGetElementList(FDE_CaseDocumentsPageObjects.supportFileName);
				int fileCount = 0;
				for (int i = 0; i < fileName.size(); i++) {
					System.out.println("Available Case Summary Sheet : " + i + pdfName.get(i));
					System.out.println(pdfName.get(i));
					if (pdfName.get(i).contains(SendToActivity)) {
						fileCount++;
					}
				}
				if (fileCount > 0) {
					Reports.ExtentReportLog("", Status.PASS,
							" Case Summary Sheet generated for the case >> " + " WorkFlow: " + Activity, true);
				}
				if (fileCount == 0) {
					Reports.ExtentReportLog("", Status.FAIL,
							" Case Summary Sheet not generated for the case >> " + " WorkFlow: " + Activity, true);
				}
			} else {
				Reports.ExtentReportLog("", Status.PASS,
						" No Case summary sheet attached for the case >> " + " WorkFlow: " + Activity, true);
			}
		} else if (caseSummaryStatus.equalsIgnoreCase("No")) {
			ArrayList<String> pdfName = fileNameList();
			if (pdfName.size() > 0) {
				List<WebElement> fileName = agGetElementList(FDE_CaseDocumentsPageObjects.supportFileName);
				int k = 0;
				for (int i = 0; i < fileName.size(); i++) {
					System.out.println("Available Case Summary Sheet : " + i + pdfName.get(i));
					if (pdfName.get(i).contains(SendToActivity)) {
						k++;
					}
				}
				if (k > 0) {
					Reports.ExtentReportLog("", Status.FAIL,
							" Case Summary Sheet generated for the case >> " + " WorkFlow: " + Activity, true);
				}
				if (k == 0) {
					Reports.ExtentReportLog("", Status.PASS,
							" Case Summary Sheet not generated for the case >> " + " WorkFlow: " + Activity, true);
				}
			} else {
				Reports.ExtentReportLog("", Status.PASS,
						" No Case summary sheet attached for the case >> " + " WorkFlow: " + Activity, true);
			}

		} else if (caseSummaryStatus.equalsIgnoreCase("") || caseSummaryStatus.equalsIgnoreCase("#skip#")) {
			Reports.ExtentReportLog("", Status.INFO, " No Value provided for the workflow " + Activity, true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to get all case summary sheet pdf
	 *             files
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 03-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> fileNameList() {
		ArrayList<String> list = new ArrayList<String>();
		// ArrayList Al = new ArrayList<>();
		if (agIsVisible(FDE_CaseDocumentsPageObjects.supportFileName) == true) {
			List<WebElement> fileName = agGetElementList(FDE_CaseDocumentsPageObjects.supportFileName);
			for (int i = 0; i < fileName.size(); i++) {
				String pdfName = agGetAttribute("title",
						FDE_CaseDocumentsPageObjects.fileNameCount(Integer.toString(i + 1)));
				// List<String> list = Arrays.asList(pdfName.toString());
				// Al.addAll(list);
				list.add(pdfName);
			}

		}
		return list;
	}
	
	
	
	
}