package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class AccountsPageObjects {

	public static String accountNewLable = "xpath#//span[@class='ui-panel-title']/label[text()='Accounts Details']";
	public static String accountListingLable = "xpath#//div[@id='accountListForm:searchPanel']//following::div/child::div/label[text()='Accounts Listing']";
	public static String accountsGroupLable = "xpath#//div[@class='CaseList_Title']/label[text()='Accounts Group Listing']";
	public static String accounts_tab = "xpath#//a[@id='accountNewForm:accountTabId']//span[text()='Accounts']";

	// Account Module Menu Navigations Validation point
	public static String accountHover = "xpath#//a[@class='ui-menuitem-link ui-submenu-link ui-corner-all']//span[@class='ui-menuitem-text'][contains(text(),'Accounts')]";
	public static String accountNew = "xpath#//a[@id='headerForm:accountNewId']//span[@class='ui-menuitem-text'][contains(text(),'New')]";
	public static String accountNameTextbox = "xpath#//input[@id='accountNewForm:accountNameId']";
	public static String accountListingSearchTextbox = "xpath#//input[@id='accountListForm:keyword']";
	public static String accountGroupSearchTextbox = "xpath#//input[@id='accountsGroupListForm:keyword']";
	public static String unResolveCorrSearchTextbox = "xpath#//input[@id='unResolveCorrlistForm:searchText']";
	public static String accountListing = "xpath#//a[@id='headerForm:accountListId']//span[@class='ui-menuitem-text'][contains(text(),'Listing')]";
	public static String accountsGroup = "xpath#//a[@id='headerForm:accountGroupListId']/span[(text() ='Accounts group')]";
	public static String unresolvedCorrespondence = "xpath#//a[@id='headerForm:accountGroupListId']//following::span[@class='ui-menuitem-text'][contains(text(),'Unresolved correspondence')]";
	public static String unresolvedCorrespondenceLable = "xpath#//label[@id='unResolveCorrlistForm:accessLabel3']";
	public static String set_AccountsDetails_Txtfields = "xpath#//div[@id='accountNewForm:accountPanelId_content']/div/child::div//label[contains(text(),'%s')]/following-sibling::input";
	public static String set_FirmDetails_Txtfields = "xpath#//div[@id='accountNewForm:firmPanelId_content']/div/child::div//label[contains(text(),'%s')]/following-sibling::input";
	public static String accountsGroupNameLookup_icon = "xpath#//a[@id='accountNewForm:manufacturerGroupId:accountGroupLookup']/img";
	public static String accountsGroupName_Txtfield = "xpath#//input[@id='accountGroupLookup:accountGroupName']";
	public static String lookupSearch_Btn = "xpath#//button[@id='accountGroupLookup:findButton']";
	public static String lookupOK_Btn = "xpath#//button[@id='accountGroupLookup:okButton1']";
	public static String reasonforDeactivate_Txtarea = "xpath#//textarea[@id='accountNewForm:reasonForInActive']";
	public static String description_Txtarea = "xpath#//textarea[@id='accountNewForm:descriptionId']";
	public static String phoneCountryCode = "xpath#//input[@id='accountNewForm:phoneCntryCode']";
	public static String phoneAreaCode = "xpath#//input[@id='accountNewForm:phoneAreaCode']";
	public static String phoneNumber = "xpath#//input[@id='accountNewForm:phoneNo']";
	public static String faxCountryCode = "xpath#//input[@id='accountNewForm:faxCntryCOde']";
	public static String faxAreaCode = "xpath#//input[@id='accountNewForm:faxAreaCode']";
	public static String faxNumber = "xpath#//input[@id='accountNewForm:fax']";
	public static String save_Btn = "xpath#//button[@id='accountNewForm:visibleSave']";
	public static String saveAndExit_Btn = "xpath#//button[@id='accountNewForm:saveAndExitId']";
	public static String SaveOkBtn = "xpath#//button[@id='mandatoryDialogform:okButton']/span";
	public static String cancel_Btn = "xpath#//button[@id='accountNewForm:cancelId']";
	public static String synonyms_tab = "xpath#//a[@id='accountNewForm:synonymsId']/span[contains(text(),'Synonyms')]";
	public static String click_dropdown = "xpath#//label[contains(@id,'accountNewForm')][contains(text(),'%s')]/following-sibling::div/div[contains(@class,'ui-selectonemenu-trigger')]";
	public static String select_value = "xpath#//ul[contains(@class,'ui-selectonemenu-items')]/child::li[text()='%s']";
	public static String selectParentCountry = "xpath#//ul[@id='accountNewForm:PA1-1_items']/li[contains(text(),'%s')]";
	public static String selectFirmCountry = "xpath#//ul[contains(@id,'accountNewForm:FA1')]/li[contains(text(),'%s')]";

	public static String clickCountry_AccdetailsSection = "xpath#//label[@for='accountNewForm:A1-1015_focus']/following-sibling::div/div[contains(@class,'ui-selectonemenu-trigger')]";
	public static String clickCountry_FirmdetailsSection = "xpath#//label[contains(@id,'accountNewForm:FA1')]/following-sibling::div/span";
	public static String icsrExchangePartner_RadioBtn = "xpath#//label[contains(text(),'ICSR Exchange Partner?')]/parent::div/table[@id='accountNewForm:usertype']/tbody/tr/td//label[text()='%s']";
	public static String isDistributionContact_RadioBtn = "xpath#//label[contains(text(),'Is Distribution Contact?')]/parent::div/table[@id='accountNewForm:usertypeDistributionCntact']/tbody/tr/td//label[text()='%s']";
	public static String synonymsAdd_Btn = "xpath#//a[@id='accountNewForm:addSearchField5']";
	public static String synonyms_Txtarea = "xpath#//input[@id='accountNewForm:verbatiumTermsDataTable:%s:verbatiumTerms']";
	public static String synonyms_Label = "xpath#//th[@aria-label='Synonyms']";
	public static String searchIcon = "xpath#//a[@id='accountListForm:searchgroups']/img";
	public static String validationOk_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']";
	public static String validation_Popup = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String paginator = "xpath#//div[@id='accountListForm:accountListDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String refresh_icon = "xpath#//a[@id='accountListForm:refreshImage']";
	public static String get_ListofAccountID = "xpath#//tbody[@id='accountListForm:accountListDataTable_data']/tr/child::td[5]";
	public static String get_ListofAccountName = "xpath#//tbody[@id='accountListForm:accountListDataTable_data']/tr/child::td[4]";
	public static String columnHeader = "xpath#(//tbody[@id='accountListForm:accountListDataTable_data']/tr/child::td[5])[{%count}]";
	public static String accountLookup_label = "xpath#//span[text()='Account Lookup']";
	public static String accountLookup_RadioBtn = "xpath#//td/span[contains(text(),'%s')]/ancestor::tbody/tr/td/div/child::div/span";
	public static String new_Btn = "xpath#//a[@id='accountListForm:newId']";
	public static String delete_Btn = "xpath#//a[@id='accountListForm:deleteId']";
	public static String deleteConfirmWindow = "xpath#//div[@id='accountListForm:deleteconfirm']";
	public static String deleteConfirm_YesBtn = "xpath#//button[@id='accountListForm:confirmation_yes']";

	// public static String deleteConfirmWindow =
	// "xpath#//div[contains(@id,'accountListForm:deleteconfirm')]//span[contains(text(),'Are
	// you sure you want to delete')]";
	// public static String deleteConfirm_YesBtn =
	// "xpath#//div[contains(@id,'accountListForm:deleteconfirm')]//span[text()='Yes']//parent::button";

	public static String editIcon = "xpath#//a[@id='accountListForm:accountListDataTable:0:editLink']";
	public static String get_AccountType = "xpath#//label[@id='accountNewForm:A1-7032_label']";
	public static String get_AccountsGroupName = "xpath#//input[@id='accountNewForm:accountGroupName_input']";
	public static String get_AccountCountry = "xpath#//label[@id='accountNewForm:A1-1015_label']";
	public static String get_EncodingFormat = "xpath#//label[@id='accountNewForm:encodingFormatField_label']";
	public static String get_e2BMedDRAcodingforExport_dropdwn = "xpath#//label[@id='accountNewForm:medDraCode_label']";
	public static String get_SenderOrganizationType_dropdwn = "xpath#//label[@id='accountNewForm:senderOrgTypeId_label']";
	public static String get_TimeZone_dropdwn = "xpath#//label[@id='accountNewForm:timeZoneId_label']";
	public static String get_DocumentCompressionAlgorithm_dropdwn = "xpath#//label[@id='accountNewForm:compressionId_label']";
	public static String get_IRDLRDforE2BImport_dropdwn = "xpath#//label[@id='accountNewForm:irdLrd-9944_label']";

	public static String get_DistributionSetting = "xpath#//label[@id='accountNewForm:distributionsetting-7092_label']";
	public static String get_HealthAuthority = "xpath#//label[@id='accountNewForm:healthauthorityField_label']";
	public static String get_Firmcountry = "xpath#//label[contains(@id,'accountNewForm:FA1')]";
	public static String get_ParentCompanyCountry = "xpath#//label[@id='accountNewForm:PA1-1_label']";
	public static String get_SynonymsList = "xpath#//tbody[@id='accountNewForm:verbatiumTermsDataTable_data']/tr/td/input";
	public static String synonyms_Data = "xpath#(//tbody[@id='accountNewForm:verbatiumTermsDataTable_data']/tr/td/input)[%s]";
	public static String listingScreen_CheckBoxs = "xpath#//td/a/span[text()='%s']/ancestor::tbody[@id='accountListForm:accountListDataTable_data']/tr/td/div/child::div/span";
	public static String downloadIcon = "xpath#//a[@id='accountListForm:actionId']";
	public static String exporttoExcel_link = "xpath#//button[contains(@id,'accountListForm:excelID')]/span[text()='Export To Excel']";
	public static String exporttoExcel_popup = "xpath#//span[@id='listingForm:columnSelectionDialogId_title']";
	public static String export_Btn = "xpath#//button[@id='accountListForm:submitId']";
	public static String exportexcelcancel_Btn = "xpath#//button[@id='accountListForm:cancelDialogId']";
	public static String accountStatusRadioBtn = "xpath#//table[@id='accountNewForm:active']/tbody/tr/td/div/following-sibling::label[text()='%s']";

	// Advansearch
	public static String advanceSearchBtn = "xpath#//a[contains(@id,'accountListForm:j_id')][text()='Advanced Search']";
	public static String advaSrchAccountNameTxtFeild = "xpath#//input[@id='accountListForm:accountNameId']";
	public static String advSearchBtn = "xpath#//button[@id='accountListForm:j_id_qy']/span[text()='Search']";
	public static String searchRecEdit = "xpath#//span[text()='%s']/parent::a[@id='accountListForm:accountListDataTable:0:accountNameViewId']//parent::td//preceding-sibling::td//img[contains(@src,'Edit')]";

	// Account details labels
	public static String accountName_txtfield = "Account Name";
	public static String accountType_dropdown = "Account Type";
	public static String accountId_txtfield = "Account Id";
	public static String industry_txtfield = "Industry";
	public static String emailID_txtfield = "Email ID";
	public static String streetAddress_txtfield = "Street Address";
	public static String city_txtfield = "City";
	public static String state_txtfield = "State";
	public static String postcode_txtfield = "Postcode";
	public static String faxDirectory_txtfield = "Fax Directory";
	public static String faxDomain_txtfield = "Fax Domain";
	public static String website_txtfield = "Website";
	public static String domain_txtfield = "xpath#//input[@id='accountNewForm:domainId']";
	public static String qcSamplingCount_txtfield = "QC Sampling Count";
	public static String regionCode_txtfield = "xpath#//input[@id='accountNewForm:regionCode']";
	public static String region_txtfield = "xpath#//input[@id='accountNewForm:region']";
	public static String e2bDetails_label = "xpath#//label[text()='E2B Details']";

	public static String limitErrorMessageinACK_txtfield = "xpath#//input[@id='accountNewForm:ackCommentid']";

	public static String qcSamplingRunningCount_txtfield = "QC Sampling Running Count";
	public static String encodingFormat_dropdwn = "Encoding Format";

	public static String e2BMedDRAcodingforExport_dropdwn = "E2B MedDRA coding for Export";

	public static String senderOrgType_dropdwn = "Sender Organization Type";
	public static String timeZone_dropdwn = "Time Zone";

	public static String documentCompressionAlgorithm_dropdwn = "Document Compression Algorithm";
	public static String IRDLRDforE2BImport_dropdwn = "IRD-LRD for E2B Import";
	public static String distribution_dropdwn = "Distribution Setting";
	public static String language_dropdwn = "Language";
	public static String companyStatus_dropdwn = "Company Status";
	public static String healthAuthority_dropdwn = "Health Authority";
	public static String licenceType_dropdwn = "License Status";
	// Firm details labels
	public static String FirmSiteName_txtfield = "Firm/Site Name";
	public static String firmCity_txtfield = "City";
	public static String firmState_txtfield = "State";
	public static String firmPostcode_txtfield = "xpath#//input[@id='accountNewForm:firmPostCodeId']";
	public static String firmSiteFEINumber_txtfield = "Firm/Site FEI Number";
	public static String parentCompanyName_txtfield = "Parent Company Name";
	public static String parentCompanyCity_txtfield = "Parent Company City";
	public static String parentCompanyState_txtfield = "Parent Company State";
	public static String parentCompanyPostalCode_txtfield = "xpath#//input[@id='accountNewForm:parentPostCodeId']";
	public static String parentCompanyFEINumber_txtfield = "Parent Company FEI Number";
	public static String parentCompanyCountry = "Parent Company Country";
	public static String statusDate = "xpath#//input[@id='accountNewForm:statusDate_input']";

	// public static String
	// EditParticularAccount="xpath#//td[text()='%s']/preceding-sibling::td//a[contains(@id,'editLink')]";
	public static String EditParticularAccount = "xpath#//span[text()='LSMV_ACC']/ancestor::td/preceding-sibling::td/a[contains(@id,'editLink')]";

	// Exclusion and Masking >>Mask Fields

	public static String Addlink = "xpath#//a[@id='accountNewForm:addSearchMask']";
	public static String NextPageicon = "xpath#//div[@id='accountNewForm:accMaskData_paginator_top']//a[@aria-label='Next Page']";
	public static String Okbtn = "xpath#//input[@id='accountNewForm:accMaskData_selection']/following::button[contains(@id,'accountNewForm')]/span[text()='OK']";
	public static String keywordSearchTextbox = "xpath#//input[@name='accountListForm:keyword']";
	public static String searchButton = "xpath#//a[@class='ui-commandlink ui-widget newAeSearchIocn']/img";
	public static String savebtn = "xpath#//button[@name='accountNewForm:visibleSave']";
	public static String saveOkbtn = "xpath#//span[text()='OK']/preceding::button[@name='mandatoryDialogform:okButton']";
	public static String validationpopup = "xpath#//span[text()='Action  Completed Successfully']";
	public static String deletelink = "xpath#//span/a[@id='accountNewForm:maskDelete']";
	public static String deleteyesBtn = "xpath#//button[contains(@onclick,'deleteMaskConfirmDialog')]/span[text()='Yes']";

	public static String fieldNameText = "Field Name";
	public static String fieldNameFilter = "Filter by Field Name";
	public static String sectionText = "Section";
	public static String sectionFilter = "Filter by Section";
	public static String panelText = "Panel";
	public static String panelFilter = "Filter by Panel";
	public static String searchTextbox = "xpath#(//thead[@id='accountNewForm:accMaskData_head']/tr/th/span[text()='%text%']/following::label[text()='%label%']/following::input)[1]";
	public static String checkbox = "xpath#//tbody[@id='accountNewForm:accMaskData_data']/tr/td/div/div[contains(@class,'ui-chkbox-box')]/span";
	public static String fieldResult = "xpath#//tbody[@id='accountNewForm:accMaskData_data']/tr/td[4]";
	public static String page2 = "xpath#//div[@id='accountNewForm:accMaskData_paginator_top']/span/a[@aria-label='Page 2']";
	public static String page1 = "xpath#//div[@id='accountNewForm:accMaskData_paginator_top']/span/a[@aria-label='Page 1']";
	public static String maskFields_label = "xpath#//label[text()='Mask Fields']";
	public static String pagination = "xpath#//div[@id='accountNewForm:maskDataTable_paginator_top']";
	public static String deleteAllCheckbox = "xpath#(//thead[@id='accountNewForm:maskDataTable_head']/tr/th/span/following::div/span)[1]";
	public static String deleteMessage = "xpath#//span[contains(text(),'selected Contact')]";

	public static String checkBox = "xpath#//div[@id='accountNewForm:accMaskData']//tbody/tr/td[2]/label[text()='%section%']/ancestor::tr/td[3]/label[text()='%panel%']/ancestor::tr/td[4]/label[text()='%fieldName%']/ancestor::tr/td[1]/div//span";

	public static String checkbox(String section, String panel, String fieldName) {
		String value = checkBox.replace("%section%", section);
		String value1 = value.replace("%panel%", panel);
		String value2 = value1.replace("%fieldName%", fieldName);
		return value2;
	}

	// establishment

	public static String addEstablishmentBtn = "xpath#//a[@id='accountNewForm:addSearchField']";
	public static String establishmentIdTxtfield = "xpath#//input[@id='accountNewForm:productLicenseDataTable:0:establishmentId']";
	public static String establishmentcontactIdTxtfield = "xpath#//input[@id='accountNewForm:productLicenseDataTable:0:contactId']";
	public static String establishmentapplicationTypeTxtfield = "xpath#//input[@id='accountNewForm:productLicenseDataTable:0:applicationType']";
	public static String get_LicenseType = "xpath#//label[@id='accountNewForm:productLicenseDataTable:0:licenseStatus-9966_label']";
	public static String click_LicenseType = "xpath#//div[@id='accountNewForm:productLicenseDataTable:0:licenseStatus-9966']/div/span";
	public static String licenseTypeDropdwn = "xpath#//ul[@id='accountNewForm:productLicenseDataTable:0:licenseStatus-9966_items']/li[text()='%s']";

	/**********************************************************************************************************
	 * @Objective:The below method is created to set account status text area by
	 *                passing index at runtime.
	 * @Input Parameters: index
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Nov-2019 Updated by and when
	 **********************************************************************************************************/

	public static String setAccountStatus(String runTimeLabel) {
		String value = accountStatusRadioBtn;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String setlicenseType(String runTimeLabel) {
		String value = licenseTypeDropdwn;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to set the parameters to search the Mask
	 *             fields according to section and field name
	 * @Parameters: text,label
	 * @author:Pooja S Date :17-April-2020 Updated by and when
	 **********************************************************************************************************/
	public static String setSearchParameter(String text, String label) {
		String value = searchTextbox;
		String value2;
		String value3;
		value2 = value.replace("%text%", text);
		value3 = value2.replace("%label%", label);
		return value3;
	}

	public static String searchRecEdit(String contactId) {
		String value = searchRecEdit.replace("%s", contactId);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Synonyms data by passing index
	 *                at runtime.
	 * @Input Parameters: index
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Nov-2019 Updated by and when
	 **********************************************************************************************************/

	public static String synonyms_Data(String runTimeLabel) {
		String value = synonyms_Data;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to set Synonyms text area by passing
	 *                index at runtime.
	 * @Input Parameters: index
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Nov-2019 Updated by and when
	 **********************************************************************************************************/

	public static String selectAccountLookupRadioBtn(String runTimeLabel) {
		String value = accountLookup_RadioBtn;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select account lookup radio button
	 *                by passing value at runtime.
	 * @Input Parameters: index
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Nov-2019 Updated by and when
	 **********************************************************************************************************/

	public static String setSynonyms(String runTimeLabel) {
		String value = synonyms_Txtarea;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select dropdown value by passing
	 *                value at runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Nov-2019 Updated by and when
	 **********************************************************************************************************/

	public static String selectDropdownvalue(String runTimeLabel) {
		String value = select_value;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to click Is Distribution Contact?
	 *                radio button by passing value at runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Nov-2019 Updated by and when
	 **********************************************************************************************************/

	public static String setIsDistributionContact(String runTimeLabel) {
		String value = isDistributionContact_RadioBtn;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to click ICSR Exchange Partner? radio
	 *                button by passing value at runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Nov-2019 Updated by and when
	 **********************************************************************************************************/

	public static String setICSRExchangePartner(String runTimeLabel) {
		String value = icsrExchangePartner_RadioBtn;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select parent country value by
	 *                passing value at runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Nov-2019 Updated by and when
	 **********************************************************************************************************/

	public static String selectParentCountry(String runTimeLabel) {
		String value = selectParentCountry;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select Firm country value by
	 *                passing value at runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Nov-2019 Updated by and when
	 **********************************************************************************************************/

	public static String selectFirmCountry(String runTimeLabel) {
		String value = selectFirmCountry;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to set Accounts Details section text
	 *                fields by passing label name at runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Nov-2019 Updated by and when
	 **********************************************************************************************************/

	public static String setAccountsDetailsTxtfields(String runTimeLabel) {
		String value = set_AccountsDetails_Txtfields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to click drop down in Accounts Details
	 *                section by passing label name at runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Nov-2019 Updated by and when
	 **********************************************************************************************************/

	public static String clickdropdown(String runTimeLabel) {
		String value = click_dropdown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to set Firm Details section text
	 *                fields by passing label name at runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Nov-2019 Updated by and when
	 **********************************************************************************************************/

	public static String setFirmDetailsTxtfields(String runTimeLabel) {
		String value = set_FirmDetails_Txtfields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:get substance name by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:DushyanthMahesh Date :16-September-2019 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderList(String num) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select checkbox by passing value at
	 *                runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name Output
	 * @Parameters:
	 * @author:Avinash K Date :18-Oct-2019 Updated by and when
	 **********************************************************************************************************/

	public static String selectListingCheckbox(String runTimeLabel) {
		String value = listingScreen_CheckBoxs;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to Edit Particular Account.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Avinash K Date :06-Nov-2019 Updated by and when
	 **********************************************************************************************************/

	public static String EditParticularAccount(String runTimeLabel) {
		String value = EditParticularAccount;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	// Contacts
	public static String addContactButton = "xpath#//a[@id = 'accountNewForm:selectCntLink:contactLookup']";
	public static String deleteContactButton = "xpath#//a[@id = 'accountNewForm:contactDelete']";
	// AddContactformObjects
	public static String contactIdTextbox = "xpath#//input[@id= 'contactsLookupForm:contactId']";
	public static String countryDropdown = "xpath#//label[@id='contactsLookupForm:C-1015_label']";
	public static String firstNameTextbox = "xpath#//input[@id='contactsLookupForm:firstName']";
	public static String middleNameTextbox = "xpath#//label[text()='Middle Name']//following-sibling::input[contains(@id,'contactsLookupForm')]";
	public static String lastNameTextbox = "xpath#//input[@id='contactsLookupForm:lastName']";
	public static String countryCodeTextbox = "xpath#//label[text()='Country Code']//following-sibling::input[contains(@id,'contactsLookupForm')]";
	public static String areaCodeTextbox = "xpath#//label[text()='Area Code']//following-sibling::input[contains(@id,'contactsLookupForm')]";
	public static String NumberTextbox = "xpath#//label[text()='Number']//following-sibling::input[contains(@id,'contactsLookupForm')]";
	public static String extNoTextbox = "xpath#//label[text()='Extn No']//following-sibling::input[contains(@id,'contactsLookupForm')]";
	public static String emailAddressTextbox = "xpath#//label[text()='Email Address']//following-sibling::input[contains(@id,'contactsLookupForm')]";
	public static String degreeTextbox = "xpath#//label[text()='Degree']//following-sibling::input[contains(@id,'contactsLookupForm')]";
	public static String otherPhNumberTextbox = "xpath#//label[text()='Other Phone No']//following-sibling::input[contains(@id,'contactsLookupForm')]";
	public static String specializationDropdown = "xpath#//label[@id='contactsLookupForm:CL-345_label']";
	public static String ifOtherTextbox = "xpath#//input[@id='contactsLookupForm:otherVal']";
	public static String departmentDropdown = "xpath#//label[@id='contactsLookupForm:j_id_241'][text()='Department']";
	public static String primaryAccountTextbox = "xpath#//label[text()='Primary Account']//following-sibling::input[contains(@id,'contactsLookupForm')]";
	public static String postalCodeTextbox = "xpath#//label[text()='Postal Code']//following-sibling::input[contains(@id,'contactsLookupForm')]";
	public static String customerMasterIdTextbox = "xpath#//label[text()='Customer Master ID ']//following-sibling::input[contains(@id,'contactsLookupForm')]";
	public static String interchangeIdTextbox = "xpath#//label[text()='Interchange ID']//following-sibling::input[contains(@id,'contactsLookupForm')]";
	public static String isAlsoAnE2BContact = "Is also an E2B Contact";

	public static String searchContactButton = "xpath#//button[@id='contactsLookupForm:cntSearch']";
	public static String clearContactButton = "xpath#//button[@id='contactsLookupForm:cntClear']";
	public static String cancelContactButton = "xpath#//button[@id='contactsLookupForm:topCancelButton']";

	public static String confirmdelDialog = "xpath#//div[contains(@id,'deleteContactConfirmDialog')]//span[contains(text(),'Are you sure you want to delete')]";
	public static String confirmdel_YesBtn = "xpath#//div[contains(@id,'deleteContactConfirmDialog')]//span[text()='Yes']//parent::button";
	public static String confirmdel_NoBtn = "xpath#//div[contains(@id,'deleteContactConfirmDialog')]//span[text()='No']//parent::button";

	public static String selectContactFromLookupList = "xpath#//tbody[contains(@id,'contactsLookupForm:contactTable')]//td[text()='%s']//parent::tr//div[2]//span";
	public static String paginator_FirstPage = "xpath#//div[contains(@id,'contactsLookupForm:contactTable')]//a[contains(@class,'paginator-first')][@aria-label='First Page']";
	public static String paginator_PreviousPage = "xpath#//div[contains(@id,'contactsLookupForm:contactTable')]//a[contains(@class,'paginator-prev')][@aria-label='Previous Page']";
	public static String paginator_NextPage = "xpath#//div[contains(@id,'contactsLookupForm:contactTable')]//a[contains(@class,'paginator-next')][@aria-label='Next Page']";
	public static String paginator_LastPage = "xpath#//div[contains(@id,'contactsLookupForm:contactTable')]//a[contains(@class,'paginator-last')][@aria-label='Last Page']";
	public static String okContactButton = "xpath#//button[@id='contactsLookupForm:bottomOkButton']";

	public static String contacts_Label = "xpath#//div[@id= 'accountNewForm:contactsPanel_header']/descendant::label[text()= 'Contacts']";
	public static String checkContact = "xpath#//tbody[@id='accountNewForm:contactsDataTable_data']//label[contains(@id,'firstName')][text()='%s']//ancestor::td//preceding-sibling::td[3]//span";
	public static String checkPrimary = "xpath#//tbody[@id='accountNewForm:contactsDataTable_data']//label[contains(@id,'firstName')][text()='%s']//ancestor::td//preceding-sibling::td[2]//span";
	public static String interchangeIDTextbox = "xpath#//input[@id= 'accountNewForm:contactsDataTable:%rowNo%:interchangeId']";
	public static String checkE2BContacts = "xpath#//tbody[@id='accountNewForm:contactsDataTable_data']//label[contains(@id,'firstName')][text()='%s']//ancestor::td//following-sibling::td//div[contains(@id,'E2bContact')]//span";
	public static String checkDistribute = "xpath#//tbody[@id='accountNewForm:contactsDataTable_data']//label[contains(@id,'firstName')][text()='%s']//ancestor::td//following-sibling::td//div[contains(@id,'accountDistribute')]//span";

	public static String selectContactFromLookupList(String runtimeFirstName) {
		String value = selectContactFromLookupList;
		String value2;
		value2 = value.replace("%s", runtimeFirstName);
		return value2;
	}

	public static String checkContact(String runtimeFirstName) {
		String value = checkContact;
		String value2;
		value2 = value.replace("%s", runtimeFirstName);
		return value2;
	}

	public static String checkPrimary(String runtimeFirstName) {
		String value = checkPrimary;
		String value2;
		value2 = value.replace("%s", runtimeFirstName);
		return value2;
	}

	public static String checkE2BContacts(String runtimeFirstName) {
		String value = checkE2BContacts;
		String value2;
		value2 = value.replace("%s", runtimeFirstName);
		return value2;
	}

	public static String checkDistribute(String runtimeFirstName) {
		String value = checkDistribute;
		String value2;
		value2 = value.replace("%s", runtimeFirstName);
		return value2;
	}

	// SLA
	public static String addSLAButton = "xpath#//a[@id='accountNewForm:slaAdd']";
	public static String deleteSLAButton = "xpath#//a[@id='accountNewForm:slaDelete']";

	public static String selectPriorityDropdown = "xpath#//label[@id='accountNewForm:Sla:0:A1-145_label']";
	public static String selectDurationTextbox = "xpath#//input[@id='accountNewForm:Sla:0:slaValue']";
	public static String selectUnitDropdown = "xpath#//label[@id='accountNewForm:Sla:0:hours_label']";
	public static String selectSLARecord = "xpath#//tbody[@id='accountNewForm:Sla_data']//tr[@data-ri='%s']//input[@name='accountNewForm:Sla_checkbox']//parent::div//following-sibling::div//span";
	public static String checkSLARecord = "xpath#//label[contains(@id,'accountNewForm:Sla')][text()='%s']//..//..//..//span[@class='ui-chkbox-icon ui-icon ui-icon-blank ui-c']";
	public static String confirmSLADel_Dialog = "xpath#//div[contains(@id,'deleteConfirmSlaDia')]//span[contains(text(),'you want to delete the selected SLA')]";
	public static String confirmSLADel_Yes = "xpath#//div[@id='accountNewForm:deleteConfirmSlaDialogId']//span[text()='Yes']//parent::button";
	public static String confirmSLADel_No = "xpath#//div[@id='accountNewForm:deleteConfirmSlaDialogId']//span[text()='No']//parent::button";

	public static String checkSLARecord(String priority) {
		String value = checkSLARecord;
		String value2;
		value2 = value.replace("%s", priority);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select priority dropdown in SLA
	 *                Section
	 * @Input Parameters: runtimeRowno(Starts from 0,1,2,3..,)
	 * @Scenario:
	 * @Parameters:
	 * @author:@author:Mithun M P Date :14-jan-2020
	 **********************************************************************************************************/
	public static String selectPriorityDropdown(String runtimeRowno) {
		String value = selectPriorityDropdown;
		String value2;
		value2 = value.replace("%s", runtimeRowno);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to enter duration Textbox in SLA
	 *                Section
	 * @Input Parameters: runtimeRowno(Starts from 0,1,2,3..,)
	 * @Scenario:
	 * @Parameters:
	 * @author:@author:Mithun M P Date :14-jan-2020
	 **********************************************************************************************************/
	public static String selectDurationTextbox(String runtimeRowno) {
		String value = selectDurationTextbox;
		String value2;
		value2 = value.replace("%s", runtimeRowno);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to enter Unit dropdown in SLA Section
	 * @Input Parameters: runtimeRowno(Starts from 0,1,2,3..,)
	 * @Scenario:
	 * @Parameters:
	 * @author:Mithun M P Date :14-jan-2020 Updated by and when
	 **********************************************************************************************************/
	public static String selectUnitDropdown(String runtimeRowno) {
		String value = selectUnitDropdown;
		String value2;
		value2 = value.replace("%s", runtimeRowno);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select records in SLA Section
	 * @Input Parameters: runtimeRowno(Starts from 0,1,2,3..,)
	 * @Scenario:
	 * @Parameters:
	 * @author:@author:Mithun M P Date :14-jan-2020
	 **********************************************************************************************************/
	public static String selectSLARecord(String runtimeRowno) {
		String value = selectSLARecord;
		String value2;
		value2 = value.replace("%s", runtimeRowno);
		return value2;
	}

	// Contracts
	public static String addContractsButton = "xpath#//a[@id='accountNewForm:contractAdd:documentLookup']";
	public static String deleteContractsButton = "xpath#//a[@id='accountNewForm:sourceDelete']";

	// Documents/Literature Lookup
	// Documents Library
	public static String documentIdTextbox = "xpath#//input[@id='documentsLookupForm:tabView:docId']";
	public static String titleTextbox = "xpath#//input[@id='documentsLookupForm:tabView:docTitle']";
	public static String fileNameTextbox = "xpath#documentsLookupForm:tabView:fileName";
	public static String productTextbox = "xpath#//input[@id='documentsLookupForm:tabView:productId']";
	public static String tradeNameTextbox = "xpath#//input[@id='documentsLookupForm:tabView:tradeName']";
	public static String subTypeDropdown = "xpath#documentsLookupForm:tabView:DLU-5042_label";
	public static String requestCategoryDropdown = "xpath#//label[@id='documentsLookupForm:tabView:DLU-5026_label']";
	public static String requestSubCategoryDropdown = "xpath#//label[@id='documentsLookupForm:tabView:docreqSubCatListId_label']";
	public static String languageDropdown = "xpath#//label[@id='documentsLookupForm:tabView:DLD-5060_label']";
	public static String assetTypeDropdown = "xpath#//label[@id='documentsLookupForm:tabView:assetType_label']";
	public static String documentStatusDropdown = "xpath#//label[@id='documentsLookupForm:tabView:docStatus_label']";
	public static String documentKeywordsTextarea = "xpath#//textarea[@id='documentsLookupForm:tabView:dockeywords']";
	public static String keywordTextarea = "xpath#//textarea[@id='documentsLookupForm:tabView:keywordsId']";
	public static String documentsSearchButton = "xpath#//button[@id='documentsLookupForm:tabView:docSearchButton']";
	public static String documentsClearButton = "xpath#//span[text()='Clear']//parent::button[contains(@id,'documentsLookupForm:tabView')]";

	public static String offLabelCheckbox = "Off-Label";
	public static String docContectSearchCheckbox = "Document Content Search ";

	// Contracts
	public static String ContractsTab = "xpath#//a[contains(@href,'documentsLookupForm:tabView:contractTab')][text()='Contracts']";
	public static String ContractNameTextbox = "xpath#//input[@id='documentsLookupForm:tabView:contractNameId']";
	public static String ContractNoTextbox = "xpath#//input[@id='documentsLookupForm:tabView:contractNo']";
	public static String startDateTextbox = "xpath#//input[@id='documentsLookupForm:tabView:contractStartDate_input']";
	public static String endDateTextbox = "xpath#//input[@id='documentsLookupForm:tabView:contractEndDate_input']";
	public static String activeCheckbox = "Active";
	public static String uploadFileButton = "xpath#//input[@id='documentsLookupForm:tabView:sourceUpload_input']";
	public static String descriptionTextarea = "xpath#//textarea[@id='documentsLookupForm:tabView:description']";
	public static String uploadContractButton = "xpath#//span[text()='Upload']//parent::button[contains(@id,'documentsLookupForm:tabView')]";
	public static String cancelContractButton = "xpath#//span[text()='Cancel']//parent::button[contains(@id,'documentsLookupForm:tabView')]";

	public static String confirmContractdel_Dialog = "xpath#//span[text()='Are you sure you want to delete the selected Contract(s) ?']";
	public static String confirmContractdel_Yes = "xpath#//div[@id='accountNewForm:deleteConfirmDialogId']//span[text()='Yes']//parent::button";
	public static String confirmContractdel_No = "xpath#//div[@id='accountNewForm:deleteConfirmDialogId']//span[text()='No']//parent::button";

	public static String documentsLibraryLink = "xpath#//a[text()='Documents Library']";
	public static String ContractsLink = "xpath#//a[text()='Contracts']";
	public static String fileUploadedLink = "xpath#//label[@id='documentsLookupForm:tabView:doclabelId1'][text()='%s']";

	public static String fileUploadedLink(String fileName) {
		String value = fileUploadedLink;
		String value2;
		value2 = value.replace("%s", fileName);
		return value2;
	}

	// Exclusion And Masking
	// Account Exclusion
	public static String ExclusionAndMaskingTab = "xpath#//a//span[text()='Exclusion And Masking']";
	public static String addAccountExclusionLink = "xpath#//a[@id='accountNewForm:accountDistributionId']";
	public static String deleteAccountExclusionLink = "xpath#//a[@id='accountNewForm:exclusionAccountDelete']";

	public static String selectRecInAccExclLookup = "xpath#(//label[contains(@id,'accountNewForm:accExclusionDataId')][text()='%s'])[1]//parent::td//preceding-sibling::td//span";
	public static String aE_OkButton = "xpath#//div[@id='accountNewForm:accExclusionLookupId']//div[@class='srcButtonBg']//button//span[text()='OK']";
	public static String aE_FirstPage_Paginator = "xpath#//div[@id='accountNewForm:accExclusionDataId_paginator_top']//a[contains(@class,'paginator')][@aria-label='First Page']";
	public static String aE_PrevPage_Paginator = "xpath#//div[@id='accountNewForm:accExclusionDataId_paginator_top']//a[contains(@class,'paginator')][@aria-label='Previous Page']";
	public static String aE_LastPage_Paginator = "xpath#//div[@id='accountNewForm:accExclusionDataId_paginator_top']//a[contains(@class,'paginator')][@aria-label='Last Page']";
	public static String aE_NextPage_Paginator = "xpath#//div[@id='accountNewForm:accExclusionDataId_paginator_top']//a[contains(@class,'paginator')][@aria-label='Next Page']";
	public static String aE_LastPage = "xpath#//div[@id='accountNewForm:accExclusionDataId_paginator_top']//a[contains(@class,'paginator')][@aria-label='Next Page']//preceding::a[1]";
	public static String checkAccExcRecord = "xpath#//td//label[contains(@id,'accountNewForm:accExclusionDataId')][text()='%s']//..//..//span";
	public static String AccountNameValidation = "xpath#//label[@id='accountNewForm:accountExclsuionDataTable:0:j_id_1n6']";
	public static String AccountCheckbox = "xpath#//th[@id='accountNewForm:accountExclsuionDataTable:j_id_1n2']//span[@class='ui-chkbox-icon ui-icon ui-icon-blank ui-c']";
	public static String DeleteYesBtn = "xpath#//button[@id='accountNewForm:j_id_1w2']/span[text()='Yes']";
	public static String UnitNamevalidation = "xpath#//label[@id='accountNewForm:partnerExclsuionDataTable:0:j_id_1nw']";

	public static String selectRecInAccExclLookup(String accId) {
		String value = selectRecInAccExclLookup;
		String value2;
		value2 = value.replace("%s", accId);
		return value2;
	}

	public static String checkAccExcRecord(String accId) {
		String value = checkAccExcRecord;
		String value2;
		value2 = value.replace("%s", accId);
		return value2;
	}

	// Partner Exclusion
	public static String addPartnerExclusionButton = "xpath#//span[@id='accountNewForm:addingexclusionPartnerForm']//a";
	public static String deletePartnerExclusionButton = "xpath#//span[@id='accountNewForm:deleteExclusionForm']//a";
	public static String checkPartnerExcLookupRec = "xpath#//label[text()='%s']/../../descendant::span[@class='ui-chkbox-icon ui-icon ui-icon-blank ui-c']";
	public static String pE_OkButton = "xpath#//div[@id='accountNewForm:accPartnerExclusionLookup']//div[@class='srcButtonBg']//button//span[text()='OK']";
	public static String pE_FirstPage_Paginator = "xpath#//div[@id='accountNewForm:accPartnerExclusionDataId_paginator_top']//a[contains(@class,'paginator')][@aria-label='First Page']";
	public static String pE_PrevPage_Paginator = "xpath#//div[@id='accountNewForm:accPartnerExclusionDataId_paginator_top']//a[contains(@class,'paginator')][@aria-label='Previous Page']";
	public static String pE_LastPage_Paginator = "xpath#//div[@id='accountNewForm:accPartnerExclusionDataId_paginator_top']//a[contains(@class,'paginator')][@aria-label='Last Page']";
	public static String pE_NextPage_Paginator = "xpath#//div[@id='accountNewForm:accPartnerExclusionDataId_paginator_top']//a[contains(@class,'paginator')][@aria-label='Next Page']";
	public static String pE_LastPage = "xpath#//div[@id='accountNewForm:accPartnerExclusionDataId_paginator_top']//a[contains(@class,'paginator')][@aria-label='Next Page']//preceding::a[1]";
	public static String checkPartExcRecord = "xpath#//td[2]//label[contains(@id,'accountNewForm:accPartnerExclusionDataId')][text()='%s']//..//..//span";

	public static String checkPartnerExcLookupRec(String unitCode) {
		String value = checkPartnerExcLookupRec;
		String value2;
		value2 = value.replace("%s", unitCode);
		return value2;
	}

	public static String checkPartExcRecord(String unitCode) {
		String value = checkPartExcRecord;
		String value2;
		value2 = value.replace("%s", unitCode);
		return value2;
	}

	// Mask Fields
	public static String addMaskFieldsLink = "xpath#//span[@id='accountNewForm:addingmaskForm']//a";
	public static String deleteMaskFieldsLink = "xpath#//span[@id='accountNewForm:deleteMaskForm']//a";

	public static String primaryContactChkBox = "xpath#//div[@id='accountNewForm:contactsDataTable:0:isprimaryContact']//span[1]";

}
