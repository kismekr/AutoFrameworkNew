package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class ApplicationConfigSearchPolices_PageObjects {

	///// Administration >> Application Configurations >> Search Policies //////

	public static String edit_Btn = "xpath#//tbody[@id='DuplicateCheckListform:dupPolicy_data']/tr/td[3]/label[text()='%Label%']/preceding::td[1]/a/img";
	public static String search_TextBox = "xpath#//input[@id='DuplicateCheckListform:searchText']";
	public static String search_Icon = "xpath#//img[@id='DuplicateCheckListform:j_id_ne']";
	public static String newBtn = "xpath#//a[@id='DuplicateCheckListform:newId']";
	public static String policyName_TextBox = "xpath#//input[@id='dupCheckPolicyDetailsform:regionId']";
	public static String detscription_TextArea = "xpath#//textarea[@id='dupCheckPolicyDetailsform:regionDesc']";
	public static String exportConfig_Btn = "xpath#//button[@id='dupCheckPolicyDetailsform:exportJson']";
	public static String importConfig_Btn = "xpath#//div[@id='dupCheckPolicyDetailsform:ruleupload']";
	public static String saveBtn = "xpath#//button[@id='dupCheckPolicyDetailsform:visibleSave']";
	public static String cancelBtn = "xpath#//button[@id='dupCheckPolicyDetailsform:cancelId']";
	public static String reportType_Dropdown = "xpath#//label[@id='dupCheckPolicyDetailsform:reportTyprAOSEId_label']";
	public static String informedAutority_Dropdown = "xpath#//label[@id='dupCheckPolicyDetailsform:informedAuthorityId_label']";
	public static String reportingStatus_Dropdown = "xpath#//label[@id='dupCheckPolicyDetailsform:reportingStatusId_label']";
	public static String status_Radio = "Status";
	public static String policyType_Radio = "Policy Type";
	public static String source_Radio = "Source";
	public static String defaut_CheckBox = "Default";
	public static String dropDownListItem = "xpath#//div[@id='%locator%_panel']//label[text()='%text%']";
	public static String ruleBuilder_LookUp = "xpath#//img[@id='dupCheckPolicyDetailsform:j_id_ot:j_id_p4']";
	public static String ruleName_TextBox = "xpath#//input[@id='ruleBuilderLookupSearchForm:j_id_13j']";
	public static String ruleType_Dropdown = "xpath#//label[@id='ruleBuilderLookupSearchForm:ruleTypeList_label']";
	public static String search_Btn = "xpath#//button[@id='ruleBuilderLookupSearchForm:findRules']";
	public static String selectRule_CheckBox = "xpath#//tbody[@id='ruleBuilderLookupSearchForm:rbTable:rbLookUpDataTable_data']/tr/td[1]//div/span";
	public static String rule_OKBtn = "xpath#//button[contains(@id,'okButtonbottom')]";
	public static String rule_CancelBtn = "xpath#//button[contains(@id,'cancelButtonbottom')]";
	public static String clear_Icon = "xpath#//img[@id='dupCheckPolicyDetailsform:j_id_su']";
	public static String add_Link = "xpath#//a[@id='dupCheckPolicyDetailsform:levelsAddLink']";

	// >>>

	public static String administration = "xpath#//*[text()='Administration']";
	public static String searchPolicies = "xpath#//*[text()='Search policies']";

	public static String searchPolicyTableHeader = "xpath#//*[@class='checkBoxnEditSty']/thead/tr/th[contains(@id,':dupPolicy:dup')]//*[contains(@class,'title')]";
	public static String searchPolicylist = "xpath#//table[@class='checkBoxnEditSty']/tbody/tr";
	public static String searchPolicyCollist = "xpath#//table[@class='checkBoxnEditSty']/tbody/tr[{0}]/td[contains(@class,width)]//label";

	public static String editButton = "xpath#//label[text()='{0}']/ancestor::tr//a[@aria-label='Edit']";
	public static String policyName = "xpath#//label[text()=' Policy Name']/following-sibling::input[@type='text']";
	public static String reportType = "xpath#//label[text()=' Report Type']/following-sibling::div[contains(@class,'select')]//label[contains(@class,'select')]";
	public static String activeSource = "xpath#//*[text()='Source']/following-sibling::*//*[contains(@class,'state-active')]/../following-sibling::label";
	public static String defaultActiveCheckbox = "xpath#//label[text()='Default']/parent::*/*[contains(@class,'checkbox')]/*[contains(@class,'state-active')]";
	public static String statusActiveRadioButton = "xpath#//*[text()='Status']/..//*[contains(@class,'state-active')]/../following-sibling::label";
	public static String policyActiveoption = "xpath#//label[text()='Policy Type']/..//*[contains(@class,'state-active')]/parent::*/following-sibling::label";
	public static String description = "xpath#//textarea[contains(@id,'regionDesc')]";
	public static String ruleBuilder = "xpath#//input[contains(@id,'ruleName')]";

	public static String caseAttributelist = "xpath#//*[contains(@class,'token-label')]";

	public static String resultSetChecked = "xpath#//*[contains(@id,'dupRulesDataTable_data')]//*[contains(@class,'state-active')]";

	// Updated
	public static String selectLevelRowsList = "xpath#//*[@id='dupCheckPolicyDetailsform:dupLevelDataTable_data']/tr";
	public static String selectLevel = "xpath#//*[@id='dupCheckPolicyDetailsform:dupLevelDataTable:" + "{0}"
			+ ":A1-9129_input']//*[@selected='selected']";
	public static String caseAttribute = "xpath#//*[@id='dupCheckPolicyDetailsform:dupLevelDataTable:" + "{0}"
			+ ":selectManyFields']";
	public static String caseAttributeCriteriaList = "xpath#//*[@id='dupCheckPolicyDetailsform:dupLevelDataTable:"
			+ "{0}" + ":dupRulesDataTable_data']/tr";
	public static String caseAttributeCriteria = "xpath#//*[@id='dupCheckPolicyDetailsform:dupLevelDataTable:" + "{0}"
			+ ":dupRulesDataTable:" + "{1}" + ":j_id_vt']";
	public static String unconditionalATBT = "xpath#//label[@id='dupCheckPolicyDetailsform:dupLevelDataTable:" + "{0}"
			+ ":dupRulesDataTable:" + "{1}" + ":actionToBeTakenId_label']";
	public static String actionTobeTaken="xpath#//label[contains(@id,'dupCheckPolicyDetailsform:dupLevelDataTable:"+"{0}"+":dupRulesDataTable:"+"{1}"+":dupResultSetDataTable:"+"{2}"+":') and contains(@class,'ui-selectonemenu')]";
	public static String resultSetlist = "xpath#//tbody[@id='dupCheckPolicyDetailsform:dupLevelDataTable:" + "{0}"
			+ ":dupRulesDataTable:" + "{1}" + ":dupResultSetDataTable_data']/tr";
	public static String resultSet = "xpath#//label[contains(@id,'dupCheckPolicyDetailsform:dupLevelDataTable:" + "{0}"
			+ ":dupRulesDataTable:" + "{1}" + ":dupResultSetDataTable:" + "{2}" + ":')]";

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit the Policy name
	 * @InputParameters: count
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 28-Sep-2020
	 * @UpdatedByAndWhen:Chithuraj R 28-Jan-2021
	 **********************************************************************************************************/
	public static String clickEdit(String text) {
		String xpath = editButton;
		String value = xpath.replace("{0}", text);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to generate xpath based on locator
	 *             and value to select from dropdown inlcuding the checkbox.
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Pooja S
	 * @Date : 16-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectListDropDown(String locator, String valueToSelect) {
		String xpath[] = locator.split("'");
		String resLocator = xpath[1].replace("_label", "");
		String actualLocator = dropDownListItem;
		String tempLocator = actualLocator.replace("%text%", valueToSelect);
		String resultLocator = tempLocator.replace("%locator%", resLocator);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: Select the value from drop down using index
	 * @InputParameters: index
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Chithuraj R
	 * @Date : 23-jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String searchPolicyCollist(int index) {
		String xpath = searchPolicyCollist;
		String value = null;
		value = xpath.replace("{0}", Integer.toString(index));
		return value;

	}

	/**********************************************************************************************************
	 * @Objective:xpath of Select level
	 * @InputParameters: index
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Chithuraj R
	 * @Date : 05-feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String selectLevel(int index) {

		String xpath = selectLevel;
		String value = null;
		value = xpath.replace("{0}", Integer.toString(index));
		return value;

	}

	/**********************************************************************************************************
	 * @Objective:Case Attribute of Level
	 * @InputParameters: index
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Chithuraj R
	 * @Date : 05-feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String caseAttribute(int index) {
		String xpath = caseAttribute;
		String value = null;
		value = xpath.replace("{0}", Integer.toString(index));
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:xpath of Case Attribute Criteria List
	 * @InputParameters: index
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Chithuraj R
	 * @Date : 05-feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String caseAttributeCriteriaList(int index) {
		String xpath = caseAttributeCriteriaList;
		String value = null;
		value = xpath.replace("{0}", Integer.toString(index));
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:xpath of Case Attribute Criteria List
	 * @InputParameters: index
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Chithuraj R
	 * @Date : 05-feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String caseAttributeCriteria(int caseAttributeIndex, int caseAttributeCriteriaIndex) {
		String xpath = caseAttributeCriteria;
		String value = null;
		value = xpath.replace("{0}", Integer.toString(caseAttributeIndex)).replace("{1}",
				Integer.toString(caseAttributeCriteriaIndex));
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:xpath of Case Attribute Criteria List
	 * @InputParameters: index
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Chithuraj R
	 * @Date : 05-feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String unconditionalATBT(int caseAttributeIndex, int caseAttributeCriteriaIndex) {
		String xpath = unconditionalATBT;
		String value = null;
		value = xpath.replace("{0}", Integer.toString(caseAttributeIndex)).replace("{1}",
				Integer.toString(caseAttributeCriteriaIndex));
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:xpath of Case Attribute Criteria List
	 * @InputParameters: caseAttributeIndex,caseAttributeCriteriaIndex,resultSet(zeroBased="0",onlyOne="1",morethanOne="2")
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Chithuraj R
	 * @Date : 05-feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getActionByresultSet(int caseAttributeIndex, int caseAttributeCriteriaIndex,
			String resultSet) {
		String xpath = actionTobeTaken;
		String value = null;
		value = xpath.replace("{0}", Integer.toString(caseAttributeIndex))
				.replace("{1}", Integer.toString(caseAttributeCriteriaIndex)).replace("{2}", resultSet);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:xpath of result Set
	 * @InputParameters: caseAttributeIndex,caseAttributeCriteriaIndex,
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Chithuraj R
	 * @Date : 10-feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String resultSetlist(int caseAttributeIndex, int caseAttributeCriteriaIndex) {
		String xpath = resultSetlist;
		String value = null;
		value = xpath.replace("{0}", Integer.toString(caseAttributeIndex)).replace("{1}",
				Integer.toString(caseAttributeCriteriaIndex));
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:xpath of Case Attribute Criteria List
	 * @InputParameters: caseAttributeIndex,caseAttributeCriteriaIndex,resultSet(zeroBased="0",onlyOne="1",morethanOne="2")
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Chithuraj R
	 * @Date : 05-feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String resultSet(int caseAttributeIndex, int caseAttributeCriteriaIndex, int resultSetcount) {
		String xpath = resultSet;
		String value = null;
		value = xpath.replace("{0}", Integer.toString(caseAttributeIndex))
				.replace("{1}", Integer.toString(caseAttributeCriteriaIndex))
				.replace("{2}", Integer.toString(resultSetcount));
		return value;
	}
}
