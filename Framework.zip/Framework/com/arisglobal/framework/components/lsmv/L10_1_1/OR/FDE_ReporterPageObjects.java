package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FDE_ReporterPageObjects {

	public static String setData_Textfields = "xpath#//label[contains(text(),'%s')]/following-sibling::span/input";
	public static String click_Checkboxs = "xpath#//label[contains(text(),'%s')]/following-sibling::span/p-checkbox/div";
	public static String select_RadioButtons = "xpath#//label[contains(text(),'%s')]/following-sibling::span/span/p-radiobutton/label[contains(text(),'%r')]";
	public static String click_DropDown = "xpath#//label[contains(text(),'%s')]/following-sibling::span/p-dropdown[1]//div/label/span";
	public static String setdropDownValue = "xpath#(//ul[contains(@class,'ui-dropdown-items')]/child::li/div//span[contains(text(),'%s')])[1]";
	public static String add_Delete_Buttons = "xpath#//span[contains(@class,'agAddDeleteBlock')]/a[contains(text(),'%s')]";
	public static String manual_Checkbox = "xpath#//label[text()='Manual']/parent::div/p-checkbox/div//span";

	public static String QualificationDDlist = "xpath#//ul[@class='ui-dropdown-items ui-dropdown-list ui-widget-content ui-widget ui-corner-all ui-helper-reset']";
	public static String QualificationDDValue = "xpath#(//label[text()='Qualification']/parent::span//div//span[@class='ng-star-inserted'])[1]";
	public static String select_RadioButtonsEnable = "xpath#//label[contains(text(),'%s')]/following-sibling::span//span//label[contains(text(),'%r')]/ancestor::p-radiobutton//span[@class='ui-radiobutton-icon ui-clickable pi pi-circle-on']";

	public static String reporterTabClick = "xpath#//li[contains(@class,'ui-state-default ui-corner-top fdeMultiPanel942_{0}')]//span[contains(text(),'Reporter')]";
	public static String clickSF_Btn = "xpath#(//div[@class='ui-tabview-panels']//a[@class='agSfAppliedLink'])[1]";

	public static String country_select = "xpath#(//label[contains(text(),'%s')]/following-sibling::span/p-dropdown//div/label)[1]";

	public static String navigaterClick = "xpath#//div[@class='tabCarouselSty']/following::a[@class='tabCarouselNext evAttached']";

	// Literature Reference
	public static String literatureReference = "xpath#//label[contains(text(),'Literature Reference')]/following::input[contains(@id,'primarySrcLitrRefenceNumber')]";
	public static String clickliteratureReference = "xpath#//div[contains(@class,'agAutoCompPanelBody ng-star-inserted')]//span[1]";

	// Label Names
	public static String reporterAdd_Button = "xpath#//label[text()='Reporter']/following-sibling::span/a[text()='Add']";
	public static String click_MultipleReporter = "xpath#//div[@class='tabCarouselSty']/ul/li/a/span[starts-with(text(),'%s')]";

	public static String primaryReporter_Checkbox = "Primary Reporter";
	public static String protectConfidentiality_Checkbox = "Protect Confidentiality";
	public static String consenttoContact_Radiobtn = "Consent to Contact";
	public static String primarySourceRegulatory_Radiobtn = "Primary Source for Regulatory Purposes";
	public static String personType_Radiobtn = "Person Type";
	public static String healthProfessional_Radiobtn = "Health professional";
	public static String reporterInformed_Radiobtn = "Reporter Informed Authority Directly";
	public static String literatureReference_Textbox = "Literature Reference";
	public static String Title_DropDown = "Title";
	public static String firstName_Textbox = "First Name";
	public static String middleName_Textbox = "Middle Name";
	public static String lastName_Textbox = "Last Name";
	public static String hospitalOrganizationName_Textbox = "Hospital/Organization Name";
	public static String department_Textbox = "Department";
	public static String street_Textbox = "Street";
	public static String city_Textbox = "City";
	public static String state_Textbox = "State";
	public static String postalCode_Textbox = "Postal Code";
	public static String Country_DropDown = "Country";
	public static String Telephone_Textbox = "Telephone";
	public static String fax_Textbox = "Fax";
	public static String email_Textbox = "Email Id";
	public static String spanishState_DropDown = "Spanish State";
	public static String specialization_DropDown = "Specialization";
	public static String qualification_DropDown = "Qualification";
	public static String occupation_DropDown = "Occupation";
	public static String addButton = "Add";

	// r2 tags
	public static String R2Title = "xpath#//label[text()='[A.2.1.1a]']";
	public static String R2FirstName = "xpath#//label[text()='[A.2.1.1b]']";
	public static String R2MiddleName = "xpath#//label[text()='[A.2.1.1c]']";
	public static String R2LastName = "xpath#//label[text()='[A.2.1.1d]']";
	public static String R2Hospital_OrganizationName = "Xpath#//label[text()='[A.2.1.2a]']";
	public static String R2Department = "xpath#//label[text()='[A.2.1.2b]']";
	public static String R2Street = "xpath#//label[text()='[A.2.1.2c]']";
	public static String R2City = "xpath#//label[text()='[A.2.1.2d]']";
	public static String R2State = "xpath#//label[text()='[A.2.1.2e]']";
	public static String R2PostalCode = "xpath#//label[text()='[A.2.1.2f]']";
	public static String R2Country = "xpath#//label[text()='[A.2.1.3]']";
	public static String R2EmailId = "xpath#//label[text()='[A.2.1.3.FDA.4]']";
	public static String R2SpanishState = "xpath#//label[text()='Spanish State']//parent::span/label[text()='[A.2.1.2e]']";
	public static String R2Qualification = "xpath#//label[text()='[A.2.1.4]']";

	// R3 Tags
	public static String R3PrimarySourceForRegulatoryPurposes = "xpath#//label[text()='[C.2.r.5]']";
	public static String R3Title = "xpath#//label[text()='[C.2.r.1.1]']";
	public static String R3FirstName = "xpath#//label[text()='[C.2.r.1.2]']";
	public static String R3MiddleName = "xpath#//label[text()='[C.2.r.1.3]']";
	public static String R3LastName = "xpath#//label[text()='[C.2.r.1.4]']";
	public static String R3Hospital_OrganizationName = "xpath#//label[text()='[C.2.r.2.1]']";
	public static String R3Department = "xpath#//label[text()='[C.2.r.2.2]']";
	public static String R3Street = "xpath#//label[text()='[C.2.r.2.3]']";
	public static String R3City = "xpath#//label[text()='[C.2.r.2.4]']";
	public static String R3State = "xpath#//label[text()='[C.2.r.2.5]']";
	public static String R3PostalCode = "xpath#//label[text()='[C.2.r.2.6]']";
	public static String R3Country = "xpath#//label[text()='[C.2.r.3]']";
	public static String R3Telephone = "xpath#//label[text()='[C.2.r.2.7]']";
	public static String R3EmailId = "xpath#//label[text()='[FDA.C.2.r.2.8]']";
	public static String R3SpanishState = "xpath#//label[text()='Spanish State']//parent::span/label[text()='[C.2.r.2.5]']";
	public static String R3Qualification = "xpath#//label[text()='[C.2.r.4]']";

	// codelist
	public static String CLPrimaryReporter = "xpath#//label[text()='Primary Reporter']//parent::span/label[text()='[4]']";
	public static String CLProtectConfidentiality = "xpath#//label[text()='Protect Confidentiality']//parent::span/label[text()='[1002]']";
	public static String CLConsentToContact = "xpath#//label[text()='Consent to Contact']//parent::span/label[text()='[1002]']";
	public static String CLPrimarySourceForRegulatoryPurposes = "xpath#//label[text()='Primary Source for Regulatory Purposes']//parent::span/label[text()='[4]']";
	public static String CLPersonType = "xpath#//label[text()='[9740]']";
	public static String CLTitle = "xpath#//label[text()='[5014]']";
	public static String CLCountry = "xpath#//label[text()='[1015]']";
	public static String CLSpanishState = "xpath#//label[text()='[8147]']";
	public static String CLSpecialization = "xpath#//label[text()='[345]']";
	public static String CLQualification = "xpath#//label[text()='[1003]']";
	public static String CLHealthProfessional = "xpath#//label[text()='Health professional']//parent::span/label[text()='[1002]']";
	public static String CLOccupation = "xpath#//label[text()='[1028]']";
	public static String CLReporterInformedAuthorityDirectly = "xpath#//label[text()='[1008]']";
	public static String dataprivacyConfirmationPopUp_Message = "xpath#//div[@class='ui-dialog-content ui-widget-content']//span[@class='ui-confirmdialog-message']";
	public static String dataprivacyConfirmationPopUpYes_Btn = "xpath#//span[contains(@class,'ui-button-text ui-clickable') and text()= 'Yes']";

	public static String clickMultipleReporter(String runTimeLabel) {
		String value = click_MultipleReporter.replace("%s", runTimeLabel);
		return value;
	}

	public static String reporterRecord = "xpath#//span[contains(text(),'%s')]";
	public static String reporterRecord2 = "2. Reporter";
	public static String reporterRecord3 = "3. Reporter";

	public static String clickReporterRecord(String runTimeLabel) {
		String value = reporterRecord;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to set data in text field by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String setData_Textfields(String runTimeLabel) {
		String value = setData_Textfields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click checkboxs by passing label
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String click_Checkboxs(String runTimeLabel) {
		String value = click_Checkboxs;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select radio button by passing label
	 * name and value at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String select_RadioButtons(String runTimeLabel, String valueRuntime) {
		String value = select_RadioButtons.replace("%s", runTimeLabel);
		value = value.replace("%r", valueRuntime);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select radio button by passing label
	 * name and value at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String select_RadioButtonsEnable(String runTimeLabel, String valueRuntime) {
		String value = select_RadioButtonsEnable.replace("%s", runTimeLabel);
		value = value.replace("%r", valueRuntime);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click drop downs by passing label
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String click_DropDown(String runTimeLabel) {
		String value = click_DropDown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	// Click Drop down value
	public static String setdropDownValue(String data) {
		String value = setdropDownValue.replace("%s", data);
		return value;
	}

	// Add and delete button
	public static String add_Delete_Buttons(String data) {
		String value = add_Delete_Buttons.replace("%s", data);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: To Clik on Reporter tab
	 * @InputParameters: position, runTimeLabel
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 03-Jun-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String clickReporter(String data) {
		String value = reporterTabClick.replace("{0}", data);
		return value;
	}

}
