package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import com.arisglobal.framework.lib.main.ToolManager;

public class RolespageObjects extends ToolManager
{

	public static String newBtn = "xpath#//a[@id='rolesListForm:newId']";
	public static String deleteBtn = "xpath#//a[@id='rolesListForm:deleteRole']";
	public static String copyBtn = "xpath#//a[@id='rolesListForm:copyId']";
	public static String keywordSearchBtn = "xpath#//input[@id='rolesListForm:keywordSearch']";
	public static String keywordSearchIcon = "xpath#//img[contains(@src,'search_icon')]";
	public static String paginator = "xpath#//div[@id='rolesListForm:roleListDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String editIcon = "xpath#//span[text() = '%text%']/ancestor::tr/descendant::a[contains(@id , ':editLockPanelGrp')]/img[contains(@id, 'editIcon')]";
	
	//Roles > Copy Pop-up
	public static String newRoleName_Textbox = "xpath#//input[contains(@id, 'rolesListForm') and @title= 'Role Name' and @aria-disabled = 'false']";
	public static String description_Textbox = "xpath#//textarea[contains(@id, 'rolesListForm') and @title= 'Description' and @aria-disabled = 'false']";
	public static String copy_Button = "xpath#//button[@id = 'rolesListForm:bottomOkButton']/span[text()= 'Copy']";
	
	
	public static String RoleNameTextbox = "xpath#//input[@id='rolesNewForm:roleName']";
	public static String descriptionTextarea = "xpath#//textarea[@id='rolesNewForm:roleDescription']";
	public static String saveBtn = "xpath#//button[@id='rolesNewForm:visibleSave']";
	public static String cancelBtn = "xpath#//button[@id='rolesNewForm:cancelId']";
	
	//CompanyUnit and Product Panel
	public static String companyUnitTab = "xpath#//span[text()='Company Unit']//parent::a";
	public static String productsTab = "xpath#//div[@id='rolesNewForm:companyAndProductPanel']//span[text()='Products']//parent::a";
	public static String filterByUnitCodeTextbox = "xpath#//input[@id='rolesNewForm:companyDataTable:j_id_ow:filter']";
	public static String filterByUnitNameTextbox = "xpath#//input[@id='rolesNewForm:companyDataTable:j_id_oy:filter']";
	public static String companyUnitFilterByAccessDropdown = "xpath#//select[@id='rolesNewForm:companyDataTable:filterAccessId_input']";
	public static String toggler = "xpath#//a[@id='rolesNewForm:companyAndProductPanel_toggler']";
	public static String addProductLink = "xpath#//a[@id='rolesNewForm:angProductLookupForRoles']";
	public static String deleteProductLink = "xpath#//a[@id='rolesNewForm:delProductLink']";
	
	public static String selectNonAccessRadio = "xpath#//label[text()='%s']//following::td[1]//label[text()='No Access']//preceding::div[1]//span";
	public static String selectReadRadio = "xpath#//label[text()='%s']//following::td[1]//label[text()='Read']//preceding::div[1]//span";
	public static String selectReadOrUpdateRadio = "xpath#//label[text()='%s']//following::td[1]//label[text()='Read/Update']//preceding::div[1]//span";
	
	//Transaction Access
	public static String caseManagementTab = "xpath#//div[@id='rolesNewForm:j_id_qy']//span[text()='Case Management']";
	public static String submissionTab = "xpath#//div[@id='rolesNewForm:j_id_qy']//span[text()='Submission ']";
	public static String studySubTab = "xpath#//div[contains(@id,'rolesNewForm')]//span[text()='Study']";
	public static String seriousnessSubTab = "xpath#//div[contains(@id,'rolesNewForm')]//span[text()='Seriousness']";
	public static String distributionUnitsOrContactsSubTab = "xpath#//div[contains(@id,'rolesNewForm')]//span[text()='Distribution Units/Contacts']";
	public static String caseManagementAddStudyLink = "xpath#//a[@id='rolesNewForm:addStudy:studyLookup']";
	public static String submissionAddStudyLink = "xpath#//a[@id='rolesNewForm:addStudySubmission:studyLookup']";
	public static String filterByNameTextbox = "xpath#//input[@id='rolesNewForm:transactionAccessDataTable:namecolumn1:filter']";
	public static String filterByContactNameTextbox = "xpath#//label[text()='Filter by Contact Name']//following-sibling::input";
	public static String filterByAccessDropdown = "xpath#//div[@id='rolesNewForm:contactsDataTable:filterAccessId']//select";
	public static String allUnitsOrContactsDropdown = "xpath#//label[@id='rolesNewForm:allContacts']//ancestor::div[1]//following-sibling::div//select";
	
	public static String projectNoTextbox = "xpath#//input[@id='studyLookupForm:prjctId']";
	public static String studyNoTextbox = "xpath#//input[@id='studyLookupForm:studyNoSearch']";
	public static String searchStudyButton = "xpath#//button[@id='studyLookupForm:studySearchButton']";
	public static String clearStudyButton = "xpath#//span[text()='Clear']//parent::button";
	public static String studyLookUpOkButton = "xpath#//button[@id='studyLookupForm:okButtonBottom']";
	public static String studyLookUpCancelButton = "xpath#//button[@id='studyLookupForm:cancelButtonBottom']";
	
	public static String checkStudyAccessAssignedCheckbox = "xpath#//label[@title='%s']//parent::td//following-sibling::td//span";
	public static String checkStudyNoLookUpResultsCheckbox = "xpath#//tbody[@id='studyLookupForm:studyTable:studyLookUpDataTableMulti_data']//tr//td[2]//span[text()='%s']//parent::td//preceding-sibling::td//span";
	
	
	//Labels
	public static String productName_RadioBtn = "Product Name";
	public static String noAccess_RadioBtn = "No Access";
	public static String read_RadioBtn = "Read";
	public static String readUpdate_RadioBtn = "Read/Update";
	
	public static String allStudy_Checkbox = "All Study";
	public static String accessAssignedCheckbox = "Access Assigned";
	
	//Workflow Activities
	public static String wa_CaseTriageLink = "xpath#//span[text()='Case Triage']//parent::a";
	public static String wa_submissionLink = "xpath#//div[@id='rolesNewForm:workFlowtabMenus']//span[text()='Submission']//parent::a";
	public static String wa_FAQLink = "xpath#//div[@id='rolesNewForm:workFlowtabMenus']//span[text()='FAQ']//parent::a";
	public static String wa_DocumentsLink = "xpath#//div[@id='rolesNewForm:workFlowtabMenus']//span[text()='Documents']//parent::a";
	public static String wa_TemplateLink = "xpath#//div[@id='rolesNewForm:workFlowtabMenus']//span[text()='Template']//parent::a";	
	  //CaseTriage & Submission
	  public static String wa_Ct_NoAccessRadio = "xpath#//label[text()='%s']//parent::td//following-sibling::td//label[text()='No Access']//preceding::div[1]//span";
	  public static String wa_Ct_ReadRadio = "xpath#//label[text()='%s']//parent::td//following-sibling::td//label[text()='Read']//preceding::div[1]//span";
	  public static String wa_Ct_ReadOrUpdateRadio = "xpath#//label[text()='%s']//parent::td//following-sibling::td//label[text()='Read/Update']//preceding::div[1]//span";
	  //FAQ or Documents or Template
	  public static String wa_DefActivityRadio = "xpath#//tbody[@id='rolesNewForm:aeWFDataTable_data']//label[text()='%s']//parent::td//following-sibling::td//input[@type='radio']//parent::div//following-sibling::div//span";
	  public static String wa_AccAssignedCheckbox = "xpath#//tbody[@id='rolesNewForm:aeWFDataTable_data']//label[text()='%s']//parent::td//following-sibling::td//input[@type='checkbox']//parent::div//following-sibling::div//span";
	 
	//WebServiceAccess
	public static String wsa_AddLink = "xpath#//a[@id='rolesNewForm:addScriptedRoleClass:addScriptedRoleClass']";
	public static String wsa_DeleteLink = "xpath#//a[@id='rolesNewForm:delWebAccessLink']";
	
	public static String wsa_ServiceNameCheckbox = "xpath#//tbody[contains(@id,'scriptedrolesLookupSearchForm:rolesTable')]//span[text()='%s']//parent::td//preceding-sibling::td//span";
	public static String wsa_NextPagePaginator = "xpath#//a[contains(@class,'paginator')][@aria-label='Next Page']";
	public static String wsa_PreviousPagePaginator = "xpath#//a[contains(@class,'paginator')][@aria-label='Previous Page']";
	public static String wsa_FirstPagePaginator = "xpath#//a[contains(@class,'paginator')][@aria-label='First Page']";
	public static String wsa_LastPagePaginator = "xpath#//a[contains(@class,'paginator')][@aria-label='Last Page']";
	public static String wsa_ResultPerPageDropdown = "xpath#//select[contains(@name,'rppDD')]";
	public static String wsa_LookUpOkBtn = "xpath#//button[@id='scriptedrolesLookupSearchForm:okButtonbottom']";
	public static String wsa_LookUpCancelBtn = "xpath#//button[@id='scriptedrolesLookupSearchForm:cancelButtonbottom']";
	
	public static String wsa_CheckServices = "xpath#//label[text()='%s']//parent::td//preceding-sibling::td//span";
	
	//Monitoring
	public static String Dashboard_label = "Dashboard";
	
	//SectionAccess
	public static String sa_AccAssignedCheckbox = "xpath//tbody[contains(@id,'rolesNewForm:sectionAccessDatatable')]//label[text()='%s']//parent::td//following-sibling::td//span";
	public static String sa_tabMenusNavig = "xpath//span[text()='%s']//parent::a[contains(@onclick,'rolesNewForm:sectionAccesstabMenus')]";
	
	
	public static String selectNonAccessRadio(String companyUnitName){
		String value1 = selectNonAccessRadio; 
		String value2 = value1.replace("%s" , companyUnitName);
		
		return value2;
	}

	public static String selectReadRadio(String companyUnitName){
		String value1 = selectReadRadio; 
		String value2 = value1.replace("%s" , companyUnitName);
		
		return value2;
	}
	
	public static String selectReadOrUpdateRadio(String companyUnitName){
		String value1 = selectReadOrUpdateRadio; 
		String value2 = value1.replace("%s" , companyUnitName);
		
		return value2;
	}
	
	public static String checkStudyAccessAssignedCheckbox(String companyUnitName){
		String value1 = checkStudyAccessAssignedCheckbox; 
		String value2 = value1.replace("%s" , companyUnitName);
		
		return value2;
	}
	
	public static String checkStudyNoLookUpResultsCheckbox(String companyUnitName){
		String value1 = checkStudyNoLookUpResultsCheckbox; 
		String value2 = value1.replace("%s" , companyUnitName);
		
		return value2;
	}
	
	public static String wa_Ct_NoAccessRadio(String activity){
		String value1 = wa_Ct_NoAccessRadio; 
		String value2 = value1.replace("%s" , activity);
		
		return value2;
	}
	public static String wa_Ct_ReadRadio(String activity){
		String value1 = wa_Ct_ReadRadio; 
		String value2 = value1.replace("%s" , activity);
		
		return value2;
	}
	public static String wa_Ct_ReadOrUpdateRadio(String activity){
		String value1 = wa_Ct_ReadOrUpdateRadio; 
		String value2 = value1.replace("%s" , activity);
		
		return value2;
	}
	
	public static String wa_DefActivityRadio(String activity){
		String value1 = wa_DefActivityRadio; 
		String value2 = value1.replace("%s" , activity);
		
		return value2;
	}
	public static String wa_AccAssignedCheckbox(String activity){
		String value1 = wa_AccAssignedCheckbox; 
		String value2 = value1.replace("%s" , activity);
		
		return value2;
	}
	public static String wsa_ServiceNameCheckbox(String activity){
		String value1 = wsa_ServiceNameCheckbox; 
		String value2 = value1.replace("%s" , activity);
		
		return value2;
	}
	public static String wsa_CheckServices(String activity){
		String value1 = wsa_CheckServices; 
		String value2 = value1.replace("%s" , activity);
		
		return value2;
	}
	public static String sa_AccAssignedCheckbox(String Name){
		String value1 = sa_AccAssignedCheckbox; 
		String value2 = value1.replace("%s" , Name);
		
		return value2;
	}
	
	public static String sa_tabMenusNavig(String tab){
		String value1 = sa_tabMenusNavig; 
		String value2 = value1.replace("%s" , tab);
		
		return value2;
	}
}
