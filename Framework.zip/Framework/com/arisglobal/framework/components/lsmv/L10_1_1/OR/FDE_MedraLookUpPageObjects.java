package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FDE_MedraLookUpPageObjects {

	public static String searchTerm_Textfields = "xpath#//label[contains(text(),'Search Term')]/input";
	public static String dictionaryCode_Textfields = "xpath#//label[contains(text(),'Dictionary Code')]/following-sibling::input";
	public static String search_Button = "xpath#//button/span[text()='Search']";
	public static String ok_Button = "xpath#//p-dialog//div/button/span[text()='OK']";
	public static String clickDropDown = "xpath#//div/label[contains(text(),'%s')]/following-sibling::p-dropdown/div/label";
	public static String SetdropDownValue = "xpath#//ul[contains(@class,'ui-dropdown-items')]/child::li/span[contains(text(),'%s')]";
	public static String SearchBtnMed = "xpath#//button/span[text()='Search']";
	public static String Hierachytermload = "xpath#//span[text()='LLT - Cold(10009851)']";
	public static String yesButton = "xpath#//p-confirmdialog//span[text()='Yes']/ancestor::button";

	public static String MedraLanguagePopUpClick = "xpath#//label[@class='ng-tns-c2-31 ui-dropdown-label ui-inputtext ui-corner-all ng-star-inserted']";
	public static String MeraLanguageDropdownValue = "xpath#//li/span[text()='English']";

	// Label Names
	public static String level_DropDown = "Level:";

	// company unit lookup click DropDown
	public static String clickDropDown(String label) {
		String value = clickDropDown.replace("%s", label);
		return value;
	}

	// set Dropdown value
	public static String SetdropDownValue(String data) {
		String value = SetdropDownValue.replace("%s", data);
		return value;
	}

}
