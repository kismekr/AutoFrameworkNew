package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class ValidationPageObjects {

	public static String validationsList = "xpath#//div[@id='agMandatoryContextCheck']/div/ol/li[@class='agValError ng-star-inserted']";
	public static String validationError = "xpath#//div[@id='agMandatoryContextCheck']/div/ol/li[@class='agValError ng-star-inserted']/a[contains(text(),'%tokenErrorId')]";

	public static String productInformation = "xpath#//a[text()='Product Information']";
	public static String confirmationOkButton = "xpath#//*[@class='searchOkbtn']/button/span[text()='OK']";
	public static String confirmationYesButton = "xpath#//button[contains(@class,'undefined ui-button ui-widget ui-state-default ui-corner-all ui-button-text-icon-left ng-star-inserted')]/span[text()='Yes']";
	public static String primarySourceCheckBox = "xpath#(//label[text()='Primary Source']//following::span/p-checkbox)[1]";
	public static String completeActivityYesButton = "xpath#//*[@id='mandatoryDialogform:yesButton']";
	public static String completeActivityOKButton = "xpath#//button[@id='mandatoryDialogform:okButton']";
	public static String completeActivityYesButtonLoading = "xpath#//label[contains(@id,'exportXmlviewForm') and text()='Loading']";

	public static String arrowIcon = "xpath#//img[contains(@src,'fde-expand-arrow.png')]";
	public static String literatureReferenceBox = "xpath#(//div[contains(@class,'ui-autocomplete-panel')]/ul/li/div[@class='agAutoCompPanelBody ng-star-inserted']/span)[1]";

	// unblinding blinding validations
	public static String validationAllList = "xpath#//div[@id='agMandatoryContextCheck']//li/a";
	public static String blindedProduct = "xpath#//li[contains(@class,'proTabBlindedClass')]//span[@class='ui-tabview-title']";
	public static String unBlindedProduct = "xpath#//li[contains(@class,'proTabUnBlindedClass')]//span[@class='ui-tabview-title']";
	public static String columnHeader = "xpath#(//div[@id='agMandatoryContextCheck']//li/a)[{%count}]";

	/**********************************************************************************************************
	 * @Objective:get substance name by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:Pooja S Date :4-Nov-2020 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderList(String num) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}

	/**********************************************************************************************************
	 * @Purpose: To get the validation error in single methods
	 * @author: Yashwanth Naidu
	 * @Pre-requisite: NA
	 * @Date :15-May-2020
	 * @Updated by and when:
	 **********************************************************************************************************/

	public static String selectValidation(String errorId) {
		String value = validationError.replace("%tokenErrorId", errorId);
		return value;

	}

	public static String selectValidationByIndex(String index) {
		String result = null;
		result = validationsList + "[" + index + "]";
		return result;
	}
}
