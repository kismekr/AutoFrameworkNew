package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.Set;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.HomePageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.LoginPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.DriverBrowser;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class LSMVLogin extends ToolManager {
	static String className = LSMVLogin.class.getSimpleName();
	public static WebElement webElement;
	static String loginWindow = null;
	static Set<String> allWindowHandles = null;
	static boolean status;
	static String[] skipData={"#skip#"};
	/**********************************************************************************************************
	 * @Objective: The below method is created to login to the application.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void Login(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (Constants.URL.length() > 0) {

			agNavigate(Constants.URL);

		} else {

			agNavigate(Multimaplibraries.getTestDataCellValue(scenarioName, "URL"));
		}
		agGetCurrentWindow();
		agSetValue(LoginPageObjects.userName, getTestDataCellValue(scenarioName, "userName"));
		agSetValue(LoginPageObjects.passWord, getTestDataCellValue(scenarioName, "password"));
		CommonOperations.captureScreenShot(true);
		agClick(LoginPageObjects.loginButton);
		agSetGlobalTimeOut("3");
		if (agIsVisible(LoginPageObjects.confirmationWindow) == true) {
			agClick(LoginPageObjects.okButton);
		}
		agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
		status = agIsVisible(HomePageObjects.headerSettingBlock);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "As Expected", false);

			//Reports.ExtentReportLog("Login", Status.PASS,"<br />"+ " User is logged in successfully and home page is displayed as per the User preference.", true);
			Reports.ExtentReportLog("", Status.PASS,"<br />"+ " URL: " + getTestDataCellValue(scenarioName, "URL"), false);
			Reports.ExtentReportLog("", Status.PASS,"<br />"+ " UserName: " + getTestDataCellValue(scenarioName, "userName"), false);
			if(scenarioName.contains("LSMV_OQ_AutoLabellingFunctionality")) {
				Reports.ExtentReportLog("", Status.PASS,"<br />"+ "Language:English", false);
			}

		} else {
			Reports.ExtentReportLog("Login", Status.FAIL, "User is logged in Unsuccessfull", true);}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to login to the application.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 17-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void resetPassword(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		LSMVLogin.Logout();
		
		//agNavigate(Multimaplibraries.getTestDataCellValue("Login", "URL"));
		agGetCurrentWindow();
		agSetValue(LoginPageObjects.userName, Admin_UsersOperations.getData(scenarioName, "UserName"));
		agSetValue(LoginPageObjects.passWord, Admin_UsersOperations.getData(scenarioName, "TemporaryPassword"));
		Reports.ExtentReportLog("", Status.INFO, "New User Credentials Entered : Scenario Name::" + scenarioName, true);
		agClick(LoginPageObjects.loginButton);
		if (agIsVisible(LoginPageObjects.confirmationWindow) == true) {
			agClick(LoginPageObjects.okButton);
		}
		agIsVisible(LoginPageObjects.oldPassword_TextBox);
		agSetValue(LoginPageObjects.oldPassword_TextBox, Admin_UsersOperations.getData(scenarioName, "TemporaryPassword"));
		agSetValue(LoginPageObjects.newPassword_TextBox, Admin_UsersOperations.getData(scenarioName, "Password"));
		agSetValue(LoginPageObjects.confirmNewPassword_TextBox, Admin_UsersOperations.getData(scenarioName, "Password"));
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Password Reset Section : Scenario Name::" + scenarioName, true);
		agGetCurrentWindow();
		agClick(LoginPageObjects.submit_button);
		CommonOperations.setAuditInfo("Password_Update");

		status = agIsVisible(HomePageObjects.headerSettingBlock);
		if (status) {
			Reports.ExtentReportLog("", Status.INFO, "Password Reseted Successfully", true);
		}
	}
	/**********************************************************************************************************
	 * @Objective: Login to application
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 17-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SignIn(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(LoginPageObjects.userName, getTestDataCellValue(scenarioName, "userName"));
		agSetValue(LoginPageObjects.passWord, getTestDataCellValue(scenarioName, "password"));
		CommonOperations.takeScreenShot();
		agClick(LoginPageObjects.loginButton);
		agSetGlobalTimeOut("3");
		if (agIsVisible(LoginPageObjects.confirmationWindow) == true) {
			agClick(LoginPageObjects.okButton);
		}
		agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
		agWaitTillInvisibilityOfElement(CaseListingPageObjects.oWS_SearchLoading);
		status = agIsVisible(HomePageObjects.headerSettingBlock);
		if (status) {
			Reports.ExtentReportLog("Login", Status.PASS, "Login Successfull", true);
		} else
			Reports.ExtentReportLog("Login", Status.FAIL, "Login Unsuccessfull", true);
	}
	
	/**********************************************************************************************************
	 * @Objective: Navigation to URL
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 17-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void NavigateToURL(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agNavigate(Multimaplibraries.getTestDataCellValue(scenarioName, "URL"));
		agGetCurrentWindow();
		status = agIsVisible(LoginPageObjects.userName);
		if (status) {
			Reports.ExtentReportLog("Navigate to URL", Status.PASS, "Navigate to URL Successfull", true);
		} else
			Reports.ExtentReportLog("Navigate to URL", Status.FAIL, "Navigate to URL Unsuccessfull", true);
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to logout from the application.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void Logout() {
		agWaitTillVisibilityOfElement(LoginPageObjects.LSMVDisplaySettings);
		agClick(LoginPageObjects.LSMVDisplaySettings);
		agWaitTillVisibilityOfElement(LoginPageObjects.LSMVLogout);
		agClick(LoginPageObjects.LSMVLogout);
		agClick(LoginPageObjects.LSMVLogoutConfirmationYes);	
		agSetGlobalTimeOut("5");
		if (agIsVisible(LoginPageObjects.loginButton)||agIsVisible(LoginPageObjects.logOutConfirmationText)) {

			Reports.ExtentReportLog("Logout", Status.PASS, "As Expected", true);
			Reports.ExtentReportLog("Logout", Status.PASS,"<br />" + "User is logged out successfully", false);
		}
		
		else
		{
			Reports.ExtentReportLog("Logout", Status.FAIL, "User logged out is Unsuccessfull."+"<br />", true);
		}
		agSetGlobalTimeOut("60");
		
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to know application build no and version from the application.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Kishore
	 * @Date : 6-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AboutLSMV(String scenarioName) {
		getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		agClick(LoginPageObjects.about);
		if (agIsVisible(LoginPageObjects.aboutSpan)) {
			Reports.ExtentReportLog("About", Status.PASS, "About Screen navigation sucessful", true);
		}
		else {
			Reports.ExtentReportLog("About", Status.FAIL, "About Screen navigation Unsuccessfull", true);
		}
		String buildNo=agGetText(LoginPageObjects.getFldVal(LoginPageObjects.buildNo));
		String licenseFor=agGetText(LoginPageObjects.getFldVal(LoginPageObjects.licseFor));
		System.out.println(buildNo+licenseFor);
		if (buildNo.equalsIgnoreCase(getTestDataCellValue(scenarioName, "BuildNo")) && licenseFor.contains(getTestDataCellValue(scenarioName,"VersionNo"))) {
			Reports.ExtentReportLog("About", Status.PASS, "Version No: "+licenseFor+ ", Build No:"+buildNo, true);
		}
		else {
			Reports.ExtentReportLog("About", Status.FAIL, "<br />" +"Expected Version: "+getTestDataCellValue(scenarioName, "VersionNo")+
					", Actual Version is: "+licenseFor+"\n", true);
			Reports.ExtentReportLog("About", Status.FAIL, "<br />"+ "Expected Build No: "+ getTestDataCellValue(scenarioName,"BuildNo") +
					", Actual Build No: "+buildNo+"\n", false);
		}
		agClick(LoginPageObjects.closeAbout);
		
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to lauch browser as when required
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date : 12-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void launchBrowser() {
		try {
			Constants.driver = DriverBrowser.launchBrowser("Chrome", "UI");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
