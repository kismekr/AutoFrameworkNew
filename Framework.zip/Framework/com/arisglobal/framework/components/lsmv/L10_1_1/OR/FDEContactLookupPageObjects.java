package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public abstract class FDEContactLookupPageObjects {

	public static String contactLookUpIcon = "xpath#//a[@class='agLookupLink ng-star-inserted']//img";
	public static String FirstNameTextbox = "xpath#//input[@name='firstName']";
	public static String LastNameTextbox = "xpath#//input[@name='lastName']";
	public static String SearchButton = "xpath#//button/span[text()='Search']";
	// public static String SearchButton =
	// "xpath#//div[@class='searchOkbtn']//span[text()='SEARCH']";
	public static String CheckBox = "xpath#//td[@class='agproSelcetRad']//div[@class='ui-chkbox-box ui-widget ui-state-default']";
	public static String OkButton = "xpath#//div[@class='searchOkbtn']/button/span[text()='OK']";

	public static String SerachBtn = "xpath#//button/span[text()='Search']";
	public static String contactTab = "xpath#//a[text()='Contact']";
											 
}
