package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_LiteraturePageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_Literature extends ToolManager {
	public static WebElement webElement;
	static String className = FDE_Literature.class.getSimpleName();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is to set Literature Information details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_LiteratureInformation(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (agIsVisible(FDE_LiteraturePageObjects.formView_Btn)) {
			agClick(FDE_LiteraturePageObjects.formView_Btn);
		}
		agSetValue(FDE_LiteraturePageObjects.articleTitle_Textbox,
				getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_ArticleTitle"));
		agSetValue(FDE_LiteraturePageObjects.journalTitle_Textbox,
				getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_JournalTitle"));
		agSetValue(FDE_LiteraturePageObjects.publicationDate_Textbox, CommonOperations.returnDateTime(
				getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_PublicationDate")));
		agSetValue(FDE_LiteraturePageObjects.issue_Textbox,
				getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_Issue"));
		agSetValue(FDE_LiteraturePageObjects.pageFrom_Textbox,
				getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_PageFrom"));
		agSetValue(FDE_LiteraturePageObjects.pageTo_Textbox,
				getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_PageTo"));
		agSetValue(FDE_LiteraturePageObjects.edition_Textbox,
				getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_Edition"));
		agSetValue(FDE_LiteraturePageObjects.digitalObjectIdentifier_Textbox,
				getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_DigitalObjectIdentifierDOI"));
		agSetValue(FDE_LiteraturePageObjects.additionalLiteratureInfo_Textbox,
				getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_AdditionalLiteratureInformation"));
		agSetValue(FDE_LiteraturePageObjects.literatureReference_Textbox,
				getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_LiteratureReference"));
		if (getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_RetainLiteratureReference")
				.equalsIgnoreCase("true")) {
			agClick(FDE_LiteraturePageObjects.retainLiteratureReference);
		}

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Literature >> Literature Information Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Verify Literature Information details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void literatureInformation_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Multimaplibraries.getTestDataCellLength(scenarioName, "Literature_LiteratureInformation_ArticleTitle");
		for (int j = 1; j <= Constants.testDataParentLength; j++) {
			Constants.testDataChildLoopCount = j;

			if (j >= 1) {
				if (!agIsVisible(FDE_LiteraturePageObjects.clickMultipleLitretature(Integer.toString(j)))) {
					agJavaScriptExecuctorClick(FDE_LiteraturePageObjects.navigaterClick);
				}

				agClick(FDE_LiteraturePageObjects.clickMultipleLitretature(Integer.toString(j)));

				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

			if (agIsVisible(FDE_LiteraturePageObjects.formView_Btn)) {
				agClick(FDE_LiteraturePageObjects.formView_Btn);
			}
			agCheckPropertyValue("value",
					getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_ArticleTitle"),
					FDE_LiteraturePageObjects.articleTitle_Textbox);
			agCheckPropertyValue("value",
					getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_JournalTitle"),
					FDE_LiteraturePageObjects.journalTitle_Textbox);
			agClick(FDE_LiteraturePageObjects.publicationDate_Textbox);
			agCheckPropertyValue("title",
					CommonOperations.returnDateTime(
							getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_PublicationDate")),
					FDE_LiteraturePageObjects.publicationDate_Textbox);
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_Issue"),
					FDE_LiteraturePageObjects.issue_Textbox);
			agCheckPropertyValue("value",
					getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_PageFrom"),
					FDE_LiteraturePageObjects.pageFrom_Textbox);
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_PageTo"),
					FDE_LiteraturePageObjects.pageTo_Textbox);
			agCheckPropertyValue("value",
					getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_Edition"),
					FDE_LiteraturePageObjects.edition_Textbox);
			agCheckPropertyValue("value",
					getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_DigitalObjectIdentifierDOI"),
					FDE_LiteraturePageObjects.digitalObjectIdentifier_Textbox);
			agCheckPropertyValue("value",
					getTestDataCellValue(scenarioName,
							"Literature_LiteratureInformation_AdditionalLiteratureInformation"),
					FDE_LiteraturePageObjects.additionalLiteratureInfo_Textbox);
			CommonOperations.verifyCheckBoxUnder("Retain Literature Reference",
					getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_RetainLiteratureReference"));
			agCheckPropertyValue("value",
					getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_LiteratureReference"),
					FDE_LiteraturePageObjects.literatureReference_Textbox);

			Reports.ExtentReportLog("", Status.INFO,
					"Data Verification in Literature >> Literature_00" + j + "::" + scenarioName, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Upload and verify document in literature
	 *             tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_LiteratureFileUpload(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String fileName = Multimaplibraries.getTestDataCellValue(scenarioName,
				"Literature_LiteratureInformation_LiteratureDocumentName");
		if (!fileName.equalsIgnoreCase("#skip#")) {
			agSetValue(FDE_LiteraturePageObjects.litDocNameUpload_Button,
					lsmvConstants.LSMV_testDataInput + "\\" + fileName);
			agSetStepExecutionDelay("6000");
			agAssertVisible(CommonPageObjects.linkText(fileName));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Literature >> Literature Document Name Section : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to set literature in literature tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 02-Dec-2019
	 * @UpdatedByAndWhen: Avinash k 29-Aug-2020
	 **********************************************************************************************************/
	public static void set_Literature(String scenarioName) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,
		// "ConfigurationSettings");
		// if (getTestDataCellValue(scenarioName,
		// "FDE_Literature").equalsIgnoreCase("Yes")) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Multimaplibraries.getTestDataCellLength(scenarioName, "Literature_LiteratureInformation_ArticleTitle");
		for (int j = 1; j <= Constants.testDataParentLength; j++) {
			Constants.testDataChildLoopCount = j;
			if (j > 1) {
				agClick(FDE_LiteraturePageObjects.add_button);
				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			set_LiteratureInformation(scenarioName);
			set_LiteratureFileUpload(scenarioName);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Literature >> Literature_00" + j + "::" + scenarioName, true);
		}
		// }
	}

	/**********************************************************************************************************
	 * @Objective: Verify R2 tags in Literature tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 20-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyLiteratureR2Tags() {
		Reports.ExtentReportLog("", Status.INFO, "********Literature R2 tag verification Started*******", true);
		agAssertVisible(FDE_LiteraturePageObjects.R2LiteratureReference);
		Reports.ExtentReportLog("", Status.INFO, "********Literature R2 tag verification Completed*******", true);
	}
	
	/**********************************************************************************************************
	 * @Objective: Verify R3 tags in Literature tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 20-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyLiteratureR3Tags() {
		Reports.ExtentReportLog("", Status.INFO, "********Literature R3 tag verification Started*******", true);
		agAssertVisible(FDE_LiteraturePageObjects.R3LiteratureReference);
		agAssertVisible(FDE_LiteraturePageObjects.R3LiteratureDocumentName);
		Reports.ExtentReportLog("", Status.INFO, "********Literature R3 tag verification Completed*******", true);
	}
}