package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public abstract class FDE_CaseDocumentsPageObjects {

	/* Unchanged */public static String fileName_Link = "xpath#//td[@class='file_input_div case_doc_upload']/div/a";

	// SourceDocs
	public static String sourceDocuments_Label = "xpath#//label[text()='Source Documents']";
	public static String sourceDocuments_AddButton = "xpath#//button[@onclick='AddSourceDoc();']";
	public static String sourceDocuments_DeleteButton = "xpath#//a[@id='adverseEventNew:sourceDelete']";
	// public static String sourceDocuments_DocDesc =
	// "xpath#//input[contains(@id,'%s:sourceUpload_input')]//ancestor::td[1]//preceding::input[contains(@id,'%s:description')]";
	// public static String sourceDocuments_DocDesc =
	// "xpath#//input[contains(@id,'%s:sourceUpload_input')]//ancestor::td[1]//preceding::input[contains(@name,'%s:description')]";
	public static String sourceDocuments_DocDesc = "xpath#//input[contains(@class,'sourceDocDescription form-control suportDocInfo%s')]";
	public static String CheckOutConfirmMsg = "xpath#//label[contains(text(),'Check-out the document')]";
	public static String ConfirmationOkBtn = "xpath#//button[contains(@onclick,'checkoutSourceDoc')]";
	public static String SupportConfirmationOkBtn = "xpath#//button[contains(@onclick,'checkoutSupportDoc')]";
	public static String sourceDocuments_UploadChekoutFile = "xpath#//label[contains(text(),'Choose a file')]";
	public static String sourceDocuments_CheckOut = "xpath#(//a[contains(@onclick,'checkoutInConformationDialog')]//img)[%s]";
	public static String sourceDocuments_CheckIn = "xpath#//a[contains(@onclick,'renderSourceDocumentUploadDialog')]//img";
	public static String supportDocuments_UploadChekoutFile = "xpath#//label[contains(text(),'Choose a file')]";
	public static String supportDocuments_CheckOut = "xpath#//a[contains(@onclick,'checkoutInSupportConformationDialog')]//img";
	public static String supportDocuments_CheckIn = "xpath#//a[contains(@onclick,'renderSupportDocumentUploadDialog')]//img";
	public static String sourceDocuments_FileName = "xpath#//a[contains(@id,'%s:viewFileLink')]";
	// public static String sourceDocuments_UploadFile =
	// "xpath#//input[contains(@id,'sourceUpload_input')]";
	public static String sourceDocuments_DeleteFile = "xpath#//a[contains(@onclick,'deleteSourceDocConfirm')]//img[contains(@id,':%s:')]";
	public static String sourceDocuments_DocVer = "xpath#//span[contains(@id,'%s:viewSrcDocVersionLink')]//img";
	// public static String sourceDocuments_DocCategory =
	// "xpath#//label[contains(@id,'%s:A1-316_label')]";
	public static String sourceDocuments_DocCategory = "xpath#(//select[@class='form-control updateCaseCategory'])[%s]";
	// public static String sourceDocuments_CheckOut =
	// "xpath#//a[contains(@id,'%s:chkOutLinkId1')]//img";
	// public static String sourceDocuments_IsLocalCheck =
	// "xpath#//div[contains(@id,'%s:isLocalDoc')]//span[contains(@class,'ui-chkbox-icon')]";
	public static String sourceDocuments_IsLocalCheck = "xpath#(//td[@class='case_isLocal']//input)[%s]";
	// public static String sourceDocuments_IsIncludedCheck =
	// "xpath#//input[contains(@id,'%s:isIncluded_input')]//..//following-sibling::div//span[contains(@class,'ui-chkbox-icon')]";
	public static String sourceDocuments_IsIncludedCheck = "xpath#(//td[@class='case_isInclude']/input)[%s]";
	public static String docIsDisabled = "xpath#//a[@class='disableLink']";
	public static String sourceDocuments_LiteratureDocCheck = "xpath#//div[contains(@id,'%s:literatureDoc')]//span[contains(@class,'ui-chkbox-icon')]";
	public static String sourceDocuments_DateLabel = "xpath#//label[contains(@id,'%s:date-SYSD')]";
	public static String sourceDocuments_FileSizeLabel = "xpath#//label[contains(@id,'%s:fileSize')]";
	public static String sourceDocuments_RedactDoc = "xpath#//span[contains(@id,'0:viewSrcReduceDocVersionLink')]//img";
	public static String SourceDocuments_DocCategoryClick = "xpath#//div[@class='ui-selectonemenu ui-widget ui-state-default ui-corner-all autoWidthNew']";
	public static String sourceDocuments_OKButton = "xpath#//button[@id='mandatoryDialogform:okButton']//span[text()='OK']";
	// public static String clickDocumentCategory =
	// "xpath#//table[@class='souceTableSc']//div[contains(@id,'%index%:A1-316')]/parent::td[@class='sourcetd5']";
	public static String clickDocumentCategory = "xpath#//select[@class='form-control updateCaseCategory']";

	public static String clickDocumentCategoryFile2 = "xpath#//label[@id='adverseEventNew:j_id_2k9_u:1:A1-316_label']";
	public static String setDocumentCategory = "xpath#//ul[contains(@id,'adverseEventNew')]/child::li[text()='%s']";
	public static String setDocumentCategoryFile2 = "xpath#//ul[contains(@id,'adverseEventNew:j_id_2k9_u:1:A1-316')]/child::li[contains(text(),'%s')]";

	public static String filenameLink = "xpath#(//a[contains(@id,'docNmae')])[1]";
	public static String filenameLink1 = "xpath#(//a[contains(@id,'docNmae')])[2]";
	// public static String sourceDocuments_UploadFile =
	// "xpath#//input[contains(@id,'%s:sourceUpload_input')]//ancestor::td[1]//preceding::input[contains(@name,'%s:sourceUpload_input')]";
	public static String sourceDocuments_UploadFile = "xpath#(//input[contains(@onchange,'sourceDocGetFileName(event)')])[%s]";
	// public static String uploadfile_label = "xpath#//label[text()='INFO : ']";
	public static String uploadfile_label = "xpath#//label[contains(text(),'uploaded Successfully')]";
	public static String sourcecategory_textbox = "xpath#//input[@name='adverseEventNew:j_id_2k5_u:0:A1-316_filter']";

	public static String setsourcedocumentcategory = "xpath#//ul[contains(@id,'adverseEventNew:SupportDoc:{0}:')]/child::li[text()='%s']";

	// case summary doc
	public static String casesummarypdflink = "xpath#//a[contains(@id,'SupportDoc:%s:viewAttachFileLink')]";
	public static String aerversionno = "xpath#//tr[contains(@id,'adverseEventNew:caseVersionDocs')]/td[1]";

	public static String sourceDoc = "xpath#//div[@class='fileAction']/a[@id='docNmae']";
	public static String supportDoc = "xpath#(//div[@class='fileAction']/a[@id='suportdocNmae'])[2]";

	public static String PageNoPdf1 = "xpath#//input[@id='pageNumber']";
	public static String PageNoPdf2 = "xpath#//span[@id='numPages']";

	public static String DeleteSourceDocument = "xpath#(//input[@name='SourceDocument'])[%s]";
	public static String DeleteSupportDocument = "xpath#(//input[@name='supportDoc'])[%s]";
	public static String DeleteBtnSourceDocument = "xpath#//button[@onclick='deleteSourceDoc();']";
	public static String DeleteBtnSupportDocument = "xpath#//button[@onclick='deleteSuportDocRow()']";
	public static String DeleteOkBtn = "xpath#//button[text()='Ok']";
	public static String DeleteYesBtn = "xpath#//div[@class='bg-default']//button[text()='Yes']";

	public static String disableLink = "xpath#//a[not(@class='disableLink') and text()='local1.pdf']";
	public static String EnableLink = "xpath#//a[not(@class='disableLink') and @id='docNmae']";

	/**********************************************************************************************************
	 * @Objective:The below method is created to select the document category by
	 *                passing index
	 * @Input Parameters: index
	 * @Output Parameters:
	 * @author: Pooja S on 20-May-2020
	 **********************************************************************************************************/
	public static String clikcDocmentCategory(String index) {
		String value = clickDocumentCategory.replace("%index%", index);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to verify the case summary pdf
	 *                available at run time.
	 * @Input Parameters: index, label
	 * @Output Parameters:
	 * @author: Pooja S on 21-Apr-2020
	 **********************************************************************************************************/
	public static String verifycasesummarypdf(String index) {
		String value = casesummarypdflink.replace("%s", index);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to set Document Category at run time.
	 * @Input Parameters: index, label
	 * @Output Parameters:
	 * @author: Pooja S on 21-Apr-2020
	 **********************************************************************************************************/
	public static String setSupportDocCategory(String index, String label) {
		String value = setsourcedocumentcategory.replace("{0}", index);
		String value1 = value.replace("%s", label);
		return value1;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to set the description at run time.
	 * @Input Parameters: Scenario Name
	 * @Output Parameters:
	 * @author: Avinash k Date : 26-Jul-2019 Updated by and when: Mithun M P on
	 *          18-Feb-2020
	 **********************************************************************************************************/
	public static String sourceDocuments_DocDesc(String index) {
		String value = sourceDocuments_DocDesc;
		String value2;
		value2 = value.replace("%s", index);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get FileName at run time.
	 * @Input Parameters: Scenario Name
	 * @Output Parameters:
	 * @author: Avinash k Date : 26-Jul-2019 Updated by and when: Mithun M P on
	 *          18-Feb-2020
	 **********************************************************************************************************/
	public static String sourceDocuments_FileName(String index) {
		String value = sourceDocuments_FileName;
		String value2;
		value2 = value.replace("%s", index);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to upload the document at run time.
	 * @Input Parameters: Scenario Name
	 * @Output Parameters:
	 * @author: Avinash k Date : 26-Jul-2019 Updated by and when:Mithun M P on
	 *          18-Feb-2020
	 **********************************************************************************************************/
	public static String sourceDocuments_UploadFile(String index) {
		String value = sourceDocuments_UploadFile;
		String value2;
		value2 = value.replace("%s", index);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Delete File at run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author: Mithun M P on 18-Feb-2020
	 **********************************************************************************************************/
	public static String sourceDocuments_DeleteFile(String num) {
		String value = sourceDocuments_DeleteFile.replace("%s", num);
		return value;

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Document Version at run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author: Mithun M P on 18-Feb-2020
	 **********************************************************************************************************/
	public static String sourceDocuments_DocVer(String num) {
		String value = sourceDocuments_DocVer.replace("%s", num);
		return value;

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Document Category at run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author: Mithun M P on 18-Feb-2020
	 **********************************************************************************************************/
	public static String sourceDocuments_DocCategory(String num) {
		String value="";
		if(num.equalsIgnoreCase("0"))
			value=sourceDocuments_DocCategory.replace("[%s]", "");
		else
		 value = sourceDocuments_DocCategory.replace("%s", num);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Document checkout at run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author: Mithun M P on 18-Feb-2020
	 **********************************************************************************************************/
	public static String sourceDocuments_CheckOut(String num) {
		String value = sourceDocuments_CheckOut.replace("%s", num);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Document checkout at run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author: Mythri Jain on 09-Dec-2020
	 **********************************************************************************************************/
	public static String sourceDocuments_CheckIn(String num) {
		String value = sourceDocuments_CheckIn.replace("%s", num);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Is Local Checkbox at run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author: Mithun M P on 18-Feb-2020
	 **********************************************************************************************************/
	public static String sourceDocuments_IsLocalCheck(String num) {
		String value = sourceDocuments_IsLocalCheck.replace("%s", num);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Is Included Checkbox at run
	 *                time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author: Mithun M P on 18-Feb-2020
	 **********************************************************************************************************/
	public static String sourceDocuments_IsIncludedCheck(String num) {
		String value = sourceDocuments_IsIncludedCheck.replace("%s", num);
		return value;

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Literature Doc Checkbox at run
	 *                time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author: Mithun M P on 18-Feb-2020
	 **********************************************************************************************************/
	public static String sourceDocuments_LiteratureDocCheck(String num) {
		String value = sourceDocuments_LiteratureDocCheck.replace("%s", num);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Date Label at run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author: Mithun M P on 18-Feb-2020
	 **********************************************************************************************************/
	public static String sourceDocuments_DateLabel(String num) {
		String value = sourceDocuments_DateLabel.replace("%s", num);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get FileSize at run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author: Mithun M P on 18-Feb-2020
	 **********************************************************************************************************/
	public static String sourceDocuments_FileSizeLabel(String num) {
		String value = sourceDocuments_FileSizeLabel.replace("%s", num);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get RedactDoc at run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author: Mithun M P on 18-Feb-2020
	 **********************************************************************************************************/
	public static String sourceDocuments_RedactDoc(String num) {
		String value = sourceDocuments_RedactDoc.replace("%s", num);
		return value;
	}

	// SupportingDocs
	public static String supportDocs_AddButton = "xpath#//button[contains(@onclick,'addSuportDocumentRows')]";
	public static String supportDocs_DeleteButton = "xpath#//a[@id='adverseEventNew:supDelete']";
	public static String supportDocs_label = "xpath#//div[contains(text(),'Support Documents')]";
	public static String supportDocs_DocDesc = "xpath#//input[contains(@class,'suportInfo%s supportDocDescription')]";
	public static String supportDocs_FileName = "xpath#//a[contains(@id,'%s:viewAttachFileLink')]";
	public static String supportDocs_UploadFile = "xpath#(//input[contains(@onchange,'supportGetFileName')])[%s]";

	// public static String supportDocs_UploadFile =
	// "xpath#//input[contains(@id,'%s:supportDocUpload_input')]//ancestor::td[1]//preceding::input[contains(@name,'%s:supportDocUpload_input')]";
	public static String supportDocs_DocVer = "xpath#//a[@id='adverseEventNew:SupportDoc:%s:viewSrcDocVersionLink']";
	public static String supportDocs_DocCategory = "xpath#(//select[@class='form-control updateCaseSupportCategory'])[%s]";
	public static String supportDocs_CheckOut = "xpath#//img[contains(@src,'checkout.png')][contains(@id,'SupportDoc:%s')]";
	public static String supportDocs_IsLocalCheck = "xpath#(//table[contains(@class,'supportContent')]//tr[@id='updateSupportObj']/td[@class='suport_doc_local']/input)[%s]";
	public static String supportDocs_IsIncludedCheck = "xpath#//div[contains(@id,'%s:isIncludedsupport')]//span[contains(@class,'ui-chkbox-icon')]";
	public static String supportDocs_LiteratureDocCheck = "xpath#//div[contains(@id,'%s:supportliteratureDoc')]//span[contains(@class,'ui-chkbox-icon')]";
	public static String supportDocs_DateLabel = "xpath#//label[contains(@id,'%s:supDocDate')]";
	public static String supportDocs_FileSizeLabel = "xpath#//label[contains(@id,'%s:supDocFileSize')]";

	public static String FileName = "xpath#//a[@title='local1.pdf']";
	public static String supportFileName = "xpath#//a[@id='suportdocNmae']";
	public static String supportFileNameCount = "xpath#(//a[@id='suportdocNmae'])[%count%]";

	public static String fileNameCount(String count) {
		String value = supportFileNameCount.replace("%count%", count);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Support Document Description at
	 *                run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author: Mithun M P Date : 18-Feb-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String supportDocs_DocDesc(String num) {
		String value = supportDocs_DocDesc.replace("%s", num);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to send index at run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author: Avinash k Date : 16-Oct-2019 Updated by and when:Mithun M P on
	 *          18-Feb-2020
	 **********************************************************************************************************/

	public static String supportDocs_FileName(String num) {
		String value = supportDocs_FileName.replace("%s", num);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Upload File Link at run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author: Mithun M P Date : 18-Feb-2020
	 **********************************************************************************************************/
	public static String supportDocs_UploadFile(String index) {
		String value="";
		if(index.equalsIgnoreCase("0"))
			value=supportDocs_UploadFile.replace("[%s]", "");
		else
		 value = supportDocs_UploadFile.replace("%s", index);
		return value;

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Support Document version at run
	 *                time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author: Avinash k Date : 16-Oct-2019 Updated by and when:Mithun M P on
	 *          18-Feb-2020
	 **********************************************************************************************************/
	public static String supportDocs_DocVer(String num) {
		String value = supportDocs_DocVer.replace("%s", num);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Support Document Category at
	 *                run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author:Mithun M P Date: 18-Feb-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String supportDocs_DocCategory(String num) {
		

		String value="";
		if(num.equalsIgnoreCase("0"))
			value=supportDocs_UploadFile.replace("[%s]", "");
		else
		 value = supportDocs_UploadFile.replace("%s", num);
		return value;
		
	
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Support Document Checkout at
	 *                run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author:Mithun M P Date: 18-Feb-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String supportDocs_CheckOut(String num) {
		String value = supportDocs_CheckOut.replace("%s", num);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get is Local checkbox at run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author:Mithun M P Date: 18-Feb-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String supportDocs_IsLocalCheck(String num) {
		String value = supportDocs_IsLocalCheck.replace("%s", num);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get is included checkbox at run
	 *                time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author:Mithun M P Date: 18-Feb-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String supportDocs_IsIncludedCheck(String num) {
		String value = supportDocs_IsIncludedCheck.replace("%s", num);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Literature doc checkbox at run
	 *                time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author:Mithun M P Date: 18-Feb-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String supportDocs_LiteratureDocCheck(String num) {
		String value = supportDocs_LiteratureDocCheck.replace("%s", num);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get date label at run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author:Mithun M P Date: 18-Feb-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String supportDocs_DateLabel(String num) {
		String value = supportDocs_DateLabel.replace("%s", num);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get date label at run time.
	 * @Input Parameters: num
	 * @Output Parameters:
	 * @author:Mithun M P Date: 18-Feb-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String supportDocs_FileSizeLabel(String num) {
		String value = supportDocs_FileSizeLabel.replace("%s", num);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get data at run time.
	 * @Input Parameters: data
	 * @Output Parameters:
	 * @author:Mythri Jain Date: 02-Mar-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String setDocumentCategory(String data) {
		String value = setDocumentCategory.replace("%s", data);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get data at run time.
	 * @Input Parameters: data
	 * @Output Parameters:
	 * @author:WajahatUmar S Date: 02-Mar-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String setDocumentCategoryFile2(String data) {
		String value = setDocumentCategoryFile2.replace("%s", data);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get data at run time.
	 * @Input Parameters: data
	 * @Output Parameters:
	 * @author:WajahatUmar S Date: 02-Mar-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String CheckSourceFile(String data) {
		String value = DeleteSourceDocument.replace("%s", data);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get data at run time.
	 * @Input Parameters: data
	 * @Output Parameters:
	 * @author:WajahatUmar S Date: 02-Mar-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String CheckSuportFile(String data) {
		String value = DeleteSupportDocument.replace("%s", data);
		return value;
	}
}