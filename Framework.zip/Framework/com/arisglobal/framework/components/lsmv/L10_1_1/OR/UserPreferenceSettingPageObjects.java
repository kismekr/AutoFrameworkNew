package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class UserPreferenceSettingPageObjects {

	public static String LSMV_UserPrefernce = "xpath#//div[@id='headerForm:settingsBlock']/div[@class='headIconRight compheadIconRight']/div[@class='AdvanceSe-tooltip inqColorWidth']/div[@class='tooltipAct tooltipInqList navigationFixed usertolltipsty agSavePrefrance']/div[@class='UserPreIcon']/a[@id='headerForm:preferences']";
	public static String EventListingSortOrderAscending = "xpath#//table[@id='userPreferencesForm:primarySortOrder']//label[text()='Ascending']/preceding-sibling::div//span";
	public static String EventListingSortOrderDesending = "xpath#//table[@id='userPreferencesForm:primarySortOrder']//label[text()='Descending']/preceding-sibling::div//span";
	public static String UserPrefernceSaveBtn = "xpath#//button[@id='userPreferencesForm:visibleSave']/span[text()='Save']";
	public static String ConfirmationMsg = "xpath#//span[@id='mandatoryDialogform:mandatoryID_title']";
	public static String ConfirmationOkBtn = "xpath#//button[@id='mandatoryDialogform:okButton']//span[text()='OK']";
	public static String oddRecptNumber = "xpath#(//a[@class='receiptNoSty'])[2]";
	public static String EvenRecptNumber = "xpath#(//a[@class='receiptNoSty'])[3]";

	public static String PrimarySortColumnDropDown = "xpath#//div[@id='userPreferencesForm:selectPrimarySort']";
	public static String PrimarySortColumnDDValue = "xpath#//ul[@id='userPreferencesForm:selectPrimarySort_items']//li[text()='Receipt No.']";
}
