package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class Lib_IMEDME_PageObjects {
	
	
	public static String clickeventversion_Dropdown = "xpath#//label[@id='imeListingId:medDRAVerOnemenu_label']/following-sibling::div/span";
	public static String event_version = "xpath#//ul[@id='imeListingId:medDRAVerOnemenu_items']/li[text()='%s']";
	public static String keywordSearch_Textbox = "xpath#//input[@id='imeListingId:keyword']";
	public static String search_Icon = "xpath#//a[@id='imeListingId:defaultSearch']";
	public static String paginator = "xpath#//div[@id='imeListingId:imeFormDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String get_ListofIMEDMEEvents = "xpath#//tbody[@id='imeListingId:imeFormDataTable_data']/ancestor::table/tbody/tr/td[3]";
	public static String columnHeader = "xpath#(//tbody[@id='imeListingId:imeFormDataTable_data']/ancestor::table/tbody/tr/td[3])[{%count}]";
	public static String imeDME_Lable = "xpath#//div[@id='imeDetailsForm:imePanel_header']//label[text()='IME/DME Management']";
	public static String imeDMEEventMedDRAPTTerm_lookup = "xpath#//a[@id='imeDetailsForm:reactionMeddraLookup']/img";
	public static String dictionaryCodingBrowser_SearchTxtfield = "xpath#//input[@name='term']";
	public static String dictionaryCodingBrowser_SearchBtn = "xpath#//button/span[text()='Search']";
	public static String dictionaryCodingBrowser_OkBtn = "xpath#//div[contains(@class,'searchOkbtn dictCodingOk')]//button/span[text()='Ok']";
	public static String saveButton = "xpath#//div[@id='imeDetailsForm:panelGroupTop']//button[@id='imeDetailsForm:visibleSave']/span[text()='Save']";
	public static String isDME_Checkbox = "Is DME";
	public static String isIME_Checkbox = "Is IME";
	public static String activeCheckbox = "Active";
	public static String typeDropdown = "xpath#//label[@id='imeDetailsForm:stdImeChekbox_label']";
	public static String comment_Textbox = "xpath#//textarea[@id='imeDetailsForm:commenttxtA']";
	public static String get_IMDMEEventMedDRAPTTerm = "xpath#//input[@id='imeDetailsForm:medraPTtermtxt_input']";
	public static String get_MedDRAPTCode = "xpath#//input[@id='imeDetailsForm:medraCodetxt']";
	public static String get_SOCName = "xpath#//input[@id='imeDetailsForm:socNametxt']";
	public static String active_checkbox = "Active";
	public static String edit_Icon = "xpath#//img[@id='imeListingId:imeFormDataTable:0:editIcon']";
	public static String cancelButton = "xpath#//button[@id='imeDetailsForm:cancelId']";
	public static String get_PtTerm = "xpath#//tbody[@id='imeListingId:imeFormDataTable_data']/tr/td[contains(@class,'EditIcon')]/following-sibling::td[1]";
	public static String new_Btn = "xpath#//a[@id='imeListingId:newId']";
	public static String AddIMEDEMEVentVer_Dropdown = "xpath#//div[@id='imeListingId:medDRAVerOnemenu']";
	public static String addversion_Btn = "xpath#//a[@id='imeListingId:meddraAddBtn']";
	public static String validationPopup_Btn = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String validationOK_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']/span";
	public static String checkbox = "xpath#//div/label[text()='%s']/following-sibling::div//span";
	
	public static String downloadTemplate_Btn = "xpath#//a[@id='imeListingId:downloadStdtemplatelnk']";
	public static String import_btn = "xpath#//div[@id='imeListingId:excelfileimportId']";
	public static String importfile = "xpath#//div//span[text()='Import']/following-sibling::input";
	
	
	public static String version = "Version v.22.1";

	/**********************************************************************************************************
	 * @Objective:click based on version name by passing input Parameters:rowNum
	 *                  Output
	 * @Parameters: Case data attribute value
	 * @author:Pooja S Date :05-June-2020 Updated by and when
	 **********************************************************************************************************/
	public static String eventVersion(String num) {
		String value = event_version;
		String value2;
		value2 = value.replace("%s", num);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:get event name by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author: Pooja S Date :05-June-2020 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderList(String num) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:get event name by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author: Avinash k Date :25-Nov-2020 Updated by and when
	 **********************************************************************************************************/
	public static String checkbox(String num) {
		String value = checkbox;
		String value2;
		value2 = value.replace("%s", num);
		return value2;
	}

}
