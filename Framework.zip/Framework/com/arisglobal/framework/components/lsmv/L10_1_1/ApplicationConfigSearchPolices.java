package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AdministrationPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ApplicationConfigSearchPolices_PageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;

public class ApplicationConfigSearchPolices extends ToolManager {
	public static String className = ApplicationConfigSearchPolices.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Navigate to search policies menu
	 * @InputParameters:Policy Name
	 * @OutputParameters:
	 * @author: Chithuraj R
	 * @Date : 20.1.2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void menuNavigation(String pageObject) {

		agMouseHover(AdministrationPageObjects.administrationHover);
		agJavaScriptExecuctorClick(pageObject);
	}

	/**********************************************************************************************************
	 * @Objective: Get search policies list
	 * @InputParameters:
	 * @OutputParameters:Get search policy list into excel
	 * @author: Chithuraj R
	 * @Date : 20.1.2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Map<String, String> getSearchPoliciesValue(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		AdministrationOperations.selectSearchPolicies(ApplicationConfigSearchPolices_PageObjects.searchPolicies);

		String[] columnName = { "POLICY NAME", "POLICY TYPE", "DESCRIPTION", "REPORT TYPE", "SOURCE", "DEFAULT",
				"STATUS", "USER MODIFIED", "DATE MODIFIED" };
		List<String> srchVal = new ArrayList<>();
		int policyName = 0, policyType = 0, description = 0, reportType = 0, source = 0, idefault = 0, status = 0,
				usermodified = 0, datemodified = 0;
		Map<String, String> srchValMap = new HashMap<String, String>();

		List<WebElement> searchPolicyTabHeaders = agGetElementList(
				ApplicationConfigSearchPolices_PageObjects.searchPolicyTableHeader);
		for (WebElement searchPolicyTableColName : searchPolicyTabHeaders) {
			srchVal.add(searchPolicyTableColName.getText());
		}

		for (int i = 0; i <= srchVal.size() - 1; i++) {

			switch (srchVal.get(i)) {
			case "POLICY NAME":
				policyName = i;
				break;
			case "POLICY TYPE":
				policyType = i;
				break;
			case "DESCRIPTION":
				description = i;
				break;
			case "REPORT TYPE":
				reportType = i;
				break;
			case "SOURCE":
				source = i;
				break;
			case "DEFAULT":
				idefault = i;
				break;
			case "STATUS":
				status = i;
				break;
			case "USER MODIFIED":
				usermodified = i;
				break;
			case "DATE MODIFIED":
				datemodified = i;
				break;
			}
		}

		srchVal.clear();
		List<WebElement> searchpolicyList = agGetElementList(
				ApplicationConfigSearchPolices_PageObjects.searchPolicylist);

		for (int i = 1; i <= searchpolicyList.size(); i++) {
			List<WebElement> policyValue = agGetElementList(
					ApplicationConfigSearchPolices_PageObjects.searchPolicyCollist(i));
			for (WebElement iPolicyValue : policyValue) {
				srchVal.add(iPolicyValue.getText());
			}
			if (srchVal.get(policyName).contentEquals(scenarioName)) {

				srchValMap.put(columnName[0], srchVal.get(policyName));
				srchValMap.put(columnName[1], srchVal.get(policyType));
				srchValMap.put(columnName[2], srchVal.get(description));
				srchValMap.put(columnName[3], srchVal.get(reportType));
				srchValMap.put(columnName[4], srchVal.get(source));
				srchValMap.put(columnName[5], srchVal.get(idefault));
				srchValMap.put(columnName[6], srchVal.get(status));
				srchValMap.put(columnName[7], srchVal.get(usermodified));
				srchValMap.put(columnName[8], srchVal.get(datemodified));
				break;
			} else {
				srchVal.clear();
			}
			srchVal.clear();
		}

		for (int i = 0; i <= columnName.length - 1; i++) {
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, columnName[i],
					srchValMap.get(columnName[i]));
		}
		return srchValMap;
	}

	/**********************************************************************************************************
	 * @Objective: Reading Edit policy page
	 * @InputParameters:Policy Name
	 * @OutputParameters:Read Policy edit page data into testdata
	 * @author: Chithuraj R
	 * @Date : 18.1.2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void readPolicyLevelDetails(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		AdministrationOperations.selectSearchPolicies(ApplicationConfigSearchPolices_PageObjects.searchPolicies);
		agSetStepExecutionDelay("3000");
		agClick(ApplicationConfigSearchPolices_PageObjects.clickEdit(scenarioName));

		Map<String, String> config = new HashMap<String, String>();

		String policyName = agGetAttribute("value", ApplicationConfigSearchPolices_PageObjects.policyName);
		String reportType = agGetText(ApplicationConfigSearchPolices_PageObjects.reportType);
		String activeSourceType = agGetText(ApplicationConfigSearchPolices_PageObjects.activeSource);

		String defaultActiveCheckbox = agIsExists(ApplicationConfigSearchPolices_PageObjects.defaultActiveCheckbox).toString();
		if (defaultActiveCheckbox == "false")
			defaultActiveCheckbox = "NotChecked";
		else
			defaultActiveCheckbox = "Checked";

		String statusActiveRadio = agGetText(ApplicationConfigSearchPolices_PageObjects.statusActiveRadioButton);
		String policyType = agGetText(ApplicationConfigSearchPolices_PageObjects.policyActiveoption);
		String ruleBuilder = agGetText(ApplicationConfigSearchPolices_PageObjects.ruleBuilder);
		if (ruleBuilder == "")
			ruleBuilder = "NA";
		String description = agGetText(ApplicationConfigSearchPolices_PageObjects.description);
		if (description == "")
			description = "NA";

		String[] columnName = { "Policy Name", "Report Type", "Source", "Default", "Status", "Policy Type","Rule Builder", "Description"};

		config.put(columnName[0], policyName);
		config.put(columnName[1], reportType);
		config.put(columnName[2], activeSourceType);
		config.put(columnName[3], defaultActiveCheckbox);
		config.put(columnName[4], statusActiveRadio);
		config.put(columnName[5], policyType);
		config.put(columnName[6], ruleBuilder);
		config.put(columnName[7], description);
		for (int i = 0; i <= columnName.length - 1; i++) {
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, columnName[i],config.get(columnName[i]));
		}

		List<WebElement> getSelectLevelrows = agGetElementList(ApplicationConfigSearchPolices_PageObjects.selectLevelRowsList);

		String selectLevelCol = "", caseAttributes = "", caseAttributeCriteria = "", resultSet = "",actionToBeTaken = "";

		for (int i = 0; i <= getSelectLevelrows.size() - 1; i++) {

			selectLevelCol = selectLevelCol + agGetText(ApplicationConfigSearchPolices_PageObjects.selectLevel(i))+ '\n' + "::" + '\n';
			caseAttributes = caseAttributes+ agGetAttribute("outerText", ApplicationConfigSearchPolices_PageObjects.caseAttribute(i)).replace("\n", ":\n")+ '\n' + "::" + '\n';

			List<WebElement> caseAttributeCriteriaList = agGetElementList(ApplicationConfigSearchPolices_PageObjects.caseAttributeCriteriaList(i));
			for (int j = 0; j <= caseAttributeCriteriaList.size() - 1; j++) {
				caseAttributeCriteria = caseAttributeCriteria + agGetAttribute("outerText",ApplicationConfigSearchPolices_PageObjects.caseAttributeCriteria(i, j));
				if (j == caseAttributeCriteriaList.size() - 1) {
					caseAttributeCriteria = caseAttributeCriteria + '\n' + "::" + '\n';
					actionToBeTaken = actionToBeTaken+ agGetText(ApplicationConfigSearchPolices_PageObjects.unconditionalATBT(i, j)) + '\n'+ "::" + '\n';
					break;
				}

				caseAttributeCriteria = caseAttributeCriteria + '\n' + ":" + '\n';
				
				List<WebElement> resultSetList = agGetElementList(ApplicationConfigSearchPolices_PageObjects.resultSetlist(i, j));
				for (int k = 0; k <= resultSetList.size() - 1; k++) {
					resultSet = resultSet + agGetText(ApplicationConfigSearchPolices_PageObjects.resultSet(i, j, k));

					if (k < resultSetList.size() - 1) {
						resultSet = resultSet + ":" + '\n';
					} else {
						resultSet = resultSet + '\n';
					}
				}

				if (j == caseAttributeCriteriaList.size() - 1) {
					resultSet = resultSet + '\n';}
				else {
					resultSet = resultSet +":"+ '\n';
				}
		
				actionToBeTaken = actionToBeTaken+ agGetText(ApplicationConfigSearchPolices_PageObjects.getActionByresultSet(i, j, "0")) +":"+ '\n'+ agGetText(ApplicationConfigSearchPolices_PageObjects.getActionByresultSet(i, j, "1"))+ ':' + '\n'+ agGetText(ApplicationConfigSearchPolices_PageObjects.getActionByresultSet(i, j, "2")) + ":"+ '\n';
			}
			
			if(resultSet=="") {
				resultSet="Unchecked" + ":::" + '\n';
			}else {
				resultSet =resultSet.substring(0, resultSet.length()-2) + "::" + '\n';
			}
		}

		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SELECT LEVEL", selectLevelCol.substring(0, selectLevelCol.length()-4));
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CASE ATTRIBUTES",caseAttributes.substring(0, caseAttributes.length()-4));
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CASE ATTRIBUTE CRITERIA",caseAttributeCriteria.substring(0, caseAttributeCriteria.length()-4));
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "RESULT SET", resultSet.substring(0, resultSet.length()-4));
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ACTION TO BE TAKEN",actionToBeTaken.substring(0, actionToBeTaken.length()-4));
	}
}
