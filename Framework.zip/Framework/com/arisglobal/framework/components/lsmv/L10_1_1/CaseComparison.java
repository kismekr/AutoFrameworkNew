package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CaseComparisonPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.aventstack.extentreports.Status;

public class CaseComparison extends ToolManager {
	static String className = CaseComparison.class.getSimpleName();
	
	public static String actualSheetName = "Case Compare";
	public static String expectedSheetName = "UI_Data";
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Comparison report checkbox is selected in compare window.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 16-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_ComparisonReportCheckBx() {
		String value = agGetAttribute("class", CaseComparisonPageObjects.get_ComparisonreportCheckBx);
		if (value.contains("ui-state-active")) {
			Reports.ExtentReportLog("Comparison Report CheckBox is selected", Status.PASS, "", true);
		} else {
			Reports.ExtentReportLog("Comparison Report CheckBox is not selected", Status.FAIL, "", true);

		}
	}
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Highlight differences checkbox is selected in compare window.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 16-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_HighlightdiffCheckBx() {
		String value = agGetAttribute("value", CaseComparisonPageObjects.highlightdiffCheckBx);
		if (value.contains("true")) {
			Reports.ExtentReportLog("Highlight differences checkbox is selected", Status.PASS, "", true);
		} else {
			Reports.ExtentReportLog("Highlight differences checkbox is not selected", Status.FAIL, "", true);

		}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to download Excel in case compare window.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 16-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downloadExcel(String FileName) {
		
		agMouseHover(CaseComparisonPageObjects.downloadIcon);
		agMouseHover(CaseComparisonPageObjects.exportToexcelLink);
		agClick(CaseComparisonPageObjects.exportToexcelLink);
		if(agIsVisible(CaseComparisonPageObjects.exportToexcelBtn)==true)
		{
			agClick(CaseComparisonPageObjects.exportToexcelBtn);
			CommonOperations.takeScreenShot();
			agSetStepExecutionDelay("5000");
			agClick(CaseComparisonPageObjects.exportToexcel_closeicon);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CommonOperations.move_Downloadedexcel(FileName);
			
		}
		else
		{
			Reports.ExtentReportLog("Export to excel pop is not displayed", Status.INFO, "", true);
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Highlight differences and Comparison report checkbox is selected in compare window.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 16-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_CheckBox() {
		
		verify_ComparisonReportCheckBx();
		verify_HighlightdiffCheckBx();
	}

	/**********************************************************************************************************
	 * @Objective: Get case data comparison
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 12-September-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void getCaseDataAttributes(String filePath) throws IOException {
		XlsReader.createSheet(filePath, expectedSheetName);
		List<WebElement> caseDataAttributes = agGetElementList(CaseComparisonPageObjects.caseDataAttributesList);
		List<WebElement> colHeaderList = agGetElementList(CaseComparisonPageObjects.columnHeaderList);
		String columnHeader = null;
		for (int j = 1; j <= colHeaderList.size(); j++) {
			columnHeader = agGetText(CaseComparisonPageObjects.columnHeaderList(Integer.toString(j)));
			XlsReader.writeToExcel(filePath, expectedSheetName, 0, j - 1, columnHeader);
		}
		for (int i = 1; i <=caseDataAttributes.size(); i++) {
			String caseDataAttributesValue = agGetText(
					CaseComparisonPageObjects.caseDataAttributes(Integer.toString(i)));
			String case1Value = agGetText(
					CaseComparisonPageObjects.caseColumn(Integer.toString(1), Integer.toString(i)));
			String case2Value = agGetText(
					CaseComparisonPageObjects.caseColumn(Integer.toString(2), Integer.toString(i)));
			XlsReader.writeToExcel(filePath, expectedSheetName, i, 0, caseDataAttributesValue);
			if (!case1Value.isEmpty() || !case2Value.isEmpty()) {
				XlsReader.writeToExcel(filePath, expectedSheetName, i, 1, case1Value);
				XlsReader.writeToExcel(filePath, expectedSheetName, i, 2, case2Value);
			}
		}
		System.out.println("Get data completed");
		agSetStepExecutionDelay("2000");
		agMouseHover(CaseComparisonPageObjects.close_icon);
		agClick(CaseComparisonPageObjects.close_icon);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.takeScreenShot();
	}
	/**********************************************************************************************************
	 * @Objective: case data comparison actual vs expected
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 12-September-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCaseDataAttributes(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		String caseAttributeActualValue, RCT1_ActualValue, RCT2_ActualValue = null;
		String caseAttributeExpectedValue, RCT1_expectedValue, RCT2_expectedValue = null;
		int actualRowCount, expectedRowCount;
		actualRowCount = xls.activeRowcount(filePath, actualSheetName);
		expectedRowCount = xls.activeRowcount(filePath, expectedSheetName);
		System.out.println("actualRowCount: " + actualRowCount);
		System.out.println("expectedRowCount" + expectedRowCount);
		for (int i = 6; i <= actualRowCount + 1; i++) {
			caseAttributeActualValue = xls.getCellData(actualSheetName, 0, i);
			RCT1_ActualValue = xls.getCellData(actualSheetName, 1, i);
			RCT2_ActualValue = xls.getCellData(actualSheetName, 2, i);
			caseAttributeExpectedValue = xls.getCellData(expectedSheetName, 0, i - 4);
			RCT1_expectedValue = xls.getCellData(expectedSheetName, 1, i - 4);
			RCT2_expectedValue = xls.getCellData(expectedSheetName, 2, i - 4);
			if (caseAttributeExpectedValue.equals(caseAttributeActualValue)
					&& RCT1_expectedValue.equals(RCT1_ActualValue) && RCT2_expectedValue.equals(RCT2_ActualValue)) {
				XlsReader.writeToExcel(filePath, expectedSheetName, i - 5, 3, "PASS");
			} else {
				XlsReader.writeToExcel(filePath, expectedSheetName, i - 5, 3, "FAIL");
			}
		}
		System.out.println("Verification completed");
	
	}
}
