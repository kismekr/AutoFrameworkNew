package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import org.openqa.selenium.By;

public class CalllogPageObjects {
	
	
	public static String calllogNew = "xpath#//span[contains(text(),'Calllog new')]";
	public static String calllogNewLable = "xpath#//";
	public static String calllogListing = "xpath#//span[contains(text(),'Calllog listing')]";
	public static String calllogListingLabel = "xpath#//span[@id='callLogListingDatatableForm:callLogTitleId']/label[text()='Call Log ']";
	
	//Calllog Module Menu Navigation validation point
	public static String calllogMenu = "xpath#//div[@id='headerForm:menuMainId']//ul[@class='ui-menu-list ui-helper-reset']/child::li/a/span[contains(text(),'Calllog')]/following::ul/li/a/span[contains(text(),'%s')]";
	public static String calllogHover = "xpath#//a[@class='ui-menuitem-link ui-submenu-link ui-corner-all']//span[@class='ui-menuitem-text'][contains(text(),'Calllog')]";
	public static String calllogNewButton = "xpath#//a[@id='callLogListingDatatableForm:newId']";
	
	   
	/**********************************************************************************************************
	 * Objective:The below method is created to perform menu Navigation by passing Menu Name at runtime.
	 * Input Parameters: ColumnName
	 * Scenario Name Output
	 * Parameters:
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when   	 
	**********************************************************************************************************/
    public static String calllogMenuNavigations(String menu) {
        String value = calllogMenu;
        String value2;
        value2 = value.replace("%s", menu);
        return value2;
    }
}
