package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1.CommonOperations;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ApplicationConfigPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.DuplicateCheckPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.DuplicateSearchPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class DuplicateCheckPolicyOperations extends ToolManager {

	static String className = DuplicateCheckPolicyOperations.class.getSimpleName();
	public static WebElement webElement;

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform search based on policy
	 *             name in duplicate search.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void duplicateCheckSearch(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		ApplicationConfigOperations.menuNavigation(ApplicationConfigPageObjects.duplicatecheckpoliciesLink);
		agSetValue(DuplicateCheckPageObjects.keywordSearchTextbox,
				getTestDataCellValue(scenarioName, "SearchCriteria"));
		agClick(DuplicateCheckPageObjects.searchIcon);

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to set duplicate check general details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setGeneralDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(DuplicateCheckPageObjects.PolicyNameTextbox, getTestDataCellValue(scenarioName, "PolicyName"));
		setReportType(scenarioName);
		agClick(DuplicateCheckPageObjects.selectRadioButton(getTestDataCellValue(scenarioName, "Status")));
		agClick(DuplicateCheckPageObjects.selectRadioButton(getTestDataCellValue(scenarioName, "Source")));
		if (getTestDataCellValue(scenarioName, "Default") == "true") {
			agClick(DuplicateCheckPageObjects.DefaultCheckbox);
		}
		agSetValue(DuplicateCheckPageObjects.descriptionTextarea, getTestDataCellValue(scenarioName, "Description"));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the Report Type Input
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setReportType(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(DuplicateCheckPageObjects.clickReportTypeDropDown);
		agClick(DuplicateCheckPageObjects.setreportType(getTestDataCellValue(scenarioName, "ReportType")));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Case Attributes
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCaseAttributes(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(DuplicateCheckPageObjects.ClickCaseAttributesDropDown);
		agClick(DuplicateCheckPageObjects.setcaseAttributes(getTestDataCellValue(scenarioName, "CaseAttributes")));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to save duplicate check
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void saveDuplicateCheckRule() {
		agClick(DuplicateCheckPageObjects.SaveButton);
		agAssertContainsText(DuplicateCheckPageObjects.validationPopup, "Saved Successfully");
		agClick(DuplicateCheckPageObjects.popupOkButton);
		agClick(DuplicateCheckPageObjects.CancelButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Rules Configurations
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setRulesConfigurations(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(DuplicateCheckPageObjects.Addlevellink);
		agSelectByVisibleText(DuplicateCheckPageObjects.SelectLevelDropDown,
				getTestDataCellValue(scenarioName, "SelectLevel"));
		setCaseAttributes(scenarioName);
		agClick(DuplicateCheckPageObjects.AddRule_1Link);
		agClick(DuplicateCheckPageObjects.AddConditions_1Link);
		agClick(DuplicateCheckPageObjects.ConditionpopupOkbutton);
		agSelectByVisibleText(DuplicateCheckPageObjects.ActionTaken_1DropDown,
				getTestDataCellValue(scenarioName, "Action1"));
		agClick(DuplicateCheckPageObjects.AddRule_2Link);
		agClick(DuplicateCheckPageObjects.AddConditions_2Link);
		agClick(DuplicateCheckPageObjects.UnconditionalCheckbox);
		agClick(DuplicateCheckPageObjects.ConditionpopupOkbutton);
		agSelectByVisibleText(DuplicateCheckPageObjects.ActionTaken_2DropDown,
				getTestDataCellValue(scenarioName, "Action2"));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create a duplicate check rule
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void createDuplicateCheckRule(String scenarioName) {
		duplicateCheckSearch(scenarioName);
		String paginator = agGetText(DuplicateCheckPageObjects.paginator);
		if (paginator == null && paginator.startsWith("0")) {
			agClick(DuplicateCheckPageObjects.NewButton);
			setGeneralDetails(scenarioName);
			setRulesConfigurations(scenarioName);
			saveDuplicateCheckRule();
		} else {
			Reports.ExtentReportLog("Duplicate check policy already exists", Status.PASS, "", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create a duplicate check rule
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void DuplicateSearch(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		CaseManagementOperations.menuNavigation("Case listing");
		// CaseManagementOperations.menusubmenuNavigation("Case listing");
		agSetStepExecutionDelay("3000");
		agWaitTillVisibilityOfElement(DuplicateSearchPageObjects.duplicateSearch);
		agClick(DuplicateSearchPageObjects.duplicateSearch);
		agClick(DuplicateSearchPageObjects.ProductLookUp);
		agSetValue(DuplicateSearchPageObjects.ProductNameLookUp, getTestDataCellValue(scenarioName, "ProductName"));
		agSetStepExecutionDelay("5000");
		agClick(DuplicateSearchPageObjects.SearchLoopkup);
		agSetStepExecutionDelay("2000");
		agClick(DuplicateSearchPageObjects.ProductRadioBtn);
		agClick(DuplicateSearchPageObjects.OkBtn);
		agClick(DuplicateSearchPageObjects.CloseBtn);
		Reports.ExtentReportLog("", Status.INFO, "Duplicate Search", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set all the fields to search for
	 *             duplicate cases
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setAllDuplicateSearch(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		setProductDetails(scenarioName);
		setGeneralInfo(scenarioName);
		setEventsDetails(scenarioName);
		setLiteratureDetails(scenarioName);
		setPatientDetails(scenarioName);
		setSourceDetails(scenarioName);
		setStudyDetails(scenarioName);
		setReporterDetails(scenarioName);
		agClick(DuplicateSearchPageObjects.SearchButton);
		Reports.ExtentReportLog("", Status.INFO, "Duplicate Search", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set all the fields to search for
	 *             duplicate cases
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void duplicateSearch() {
		agWaitTillVisibilityOfElement(DuplicateSearchPageObjects.duplicateSearch);
		agClick(DuplicateSearchPageObjects.duplicateSearch);
		Reports.ExtentReportLog("", Status.INFO, "Navigated to Duplicate Search", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set product details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setProductDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		agSetStepExecutionDelay("2000");
		agClick(DuplicateSearchPageObjects.ProductLookUp);
		agSetValue(DuplicateSearchPageObjects.ProductNameLookUp,
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"));
		agClick(DuplicateSearchPageObjects.SearchLoopkup);
		agSetStepExecutionDelay("2000");
		agClick(DuplicateSearchPageObjects.ProductRadioBtn);
		agClick(DuplicateSearchPageObjects.OkBtn);
		agSelectByVisibleText(DuplicateSearchPageObjects.productChaacterzation_Dropdown,
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductCharacterization"));
		agSetValue(DuplicateSearchPageObjects.ProductNameasReported,
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductNameAsReported"));
		Reports.ExtentReportLog("", Status.INFO, "Product details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set unBlindProduct details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setUnBlindProductDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "Product_LookupOperations");
		agSetStepExecutionDelay("2000");
		agClick(DuplicateSearchPageObjects.ProductLookUp);
		agSetValue(DuplicateSearchPageObjects.ProductNameLookUp,
				getTestDataCellValue(scenarioName, "ProductLibraryProductName"));
		agClick(DuplicateSearchPageObjects.SearchLoopkup);
		agSetStepExecutionDelay("2000");
		agClick(DuplicateSearchPageObjects.ProductRadioBtn);
		agClick(DuplicateSearchPageObjects.OkBtn);
		agClick(DuplicateSearchPageObjects.SearchButton);
		Reports.ExtentReportLog("", Status.INFO, "UnBlind Product details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set general details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setGeneralInfo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		agSetStepExecutionDelay("2000");
		// agSetValue(DuplicateSearchPageObjects.authorityNum,
		// getTestDataCellValue(scenarioName,
		// "Gen_CaseReferences_AuthorityNoCompNumber"));
		agSetValue(DuplicateSearchPageObjects.LRDFromRecvDate, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_LatestReceivedDate")));
		agSetValue(DuplicateSearchPageObjects.LRDToRecvDate, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_LatestReceivedDate")));
		agSetValue(DuplicateSearchPageObjects.safetyReportID,
				getTestDataCellValue(scenarioName, "Gen_CaseReferences_SafetyReportID"));
		agSelectByVisibleText(DuplicateSearchPageObjects.reportType_Dropdown,
				getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportType"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "DuplicateCheckPolicyOperations");
		agSelectByVisibleText(DuplicateSearchPageObjects.primarySourceCountry_Dropdown,
				getTestDataCellValue(scenarioName, "PrimarySourceCountry"));
		agSelectByVisibleText(DuplicateSearchPageObjects.countryDetection_Dropdown,
				getTestDataCellValue(scenarioName, "CountryOfDetection"));
		Reports.ExtentReportLog("", Status.INFO, "General details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set events details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setEventsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
		agSetStepExecutionDelay("2000");
		agSetValue(DuplicateSearchPageObjects.onsetDate, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Events_EventInformation_OnsetDate")));
		agSetValue(DuplicateSearchPageObjects.reportedTerm,
				getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		Reports.ExtentReportLog("", Status.INFO, "Event details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set literature details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setLiteratureDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Literature");
		agSetStepExecutionDelay("2000");
		agSetValue(DuplicateSearchPageObjects.articleTitle,
				getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_ArticleTitle"));
		agSetValue(DuplicateSearchPageObjects.journalTitle,
				getTestDataCellValue(scenarioName, "Literature_LiteratureInformation_JournalTitle"));
		// agSetValue(DuplicateSearchPageObjects.literatureRef,
		// getTestDataCellValue(scenarioName,
		// "Literature_LiteratureInformation_LiteratureReference"));
		Reports.ExtentReportLog("", Status.INFO, "Literature details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set patient details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setPatientDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Patient");
		agSetStepExecutionDelay("2000");
		agSetValue(DuplicateSearchPageObjects.patientDOB, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_PatientDOB")));
		// agSetValue(DuplicateSearchPageObjects.ageTimeEvent,
		// getTestDataCellValue(scenarioName,
		// "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent"));
		agSetValue(DuplicateSearchPageObjects.patientID,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_PatientID"));
		agSetValue(DuplicateSearchPageObjects.hospitalRecordNo,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_HospitalRecordNumber"));
		agSetValue(DuplicateSearchPageObjects.GPrecordNo,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_GPMedicalRecordNumber"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "DuplicateCheckPolicyOperations");
		// agSelectByVisibleText(DuplicateSearchPageObjects.patientAgeUnit_Dropdown,
		// getTestDataCellValue(scenarioName, "AgeAtTheTimeOfEvent_Units"));
		agSelectByVisibleText(DuplicateSearchPageObjects.gender_dropDown, getTestDataCellValue(scenarioName, "Gender"));
		Reports.ExtentReportLog("", Status.INFO, "Patient details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set source details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSourceDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Source");
		agSetStepExecutionDelay("2000");
		agSetValue(DuplicateSearchPageObjects.referenceNum,
				getTestDataCellValue(scenarioName, "Source_ReferenceNumber"));
		agSelectByVisibleText(DuplicateSearchPageObjects.referenceType_Dropdown,
				getTestDataCellValue(scenarioName, "Source_ReferenceType"));
		Reports.ExtentReportLog("", Status.INFO, "Source details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set study details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setStudyDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Study");
		agClick(DuplicateSearchPageObjects.ProtocolNoLookup);
		agSetValue(DuplicateSearchPageObjects.sponsorStudyNo,
				getTestDataCellValue(scenarioName, "Study_StudyLookup_StudyNo"));
		agClick(DuplicateSearchPageObjects.ProtocolSearchIcon);
		agSetStepExecutionDelay("2000");
		agClick(DuplicateSearchPageObjects.ProductRadioBtn);
		agClick(DuplicateSearchPageObjects.studyOkBtn);
		agSetValue(DuplicateSearchPageObjects.centerNo,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_CenterNumber"));
		agSetValue(DuplicateSearchPageObjects.subjectID,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_SubjectID"));
		Reports.ExtentReportLog("", Status.INFO, "Study details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set reporter details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setReporterDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Reporter");
		agSetStepExecutionDelay("2000");
		agSetValue(DuplicateSearchPageObjects.firstName, getTestDataCellValue(scenarioName, "Reporter_FirstName"));
		agSetValue(DuplicateSearchPageObjects.LastName, getTestDataCellValue(scenarioName, "Reporter_LastName"));
		agSetValue(DuplicateSearchPageObjects.state, getTestDataCellValue(scenarioName, "Reporter_State"));
		agSetValue(DuplicateSearchPageObjects.postalCode, getTestDataCellValue(scenarioName, "Reporter_PostalCode"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "DuplicateCheckPolicyOperations");
		agSelectByVisibleText(DuplicateSearchPageObjects.country_Dropdown,
				getTestDataCellValue(scenarioName, "ReporterCountry"));
		Reports.ExtentReportLog("", Status.INFO, "Reporter details selected", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify the RCT number result shown
	 *             based on duplicate search
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyRCTNumber(String scenarioName) {
		String data = FDE_General.getData(scenarioName, "ReceiptNo");
		int fileCount = 0;
		int i;
		ArrayList<String> receiptnum = DuplicateCheckPolicyOperations.receiptNoList();
		List<WebElement> rctNum = agGetElementList(DuplicateSearchPageObjects.getRCTNumberList);
		if (receiptnum.size() > 0) {

			for (i = 0; i < rctNum.size(); i++) {
				if (data.equalsIgnoreCase(receiptnum.get(i))) {
					System.out.println("Available Receipt numbers : " + i + receiptnum.get(i));
					System.out.println(receiptnum.get(i));
					fileCount++;
					break;
				}
			}

			if (fileCount > 0) {
				Reports.ExtentReportLog("", Status.PASS,
						"Irrespective of Previleges the cases with blinded and unblinded results are searched in Duplicate search  "
								+ receiptnum.get(i),
						true);
			}
			if (fileCount == 0) {
				Reports.ExtentReportLog("", Status.FAIL,
						"Irrespective of Previleges the cases with blinded and unblinded results are not searched in Duplicate search  "
								+ receiptnum.get(i),
						true);
			}
		} else {
			Reports.ExtentReportLog("", Status.FAIL, " Receipt numbers not visible ", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to Verify the RCT number result shown
	 *                based on duplicate search
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 17-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> receiptNoList() {
		ArrayList Al = new ArrayList<>();
		if (agIsVisible(DuplicateSearchPageObjects.getRCTNumberList) == true) {
			List<WebElement> receiptNo = agGetElementList(DuplicateSearchPageObjects.getRCTNumberList);
			for (int i = 0; i < receiptNo.size(); i++) {
				String rctNo = agGetText(
						DuplicateSearchPageObjects.getRCTNumber.replace("%count%", Integer.toString(i + 1)));
				List<String> list = Arrays.asList(rctNo.toString());
				Al.addAll(list);
			}

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Receipt numbers list not visible ", true);
		}
		return Al;
	}

}
