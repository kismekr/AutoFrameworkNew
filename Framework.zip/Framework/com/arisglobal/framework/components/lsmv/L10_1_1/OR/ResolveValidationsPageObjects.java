package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class ResolveValidationsPageObjects {
	
	public static String validationDescription = "xpath#(//div[@id='agMandatoryContextCheck']/div/ol/li[@class='agValError ng-star-inserted']/a)[{0}]";
	public static String openValidationDialog = "xpath#//div[contains(@class,'mandatoryOpenState')]/img";
	public static String closeValidationDialog = "xpath#//div[@class='agTreeToggle right ng-star-inserted mandatoryClosedState']";
	public static String activeTab = "xpath#//li[contains(@class,'treeActive')]/h4/a";
	public static String radioButtonXpath = "xpath#(//label[contains(text(),'{0}')]/ancestor::*/*/span/p-radiobutton/label[text()='{@}']/ancestor::p-radiobutton/div/div[contains(@class,'radiobutton-box')]/span)[1]";
	public static String textbox = "xpath#(//label[text()='{0}']/ancestor::*/span/input[contains(@style,'display: inline') or (contains(@style,'border'))])[1]";
	
	public static String validationDescription (int count) {
		String countString = Integer.toString(count);
	 	String value =  validationDescription.replace("{0}", countString);
	 	return value;
	}

	public static String radioButton (String field, String testdatavalue) {
		String value =  radioButtonXpath.replace("{0}", field);
		value = value.replace("{@}", testdatavalue);
	 	return value;
	}
	
	public static String textbox (String field) {
	 	String value =  textbox.replace("{0}", field);
	 	return value;
	}
	
}
