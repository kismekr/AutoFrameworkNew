package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class WorkFlowPageObjects {

	// ~~~~~~~~~~~~~~~~~~~~~ Main ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	public static String checkBoxLeftOf = "xpath#(//label[starts-with(normalize-space(text()),'{0}')]/preceding::div[1]/span)[1]";
	public static String activityName_TextBox = "xpath#//input[@id='configForm:wfactivityname']";
	public static String sequence_TextBox = "xpath#//input[@id='configForm:wfactivitysequenceID']";
	public static String SequenceTrans_Textbox = "xpath#//input[@id='configForm:wftransitionsequenceID']";
	public static String dropDownListItem = "xpath#//div[@id='%locator%_panel']//label[text()='%text%']";
	public static String onSuccessTransition_Dropdown = "xpath#//label[@id='configForm:wfsuccessfultransition_label']";
	public static String onFailureTransition_Dropdown = "xpath#//label[@id='configForm:wffailuretransition_label']";
	public static String completionRule_Label = "xpath#//label[@id='configForm:wfactivitycompletionrulemenuMulti_label']";
	public static String transitionRule_Label = "xpath#//label[@id='configForm:wfactivitydecisionrulemenu_label']";
	public static String autoCompletionRule_Label = "xpath#//label[@id='configForm:wfautocompletionrulemenuMulti2_label']";
	public static String autocompletionRule_div = "xpath#//div[contains(@id,'configForm:wfautocompletionrulemenuMulti2')]";
	public static String allowManualLock_Label = "Allow Manual Lock";
	public static String autoComplete_Label = "Auto Complete";
	public static String generateCaseQualityScore_Label = "Generate Case Quality Score";
	public static String enableSumissionTracking_Label = "Enable Submission Tracking";
	public static String isInCriticalPath = "Is in Critical Path";
	public static String generateCaseSummary_Label = "Generate Case Summary";
	public static String dropDownList = "xpath#//li[text()='{0}'][contains(@id,'{1}')]";

	public static String ActivityType_Label = "xpath#//label[contains(@id,'configForm:acticityType-9105_label')]";
	public static String ActivityID_TextBox = "xpath#//span[text()='Activity ID']/following-sibling::input";
	public static String CheckedCheckBox = "xpath#//label[starts-with(normalize-space(text()),'{0}')]/../descendant::div[contains(@class,'ui-state-active')]";
	public static String CheckedCheckBox2 = "xpath#//label[starts-with(normalize-space(text()),'{0}')]/../descendant::span/parent::div";
	public static String CheckedCheckBoxYes = "xpath#//label[text()='{0}']/parent::div/following-sibling::div//label[starts-with(normalize-space(text()),'No')]/../descendant::div[contains(@class,'ui-state-active')]";
	public static String checkBoxClickedcheck = "xpath#(//label[starts-with(normalize-space(text()),'{0}')]/preceding::div[1]/span[contains(@class,'check')])[1]";
	public static String SubActCheckBoxCheck = "xpath#//span[starts-with(normalize-space(text()),'{0}')]/../descendant::div[contains(@class,'ui-chkbox-box')]/span[contains(@class,'check')]";
	
	// ~~~~~~~~~~~~~~~~~~~~~ Configurations ~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	public static String ConfigurationsTab = "xpath#//a[@id='configForm:wfactConfigTab']//span";
	public static String investigationActivity = "Investigation Activity";
	public static String restrictLocalDocView = "Restrict Local Document View";
	public static String stopForSampling = "Stop for sampling";
	public static String preliminaryInvestigationActivity = "Preliminary Investigation Activity";
	public static String onSave = "On Save";
	public static String onCompleteActivity = "On Complete Activity";
	public static String followUpCaseAutoMerge = "Follow Up Case Auto Merge";
	public static String updateVTASynonyms = "Update VTA Synonyms";
	public static String allowApprovedCaseEdit = "Allow Approved Case Edit";
	public static String allowDeletion = "Allow Deletion";
	public static String deletionActivity = "Deletion Activity";
	public static String paralleWorkflowStarts = "Parallel Workflow Starts";
	public static String waitForChildWorkflow = "Wait for Child Workflow";
	public static String notifyFUcaseonComplete = "Notify follow up case on Complete";
	public static String autoDataAssessment = "Auto Data Assessment";
	public static String submitUncodedTerms = "Submit Uncoded Terms";
	public static String localCorrespondenceView = "Local Correspondence View";
	public static String restrictDataPrivacy = "Restrict Data Privacy Data Access";
	public static String allowCompareReconcileFU = "Allow Compare and Reconcile for Follow Up";
	
	//public static String parallelWorkflowStarts = "Parallel Workflow Starts";
	//public static String waitforChildWorkflow= "Wait for Child Workflow";
	public static String japanNonCase = "Japan Non Case";
	public static String nonCaseActivity= "Non Case Activity";
	public static String notifyfollowupcaseonCompleteActivity = "Notify follow up case on Complete Activity";
	
	

	public static String rejectXMLReceipt = "Reject XML Receipt";
	public static String GenerateNarrative = "Generate Narrative";
	public static String checkBoxUnder = "xpath#//label[starts-with(normalize-space(text()),'{0}')]/../descendant::div[contains(@class,'ui-chkbox-box')]";
	public static String radioBtn = "xpath#//label[starts-with(normalize-space(text()),'{0}')]/../descendant::div[contains(@class,'ui-radiobutton-box')]";
	public static String initialDataAssessment = "Initial Data Assessment";
	public static String fullDataAssessment = "Full Data Assessment";
	public static String autoMerge_DropDown = "xpath#//label[@id='configForm:autoMergeScriptedRuleMenuId_label']";
	public static String onSaveAOSEEnable = "xpath#//div[@id='configForm:aoseSearchSaveId']//div[contains(@class,'ui-chkbox-box')]";

	// ~~~~~~~~~~~~~~~~~~~~ Generate Narrative ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	public static String EventDescription = "Event Description";
	public static String Medicalhisory = "Medical History And Concurrent Conditions";
	public static String CompanyRemarks = "Company Remarks";
	public static String PharmacologicalComments = "Pharmacovigilance Comments";
	public static String AdditionalComments = "Additional Comments";

	// ~~~~~~~~~~~~~~~~~~ Distribution Related Configurations ~~~~~~~~~~~~~~~~~~~~

	public static String sendForReprocessing = "Send for Reprocessing";
	public static String distributionInTransitActivity = "Is Distribution In Transit Activity";
	public static String createNewVersionActivity = "Create New Version Activity";
	public static String allowAddingDistributionContacts = "Allow Adding of Distribution Contacts";
	public static String allowDistribution = "Allow Redistribution";

	// ~~~~~~~~WorkFlow Activity > Explore the workflow activity ~~~~~~~~~~~~~~~~

	public static String transitionName_Textbox = "xpath#//input[@id='configForm:wftransitionname']";
	public static String transitionTo = "//label[@id='configForm:transitionLeadsTo_label']";
	public static String checkBox = "xpath#//span[starts-with(normalize-space(text()),'{0}')]/../descendant::div[contains(@class,'ui-chkbox-box')]";
	public static String checkBoxTick = "xpath#//span[starts-with(normalize-space(text()),'{0}')]/../descendant::div[contains(@class,'ui-chkbox-box')]/span[@class='ui-chkbox-icon ui-icon ui-c ui-icon-check']";
	public static String dataAssessmentReq = "Data Assessment Required";
	public static String approved = "Approved";
	public static String autoLock = "Auto Lock";
	public static String generateDistributionContacts = "Generate Distribution Contacts";
	public static String generateDistributionReports = "Generate Distribution Reports";
	public static String generateVariableContacts = "Generate Variable Contacts";
	public static String finalEvaluationVariableContact = "Final Evaluation for Variable Contacts";
	public static String transitionRule_Dropdown = "xpath#//label[@id='configForm:wftTransitionRuleId_label']";
	public static String childWorkflow_Dropdown = "xpath#//label[@id='configForm:wftChildWorkflowId_label']";
	public static String ProposeSubmissionTrackingDepostion = "Propose Submission Tracking Disposition";

	public static String WfActivity = "xpath#//label[text()='WorkFlow Activity > '%s'']";
	public static String ActivityTab = "xpath#//span[text()='%s']";
	public static String MaximizeActivityTab = "xpath#//span[text()='%s']/preceding-sibling::span[@class='ui-tree-toggler ui-icon ui-icon-triangle-1-e']";
	public static String TranslationActivity = "xpath#//label[contains(text(),'%s')]";

	public static String inital_Label = "Initial";
	public static String nonCase_Label = "Non Case";
	public static String intakeAndAssesment_Label = "Intake and Assessment";
	public static String translation_Label = "Translation";
	public static String review_Label = "Review";
	public static String fullDataEntry_Label = "Full Data Entry";
	public static String qualityReview_Label = "Quality Review";
	public static String medicalReview_Label = "Medical Review";
	public static String supplementalReview_Label = "Supplemental Review";
	public static String caseApproval_Label = "Case Approval (Auto)";
	public static String distribute_Label = "Distribute";
	public static String distributeTransit_Label = "Distribute Transit";
	public static String minorChange_Label = "Minor Change";
	public static String exit_Label = "Exit";
	public static String caseDeletion_Label = "Case Deletion";
	public static String checkCaseNullified_Label = "Check Case Nullified";
	public static String JPNNonCaseEntry_Label = "JPN Non Case Data Entry";
	public static String japanWorkflow_Label = "Japan Workflow";
	public static String finalReview_Label = "Final Review";

	///////// -------------------Activity
	///////// Tabs-------------------------////////////////////////////////
	public static String Initial_SendToIA = "xpath#//span[text()='Initial']/parent::span/following-sibling::ul//span[text()='Send to Intake and Assessment']";
	public static String Initial_SendToNonCase = "xpath#//span[text()='Initial']/parent::span/following-sibling::ul//span[text()='Send to Non Case']";

	public static String NonCase_SendToIA = "xpath#//span[text()='Non Case']/parent::span/following-sibling::ul//span[text()='Send to Intake and Assessment']";
	public static String NonCase_SendToExit = "xpath#//span[text()='Non Case']/parent::span/following-sibling::ul//span[text()='Send to Exit']";

	public static String IA_SendToReview = "xpath#//span[text()='Intake and Assessment']/parent::span/following-sibling::ul//span[text()='Send to Review']";
	public static String IA_SendToTranslation = "xpath#//span[text()='Intake and Assessment']/parent::span/following-sibling::ul//span[text()='Send to Translation']";
	public static String IA_SendToNonCase = "xpath#//span[text()='Intake and Assessment']/parent::span/following-sibling::ul//span[text()='Send to Non Case']";

	public static String Translation_SendToIA = "xpath#//span[text()='Translation']/parent::span/following-sibling::ul//span[text()='Send to Intake and Assessment']";
	public static String Translation_SendToReview = "xpath#//span[text()='Translation']/parent::span/following-sibling::ul//span[text()='Send  to Review']";

	public static String Review_SendToFDE = "xpath#//span[text()='Review']/parent::span/following-sibling::ul//span[text()='Send to Full Data Entry']";
	public static String Review_SendToNonCase = "xpath#//span[text()='Review']/parent::span/following-sibling::ul//span[text()='Send to Non Case']";
	public static String Review_SendToIA = "xpath#//span[text()='Review']/parent::span/following-sibling::ul//span[text()='Send to Intake and Assessment']";

	public static String FDE_SendToQltyReview = "xpath#//span[text()='Full Data Entry']/parent::span/following-sibling::ul//span[text()='Send to Quality Review']";

	public static String QR_SendToMedicalReview = "xpath#//span[text()='Quality Review']/parent::span/following-sibling::ul//span[text()='Send to Medical Review']";
	public static String QR_SendToFDE = "xpath#//span[text()='Quality Review']/parent::span/following-sibling::ul//span[text()='Send to Full Data Entry']";

	public static String MR_SendToFinalReview = "xpath#//span[text()='Medical Review']/parent::span/following-sibling::ul//span[text()='Send to Final Review']";
	public static String MR_SendToSuppReview = "xpath#//span[text()='Medical Review']/parent::span/following-sibling::ul//span[text()='Send to Supplemental Review']";
	public static String MR_SendToFDE = "xpath#//span[text()='Medical Review']/parent::span/following-sibling::ul//span[text()='Send to Full Data Entry']";

	public static String SR_SendToMedicalReview = "xpath#//span[text()='Supplemental Review']/parent::span/following-sibling::ul//span[text()='Send to Medical Review']";
	public static String SR_SendToFullDataEntry = "xpath#//span[text()='Supplemental Review']/parent::span/following-sibling::ul//span[text()='Send to Full Data Entry']";
	public static String SR_SendToFinalReview = "xpath#//span[text()='Supplemental Review']/parent::span/following-sibling::ul//span[text()='Send to Final Review']";
	
	public static String FR_SendToCaseApproval = "xpath#//span[text()='Final Review']/parent::span/following-sibling::ul//span[text()='Send to Case Approval']";
	public static String FR_SendToFullDataEntry = "xpath#//span[text()='Final Review']/parent::span/following-sibling::ul//span[text()='Send to Full Data Entry']";
	public static String FR_SendToMedicalReview = "xpath#//span[text()='Final Review']/parent::span/following-sibling::ul//span[text()='Send to Medical Review']";

	public static String CA_SendToDistriute = "xpath#//span[text()='Case Approval (Auto)']/parent::span/following-sibling::ul//span[text()='Send to Distribute']";
	public static String CA_JapanCaseReportableToPDA = "xpath#//span[text()='Case Approval (Auto)']/parent::span/following-sibling::ul//span[text()='JPN Case reportable to PMDA']";

	public static String Distribute_SendToDistribute = "xpath#//span[text()='Distribute']/parent::span/following-sibling::ul//span[text()='Send to Distribute Transit']";

	public static String DT_SendToExit = "xpath#//span[text()='Distribute Transit']/parent::span/following-sibling::ul//span[text()='Exit']";
	public static String DT_SendToMinorChange = "xpath#//span[text()='Distribute Transit']/parent::span/following-sibling::ul//span[text()='Send to Minor Change']";

	public static String MC_SendToDistribute = "xpath#//span[text()='Minor Change']/parent::span/following-sibling::ul//span[text()='Send to Distribute Transit']";

	public static String exit = "xpath#//li[@id='configForm:activityTreeId:0_14']//following::span[text()='Exit']";

	public static String CaseDeletion_DeleteConfirmed = "xpath#//span[text()='Case Deletion']/parent::span/following-sibling::ul//span[text()='Delete Confirmed']";
	public static String CaseDeletion_RejectDeletion = "xpath#//span[text()='Case Deletion']/parent::span/following-sibling::ul//span[text()='Reject Deletion']";

	public static String CCNullified_SendToDeletion = "xpath#//span[text()='Check Case Nullified']/parent::span/following-sibling::ul//span[text()='Send to Deletion']";
	public static String CCNullified_SendToDistribute = "xpath#//span[text()='Check Case Nullified']/parent::span/following-sibling::ul//span[text()='Send to Distribute']";

	public static String JPNNonCaseDE_SendToNonCase = "xpath#//span[text()='JPN Non Case Data Entry']/parent::span/following-sibling::ul//span[text()='Send to Non Case']";
	public static String JPNNonCaseDE_NonJPNCaseReportablePMDA = "xpath#//span[text()='JPN Non Case Data Entry']/parent::span/following-sibling::ul//span[text()='Non-JPN Case reportable to PMDA']";

	////////// Validation///////////////////////
	public static String ValidationBtn = "xpath#//span[text()='Validations']";
	// label[text()='On
	// Save']/ancestor::div[@id='configForm:editCheckTableId']//td[text()='%s']/parent::tr//table[contains(@id,'j_id_16d')]//label[text()='Warning']/preceding-sibling::div//div[contains(@class,'active')]
	public static String OnSaveWarningRadioBtn = "xpath#//label[text()='On Save']/ancestor::div[@id='configForm:editCheckTableId']//td[text()='%s']/parent::tr//table[contains(@id,'j_id_16d')]//label[text()='Warning']/preceding-sibling::div//div[contains(@class,'active')]";
	public static String OnCompleteWarningRadioBtn = "xpath#//div[@id='configForm:editCheckTableId']//td[text()='%s']/parent::tr//table[contains(@id,'j_id_16o')]//label[text()='Warning']/preceding-sibling::div//div[contains(@class,'active')]";
	public static String OnSaveErrorRadioBtn = "xpath#//label[text()='On Save']/ancestor::div[@id='configForm:editCheckTableId']//td[text()='%s']/parent::tr//table[contains(@id,'j_id_16d')]//label[text()='Error']/preceding-sibling::div//div[contains(@class,'active')]";
	public static String OnCompleteErrorRadioBtn = "xpath#//div[@id='configForm:editCheckTableId']//td[text()='%s']/parent::tr//table[contains(@id,'j_id_16o')]//label[text()='Error']/preceding-sibling::div//div[contains(@class,'active')]";
	public static String RuleName = "xpath#//td[text()='%s']";

	// Activity Due Dates
	public static String Administartion = "Administration";
	public static String Workflow = "Workflow";
	public static String ActivityDueDates = "Activity Due Dates";
	public static String Initial = "Initial";
	public static String LocalSubmission = "Local Submission";
	public static String SubmissionReview = "Submission Review";
	public static String links = "xpath#//span[@class='ui-menuitem-text'][contains(text(),'%s')]";
	public static String NewConfigBtn = "xpath#//a[@id='wrkflowList:newTrackerWFId']";
	public static String editSubmissionWorkflow = "xpath#//tbody[@id='wrkflowList:wrkflowTablenew_data']//tr//td//label[contains(text(),'ISP Submission Workflow')]//preceding::td[3]";
	public static String CaseDueDateDD = "xpath#//tbody[@id='configForm:wfCDDDataTable_data']//tr//td//label[contains(text(),'%s')]//following::div[contains(@id,'cddType1')][1]";
	public static String LatenessReasonDD = "xpath#//tbody[@id='configForm:wfCDDDataTable_data']//tr//td//label[contains(text(),'%s')]//following::div[contains(@id,'C-801')][1]";
	public static String ActivityDueDateValue = "xpath#//tbody[@id='configForm:wfCDDDataTable_data']//tr//td//label[contains(text(),'%s')]//parent::td//following::input[contains(@id,'activityDueDateValue')][1]";
	public static String LatenessReasonCheckBox = "xpath#//tbody[@id='configForm:wfCDDDataTable_data']//tr//td//label[contains(text(),'%s')]//parent::td//following::input[contains(@id,'j_id_1c5_input')][1]";
	public static String latensessCheckBoxChecked = "xpath#(//tbody[@id='configForm:wfCDDDataTable_data']//tr//td//label[contains(text(),'%s')]//parent::td//following::input[contains(@id,'j_id_1c5_input')]//parent::div//following-sibling::div)[1]";
	public static String saveButton = "xpath#//button[@id='configForm:wfSaveId']";
	public static String cancelButton = "xpath#//button[@id='configForm:wfcancelID']";
	public static String CaseDDValue = "xpath#(//ul[contains(@id,'cddType1_items')])[%index]//li[text()='%s']";
	public static String LatenessReasonDDValue = "xpath#//ul[contains(@id,'%index:C-801_items')]//li[contains(text(),'%s')]";
	public static String ConfirmationPopUp = "xpath#//span[contains(text(),'Action  Completed Successfully')]";
	public static String ConfirmationPopUpOk = "xpath#//button[@id='mandatoryDialogform:okButton']";

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox left of
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Pooja S
	 * @Date : 10-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String resultLocator = null;

	public static String checkBoxLeftOf(String checkBoxLabel) {
		String actualLocator = checkBoxLeftOf;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}
	
	public static String verifyCheckBoxClicked(String checkBoxLabel) {
		String actualLocator = checkBoxClickedcheck;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}
	
	public static String verifySubActCheckBoxClicked(String checkBoxLabel) {
		String actualLocator = SubActCheckBoxCheck;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to generate xpath based on locator
	 *             and value to select from dropdown including the checkbox
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Pooja S
	 * @Date : 16-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectListDropDown(String locator, String valueToSelect) {
		String xpath[] = locator.split("'");
		String resLocator = xpath[1].replace("_label", "");
		String actualLocator = dropDownListItem;
		String tempLocator = actualLocator.replace("%text%", valueToSelect);
		String resultLocator = tempLocator.replace("%locator%", resLocator);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Pooja S
	 * @Date : 16-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String checkBoxUnder(String checkBoxLabel) {
		String actualLocator = checkBoxUnder;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Pooja S
	 * @Date : 16-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String checkBox(String checkBoxLabel) {
		String actualLocator = checkBox;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}
	
	public static String checkBoxTick(String checkBoxLabel) {
		String actualLocator = checkBoxTick;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the radio button under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Pooja S
	 * @Date : 16-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String radioButton(String radioBtnLabel) {
		String actualLocator = radioBtn;
		resultLocator = actualLocator.replace("{0}", radioBtnLabel.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to generate xpath based on locator
	 *             and value to select from dropdown.
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Pooja s
	 * @Date : 18-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectList(String locator, String valueToSelect) {
		String xpath[] = locator.split("'");
		String resLocator = xpath[1].replace("_label", "");
		String actualLocator = dropDownList;
		String tempLocator = actualLocator.replace("{0}", valueToSelect);
		String resultLocator = tempLocator.replace("{1}", resLocator);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox left of
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:WajahatUmar S
	 * @Date : 05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String CheckedCheckBox(String checkBoxLabel) {
		String actualLocator = CheckedCheckBox;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox left of
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:WajahatUmar S
	 * @Date : 05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String CheckedCheckBoxYes(String checkBoxLabel) {
		String actualLocator = CheckedCheckBoxYes;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox left of
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:WajahatUmar S
	 * @Date : 05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String ActivityTabs(String ActivityName) {
		String actualLocator = ActivityTab;
		resultLocator = actualLocator.replace("%s", ActivityName);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox left of
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:WajahatUmar S
	 * @Date : 09-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String MaximizeActivityTabs(String ActivityName) {
		String actualLocator = MaximizeActivityTab;
		resultLocator = actualLocator.replace("%s", ActivityName);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox left of
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:WajahatUmar S
	 * @Date : 09-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String WfActivityVerify(String ActivityName) {
		String actualLocator = WfActivity;
		resultLocator = actualLocator.replace("%s", ActivityName);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox left of
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:WajahatUmar S
	 * @Date : 09-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String TranslationWfActivityVerify(String ActivityName) {
		String actualLocator = TranslationActivity;
		resultLocator = actualLocator.replace("%s", ActivityName);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is Pass OnSAve Error Radio Button Value
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:WajahatUmar S
	 * @Date : 22-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String OnSaveWarningRadioBtn(String RuleName) {
		String actualLocator = OnSaveWarningRadioBtn;
		resultLocator = actualLocator.replace("%s", RuleName);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is Pass OnSAve Warning Radio Button Value
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:WajahatUmar S
	 * @Date : 22-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String OnSaveErrorRadioBtn(String RuleName) {
		String actualLocator = OnSaveErrorRadioBtn;
		resultLocator = actualLocator.replace("%s", RuleName);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is Pass OnComplete Warning Radio Button Value
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:WajahatUmar S
	 * @Date : 22-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String OnCompleteWarningRadioBtn(String RuleName) {
		String actualLocator = OnCompleteWarningRadioBtn;
		resultLocator = actualLocator.replace("%s", RuleName);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is Pass OnComplete Error Radio Button Value
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:WajahatUmar S
	 * @Date : 22-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String OnCompleteErrorRadioBtn(String RuleName) {
		String actualLocator = OnCompleteErrorRadioBtn;
		resultLocator = actualLocator.replace("%s", RuleName);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is Pass OnComplete Error Radio Button Value
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:WajahatUmar S
	 * @Date : 22-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String RuleName(String RuleNames) {
		String actualLocator = RuleName;
		resultLocator = actualLocator.replace("%s", RuleNames);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the Admin and XML Doc
	 *             Config links
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Karthikeyan Natarajan
	 * @Date : 26-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String Links(String runtimeLabel) {
		String actualLocator = links;
		resultLocator = actualLocator.replace("%s", runtimeLabel.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the Admin and XML Doc
	 *             Config links
	 * @InputParameters: Field Locator,Field Label
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Karthikeyan Natarajan
	 * @Date : 26-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String ActivityDueDateFields(String locator, String runtimeLabel) {
		String actualLocator = locator;
		resultLocator = actualLocator.replace("%s", runtimeLabel.trim());
		return resultLocator;
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox left of
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Abhisek Ghosh
	 * @Date : 09-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String CheckedCheckBox2(String checkBoxLabel) {
		String actualLocator = CheckedCheckBox2;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}
}
