package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class LibrariesAEkeywordsPageObjects {
	
	//Libraries >> AE Keywords
	public static String aeKeywordsTextArea = "xpath#//textarea[@id='aeKeywordsForm:aeKeywords']";
	public static String activeCheckBoxLabel = "Active"; 
	public static String lenghtOfStringLabel= "xpath#//span[@id='aeKeywordsForm:displayForMessage']";
	
	public static String saveButton = "xpath#//button[@id='aeKeywordsForm:visibleSave']";
}
