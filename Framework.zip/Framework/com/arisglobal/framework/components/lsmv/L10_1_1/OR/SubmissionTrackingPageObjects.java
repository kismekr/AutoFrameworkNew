package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class SubmissionTrackingPageObjects {
	
	public static String submissionTrackingPaginator = "xpath#//span[@class='lsmv-pager-info']";
	public static String AERVerNumSelect ="xpath#//select[@id='subTrackAerVersionsCombo']";
	public static String AERVerNumSelectOption ="xpath#//select[@id='subTrackAerVersionsCombo']/option[@value='{%s}']";
	public static String distributionContactListGrid = "xpath#//div[@class='lsmv-grid-row']";
	public static String AERverNum = "xpath#//label[@id='adverseEventNew:mappedAerNoVersionLable']";
	
	/**********************************************************************************************************
	 * @Objective:Select version number
	 * @Input Parameters: Version number
	 * @Output Parameters:
	 * @author:DushyanthMahesh Date :16-Mar-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String AERVerNumSelectOption(String verNum) {
		String value = AERVerNumSelectOption;
		String value2;
		value2 = value.replace("{%s}", verNum);
		return value2;
	}
}
