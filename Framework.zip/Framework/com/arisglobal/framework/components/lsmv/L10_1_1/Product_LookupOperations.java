package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.Product_LookupPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;

public class Product_LookupOperations extends ToolManager{
	public static WebElement webElement;
	static String className = Product_LookupOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: Search product from product lookup in product library
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 22-August-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
    public static void searchProductLibStudy(String scenarioName) {
           Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
           agSetStepExecutionDelay("8000");
           agSetValue(Product_LookupPageObjects.productNameTextbox, getTestDataCellValue(scenarioName, "ProductName"));
           agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
           agClick(Product_LookupPageObjects.searchButton);
           agClick(Product_LookupPageObjects.LibStudyFirstProductChkbox);
           agClick(Product_LookupPageObjects.okButton);
    }

    public static void searchProductInProductLibrary(String scenarioName) {
           Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
           agClick(Product_LookupPageObjects.productLibray_RadioBtn);
           agSetStepExecutionDelay("3000");
           agSetValue(Product_LookupPageObjects.level1ProductTextbox(Product_LookupPageObjects.prodLibproductNameTextbox), getTestDataCellValue(scenarioName, "ProductLibraryProductName"));
           agClick(Product_LookupPageObjects.searchButton);
           agSetStepExecutionDelay("8000");
           agClick(Product_LookupPageObjects.checkFirstProdInProdLib);
           agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
           if(agIsVisible(Product_LookupPageObjects.indication_Popup)==true)// Add by avinash 13-Nov-2019
           {
        	   agClick(Product_LookupPageObjects.indicationPopup_CloseIcon);
           }
           agClick(Product_LookupPageObjects.prodLibOkButton);
           agSetStepExecutionDelay("3000");
           agWaitTillInvisibilityOfElement(Product_LookupPageObjects.prodLibOkButton);
           
    }
	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet
	 * @InputParameters: scenarioName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
    public static String getData(String scenarioName, String columnName) {
        Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
        return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
    }
}
