package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import org.openqa.selenium.By;

public class PortfoliosPageObjects {
	
	public static String portfoliosHover = "xpath#//span[contains(text(),'Portfolios')]";
	public static String productPortfolio = "xpath#//span[contains(text(),'Product portfolio')]";
	public static String productPorftKeywordSearch = "xpath#//input[@id='productGrpListForm:keyword']";
	public static String productPortfolioLable = "xpath#//div[@id='productGrpListForm:header']/label[text()='Product Portfolio']";
	public static String accountPortfolio = "xpath#//span[contains(text(),'Account portfolio')]";
	public static String accountPortfKeywordSearch = "xpath#//input[@id='accountsSeries:keyword']";
	public static String accountPortfolioLable = "xpath#//div[@class='CaseList_Title']/label[text()='Account Portfolio Listings']";
	public static String eventPortfolio = "xpath#//span[contains(text(),'Event portfolio')]";
	public static String eventPortfKeywordSearch = "xpath#//input[@id='eventGrpListForm:keyword']";
	public static String eventPortfolioLable = "xpath#//div[@class='CaseList_Title']/label[text()='Event Portfolio Listings']";
	public static String myAssignment = "xpath#//span[contains(text(),'My assignment')]";
	public static String myAssignmentLable = "xpath#//div[@id='productGrpListForm:header']/label[text()='My Assignment']";
	public static String myAssignKeywordSearch = "xpath#//input[@id='productGrpListForm:keyword']";
	
	
	
}
