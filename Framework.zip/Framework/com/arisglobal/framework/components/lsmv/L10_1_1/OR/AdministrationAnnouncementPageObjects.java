package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class AdministrationAnnouncementPageObjects {

	public static String newButton = "xpath#//a[@id='annolists:newId']";
	public static String deleteButton = "xpath#//a[@id='annolists:deleteId']";
	public static String searchTextbox = "xpath#//input[@id='annolists:searchText']";
	public static String searchIcon = "xpath#//a[@id='annolists:findButton']";
	public static String searchResultLabel = "xpath#//label[text()='%searchResult%']";
	public static String noResultLabel = "xpath#//td[contains(text(),'No Records Found')]";
	public static String edit_Icon = "xpath#//img[@id='annolists:announceDataTable:0:editLink1']";
	public static String listingScreen_CheckBoxs = "xpath#//label[text() = '%s%']/ancestor::tbody[@id='annolists:announceDataTable_data']/tr/td/div/child::div/span";
	public static String paginator = "xpath#//div[@id='annolists:announceDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String downloadIcon = "xpath#//a[@id='annolists:actionId']/img[contains(@src, 'Gear_off_new')]";
	public static String exportTypeLabel = "xpath#//button[contains(@id,'annolists')]/span[text()='Export To %export%']";
	public static String export_popup = "xpath#//span[@id='annolists:columnSelectionDialogId_title']";
	public static String export_Btn = "xpath#//button[@id='annolists:submitId']";
	public static String exportCancel_Btn = "xpath#//button[@id='annolists:cancelDialogId']";

	// Administration >> Announcement >> New
	public static String subjectTextBox = "xpath#//input[@id='newAnnounce:subject']";
	public static String sourceDocButton = "xpath#//input[@type='file' and contains(@id, 'newAnnounce')]";
	public static String sourceDocLink = "xpath#//a[@id='newAnnounce:commandLinkAttachment']";
	public static String messageTextArea = "xpath#//textarea[@id='newAnnounce:message']";
	public static String publicCheckBoxLabel = "Public";
	public static String assignToRadio = "xpath#//table[@id='newAnnounce:assignTo']//label[contains(text(),'%radio%')]";
	public static String groupLabel = "xpath#//label[@id='newAnnounce:group']";
	public static String userLabel = "xpath#//label[@id='newAnnounce:user']";
	public static String addButton = "xpath#//a[contains(@id,'newAnnounce:add')]";
	public static String saveButton = "xpath#//button[@id='newAnnounce:visibleSave']";
	public static String cancelButton = "xpath#//button[@id='newAnnounce:cancelId']";

	public static String expireDateTextbox = "xpath#//input[@id='newAnnounce:expDateId_input']";
	public static String monthSelect = "xpath#//div[@class='ui-datepicker-title']/select[@class='ui-datepicker-month']";
	public static String yearSelect = "xpath#//div[@class='ui-datepicker-title']/select[@class='ui-datepicker-year']";
	public static String monthDropdown = "xpath#//div[@class='ui-datepicker-title']/select[@class='ui-datepicker-month']/option[text()='{@}']";
	public static String yearDropdown = "xpath#//div[@class='ui-datepicker-title']/select[@class='ui-datepicker-year']/option[text()='{@}']";
	public static String dateSelect = "xpath#//a[@class='ui-state-default'][text()='{@}']";

	public static String dateSelect(String date) {
		String value = dateSelect;
		value = value.replace("{@}", date);
		return value;
	}

	public static String monthDropdown(String month) {
		String value = monthDropdown;
		value = value.replace("{@}", month);
		return value;
	}

	public static String yearDropdown(String year) {
		String value = yearDropdown;
		value = value.replace("{@}", year);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to pass Radio Button Label to be
	 *             selected.
	 * @InputParameters: Radio Button Label
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 25-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	// Assign To Radio
	public static String assignToRadioBtn(String label) {
		String value = assignToRadio.replace("%radio%", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to pass Search Result Text.
	 * @InputParameters: Search Result Text
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 25-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	// Search Result Data
	public static String searchResult(String label) {
		String value = searchResultLabel.replace("%searchResult%", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to pass Search Result Text for Check
	 *             Box Selection.
	 * @InputParameters: Search Result Text
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 25-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	// Listing Screen Data Checkbox
	public static String selectListingCheckbox(String runTimeLabel) {
		String value = listingScreen_CheckBoxs.replace("%s%", runTimeLabel);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to pass Export Type Label.
	 * @InputParameters: Export Type >> Excel or PDF
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 25-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	// Listing Screen Export Type >> Excel or PDF
	public static String selectExportType(String runTimeLabel) {
		String value = exportTypeLabel.replace("%export%", runTimeLabel);
		return value;
	}

}
