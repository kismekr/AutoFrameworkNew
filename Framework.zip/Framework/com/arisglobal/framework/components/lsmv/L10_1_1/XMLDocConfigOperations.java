package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.WorkFlowPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.XMLDocConfigPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DataBaseOperations;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.aventstack.extentreports.Status;

public class XMLDocConfigOperations extends ToolManager {

	/**********************************************************************************************************
	 * @Objective: The below method is created to select list type dropdown value.
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 16-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setListDropDownValue(String locator, String valueToSelect) {
		if (!valueToSelect.equalsIgnoreCase("#skip#")) {
			// agJavaScriptExecuctorScrollToElement(locator);
			agSetStepExecutionDelay("2000");
			agClick(locator);
			agClick(XMLDocConfigPageObjects.selectListDropDown(locator, valueToSelect));
			// agCheckPropertyText(valueToSelect, locator);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to navigate in XML Doc configuration
	 *             screen
	 * @InputParameters: TabName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :14-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void FDE_Navigations(String TabName) {
		agSetStepExecutionDelay("5000");
		agClick(XMLDocConfigPageObjects.FDE_tabNavigation(TabName));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select radio button.
	 * @InputParameters: label, radioButtonLabel
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 18-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickRadioButton(String label, String radioButtonLabel) {
		if (!label.trim().contains("#skip#") && !radioButtonLabel.trim().contains("#skip#")) {
			agClick(XMLDocConfigPageObjects.selectRadioButton(label, radioButtonLabel));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Check/Uncheck Operation on
	 *             radio button under Specified Label.
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 23-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickRadioBtn(String label, String boolCheck) {
		if (!boolCheck.trim().contains("#skip#")) {
			String radioBtnStatus = null;
			radioBtnStatus = ToolManager.agGetAttribute("class", WorkFlowPageObjects.radioButton(label));
			if (radioBtnStatus.contains("blank") || !radioBtnStatus.contains("pi-check")) {
				radioBtnStatus = "false";
			} else {
				radioBtnStatus = "true";
			}
			if ((boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check"))
					&& radioBtnStatus.equalsIgnoreCase("false")) {
				ToolManager.agClick(WorkFlowPageObjects.radioButton(label));
			} else if ((boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck"))
					&& radioBtnStatus.equalsIgnoreCase("true")) {
				ToolManager.agClick(WorkFlowPageObjects.radioButton(label));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to Navigate to the XML Doc Config Page
	 * @InputParameters:
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void XMLDocConfigNavigation() {

		agMouseHover(XMLDocConfigPageObjects.Links(XMLDocConfigPageObjects.Administartion));
		agClick(XMLDocConfigPageObjects.Links(XMLDocConfigPageObjects.XMLDocConfiguration));
		agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.NewBtn);
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to read the xmlDoc Config from UI and to
	 *             update in xmlDoc Config
	 * @InputParameters:
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void XMLDocConfigRead() throws SQLException {
		Reports.ExtentReportLog("", Status.INFO, "XML Doc Config Read Starts", false);
		Connection dbCon = null;
		try {
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);
			XMLDocConfigNavigation();

			int numberOfRecords = agGetElementList(XMLDocConfigPageObjects.xmlDocTable).size();

			for (int rowIndex = 1; rowIndex <= numberOfRecords; rowIndex++) {
				agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.NewBtn);
				String configName = agGetText(
						XMLDocConfigPageObjects.XMLDocConfigTableCell(XMLDocConfigPageObjects.ConfigName, rowIndex));
				String dtdSchema = agGetText(
						XMLDocConfigPageObjects.XMLDocConfigTableCell(XMLDocConfigPageObjects.DTDSchema, rowIndex));
				String dtdType = agGetText(
						XMLDocConfigPageObjects.XMLDocConfigTableCell(XMLDocConfigPageObjects.DTDType, rowIndex));
				String rootTagName = agGetText(
						XMLDocConfigPageObjects.XMLDocConfigTableCell(XMLDocConfigPageObjects.RootTagName, rowIndex));

				System.out.println(configName + " " + dtdSchema + " " + dtdType + " " + rootTagName);
				System.out.println();

				agClick(XMLDocConfigPageObjects.clickEdit(configName));

				agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.cancel_Btn);

				String ConfigName = agGetAttribute("value",
						XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.XMLDocConfigurationNameLabel));
				String RootTagName = agGetAttribute("value",
						XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.RootTagNameLabel));
				String DTDSchema = agGetText(XMLDocConfigPageObjects.DTDSchema_Dropdown);
				String DTDName = agGetText(XMLDocConfigPageObjects.DTDName_Dropdown);
				String DTDType = agGetText(XMLDocConfigPageObjects.DTDType_Dropdown);
				String PostProcessingScript = agGetText(XMLDocConfigPageObjects.postProcessingScriptImport_Dropdown);
				String PreProcessingScrit = agGetText(XMLDocConfigPageObjects.preProcessingScriptExport_Dropdown);
				if (configName.equalsIgnoreCase(ConfigName) && rootTagName.equalsIgnoreCase(RootTagName)
						&& dtdSchema.equalsIgnoreCase(DTDSchema) && dtdType.equalsIgnoreCase(DTDName)) {
					Reports.ExtentReportLog("", Status.PASS, "XML Doc Config Details Matches for " + configName, true);
				} else {
					if (dtdSchema.equalsIgnoreCase("R2") && dtdType.contains("ICHICSR")) {
						Reports.ExtentReportLog("", Status.PASS, "XML Doc Config Details Matches for " + configName,
								true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL,
								"XML Doc Config Details Doesnt Matches for " + configName, true);
					}

				}
				// XML Doc Config Write
				DataBaseOperations.performWrite(dbCon,
						"update xmldocconfig set DTDName='" + parseDBValue(DTDName) + "' , RootTagName = '"
								+ parseDBValue(RootTagName) + "' , DTDSchema = '" + parseDBValue(DTDSchema)
								+ "' , DTDType = '" + parseDBValue(DTDType) + "' , PostProcessingScript = '"
								+ parseDBValue(PostProcessingScript) + "' , PreProcessingScript = '"
								+ parseDBValue(PreProcessingScrit) + "' where XMLDocConfigName='"
								+ parseDBValue(ConfigName) + "'");

				ImportConfigSendersRead(ConfigName);
				ExportConfigForReceivers(ConfigName);
				ImportPathConfig(ConfigName);
				DTDXpathRead(ConfigName);

				agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.XMLDocConfigCancel);
				agClick(XMLDocConfigPageObjects.XMLDocConfigCancel);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "XML Doc Config Read Failed", true);
		} finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		Reports.ExtentReportLog("", Status.INFO, "XML Doc Config Read Ends", false);
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to read the Import Config for Senders
	 * @InputParameters:
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @throws SQLException
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ImportConfigSendersRead(String configName) {
		Reports.ExtentReportLog("", Status.INFO,
				"Import Config for Senders Read Starts for configuration " + configName, false);
		Connection dbCon = null;
		try {
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);
			FDE_Navigations(XMLDocConfigPageObjects.ImportConfigurationForSenders);
			agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.SenderSettingsLabel);
			int numberOfRecords = agGetElementList(XMLDocConfigPageObjects.ImportConfigForSendersTable).size();
			if (agIsVisible(XMLDocConfigPageObjects.ICFSNoRecordsFound)) {
				Reports.ExtentReportLog("", Status.INFO, "Nothing in Import Config for Senders to Read", true);
				return;
			}
			if (numberOfRecords == 0) {
				Reports.ExtentReportLog("", Status.INFO, "Nothing in Import Config for Senders to Read", true);
				return;
			} else {

				for (int rowIndex = 1; rowIndex <= numberOfRecords; rowIndex++) {
					agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.SenderSettingsLabel);
					String sender = agGetText(XMLDocConfigPageObjects
							.XMLDocConfigTableCell(XMLDocConfigPageObjects.ICFSSender, rowIndex));
					String defaultSender = agGetText(XMLDocConfigPageObjects
							.XMLDocConfigTableCell(XMLDocConfigPageObjects.ICFSDefaultSender, rowIndex));
					String defaultReceiver = agGetText(XMLDocConfigPageObjects
							.XMLDocConfigTableCell(XMLDocConfigPageObjects.ICFSDefaultReceiver, rowIndex));
					String defaultSourceMedium = agGetText(XMLDocConfigPageObjects
							.XMLDocConfigTableCell(XMLDocConfigPageObjects.ICFSDefaultSourceMedium, rowIndex));
					String sourceDocument = "";
					if (agIsVisible(XMLDocConfigPageObjects
							.XMLDocConfigTableCell(XMLDocConfigPageObjects.ICFSSourceDocument, rowIndex))) {
						sourceDocument = agGetText(XMLDocConfigPageObjects
								.XMLDocConfigTableCell(XMLDocConfigPageObjects.ICFSSourceDocument, rowIndex));
					}
					agClick(XMLDocConfigPageObjects.XMLDocConfigTableCell(XMLDocConfigPageObjects.ICFSConfigEdit,
							rowIndex));
					agWaitTillVisibilityOfElement(
							XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.ICFSImportFormTextBox));
					// Text Box and Drop downs
					String SenderTextBox = agGetAttribute("value", XMLDocConfigPageObjects.ICFSSenderTextBox);
					String DefaultSenderTextBox = agGetAttribute("value",
							XMLDocConfigPageObjects.ICFSDefaultSenderTextBox);
					String DefaultReceiverTextBox = agGetAttribute("value",
							XMLDocConfigPageObjects.ICFSDefaultReceiverTextBox);
					String DefaultSourceMediumTextBox = agGetText(XMLDocConfigPageObjects
							.ICFSDropDownText(XMLDocConfigPageObjects.ICFSDefaultDefaultSourceMediumTextBox));
					String SourceDocumentTextBox = agGetText(XMLDocConfigPageObjects
							.ICFSDropDownText(XMLDocConfigPageObjects.ICFSSourceDocumentTextBox));
					String ImportFormTextBox = agGetText(
							XMLDocConfigPageObjects.ICFSDropDownText(XMLDocConfigPageObjects.ICFSImportFormTextBox));
					System.out.println(SenderTextBox + " " + DefaultSenderTextBox + " " + DefaultReceiverTextBox + " "
							+ DefaultSourceMediumTextBox + " " + ImportFormTextBox + " " + SourceDocumentTextBox);

					boolean boolSender = sender.equalsIgnoreCase(SenderTextBox);
					boolean boolDefaultSender = defaultSender.equalsIgnoreCase(DefaultSenderTextBox);
					boolean boolDefaultReceiver = defaultReceiver.equalsIgnoreCase(DefaultReceiverTextBox);
					boolean boolDefaultSourceMedium = defaultSourceMedium.equalsIgnoreCase(DefaultSourceMediumTextBox);

					if (boolSender && boolDefaultSender && boolDefaultReceiver && boolDefaultSourceMedium) {
						if (sourceDocument.equalsIgnoreCase("") && SourceDocumentTextBox.contains("Select")) {
							Reports.ExtentReportLog("", Status.PASS,
									"Import Config for Senders Details Matches for Sender :" + SenderTextBox
											+ " of Configuration " + configName,
									true);
						} else if (SourceDocumentTextBox.equalsIgnoreCase("Attach Import XML")
								&& sourceDocument.equalsIgnoreCase("Attach Import XML to Summary Sheet")) {
							Reports.ExtentReportLog("", Status.PASS,
									"Import Config for Senders Details Matches for Sender :" + SenderTextBox
											+ " of Configuration " + configName,
									true);
						} else if (SourceDocumentTextBox.equalsIgnoreCase("Merge Import XML")
								&& sourceDocument.equalsIgnoreCase("Merge Import XML to Summary Sheet")) {
							Reports.ExtentReportLog("", Status.PASS,
									"Import Config for Senders Details Matches for Sender :" + SenderTextBox
											+ " of Configuration " + configName,
									true);
						} else {
							Reports.ExtentReportLog("", Status.FAIL,
									"Import Config for Senders Details Doesnt Matches for Sender :" + SenderTextBox
											+ " of Configuration " + configName,
									true);
						}
					} else {
						Reports.ExtentReportLog("", Status.FAIL,
								"Import Config for Senders Details Doesnt Matches for Sender :" + SenderTextBox
										+ " of Configuration " + configName,
								true);
					}

					// Check Boxes
					String ICFSDefaultConfiguration = checkBoxSelect(XMLDocConfigPageObjects.ICFSDefaultConfigCheckBox);
					String ICFSAcknowledgementRequiredCheckBox = checkBoxSelect(
							XMLDocConfigPageObjects.ICFSAcknowledgementRequiredCheckBox);
					String ICFSPlaceAckXMLinFolderCheckBox = checkBoxSelect(
							XMLDocConfigPageObjects.ICFSPlaceAckXMLinFolderCheckBox);
					String ICFSRejectCasesAssessedasSDCheckBox = checkBoxSelect(
							XMLDocConfigPageObjects.ICFSRejectCasesAssessedasSDCheckBox);
					String ICFSMDNRequiredCheckBox = checkBoxSelect(XMLDocConfigPageObjects.ICFSMDNRequiredCheckBox);
					String ICFSGenerateACkafterAERgenerationCheckBox = checkBoxSelect(
							XMLDocConfigPageObjects.ICFSGenerateACkafterAERgenerationCheckBox);
					String ICFSSDManualRejectCheckBox = checkBoxSelect(
							XMLDocConfigPageObjects.ICFSSDManualRejectCheckBox);
					String ICFSRejectCasesforhardvalidationsCheckBox = checkBoxSelect(
							XMLDocConfigPageObjects.ICFSRejectCasesforhardvalidationsCheckBox);
					String ICFSImportSourceDocumentCheckBox = checkBoxSelect(
							XMLDocConfigPageObjects.ICFSImportSourceDocumentCheckBox);
					System.out.println(ICFSAcknowledgementRequiredCheckBox + " " + ICFSPlaceAckXMLinFolderCheckBox + " "
							+ ICFSRejectCasesAssessedasSDCheckBox + " " + ICFSMDNRequiredCheckBox + " "
							+ ICFSGenerateACkafterAERgenerationCheckBox + " " + ICFSImportSourceDocumentCheckBox + " "
							+ ICFSRejectCasesforhardvalidationsCheckBox + " " + ICFSSDManualRejectCheckBox);
					// Radio Buttons
					String ICFSEasyViewRadioButton = radioButtonSelect(XMLDocConfigPageObjects.ICFSEasyViewRadioButton);
					String ICFSSummarySheetRadioButton = radioButtonSelect(
							XMLDocConfigPageObjects.ICFSSummarySheetRadioButton);
					System.out.println(ICFSEasyViewRadioButton + " " + ICFSSummarySheetRadioButton);

					DataBaseOperations.performWrite(dbCon, "update xmldocconfig set ICFSSender='"
							+ parseDBValue(SenderTextBox) + "' , ICFSDefaultReceiver = '"
							+ parseDBValue(DefaultReceiverTextBox) + "' , ICFSDefaultSender = '"
							+ parseDBValue(DefaultSenderTextBox) + "' , ICFSDefaultSourceMedium = '"
							+ parseDBValue(DefaultSourceMediumTextBox) + "' , ICFSSourceDocument = '"
							+ parseDBValue(SourceDocumentTextBox) + "' , ICFSImportForm = '"
							+ parseDBValue(ImportFormTextBox) + "' , ICFSDefaultConfigCB = '"
							+ parseDBValue(ICFSDefaultConfiguration) + "' , ICFSACKRequired = '"
							+ parseDBValue(ICFSAcknowledgementRequiredCheckBox) + "' , ICFSPlaceACK = '"
							+ parseDBValue(ICFSPlaceAckXMLinFolderCheckBox) + "' , ICFSRejectCasesAssessedasSD = '"
							+ parseDBValue(ICFSRejectCasesAssessedasSDCheckBox) + "' , ICFSMDNRequired = '"
							+ parseDBValue(ICFSMDNRequiredCheckBox) + "' , ICFSGenerateACK = '"
							+ parseDBValue(ICFSGenerateACkafterAERgenerationCheckBox) + "' , ICFSDorManual = '"
							+ parseDBValue(ICFSSDManualRejectCheckBox) + "' , ICFSRejectCasesHV = '"
							+ parseDBValue(ICFSRejectCasesforhardvalidationsCheckBox)
							+ "' , ICFSImportSourceDocument = '" + parseDBValue(ICFSImportSourceDocumentCheckBox)
							+ "' , ICFSEasyView = '" + parseDBValue(ICFSEasyViewRadioButton)
							+ "' , ICFSSummarySheet = '" + parseDBValue(ICFSSummarySheetRadioButton)
							+ "' where XMLDocConfigName='" + parseDBValue(configName) + "'");

					agClick(XMLDocConfigPageObjects.ICFSCancel);
					agWaitTillInvisibilityOfElement(XMLDocConfigPageObjects.ICFSCancel);
				}
			}
			Reports.ExtentReportLog("", Status.INFO,
					"Import Config for Senders Read Ends for configuration " + configName, false);
		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL,
					"Import Config for Senders Read Failed for configuration " + configName, true);
		} finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to read the Export Config for Receivers
	 * @InputParameters:
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ExportConfigForReceivers(String configName) {
		Reports.ExtentReportLog("", Status.INFO,
				"Export Config for Receiver Read Starts for configuration " + configName, false);
		Connection dbCon = null;
		try {
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);
			FDE_Navigations(XMLDocConfigPageObjects.ExportConfigurationForReceivers);
			agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.ReceiverSettingsLabel);
			int numberOfRecords = agGetElementList(XMLDocConfigPageObjects.ECFRTable).size();
			if (agIsVisible(XMLDocConfigPageObjects.ECFRNoRecordsFound)) {
				Reports.ExtentReportLog("", Status.INFO, "Nothing in Export Config for Recievers to Read", true);
				return;
			}
			if (numberOfRecords == 0) {
				Reports.ExtentReportLog("", Status.INFO, "Nothing in Export Config for Recievers to Read", true);
				return;
			} else {
				for (int rowIndex = 1; rowIndex <= numberOfRecords; rowIndex++) {
					agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.ReceiverSettingsLabel);
					String enableDocExport = "", xmlImportACKEnabled = "", docImportACKEnabled = "";
					String receiver = agGetText(
							XMLDocConfigPageObjects.XMLDocConfigTableCell(XMLDocConfigPageObjects.receiver, rowIndex));
					if (agIsVisible(XMLDocConfigPageObjects
							.XMLDocConfigTableCell(XMLDocConfigPageObjects.enableDocExport, rowIndex))) {
						enableDocExport = agGetText(XMLDocConfigPageObjects
								.XMLDocConfigTableCell(XMLDocConfigPageObjects.enableDocExport, rowIndex));
					}
					if (agIsVisible(XMLDocConfigPageObjects
							.XMLDocConfigTableCell(XMLDocConfigPageObjects.xmlImportACKEnabled, rowIndex))) {
						xmlImportACKEnabled = agGetText(XMLDocConfigPageObjects
								.XMLDocConfigTableCell(XMLDocConfigPageObjects.xmlImportACKEnabled, rowIndex));
					}

					if (agIsVisible(XMLDocConfigPageObjects
							.XMLDocConfigTableCell(XMLDocConfigPageObjects.docImportACKEnabled, rowIndex))) {
						docImportACKEnabled = agGetText(XMLDocConfigPageObjects
								.XMLDocConfigTableCell(XMLDocConfigPageObjects.docImportACKEnabled, rowIndex));
					}
					agClick(XMLDocConfigPageObjects.XMLDocConfigTableCell(XMLDocConfigPageObjects.ECFRConfigEdit,
							rowIndex));
					agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.ECFRReceiver);
					String Receiver = agGetAttribute("value", XMLDocConfigPageObjects.ECFRReceiver);

					// Validate ECFR Radio Buttons

					validateECFRRadioButtons(configName, Receiver, enableDocExport, xmlImportACKEnabled,
							docImportACKEnabled);

					if (receiver.equalsIgnoreCase(Receiver)) {
						Reports.ExtentReportLog("", Status.PASS,
								"Export Config for Receiver Receiver Text Box for Receiver " + Receiver
										+ " of Configuration " + configName,
								true);

					} else {
						Reports.ExtentReportLog("", Status.FAIL,
								"Export Config for Receiver Receiver Text Box Doesnt Matches for Receiver " + Receiver
										+ " of Configuration " + configName,
								true);
					}
					String MeddraPopulation = agGetText(XMLDocConfigPageObjects.ECFRMeddra);
					String DisplayR3TagsinXML = checkBoxSelect(XMLDocConfigPageObjects.ECFRDisplayR3TagsInXMLLabel);

					System.out.println(MeddraPopulation + " " + DisplayR3TagsinXML);

					DataBaseOperations.performWrite(dbCon,
							"update xmldocconfig set ECFREnableDocumentExport='" + parseDBValue(enableDocExport)
									+ "' , ECFRXMLACKImportEnabled = '" + parseDBValue(xmlImportACKEnabled)
									+ "' , ECFRDocACKImportEnabled = '" + parseDBValue(docImportACKEnabled)
									+ "' , ECFRReceiver = '" + parseDBValue(Receiver) + "' , ECFRMeddra = '"
									+ parseDBValue(MeddraPopulation) + "' , ECFRDisplayR3Tags = '"
									+ parseDBValue(DisplayR3TagsinXML) + "' where XMLDocConfigName='"
									+ parseDBValue(configName) + "'");

					agClick(XMLDocConfigPageObjects.ECFRCancelButton);

					agWaitTillInvisibilityOfElement(XMLDocConfigPageObjects.ECFRCancelButton);
				}

			}
			Reports.ExtentReportLog("", Status.INFO,
					"Export Config for Receiver Read Ends for configuration " + configName, false);
		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL,
					"Export Config for Receiver Read Failed for configuration " + configName, true);
		} finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to read the Import Path Config
	 * @InputParameters: Config Name
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ImportPathConfig(String configName) {
		Reports.ExtentReportLog("", Status.INFO, "Import Path Config Read Starts for configuration " + configName,
				false);
		Connection dbCon = null;
		try {
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);
			FDE_Navigations(XMLDocConfigPageObjects.ImportPathConfigurations);
			agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.schema_TextBox);
			String Schema = agGetAttribute("value", XMLDocConfigPageObjects.schema_TextBox);
			String SequenceLength = agGetAttribute("value", XMLDocConfigPageObjects.sequenceLength_TextBox);
			String XMLImportPath = agGetAttribute("value",
					XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.XMLimportPath_Label));
			String XMLACKExportPath = agGetAttribute("value",
					XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.XMLAckExportPath_Label));
			String DocumentImportPath = agGetAttribute("value",
					XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.docImportPath_Label));
			String DocImportBackUpPath = agGetAttribute("value",
					XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.docImportBackPath_Label));
			String DocExportACKPath = agGetAttribute("value",
					XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.docAckExportPath_Label));
			DataBaseOperations.performWrite(dbCon, "update xmldocconfig set IPCSchema='" + parseDBValue(Schema)
					+ "' , IPCSequenceLength = '" + parseDBValue(SequenceLength) + "' , IPCXMLImportPath = '"
					+ parseDBValue(XMLImportPath) + "' , ICPXMLACKExportPath = '" + parseDBValue(XMLACKExportPath)
					+ "' , ICPDocImportPath = '" + parseDBValue(DocumentImportPath) + "' , ICPDocImportBackUpPath = '"
					+ parseDBValue(DocImportBackUpPath) + "' , ICPDocACKExpPath = '" + parseDBValue(DocExportACKPath)
					+ "' where XMLDocConfigName='" + parseDBValue(configName) + "'");

			System.out.println(Schema + " " + SequenceLength + " " + XMLImportPath + " " + " " + XMLACKExportPath + " "
					+ DocumentImportPath + " " + DocImportBackUpPath + " " + DocExportACKPath);
			Reports.ExtentReportLog("", Status.INFO, "Import Path Config Read Ends for configuration " + configName,
					false);
		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, "Import Path Config Read Failed for configuration " + configName,
					true);
		} finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to read the DTD Xpath Path Config
	 * @InputParameters: Config Name
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void DTDXpathRead(String configName) {
		Reports.ExtentReportLog("", Status.INFO, "DTD  XPath Config Read Starts for configuration " + configName,
				false);
		Connection dbCon = null;
		try {
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);
			FDE_Navigations(XMLDocConfigPageObjects.DTDXpaths);
			agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.DTDXPathsLabel);
			int numberOfRecords = agGetElementList(XMLDocConfigPageObjects.DTDXpathTable).size();
			if (agIsVisible(XMLDocConfigPageObjects.DTDXPATHNorecordsFound)) {
				Reports.ExtentReportLog("", Status.INFO, "Nothing in DTD XPATH Config to Read", true);
				return;
			}
			if (numberOfRecords == 0) {
				Reports.ExtentReportLog("", Status.INFO, "Nothing in DTD Xpath Config to Read", true);
				return;
			} else {
				for (int rowIndex = 1; rowIndex <= numberOfRecords; rowIndex++) {
					agWaitTillVisibilityOfElement(XMLDocConfigPageObjects
							.XMLDocConfigTableCell(XMLDocConfigPageObjects.DTDXpathEdit, rowIndex));
					String xpath = agGetText(
							XMLDocConfigPageObjects.XMLDocConfigTableCell(XMLDocConfigPageObjects.XPATH, rowIndex));
					String xpathValue = agGetText(XMLDocConfigPageObjects
							.XMLDocConfigTableCell(XMLDocConfigPageObjects.XPATHValue, rowIndex));
					String XPATHValueType = agGetText(XMLDocConfigPageObjects
							.XMLDocConfigTableCell(XMLDocConfigPageObjects.XPATHValueType, rowIndex));

					agClick(XMLDocConfigPageObjects.XMLDocConfigTableCell(XMLDocConfigPageObjects.DTDXpathEdit,
							rowIndex));
					agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.DTDxpath_SaveBtn);

					String XPATH = agGetAttribute("value",
							XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.xpath_Label));
					String XPATHVALUE = agGetAttribute("value",
							XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.xpathValue_Label));
					String XPATHVALUETYPE = agGetText(XMLDocConfigPageObjects.xpathValueType_Dropdown);

					boolean boolXpath = xpath.equalsIgnoreCase(XPATH);
					boolean boolXpathValue = xpathValue.equalsIgnoreCase(XPATHVALUE);
					if (boolXpath && boolXpathValue) {
						if (XPATHValueType.equalsIgnoreCase(XPATHVALUETYPE)) {
							Reports.ExtentReportLog("", Status.PASS,
									"DTD  XPath Config Matches for Xpath " + XPATH + "+ configuration " + configName,
									true);
						} else if (XPATHValueType.isEmpty() && XPATHVALUETYPE.contains("Select")) {
							Reports.ExtentReportLog("", Status.PASS,
									"DTD  XPath Config Matches for Xpath " + XPATH + "+ configuration " + configName,
									true);
						} else {
							Reports.ExtentReportLog("", Status.FAIL, "DTD  XPath Config Doesnt Matches for Xpath "
									+ XPATH + "+ configuration " + configName, true);
						}

					} else {
						Reports.ExtentReportLog("", Status.FAIL,
								"DTD  XPath Config Doesnt Matches for Xpath " + XPATH + "+ configuration " + configName,
								true);
					}
					String statement = "update xmldocconfig set DTDXpath_" + rowIndex + " = '"
							+ parseDBValue(XPATH.replace("'", "''")) + "' , DTDXpathValue_" + rowIndex + " = '"
							+ parseDBValue(XPATHVALUE) + "' , DTDXpathValueType_" + rowIndex + " = '"
							+ parseDBValue(XPATHVALUETYPE) + "' where XMLDocConfigName='" + parseDBValue(configName)
							+ "'";
					System.out.println(statement);
					DataBaseOperations.performWrite(dbCon, statement);

					agClick(XMLDocConfigPageObjects.DTDxpath_CancelBtn);
					agWaitTillInvisibilityOfElement(XMLDocConfigPageObjects.DTDxpath_CancelBtn);
				}
			}
			Reports.ExtentReportLog("", Status.INFO, "DTD  XPath Config Read Ends for configuration " + configName,
					false);
		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, "DTD  XPath Config Read Failed for configuration " + configName,
					true);
		} finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to read whethere the Check box is checked or
	 *             not
	 * @InputParameters: CheckBox Name
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String checkBoxSelect(String checkBoxName) {
		String active = "ui-state-active";
		String value = "Unchecked";
		String classValue = agGetAttribute("class", XMLDocConfigPageObjects.checkBoxUnder(checkBoxName));
		if (classValue.contains(active))
			value = "Checked";
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to read whethere the Radio button is selected
	 *             or not
	 * @InputParameters: Radio button Name
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String radioButtonSelect(String radioButtonName) {
		String active = "ui-state-active";
		String value = "Unchecked";
		String classValue = agGetAttribute("class", XMLDocConfigPageObjects.radioButton(radioButtonName));
		if (classValue.contains(active))
			value = "Checked";
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to read whethere the ECFR Radio button is
	 *             selected or not
	 * @InputParameters: Radio button Name, Value to be selected
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean ECFRadioButtonSelect(String radioButtonName, String valueSelected) {
		String active = "ui-state-active";
		boolean value = false;
		String classValue = agGetAttribute("class",
				XMLDocConfigPageObjects.ECFRRadioButton(radioButtonName, valueSelected));
		if (classValue.contains(active))
			value = true;
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to validate ECFR Radio button is enabled
	 *             correctly or not
	 * @InputParameters: Config Name, Reciver Name , ECFR Radio buttons values
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void validateECFRRadioButtons(String configName, String Receiver, String enableDocExport,
			String xmlImportACKEnabled, String docImportACKEnabled) {
		// Enable Document Export Radio Button
		if (enableDocExport.isEmpty()) {
			boolean boolenableDocExportYes = ECFRadioButtonSelect(XMLDocConfigPageObjects.ECFREnableDocumentExportLabel,
					"Yes");
			boolean boolenableDocExportNo = ECFRadioButtonSelect(XMLDocConfigPageObjects.ECFREnableDocumentExportLabel,
					"No");

			if (!boolenableDocExportYes && !boolenableDocExportNo) {
				Reports.ExtentReportLog("", Status.PASS,
						"Export Config for Receiver Enable Document Export Radio Button for Receiver " + Receiver
								+ " of Configuration " + configName,
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Export Config for Receiver Enable Document Export Radio Button for Receiver " + Receiver
								+ " of Configuration " + configName,
						true);
			}

		} else {
			boolean boolenableDocExport = ECFRadioButtonSelect(XMLDocConfigPageObjects.ECFREnableDocumentExportLabel,
					enableDocExport);
			if (boolenableDocExport) {
				Reports.ExtentReportLog("", Status.PASS,
						"Export Config for Receiver Enable Document Export Radio Button for Receiver " + Receiver
								+ " of Configuration " + configName,
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Export Config for Receiver Enable Document Export Radio Button for Receiver " + Receiver
								+ " of Configuration " + configName,
						true);
			}
		}

		// XML Import ACK enabled
		if (xmlImportACKEnabled.isEmpty()) {
			boolean booleanxmlImportACKEnabledYes = ECFRadioButtonSelect(
					XMLDocConfigPageObjects.ECFRXMLACKImpotEnabledLabel, "Yes");
			boolean boolxmlImportACKEnabledNo = ECFRadioButtonSelect(
					XMLDocConfigPageObjects.ECFRXMLACKImpotEnabledLabel, "No");

			if (!booleanxmlImportACKEnabledYes && !boolxmlImportACKEnabledNo) {
				Reports.ExtentReportLog("", Status.PASS,
						"Export Config for Receiver Enable Document Export Radio Button for Receiver " + Receiver
								+ " of Configuration " + configName,
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Export Config for Receiver Enable Document Export Radio Button for Receiver " + Receiver
								+ " of Configuration " + configName,
						true);
			}

		} else {
			boolean boolxmlImportACKEnabled = ECFRadioButtonSelect(XMLDocConfigPageObjects.ECFRXMLACKImpotEnabledLabel,
					xmlImportACKEnabled);
			if (boolxmlImportACKEnabled) {
				Reports.ExtentReportLog("", Status.PASS,
						"Export Config for Receiver Enable Document Export Radio Button for Receiver " + Receiver
								+ " of Configuration " + configName,
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Export Config for Receiver Enable Document Export Radio Button for Receiver " + Receiver
								+ " of Configuration " + configName,
						true);
			}
		}
		// Document Import ACK enabled
		if (docImportACKEnabled.isEmpty()) {
			boolean booldocImportACKEnabledYes = ECFRadioButtonSelect(
					XMLDocConfigPageObjects.ECFRDocumentACKImportEnabledLabel, "Yes");
			boolean booldocImportACKEnabledNo = ECFRadioButtonSelect(
					XMLDocConfigPageObjects.ECFRDocumentACKImportEnabledLabel, "No");

			if (!booldocImportACKEnabledYes && !booldocImportACKEnabledNo) {
				Reports.ExtentReportLog("", Status.PASS,
						"Export Config for Receiver Enable Document Export Radio Button for Receiver " + Receiver
								+ " of Configuration " + configName,
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Export Config for Receiver Enable Document Export Radio Button for Receiver " + Receiver
								+ " of Configuration " + configName,
						true);
			}

		} else {
			boolean booldocImportACKEnabled = ECFRadioButtonSelect(
					XMLDocConfigPageObjects.ECFRDocumentACKImportEnabledLabel, docImportACKEnabled);
			if (booldocImportACKEnabled) {
				Reports.ExtentReportLog("", Status.PASS,
						"Export Config for Receiver Enable Document Export Radio Button for Receiver " + Receiver
								+ " of Configuration " + configName,
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Export Config for Receiver Enable Document Export Radio Button for Receiver " + Receiver
								+ " of Configuration " + configName,
						true);
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to parse the DB values appropriately
	 * @InputParameters: value
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String parseDBValue(String value) {
		String result = "";
		if (value.isEmpty() || value.contains("Select")) {
			result = "#skip#";
		} else {
			result = value;
		}
		return result;
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to Add new XML doc Config
	 * @InputParameters: value
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AddXmlDocConfig() throws SQLException {
		Reports.ExtentReportLog("", Status.INFO, "Add New XML Doc Config Starts", false);
		Connection dbCon = null;
		try {
			XMLDocConfigNavigation();
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);

			ResultSet rs = DataBaseOperations.performRead(dbCon,
					"SELECT * FROM xmldocconfig WHERE XMLDocConfigName = 'E2B R3 STANDARD'");
			rs.last();
			int rowCount = rs.getRow();
			for (int i = 0; i < rowCount; i++) {
				rs.beforeFirst();
				rs.next();
				String configName = rs.getString("XMLDocConfigName");
				agClick(XMLDocConfigPageObjects.e2bSettings_NewBtn);
				agWaitTillVisibilityOfElement(
						XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.XMLDocConfigurationNameLabel));
				agSetStepExecutionDelay("2000");
				agSetValue(XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.XMLDocConfigurationNameLabel),
						rs.getString("XMLDocConfigName"));
				// agSetValue(XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.RootTagNameLabel),
				// rs.getString("RootTagName"));
				agSelectByVisibleText(XMLDocConfigPageObjects.DTDNameDropDown, rs.getString("DTDName"));
				agSelectByVisibleText(XMLDocConfigPageObjects.DTDSchemaDropDown, rs.getString("DTDSchema"));
				agSelectByVisibleText(XMLDocConfigPageObjects.DTDTypeDropDown, rs.getString("DTDType"));
				agSelectByVisibleText(XMLDocConfigPageObjects.PostProcessingScriptForImportDropDown,
						rs.getString("PostProcessingScript"));
				agSelectByVisibleText(XMLDocConfigPageObjects.PostProcessingScriptForExportDropDown,
						rs.getString("PreProcessingScript"));
				agSetStepExecutionDelay(Constants.defaultGlobalStepExecutionDelay + "");
				AddImportConfigForSenders(configName);
				AddExportConfogForReceivers(configName);
				AddImportPathConfig(configName);
				AddDTDXpath(configName);
				agClick(XMLDocConfigPageObjects.save_Btn);
			}

		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, "Add New XML Doc Config Failed", true);
		} finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		Reports.ExtentReportLog("", Status.INFO, "Add New XML Doc Config Ends", false);

	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to Add new XML doc Config ICFS
	 * @InputParameters: configName
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AddImportConfigForSenders(String configName) {

		Reports.ExtentReportLog("", Status.INFO,
				"Add Import Config For Senders of Configuration " + configName + " Starts", true);

		Connection dbCon = null;
		try {
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);

			ResultSet rs = DataBaseOperations.performRead(dbCon,
					"SELECT * FROM xmldocconfig WHERE XMLDocConfigName='" + configName + "");
			rs.last();
			rs.beforeFirst();
			rs.next();
			FDE_Navigations(XMLDocConfigPageObjects.ImportConfigurationForSenders);
			agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.SenderSettingsLabel);
			agClick(XMLDocConfigPageObjects.ICFSAddButon);
			ICFSSenderLookUp(rs.getString("ICFSSender"));
			ICFSDefaultReceiverLookUp(rs.getString("ICFSDefaultReceiver"));
			ICFSDefaultReceiverLookUp(rs.getString("ICFSDefaultSender"));
			agSelectByVisibleText(XMLDocConfigPageObjects.ICFSDefaultSourceMediumDD,
					rs.getString("ICFSDefaultSourceMedium"));
			agSelectByVisibleText(XMLDocConfigPageObjects.ICFSSorceDocDD, rs.getString("ICFSSourceDocument"));
			agSelectByVisibleText(XMLDocConfigPageObjects.ICFSImportFOrmDD, rs.getString("ICFSImportForm"));
			checkBoxSelect(XMLDocConfigPageObjects.ICFSDefaultConfigCheckBox, rs.getString("ICFSDefaultConfigCB"));
			checkBoxSelect(XMLDocConfigPageObjects.ICFSAcknowledgementRequiredCheckBox,
					rs.getString("ICFSACKRequired"));
			checkBoxSelect(XMLDocConfigPageObjects.ICFSPlaceAckXMLinFolderCheckBox, rs.getString("ICFSPlaceACK"));
			checkBoxSelect(XMLDocConfigPageObjects.ICFSRejectCasesAssessedasSDCheckBox,
					rs.getString("ICFSRejectCasesAssessedasSD"));
			checkBoxSelect(XMLDocConfigPageObjects.ICFSMDNRequiredCheckBox, rs.getString("ICFSMDNRequired"));
			checkBoxSelect(XMLDocConfigPageObjects.ICFSGenerateACkafterAERgenerationCheckBox,
					rs.getString("ICFSGenerateACK"));
			checkBoxSelect(XMLDocConfigPageObjects.ICFSSDManualRejectCheckBox, rs.getString("ICFSDorManual"));
			checkBoxSelect(XMLDocConfigPageObjects.ICFSRejectCasesforhardvalidationsCheckBox,
					rs.getString("ICFSRejectCasesHV"));
			checkBoxSelect(XMLDocConfigPageObjects.ICFSImportSourceDocumentCheckBox,
					rs.getString("ICFSImportSourceDocument"));
			radioButtonSelect(XMLDocConfigPageObjects.ICFSEasyViewRadioButton, rs.getString("ICFSEasyView"));
			radioButtonSelect(XMLDocConfigPageObjects.ICFSSummarySheetRadioButton, rs.getString("ICFSSummarySheet"));
			agClick(XMLDocConfigPageObjects.ICFSSubmitButton);
			agWaitTillInvisibilityOfElement(XMLDocConfigPageObjects.ICFSSubmitButton);
			Reports.ExtentReportLog("", Status.INFO,
					"Add  Import Config For Senders of Configuration " + configName + " Ends", true);

		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL,
					"Add  Import Config For Senders of Configuration " + configName + " Failed", true);
		}

		finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to Add new XML doc Config ICFS
	 * @InputParameters: configName
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AddExportConfogForReceivers(String configName) {
		Reports.ExtentReportLog("", Status.INFO,
				"Add  Export Config For Receiver of Configuration " + configName + " Starts", true);

		Connection dbCon = null;
		try {
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);

			ResultSet rs = DataBaseOperations.performRead(dbCon,
					"SELECT * FROM xmldocconfig WHERE XMLDocConfigName='" + configName + "");
			rs.last();
			rs.beforeFirst();
			rs.next();
			FDE_Navigations(XMLDocConfigPageObjects.ExportConfigurationForReceivers);
			agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.ECFRAddButton);
			agClick(XMLDocConfigPageObjects.ECFRAddButton);
			agWaitTillVisibilityOfElement(
					XMLDocConfigPageObjects.selectRadioButton(XMLDocConfigPageObjects.ECFRDocumentACKImportEnabledLabel,
							rs.getString("ECFREnableDocumentExport")));
			agClick(XMLDocConfigPageObjects.selectRadioButton(XMLDocConfigPageObjects.ECFRDocumentACKImportEnabledLabel,
					rs.getString("ECFREnableDocumentExport")));
			agClick(XMLDocConfigPageObjects.selectRadioButton(XMLDocConfigPageObjects.ECFRXMLACKImpotEnabledLabel,
					rs.getString("ECFRXMLACKImportEnabled")));
			agClick(XMLDocConfigPageObjects.selectRadioButton(XMLDocConfigPageObjects.ECFRDocumentACKImportEnabledLabel,
					rs.getString("ECFRDocACKImportEnabled")));
			checkBoxSelect(XMLDocConfigPageObjects.ECFRDisplayR3TagsInXMLLabel, rs.getString("ECFRDisplayR3Tags"));
			agSelectByVisibleText(XMLDocConfigPageObjects.ECFRMeddraDD, rs.getString("ECFRMeddra"));
			agClick(XMLDocConfigPageObjects.ECFRSubmitButton);
			agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.ECFRSubmitButton);
			Reports.ExtentReportLog("", Status.INFO,
					"Add  Export Config For Receiver of Configuration " + configName + " Ends", true);

		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.INFO,
					"Add  Export Config For Receiver of Configuration " + configName + " Failed", true);
		}

		finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to Add new XML doc Config for Import Path
	 *             Config
	 * @InputParameters: configName
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AddImportPathConfig(String configName) {
		Reports.ExtentReportLog("", Status.INFO, "Add  Import Path Config of Configuration " + configName + " Starts",
				true);

		Connection dbCon = null;
		try {
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);

			ResultSet rs = DataBaseOperations.performRead(dbCon,
					"SELECT * FROM xmldocconfig WHERE XMLDocConfigName='" + configName + "");
			rs.last();
			rs.beforeFirst();
			rs.next();
			FDE_Navigations(XMLDocConfigPageObjects.ExportConfigurationForReceivers);
			agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.ECFRAddButton);
			agIsVisible(XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.XMLimportPath_Label));
			agSetValue(XMLDocConfigPageObjects.schema_TextBox, rs.getString("IPCSchema"));
			agSetValue(XMLDocConfigPageObjects.sequenceLength_TextBox, rs.getString("IPCSequenceLength"));
			agSetValue(XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.XMLimportPath_Label),
					rs.getString("IPCXMLImportPath"));
			agSetValue(XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.XMLAckExportPath_Label),
					rs.getString("ICPXMLACKExportPath"));
			agSetValue(XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.docImportPath_Label),
					rs.getString("ICPDocImportPath"));
			agSetValue(XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.docImportBackPath_Label),
					rs.getString("ICPDocImportBackUpPath"));
			agSetValue(XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.docAckExportPath_Label),
					rs.getString("ICPDocACKExpPath"));
			Reports.ExtentReportLog("", Status.INFO, "Add  Import Path Config of Configuration " + configName + " Ends",
					true);
		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.INFO,
					"Add  Import Path Config of Configuration " + configName + " Failed", true);
		}

		finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to Add new XML doc Config for Import Path
	 *             Config
	 * @InputParameters: configName
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AddDTDXpath(String configName) {
		Reports.ExtentReportLog("", Status.INFO, "Add DTD XPATH Path Config of Configuration " + configName + " Starts",
				true);

		Connection dbCon = null;
		try {
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);

			ResultSet rs = DataBaseOperations.performRead(dbCon,
					"SELECT * FROM xmldocconfig WHERE XMLDocConfigName='" + configName + "");
			rs.last();
			rs.beforeFirst();
			rs.next();
			FDE_Navigations(XMLDocConfigPageObjects.DTDXpaths);
			agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.DTDXpathAddButton);
			int numberOfRecords = totalXpathCount(configName);
			for (int index = 1; index <= numberOfRecords; index++) {
				agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.DTDXpathAddButton);
				agClick(XMLDocConfigPageObjects.DTDXpathAddButton);
				agSetValue(XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.xpath_Label),
						rs.getString("DTDXpath_" + index));
				agSetValue(XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.xpathValue_Label),
						rs.getString("DTDXpathValue_" + index));
				agSelectByVisibleText(XMLDocConfigPageObjects.DTDXpathValueTypeDD,
						rs.getString("DTDXpathValueType_" + index));
				agClick(XMLDocConfigPageObjects.DTDXpathSave);
			}
			Reports.ExtentReportLog("", Status.INFO,
					"Add DTD XPATH Path Config of Configuration " + configName + " Ends", true);
		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.INFO,
					"Add DTD XPATH Path Config of Configuration " + configName + " Failed", true);
		}

		finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to Look Up ICFS Sender LookUp
	 * @InputParameters: sender
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ICFSSenderLookUp(String sender) {
		if (sender.contains("skip")) {
			return;
		}
		agClick(XMLDocConfigPageObjects.ICFSSenderLookUp);
		agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.ICFSAccountName));
		agSetValue(XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.ICFSAccountName), sender);
		agClick(XMLDocConfigPageObjects.ICFSReceiverSearch);
		agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.ICFSReceiverRadioButton);
		agClick(XMLDocConfigPageObjects.ICFSReceiverRadioButton);
		agClick(XMLDocConfigPageObjects.ICFSReceiverSearchOK);
		agWaitTillInvisibilityOfElement(XMLDocConfigPageObjects.ICFSReceiverSearchOK);
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to Look Up ICFS Default Reeiver Lookup
	 * @InputParameters: defaultReceiver
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ICFSDefaultReceiverLookUp(String defaultReceiver) {
		if (defaultReceiver.contains("skip")) {
			return;
		}
		agClick(XMLDocConfigPageObjects.ICFSDefaultReceiverLookUp);
		agWaitTillInvisibilityOfElement(
				XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.ICFSDefaultReceiverUnitCodeLabel));
		agSetValue(XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.ICFSDefaultReceiverUnitCodeLabel),
				defaultReceiver);
		agClick(XMLDocConfigPageObjects.ICFSDefaultReceiverSearchButton);
		agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.ICFSDefaultReceiverRadioButton);
		agClick(XMLDocConfigPageObjects.ICFSDefaultReceiverRadioButton);
		agClick(XMLDocConfigPageObjects.ICFSDefaultReceiverOkButton);
		agWaitTillInvisibilityOfElement(XMLDocConfigPageObjects.ICFSDefaultReceiverOkButton);
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to Look Up ICFS Default Sender Lookup
	 * @InputParameters: defaultSender
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ICFSDefaultSenderLookUp(String defaultSender) {
		if (defaultSender.contains("skip")) {
			return;
		}
		agClick(XMLDocConfigPageObjects.ICFSDefaultSenderLookUp);
		agWaitTillVisibilityOfElement(
				XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.ICFSDefaultSenderAccountName));
		agSetValue(XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.ICFSDefaultSenderAccountName),
				defaultSender);
		agClick(XMLDocConfigPageObjects.ICFSDefaultSenderrSearch);
		agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.ICFSReceiverRadioButton);
		agClick(XMLDocConfigPageObjects.ICFSDefaultSenderRadioButton);
		agClick(XMLDocConfigPageObjects.ICFSDefaultSenderOkButton);
		agWaitTillInvisibilityOfElement(XMLDocConfigPageObjects.ICFSDefaultSenderOkButton);
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is to Look Up ECFR receiver Lookup
	 * @InputParameters: receiver
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ECFRReceiverLookUp(String receiver) {
		if (receiver.contains("skip")) {
			return;
		}
		agClick(XMLDocConfigPageObjects.ICFSDefaultSenderLookUp);
		agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.ECFRReceiverLookUp));
		agSetValue(XMLDocConfigPageObjects.setTextBox(XMLDocConfigPageObjects.ECFRReceiverAccountName), receiver);
		agClick(XMLDocConfigPageObjects.ECFRReceiverSearch);
		agWaitTillVisibilityOfElement(XMLDocConfigPageObjects.ECFRReceiverRadioButton);
		agClick(XMLDocConfigPageObjects.ECFRReceiverRadioButton);
		agClick(XMLDocConfigPageObjects.ECFRReceiverSearchOk);
		agWaitTillInvisibilityOfElement(XMLDocConfigPageObjects.ECFRReceiverSearchOk);
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is select checkbox based on DB Value
	 * @InputParameters: CheckBox Name, Check Value
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void checkBoxSelect(String checkBoxName, String checkValue) {
		String active = "ui-state-active";
		String value = "Unchecked";
		String classValue = agGetAttribute("class", XMLDocConfigPageObjects.checkBoxUnder(checkBoxName));
		if (classValue.contains(active))
			value = "Checked";
		if (checkValue.equalsIgnoreCase("Checked")) {
			if (!value.equalsIgnoreCase(checkValue)) {
				agClick(XMLDocConfigPageObjects.checkBoxUnder(checkBoxName));
			}
		} else if (checkValue.equalsIgnoreCase("Unchecked")) {
			if (!value.equalsIgnoreCase(checkValue)) {
				agClick(XMLDocConfigPageObjects.checkBoxUnder(checkBoxName));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is select Radio button based on DB Value
	 * @InputParameters: Radio Button Name, Check Value
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void radioButtonSelect(String radioButtonName, String select) {
		String active = "ui-state-active";
		String value = "Unchecked";
		String classValue = agGetAttribute("class", XMLDocConfigPageObjects.radioButton(radioButtonName));
		if (classValue.contains(active))
			value = "Checked";
		if (select.equalsIgnoreCase("Checked")) {
			if (!value.equalsIgnoreCase(select)) {
				agClick(XMLDocConfigPageObjects.radioButton(radioButtonName));
			}
		} else if (select.equalsIgnoreCase("Unchecked")) {
			if (!value.equalsIgnoreCase(select)) {
				agClick(XMLDocConfigPageObjects.radioButton(radioButtonName));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is calculate the number of XPaths records needs
	 *             to be added
	 * @InputParameters: configName
	 * @OutputParameters:NA
	 * @author: Karthikeyan Natarajan
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static int totalXpathCount(String configName) {
		int value = 0;
		Connection dbCon = null;
		try {
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);

			ResultSet rs = DataBaseOperations.performRead(dbCon,
					"SELECT * FROM xmldocconfig WHERE XMLDocConfigName='" + configName + "");
			rs.last();
			rs.beforeFirst();
			rs.next();
			for (int index = 1; index <= 10; index++) {
				try {
					if (rs.getString("DTDXpath_" + index).contains("#skip#"))
						value++;
				} catch (Exception ex) {
					System.out.println(ex);
					System.out.println("Number of Xpaths calculated");
				}
			}
		} catch (Exception ex) {
			System.out.println(ex);
		} finally {
			try {
				dbCon.clearWarnings();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return value;
	}
}
