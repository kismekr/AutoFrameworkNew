package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FDE_PatientPageObjects {

	public static String click_DropDown = "xpath#//label[@style='visibility: visible;'][contains(text(),'{0}')]/ancestor::span/p-dropdown/div";
	// public static String setdropDownValue =
	// "xpath#//div/div/div/ul[contains(@class,'ui-dropdown-items')]/child::li/div/span[contains(text(),'%s')]";
	public static String setdropDownValue = "xpath#//div/div/ul[contains(@class,'ui-dropdown-items')]/child::li/div/span[contains(text(),'%s')]";
	public static String setData_Textfields = "xpath#//label[contains(@style,'visibility: visible;')][contains(text(),'%s')]/following-sibling::input";
	public static String setData_Datesfields = "xpath#//label[contains(@style,'visibility: visible;')][contains(text(),'%s')]/following-sibling::span/input[1]";
	public static String set_WeightHeight_TxtField = "xpath#//label[contains(@style,'visibility: visible;')][contains(text(),'%s')]/following-sibling::span/input";
	public static String click_Checkboxs = "xpath#//label[contains(@style,'visibility: visible;')][contains(text(),'%s')]/following-sibling::p-checkbox/div/child::div/span";
	public static String select_RadioButtons = "xpath#//label[contains(@style,'visibility: visible;')][contains(text(),'%s')]/following-sibling::span/p-radiobutton/label[contains(text(),'%r')]";
	public static String raceDropdown = "xpath#//div[@class='ui-multiselect-items-wrapper']/ul/li/div/child::div/following::label[text()='%s']";
	public static String clickRaceDropdown = "xpath#//input[@id='adverseEventNew:patientPanelTable:patientIdentifierTable:race_focus']/following::div[@class='ui-multiselect-label-container']/label";
	public static String ageAtEvent = "xpath#//label[contains(@style,'visibility: visible;')][contains(text(),'Age at the Time of Event')]/following-sibling::span/input";
	public static String click_embeddedDrpdwn = "xpath#//label[@style='visibility: visible;'][contains(text(),'{0}')]/ancestor::span/span/p-dropdown/div[1]/label";
	public static String autopsyDeterminedCauseOfDeathTxtbox = "xpath#(//label[contains(text(),'{0}')]/ancestor::thead/following-sibling::tbody/tr/td/span/input)[{@}]";
	public static String get_LMPDate = "xpath#//input[@id='adverseEventNew:patientPanelTable:patientIdentifierTable:lmpdate:impcalinput']";

	public static String setData_TextAreafields = "xpath#//label[contains(text(),'%s')]/following-sibling::textarea";
	public static String ManualAutopsycheckboxVerify = "xpath#//label[contains(text(),'Date of Death')]/parent::span/parent::div/parent::div/div[@class='col-md-4 agSkipClear manualChkCss ng-star-inserted']/label[contains(text(),'Manual')]/parent::div/p-checkbox/div[@class='ui-chkbox ui-widget']";
	public static String manualAutopsyCheckBox = "xpath//div[@id='ui-panel-33-content']//div[@class='ui-chkbox ui-widget']";

	public static String clickNFbutton = "xpath#//label[text()='%s']//parent::span//parent::div//a[@class='agNfLink']";
	public static String AgeAtTimeofEVentDropDownValue = "xpath#//label[text()='Age at the Time of Event']/parent::span//span/p-dropdown/div[contains(title,'')]";
	public static String AgeAtTimeofEventTextBoxValue = "xpath#//label[text()='Age at the Time of Event']/parent::span//span/input";
	public static String GestationAgeTextBoxValue = "xpath#//input[@id='adverseEventNew:patientPanelTable:patientIdentifierTable:gestationalAge']";
	public static String GestationAgeDropDownValue = "xpath#//label[text()='Gestational Age at event']/parent::span//span/p-dropdown/div[contains(title,'')]";
	public static String newDiseaseTerm_Textbox = "xpath#(//input[contains(@id, 'adverseEventNew:patientPanelTable:patientMedHistTable:idN103D2103104')])[3]";
	public static String GestationAgeUnitValue = "xpath#//label[text()='Gestational Age at event']/parent::span//span/p-dropdown/div[contains(title,'')]/label/span";
	public static String key_LMPDateasText = "xpath#//label[text()='LMP Date']/following-sibling::span/input[contains(@id,'lmpdate')]";

	// Label Names

	public static String patientID_Textbox = "Patient ID";
	public static String patientDOB_Date = "Patient DOB";
	public static String protectConfidentiality_Checkbx = "Protect Confidentiality";
	public static String ageTimeEvent_DropDown = "Age at the Time of Event";
	public static String manual_Checkbx = "Manual";
	public static String consentcontactPatient_DropDown = "Consent to contact Patient";
	public static String ageGroup_DropDown = "Age Group";
	public static String Pregnant_label = "Pregnant";
	public static String weight_DropDown = "Weight";
	public static String height_DropDown = "Height";
	public static String gender_DropDown = "Gender";
	public static String race_DropDown = "Race";
	public static String ethnicity_DropDown = "Ethnicity";
	public static String lMPDate_Date = "LMP Date";
	public static String specialistRecordNumber_Textbox = "Specialist Record Number";
	public static String hospitalRecordNumber_Textbox = "Hospital Record Number";
	public static String gpMedicalRecordNumber_Textbox = "GP Medical Record Number";
	public static String investigationNumber_Textbox = "Investigation Number";
	public static String concomitantTherapies_Checkbx = "Concomitant Therapies";
	public static String registrationNumber_Textbox = "Registration Number";
	public static String identifiablePatient_Checkbx = "Identifiable Patient";
	public static String birthWeight_label = "Birth weight";
	public static String birthWeight_Textbox = "xpath#//input[@id='adverseEventNew:patientPanelTable:patientIdentifierTable:birthWeight']";
	public static String birthWeightUnit_DropDown = "xpath#//select[@name='adverseEventNew:patientPanelTable:patientIdentifierTable:birthWeightUnit']";
	public static String bodySurfaceIndex_label = "Body surface index";
	public static String bodySurfaceIndex_Textbox = "xpath#//input[@id='adverseEventNew:patientPanelTable:patientIdentifierTable:bodySurfaceIndex']";
	public static String bodyMassIndex_label = "Body mass index";
	public static String bodyMassIndex_Textbox = "xpath#//input[@id='adverseEventNew:patientPanelTable:patientIdentifierTable:bodyMassIndex']";

	public static String WeightUnits = "xpath#//label[contains(text(),'Weight')]/parent::span//span/p-dropdown/div";
	public static String HeightUnits = "xpath#//label[contains(text(),'Height')]/parent::span//span/p-dropdown/div";
	public static String dateOfDeath_Date = "Date of Death";
	public static String autopsyDone_Radio = "Autopsy Done?";
	public static String autopsyDeterminedCauseOfDeath = "Autopsy Determined Cause of Death";

	public static String medicalHistoryAndConcurrentConditions_TextArea = "Medical History And Concurrent Conditions";
	public static String dateOfAutopsy_Textbox = "xpath#//input[contains(@id, '109456:impcalinput')]";
	public static String deathDetails_label = "xpath#//label[text()='Death Details']";
	public static String patientIdentifier_label = "xpath#//label[text()='Patient Identifiers']";
	public static String collapse_icon = "xpath#//*[@id='fdeAngularForm']/div/div[2]/img";

	// added by rashmi
	public static String PastTherapycheckboxingridview = "xpath#//input[contains(@id,  '108102:%rowNo%')]/ancestor::td/./preceding-sibling::td/p-tablecheckbox/div";
	public static String ReportedCauseOfDeathcheckboxingridview = "xpath#//input[contains(@id,  '118104_input:%rowNo%')]/ancestor::td/./preceding-sibling::td/p-tablecheckbox/div";
	public static String confirmationYesbutton = "xpath#//span[@class='ui-button-text ui-clickable' and contains(text(),'Yes')]";
	public static String DeathDateAsNullButton = "xpath#(//div/span[@class='agNfField']/label[contains(text(),'%s')])/../following-sibling::span/a/img";
	public static String NullDropdown = "xpath#//label[contains(text(),'{0}')]/ancestor::span/span/p-dropdown[@styleclass='agNfDropdown']//div/span";
	public static String autoSpyManualCheckbox = "xpath#//label[contains(text(),'Autopsy Done?')]/parent::span/parent::div/following-sibling::div[1]//p-checkbox/div/div[2]";

	public static String DeathDateAsNullButton(String label) {
		String value = DeathDateAsNullButton.replace("%s", label);
		return value;
	}

	// Null Flavours Common

	// Null Flavour Label >>
	// //label[text()='%labelName%']/../descendant::label[contains(@class,'ui-dropdown')]
	// Null Flavour Icon >>
	// //label[text()='%labelName%']/ancestor::div[1]/span/a/img[contains(@src,'NullFlv.png')]

	// Consent To Contact Patient
	public static String ConsenttocontactPatient_DD = "xpath#//select[@name='adverseEventNew:pregnancyPanelTable:pregnancyDetailsTable:consentContactPatient-7073_focus']";

	// Patient Identifiers
	// public static String patientIDNullFlavour_Dropdown =
	// "xpath#//label[contains(@class,'c3-91 ui-dropdown-label')]";
	// public static String patientDOBNullFlavour_Dropdown =
	// "xpath#//label[contains(@class, 'c3-92 ui-dropdown-label')]";
	// public static String genderNullFlavour_Dropdown =
	// "xpath#//label[contains(@class, 'c3-99 ui-dropdown-label')]";

	// Medical History
	public static String medicalHistory_Label = "Medical History";
	public static String diseaseTerm_Textbox = "xpath#(//input[contains(@id, 'adverseEventNew:patientPanelTable:patientMedHistTable:idN103D2103104')])[1]";
	public static String medDRALLTforDiseaseTerm_Textbox = "xpath#//input[contains(@id, 'diseaseTermMeddraLltDecode:%rowNo%')]";
	public static String medDRALLTforDiseaseTerm_LookUpIcon = "xpath#//input[contains(@id,  'diseaseTermMeddraLltDecode:%rowNo%')]/following::img[contains(@src, 'Lookup_Selection.svg')][1]";
	public static String medDRAPTforDiseaseTerm_Textbox = "xpath#//input[contains(@id, 'diseaseTermMeddraPtDecode:%rowNo%')]";
	public static String startDateMedHist_Textbox = "xpath#//input[contains(@id, 'startDate:impcalinput:%rowNo%')]";
	public static String endDateMedHist_Textbox = "xpath#//input[contains(@id, '107107:impcalinput:%rowNo%')]";
	public static String ContinuingYes_Radio = "xpath#//label[contains(@for, 'patientMedHistTable:medicalContinue-orderByDisplayOrder-1008:0:%rowNo%')]";
	public static String ContinuingNo_Radio = "xpath#//label[contains(@for, 'patientMedHistTable:medicalContinue-orderByDisplayOrder-1008:1:%rowNo%')]";
	public static String ContinuingUnknown_Radio = "xpath#//label[contains(@for, 'patientMedHistTable:medicalContinue-orderByDisplayOrder-1008:2:%rowNo%')]";

	public static String deleteBtn = "xpath#(//span[contains(@class,'agAddDeleteBlock')]//a[@class='agMultiDeleteLink ng-star-inserted'])[1]";
	public static String deletePopup = "xpath#//span[@class='ui-confirmdialog-message']";
	public static String yesBtn = "xpath#//button[contains(@class,'undefined ui-button')]//span[text()='Yes']";
	public static String diseaseCommentsTextarea = "xpath#//textarea[contains(@id,'adverseEventNew:patientPanelTable:patientMedHistTable')]";
	public static String deleteCheckbox = "xpath#(//div[@class='ui-table-wrapper ng-star-inserted']//thead/tr/th[1]/p-checkbox//div/span)[1]";

	// Patient Past Therapy
	public static String patientPastTherapy_Label = "Patient Past Therapy";
	public static String productDescriptionReported_Textbox = "xpath#//input[contains(@id, '108102:%rowNo%')]";
	public static String productDescriptionReported_LookUpIcon = "xpath#//input[contains(@id,  '108102:%rowNo%')]/following::img[contains(@src, 'Lookup_Selection.svg')][1]";
	public static String startDatePatPastTherap_Textbox = "xpath#//input[contains(@id, '108105:impcalinput:%rowNo%')]";
	public static String endDatePatPastTherap_Textbox = "xpath#//input[contains (@id, '108107:impcalinput:%rowNo%')]";
	public static String indicationTerm_Textbox = "xpath#//input[contains (@id, '108110:%rowNo%')]";
	public static String medDRALLTCodeIndicationTerm_Textbox = "xpath#//input[contains(@id, 'indicationTermMeddraLltCode:%rowNo%')]";
	public static String medDRALLTCodeIndicationTerm_LookUpIcon = "xpath#//input[contains(@id,  'indicationTermMeddraLltCode:%rowNo%')]/following::img[contains(@src, 'Lookup_Selection.svg')][1]";
	public static String medDRAPTCodeIndicationTerm_Textbox = "xpath#//input[contains(@id, '108613:%rowNo%')]";
	public static String reactionTerm_Textbox = "xpath#//input[contains(@id, '071046:%rowNo%')]";
	public static String medDRALLTCodeReactionTerm_Textbox = "xpath#//input[contains(@id, 'reactionTermMeddraLltCode:%rowNo%')]";
	public static String medDRALLTCodeReactionTerm_LookUpIcon = "xpath#//input[contains(@id,  'reactionTermMeddraLltCode:%rowNo%')]/following::img[contains(@src, 'Lookup_Selection.svg')][1]";
	public static String medDRAPTCodeReactionTerm_Textbox = "xpath#//input[contains(@id, '108614:%rowNo%')]";

	public static String productNameAsReported_Textbox = "xpath#//label[text()='Product Name As Reported']/parent::span/span/input";
	public static String patientPastTherapy_AddBtn = "xpath#//label[text()='Patient Past Therapy']/following-sibling::span/a[text()='Add']";
	public static String patientPastTherapy_DeleteBtn = "xpath#//a[text()='Delete']/parent::span/parent::p-header/label[text()='Patient Past Therapy']/parent::p-header//a[text()='Delete']";

	// Reported Cause(s) of Death
	public static String reportedCauseofDeath_Label = "Reported Cause(s) of Death";
	public static String reportedCauseofDeath_Textbox = "xpath#//input[contains(@id, '118104_input:%rowNo%')]";
	public static String medDRALLTCodeforReportedCauseofDeath_Textbox = "xpath#//input[contains(@id, 'patDeathReportMeddraLltCode:%rowNo%')]";
	public static String medDRALLTCodeforReportedCauseofDeath_LookUpIcon = "xpath#//input[contains(@id, 'patDeathReportMeddraLltCode:%rowNo%')]/following::img[contains(@src, 'Lookup_Selection.svg')][1]";
	public static String medDRAPTCodeForReportedCauseOfDeath_Textbox = "xpath#//input[contains(@id, '118252:%rowNo%')]";

	// Autopsy Determined Cause(s) of Death
	public static String autopsyDeterminedCauseofDeath_Label = "Autopsy Determined Cause(s) of Death";
	public static String autopsyDeterminedCauseofDeath_Textbox = "xpath#//input[contains(@id, '1230044:%rowNo%')]";
	public static String medDRALLTCodeforAutopsyDeterminedCauseofDeath_Textbox = "xpath#//input[contains(@id, 'autopsyDeterminedMeddraLltCode:%rowNo%')]";
	public static String medDRALLTCodeforAutopsyDeterminedCauseofDeath_LookUpIcon = "xpath#//input[contains(@id, 'autopsyDeterminedMeddraLltCode:%rowNo%')]/following::img[contains(@src, 'Lookup_Selection.svg')][1]";
	public static String medDRAPTCodeForAutopsyDeterminedCauseOfDeath_Textbox = "xpath#//input[contains(@id, 'autopsyDeterminedMeddraLltCode119254:%rowNo%')]";
	public static String autopsyDeterminedCheckBox = "xpath#//a[contains(text(),'Heart attack')]/parent::span/ancestor::tr//td//div[@class='ui-chkbox-box ui-widget ui-state-default']";

	// Risk Factor
	public static String riskFactor_Label = "Risk Factor";
	public static String evaluation_DropDown = "xpath#//select[contains(@name, 'riskFactorTable:evaluation')]";
	public static String riskFactor_DropDown = "xpath#//select[contains(@name, 'riskFactorTable:riskFactor')]";
	public static String riskFactor = "xpath#//div[contains(@class,'ui-panel-titlebar ')]//label[text()='Risk Factor']";
	// public static String evaluation_DropDown = "xpath#//select[contains(@name,
	// 'riskFactorTable:evaluation:%rowNo%')]";
	// public static String riskFactor_DropDown = "xpath#//select[contains(@name,
	// 'riskFactorTable:riskFactor:%rowNo%')]";

	public static String addButton = "xpath#//label[text()='%divName%']/../descendant::a[text()='Add']";
	public static String deleteButton = "xpath#//label[text()='%divName%']/../descendant::a[text()='Delete']";

	// FDA Specific additional fields - Patient Past Therapy
	public static String diseaseComments_TextArea = "xpath#//label[contains(text(),'Disease comments')]/following-sibling::textarea";

	public static String familyHistory_Checkbx = "xpath#//label[contains(text(),'Family History')]/following-sibling::span/p-checkbox";
	public static String relevantForEventDescptn_Checkbx = "xpath#//label[contains(text(),'Family History')]/following-sibling::span/p-checkbox";

	public static String medicinalPrdtIdentifier_textBox = "xpath#//label[contains(text(),'Medicinal Product Identifier')]/following-sibling::span/input";
	public static String MPIDVersionDateNumber_textBox = "xpath#//label[contains(text(),'MPID Version Date / Number')]/following-sibling::span/input";
	public static String PhPID_textBox = "xpath#//label[text()='PhPID']/following-sibling::span/input";
	public static String PhPIDVersionDateNumber_textBox = "xpath#//label[text()='PhPID Version Date / Number']/following-sibling::span/input";

	public static String scientificName_textBox = "xpath#//label[text()='Scientific Name']/following-sibling::span/input";
	public static String trademarkName_textBox = "xpath#//label[text()='Trademark Name']/following-sibling::span/input";
	public static String StrengthName_textBox = "xpath#//label[text()='Strength Name']/following-sibling::span/input";
	public static String formName_textBox = "xpath#//label[text()='Form Name']/following-sibling::span/input";
	public static String containerName_textBox = "xpath#//label[text()='Container Name']/following-sibling::span/input";
	public static String inventedName_textBox = "xpath#//label[text()='Invented Name']/following-sibling::span/input";
	public static String deviceName_textBox = "xpath#//label[text()='Device Name']/following-sibling::span/input";
	public static String intendedUseName_textBox = "xpath#//label[text()='Intended Use Name']/following-sibling::span/input";

	public static String WHODDCode_LookupHeader = "xpath#//div[@class='lsmv-popup-header']/span[text()='List of Product']";
	public static String WHODDCodeLookup_TextField = "xpath#//div[@class='lsmv-field-text']/input[@title='WHODD Code']";
	public static String tradeBrandNameCodeLookup_TextField = "xpath#//div[@class='lsmv-field-text']/input[@title='Trade/Brand Name']";
	public static String ATCCode_TextField = "xpath#//div[@class='lsmv-field-text']/input[@title='ATC Code']";
	public static String substance_TextField = "xpath#//div[@class='lsmv-field-text']/input[@title='Substance']";
	public static String search_Button = "xpath#//div/span[@class='lsmv-button'][text()='Search']";
	public static String retrievedRecord_Checkbx = "xpath#(//div[@id='targetPanelForWhoddLookupGrid']/div/span)[2]";
	public static String select_Button = "xpath#//div/span[text()='Select']";

	// R2 tags
	public static String R2PatientId = "xpath#//label[text()='[B.1.1]']";
	public static String R2PatientDOB = "xpath#//label[text()='[B.1.2.1b]']";
	public static String R2AgeAtTheTimeOfEvent = "xpath#//label[text()='[B.1.2.2a/b]']";
	public static String R2GestationalAgeAtEvent = "xpath#//label[text()='[B.1.2.2.1a/b]']";
	public static String R2AgeGroup = "xpath#//label[text()='[B.1.2.3]']";
	public static String R2Gender = "xpath#//label[text()='[B.1.5]']";
	public static String R2Weight = "xpath#//label[text()='[B.1.3]']";
	public static String R2Height = "xpath#//label[text()='[B.1.4]']";
	public static String R2LMPDate = "xpath#//label[text()='[B.1.6b]']";
	public static String R2SpecialistRecordNumber = "xpath#//label[text()='[B.1.1.1b]']";
	public static String R2HospitalRecordNo = "xpath#//label[text()='[B.1.1.1c]']";
	public static String R2GPMedicalRecordNumber = "xpath#//label[text()='[B.1.1.1a]']";
	public static String R2InvestigationNumber = "xpath#//label[text()='[B.1.1.1d ]']";
	public static String R2MedicalHistoryAndConcurrentConditions = "xpath#//label[text()='[B.1.7.2]']";
	public static String R2DiseaseTerm = "xpath#//label[text()='[B.1.7.1a.2]']";
	public static String R2StartDate = "xpath#//label[text()='[B.1.7.1c]']";
	public static String R2EndDate = "xpath#//label[text()='[B.1.7.1f]']";
	public static String R2Continuing = "xpath#//label[text()='[B.1.7.1d]']";
	public static String R2DiseaseComments = "xpath#//label[text()='[B.1.7.1g]']";
	public static String R2ProductNameAsReported = "xpath#//label[text()='[B.1.8a]']";
	public static String R2PPTStartDate = "xpath#//label[text()='[B.1.8c]']";
	public static String R2PPTEndDate = "xpath#//label[text()='[B.1.8e]']";
	public static String R2IndicationTerm = "xpath#//label[text()='[B.1.8f.2]']";
	public static String R2ReactionTerm = "xpath#//label[text()='[B.1.8g.2]']";
	public static String R2DateOfDeath = "xpath#//label[text()='[B.1.9.1b]']";
	public static String R2AutopsyDone = "xpath#//label[text()='[B.1.9.3]']";
	public static String R2ReportedCauseOfDeath = "xpath#//label[text()='[B.1.9.2.b]']";
	public static String R2AutopsyDeterminedCauseOfDeath = "xpath#//label[text()='[B.1.9.4b]']";

	// R3 tags
	public static String R3PatientId = "xpath#//label[text()='[D.1]']";
	public static String R3PatientDob = "xpath#//label[text()='[D.2.1]']";
	public static String R3AgeAtTheTimeOfEvent = "xpath#//label[text()='[D.2.2a/b]']";
	public static String R3GestationalAgeAtEvent = "xpath#//label[text()='[D.2.2.1a/b]']";
	public static String R3AgeGroup = "xpath#//label[text()='[D.2.3]']";
	public static String R3Gender = "xpath#//label[text()='[D.5]']";
	public static String R3Weight = "xpath#//label[text()='[D.3]']";
	public static String R3Race = "xpath#//label[text()='[FDA.D.11.r.1]']";
	public static String R3Ethnicity = "xpath#//label[text()='[FDA.D.12]']";
	public static String R3Height = "xpath#//label[text()='[D.4]']";
	public static String R3LMPDate = "xpath#//label[text()='[D.6]']";
	public static String R3SpecialistRecordNumber = "xpath#//label[text()='[D.1.1.2]']";
	public static String R3HospitalRecordNumber = "xpath#//label[text()='[D.1.1.3]']";
	public static String R3GPMedicalRecordNumber = "xpath#//label[text()='[D.1.1.1]']";
	public static String R3InvestigationNumber = "xpath#//label[text()='[D.1.1.4]']";
	public static String R3ConcomitantTherapies = "xpath#//label[text()='[D.7.3]']";
	public static String R3MedicalHistoryAndConcurrentConditions = "xpath#//label[text()='[D.7.2]']";
	public static String R3FamilyHistory = "xpath#//label[text()='[D.7.1.r.6]']";
	public static String R3MedDRALLTForDiseaseTerm = "xpath#//label[text()='[D.7.1.r.1b]']";
	public static String R3StartDate = "xpath#//label[text()='[D.7.1.r.2]']";
	public static String R3EndDate = "xpath#//label[text()='[D.7.1.r.4]']";
	public static String R3Continuing = "xpath#//label[text()='[D.7.1.r.3]']";
	public static String R3DiseaseComments = "xpath#//label[text()='[D.7.1.r.5]']";
	public static String R3ProductNameAsReported = "xpath#//label[text()='[D.8.r.1]']";
	public static String R3MPIDVersionDate_Number = "xpath#//label[text()='[D.8.r.2a]']";
	public static String R3MedicinalProductIdentifier_MPID = "xpath#//label[text()='[D.8.r.2b]']";
	public static String R3PhPID = "xpath#//label[text()='[D.8.r.3b]']";
	public static String R3PhPIDVersionDate_Number = "xpath#//label[text()='[D.8.r.3a]']";
	public static String R3PPtStartDate = "xpath#//label[text()='[D.8.r.4]']";
	public static String R3PPtEndDate = "xpath#//label[text()='[D.8.r.5]']";
	public static String R3MedDRALLTCodeForIndicationTerm = "xpath#//label[text()='[D.8.r.6b]']";
	public static String R3MedDRALLTCodeForReactionTerm = "xpath#//label[text()='[D.8.r.7b]']";
	public static String R3ScientificName = "xpath#//label[text()='[D.8.r.1.EU.2]']";
	public static String R3TrademarkName = "xpath#//label[text()='[D.8.r.1.EU.3]']";
	public static String R3StrengthName = "xpath#//label[text()='[D.8.r.1.EU.4]']";
	public static String R3FormName = "xpath#//label[text()='[D.8.r.1.EU.5]']";
	public static String R3ContainerName = "xpath#//label[text()='[D.8.r.1.EU.6]']";
	public static String R3InventedName = "xpath#//label[text()='[D.8.r.1.EU.1]']";
	public static String R3DeviceName = "xpath#//label[text()='[D.8.r.1.EU.7]']";
	public static String R3IntendedUseName = "xpath#//label[text()='[D.8.r.1.EU.8]']";
	public static String R3Substance_SpecifiedSubstanceName = "xpath#//label[text()='[D.8.r.EU.r.1]']";
	public static String R3SubstanceTermIDVerDate_Num = "xpath#//label[text()='[D.8.r.EU.r.2a]']";
	public static String R3Substance_SpecifiedSubstanceTermID = "xpath#//label[text()='[D.8.r.EU.r.2b]']";
	public static String R3Strength_Number = "xpath#//label[text()='[D.8.r.EU.r.3a/b]']";
	public static String R3DeathDate = "xpath#//label[text()='[D.9.1]']";
	public static String R3AutopsyDone = "xpath#//label[text()='[D.9.3]']";
	public static String R3ReportedCauseOfDeath = "xpath#//label[text()='[D.9.2.r.2]']";
	public static String R3MedDRALLTCodeForReportedCauseOfDeath = "xpath#//label[text()='[D.9.2.r.1b]']";
	public static String R3AutopsyDeterminedCauseOfDeath = "xpath#//label[text()='[D.9.4.r.2]']";
	public static String R3MedDRALLTCodeForAutopsyDeterminedCauseOfDeath = "xpath#//label[text()='[D.9.4.r.1b]']";

	// codelist tags
	public static String CLProtectConfidentiality = "xpath#//label[text()='Protect Confidentiality']//parent::span/label[text()='[1002]']";
	public static String CLAgeAtTheTimeOfEvent = "xpath#//label[text()='[1016]']";
	public static String CLGestationalAgeAtEvent = "xpath#//label[text()='[11]']";
	public static String CLConsentToContactPatient = "xpath#//label[text()='[7073]']";
	public static String CLAgeGroup = "xpath#//label[text()='[1006]']";
	public static String CLGender = "xpath#//label[text()='[1007]']";
	public static String CLWeight = "xpath#//label[text()='Weight']//parent::span/label[text()='[48]']";
	public static String CLRace = "xpath#//label[text()='[9126]']";
	public static String CLEthnicity = "xpath#//label[text()='[1022]']";
	public static String ClPregnant = "xpath#//label[text()='[1008]']";
	public static String CLHeight = "xpath#//label[text()='[347]']";
	public static String CLIdentifiablePatient = "xpath#//label[text()='Identifiable Patient']//parent::span/label[text()='[1002]']";
	public static String CLConcomitantTherapies = "xpath#//label[text()='Concomitant Therapies']//parent::span/label[text()='[1002]']";
	public static String CLBirthWeight = "xpath#//label[text()='Birth weight']//parent::span/label[text()='[48]']";
	public static String CLDiseaseType = "xpath#//label[text()='[9917]']";
	public static String CLFamilyHistory = "xpath#//label[text()='[1021]']";
	public static String CLContinuing = "xpath#//label[text()='Continuing?']//parent::span/label[text()='[1002]']";
	public static String CLRelevantforEventDescription = "xpath#//label[text()='Relevant for Event Description']//parent::span/label[text()='[1002]']";
	public static String CLConditionTreated = "xpath#//label[text()='Condition treated']//parent::span/label[text()='[1002]']";
	public static String CLCodingType = "xpath#//label[text()='[158]']";
	public static String CLStrengthNumber = "xpath#//label[text()='[9070]']";
	public static String CLAutopsyDone = "xpath#//label[text()='Autopsy Done?']//parent::span/label[text()='[1002]']";
	public static String CLRiskFactor = "xpath#//label[text()='[9650]']";
	public static String CLEvaluation = "xpath#//label[text()='[9916]']";

	public static String autopsyDone_Manual_checkbox = "xpath#//div[@id='ui-panel-31-content']/div/div/div[3]/p-checkbox/div/div[2]";
	public static String autopsyDone_Yes_radiobtn = "xpath#//div[@id='ui-panel-31-content']/div/div/div[2]/span[1]/span/p-radiobutton[1]/div/div[2]/span";
	public static String autopsyDone_No_radiobtn = "xpath#//div[@id='ui-panel-31-content']/div/div/div[2]/span[1]/span/p-radiobutton[2]/div/div[2]/span";

	// Date As TextFields
	public static String patientDOB_Text = "xpath#//label[contains(text(),'Patient DOB')]/following-sibling::span/input";

	// Set report
	public static String raceDropdown(String label) {
		String value = raceDropdown.replace("%s", label);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click on Add Button for specified
	 * Div. Input Parameters: Div Name Parameters:
	 * 
	 * @author:Sanchit Date :27-Nov-2019 Updated by and when
	 **********************************************************************************************************/
	public static String clickAddButton(String divName) {
		String value = addButton;
		String value2 = value.replace("%divName%", divName);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click on Delete Button for specified
	 * Div. Input Parameters: Div Name Parameters:
	 * 
	 * @author:Sanchit Date :27-Nov-2019 Updated by and when
	 **********************************************************************************************************/
	public static String clickDeleteButton(String divName) {
		String value = deleteButton;
		String value2 = value.replace("%divName%", divName);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to set Weight and Height text field by
	 * passing label name at runtime. Input Parameters: ColumnName Scenario Name
	 * Output Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String set_WeightHeight(String runTimeLabel) {
		String value = set_WeightHeight_TxtField;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to set data in text field by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String setData_Textfields(String runTimeLabel) {
		String value = setData_Textfields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to set data in text area by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Sanchit Date :20-Nov-2019 Updated by and when
	 **********************************************************************************************************/
	public static String setData_TextArea(String runTimeLabel) {
		String value = setData_TextAreafields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to set data in date field by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String setData_Datesfields(String runTimeLabel) {
		String value = setData_Datesfields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to set data in date field by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:DushyanthMahesh Date :06-Sept-2019 Updated by and when
	 **********************************************************************************************************/
	public static String setAutopsyDetermindCauseOfDeath(String runTimeLabel, String rowNum) {
		String value = autopsyDeterminedCauseOfDeathTxtbox;
		String value2;
		value2 = value.replace("{0}", runTimeLabel);
		value2 = value2.replace("{@}", rowNum);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click checkboxs by passing label
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String click_Checkboxs(String runTimeLabel) {
		String value = click_Checkboxs;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select radio button by passing label
	 * name and value at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String select_RadioButtons(String runTimeLabel, String valueRuntime) {
		String value = select_RadioButtons.replace("%s", runTimeLabel);
		value = value.replace("%r", valueRuntime);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click drop downs by passing label
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String click_DropDown(String label) {
		String value = click_DropDown.replace("{0}", label);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click embedded drop downs by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String click_embeddedDrpdwn(String label) {
		String value = click_embeddedDrpdwn.replace("{0}", label);
		return value;
	}

	// set Drop down value
	public static String setdropDownValue(String data) {
		String value = setdropDownValue.replace("%s", data);
		return value;
	}

	public static String NullFlavourDropDown(String label) {
		String value = NullDropdown.replace("{0}", label);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click NF button by passing label
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Yashwanth Naidu Date :22-April-2020 Updated by and when
	 **********************************************************************************************************/
	public static String click_NFBtn(String Label) {
		String value = clickNFbutton;
		String value2;
		value2 = value.replace("%s", Label);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to navigate at specific label field by
	 * passing label name at runtime. Input Parameters: label name maintained in
	 * Event Object Repository Parameters:
	 * 
	 * @author:Abhisek Ghosh Date : 18-Feb-2021
	 **********************************************************************************************************/

	public static String verifyLabel = "xpath#//label[contains(text(),'%s%')]";
	public static String ageGroupDropDown = "xpath#//label[contains(@class,'ng-tns-c2-121 ui-dropdown-label ui-inputtext ui-corner-all ng-star-inserted')]";

	public static String labelField(String runTimeLabel) {
		String value = verifyLabel;
		String value2;
		value2 = value.replace("%s%", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to navigate
	 * @InputParameters: Record Number in String
	 * @author: Shamanth Date : 18-Feb-2021
	 **********************************************************************************************************/
	public static String medicalHistoryRecHeader = "xpath#//p-panel [@id='fdePanelId936']//ul/li/a/span[contains(text(),'%s%. ')]";

	// public static String medicalHistoryRec2 = "xpath#//p-panel
	// [@id='fdePanelId936']//ul/li/a/span[contains(text(),'2. ')]";
	public static String medicalHistoryRecHeader(String recNum) {
		String value = medicalHistoryRecHeader;
		value = value.replace("%s%", recNum);
		return value;
	}

	public static String medDRALLTforDiseaseTerm_LookUpIcon_Formview = "xpath#//span/label[text()='MedDRA LLT for Disease Term']/parent::span/following-sibling::span/a/img";
	public static String startDateMedHist_FormView = "xpath#//span/label[text()='Start Date']/parent::span//span/input[contains(@id,'startDate')]";
	public static String endDateMedHist_FormView = "xpath#//span/label[text()='End Date']/parent::span//span/input[contains(@id,'DPN10330_IB_107107')]";
	public static String continuingYes_Radio_FormView = "xpath#//label[text()='Continuing?']/parent::span/span/span/p-radiobutton/label[text()='Yes']";

	// Date of Death
	public static String dateOfDeathNFselected = "xpath#//span/label[text()='Date of Death']/parent::span/following-sibling::span/a[1][contains(@style,'none')]/parent::span";
	public static String dateOfDeathNFImg = "xpath#//span/label[text()='Date of Death']/parent::span/following-sibling::span/a[2]/parent::span";

	/**********************************************************************************************************
	 * @Objective:The below method is created to navigate particular sub-section in
	 *                Patient screen
	 * @InputParameters: sub-section name
	 * @author: Shamanth Date : 18-Feb-2021
	 **********************************************************************************************************/
	public static String subSectionHeader = "xpath#//div[contains(@id,'ui-tabpanel')]/div/ul/li/a[text()='%s%']";

	public static String subSectionHeader(String sectionName) {
		String value = subSectionHeader;
		value = value.replace("%s%", sectionName);
		return value;
	}

	public static String confirmationWinTitle = "xpath#//p-confirmdialog/div//span[text()='Confirmation']";
	public static String confirmationWinBtnYes = "xpath#//p-confirmdialog/div//button/span[text()='Yes']";
	public static String confirmationWinBtnNo = "xpath#//p-confirmdialog/div//button/span[text()='No']";
}
