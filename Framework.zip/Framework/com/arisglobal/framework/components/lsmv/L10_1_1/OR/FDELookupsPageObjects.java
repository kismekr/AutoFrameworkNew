package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FDELookupsPageObjects {

	// Company unit lookup page objects
	public static String companyUnit_Radiobtn = "xpath#//p-radiobutton/div/following-sibling::label[text()='Company Unit']";
	// public static String companyUnit_Radiobtn =
	// "xpath#//p-radiobutton/div/following-sibling::label[text()='COMPANYUNIT']";
	public static String set_Textfields = "xpath#//label[contains(text(),'%s')]/following-sibling::input";
	public static String companyunit_clickDropDown = "xpath#//div/label[contains(text(),'%s')]/following-sibling::p-dropdown/div/label";
	public static String companyunit_SetdropDownValue = "xpath#//ul[contains(@class,'ui-dropdown-items')]/child::li/div/span[contains(text(),'%s')]";
	public static String radioButton = "xpath#//td[@class='tblEditRow']/p-tableradiobutton/div/child::div/span";
	public static String buttons = "xpath#//button[@label='%s']/span";
	public static String searchButton_CompanyUnitlookup = "xpath#//span[contains(@class,'ui-button-text ui-clickable')][contains(text(),'Search')]";
	public static String clearButton_CompanyUnitlookup = "xpath#//span[contains(text(),'Clear')]";
	public static String companyUnitCode_Textfield = "Company Unit Code";
	public static String companyUnitName_Textfield = "Company Unit Name";
	// public static String companyUnitName_Textfield = "COMPANYUNITCODE";
	public static String type_Dropdown = "Type";
	public static String country_Dropdown = "Country";
	public static String senderOkBtn = "xpath#//div[contains(@class,'searchOkbtn')]//button[1]//span[text()='OK']";
	public static String searchSenderButton = "xpath#//button[contains(@class,'agOnEnterSearch')]";
	public static String clearSenderButton = "xpath#//button[contains(@class,'agOnEnterSearch')]//following::button[1]";
	public static String newLabel = "xpath#//label[@id='adverseEventNew:newId']";

	// buttons
	public static String search_button = "Search";
	public static String clear_button = "Clear";
	public static String cancel_button = "Cancel";
	public static String ok_button = "Ok";
	public static String ok_Uppercasebutton = "OK";

	// Account lookup
	public static String sender_Radiobtn = "xpath#//p-radiobutton/div/following-sibling::label[text()='Sender']";
	public static String accountName_Textfield = "Account Name";
	public static String domain_Textfield = "Domain";
	public static String firm_SiteFEINumber_Textfield_ = "Firm";
	public static String Acct_Lookup_SearchIcon = "xpath#//span[@class='ng-star-inserted']//img[contains(@src,'Lookup_Selection')]";

	// Search

	public static String SearchBtn = "xpath#//span[text()='Search']";

	// set Data in company unit text fields
	public static String set_Textfields(String label) {
		String value = set_Textfields.replace("%s", label);
		return value;
	}

	// company unit lookup click DropDown
	public static String companyunit_clickDropDown(String label) {
		String value = companyunit_clickDropDown.replace("%s", label);
		return value;
	}

	// set Dropdown value
	public static String companyunit_SetdropDownValue(String data) {
		String value = companyunit_SetdropDownValue.replace("%s", data);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created click buttons by passing label name at
	 * runtime. Input Parameters: ColumnName Scenario Name Output Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String buttons(String runTimeLabel) {
		String value = buttons;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

}
