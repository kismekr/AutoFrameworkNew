package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class Lib_AlwaysSeriousEvent_PageObjects {

	public static String keywordSearch_Textbox = "xpath#//input[@id='alwaysListingId:keyword']";
	public static String search_Icon = "xpath#//a[@id='alwaysListingId:defaultSearch']";
	public static String paginator = "xpath#//div[@id='alwaysListingId:alwaysFormDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String get_ListofAlwaysSeriousEvent = "xpath#//tbody[@id='alwaysListingId:alwaysFormDataTable_data']/ancestor::table/tbody/tr/td[3]";
	public static String columnHeader = "xpath#(//tbody[@id='alwaysListingId:alwaysFormDataTable_data']/ancestor::table/tbody/tr/td[3])[{%count}]";
	public static String get_PtTerm = "xpath#//tbody[@id='alwaysListingId:alwaysFormDataTable_data']/tr/td[contains(@class,'EditIcon')]/following-sibling::td[1]";
	public static String new_Btn = "xpath#//a[@id='alwaysListingId:newId']";
	public static String alwaysSeriousEvent_Lable = "xpath#//label[text()='Always Serious Event']";
	public static String alwaysSeriousEventMedDRAPTTerm_lookup = "xpath#//a[@id='alwaysDetailsForm:reactionMeddraLookup']/img";
	public static String dictionaryCodingBrowser_SearchTxtfield = "xpath#//input[@name='term']";
	public static String dictionaryCodingBrowser_SearchBtn = "xpath#//button/span[text()='Search']";
	public static String dictionaryCodingBrowser_OkBtn = "xpath#//div[contains(@class,'searchOkbtn')]/button/span[contains(text(),'O')]";
	public static String saveButton = "xpath#//div[@id='alwaysDetailsForm:panelGroupTop']//button[@id='alwaysDetailsForm:visibleSave']/span[text()='Save']";
	public static String edit_Icon = "xpath#//img[@id='alwaysListingId:alwaysFormDataTable:0:editIcon']";
	public static String get_AlwaysSeriousEventMedDRAPTTerm = "xpath#//input[@id='alwaysDetailsForm:medraPTtermtxt_input']";
	public static String get_MedDRAPTCode = "xpath#//input[@id='alwaysDetailsForm:medraCodetxt']";
	public static String get_SOCName = "xpath#//input[@id='alwaysDetailsForm:socNametxt']";
	public static String active_checkbox = "Active";
	public static String cancelButton = "xpath#//button[@id='alwaysDetailsForm:cancelId']";
	public static String event_version = "xpath#//span[contains(text(),'%s')]";
	public static String click_Dropdown = "xpath#//label[@id='alwaysListingId:medDRAVerOnemenu_label']/following-sibling::div/span";
	public static String AddSeriousEventVer_Dropdown = "xpath#//div[@id='alwaysListingId:medDRAVerOnemenu']";
	public static String addversion_Btn = "xpath#//a[@id='alwaysListingId:meddraAddBtn']";
	public static String validationPopup_Btn = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String validationOK_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']/span";
	public static String versionColumn = "xpath#//a[@id='alwaysListingId:MedDRAVerionPanel1']/span[text()='%s']";
	public static String aepaginator = "xpath#//div[@id='alwaysListingId:alwaysFormDataTable_paginator_top']";
	public static String DeleteBtn = "xpath#//a[@id='alwaysListingId:deleteId']";
	public static String NoRecordFound = "xpath#//table[@class='checkBoxnEditSty']//tr[@class='ui-widget-content ui-datatable-empty-message']/td[contains(text(),'No records found')]";
	public static String FileImport = "xpath#//div[@id='alwaysListingId:excelfileimportId']//span[@class='ui-button ui-widget ui-state-default ui-corner-all ui-button-text-icon-left ui-fileupload-choose']";
	public static String DownLoadTemplate = "xpath#//a[@id='alwaysListingId:downloadStdtemplatelnk']";
	public static String ASECheckBox = "xpath#//span[text()='Edit']/parent::th/preceding-sibling::th//div[contains(@class,'ui-chkbox-box ui-widget ui-corner-all ui-state-default')]";
	public static String DownloadIcon = "xpath#//a[@id='alwaysListingId:actionId']";
	public static String ExportSelectedRecords = "xpath#//a[text()='Export Selected Records To Excel']";
	public static String ExportAllRecords = "xpath#//a[text()='Export All Records To Excel']";
	public static String FilterIcon = "xpath#//a[@id='alwaysListingId:filterId']";
	public static String PTTermTextBox = "xpath#//input[@id='alwaysListingId:alwaysFormDataTable:medDraPtTermId:filter']";
	public static String PTTermVerify = "xpath#//span[contains(@id,'medDraPtTermIdTitle')]";
	public static String RefreshBtn = "xpath#//a[@id='alwaysListingId:refreshImage']";

	public static String IsAlwaysSeriousCheckBoxChecked = "xpath#//label[contains(text(),'Always Serious Event')]/parent::span//span/p-checkbox//div[contains(@class,'ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active')]";
	public static String IsAlwaysSeriousCheckboxUnchecked = "xpath#//label[contains(text(),'Always Serious Event')]/parent::span//span/p-checkbox//div[contains(@class,'ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state')]";
	public static String SeriousnessYes = "xpath#//label[contains(text(),'Seriousness')]/parent::span//span/p-radiobutton[1]//div[contains(@class,'ui-radiobutton-box ui-widget ui-state-default ui-state-active')]";
	public static String OtherMedicalConditionYes = "xpath#//label[contains(text(),'Other Medically Important Condition')]/parent::span//span/p-radiobutton[1]//div[contains(@class,'ui-radiobutton-box ui-widget ui-state-default ui-state-active')]";
	public static String ManualIsalwaysSeriousChkbox = "xpath#//div[contains(@class,'isAlwaysSeriousEventclass')]/following-sibling::div[1]//label[contains(text(),'Manual')]/parent::div//p-checkbox//div[contains(@class,'ui-chkbox-box ui-widget ui-corner-all ui-state-default')]";
	public static String DownGradeConfirmation = "xpath#//label[contains(text(),'Event is Downgraded, so Is Always Serious Event is cleared.Please re-evaluate Other Seriousness criteria')]";
	public static String DownGradeComment = "xpath#//textarea[@name='alwaysDownGrdReason']";
	public static String SubmitBtn = "xpath#//div[@class='searchOkbtn']//button/span[text()='Submit']";
	public static String DownGradeImg = "xpath#//a[@class='agTooltipLink ng-star-inserted']/img";

	/**********************************************************************************************************
	 * @Objective:get event name by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:DushyanthMahesh Date :16-September-2019 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderList(String num) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:Verify column name by passing column name at runtime
	 * @Parameters: Case data attribute value
	 * @author: Avinash k Date :29-Dec-2019 Updated by and when
	 **********************************************************************************************************/
	public static String verfiyColumn(String num) {
		String value = versionColumn;
		String value2;
		value2 = value.replace("%s", num);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:click based on version name by passing input Parameters:rowNum
	 *                  Output
	 * @Parameters: Case data attribute value
	 * @author:Avinash k Date :27-Dec-2019 Updated by and when
	 **********************************************************************************************************/
	public static String eventVersion(String num) {
		String value = event_version;
		String value2;
		value2 = value.replace("%s", num);
		return value2;
	}

}
