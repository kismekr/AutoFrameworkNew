package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class AppParameters_ExternalApplicationPageObjects {

	////// Administration >> Application Parameters >> External Application //////

	public static String applicationID_TextBox = "xpath#//input[@id='applicationParameterForm:eaapplicationid']";
	public static String applicationName_TextBox = "xpath#//input[@id='applicationParameterForm:eaapplicationname']";
	public static String userName_TextBox = "xpath#//input[@id='applicationParameterForm:eausername']";
	public static String password_TextBox = "xpath#//input[@id='applicationParameterForm:eapassword']";
	public static String url_TextBox = "xpath#//input[@id='applicationParameterForm:eaurl']";
	public static String productKeyword_TextBox = "xpath#//input[@id='applicationParameterForm:eaproductkeyword']";
	public static String otherKeywords_TextBox = "xpath#//input[@id='applicationParameterForm:eaotherkeyword']";
	public static String author_TextBox = "xpath#//input[@id='applicationParameterForm:eaauthor']";
	public static String publication_TextBox = "xpath#//input[@id='applicationParameterForm:eapublication']";
	public static String title_TextBox = "xpath#//input[@id='applicationParameterForm:eatitle']";
	public static String maxRecordsPerSearch_TextBox = "xpath#//input[@id='applicationParameterForm:eamaxrecpersearch']";
	public static String language_Dropdown = "xpath#//label[@id='applicationParameterForm:A1-5060_label']";
	public static String searchType_Dropdown = "xpath#//label[@id='applicationParameterForm:easearchtype_label']";
	public static String includeInALS_CheckBox = "Include in ALS";
	public static String literatureAutoAccept_CheckBox = "Literature Auto Accept";

	////// External Application >> Postal Code Integration //////

	public static String postalCodeIntegration_Dropdown = "xpath#//label[@id='applicationParameterForm:Postcodetypetxt_label']";

	////// External Application >> Redis Configuration //////

	public static String redisConfiguration_TextBox = "xpath#//input[@id='applicationParameterForm:redisIpAddress']";
	public static String port_TextBox = "xpath#//input[@id='applicationParameterForm:redisPort']";

	////// External Application >> Moxtra Chat Integration //////

	public static String clientID_TextBox = "xpath#//input[@id='applicationParameterForm:agMoxtraClientId']";
	public static String clientSecret_TextBox = "xpath#//input[@id='applicationParameterForm:clientscrId']";
	public static String organisationID_TextBox = "xpath#//input[@id='applicationParameterForm:clientOrgId']";
	public static String integrateMoxtraChat_CheckBox = "Integrate Moxtra Chat";

	////// External Application >> AceOffix Integration //////

	public static String aceOffixIntegration_Radio = "AceOffix Used";

	////// External Application >> Translator Settings //////

	public static String enableTranslator_CheckBox = "Enable Translator";
	public static String enableNarrativeTranslation_CheckBox = "Enable Narrative Translation";
	public static String enableLanguageDetect_Checkox = "Enable Language Detect";
	public static String translatorType_Dropdown = "xpath#//label[@id='applicationParameterForm:transalatorType_label']";

	////// External Application >> SDL BeGlobal Details //////

	public static String sdlBeGlobalURL_TextBox = "xpath#//input[@id='applicationParameterForm:beGlobalUrlId']";
	public static String sdlBeGlobalClientID_TextBox = "xpath#//input[@id='applicationParameterForm:beGlobalClientId']";
	public static String sdlBeGlobalClientSecret_TextBox = "xpath#//input[@id='applicationParameterForm:beGlobalSecretId']";

	////// External Application >> AG SHARE Setting(s) //////

	public static String agShareURL_TextBox = "xpath#//input[@id='applicationParameterForm:eaagshareurl']";
	public static String userID_TextBox = "xpath#//input[@id='applicationParameterForm:eauserid']";
	public static String passwordAG_TextBox = "xpath#//input[@id='applicationParameterForm:eapassword1']";

	////// External Application >> CRM //////

	public static String integrateCRM_Radio = "Integrate CRM";
	public static String crmEndPointURL_TextBox = "xpath#//input[@id='applicationParameterForm:eacrmendpointurl']";
	public static String crmUserID_TextBox = "xpath#//input[@id='applicationParameterForm:eacrmuserid']";
	public static String crmPassword_TextBox = "xpath#//input[@id='applicationParameterForm:eacrmpassword']";

	////// External Application >> Integration Option(s) //////

	public static String accounts_CheckBox = "Accounts";
	public static String contacts_CheckBox = "Contacts";

	////// External Application >> Integration URLs //////

	public static String reportsURL = "xpath#//input[@id='applicationParameterForm:eareporturl']";
	public static String adhocsReportsURL = "xpath#//input[@id='applicationParameterForm:eaadhocreporturl']";
	public static String agSearchURL_TextBox = "xpath#//input[@id='applicationParameterForm:eaagsearchurl']";
	public static String medComURL_TextBox = "xpath#//input[@id='applicationParameterForm:eamedcommurl']";
	public static String reportPublishingPath_TextBox = "xpath#//input[@id='applicationParameterForm:birtReportPublishPath']";

	////// External Application >> Extraction //////

	public static String extractionURL_TextBox = "xpath#//input[@id='applicationParameterForm:extractionUrl']";
	public static String input_TextBox = "xpath#//input[@id='applicationParameterForm:extractionInput']";

	////// External Application >> NLP Settings //////

	public static String NLPUrl_TextBox = "xpath#//input[@id='applicationParameterForm:nlpUrl']";
	public static String NLPThreshold_TextBox = "xpath#//input[@id='applicationParameterForm:nlptheshold_input']";

	////// External Application >> Business Objects Configuration //////

	public static String hostName_TextBox = "xpath#//input[@id='applicationParameterForm:hostname']";
	public static String portNumber_TextBox = "xpath#//input[@id='applicationParameterForm:portno']";
	public static String businessUserName_TextBox = "xpath#//input[@id='applicationParameterForm:username']";
	public static String businessPassword_TextBox = "xpath#//input[@id='applicationParameterForm:password']";

	////// External Application >> Setting For Elastic Search //////

	public static String enableTextIndexing_CheckBox = "Enable text Indexing";
	public static String enableFreeTextSearch_CheckBox = "Enable Free Text Search";

}
