package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class E2bMessageQueueListingPageObjects {

	public static String e2bMessageQueueListing = "xpath#//a[@id='headerForm:aeE2BMessageQueueListingId']";
	public static String basicsearch_TextField = "xpath#//input[@type='text'][@placeholder='Search...']";
	public static String serachIcon = "xpath#//span[@class='lsmv-grid-search-icon']";
	public static String noRecordsfound = "xpath#//td[@colspan='14']";
	public static String getReceiptID = "id#safetyE2BMessageQueueListform:aeE2BMessageQueueDataTable:0:receiptNoId";
	// public static String ReceiptID =
	// "xpath#//span[@id='safetyE2BMessageQueueListform:aeE2BMessageQueueDataTable:0:receiptNoId']";
	public static String ReceiptID = "xpath#//div[@fieldid='receiptNo']/child::span/following-sibling::div[@class='lsmv-grid-col-adjust ']";
	public static String XMLImportStatusDropdown = "xpath#//div[@id='safetyE2BMessageQueueListform:statusFilterId-9859']/child::div/span";
	public static String setStatus = "xpath#//ul[@id='safetyE2BMessageQueueListform:statusFilterId-9859_items']/child::li[text()='%s']";
	public static String advanceSearchButton = "xpath#//div[@id='safetyE2BMessageQueueListform:featuredSearch']//child::a[contains(@id,'safetyE2BMessageQueueListform:j_id')]";
	public static String advanceSearch_MessageNumberTextbox = "xpath#//input[@id='safetyE2BMessageQueueListform:msgNo']";
	public static String paginator = "xpath#//span[@class='ui-paginator-current']";
	public static String loadingicon = "xpath#//label[contains(@id,'exportAckXmlViewForm')][text()='Loading']";

	public static String EmptyRow = "xpath#//div[@class='lsmv-grid-row']";
	public static String RefreshBtn = "xpath#//span[contains(text(),'Refresh')]";
	public static String importRefreshIcon = "xpath#//span[@class='lsmv-refresh-icon']";
	public static String ProcessingStatus = "xpath#//div[@class='lsmv-grid-row']/div[@fieldid='processingStatus']";
	public static String XmlImportStatus = "xpath#//div[@class='lsmv-grid-row']/div[@fieldid='processingStatus']";
	public static String SafetyReportImportStatus = "xpath#//span[@id='safetyE2BMessageQueueListform:aeE2BMessageQueueDataTable:0:importStatusId']";
	public static String AdditionalComments = "xpath#//span[@id='safetyE2BMessageQueueListform:aeE2BMessageQueueDataTable:0:reportCommentsId']";
	public static String refreshImportQueue = "xpath#//div/span[text()='Import Queue']";
	public static String R2R3Icon = "xpath#//div[@fieldid='xmlType']/div[@class='lsmv-grid-col-adjust ']/img[contains(@filename,'.xml')]";

	public static String getTextColumn = "xpath#//div[@fieldid='%s']/div[@class='lsmv-grid-col-adjust ']";
	public static String easyViewButton = "xpath#//input[@type='button'][@value='Easy View']";
	public static String acknowledgmentTab = "xpath#//li[@id='btnAck']";
	public static String ackType = "xpath#//select[@id='ddlAckType']";
	public static String ackTypeDropdown = "xpath#//select[@id='ddlAckType']/option[text()='%s']";
	public static String closeComments = "xpath#//li[@id='lsmv-comments-close']";
	public static String ackReport = "ACK REPORT";
	public static String xmlFileName = "messageFileName";
	public static String messageNumber = "messageNumber";
	public static String processingStatus = "processingStatus";
	public static String importStatus = "importStatus";
	public static String safetyImportStatus = "safetyImportStatus";
	public static String xmlUploadedDate = "xmlUploadedDate";
	public static String xmlType = "xmlType";
	public static String dtdType = "dtdType";
	public static String batchOrSingle = "batchOrSingle";
	public static String icsrReportNo = "icsrReportNo";
	public static String receiptNo = "receiptNo";
	public static String additionalComments = "comment";

	public static String clickToDownload = "xpath#//div[@id='targetPanelForImportQueue']//img";
	public static String downloadButton = "xpath#//input[@id='btnDownload']";
	public static String closeDownloadPopUp = "xpath#//input[@id='btnClose']";
	
	public static String importQueue = "xpath#//span[contains(text(),'Import Queue')]";
	public static String exportQueue = "xpath#//span[contains(text(),'Export Queue')]";
	public static String exportsearch = "xpath#//div[@id='targetPanelForExportQueue']/div/div/child::div[2]/div/child::input";
	public static String exportserachIcon = "xpath#//div[@id='targetPanelForExportQueue']/div/div/child::div[2]/div/span[@class='lsmv-search-icon']";
	public static String exportprocessingStatus = "xpath#//div[@fieldid='exportStatus']/child::div//span[text()='PROCESSING STATUS']//parent::div/parent::div/parent::div/following-sibling::div/child::div[@fieldid='exportStatus']/child::div[text()='Report Generation Succesful']";

	/**********************************************************************************************************
	 * Objective:The below method is created to set XML Import Status Dropdown by
	 * passing value at runtime. Input Parameters: value Output Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String setStatus(String Runtimevalue) {
		String value = setStatus;
		String value2;
		value2 = value.replace("%s", Runtimevalue);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:Get column data Input Parameters: value Output Parameters:
	 * 
	 * @author:DushyanthMahesh Date :20-Mar-2020 Updated by and when
	 **********************************************************************************************************/
	public static String getTextColumn(String fldid) {
		String value = getTextColumn;
		String value2;
		value2 = value.replace("%s", fldid);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:Select ACK format Input Parameters: value Output Parameters:
	 * 
	 * @author:DushyanthMahesh Date :20-Mar-2020 Updated by and when
	 **********************************************************************************************************/
	public static String ackTypeDropdown(String ackType) {
		String value = ackTypeDropdown;
		String value2;
		value2 = value.replace("%s", ackType);
		return value2;
	}

}
