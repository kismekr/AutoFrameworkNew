package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public abstract class CaseListingPageObjects {

	public static String pagination = "xpath#//div[@id='listingTable_paginate']";
	public static String caseAttributesReports_Icon = "xpath#//img[contains(@src, 'listing_reports.svg')]";
	public static String reports_Link = "xpath#//td[starts-with(normalize-space(@class),'ADL_table_caseAttr')]/descendant::div[contains(@class, 'htmlRctTooltip')]/ul/li/a[text() = '%reportType%']";
	public static String pdfFrameid = "documentViewerDialogView:docuemntViewerContent";
	public static String downloadIcon = "xpath#//button[@id='download']";
	public static String importXmlLink = "xpath#//div[@id='advanceHeader']/div/span/div/ul/li/a[text()='Import XML']";
	public static String keywordSearchTextbox = "xpath#//input[@id='htmlKeywordSearch']";
	public static String hirchyCheckout = "xpath#//div[contains(@class,'workFlowActivityBreadCrumb')]";
	public static String hirchyCurrentActivity = "xpath#//div[contains(@class,'workFlowActivityBreadCrumb')]/ul/li/label[@title='Current Activity']";
	public static String caseCurrentActivity = "xpath#//label[@id='adverseEventNew:workflowId']";

	public static String searchButton = "xpath#//span[@class='htmlSearchBlock']//img";
	public static String searchInputbox="xpath#//*[@id='htmlKeywordSearch']";
	public static String receiptNumberlink = "xpath#//a[@class='receiptNoSty']";
	public static String receipt="xpath#//a[@class='receiptNoSty' and text()='%id%']";
	public static String moreOptions_caselisting = "xpath#//span[contains(text(),'More Options')]";
	public static String newButton = "xpath#(//div[@class='htmlTopButtonBar']/span/button[text()='New'])[1]";
	public static String importXml = "xpath#//div[@id='advanceHeader']/div/span/div/ul/li/a[text()='Import XML']/following-sibling::input";
	// public static String importXml =
	// "xpath#//div[@class='htmlTableTopHeader'][@id='advanceHeader']//input[@type='file'][@id='fileUploadBbutton'][@value='Import']";
	public static String FIleUpload = "xpath#//input[@id='fileUploadBbutton']";
	// public static String LoadingIcon =
	// "xpath#//div[@id='headerForm:angularLoader']/img";
	// public static String validationPopup =
	// "xpath#//label[@class='validationDialogSpanSty newDesign_INFO_label']";
	public static String validationPopup = "xpath#(//label[@class='validationDialogSpanSty newDesign_INFO_label'])[1]";
	public static String AERVersionPopUp = "xpath#//div[contains(text(),'Successfully Created New AER Version')]";
	public static String collapse_Btn = "xpath#//div[@title='Collapse']";
	public static String importvalidationPopup = "xpath#//div[@id='htmlValidationDailog']/ul/li";
	public static String importvalidationPopupOk_Btn = "xpath#//div[@id='htmlValidationDailog']/div/a[contains(text(),'OK')]";
	public static String columnSelec_validationPopup = "xpath#//span[@id='mandatoryDialogform:mandatoryID_title']";
	// public static String caseActHeader =
	// "xpath#//label[@id='adverseEventNew:workflowId']";

	// For complete activity-- Active header
	public static String caseActHeader = "xpath#//label[@id='adverseEventNew:workflowId']";

	public static String r3Import_msg = "xpath#//span[@id='ui-id-6']";
	public static String outOfWorkflowSearchPage = "xpath#//div[@class='advHeader']//label[text()='Out Of Workflow Search']";
	public static String oWS_recieptNoTextbox = "xpath#//div[@id='INBOUND_SEARCH_RECEIPT_NO']//input[@name='receiptNumber']";
	public static String oWS_SearchButton = "xpath#//div[@class='adv-title-buttons']//button[@id='advSearchButton'][text()='Search']";
	public static String oWS_SearchLoading = "xpath#//div[@id='headerForm:angularLoader']//img[contains(@src,'LoaderNew')]";

	public static String confirmationPopup = "xpath#//span[@id='ADL:deleteconfirm_title'][text()='Confirmation']";
	public static String get_deleteValidationMSG = "xpath#//div[@id='ADL:deleteconfirm']/div[@class='ui-dialog-content ui-widget-content']/span[@class='ui-confirm-dialog-message']";
	public static String deletePopup_YesBtn = "xpath#//button[@id='ADL:listiID']/span[text()='Yes']";
	// public static String oWS_LoadingIcon = "xpath#//div[@class='ui-dialog-content
	// ui-widget-content']//label[@id='adverseEventNew:j_id_1ak']";
	public static String oWS_CaseValidity = "xpath#//div[@id='adverseEventNew:casevailidtyPnl_header']";

	public static String moreActionsLink = "xpath#//a[contains(text(),'More Actions')]";
	public static String caseListingAssessedcolumn = "xpath#//tbody[@id='ADL:ADT_data']/tr/child::td[@class='width100 caseAttributImageSize assessed']/a";
	public static String caseListinglable = "xpath#//div[@class='CaseList_Label']/div/label[contains(text(),'Case Listings')]";
	public static String PopupOkButton = "xpath#//div[@id='validationDialog']//button[@class='buttonBg'][contains(text(),'OK')]";
	public static String listingCheckBox = "xpath#//td[@class=' htmlSelectChkBox']/input[@type='checkbox']";
	public static String deleteLink = "xpath#//div[@class='DeleteLink']/a[@id='ADL:deleteAe']";
	public static String noRecordFound = "xpath#//tbody//child::td[text()='No records found']";
	public static String reAssignButton = "xpath#//div[@class='htmlTopButtonBar']/button[text()='Reassign']";
	public static String assignToLabel = "xpath#//div[@class='caseAssgnToAe']/label[text()='Assign To']";
	public static String clickAssignToDropDown = "xpath#//input[@id='AEL:caseAssgnTo_focus']/ancestor::div[@class='ui-helper-hidden-accessible']/following-sibling::label";
	public static String setAssignToDropDown = "xpath#//ul[@id='AEL:caseAssgnTo_items']/child::li[contains(text(),";
	public static String getReceiptNumber = "xpath#//a[@class='receiptNoSty']";
	public static String refreshIcon = "xpath#//a[@id='htmlTableRefreshicon']";
	public static String searchLinks = "xpath#//div[@class='leftSideContent']/ul/li/a[contains(text(),'%s')]";
	public static String columnSelectionButton = "xpath#//button[@id='ADL:ADT:toggler']";
	public static String selectColumn = "xpath#//ul[@class='ui-columntoggler-items']/child::li/label[contains(text(),'%s')]";
	public static String getColumnAttribute = "xpath#//div[@id='ADL:ADT:colTogglerinDataTable' and @role='dialog']/child::li/label[contains(text(),'%s')]/ancestor::li[@class='ui-columntoggler-item']/div/div/input";
	public static String saveColumnReorderButton = "xpath#//a[@id='ADL:saveAeColOrderBtn']";
	public static String verifyColumnName = "xpath#//thead[@id='ADL:ADT_head']/tr[@role='row']/th[not(contains(@style,'display: none;'))][contains(@aria-label,'%s')]";
	public static String FDEcaseListingClickDropdown = "xpath#(//div[contains(@id,'htmlistingPanel')]/div//label[text()='%s']/following-sibling::span//span[contains(@class,'select2-selection__rendered')])[1]";
	public static String FDEcaseListingSelectDropdown = "xpath#//ul[@class='select2-results__options']/child::li[contains(text(),'%s')]";
	public static String caseListingLoading = "xpath#//div[@id='headerForm:angularLoader']/img";
	public static String companyUnit_column = "xpath#//table[@role='grid']/thead[@id='ADL:ADT_head']/tr[@role='row']/th[@id='ADL:ADT:companyUnit']";
	public static String get_columnAttribute = "xpath#//ul[@class='ui-columntoggler-items']/child::li/label[contains(text(),'%s')]/ancestor::li/div/div[2]";
	// public static String get_columnAttribute =
	// "xpath#//div[@id='ADL:ADT:colTogglerinDataTable' and
	// @role='dialog']/child::li/label[contains(text(),'%s')]/ancestor::li/div/div[2]";
	public static String moreOptions_Button = "xpath#//button[contains(text(),'More Options')]";
	// public static String openMultiple_link = "xpath#//a[@id='ADL:multipleEdit']";
	public static String multipleCheckbox = "xpath#//th[@id='ADL:ADT:columnMultipleChkbox']/div//span";
	public static String moreOptionsLink = "xpath#//div[@class='htmlListingMreBtnTooltip']/ul/li/a[contains(text(),'%s')]";
	public static String compareButton = "xpath#//div[@id='ADL:aeCaseCompare']/button/span[text()='Compare']";

	// ----------------------------------------------
	public static String moreOptionsCopy = "xpath#//div[@class='tooltipInqList']/a[text()='Copy']";
	public static String copyCaseComments = "xpath#//textarea[@id='safetyCopyForm:commentId']";
	public static String copyCaseCopyButton = "xpath#//button[contains(@id,'safetyCopyForm:submitCopyHiddenBtn')]";
	// ----------------------------------------------
	// More Options Link
	public static String exportAERData_link = "Export AER Data";
	public static String delete_link = "Delete";
	public static String openMultiple_link = "Open Multiple";

	// ISP Case Processing Workflow link
	public static String workflowlink = "xpath#//div[@class='workFlowTreeHeader']/following-sibling::ul/li/a[text()='%s']";
	public static String caseDeletion_WFlink = "Case Deletion";

	// searchLinks
	public static String outOfWorkflowSearch_link = "Out of Workflow Search";
	public static String advanceSearch_link = "Advanced Search";

	public static String columnSelectionImg = "xpath#//img[@title='Column Selection']";
	public static String columnSelectionFilter = "xpath#//input[@class='htmlColSelectionFilter']";
	public static String columnSelectionCheckbox = "xpath#//li[@style='display: list-item;']//input";
	public static String wfCurrentActivity = "xpath#//tr[1]/td[@class=' ADL_table_wfActivityName']/div";
	public static String Filter = "xpath#//span[@id='caseListingColFilter']//img";
	public static String CaseAttributeHTML = "xpath#//td[@class=' ADL_table_caseAttr']//span[@class='htmlRctColMreAction'][2]//img";
	public static String DocumnetSelection = "xpath#//div[@class='htmlRctTooltip htmlToolTip']//ul//li//a[contains(text(),'%s')]";

	// Wait for RCT displayed

	public static String RCT = "xpath#//a[@class='receiptNoSty'][text()='%s']";

	// workflow
	public static String workflowInitial = "xpath#//a[contains(text(),'Initial')]";
	public static String workflowIntakeAndAssessment = "xpath#//a[contains(text(),'Intake and Assessment')]";

	// Data Export Movehover
	public static String ExportHover = "xpath#//div[@id='listingHtmlHeaderIcons']//span[@id='exportPanelGroup']";
	public static String ExportClick = "xpath#//span[@id='exportPanelGroup']//a[contains(text(),'Export To Excel')]";
	public static String SelectAllCheckboxCheck = "xpath#//label[contains(text(),'Select All')]//span[@class='checkmark' and not(@checked)]";
	public static String ExportBtn = "xpath#//div[@class='smq-footer ']//a[text()='Export']";

	public static String ISPcaseProcessingWorkflowFilter = "xpath#//div[text()='ISP Case Processing Workflow']/following-sibling::ul/li/a[text()='{%s}']";
	public static String workflowCurrentStatus = "xpath#//label[@id='workflowCurrentText']";
	public static String selectSearchedCase = "xpath#(//td[@class=' htmlSelectChkBox']/input)[1]";
	public static String createNewVersionDialog = "xpath#//span[@class='ui-dialog-title'][text()='Create New Version']";
	public static String createNewVerComments = "xpath#//textarea[@name='aerCommentsForVersion']";
	public static String createNewversionSubmit = "xpath#//a[text()='Submit']";

	public static String OkPopup_reassignbtn = "xpath#//div[@id='htmlValidationDailog']//a[@class='btn btn-secondary']";
	public static String AssignToDD_Textbox = "xpath#//input[@class='select2-search__field']";

	public static String Load_img = "xpath#//img[@id='headerForm:j_id_x']";
	public static String paginator = "xpath#//a[@class='paginate_button next']";

	// Create new version
	public static String Createnewverion = "Create New Version";
	public static String Aer_lookup = "xpath#//a/img[@title='AER #']";
	public static String Createnewvercomment = "xpath#//textarea[@name='createNewVersionForm:commentId']";
	public static String CreatenewverSubmit = "xpath#//a[contains(@onclick,'submitAerVersion')][text()='Submit']";

	public static String AERNotextbox = "xpath#//input[@id='aerNoForm:aer']";
	public static String SearchBtn = "xpath#//span[text()='Search']";
	public static String Aerradiobtn = "xpath#//td[@class='ui-selection-column']//input[@type='radio']/following::span[@class='ui-radiobutton-icon ui-icon ui-icon-blank ui-c']";
	public static String AerokBtn = "xpath#//thead[@id='aerNoForm:aerTable:aerLookUpDataTable_head']/following::button[@id='aerNoForm:okButtonBottom']";
	public static String newversioncomments = "xpath#//textarea[@name='aerCommentsForVersion']";

	// followup notification

	public static String followupnotificationalert = "xpath#//span[text()='Follow-Up Notification Alert']";
	public static String followupyesbtn = "xpath#//span[@id='adverseEventNew:fuNotificationId_title']/following::div/div/following::button[@id='adverseEventNew:j_id_1b2']/span[text()='Yes']";
	public static String appendtoexisitngbtn = "xpath#//button[text()='Append To Existing']";
	public static String createnewversionbtn = "xpath#//button[text()=' Create New Version ']";

	public static String showMoreLink = "xpath#//div[text()='Show More']";
	public static String listingColumnFilter = "xpath#//a[@title='Quick Column Filter']/img";
	public static String workflowActivitySearch = "xpath#//input[@name= 'wfActivityName']";
	public static String searchLoader = "xpath#//img[@id = 'headerForm:j_id_y']";

	// listing screen columns
	public static String columnSelection = "xpath#//span[@id='htmlColSelection']/img";
	public static String columnSelectAll = "xpath#//span[@id='lbl_selectAll']/parent::a/input[@class='htmlColSelectionUnqChckBox']";
	public static String aerNolink = "xpath#//td[@class=' ADL_table_aerNo']/a";
	public static String reportTypeFieldData = "xpath#//td[@class=' ADL_table_reportType']";
	public static String productNameFieldData = "xpath#//td[@class=' ADL_table_dmidrug']/a";
	public static String companyUnitData = "xpath#//td[@class=' ADL_table_companyUnitName']";
	public static String reportTermData = "xpath#//td[@class=' ADL_table_transdmiReaction']";
	public static String reportReceivingMediumData = "xpath#//td[@class=' ADL_table_mediumCode']";
	public static String safetyReportIdData = "xpath#//td[@class=' ADL_table_safetyReportId']";
	public static String reportPriorityData = "xpath#//td[@class=' ADL_table_priority']";
	public static String reportReceivingFormatData = "xpath#//td[@class=' ADL_table_sourceFormType']";
	public static String reporterEmailIdData = "xpath#//td[@class=' ADL_table_reporterEmail']";
	public static String reporterStateData = "xpath#//td[@class=' ADL_table_reporterState']";
	public static String reporterCountryData = "xpath#//td[@class=' ADL_table_reporterCountry']";
	public static String reportClassificationData = "xpath#//td[@class=' ADL_table_reportClassificationCategory']";
	public static String casePriorityData = "xpath#//td[@class=' ADL_table_casePriority']";
	public static String studyTypeData = "xpath#//td[@class=' ADL_table_studyType']";

	public static String caseApproved = "xpath#//img[@title='Approved']";
	public static String japanDataEntryLink = "xpath#//td[@class=' ADL_table_wfActivityName']/div[text()='JPN Data Entry']";
	public static String lbl_deletedWorkflow = "xpath#//label[@id='adverseEventNew:caseStatusIdMah']";
	public static String DupDeleteValidationPopUp = "xpath#//div[@id='validationDialog']";
	public static String NotifiedFollowupIcon = "xpath#//i[contains(@title,'Notified')]";

	// Xml
	public static String selectAll_checkbox = "xpath#//span[@id='lbl_selectAll']/preceding::input[@class='htmlColSelectionUnqChckBox']";
	public static String XMLicon = "xpath#//a/img[@class='htmlListingIcons']";
	public static String downloadBtn = "xpath#//input[@id='btnDownload']";
	public static String closeBtn = "xpath#//input[@id='btnClose']";
	public static String caseAttributeslable = "xpath#//th[text()='Case Attributes']";
	public static String caseListingLabel = "xpath#//label[text()='Case Listings']";

	// Case Attributes
	public static String caseSeriousness_Label = "xpath#//th[text()='Case seriousness']";
	public static String partialCodeIcon = "xpath#//span//img[@title='Partially Coded']";
	public static String caseCodedIcon = "xpath#//span//img[@title='Coded']";
	public static String caseCoding_Label = "xpath#//span[contains(text(),'Case Coding')]";
	public static String prodNameAsReportedList = "xpath#//th[text()='PRODUCT NAME AS REPORTED']/ancestor::thead/following-sibling::tbody//tr/td[1]";
	public static String prodNameAsReported = "xpath#(//th[text()='PRODUCT NAME AS REPORTED']/ancestor::thead/following-sibling::tbody//tr/td[1])[%count%]";
	public static String codingStatusList = "xpath#//th[text()='CODING STATUS']/ancestor::thead/following-sibling::tbody//tr/td/img";
	public static String codingStatus = "xpath#(//th[text()='CODING STATUS']/ancestor::thead/following-sibling::tbody//tr/td/img)[%count%]";
	public static String getindicationTerm = "xpath#(//th[text()='INDICATION TERM']/ancestor::thead/following-sibling::tbody//tr/td[1])[%count%]";
	public static String getindicationTermList = "xpath#//th[text()='INDICATION TERM']/ancestor::thead/following-sibling::tbody//tr/td[1]";
	public static String indicationStatusList = "xpath#//h5[text()=' Drug Indications']//following::th[text()='CODING STATUS']/ancestor::thead/following-sibling::tbody//tr/td/img";
	public static String indicationStatus = "xpath#(//h5[text()=' Drug Indications']//following::th[text()='CODING STATUS']/ancestor::thead/following-sibling::tbody//tr/td/img)[%count%]";
	public static String productStatus = "xpath#(//h5[text()=' Product(s)']//following::th[text()='CODING STATUS']/ancestor::thead/following-sibling::tbody//tr/td[2]/img)[%count%]";
	public static String productStatusList = "xpath#//h5[text()=' Product(s)']//following::th[text()='CODING STATUS']/ancestor::thead/following-sibling::tbody//tr/td[2]/img";
	public static String drugIndicationLabel = "xpath#//h5[text()=' Drug Indications']";
	public static String closeIcon = "xpath#//div[contains(@class,'codinglookupSty')]//button[@title='Close']";

	public static String caseDeletedIcon = "xpath#//td[@class=' ADL_table_receiptNo']//img[@title='Deleted']";
	public static String clearall = "xpath#//a[text()='Clear All']";

	public static String duplicateSearch_Link = "Duplicate Search";
	public static String duplicateSearchHeader = "xpath#//label[text()='Duplicate Search']";
	public static String dupAerNoLookUp = "xpath#//label[text()='AER Number']//parent::div//img";
	public static String aerNoLookUpHeader = "xpath#//span[text()='Aer No Lookup']";
	public static String areNoTextBox = "xpath#//input[@name='Aer No']";
	public static String aersearchBtn = "xpath#//span[text()='Search']";
	public static String receiptNo = "xpath#//input[@name='rctNo']";
	public static String dupSearchBtn = "xpath#//button[@id='dupSearchButton']";
	public static String dupRCT = "xpath#//td[text()='%s']";

	public static String copiedAERNo = "xpath#//label[@id='adverseEventNew:mappedAerNoLable']";
	public static String distributeActivity = "xpath#//label[text()='Distribute']";

	// Follow up received
	public static String followupRecvdIcon = "xpath#//i[@title='Followup Received']";

	public static String dupRCTNo(String data) {
		String value = dupRCT;
		String value2;
		value2 = value.replace("%s", data);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get the indication name in listing
	 *                screen
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Pooja S Date :06-Oct-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String getIndication(String count) {
		String value = getindicationTerm;
		String value2;
		value2 = value.replace("%count%", count);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get the coding status in listing
	 *                screen
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Pooja S Date :06-Oct-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String getIndicationStatus(String count) {
		String value = indicationStatus;
		String value2;
		value2 = value.replace("%count%", count);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get the coding status in listing
	 *                screen
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Pooja S Date :06-Oct-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String productCodingStatus(String count) {
		String value = productStatus;
		String value2;
		value2 = value.replace("%count%", count);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get the product name as reported in
	 *                listing screen
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Pooja S Date :06-Oct-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String getProdNameAsReported(String count) {
		String value = prodNameAsReported;
		String value2;
		value2 = value.replace("%count%", count);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to to check RCT is visible by passing
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Avinash K Date :05-Feb-2019 Updated by and when:
	 **********************************************************************************************************/
	public static String waitForRCT(String ColumnName) {
		String value = RCT;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to click on search link by passing
	 *                search name at runtime in case listing screen.
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Avinash K Date :31-Dec-2019 Updated by and when:
	 **********************************************************************************************************/
	public static String searchLinks(String ColumnName) {
		String value = searchLinks;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to click on workflow link by passing
	 *                workflow name at runtime in case listing screen.
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Avinash K Date :31-Dec-2019 Updated by and when:
	 **********************************************************************************************************/
	public static String workflowlink(String ColumnName) {
		String value = workflowlink;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select the check box by passing
	 *                receipt number at runtime in case listing screen.
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Avinash K Date :30-Dec-2019 Updated by and when:
	 **********************************************************************************************************/
	public static String clickCheckBox(String ColumnName) {
		String value = listingCheckBox;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select the column from column
	 * selection in case listing screen. Input Parameters: ColumnName Scenario Name
	 * Output Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when:
	 **********************************************************************************************************/
	public static String selectColumn(String ColumnName) {
		String value = selectColumn;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click link in moreoptions in case
	 * listing screen. Input Parameters: ColumnName Scenario Name Output Parameters:
	 * 
	 * @author:Avinash K Date :13-Sep-2019 Updated by and when:
	 **********************************************************************************************************/
	public static String moreOptionsLink(String ColumnName) {
		String value = moreOptionsLink;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to get the attribute from column
	 * selection in case listing screen. Input Parameters: ColumnName Scenario Name
	 * Output Parameters:
	 * 
	 * @author:Avinash K Date :10-Sep-2019 Updated by and when:
	 **********************************************************************************************************/
	public static String get_columnAttribute(String ColumnName) {
		String value = get_columnAttribute;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to get the column attribute from column
	 * selection in case listing screen. Input Parameters: ColumnName Scenario Name
	 * Output Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when:
	 **********************************************************************************************************/
	public static String getColumnAttribute(String ColumnName) {
		String value = getColumnAttribute;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to verify column name in case listing
	 * screen. Input Parameters: ColumnName Scenario Name Output Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String verifyColumnName(String ColumnName) {
		String value = verifyColumnName;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click Assign to and Show DropDown in
	 * case listing screen by passing label name at runtime. Input Parameters: label
	 * name Scenario Name Output Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String clickDropDown(String runTimeLabel) {
		String value = FDEcaseListingClickDropdown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to Assign to and Show dropdown value in
	 * case listing screen by passing value at runtime. Input Parameters: ColumnName
	 * Scenario Name Output Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String selectDropdown(String runTimeLabel) {
		String value = FDEcaseListingSelectDropdown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to Click on Export Values Scenario Name
	 * Output Parameters:
	 * 
	 * @author:wajahatumar S Date :20-Feb-2020 Updated by and when
	 **********************************************************************************************************/
	public static String ExportValue(String runTimeLabel) {
		String value = ExportClick;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective: ISP case processing workflow
	 * 
	 * @author:DushyanthMahesh Date :16-Mar-2020 Updated by and when
	 **********************************************************************************************************/
	// div[text()='ISP Case Processing
	// Workflow']/following-sibling::ul/li/a[text()='{%s}']

	public static String ISP_CaseProcessingWF_Filters(String filterLabel) {
		String value = ISPcaseProcessingWorkflowFilter;
		String value2;
		value2 = value.replace("{%s}", filterLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select the check box by passing
	 *                receipt number at runtime in case listing screen.
	 * @Input Parameters: ColumnName Scenario Name
	 * @Output Parameters:
	 * @author:Avinash K Date :30-Dec-2019 Updated by and when:
	 **********************************************************************************************************/
	public static String DocumentSelection(String ColumnName) {
		String value = DocumnetSelection;
		String value2;
		value2 = value.replace("%s", ColumnName);
		return value2;
	}

	public static String ConfirmationMessage = "xpath#//div[@id='delteConfirmDlgContent']/div/div/label";
	public static String OkButton = "xpath#//div[@id='delteConfirmDlgContent']//span[@id='okCnfDlgDetails']";
	public static String receiptGenericLik = "xpath#//a[@class='receiptNoSty' and .='%RCT%']/parent::td/preceding-sibling::td/input";
	public static String genericrecptCheckbox(String rctnum) {
		String value=receiptGenericLik.replace("%RCT%", rctnum);
		return value;
		
	}
	
	public static String clickReceipt(String id) {
		String value=receipt;
		value=value.replace("%id%", id);
		return value;	
	}
}