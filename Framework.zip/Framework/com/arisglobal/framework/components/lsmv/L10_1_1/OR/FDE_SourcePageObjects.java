package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import com.arisglobal.framework.lib.main.ToolManager;

public class FDE_SourcePageObjects extends ToolManager {

	/**************************************
	 * SourcePageObjects
	 ***********************************************************/

	public static String senderOrganizationTextBox = "xpath#//input[@id='adverseEventNew:sourcePanelTable:originatingAccount']";
	public static String ReferenceNumberTextBox = "xpath#//input[@id='adverseEventNew:sourcePanelTable:identificationNo']";
	public static String DescriptionTextBox = "xpath#//input[@id='adverseEventNew:sourcePanelTable:srcDescription']";
	public static String sourceDropdown = "xpath#//select[contains(@name,'adverseEventNew:sourceTable:idN12419112104-346_focus0')]";
	public static String referenceTypeDropdown = "xpath#//select[contains(@name,'adverseEventNew:sourcePanelTable:referenceType-9060_focus0')]";
	public static String dateReceivedTextBox = "xpath#//input[@id='adverseEventNew:sourceTable:srcDateReceived:impcalinput']";
	public static String primarySourceCheckBox = "xpath#//label[text()='Primary Source ']";
	public static String primarySourceCheckLabel = "Primary Source ";
	public static String senderOrganizationLookUpIcon = "xpath#//a[@class='agLookupLink']/img";

	public static String addButton = "xpath#//a[contains(@class,'agMultiAddLink')][text()='Add']";

	public static String source_DropdownLabel = "Source";
	public static String referenceType_DropdownLabel = "Reference Type";

	// Sender Org Lookup Objects
	public static String accountNameTextBox = "xpath#//label[text()='Account Name']//following::input[1]";
	public static String domainTextBox = "xpath#//label[text()='Domain']//following::input[1]";
	public static String firmOrSiteFEINumberTextBox = "xpath#//label[text()='Firm/Site FEI Number']//following::input[1]";
	public static String searchSenderButton = "xpath#//button[contains(@class,'agOnEnterSearch')]";
	public static String clearSenderButton = "xpath#//button[contains(@class,'agOnEnterSearch')]//following::button[1]";
	public static String selectBySenderRecRadioBtn = "xpath#//td[@class='tblEditRow']/p-tableradiobutton/div/child::div/span";

	public static String senderOkBtn = "xpath#//div[contains(@class,'searchOkbtn')]//button[1]//span[text()='OK']";

	public static String companyUnitCodeTextBox = "xpath#//label[text()='Company Unit Code']//following::input[1]";
	public static String companyUnitNameTextBox = "xpath#//label[text()='Company Unit Name']//following::input[1]";
	public static String selectByCompanyUnitRecRadioBtn = "xpath#//td[@class='tblEditRow']/p-tableradiobutton/div/child::div/span";
	public static String typeLabel = "Type";
	public static String countryLabel = "Country";

	public static String senderRadiobtn = "xpath#//input[@type='radio'][@value='sender']/following::span[1]";
	public static String companyUnitRadiobtn = "xpath#//input[@type='radio'][@value='partner']/following::span[1]";

	public static String sourceDropdownSelect = "xpath#//input[@id='adverseEventNew:sourceTable:idN12419112104-346_focus']//ancestor::div[2]";
	public static String sourceRefTypeDropdownSelect = "xpath#//input[@id='adverseEventNew:sourcePanelTable:referenceType-9060_focus']//ancestor::div[2]";

	public static String verify_Datesfields = "xpath#//label[contains(text(),'%s')]/following::span[2]/input[1]";
	public static String dateReceivedLabel = "Date Received ";

	public static String dateRecevied = "xpath#//input[@id='adverseEventNew:sourceTable:srcDateReceived:impcalinput']";

	public static String buttons = "xpath#//span[@class='agAddDeleteBlock ng-star-inserted']/a[@title='%s']";
	public static String navigaterClick = "xpath#//div[@class='tabCarouselSty']/following::a[@class='tabCarouselNext evAttached']";
	public static String click_MultipleSource = "xpath#//div[@class='tabCarouselSty']/ul/li/a/span[starts-with(text(),'%s')]";

	public static String sourceSenderOrgLabel = "Source_SenderOrganization";
	public static String sourceDataReceivedLabel = "Source_DateReceived";
	public static String sourceReferenceNo = "Source_ReferenceNumber";
	public static String sourceSourceDescLabel = "Source_Description";
	// Codelist

	public static String CLPrimarySource = "xpath#//label[text()='Primary Source']//parent::span/label[text()='[4]']";
	public static String CLSource = "xpath#//label[text()='[346]']";
	public static String CLReferenceType = "xpath#//label[text()='[9060]']";

	public static String SourceTab = "xpath#//span[text()='2. Source']";
	public static String SourceTab3 = "xpath#//span[text()='4. Source']";
	public static String SourceTab4 = "xpath#//span[text()='3. Source']";

	public static String DeleteSource = "xpath#//span[contains(@class,'agAddDeleteBlock')]//a[@class='agMultiDeleteLink ng-star-inserted']";
	public static String YesBtn = "xpath#//p-confirmdialog//button//span[text()='Yes']";

	public static String secondSource = "2. Source";

	public static String clickMultipleSource(String runTimeLabel) {
		String value = click_MultipleSource.replace("%s", runTimeLabel);
		return value;
	}

	public static String setData_Datesfields(String runTimeLabel) {
		String value = verify_Datesfields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Purpose: To handle Add, Delete and Copy buttons with single method
	 * @author: MP Ramkumar
	 * @Pre-requisite: NA
	 * @Date :29-Feb-2020
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String buttonLabel(String buttonName) {
		String value = buttons;
		String value2;
		value2 = value.replace("%s", buttonName);
		return value2;
	}

	/**********************************************************************************************************
	 * @Purpose: To select specific source record from multiple records based on
	 *           runtime value
	 * @author: Abhisek Ghosh
	 * @Pre-requisite: NA
	 * @Date :22-Mar-2021
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String sourceRecord = "xpath#//span[contains(text(),'%s')]";

	public static String clickSourceRecord(String runTimeLabel) {
		String value = sourceRecord;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String sourceSubtabs = "xpath#//span[text()='%i. Source']";

	public static String sourceSubtabs(String tabcount) {
		String value = sourceSubtabs.replace("%i", "2");
		return value;
	}
}
