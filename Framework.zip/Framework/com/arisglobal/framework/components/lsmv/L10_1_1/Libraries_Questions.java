package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.List;

import org.openqa.selenium.WebElement;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.QuestionsPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Libraries_Questions  extends ToolManager {
	
	static String className = Libraries_Questions.class.getSimpleName();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to create new Question
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :  08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createNewQuestion()
	{
		agClick(QuestionsPageObjects.newbtn);
		agAssertVisible(QuestionsPageObjects.questionname_textbox);
		CommonOperations.takeScreenShot();
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Edit new Question
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :  08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void editQuestion()
	{
		agSetStepExecutionDelay("3000");
		agClick(QuestionsPageObjects.edit_Icon);
		agAssertVisible(QuestionsPageObjects.questionname_textbox);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to select question type and Show dropdown
	 *             value in Library Question screen
	 * @InputParameters: LabelName, value
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setQuestionType(String scenarioName) 
	{	
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agIsVisible(QuestionsPageObjects.clickDropDown(QuestionsPageObjects.questionTypelabel));
		agClick(QuestionsPageObjects.clickDropDown(QuestionsPageObjects.questionTypelabel));
		agSetStepExecutionDelay("3000");
		agClick(QuestionsPageObjects.selectDropdown(getTestDataCellValue(scenarioName, "QuestionType")));
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to select module and Show dropdown
	 *             value in Library Question screen
	 * @InputParameters: LabelName, value
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setModule(String scenarioName) 
	{	
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agIsVisible(QuestionsPageObjects.clickDropDown(QuestionsPageObjects.modulelabel));
		agClick(QuestionsPageObjects.clickDropDown(QuestionsPageObjects.modulelabel));
		agSetStepExecutionDelay("3000");
		agJavaScriptExecuctorClick(QuestionsPageObjects.selectDropdown(getTestDataCellValue(scenarioName, "Module")));
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to select form name and Show dropdown
	 *             value in Library Question screen
	 * @InputParameters: LabelName, value
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setFormName(String scenarioName) 
	{	
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agIsVisible(QuestionsPageObjects.clickDropDown(QuestionsPageObjects.formnamelabel));
		agJavaScriptExecuctorClick(QuestionsPageObjects.clickDropDown(QuestionsPageObjects.formnamelabel));
		agSetStepExecutionDelay("3000");
		agJavaScriptExecuctorClick(QuestionsPageObjects.selectDropdown(getTestDataCellValue(scenarioName, "FormName")));
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to select context and Show dropdown
	 *             value in Library Question screen
	 * @InputParameters: LabelName, value
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setContext(String scenarioName) 
	{		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agIsVisible(QuestionsPageObjects.clickDropDown(QuestionsPageObjects.contextlabel));
		agJavaScriptExecuctorClick(QuestionsPageObjects.clickDropDown(QuestionsPageObjects.contextlabel));
		agSetStepExecutionDelay("3000");
		agJavaScriptExecuctorClick(QuestionsPageObjects.selectDropdown(getTestDataCellValue(scenarioName,"Context")));
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to select field and Show dropdown
	 *             value in Library Question screen
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setField(String scenarioName) 
	{	
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agIsVisible(QuestionsPageObjects.clickDropDown(QuestionsPageObjects.fieldlabel));
		agJavaScriptExecuctorClick(QuestionsPageObjects.clickDropDown(QuestionsPageObjects.fieldlabel));
		agSetStepExecutionDelay("3000");
		agJavaScriptExecuctorClick(QuestionsPageObjects.selectDropdown(getTestDataCellValue(scenarioName,"Field")));
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to select component and Show dropdown
	 *             value in Library Question screen
	 * @InputParameters: LabelName, value
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setComponent(String scenarioName) 
	{
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agIsVisible(QuestionsPageObjects.clickDropDown(QuestionsPageObjects.componentlabel));
		agJavaScriptExecuctorClick(QuestionsPageObjects.clickDropDown(QuestionsPageObjects.componentlabel));
		agSetStepExecutionDelay("3000");
		agJavaScriptExecuctorClick(QuestionsPageObjects.selectDropdown(getTestDataCellValue(scenarioName,"Component")));
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Question Details.
	 * @InputParameters: SheetName, scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setQuestionsDetails(String scenarioName,String sheetName)
	{
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		agSetValue(QuestionsPageObjects.questionname_textbox, getTestDataCellValue(scenarioName, "QuestionName"));
		CommonOperations.clickCheckBoxRightOf(QuestionsPageObjects.Activelabel, getTestDataCellValue(scenarioName, "Active"));
		setQuestionType(scenarioName);
		setModule(scenarioName);
		setFormName(scenarioName);
		setContext(scenarioName);
		setField(scenarioName);
		setComponent(scenarioName);
		//agSetValue(QuestionsPageObjects.displayOrderTextbox, getTestDataCellValue(scenarioName, "DisplayOrder"));
		Save(scenarioName , sheetName);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Libraries Scenario Name:: "+scenarioName, true);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Question Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyQuestionDetails(String scenarioName) 
	{
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "QuestionName"), QuestionsPageObjects.questionname_textbox);
		CommonOperations.verifyCheckBoxRightOf(QuestionsPageObjects.Activelabel, getTestDataCellValue(scenarioName, "Active"));
		
		
		agCheckPropertyText(getTestDataCellValue(scenarioName, "QuestionType"),
				(QuestionsPageObjects.clickAlldropdownvalue).replace("%label%", QuestionsPageObjects.questionTypelabel));
		
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Module"),
				(QuestionsPageObjects.clickAlldropdownvalue).replace("%label%", QuestionsPageObjects.modulelabel));
		
		agCheckPropertyText(getTestDataCellValue(scenarioName, "FormName"),
				(QuestionsPageObjects.clickAlldropdownvalue).replace("%label%", QuestionsPageObjects.formnamelabel));
		
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Context"),
				(QuestionsPageObjects.clickAlldropdownvalue).replace("%label%", QuestionsPageObjects.contextlabel));
		
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Field"),
				(QuestionsPageObjects.clickAlldropdownvalue).replace("%label%", QuestionsPageObjects.fieldlabel));
		
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Component"),
				(QuestionsPageObjects.clickAlldropdownvalue).replace("%label%", QuestionsPageObjects.componentlabel));
		
		//agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "DisplayOrder"), QuestionsPageObjects.displayOrderTextbox);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Data verification in Libraries Scenario Name:: "+scenarioName, true);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to write the question number in test data.
	 * @InputParameters: Scenario Name,sheetName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void writeQuesNo_Save(String scenarioName, String sheetName) 
	{
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.agwaitTillVisible(QuestionsPageObjects.questionNo, 20, 1000);
		String quesNo = agGetText(QuestionsPageObjects.questionNo);
		String[] arrOfStr = quesNo.split("Question");
		arrOfStr = arrOfStr[1].split("Saved Successfully");
		quesNo = arrOfStr[0].trim();
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "QuestionNo", quesNo);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to save Question Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void Save(String scenarioName, String sheetName)
	{
		agSetStepExecutionDelay("5000");
		agClick(QuestionsPageObjects.savebtn);
		agWaitTillVisibilityOfElement(QuestionsPageObjects.validationPopUp);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		writeQuesNo_Save(scenarioName, sheetName);
		String QuestionNumber = agGetText(QuestionsPageObjects.questionNo);
		status = agIsVisible(QuestionsPageObjects.questionNo);
		if (status) {
			Reports.ExtentReportLog("Create new question", Status.PASS,
					"New question creation successfull :: Validation-" + QuestionNumber, true);
		} else {
			Reports.ExtentReportLog("Create new question", Status.FAIL,
					"New question creation unsuccessfull :: Validation-" + QuestionNumber, true);
		}
		agWaitTillVisibilityOfElement(QuestionsPageObjects.saveOkButton);
		agJavaScriptExecuctorClick(QuestionsPageObjects.saveOkButton);

	}
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Question name exist or not based on Question name 
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Boolean verifysearchData(String scenarioName) {
		Boolean falg = false;
		String paginator = agGetText(QuestionsPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			List<WebElement> list = agGetElementList(QuestionsPageObjects.get_ListofQuestionName);
			String columnHeader = null;
			for (int j = 1; j <= list.size(); j++) {
				columnHeader = agGetText(QuestionsPageObjects.columnHeaderList(Integer.toString(j)));
				if (getTestDataCellValue(scenarioName, "QuestionName").equalsIgnoreCase(columnHeader)) {
					falg = true;
					break;
				}
			}
		}
		return falg;
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to search Question if the question is already exists question will be ignored.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreateQuestion(String scenarioName,String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		search(scenarioName);
		if (verifysearchData(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Question Name already exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "QuestionName"),
					QuestionsPageObjects.get_ListofQuestionName);
		} else {
			createNewQuestion();
			setQuestionsDetails(scenarioName,sheetName);
			search(scenarioName);
			editQuestion();
			verifyQuestionDetails(scenarioName);
			agClick(QuestionsPageObjects.cancelbtn);
			agWaitTillVisibilityOfElement(QuestionsPageObjects.keywordSearch_TxtField);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to search Question
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void search(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(QuestionsPageObjects.keywordSearch_TxtField, getTestDataCellValue(scenarioName, "QuestionName"));
		agClick(QuestionsPageObjects.search_Icon);
		agIsVisible(QuestionsPageObjects.paginator);
		CommonOperations.takeScreenShot();
	}
	
	
	
	}
	
	
	

