package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class UserLookUpPageObjects {
	public static String userNameTextBox = "xpath#//input[@id='userGroupLookupForm:searchUserName']";
	public static String firstNameTextBox = "xpath#//input[@id='userGroupLookupForm:searchFirstName']";
	public static String lastNameTextBox = "xpath#//input[@id='userGroupLookupForm:searchLastName']";
	public static String emailIdTextBox = "xpath#//input[@id='userGroupLookupForm:searchEmailId']";
	
	public static String searchButton = "xpath#//button[@id='userGroupLookupForm:findButton']";
	public static String clearButton = "xpath#//button[@id='userGroupLookupForm:clear']";
	public static String okButton = "xpath#//button[@id='userGroupLookupForm:okButtonBottom']";
	public static String cancelButton = "xpath#//button[@id='userGroupLookupForm:cancelButtonBottom']";
	
	
	public static String selectData = "xpath#//*[text()='%data%']/ancestor::tr/td/div/div/span";
	
	// Select User Data from Search Result
    public static String selectUserData(String data) {
        String value = selectData.replace("%data%", data);
        return value;
    }
}
