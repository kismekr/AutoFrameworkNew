package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class AccountsGroupPageObjects {

	public static String get_ListofAccountsGroup = "xpath#//tbody[@id='accountsGroupListForm:accountGroupListDataTable_data']/tr/child::td[3]";
	public static String get_AccountsGroup = "xpath#//tbody[@id='accountsGroupListForm:accountGroupListDataTable_data']/tr/td[@class='EditIcon']/following-sibling::td[1]";
	public static String new_Button = "xpath#//a[@id='accountsGroupListForm:newId']";
	public static String accountsGroupListingSearch_Textbox = "xpath#//input[@id='accountsGroupListForm:keyword']";
	public static String search_Icon = "xpath#//a[@id='accountsGroupListForm:searchAccountsGroup']/img";
	public static String paginator = "xpath#//div[@id='accountsGroupListForm:accountGroupListDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String columnHeader = "xpath#(//tbody[@id='accountsGroupListForm:accountGroupListDataTable_data']/ancestor::table/tbody/tr/td[3])[{%count}]";
	public static String accountsGroupLable = "xpath#//span[@class='ui-panel-title']/label[text()='General']";
	public static String AccountsGroup_Txtfield = "xpath#//input[@id='accountsGroupForm:accountGroupName']";
	public static String Description_Txtfield = "xpath#//textarea[@id='accountsGroupForm:accountgroupDesc']";
	public static String save_Button = "xpath#//button[@id='accountsGroupForm:visibleSave']";
	public static String edit_Icon = "xpath#//img[@id='accountsGroupListForm:accountGroupListDataTable:0:editIcon']";
	public static String cancel_Button = "xpath#//button[@id='accountsGroupForm:cancelId']";
	public static String refresh_Icon = "xpath#//a[@id='accountsGroupListForm:refreshImage']";
	public static String listingScreen_CheckBoxs = "xpath#//label[text()='%s']/ancestor::tbody[@id='accountsGroupListForm:accountGroupListDataTable_data']/tr/td/div/child::div/span";
	public static String delete_Button = "xpath#//a[@id='accountsGroupListForm:deleteId']";
	public static String download_Icon = "xpath#//a[@id='accountsGroupListForm:actionId']";
	public static String exporttoExcel_link = "xpath#//button[contains(@id,'accountsGroupListForm')]/span[text()='Export To Excel']";
	public static String exporttoExcel_popup = "xpath#//span[@id='accountsGroupListForm:columnSelectionDialogId_title']";
	public static String export_Button = "xpath#//button[@id='accountsGroupListForm:submitId']";
	public static String exportexcelcancel_Button = "xpath#//button[@id='accountsGroupListForm:cancelDialogId']";

	public static String columnHeaderList(String num) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select checkbox by passing value at
	 *                runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name Output
	 * @Parameters:
	 * @author:Avinash K Date :18-Oct-2019 Updated by and when
	 **********************************************************************************************************/

	public static String selectListingCheckbox(String runTimeLabel) {
		String value = listingScreen_CheckBoxs;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

}
