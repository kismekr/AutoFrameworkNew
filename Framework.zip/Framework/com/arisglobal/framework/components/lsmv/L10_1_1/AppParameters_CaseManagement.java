package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AppParameters_CaseManagementPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AppParameters_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.WorkFlowPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AppParameters_CaseManagement extends ToolManager {
	static String className = AppParameters_CaseManagement.class.getSimpleName();

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Receipt Numbering Format
	 *             Details in Case Management Tab under Application Parameters
	 *             Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 14-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setReceiptNumberingFormatDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_CaseManagementPageObjects.receiptPrefix_TextBox,
					getTestDataCellValue(scenarioName, "ReceiptPrefix"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.receiptDateFormat_DropDown,
					getTestDataCellValue(scenarioName, "ReceiptDateFormat"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.receiptSeparator_DropDown,
					getTestDataCellValue(scenarioName, "ReceiptSeparator"));
			CommonOperations.setListDropDownValue(
					AppParameters_CaseManagementPageObjects.receiptResetSequenceBy_DropDown,
					getTestDataCellValue(scenarioName, "ReceiptResetSequenceBy"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.receiptPadding_DropDown,
					getTestDataCellValue(scenarioName, "ReceiptPadding"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.receiptFormatScripts_DropDown,
					getTestDataCellValue(scenarioName, "ReceiptFormatScripts"));
			CommonOperations.captureScreenShot(true);
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.Save);
			agWaitTillVisibilityOfElement(AppParameters_CaseManagementPageObjects.SaveOkBtn);
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.SaveOkBtn);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Receipt Numbering Format Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> Case Management >> Receipt Numbering Format Section Fails",
					true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set LRN Numbering Format Details
	 *             in Case Management Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 14-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setLRNNumberingFormatDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_CaseManagementPageObjects.lrnPrefix_TextBox,
					getTestDataCellValue(scenarioName, "LRNPrefix"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.lrnDateFormat_DropDown,
					getTestDataCellValue(scenarioName, "LRNDateFormat"));
			CommonOperations.setListDropDownValue(
					AppParameters_CaseManagementPageObjects.lrnDateFormatSequence_DropDown,
					getTestDataCellValue(scenarioName, "LRNDateFormatSequence"));
			
			if(getTestDataCellValue(scenarioName, "LRNCountry").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.lrnCountry_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.lrnCountry_CheckBox,
								getTestDataCellValue(scenarioName, "LRNCountry"));
				}
					}
			
			
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.lrnCountrySequence_DropDown,
					getTestDataCellValue(scenarioName, "LRNCountrySequence"));
			
			if(getTestDataCellValue(scenarioName, "LRNReportType").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.lrnReportType_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.lrnReportType_CheckBox,
								getTestDataCellValue(scenarioName, "LRNReportType"));
				}
					}
			

			CommonOperations.setListDropDownValue(
					AppParameters_CaseManagementPageObjects.lrnReportTypeSequence_DropDown,
					getTestDataCellValue(scenarioName, "LRNReportTypeSequence"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.lrnSeparator_DropDown,
					getTestDataCellValue(scenarioName, "LRNSeparator"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.lrnResetSequenceBy_DropDown,
					getTestDataCellValue(scenarioName, "LRNResetSequenceBy"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.lrnPadding_DropDown,
					getTestDataCellValue(scenarioName, "LRNPadding"));

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.lrnNumberingFormat_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> LRN Numbering Format Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> Case Management >> LRN Numbering Format Section Fails",
					true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set AER Numbering Format Details
	 *             in Case Management Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 14-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setAERNumberingFormatDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_CaseManagementPageObjects.aerPrefix_TextBox,
					getTestDataCellValue(scenarioName, "AERPrefix"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.aerPrefixSequence_DropDown,
					getTestDataCellValue(scenarioName, "AERPrefixSequence"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.aerDateFormat_DropDown,
					getTestDataCellValue(scenarioName, "AERDateFormat"));
			CommonOperations.setListDropDownValue(
					AppParameters_CaseManagementPageObjects.aerDateFormatSequence_DropDown,
					getTestDataCellValue(scenarioName, "AERDateFormatSequence"));
			CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.aerCountry_CheckBox,
					getTestDataCellValue(scenarioName, "AERCountry"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.aerCountrySequence_DropDown,
					getTestDataCellValue(scenarioName, "AERCountrySequence"));
			CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.aerReportType_CheckBox,
					getTestDataCellValue(scenarioName, "AERReportType"));
			CommonOperations.setListDropDownValue(
					AppParameters_CaseManagementPageObjects.aerReportTypeSequence_DropDown,
					getTestDataCellValue(scenarioName, "AERReportTypeSequence"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.aerSeparator_DropDown,
					getTestDataCellValue(scenarioName, "AERSeparator"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.aerResetSequenceBy_DropDown,
					getTestDataCellValue(scenarioName, "AERResetSequenceBy"));
			agSetValue(AppParameters_CaseManagementPageObjects.aerStartAERVersionNoFrom_TextBox,
					getTestDataCellValue(scenarioName, "AERStartAERVersionNoFrom"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.aerPadding_DropDown,
					getTestDataCellValue(scenarioName, "AERPadding"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.aerFormatScripts_DropDown,
					getTestDataCellValue(scenarioName, "AERFormatScripts"));

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.aerNumberingFormat_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> AER Numbering Format Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> Case Management >> AER Numbering Format Section Fails",
					true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Case Management Details in
	 *             Case Management Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 14-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setCaseManagementDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_CaseManagementPageObjects.maxNOofCasesDayUser_TextBox,
					getTestDataCellValue(scenarioName, "MaxNOofCasesDayUser"));
			agSetValue(AppParameters_CaseManagementPageObjects.archiveSafetyCasesOlderThan_TextBox,
					getTestDataCellValue(scenarioName, "ArchiveSafetyCasesOlderThan"));
			CommonOperations.setListDropDownValue(
					AppParameters_CaseManagementPageObjects.archiveSafetyCasesOlderThan_DropDown,
					getTestDataCellValue(scenarioName, "ArchiveSafetyCasesOlderThanDD"));
			agSetValue(AppParameters_CaseManagementPageObjects.maxNumberOfRecordsAdvancedFlexibleSearch_TextBox,
					getTestDataCellValue(scenarioName, "MaxNumberOfRecordsAdvancedFlexibleSearch"));
			agSetValue(AppParameters_CaseManagementPageObjects.icsrLocalMessageNumberSchema_TextBox,
					getTestDataCellValue(scenarioName, "ICSRLocalMessageNumberSchema"));
			agSetValue(AppParameters_CaseManagementPageObjects.sequenceLength_TextBox,
					getTestDataCellValue(scenarioName, "SequenceLength"));
			agSetValue(AppParameters_CaseManagementPageObjects.noOfCasestoCopy_TextBox,
					getTestDataCellValue(scenarioName, "NoOfCasestoCopy"));
			// CommonOperations.clickCheckBoxLeftOf(
			// AppParameters_CaseManagementPageObjects.notifyARISgWhenFollowupCaseIsDisposed_CheckBox,
			// getTestDataCellValue(scenarioName, "NotifyARISgWhenFollowupCaseIsDisposed"));
		

			if(getTestDataCellValue(scenarioName, "DisplayReporterContactFirstandLastNameDuplicateSearch").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.displayReporterContactFirstandLastNameDuplicateSearch_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.displayReporterContactFirstandLastNameDuplicateSearch_CheckBox,
								getTestDataCellValue(scenarioName, "DisplayReporterContactFirstandLastNameDuplicateSearch"));
				}
					}
			

			if(getTestDataCellValue(scenarioName, "AutoDispositionOfE2BCases").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.autoDispositionOfE2BCases_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.autoDispositionOfE2BCases_CheckBox,
								getTestDataCellValue(scenarioName, "AutoDispositionOfE2BCases"));
				}
					}
			

			if(getTestDataCellValue(scenarioName, "IncludeAllAERVersionsfromARISg").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.includeAllAERVersionsfromARISg_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.includeAllAERVersionsfromARISg_CheckBox,
								getTestDataCellValue(scenarioName, "IncludeAllAERVersionsfromARISg"));
				}
					}
			

			if(getTestDataCellValue(scenarioName, "MigrateCorrespondenceRecordstoCCM").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.migrateCorrespondenceRecordstoCCM_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.migrateCorrespondenceRecordstoCCM_CheckBox,
								getTestDataCellValue(scenarioName, "MigrateCorrespondenceRecordstoCCM"));
				}
					}
			if(getTestDataCellValue(scenarioName, "DontsendAECaseSummarySheettoArisg").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.dontsendAECaseSummarySheettoArisg_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.dontsendAECaseSummarySheettoArisg_CheckBox,
								getTestDataCellValue(scenarioName, "DontsendAECaseSummarySheettoArisg"));
				}
					}
			
			if(getTestDataCellValue(scenarioName, "DisplayAECaseTagging").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.displayAECaseTagging_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.displayAECaseTagging_CheckBox,
								getTestDataCellValue(scenarioName, "DisplayAECaseTagging"));
				}
					}
			
			if(getTestDataCellValue(scenarioName, "DisplayAESuggestedFAQs").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.displayAESuggestedFAQs_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.displayAESuggestedFAQs_CheckBox,
								getTestDataCellValue(scenarioName, "DisplayAESuggestedFAQs"));
				}
					}
			if(getTestDataCellValue(scenarioName, "IncludeCasesFromallWorkflowinLookup").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.includeCasesFromallWorkflowinLookup_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.includeCasesFromallWorkflowinLookup_CheckBox,
								getTestDataCellValue(scenarioName, "IncludeCasesFromallWorkflowinLookup"));
				}
					}
			if(getTestDataCellValue(scenarioName, "IncludeCasesFromAllWorkflowDuplicateSearch").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.includeCasesFromAllWorkflowDuplicateSearch_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.includeCasesFromAllWorkflowDuplicateSearch_CheckBox,
								getTestDataCellValue(scenarioName, "IncludeCasesFromAllWorkflowDuplicateSearch"));
				}
					}
			if(getTestDataCellValue(scenarioName, "AlwaysShowTwoPanelCaseformLayout").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.alwaysShowTwoPanelCaseformLayout_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.alwaysShowTwoPanelCaseformLayout_CheckBox,
								getTestDataCellValue(scenarioName, "AlwaysShowTwoPanelCaseformLayout"));
				}
					}
			if(getTestDataCellValue(scenarioName, "EnableAutoRanking").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.enableAutoRanking_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.enableAutoRanking_CheckBox,
								getTestDataCellValue(scenarioName, "EnableAutoRanking"));
				}
					}
			if(getTestDataCellValue(scenarioName, "PerformNLPOnE2BImport").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.performNLPOnE2BImport_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.performNLPOnE2BImport_CheckBox,
								getTestDataCellValue(scenarioName, "PerformNLPOnE2BImport"));
				}
					}
			if(getTestDataCellValue(scenarioName, "EnableANGEdit").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.enableANGEdit_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.enableANGEdit_CheckBox,
								getTestDataCellValue(scenarioName, "EnableANGEdit"));
				}
					}
		
			

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.caseManagement_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Case Management Section : 1", true);

			if(getTestDataCellValue(scenarioName, "DisableManualANGEdit").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.disableManualANGEdit_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.disableManualANGEdit_CheckBox,
								getTestDataCellValue(scenarioName, "DisableManualANGEdit"));
				}
					}
		
			if(getTestDataCellValue(scenarioName, "DisplayWorkflowStatusTree").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.displayWorkflowStatusTree_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.displayWorkflowStatusTree_CheckBox,
								getTestDataCellValue(scenarioName, "DisplayWorkflowStatusTree"));
				}
					}
		

			if(getTestDataCellValue(scenarioName, "EnableContactCaseReporter").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.enableContactCaseReporter_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.enableContactCaseReporter_CheckBox,
								getTestDataCellValue(scenarioName, "EnableContactCaseReporter"));
				}
					}
			if(getTestDataCellValue(scenarioName, "EnableSubmissionTracking").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.enableSubmissionTracking_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.enableSubmissionTracking_CheckBox,
								getTestDataCellValue(scenarioName, "EnableSubmissionTracking"));
				}
					}
			
		
			// CommonOperations.clickCheckBoxLeftOf(
			// AppParameters_CaseManagementPageObjects.allowManualSelectionofIMEDME_CheckBox,
			// getTestDataCellValue(scenarioName, "AllowManualSelectionofIMEDME"));
			
			if(getTestDataCellValue(scenarioName, "AllowAccesstoEnableSUSAR").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.allowAccesstoEnableSUSAR_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.allowAccesstoEnableSUSAR_CheckBox,
								getTestDataCellValue(scenarioName, "AllowAccesstoEnableSUSAR"));
				}
					}
			
			if(getTestDataCellValue(scenarioName, "AllowManualSelectionOfAssessRelationship").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.allowManualSelectionOfAssessRelationship_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.allowManualSelectionOfAssessRelationship_CheckBox,
								getTestDataCellValue(scenarioName, "AllowManualSelectionOfAssessRelationship"));
				}
					}
			if(getTestDataCellValue(scenarioName, "AllowManualSelectionofAESI").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.allowManualSelectionofAESI_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.allowManualSelectionofAESI_CheckBox,
								getTestDataCellValue(scenarioName, "AllowManualSelectionofAESI"));
				}
					}
			if(getTestDataCellValue(scenarioName, "AllowManualSelectionofIMEDME").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.allowManualSelectionofIMEDME_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.allowManualSelectionofIMEDME_CheckBox,
								getTestDataCellValue(scenarioName, "AllowManualSelectionofIMEDME"));
				}
					}
			if(getTestDataCellValue(scenarioName, "AllowManualSelectionofMedicallyConfirmed").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.allowManualSelectionofMedicallyConfirmed_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.allowManualSelectionofMedicallyConfirmed_CheckBox,
								getTestDataCellValue(scenarioName, "AllowManualSelectionofMedicallyConfirmed"));
				}
					}
			if(getTestDataCellValue(scenarioName, "AllowManualSelectionofIsAlwaysSeriousEvent").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.allowManualSelectionofIsAlwaysSeriousEvent_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.allowManualSelectionofIsAlwaysSeriousEvent_CheckBox,
								getTestDataCellValue(scenarioName, "AllowManualSelectionofIsAlwaysSeriousEvent"));
				}
					}

			if(getTestDataCellValue(scenarioName, "AllowManualSelectionofCaseSignificance").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.allowManualSelectionofCaseSignificance_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.allowManualSelectionofCaseSignificance_CheckBox,
								getTestDataCellValue(scenarioName, "AllowManualSelectionofCaseSignificance"));
				}
			}
			if(getTestDataCellValue(scenarioName, "AllowManualSelectionofCaseSignificance").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.allowManualSelectionofCaseSignificance_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.allowManualSelectionofCaseSignificance_CheckBox,
								getTestDataCellValue(scenarioName, "AllowManualSelectionofCaseSignificance"));
				}
			}
			if(getTestDataCellValue(scenarioName, "EnableTypeAheadForAutosuggestionFullDataEntryForm").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.enableTypeAheadForAutosuggestionFullDataEntryForm_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.enableTypeAheadForAutosuggestionFullDataEntryForm_CheckBox,
								getTestDataCellValue(scenarioName, "EnableTypeAheadForAutosuggestionFullDataEntryForm"));
				}
			}
			
			if(getTestDataCellValue(scenarioName, "AlertOnCaseAssignment").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.alertOnCaseAssignment_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.alertOnCaseAssignment_CheckBox,
								getTestDataCellValue(scenarioName, "AlertOnCaseAssignment"));
				}
			}
			if(getTestDataCellValue(scenarioName, "CreateContactfromEmailInbound").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.createContactfromEmailInbound_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.createContactfromEmailInbound_CheckBox,
								getTestDataCellValue(scenarioName, "CreateContactfromEmailInbound"));
				}
			}
			if(getTestDataCellValue(scenarioName, "AllowPPDLevelCoding").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.allowPPDLevelCoding_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.allowPPDLevelCoding_CheckBox,
								getTestDataCellValue(scenarioName, "AllowPPDLevelCoding"));
				}
			}
			if(getTestDataCellValue(scenarioName, "EnableAgeGroup").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.enableAgeGroup_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.enableAgeGroup_CheckBox,
								getTestDataCellValue(scenarioName, "EnableAgeGroup"));
				}
			}
			if(getTestDataCellValue(scenarioName, "EnableAutopsyDone").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.enableAutopsyDone_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.enableAutopsyDone_CheckBox,
								getTestDataCellValue(scenarioName, "EnableAutopsyDone"));
				}
			}
			if(getTestDataCellValue(scenarioName, "EnableFollowUpQeriesCaptcha").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.enableFollowUpQeriesCaptcha_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.enableFollowUpQeriesCaptcha_CheckBox,
								getTestDataCellValue(scenarioName, "EnableFollowUpQeriesCaptcha"));
				}
			}
			
			agSetValue(AppParameters_CaseManagementPageObjects.percentageOfSDDforCDD_TextBox,
					getTestDataCellValue(scenarioName, "PercentageOfSDDforCDD"));
			CommonOperations.clickRadioButtonUpdated(
					AppParameters_CaseManagementPageObjects.displaySupplementFieldsLike_Radio,
					getTestDataCellValue(scenarioName, "DisplaySupplementFieldsLike"));
			agSetValue(AppParameters_CaseManagementPageObjects.watermarkTextforReports_TextBox,
					getTestDataCellValue(scenarioName, "WatermarkTextforReports"));
			CommonOperations.clickRadioButtonUpdated(
					AppParameters_CaseManagementPageObjects.defaultValuesforEventSeriousnessCriteria_Radio,
					getTestDataCellValue(scenarioName, "DefaultValuesforEventSeriousnessCriteria"));
			CommonOperations.clickRadioButton(AppParameters_CaseManagementPageObjects.defaultDueDateforSWM_Radio,
					getTestDataCellValue(scenarioName, "DefaultDueDateforSWM"));
			agSetValue(AppParameters_CaseManagementPageObjects.closeCorrespondenceInDays_TextBox,
					getTestDataCellValue(scenarioName, "CloseCorrespondenceInDays"));

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.disableManualANGEdit_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Case Management Section : 2", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> Case Management >> Case Management Section : 2", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Labeling Details in Case
	 *             Management Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 15-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setLabelingDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			
			if(getTestDataCellValue(scenarioName, "AutoProductLabeling").equalsIgnoreCase("Yes")) {
				if(agIsVisible( CommonPageObjects.checkBoxCheckedRight(AppParameters_CaseManagementPageObjects.autoProductLabeling_CheckBox))==true)
					{
					
					}else{
						
						CommonOperations.clickCheckBoxRightOf(AppParameters_CaseManagementPageObjects.autoProductLabeling_CheckBox,
								getTestDataCellValue(scenarioName, "AutoProductLabeling"));
				}
			}
			if(getTestDataCellValue(scenarioName, "CreateDefaultIBLabelingRecordCT").equalsIgnoreCase("true")) {
				if(agIsVisible(AppParameters_CaseManagementPageObjects.IBLabellingrecordCheckedclinical)==true)
				{
				
				}else{
					
					agClick(AppParameters_CaseManagementPageObjects.IBLabellingrecordclinical);
			}
		}	
			if(getTestDataCellValue(scenarioName, "CreateDefaultCoreLabelingRecordCT").equalsIgnoreCase("true")) {
				if(agIsVisible(AppParameters_CaseManagementPageObjects.CoreLabellingrecordCheckedClinical)==true)
				{
				
				}else{
					
					agClick(AppParameters_CaseManagementPageObjects.CoreLabellingrecordclinical);
			}
		}		
			
			if(getTestDataCellValue(scenarioName, "CreateDefaultIBLabelingRecordPM").equalsIgnoreCase("true")) {
				if(agIsVisible(AppParameters_CaseManagementPageObjects.IBLabellingrecordCheckedclinicalPostMarket)==true)
				{
				
				}else{
					
					agClick(AppParameters_CaseManagementPageObjects.IBLabellingrecordclinicalPostMarket);
			}
		}	
			
			if(getTestDataCellValue(scenarioName, "CreateDefaultCoreLabelingRecordPM").equalsIgnoreCase("true")) {
				if(agIsVisible(AppParameters_CaseManagementPageObjects.CoreLabellingrecordCheckedPostMarket)==true)
				{
				
				}else{
					
					agClick(AppParameters_CaseManagementPageObjects.CoreLabellingrecordclinicalPostMarket);
			}
		}		

			CommonOperations.clickRadioButton(AppParameters_CaseManagementPageObjects.defaultLabeling_Radio,
					getTestDataCellValue(scenarioName, "DefaultLabeling"));
			
			CommonOperations.clickRadioButton(AppParameters_CaseManagementPageObjects.AutoLabellingRadio,
					getTestDataCellValue(scenarioName, "AutoLabeling"));

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.labeling_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Labeling Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Follow-up Questionnaires ID
	 *             Format Details in Case Management Tab under Application
	 *             Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 15-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setFollowUpQuestionnairesIDFormatDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_CaseManagementPageObjects.faqPrefix_TextBox,
					getTestDataCellValue(scenarioName, "FAQPrefix"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.caseNumber_DropDown,
					getTestDataCellValue(scenarioName, "CaseNumber"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.separator_DropDown,
					getTestDataCellValue(scenarioName, "Separator"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.resetSequenceBy_DropDown,
					getTestDataCellValue(scenarioName, "ResetSequenceBy"));

			agJavaScriptExecuctorScrollToElement(
					AppParameters_CaseManagementPageObjects.followUpQuestionnairesIDFormat_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Follow-up Questionnaires ID Format Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Web Service URL Details in
	 *             Case Management Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 15-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setWebServiceURLDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_CaseManagementPageObjects.contactWebService_TextBox,
					getTestDataCellValue(scenarioName, "ContactWebService"));
			agSetValue(AppParameters_CaseManagementPageObjects.contactWebServiceUserName_TextBox,
					getTestDataCellValue(scenarioName, "ContactWebServiceUserName"));
			agSetValue(AppParameters_CaseManagementPageObjects.contactWebServicePassword_TextBox,
					getTestDataCellValue(scenarioName, "ContactWebServicePassword"));
			if (getTestDataCellValue(scenarioName, "AuthenticationRequired").equalsIgnoreCase("true")) {
				
				agClick(AppParameters_CaseManagementPageObjects.authenticationRequired_CheckBox);
			}
			agSetValue(AppParameters_CaseManagementPageObjects.attachmentWebService_TextBox,
					getTestDataCellValue(scenarioName, "AttachmentWebService"));
			agSetValue(AppParameters_CaseManagementPageObjects.attachmentWebServiceUserName_TextBox,
					getTestDataCellValue(scenarioName, "AttachmentWebServiceUserName"));
			agSetValue(AppParameters_CaseManagementPageObjects.attachmentWebServicePassword_TextBox,
					getTestDataCellValue(scenarioName, "AttachmentWebServicePassword"));
			if (getTestDataCellValue(scenarioName, "AttachWebServAuthRequired").equalsIgnoreCase("true")) {
				agClick(AppParameters_CaseManagementPageObjects.attachWebServAuthRequired_CheckBox);
			}
			agSetValue(AppParameters_CaseManagementPageObjects.activityWebService_TextBox,
					getTestDataCellValue(scenarioName, "ActivityWebService"));
			agSetValue(AppParameters_CaseManagementPageObjects.activityWebServiceUserName_TextBox,
					getTestDataCellValue(scenarioName, "ActivityWebServiceUserName"));
			agSetValue(AppParameters_CaseManagementPageObjects.activityWebServicePassword_TextBox,
					getTestDataCellValue(scenarioName, "ActivityWebServicePassword"));
			if (getTestDataCellValue(scenarioName, "ActWebServAuthRequired").equalsIgnoreCase("true")) {
				agClick(AppParameters_CaseManagementPageObjects.actWebServAuthRequired_CheckBox);
			}

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.webServiceURLDetails_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Web Service URL Details Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Duplicate Search Field Details
	 *             in Case Management Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 16-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setDuplicateSearchFieldDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (getTestDataCellValue(scenarioName, "allDuplicateSearchField").equalsIgnoreCase("true")) {
				agClick((AppParameters_CaseManagementPageObjects.duplicateSearchField_Button).replace("%option%",
						"Add All"));
			} else {
				String fieldName = getTestDataCellValue(scenarioName, "DuplicateSearchField");
				String[] totalRecords = fieldName.split(",");
				for (int i = 0; i < totalRecords.length; i++) {
					agClick((AppParameters_CaseManagementPageObjects.duplicateSearchField_List).replace("%value%",
							totalRecords[i]));
					agClick((AppParameters_CaseManagementPageObjects.duplicateSearchField_Button).replace("%option%",
							"Add"));
				}
			}
			CommonOperations.setListDropDownValue(
					AppParameters_CaseManagementPageObjects.maxCriteriaForDuplicateBroadSearchReport_DropDown,
					getTestDataCellValue(scenarioName, "MaxCriteriaForDuplicateBroadSearchReport"));
			agSetValue(AppParameters_CaseManagementPageObjects.maxNumberOfRecordsforDuplicateSearch_TextBox,
					getTestDataCellValue(scenarioName, "MaxNumberOfRecordsforDuplicateSearch"));

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.duplicateSearchField_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Duplicate Search Field Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set AOSE Search Field Details in
	 *             Case Management Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 16-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setAOSESearchFieldDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "allAOSESearchField").equalsIgnoreCase("true")) {
			agClick((AppParameters_CaseManagementPageObjects.aoseSearchField_Button).replace("%option%", "Add All"));
		} else {
			String fieldName = getTestDataCellValue(scenarioName, "AOSESearchField");
			String[] totalRecords = fieldName.split(",");
			for (int i = 0; i < totalRecords.length; i++) {
				agClick((AppParameters_CaseManagementPageObjects.aoseSearchField_List).replace("%value%",
						totalRecords[i]));
				agClick((AppParameters_CaseManagementPageObjects.aoseSearchField_Button).replace("%option%", "Add"));
			}
		}

		agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.aoseSearchField_Label);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Application Parameters >> Case Management >> AOSE Search Field Section", true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Advanced Search Field Details
	 *             in Case Management Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 16-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setAdvancedSearchFieldDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (getTestDataCellValue(scenarioName, "allAdvancedSearchField").equalsIgnoreCase("true")) {
				agClick((AppParameters_CaseManagementPageObjects.advancedSearchField_Button).replace("%option%",
						"Add All"));
			} else {
				String fieldName = getTestDataCellValue(scenarioName, "AdvancedSearchField");
				String[] totalRecords = fieldName.split(",");
				for (int i = 0; i < totalRecords.length; i++) {
					agClick((AppParameters_CaseManagementPageObjects.advancedSearchField_List).replace("%value%",
							totalRecords[i]));
					agClick((AppParameters_CaseManagementPageObjects.advancedSearchField_Button).replace("%option%",
							"Add"));
				}
			}

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.advancedSearchField_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Advanced Search Field Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Relatedness Mapping
	 *             Maintenance Details in Case Management Tab under Application
	 *             Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 16-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setRelatednessMappingMaintenanceDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (getTestDataCellValue(scenarioName, "allCausality").equalsIgnoreCase("true")) {
				agClick((AppParameters_CaseManagementPageObjects.relatednessMappingMaintenance_Button)
						.replace("%option%", "Add All"));
			} else {
				String fieldName = getTestDataCellValue(scenarioName, "Causality");
				String[] totalRecords = fieldName.split(",");
				for (int i = 0; i < totalRecords.length; i++) {
					agClick((AppParameters_CaseManagementPageObjects.causality_List).replace("%value%",
							totalRecords[i]));
					agClick((AppParameters_CaseManagementPageObjects.relatednessMappingMaintenance_Button)
							.replace("%option%", "Add"));
				}
			}

			agJavaScriptExecuctorScrollToElement(
					AppParameters_CaseManagementPageObjects.relatednessMappingMaintenance_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Relatedness Mapping Maintenance Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Causality Source Derivation
	 *             Details in Case Management Tab under Application Parameters
	 *             Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 15-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setCausalitySourceDerivationDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (getTestDataCellValue(scenarioName, "boolCausalitySourceDerivation_Add").equalsIgnoreCase("true")) {
				agClick(AppParameters_CaseManagementPageObjects.causalitySourceDerivation_Add);
			}
			CommonOperations.setListDropDownValue(
					(AppParameters_CaseManagementPageObjects.reportType_DropDown).replace("%rowNO%",
							getTestDataCellValue(scenarioName, "CausalityRowNo")),
					getTestDataCellValue(scenarioName, "ReportType"));
			CommonOperations.setListDropDownValue(
					(AppParameters_CaseManagementPageObjects.studyType_DropDown).replace("%rowNO%",
							getTestDataCellValue(scenarioName, "CausalityRowNo")),
					getTestDataCellValue(scenarioName, "StudyType"));
			CommonOperations.setListDropDownValue(
					(AppParameters_CaseManagementPageObjects.reporterCausality_DropDown).replace("%rowNO%",
							getTestDataCellValue(scenarioName, "CausalityRowNo")),
					getTestDataCellValue(scenarioName, "ReporterCausality"));
			CommonOperations.setListDropDownValue(
					(AppParameters_CaseManagementPageObjects.companyCausality_DropDown).replace("%rowNO%",
							getTestDataCellValue(scenarioName, "CausalityRowNo")),
					getTestDataCellValue(scenarioName, "CompanyCausality"));
			CommonOperations.setListDropDownValue(
					(AppParameters_CaseManagementPageObjects.method_DropDown).replace("%rowNO%",
							getTestDataCellValue(scenarioName, "CausalityRowNo")),
					getTestDataCellValue(scenarioName, "Method"));

			agJavaScriptExecuctorScrollToElement(
					AppParameters_CaseManagementPageObjects.causalitySourceDerivation_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Causality Source Derivation Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Export - Department Details in
	 *             Case Management Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 15-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setExportDepartmentDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if(getTestDataCellValue(scenarioName, "SourceDocument").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.sourceDocument_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.sourceDocument_CheckBox,
								getTestDataCellValue(scenarioName, "SourceDocument"));
				}
			}
			
			if(getTestDataCellValue(scenarioName, "SupportDocument").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.supportDocument_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.supportDocument_CheckBox,
								getTestDataCellValue(scenarioName, "SupportDocument"));
				}
			}
			

			if(getTestDataCellValue(scenarioName, "SummarySheet").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.summarySheet_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.summarySheet_CheckBox,
								getTestDataCellValue(scenarioName, "SummarySheet"));
				}
			}
			if(getTestDataCellValue(scenarioName, "IncludeReceiptNumberWaterMark").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.includeReceiptNumberWaterMark_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.includeReceiptNumberWaterMark_CheckBox,
								getTestDataCellValue(scenarioName, "IncludeReceiptNumberWaterMark"));
				}
			}
			
			if(getTestDataCellValue(scenarioName, "IncludeLRNNumberWaterMark").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.includeLRNNumberWaterMark_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.includeLRNNumberWaterMark_CheckBox,
								getTestDataCellValue(scenarioName, "IncludeLRNNumberWaterMark"));
				}
			}
			if(getTestDataCellValue(scenarioName, "IncludeRegistrationCompletionDateWaterMark").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.includeRegistrationCompletionDateWaterMark_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.includeRegistrationCompletionDateWaterMark_CheckBox,
								getTestDataCellValue(scenarioName, "IncludeRegistrationCompletionDateWaterMark"));
				}
			}
			if(getTestDataCellValue(scenarioName, "IncludeDepartmentWaterMark").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.includeAerNoWaterMark_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.includeAerNoWaterMark_CheckBox,
								getTestDataCellValue(scenarioName, "IncludeDepartmentWaterMark"));
				}
			}
			
			if(getTestDataCellValue(scenarioName, "AllowReImportforFailedE2BCases").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.allowReImportforFailedE2BCases_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.allowReImportforFailedE2BCases_CheckBox,
								getTestDataCellValue(scenarioName, "AllowReImportforFailedE2BCases"));
				}
			}
			
			
			if(getTestDataCellValue(scenarioName, "FirstAlert").equalsIgnoreCase("Yes")) {
				if(agIsVisible( CommonPageObjects.checkBoxCheckedRight(AppParameters_CaseManagementPageObjects.firstAlert_CheckBox))==true)
					{
					
					}else{
						
						CommonOperations.clickCheckBoxRightOf(AppParameters_CaseManagementPageObjects.firstAlert_CheckBox,
								getTestDataCellValue(scenarioName, "FirstAlert"));
				}
			}
			
		
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.firstAlertInterval_DropDown,
					getTestDataCellValue(scenarioName, "FirstAlertInterval"));
			CommonOperations.clickCheckBoxRightOf(AppParameters_CaseManagementPageObjects.secondAlert_CheckBox,
					getTestDataCellValue(scenarioName, "SecondAlert"));
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.secondAlertInterval_DropDown,
					getTestDataCellValue(scenarioName, "SecondAlertInterval"));
			CommonOperations.clickCheckBoxRightOf(AppParameters_CaseManagementPageObjects.thirdAlert_CheckBox,
					getTestDataCellValue(scenarioName, "ThirdAlert"));
			
			
			CommonOperations.setListDropDownValue(AppParameters_CaseManagementPageObjects.thirdAlertInterval_DropDown,
					getTestDataCellValue(scenarioName, "ThirdAlertInterval"));

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.exportDepartment_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Export - Department Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Data Assessment Configurations
	 *             Details in Case Management Tab under Application Parameters
	 *             Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 15-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setDataAssessmentConfigurationsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			
			if(getTestDataCellValue(scenarioName, "FollowUpCaseAutoMerge").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.followUpCaseAutoMerge_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.followUpCaseAutoMerge_CheckBox,
								getTestDataCellValue(scenarioName, "FollowUpCaseAutoMerge"));
				}
			}
			
			
			CommonOperations.setListDropDownValue(
					AppParameters_CaseManagementPageObjects.followUpCaseAutoMergeRule_DropDown,
					getTestDataCellValue(scenarioName, "FollowUpCaseAutoMergeRule"));
			
			if(getTestDataCellValue(scenarioName, "Reconciliation").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.reconciliation_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.reconciliation_CheckBox,
								getTestDataCellValue(scenarioName, "Reconciliation"));
				}
			}
			
		

			agJavaScriptExecuctorScrollToElement(
					AppParameters_CaseManagementPageObjects.dataAssessmentConfigurations_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Data Assessment Configurations Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Data Extraction Folder
	 *             Location Details in Case Management Tab under Application
	 *             Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 15-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setDataExtractionFolderLocationDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_CaseManagementPageObjects.dataExtractionFolderLocation_TextBox,
					getTestDataCellValue(scenarioName, "DataExtractionFolderLocation"));
			agSetValue(AppParameters_CaseManagementPageObjects.dataExtractionLogo_TextBox,
					getTestDataCellValue(scenarioName, "DataExtractionLogo"));

			agJavaScriptExecuctorScrollToElement(
					AppParameters_CaseManagementPageObjects.dataExtractionFolderLocation_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Data Extraction Folder Location Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Receipt Numbering Format
	 *             Details in Case Management Tab under Application Parameters
	 *             Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadReceiptNumberingFormatDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			agClick(AppParameters_CaseManagementPageObjects.receiptPrefix_TextBox);
			String ReceiptPrefix = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.receiptPrefix_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptPrefix",
					ReceiptPrefix);

			String ReceiptDateFormat = agGetText(AppParameters_CaseManagementPageObjects.receiptDateFormat_DropDown);
			if (ReceiptDateFormat.contains("--Select--") || ReceiptDateFormat.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptDateFormat",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptDateFormat",
						ReceiptDateFormat);
			}
			String ReceiptSeparator = agGetText(AppParameters_CaseManagementPageObjects.receiptSeparator_DropDown);
			if (ReceiptSeparator.contains("--Select--") || ReceiptSeparator.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptSeparator",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptSeparator",
						ReceiptSeparator);
			}

			String ReceiptResetSequenceBy = agGetText(
					AppParameters_CaseManagementPageObjects.receiptResetSequenceBy_DropDown);
			if (ReceiptResetSequenceBy.contains("--Select--") || ReceiptResetSequenceBy.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ReceiptResetSequenceBy", "#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ReceiptResetSequenceBy", ReceiptResetSequenceBy);

			}

			String ReceiptPadding = agGetText(AppParameters_CaseManagementPageObjects.receiptPadding_DropDown);
			if (ReceiptPadding.contains("--Select--") || ReceiptPadding.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptPadding",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptPadding",
						ReceiptPadding);
			}
			String ReceiptFormatScripts = agGetText(
					AppParameters_CaseManagementPageObjects.receiptFormatScripts_DropDown);
			if (ReceiptFormatScripts.contains("--Select--") || ReceiptFormatScripts.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptFormatScripts",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptFormatScripts",
						ReceiptFormatScripts);
			}
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> Case Management >> Receipt Numbering Format Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> Case Management >> Receipt Numbering Format Section", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read LRN Numbering Format Details
	 *             in Case Management Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date :24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadLRNNumberingFormatDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			agClick(AppParameters_CaseManagementPageObjects.lrnPrefix_TextBox);
			String LRNPrefix = agGetAttribute("value", AppParameters_CaseManagementPageObjects.lrnPrefix_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNPrefix", LRNPrefix);

			String LRNDateFormat = agGetText(AppParameters_CaseManagementPageObjects.lrnDateFormat_DropDown);
			if (LRNDateFormat.contains("--Select--") || LRNDateFormat.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNDateFormat",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNDateFormat",
						LRNDateFormat);
			}
			String LRNDateFormatSequence = agGetText(
					AppParameters_CaseManagementPageObjects.lrnDateFormatSequence_DropDown);
			if (LRNDateFormatSequence.contains("--Select--") || LRNDateFormatSequence.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNDateFormatSequence",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNDateFormatSequence",
						LRNDateFormatSequence);
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.lrnCountry_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNCountry", "#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNCountry", "No");
			}
			String LRNCountrySequence = agGetText(AppParameters_CaseManagementPageObjects.lrnCountrySequence_DropDown);
			if (LRNCountrySequence.contains("--Select--") || LRNCountrySequence.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNCountrySequence",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNCountrySequence",
						LRNCountrySequence);
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.lrnReportType_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNReportType",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNReportType",
						"false");
			}

			String LRNReportTypeSequence = agGetText(
					AppParameters_CaseManagementPageObjects.lrnReportTypeSequence_DropDown);
			if (LRNReportTypeSequence.contains("--Select--") || LRNReportTypeSequence.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNReportTypeSequence",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNReportTypeSequence",
						LRNReportTypeSequence);
			}
			String LRNSeparator = agGetText(AppParameters_CaseManagementPageObjects.lrnSeparator_DropDown);
			if (LRNSeparator.contains("--Select--") || LRNSeparator.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNSeparator",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNSeparator",
						LRNSeparator);
			}
			String LRNResetSequenceBy = agGetText(AppParameters_CaseManagementPageObjects.lrnResetSequenceBy_DropDown);
			if (LRNResetSequenceBy.contains("--Select--") || LRNResetSequenceBy.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNResetSequenceBy",
						"#skip#");
			} else {

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNResetSequenceBy",
						LRNResetSequenceBy);
			}
			String LRNPadding = agGetText(AppParameters_CaseManagementPageObjects.lrnPadding_DropDown);
			if (LRNPadding.contains("--Select--") || LRNPadding.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNPadding", "#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LRNPadding",
						LRNPadding);
			}
			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.lrnNumberingFormat_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> Case Management >> LRN Numbering Format Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data  in Application Parameters >> Case Management >> LRN Numbering Format Section", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read AER Numbering Format Details
	 *             in Case Management Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 14-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadAERNumberingFormatDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			agClick(AppParameters_CaseManagementPageObjects.aerPrefix_TextBox);
			String AERPrefix = agGetAttribute("value", AppParameters_CaseManagementPageObjects.aerPrefix_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AERPrefix", AERPrefix);

			String AERPrefixSequence = agGetText(AppParameters_CaseManagementPageObjects.aerPrefixSequence_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AERPrefixSequence",
					AERPrefixSequence);

			String AERDateFormat = agGetText(AppParameters_CaseManagementPageObjects.aerDateFormat_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AERDateFormat",
					AERDateFormat);

			String AERDateFormatSequence = agGetText(
					AppParameters_CaseManagementPageObjects.aerDateFormatSequence_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AERDateFormatSequence",
					AERDateFormatSequence);

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.aerCountry_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AERCountry", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AERCountry", "No");
			}
			String AERCountrySequence = agGetText(AppParameters_CaseManagementPageObjects.aerCountrySequence_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AERCountrySequence",
					AERCountrySequence);

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.aerReportType_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AERReportType", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AERReportType", "No");
			}

			String AERReportTypeSequence = agGetText(
					AppParameters_CaseManagementPageObjects.aerReportTypeSequence_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AERReportTypeSequence",
					AERReportTypeSequence);

			String AERSeparator = agGetText(AppParameters_CaseManagementPageObjects.aerSeparator_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AERSeparator",
					AERSeparator);

			String AERResetSequenceBy = agGetText(AppParameters_CaseManagementPageObjects.aerResetSequenceBy_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AERResetSequenceBy",
					AERResetSequenceBy);

			agClick(AppParameters_CaseManagementPageObjects.aerStartAERVersionNoFrom_TextBox);
			String AERStartAERVersionNoFrom = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.aerStartAERVersionNoFrom_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AERStartAERVersionNoFrom",
					AERStartAERVersionNoFrom);

			String AERPadding = agGetText(AppParameters_CaseManagementPageObjects.aerPadding_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AERPadding", AERPadding);

			String AERFormatScripts = agGetText(AppParameters_CaseManagementPageObjects.aerFormatScripts_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AERFormatScripts",
					AERFormatScripts);

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.aerNumberingFormat_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data  in Application Parameters >> Case Management >> AER Numbering Format Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data  in Application Parameters >> Case Management >> AER Numbering Format Section", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Case Management Details in
	 *             Case Management Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar s
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadCaseManagementDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agClick(AppParameters_CaseManagementPageObjects.maxNOofCasesDayUser_TextBox);
			String MaxNOofCasesDayUser = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.maxNOofCasesDayUser_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "MaxNOofCasesDayUser",
					MaxNOofCasesDayUser);

			agClick(AppParameters_CaseManagementPageObjects.archiveSafetyCasesOlderThan_TextBox);
			String ArchiveSafetyCasesOlderThan = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.archiveSafetyCasesOlderThan_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"ArchiveSafetyCasesOlderThan", ArchiveSafetyCasesOlderThan);

			ArchiveSafetyCasesOlderThan = agGetText(
					AppParameters_CaseManagementPageObjects.archiveSafetyCasesOlderThan_DropDown);
			if (ArchiveSafetyCasesOlderThan.contains("--Select--") || ArchiveSafetyCasesOlderThan.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ArchiveSafetyCasesOlderThan", "#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ArchiveSafetyCasesOlderThan", ArchiveSafetyCasesOlderThan);
			}
			agClick(AppParameters_CaseManagementPageObjects.maxNumberOfRecordsAdvancedFlexibleSearch_TextBox);
			String MaxNumberOfRecordsAdvancedFlexibleSearch = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.maxNumberOfRecordsAdvancedFlexibleSearch_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"MaxNumberOfRecordsAdvancedFlexibleSearch", MaxNumberOfRecordsAdvancedFlexibleSearch);

			agClick(AppParameters_CaseManagementPageObjects.icsrLocalMessageNumberSchema_TextBox);
			String ICSRLocalMessageNumberSchema = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.icsrLocalMessageNumberSchema_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"ICSRLocalMessageNumberSchema", ICSRLocalMessageNumberSchema);

			agClick(AppParameters_CaseManagementPageObjects.sequenceLength_TextBox);
			String SequenceLength = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.sequenceLength_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SequenceLength",
					SequenceLength);

			agClick(AppParameters_CaseManagementPageObjects.noOfCasestoCopy_TextBox);
			String NoOfCasestoCopy = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.noOfCasestoCopy_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "NoOfCasestoCopy",
					NoOfCasestoCopy);

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.notifyARISgWhenFollowupCaseIsDisposed_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"NotifyARISgWhenFollowupCaseIsDisposed", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"NotifyARISgWhenFollowupCaseIsDisposed", "false");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.displayReporterContactFirstandLastNameDuplicateSearch_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DisplayReporterContactFirstandLastNameDuplicateSearch", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DisplayReporterContactFirstandLastNameDuplicateSearch", "false");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.autoDispositionOfE2BCases_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AutoDispositionOfE2BCases", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AutoDispositionOfE2BCases", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.includeAllAERVersionsfromARISg_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeAllAERVersionsfromARISg", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeAllAERVersionsfromARISg", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.migrateCorrespondenceRecordstoCCM_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"MigrateCorrespondenceRecordstoCCM", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"MigrateCorrespondenceRecordstoCCM", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.dontsendAECaseSummarySheettoArisg_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DontsendAECaseSummarySheettoArisg", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DontsendAECaseSummarySheettoArisg", "false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.displayAECaseTagging_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DisplayAECaseTagging",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DisplayAECaseTagging",
						"false");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.displayAESuggestedFAQs_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DisplayAESuggestedFAQs", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DisplayAESuggestedFAQs", "false");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.includeCasesFromallWorkflowinLookup_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeCasesFromallWorkflowinLookup", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeCasesFromallWorkflowinLookup", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.includeCasesFromAllWorkflowDuplicateSearch_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeCasesFromAllWorkflowDuplicateSearch", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeCasesFromAllWorkflowDuplicateSearch", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.alwaysShowTwoPanelCaseformLayout_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AlwaysShowTwoPanelCaseformLayout", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AlwaysShowTwoPanelCaseformLayout", "false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.enableAutoRanking_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableAutoRanking",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableAutoRanking",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.performNLPOnE2BImport_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "PerformNLPOnE2BImport",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "PerformNLPOnE2BImport",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.enableANGEdit_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableANGEdit",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableANGEdit",
						"false");
			}

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.caseManagement_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Case Management Section : 1", true);

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.disableManualANGEdit_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DisableManualANGEdit",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DisableManualANGEdit",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.displayWorkflowStatusTree_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DisplayWorkflowStatusTree", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DisplayWorkflowStatusTree", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.enableContactCaseReporter_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EnableContactCaseReporter", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EnableContactCaseReporter", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.enableSubmissionTracking_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EnableSubmissionTracking", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EnableSubmissionTracking", "false");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.allowManualSelectionofIMEDME_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofIMEDME", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofIMEDME", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.allowAccesstoEnableSUSAR_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowAccesstoEnableSUSAR", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowAccesstoEnableSUSAR", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.allowManualSelectionOfAssessRelationship_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionoffAssessRelationship", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofAssessRelationship", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.allowManualSelectionofAESI_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofAESI", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofAESI", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.allowManualSelectionofMedicallyConfirmed_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofMedicallyConfirmed", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectiofMedicallyConfirmed", "false");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.allowManualSelectionofIsAlwaysSeriousEvent_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionoffIsAlwaysSeriousEvent", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofIsAlwaysSeriousEvent", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.allowManualSelectionofCaseSignificance_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofCaseSignificance", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofCaseSignificance", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.enableTypeAheadForAutosuggestionFullDataEntryForm_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EnableTypeAheadForAutosuggestionFullDataEntryForm", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EnableTypeAheadForAutosuggestionFullDataEntryForm", "false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.alertOnCaseAssignment_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AlertOnCaseAssignment",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AlertOnCaseAssignment",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.createContactfromEmailInbound_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"CreateContactfromEmailInbound", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"CreateContactfromEmailInbound", "false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.allowPPDLevelCoding_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AllowPPDLevelCoding",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AllowPPDLevelCoding",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.enableAgeGroup_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableAgeGroup",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableAgeGroup",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.enableAutopsyDone_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableAutopsyDone",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableAutopsyDone",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.enableFollowUpQeriesCaptcha_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EnableFollowUpQeriesCaptcha", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EnableFollowUpQeriesCaptcha", "false");
			}
			agClick(AppParameters_CaseManagementPageObjects.percentageOfSDDforCDD_TextBox);
			String PercentageOfSDDforCDD = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.percentageOfSDDforCDD_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "PercentageOfSDDforCDD",
					PercentageOfSDDforCDD);

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.displaySupplementFieldsLike_Radio)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DisplaySupplementFieldsLike", "Context");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DisplaySupplementFieldsLike", "Tab");
			}
			agClick(AppParameters_CaseManagementPageObjects.watermarkTextforReports_TextBox);
			String WatermarkTextforReports = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.watermarkTextforReports_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "WatermarkTextforReports",
					WatermarkTextforReports);

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.defaultValuesforEventSeriousnessCriteria_Radio)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DefaultValuesforEventSeriousnessCriteria", "No Information");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DefaultValuesforEventSeriousnessCriteria", "No");
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.defaultDueDateforSWM_Radio)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DefaultDueDateforSWM",
						"Case Due Date");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DefaultDueDateforSWM",
						"Submission Due Date");
			}

			agClick(AppParameters_CaseManagementPageObjects.closeCorrespondenceInDays_TextBox);
			String CloseCorrespondenceInDays = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.closeCorrespondenceInDays_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CloseCorrespondenceInDays",
					CloseCorrespondenceInDays);

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.disableManualANGEdit_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Case Management Section : 2", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Labeling Details in Case
	 *             Management Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date :24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadLabelingDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		try {
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.defaultLabeling_Radio)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AutoProductLabeling",
						"Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AutoProductLabeling",
						"No");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.AutoLabellingRadio)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DefaultLabeling",
						"Unlabeled");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DefaultLabeling",
						"Blank");
			}
			
			if (agIsVisible(AppParameters_CaseManagementPageObjects.IBLabellingrecordCheckedclinical) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CreateDefaultIBLabelingRecordCT",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CreateDefaultIBLabelingRecordCT",
						"false");
			}
			
			if (agIsVisible(AppParameters_CaseManagementPageObjects.IBLabellingrecordCheckedclinicalPostMarket) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CreateDefaultIBLabelingRecordPM",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CreateDefaultIBLabelingRecordPM",
						"false");
			}

			if (agIsVisible(AppParameters_CaseManagementPageObjects.CoreLabellingrecordCheckedClinical) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CreateDefaultCoreLabelingRecordCT",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CreateDefaultCoreLabelingRecordCT",
						"false");
			}
			
			if (agIsVisible(AppParameters_CaseManagementPageObjects.CoreLabellingrecordCheckedPostMarket) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CreateDefaultCoreLabelingRecordPM",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CreateDefaultCoreLabelingRecordPM",
						"false");
			}
			
			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.labeling_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Labeling Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Follow-up Questionnaires ID
	 *             Format Details in Case Management Tab under Application
	 *             Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar s
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadFollowUpQuestionnairesIDFormatDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agClick(AppParameters_CaseManagementPageObjects.faqPrefix_TextBox);
			String FAQPrefix = agGetAttribute("value", AppParameters_CaseManagementPageObjects.faqPrefix_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "FAQPrefix", FAQPrefix);

			String CaseNumber = agGetText(AppParameters_CaseManagementPageObjects.caseNumber_DropDown);
			if (CaseNumber.contains("--Select--") || CaseNumber.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CaseNumber", "#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CaseNumber",
						CaseNumber);
			}
			String Separator = agGetText(AppParameters_CaseManagementPageObjects.separator_DropDown);
			if (Separator.contains("--Select--") || Separator.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Separator", "#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Separator", Separator);
			}
			String ResetSequenceBy = agGetText(AppParameters_CaseManagementPageObjects.resetSequenceBy_DropDown);
			if (ResetSequenceBy.contains("--Select--") || ResetSequenceBy.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ResetSequenceBy",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ResetSequenceBy",
						ResetSequenceBy);
			}
			agJavaScriptExecuctorScrollToElement(
					AppParameters_CaseManagementPageObjects.followUpQuestionnairesIDFormat_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Follow-up Questionnaires ID Format Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Web Service URL Details in
	 *             Case Management Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar s
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadWebServiceURLDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agClick(AppParameters_CaseManagementPageObjects.contactWebService_TextBox);
			String ContactWebService = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.contactWebService_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ContactWebService",
					ContactWebService);

			agClick(AppParameters_CaseManagementPageObjects.contactWebServiceUserName_TextBox);
			String ContactWebServiceUserName = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.contactWebServiceUserName_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ContactWebServiceUserName",
					ContactWebServiceUserName);

			agClick(AppParameters_CaseManagementPageObjects.contactWebServicePassword_TextBox);
			String ContactWebServicePassword = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.contactWebServiceUserName_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ContactWebServicePassword",
					ContactWebServicePassword);

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.authenticationRequired_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AuthenticationRequired", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AuthenticationRequired", "false");
			}

			agClick(AppParameters_CaseManagementPageObjects.attachmentWebService_TextBox);
			String AttachmentWebService = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.attachmentWebService_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AttachmentWebService",
					AttachmentWebService);
			agClick(AppParameters_CaseManagementPageObjects.attachmentWebServiceUserName_TextBox);
			String AttachmentWebServiceUserName = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.attachmentWebServiceUserName_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AttachmentWebService",
					AttachmentWebService);

			agClick(AppParameters_CaseManagementPageObjects.attachmentWebServicePassword_TextBox);
			String AttachmentWebServicePassword = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.attachmentWebServicePassword_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"AttachmentWebServicePassword", AttachmentWebServicePassword);

			if (getTestDataCellValue(scenarioName, "AttachWebServAuthRequired").equalsIgnoreCase("true")) {
				agClick(AppParameters_CaseManagementPageObjects.attachWebServAuthRequired_CheckBox);
			}
			agClick(AppParameters_CaseManagementPageObjects.activityWebService_TextBox);
			String ActivityWebService = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.activityWebService_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ActivityWebService",
					ActivityWebService);
			agClick(AppParameters_CaseManagementPageObjects.activityWebServiceUserName_TextBox);
			String ActivityWebServiceUserName = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.activityWebServiceUserName_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"ActivityWebServiceUserName", ActivityWebServiceUserName);
			agClick(AppParameters_CaseManagementPageObjects.activityWebServicePassword_TextBox);
			String ActivityWebServicePassword = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.activityWebServicePassword_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"ActivityWebServicePassword", ActivityWebServicePassword);

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.actWebServAuthRequired_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ActWebServAuthRequired", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ActWebServAuthRequired", "false");
			}
			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.webServiceURLDetails_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Web Service URL Details Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Duplicate Search Field
	 *             Details in Case Management Tab under Application Parameters
	 *             Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date :24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadDuplicateSearchFieldDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			String BusyAlertIfBusyFrom = agGetText(
					AppParameters_CaseManagementPageObjects.maxCriteriaForDuplicateBroadSearchReport_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"MaxCriteriaForDuplicateBroadSearchReport", BusyAlertIfBusyFrom);

			agClick(AppParameters_CaseManagementPageObjects.maxNumberOfRecordsforDuplicateSearch_TextBox);
			String ActivityWebServiceUserName = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.maxNumberOfRecordsforDuplicateSearch_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"MaxNumberOfRecordsforDuplicateSearch", ActivityWebServiceUserName);

			if (agIsVisible(AppParameters_CaseManagementPageObjects.DuplicateSearchField_SelectedList) == true) {

				List<WebElement> Value = agGetElementList(
						AppParameters_CaseManagementPageObjects.DuplicateSearchField_SelectedList);
				String delim = ",";
				StringBuilder sb = new StringBuilder();
				int i = 0;
				for (i = 0; i < Value.size(); i++) {
					sb.append(Value.get(i).getText());
					sb.append(delim);
				}

				String res = sb.toString();
				res = sb.deleteCharAt(sb.length() - 1).toString();
				System.out.println(res);

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DuplicateSearchField",
						res);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"allDuplicateSearchField", "#skip#");
			}

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.duplicateSearchField_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Entered Data in Application Parameters >> Case Management >> Duplicate Search Field Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read AOSE Search Field Details in
	 *             Case Management Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadAOSESearchFieldDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (agIsVisible(AppParameters_CaseManagementPageObjects.AeosSearchField_SelectedList) == true) {

				List<WebElement> Value = agGetElementList(
						AppParameters_CaseManagementPageObjects.AeosSearchField_SelectedList);
				String delim = ",";
				StringBuilder sb = new StringBuilder();
				int i = 0;
				for (i = 0; i < Value.size(); i++) {
					sb.append(Value.get(i).getText());
					sb.append(delim);
				}

				String res = sb.toString();
				res = sb.deleteCharAt(sb.length() - 1).toString();
				System.out.println(res);

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AOSESearchField", res);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "allAOSESearchField",
						"#skip#");
			}
			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.aoseSearchField_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Entered Data in Application Parameters >> Case Management >> AOSE Search Field Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Relatedness Mapping
	 *             Maintenance Details in Case Management Tab under Application
	 *             Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar s
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadRelatednessMappingMaintenanceDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (agIsVisible(AppParameters_CaseManagementPageObjects.RelatableMapping_SelectedList) == true) {

				List<WebElement> Value = agGetElementList(
						AppParameters_CaseManagementPageObjects.RelatableMapping_SelectedList);
				String delim = ",";
				StringBuilder sb = new StringBuilder();
				int i = 0;
				for (i = 0; i < Value.size(); i++) {
					sb.append(Value.get(i).getText());
					sb.append(delim);
				}

				String res = sb.toString();
				res = sb.deleteCharAt(sb.length() - 1).toString();
				System.out.println(res);

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Causality", res);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "allCausality",
						"#skip#");
			}
			agJavaScriptExecuctorScrollToElement(
					AppParameters_CaseManagementPageObjects.relatednessMappingMaintenance_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Relatedness Mapping Maintenance Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Causality Source Derivation
	 *             Details in Case Management Tab under Application Parameters
	 *             Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadCausalitySourceDerivationDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			if (agIsVisible(AppParameters_CaseManagementPageObjects.reportType_DropDown) == true) {
				String ReportType = agGetText(AppParameters_CaseManagementPageObjects.reportType_DropDown);
				if (ReportType.equalsIgnoreCase("--Select--")) {
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReportType",
							"#skip#");
				} else {
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReportType",
							ReportType);
				}
				String StudyType = agGetText(AppParameters_CaseManagementPageObjects.studyType_DropDown);
				if (StudyType.equalsIgnoreCase("--Select--")) {
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "StudyType",
							"#skip#");
				} else {
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "StudyType",
							StudyType);
				}
				String ReporterCausality = agGetText(
						AppParameters_CaseManagementPageObjects.reporterCausality_DropDown);
				if (ReporterCausality.equalsIgnoreCase("--Select--")) {
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReporterCausality",
							"#skip#");
				} else {
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReporterCausality",
							ReporterCausality);
				}

				String CompanyCausality = agGetText(AppParameters_CaseManagementPageObjects.companyCausality_DropDown);
				if (CompanyCausality.equalsIgnoreCase("--Select--")) {
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CompanyCausality",
							"#skip#");
				} else {
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CompanyCausality",
							CompanyCausality);
				}
				String Method = agGetText(AppParameters_CaseManagementPageObjects.method_DropDown);
				if (Method.equalsIgnoreCase("--Select--")) {
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Method", "#skip#");
				} else {
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Method", Method);
				}

				agJavaScriptExecuctorScrollToElement(
						AppParameters_CaseManagementPageObjects.causalitySourceDerivation_Label);
				Reports.ExtentReportLog("", Status.INFO,
						"Data Entered in Application Parameters >> Case Management >> Causality Source Derivation Section",
						true);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to read Export - Department Details
	 *             in Case Management Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadExportDepartmentDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.sourceDocument_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SourceDocument",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SourceDocument",
						"false");
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.supportDocument_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SupportDocument",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SupportDocument",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.summarySheet_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SummarySheet", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SummarySheet",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.includeReceiptNumberWaterMark_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeReceiptNumberWaterMark", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeReceiptNumberWaterMark", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.includeTotalPageWaterMark_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeTotalPageWaterMark", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeTotalPageWaterMark", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.includeLRNNumberWaterMark_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeLRNNumberWaterMark", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeLRNNumberWaterMark", "false");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.includeRegistrationCompletionDateWaterMark_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeRegistrationCompletionDateWaterMark", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeRegistrationCompletionDateWaterMark", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.includeDepartmentWaterMark_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeDepartmentWaterMark", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IncludeDepartmentWaterMark", "false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.includeAerNoWaterMark_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "IncludeAerNoWaterMark",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "IncludeAerNoWaterMark",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.allowReImportforFailedE2BCases_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowReImportforFailedE2BCases", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowReImportforFailedE2BCases", "false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.firstAlert_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "FirstAlert", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "FirstAlert", "false");
			}
			String FirstAlertInterval = agGetText(AppParameters_CaseManagementPageObjects.firstAlertInterval_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "FirstAlertInterval",
					FirstAlertInterval);

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.secondAlert_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SecondAlert", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SecondAlert", "false");
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.secondAlertInterval_DropDown)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SecondAlertInterval",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SecondAlertInterval",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.thirdAlert_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ThirdAlert", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ThirdAlert", "false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.thirdAlert_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ThirdAlertInterval",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ThirdAlertInterval",
						"false");
			}

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.exportDepartment_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Export - Department Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Data Assessment
	 *             Configurations Details in Case Management Tab under Application
	 *             Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadDataAssessmentConfigurationsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.followUpCaseAutoMerge_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "FollowUpCaseAutoMerge",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "FollowUpCaseAutoMerge",
						"false");
			}

			String FollowUpCaseAutoMergeRule = agGetText(
					AppParameters_CaseManagementPageObjects.followUpCaseAutoMergeRule_DropDown);
			if (FollowUpCaseAutoMergeRule.equalsIgnoreCase("--Select--")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"FollowUpCaseAutoMergeRule", "");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"FollowUpCaseAutoMergeRule", FollowUpCaseAutoMergeRule);
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CaseManagementPageObjects.reconciliation_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Reconciliation",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Reconciliation",
						"false");
			}

			agJavaScriptExecuctorScrollToElement(
					AppParameters_CaseManagementPageObjects.dataAssessmentConfigurations_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Data Assessment Configurations Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Data Extraction Folder
	 *             Location Details in Case Management Tab under Application
	 *             Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadDataExtractionFolderLocationDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			agClick(AppParameters_CaseManagementPageObjects.dataExtractionFolderLocation_TextBox);
			String DataExtractionFolderLocation = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.dataExtractionFolderLocation_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"DataExtractionFolderLocation", DataExtractionFolderLocation);

			agClick(AppParameters_CaseManagementPageObjects.dataExtractionLogo_TextBox);
			String DataExtractionLogo = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.dataExtractionLogo_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DataExtractionLogo",
					DataExtractionLogo);

			agJavaScriptExecuctorScrollToElement(
					AppParameters_CaseManagementPageObjects.dataExtractionFolderLocation_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Data Extraction Folder Location Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Other Medically Important
	 *             Condition Info Details in Case Management Tab under Application
	 *             Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadAdvancedSearchFieldDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (agIsVisible(AppParameters_CaseManagementPageObjects.AdvanceSEarchField_SelectedList) == true) {

				List<WebElement> Value = agGetElementList(
						AppParameters_CaseManagementPageObjects.AdvanceSEarchField_SelectedList);
				String delim = ",";
				StringBuilder sb = new StringBuilder();
				int i = 0;
				for (i = 0; i < Value.size(); i++) {
					sb.append(Value.get(i).getText());
					sb.append(delim);
				}

				String res = sb.toString();
				res = sb.deleteCharAt(sb.length() - 1).toString();
				System.out.println(res);

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AdvancedSearchField",
						res);
				agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.advancedSearchField_Label);
				Reports.ExtentReportLog("", Status.INFO,
						"Read Entered Data in Application Parameters >> Case Management >> Advanced Search Field Section",
						true);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Other Medically Important
	 *             Condition Info Details in Case Management Tab under Application
	 *             Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadOtherMedicallyImportantConditionInfoDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			agClick(AppParameters_CaseManagementPageObjects.otherMedicallyImportantConditionInfo_TextBox);
			String OtherMedicallyImportantConditionInfo = agGetAttribute("value",
					AppParameters_CaseManagementPageObjects.otherMedicallyImportantConditionInfo_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"OtherMedicallyImportantConditionInfo", OtherMedicallyImportantConditionInfo);
			agJavaScriptExecuctorScrollToElement(
					AppParameters_CaseManagementPageObjects.otherMedicallyImportantConditionInfo_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Other Medically Important Condition Info Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Other Medically Important
	 *             Condition Info Details in Case Management Tab under Application
	 *             Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 15-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setOtherMedicallyImportantConditionInfoDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_CaseManagementPageObjects.otherMedicallyImportantConditionInfo_TextBox,
					getTestDataCellValue(scenarioName, "OtherMedicallyImportantConditionInfo"));

			agJavaScriptExecuctorScrollToElement(
					AppParameters_CaseManagementPageObjects.otherMedicallyImportantConditionInfo_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Case Management >> Other Medically Important Condition Info Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set data in Case Management Tab
	 *             under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 17-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setAppParameters_CaseManagementTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >>Case Management Tab Started",
				true);
		setReceiptNumberingFormatDetails(scenarioName);
		setLRNNumberingFormatDetails(scenarioName);
		setAERNumberingFormatDetails(scenarioName);
		setCaseManagementDetails(scenarioName);
		setLabelingDetails(scenarioName);
		setFollowUpQuestionnairesIDFormatDetails(scenarioName);
		setWebServiceURLDetails(scenarioName);
		setDuplicateSearchFieldDetails(scenarioName);
		setAOSESearchFieldDetails(scenarioName);
		setAdvancedSearchFieldDetails(scenarioName);
		setRelatednessMappingMaintenanceDetails(scenarioName);
		setCausalitySourceDerivationDetails(scenarioName);
		setExportDepartmentDetails(scenarioName);
		setDataAssessmentConfigurationsDetails(scenarioName);
		setDataExtractionFolderLocationDetails(scenarioName);
		setOtherMedicallyImportantConditionInfoDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Application Parameters >>Case Management Tab Completed", true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read data in Case Management Tab
	 *             under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date :24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadAppParameters_CaseManagementTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO,
				"Read Data Entered in Application Parameters >>Case Management Tab Started", true);
		ReadReceiptNumberingFormatDetails(scenarioName);
		ReadLRNNumberingFormatDetails(scenarioName);
		ReadAERNumberingFormatDetails(scenarioName);
		ReadCaseManagementDetails(scenarioName);
		ReadLabelingDetails(scenarioName);
		ReadFollowUpQuestionnairesIDFormatDetails(scenarioName);
		ReadWebServiceURLDetails(scenarioName);
		ReadDuplicateSearchFieldDetails(scenarioName);
		ReadAOSESearchFieldDetails(scenarioName);
		ReadAdvancedSearchFieldDetails(scenarioName);
		ReadRelatednessMappingMaintenanceDetails(scenarioName);
		ReadCausalitySourceDerivationDetails(scenarioName);
		ReadExportDepartmentDetails(scenarioName);
		ReadDataAssessmentConfigurationsDetails(scenarioName);
		ReadDataExtractionFolderLocationDetails(scenarioName);
		ReadOtherMedicallyImportantConditionInfoDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO,
				"Read Data Entered in Application Parameters >>Case Management Tab Completed", true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read data in Case Management Tab
	 *             under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date :07-Jan-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void AppParameters_CaseManagementTabLabellingVerify() {
		SystemAdministrationOperations.systemAdministrationNavigations("applicationParameters");

		SystemAdministrationOperations.systemAdministrationNavigations("CaseManagement");
		agSetStepExecutionDelay("3000");
		agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.labeling_Label);
		if (agIsVisible(WorkFlowPageObjects
				.CheckedCheckBox(AppParameters_CaseManagementPageObjects.defaultLabeling_Radio)) == true) {
			Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read data in Case Management Tab
	 *             under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date :07-Jan-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void AppParameters_CaseManagementTabLabelling(String scenarioName) {
		agSetStepExecutionDelay("3000");
		if (scenarioName.equalsIgnoreCase("0")) {

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.labeling_Label);

			if (agIsVisible(AppParameters_CaseManagementPageObjects.DefaultSheetUnlabelled) == true) {
				Reports.ExtentReportLog("", Status.PASS,
						"As Expected",
						true);
			}

		} else {

			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.labeling_Label);
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.DefauktSheetBlank);
			CommonOperations.captureScreenShot(true);
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.Save);
			agWaitTillVisibilityOfElement(AppParameters_CaseManagementPageObjects.SaveOkBtn);
			agSetStepExecutionDelay("8000");
			Reports.ExtentReportLog("", Status.PASS, "As Expected"+
					"<br />"+ "Default Labeling for Datasheet: Blank Record", true);
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.SaveOkBtn);

		}

	}
		
	/**********************************************************************************************************
	 * @Objective: The below method is created to get RCT number format
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/		
	public static void getDateFormat(String scenarioName){
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		 String date = agGetText(AppParameters_CaseManagementPageObjects.getDateFormat);
	        System.out.println("Format::"+date);
	        XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className,scenarioName, "ReceiptDateFormat",date);
	    	String Prifix = agGetAttribute("value", AppParameters_CaseManagementPageObjects.getPrefix);
	        String separator = agGetText(AppParameters_CaseManagementPageObjects.getSeparator);
	        XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptSeparator",separator);
	        String Final = Prifix+separator;
	        XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptPrefix",Final);
	    	Reports.ExtentReportLog("", Status.INFO, "Prifix::"+Prifix+"::Separator::"+separator+"::Date Format::"+date, true);
	}
	
	
	
	
	
	
	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	

	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Read and Write components for Application Parameters - Case Management - Enable Manual Flag
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 10-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/		
	public static void EnableManualFlagIMEDMESUSARACCESSRELATIONSHIPAESI(String scenarioName){
		
		try {
			CaseManagementOperations.caseManagement_MenuNavigations("fullDataEntryForm");
			FDE_General.LSMVSetGeneralBasicDetails(scenarioName);
			FDE_Operations.tabNavigation("Product(s)");
			FDE_Products.setProductData(scenarioName);
			FDE_Operations.tabNavigation("Event(s)");
			FDE_Events.set_Events(scenarioName);
			FDE_Operations.LSMVSave(scenarioName, "FDE_General");
			
			SystemAdministrationOperations.systemAdministrationNavigations("applicationParameters");
			SystemAdministrationOperations.systemAdministrationNavigations("CaseManagement");
			
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.allowManualSelectionofIMEDME_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofIMEDME", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofIMEDME", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.allowAccesstoEnableSUSAR_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowAccesstoEnableSUSAR", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowAccesstoEnableSUSAR", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.allowManualSelectionOfAssessRelationship_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionOfAssessRelationship", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionOfAssessRelationship", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.allowManualSelectionofAESI_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofAESI", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofAESI", "false");
			}
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"AllowManualSelectionofIMEDME", "true");
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"AllowAccesstoEnableSUSAR", "true");
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"AllowManualSelectionOfAssessRelationship", "true");
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"AllowManualSelectionofAESI", "true");
			
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.noOfCasestoCopy_TextBox);
			if(getTestDataCellValue(scenarioName, "AllowAccesstoEnableSUSAR").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.allowAccesstoEnableSUSAR_CheckBox))==true)
					{
					
					}else{
						
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.allowAccesstoEnableSUSAR_CheckBox,
								getTestDataCellValue(scenarioName, "AllowAccesstoEnableSUSAR"));
				}
					}
			
			if(getTestDataCellValue(scenarioName, "AllowManualSelectionOfAssessRelationship").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.allowManualSelectionOfAssessRelationship_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.allowManualSelectionOfAssessRelationship_CheckBox,
								getTestDataCellValue(scenarioName, "AllowManualSelectionOfAssessRelationship"));
				}
					}
			if(getTestDataCellValue(scenarioName, "AllowManualSelectionofAESI").equalsIgnoreCase("true")) {
				if(agIsVisible(CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.allowManualSelectionofAESI_CheckBox))==true)
					{
				
					}else{

//					CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.allowManualSelectionofAESI_CheckBox,
//							getTestDataCellValue(scenarioName, "AllowManualSelectionofAESI"));
						agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.enableAESICheckBox);
					}
					}
			if(getTestDataCellValue(scenarioName, "AllowManualSelectionofIMEDME").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.allowManualSelectionofIMEDME_CheckBox))==true)
					{
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.allowManualSelectionofIMEDME_CheckBox,
								getTestDataCellValue(scenarioName, "AllowManualSelectionofIMEDME"));
					
				}
					}
			agSetStepExecutionDelay("3000");
			Reports.ExtentReportLog("", Status.INFO, "Enable Manual Flag:AESI,AccessRelationShip,SUSAR,IME/DME Checked", true);
			SystemAdministrationOperations.systemAdministrationNavigations("CallLog");
			SystemAdministrationOperations.systemAdministrationNavigations("CaseManagement");
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.Save);
			agWaitTillVisibilityOfElement(AppParameters_CaseManagementPageObjects.SaveOkBtn);
			agSetStepExecutionDelay("6000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.SaveOkBtn);
			
			
			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
			
			FDE_Operations.tabNavigation("Event(s)");
			FDE_Events.EnableFlagManualCheckBoxExist();
			FDE_Operations.tabNavigation("Labeling");
			FDE_Labelling.VerifyManualCheckBoxExistforSUSAR();
			FDE_Operations.tabNavigation("Causality");
			FDE_Causality.MaualCheckBoxExistAESIAccessRelationship();
			FDE_Operations.LSMVSave(scenarioName, "FDE_General");
			

			CaseManagementOperations.caseManagement_MenuNavigations("fullDataEntryForm");
			FDE_General.LSMVSetGeneralBasicDetails(scenarioName);
			FDE_Operations.tabNavigation("Product(s)");
			FDE_Products.setProductData(scenarioName);
			FDE_Operations.tabNavigation("Event(s)");
			FDE_Events.set_Events(scenarioName);
			FDE_Operations.LSMVSave(scenarioName, "FDE_General");
			
			
			
			SystemAdministrationOperations.systemAdministrationNavigations("applicationParameters");
			SystemAdministrationOperations.systemAdministrationNavigations("CaseManagement");
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.allowManualSelectionofIMEDME_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofIMEDME", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofIMEDME", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.allowAccesstoEnableSUSAR_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowAccesstoEnableSUSAR", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowAccesstoEnableSUSAR", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.allowManualSelectionOfAssessRelationship_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionOfAssessRelationship", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionOfAssessRelationship", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CaseManagementPageObjects.allowManualSelectionofAESI_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofAESI", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualSelectionofAESI", "false");
			}
			SystemAdministrationOperations.systemAdministrationNavigations("applicationParameters");
			SystemAdministrationOperations.systemAdministrationNavigations("CaseManagement");
			
			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.noOfCasestoCopy_TextBox);

			
			if(getTestDataCellValue(scenarioName, "AllowAccesstoEnableSUSAR").equalsIgnoreCase("true")) {
				
				agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.enableSUSARCheckBox);
					}
			
			if(getTestDataCellValue(scenarioName, "AllowManualSelectionOfAssessRelationship").equalsIgnoreCase("true")) {
				
				agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.enableAccessRelationshipCheckBox);
				
					}
			if(getTestDataCellValue(scenarioName, "AllowManualSelectionofAESI").equalsIgnoreCase("true")) {
				
//					CommonOperations.clickCheckBoxLeftOf(AppParameters_CaseManagementPageObjects.allowManualSelectionofAESI_CheckBox,
//							getTestDataCellValue(scenarioName, "AllowManualSelectionofAESI"));
						agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.enableAESICheckBox);
					}
			if(getTestDataCellValue(scenarioName, "AllowManualSelectionofIMEDME").equalsIgnoreCase("true")) {
				
				agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.enableIMECheckBox);
				
					}
			
			Reports.ExtentReportLog("", Status.INFO, "Enable Manual Flag:AESI,AccessRelationShip,SUSAR,IME/DME Un-Checked", true);
			

			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.Save);
			agWaitTillVisibilityOfElement(AppParameters_CaseManagementPageObjects.SaveOkBtn);
			agSetStepExecutionDelay("6000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.SaveOkBtn);
			
			
			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
			
			FDE_Operations.tabNavigation("Event(s)");
			FDE_Events.EnableFlagManualCheckBoxNotExist();
			FDE_Operations.tabNavigation("Labeling");
			FDE_Labelling.VerifyManualCheckBoxNotExistforSUSAR();
			FDE_Operations.tabNavigation("Causality");
			FDE_Causality.MaualCheckBoxNotExistAESIAccessRelationship();
			FDE_Operations.LSMVSave(scenarioName, "FDE_General");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "", true);
		}
	
	
	}
	
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify Autopsy Done Checkbox is selected under Case Mangement of Application Parametre.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :09-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyAppParameters_AutopsyDone_CaseManagementTabDetails(String scenarioName) {
		agSetStepExecutionDelay("3000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
		Reports.ExtentReportLog("", Status.INFO, "verify Autopsy Done Checkbox Selection in Application Parametre",
				true);
		if (agIsVisible(WorkFlowPageObjects
				.CheckedCheckBox(AppParameters_CaseManagementPageObjects.enableAutopsyDone_CheckBox)) == true) {
			Reports.ExtentReportLog("Autopsy Done Checkbox", Status.PASS, "Autopsy Done Checkbox is Selected", true);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableAutopsyDone",
					"true");
		} else {
			Reports.ExtentReportLog("Autopsy Done Checkbox", Status.PASS, "Autopsy Done Checkbox is not Selected", true);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableAutopsyDone",
					"false");
		}
			/*if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.enableAutopsyDone_CheckBox))==true)
				{
					Reports.ExtentReportLog("Autopsy Done Checkbox", Status.PASS, "Autopsy Done Checkbox is Selected", true);
				}else{
					Reports.ExtentReportLog("Autopsy Done Checkbox", Status.FAIL, "Autopsy Done Checkbox is not Selected", true);
			}*/
		
									
	}
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify Exempted Events Checkbox is selected under Case Mangement of Application Parametre.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :09-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyAppParameters_ExemptedEvents_CaseManagementTabDetails(String scenarioName) {
		agSetStepExecutionDelay("3000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
		
		Reports.ExtentReportLog("", Status.INFO, "verify Exempted Events Checkbox Selection in Application Parametre",
				true);
		if (agIsVisible(WorkFlowPageObjects
				.CheckedCheckBox(AppParameters_CaseManagementPageObjects.enableExemptedEvents_CheckBox)) == true) {
			Reports.ExtentReportLog("Exempted Events Checkbox", Status.PASS, "Exempted Events Checkbox is Selected", true);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableExemptedEvents",
					"true");
		} else {
			Reports.ExtentReportLog("Exempted Events Checkbox", Status.PASS, "Exempted Events Checkbox is not Selected", true);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableExemptedEvents",
					"false");
		}
			/*if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.enableExemptedEvents_CheckBox))==true)
				{
					Reports.ExtentReportLog("Exempted Events Checkbox", Status.PASS, "Exempted Events Checkbox is Selected", true);
				}else{
					Reports.ExtentReportLog("Exempted Events Checkbox", Status.FAIL, "Exempted Events Checkbox is not Selected", true);
			}*/
									
	}
	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify Anticipated Events Checkbox is selected under Case Mangement of Application Parametre.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :09-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyAppParameters_AnticipatedEvents_CaseManagementTabDetails(String scenarioName) {
		agSetStepExecutionDelay("3000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		
		agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
		Reports.ExtentReportLog("", Status.INFO, "verify Anticipated Events Checkbox Selection in Application Parametre",
				true);
		
		if (agIsVisible(WorkFlowPageObjects
				.CheckedCheckBox(AppParameters_CaseManagementPageObjects.enableAnticipatedEvents_CheckBox)) == true) {
			Reports.ExtentReportLog("Anticipated Events Checkbox", Status.PASS, "Anticipated Events Checkbox is Selected", true);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableAnticipatedEvents",
					"true");
		} else {
			Reports.ExtentReportLog("Anticipated Events Checkbox", Status.PASS, "Anticipated Events Checkbox is not Selected", true);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableAnticipatedEvents",
					"false");
		}	
			/*if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.enableAnticipatedEvents_CheckBox))==true)
				{
					Reports.ExtentReportLog("Anticipated Events Checkbox", Status.PASS, "Anticipated Events Checkbox is Selected", true);
				}else{
					Reports.ExtentReportLog("Anticipated Events Checkbox", Status.FAIL, "Anticipated Events Checkbox is not Selected", true);
			}*/
									
	}
	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify Event Medically Confirmed Checkbox is selected under Case Mangement of Application Parametre.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :09-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyAppParameters_EventMedicallyConfirmed_CaseManagementTabDetails(String scenarioName) {
		agSetStepExecutionDelay("3000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
		
		Reports.ExtentReportLog("", Status.INFO, "verify Event Medically Confirmed Checkbox Selection in Application Parametre",
				true);
		
		if (agIsVisible(WorkFlowPageObjects
				.CheckedCheckBox(AppParameters_CaseManagementPageObjects.enableEventMedicallyConfirmed_CheckBox)) == true) {
			Reports.ExtentReportLog("Event Medically Confirmed Checkbox", Status.PASS, "Event Medically Confirmed Checkbox is Selected", true);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableEventMedicallyConfirmed",
					"true");
		} else {
			Reports.ExtentReportLog("Event Medically Confirmed Checkbox", Status.PASS, "Event Medically Confirmed Checkbox is not Selected", true);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableEventMedicallyConfirmed",
					"false");
		}
			/*if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CaseManagementPageObjects.enableEventMedicallyConfirmed_CheckBox))==true)
				{
					Reports.ExtentReportLog("Event Medically Confirmed Checkbox", Status.PASS, "Event Medically Confirmed Checkbox is Selected", true);
				}else{
					Reports.ExtentReportLog("Event Medically Confirmed Checkbox", Status.FAIL, "Event Medically Confirmed Checkbox is not Selected", true);
			}*/
									
	}
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify Age Group Checkbox is selected under Case Mangement of Application Parametre.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :19-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyAppParameters_AgeGroup_CaseManagementTabDetails(String scenarioName) {
		//agSetStepExecutionDelay("3000");
		//agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
		Reports.ExtentReportLog("", Status.INFO, "verify Age Group Checkbox Selection in Application Parametre",
				true);
		if (agIsVisible(WorkFlowPageObjects
				.CheckedCheckBox(AppParameters_CaseManagementPageObjects.enableAgeGroup_CheckBox)) == true) {
			Reports.ExtentReportLog("Age Group Checkbox Selection", Status.PASS, "Age Group Checkbox is Selected", true);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableAgeGroup",
					"true");
			
		} else {
			Reports.ExtentReportLog("Age Group Checkbox Selection", Status.PASS, "Age Group Checkbox is not Selected", true);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableAgeGroup",
					"false");
		}
									
	}
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify Case Significance Checkbox is selected under Case Mangement of Application Parametre.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :19-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyAppParameters_caseSignificance_CaseManagementTabDetails(String scenarioName) {
		//agSetStepExecutionDelay("3000");
		//agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
		Reports.ExtentReportLog("", Status.INFO, "verify Case Significance Checkbox Selection in Application Parametre",
				true);
		if (agIsVisible(WorkFlowPageObjects
				.CheckedCheckBox(AppParameters_CaseManagementPageObjects.allowManualSelectionofCaseSignificance_CheckBox)) == true) {
			Reports.ExtentReportLog("Case Significance Checkbox Selection", Status.PASS, "Case Significance Checkbox is Selected", true);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AllowManualSelectionofCaseSignificance",
					"true");
		} else {
			Reports.ExtentReportLog("Case Significance Checkbox Selection", Status.PASS, "Case Significance Checkbox is not Selected", true);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AllowManualSelectionofCaseSignificance",
					"false");
		}
									
	}
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify Medically Confirmed Checkbox is selected under Case Mangement of Application Parametre.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :19-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyAppParameters_MedicallyConfirmedSelection_CaseManagementTabDetails(String scenarioName) {
		//agSetStepExecutionDelay("3000");
		//agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
		Reports.ExtentReportLog("", Status.INFO, "verify Medically Confirmed Checkbox Selection in Application Parametre",
				true);
		if (agIsVisible(WorkFlowPageObjects
				.CheckedCheckBox(AppParameters_CaseManagementPageObjects.allowManualSelectionofMedicallyConfirmed_CheckBox)) == true) {
			Reports.ExtentReportLog("Medically Confirmed Checkbox Selection", Status.PASS, "Medically Confirmed Checkbox is Selected", true);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AllowManualSelectionofMedicallyConfirmed",
					"true");
		} else {
			Reports.ExtentReportLog("Medically Confirmed Checkbox Selection", Status.PASS, "Medically Confirmed Checkbox is not Selected", true);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AllowManualSelectionofMedicallyConfirmed",
					"false");
		}
									
	}
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify Always Serious EventSelection Checkbox is selected under Case Mangement of Application Parametre.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :19-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyAppParameters_AlwaysSeriousEventSelection_CaseManagementTabDetails(String scenarioName) {
		//agSetStepExecutionDelay("3000");
		//agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
		Reports.ExtentReportLog("", Status.INFO, "verify Always Serious EventSelection Checkbox Selection in Application Parametre",
				true);
		if (agIsVisible(WorkFlowPageObjects
				.CheckedCheckBox(AppParameters_CaseManagementPageObjects.allowManualSelectionofIsAlwaysSeriousEvent_CheckBox)) == true) {
			Reports.ExtentReportLog("Always Serious Event Selection Checkbox", Status.PASS, "Always Serious Event Checkbox is Selected", true);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AllowManualSelectionofIsAlwaysSeriousEvent",
					"true");
		} else {
			Reports.ExtentReportLog("Always Serious Event Selection Checkbox", Status.PASS, "Always Serious Event Checkbox is not Selected", true);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AllowManualSelectionofIsAlwaysSeriousEvent",
					"false");
		}
									
	}
	
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify Auto Product Labeling Checkbox is selected under Case Mangement of Application Parametre.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :19-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyAppParam_AutoProductLabeling(String scenarioName) {
		//agSetStepExecutionDelay("3000");
		//agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.defaultDueDate_Label);
		Reports.ExtentReportLog("", Status.INFO, "verify Auto Product Labeling Checkbox Selection in Application Parametre",
				true);
		if (agIsVisible(WorkFlowPageObjects
				.CheckedCheckBox(AppParameters_CaseManagementPageObjects.autoProductLabeling_CheckBox)) == true) {
			
			Reports.ExtentReportLog("", Status.INFO, "Auto Product Labeling Checkbox is selected in Application Parametre",
					true);
			
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AutoProductLabeling",
					"True");
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Auto Product Labeling Checkbox is not selected in Application Parametre",
					true);
			
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AutoProductLabeling",
					"False");
		}
									
	}
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to check/uncheck Auto Product Labeling checkbox.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :19-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void update_AutoProductLabeling_selection() {
		//agSetStepExecutionDelay("3000");
		//agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		SystemAdministrationOperations.systemAdministrationNavigations("applicationParameters");
		SystemAdministrationOperations.systemAdministrationNavigations("CaseManagement");
		
		agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.defaultDueDate_Label);
		
		String checkBoxStatus = agGetAttribute("class", WorkFlowPageObjects
				.CheckedCheckBox2(AppParameters_CaseManagementPageObjects.autoProductLabeling_CheckBox));
		
		if (checkBoxStatus.contains("ui-state-active"))
		{
			agClick(WorkFlowPageObjects
					.CheckedCheckBox2(AppParameters_CaseManagementPageObjects.autoProductLabeling_CheckBox));
			
			
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.Save);
 			agWaitTillVisibilityOfElement(AppParameters_CaseManagementPageObjects.SaveOkBtn);
 			//agSetStepExecutionDelay("8000");
 			//agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.PASS, "Auto Product Labeling Checkbox Unchecked in Application Parametre",
					true);
 			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.SaveOkBtn);					

		}
		
		else 
		{
			agClick(WorkFlowPageObjects
					.CheckedCheckBox2(AppParameters_CaseManagementPageObjects.autoProductLabeling_CheckBox));
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.Save);
 			agWaitTillVisibilityOfElement(AppParameters_CaseManagementPageObjects.SaveOkBtn);
 			//agSetStepExecutionDelay("8000");
 			//agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			
			Reports.ExtentReportLog("", Status.PASS, "Auto Product Labeling Checkbox Checked in Application Parametre",
					true);
			
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.SaveOkBtn);	
		}

									
	}

}
