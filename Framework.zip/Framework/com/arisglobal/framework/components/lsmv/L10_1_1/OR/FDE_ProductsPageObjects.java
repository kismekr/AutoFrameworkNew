package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FDE_ProductsPageObjects {

	// Product Information
	public static String productsAdd_Button = "xpath#//label[text()='Product(s)']/following-sibling::span/a[text()='Add']";
	public static String productTextbox = "xpath#//label[contains(text(),'{0}')]/ancestor::span/input";
	public static String productRadio = "xpath#//label[contains(text(),'{0}')]/ancestor::div/span/span//label[contains(text(),'{@}')]/ancestor::p-radiobutton/div";
	public static String productDropdownSelect = "xpath#//label[contains(text(),'{0}')]/ancestor::span/p-dropdown/div[not(contains(@class,'agNfDropdown'))]";
	public static String productChkbox = "xpath#//label[contains(text(),'{0}')]/ancestor::span/ul/li/label[contains(text(),'{@}')]/ancestor::li/p-checkbox";
	public static String productDescriptionTextbox = "xpath#//label[contains(text(),'Product description')]/ancestor::span/p-autocomplete/span/input";
	public static String tabByName = "xpath#//label[contains(text(),'{0}')]/ancestor::div[contains(@class,'ui-panel-titlebar')]/following::div/div/p-tabview//a/span[@class='ui-tabview-title'][contains(text(),'{0}')]/ancestor::a[@role='tab']";
	public static String productEmbedTxtbox = "xpath#//label[contains(text(),'{0}')]/ancestor::span/span/input";
	public static String productEmdedDropdownSelect = "xpath#//label[contains(text(),'{0}')]/ancestor::span/span/p-dropdown/div[not(contains(@class,'agNfDropdown'))]";
	//public static String productDescriptionLookup = "xpath#(//label[contains(text(),'Product description')]/ancestor::div/span/a/img)[3]";
	public static String productDescriptionLookup = "xpath#//label[contains(text(),'Product description')]/ancestor::div/span/a[@class='agLookupLink']/img";
	
	public static String productDescription_Lookupfield = "xpath#//input[@id='adverseEventNew:drugPanelTable:productPanelDataTable:productCoded']";
	public static String blinded_link = "xpath#//label[text()='Product Information']/following-sibling::label[text()='[Blinded]']";
	public static String unBlinded_link = "xpath#//label[text()='Product Information']/following-sibling::label[text()='[Unblinded]']";
	public static String checkRadioButton_Value = "xpath#//label[contains(text(),'{0}')]/ancestor::div/span/span//label[contains(text(),'{@}')]/ancestor::p-radiobutton/div//span";
	public static String product_Navigations = "xpath#//div[@class='tabCarouselSty']/ul/li/a/span[contains(text(),'{0}')]";
	public static String addUnblindedProduct_Btn = "xpath#//button[text()='Add Unblinded Product']";
	public static String additionalDrugInfo_Textarea = "xpath#//textarea[@id='adverseEventNew:drugPanelTable:productPanelDataTable:additionalInfoCode']";
	public static String popUp_YesBtn = "xpath#//span[text()='Yes']/ancestor::button[@type='button']";
	// public static String product_Link =
	// "xpath#//div[@class='tabCarouselSty']/ul/li/a/span[contains(text(),'{0}')]";
	public static String product_Link = "xpath#//label[@class='blindLinkedText']/ancestor::div[contains(@class,'blindedLinkBlock')]/a[text()='{0}']";
	public static String blindedProductLink = "xpath#//div[contains(@class,'blindedLinkBlock')]/label[text()='Linked Blinded Product:']";
	public static String unblindedProductLink = "xpath#//div[contains(@class,'blindedLinkBlock')]/label[text()='Linked Unblinded Product(s):']";
	public static String confirmationPopup = "xpath#//p-confirmdialog//div//i/following-sibling::span";
	public static String popUp_Message = "xpath#//span[@class='ui-confirmdialog-message']";
	public static String product_DateTextbox = "xpath#//label[contains(text(),'{0}')]/ancestor::span/span/input";
	public static String PharmaceuticalTermID_TxtField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugTherapyDataTable:PharmaceuticalDoseFormTermId']";
	public static String setdropDownValue = "xpath#//ul[contains(@class,'ui-dropdown-items')]/child::li/div/span[contains(text(),'%s')]";
	public static String productCount_Visible = "xpath#//a[@class='mainTabTreeLink']/span[text()='[2]']";
	public static String prevNavigaterClick = "xpath#//a[@class='tabCarouselPrev evAttached']";
	public static String forwardNavigaterClick = "xpath#//div[@class='tabCarouselSty']/following::a[@class='tabCarouselNext evAttached']";
	public static String click_MultipleProducts = "xpath#//div[@class='tabCarouselSty']/ul/li/a/span[contains(text(),'%s')]";
	public static String getListOfProducts = "xpath#//div[@class='tabCarouselSty']/ul[@role='tablist']/li[contains(@class,'proTabNormalClass')]";

	// Product Information - FDA specific components
	public static String primary_CheckBx = "xpath#(//div/span/label[text()='Primary?']/following::div[contains(@class,'ui-chkbox-box')]/span)[1]";
	public static String classify_CheckBx = "xpath#(//div/span/label[text()='Classify?']/following::div[contains(@class,'ui-chkbox-box')]/span)[1]";

	public static String marketingAuthorizationHolderAsReported_TextBx = "xpath#//label[contains(text(),'Marketing Auth')]/following::input[contains(@id,'accountName')]";
	public static String marketingAuthorizationHolderAsCoded_TextBx = "xpath#//label[contains(text(),'Marketing Auth')]/following::input[contains(@id,'mahAsCoded')]";

	public static String marketingAuthHolderAsCoded_Lookup = "xpath#(//div/span/label[text()='Marketing Authorization Holder As Coded']/following::span/a/img)[1]";
	public static String accountNameLookUp_TextBx = "xpath#//label[text()='Account Name']/following-sibling::input";
	public static String domain_TextBx = "xpath#//label[text()='Domain']/following-sibling::input";
	public static String firmSiteFEINumber_TextBx = "xpath#//label[text()='Firm/Site FEI Number']/following-sibling::input";
	public static String searchLookUp_Button = "xpath#//div/button/span[text()='Search']";
	public static String okLookUp_Button = "xpath#(//td[@class='tblEditRow']//div/div/span[contains(@class,'ui-radio')])[1]";

	public static String internalDrugCode = "xpath#//div/span/label['Internal Drug Code']/following::input[contains(@id,'idN102CB113828')]";

	public static String clickMultipleProducts(String runTimeLabel) {
		String value = click_MultipleProducts.replace("%s", runTimeLabel);
		return value;
	}

	// Approval
	public static String approvalAddBtn = "xpath#//p-header/label[text()='Approval']/following-sibling::span/a[text()='Add']";
	public static String tradeBrandName_TextField = "xpath#//input[contains(@id,'adverseEventNew:drugPanelTable:drugApprovl:tradeName')]";
	public static String clickProductType_Dropdown = "xpath#//p-dropdown/div//input[@id='adverseEventNew:drugPanelTable:drugApprovl:productType:0']/parent::div/following-sibling::label";
	public static String mAHAsCoded_Lookup = "xpath#//p-autocomplete/span/input[@id='adverseEventNew:drugPanelTable:drugApprovl:mahAsCoded']/ancestor::div/span/a";
	public static String mAHAsCoded_Getvalue = "xpath#//input[contains(@id,'adverseEventNew:drugPanelTable:drugApprovl:mahAsCoded')]";
	public static String mAHAsReported_TextField = "xpath#//input[contains(@id,'adverseEventNew:drugPanelTable:drugApprovl:mahAsReported')]";
	public static String clickAuthorizationCountry_Dropdown = "xpath#//p-dropdown/div//input[@id='adverseEventNew:drugPanelTable:drugApprovl:approvalCoutry']/parent::div/following-sibling::label";
	public static String approvalNo_TextField = "xpath#//input[contains(@id,'adverseEventNew:drugPanelTable:drugApprovl:approvalNo')]";
	public static String clickApprovalType_Dropdown = "xpath#//p-dropdown/div//input[@id='adverseEventNew:drugPanelTable:drugApprovl:approvalType']/parent::div/following-sibling::label";
	public static String accountLookup_AccountNameTxtfield = "xpath#//input[@name='account']";
	public static String accountLookup_SearchBtn = "xpath#//button[contains(@class,'agOnEnterSearch')]/span";
	public static String accountLookup_OkBtn = "xpath#//div[contains(@class,'searchOkbtn')]/button/span[text()='OK']";
	public static String accountLookup_selectRadioBtn = "xpath#//td[text()='%s']/ancestor::tr/td/p-tableradiobutton/div//span";
	public static String AuthorizationNumber = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugApprovl:approvalNo']";
	public static String IdentificationNo = "xpath#//input[@id='adverseEventNew:drugPanelTable:productPanelDataTable:notifiedBodyIdentNo']";
	public static String ClickClassofDevice_dropDown = "xpath#//p-dropdown/div//input[@id='adverseEventNew:drugPanelTable:productPanelDataTable:deviceClass']/parent::div/following-sibling::label";
	public static String NotifiedBodyNo = "xpath#//label[text()='Notified Body Certificate No.']/following-sibling::input[contains(@id,'adverseEventNew:drugPanelTable:deviceInfoTable')]";
	public static String Years = "xpath#//label[text()='Years']/following-sibling::input[contains(@id,'adverseEventNew:drugPanelTable:deviceInfoTable')]";
	public static String Months = "xpath#//label[text()='Months']/following-sibling::input[contains(@id,'adverseEventNew:drugPanelTable:deviceInfoTable')]";
	public static String Click_DeviceCommericalDate_dropdown = "xpath#//p-dropdown/div//input[contains(@id,'adverseEventNew:drugPanelTable:deviceInfoTable')]/parent::div/following-sibling::label";
	public static String clickProductFlag_Dropdown = "xpath#//p-dropdown/div//input[@id='adverseEventNew:drugPanelTable:drugApprovl:productType']/parent::div/following-sibling::label";
	public static String mAHAscoded_lookUpGridView = "xpath#//p-autocomplete/span/input[@id='adverseEventNew:drugPanelTable:drugApprovl:mahAsCoded0']/ancestor::td/span/a";
	public static String Click_ProductFlag_DropDown = "xpath#//p-dropdown/div//input[contains(@id,'adverseEventNew:drugPanelTable:drugApprovl:productType')]/parent::div/following-sibling::label";
	public static String MDRSoftwareChkbox = "xpath#(//label[starts-with(normalize-space(text()),'Software')]/../descendant::div[contains(@class,'ui-chkbox-box')])[1]";
	public static String IVDRSoftwareChkbox = "xpath#(//label[starts-with(normalize-space(text()),'Software')]/../descendant::div[contains(@class,'ui-chkbox-box')])[2]";
	public static String SterliCOnditionsChkbox = "xpath#(//label[starts-with(normalize-space(text()),'Sterile Conditions')]/../descendant::div[contains(@class,'ui-chkbox-box')])[1]";
	public static String click_MultipleApproval = "xpath#//div[@class='tabCarouselSty']/ul/li/a/span[contains(text(),'Approval#1')]";

	// Ingredients#1
	public static String ingredientsAddBtn = "xpath#//p-header/label[text()='Ingredients']/following-sibling::span/a[text()='Add']";
	public static String activeSubstance_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugActiveSubsDataTable:idN102CB123004']";
	public static String substanceTermIDVerDateNum_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugActiveSubsDataTable:specifiedSubstanceDate']";
	public static String substanceSpecifiedSubstanceTermID_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugActiveSubsDataTable:specifiedSubstanceTermID']";
	public static String strengthNumber_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugActiveSubsDataTable:activeSubStrength']";
	public static String strengthNumberunit_Dropdown = "Strength (Number)";
	public static String clickStrengthNumberunit_Dropdown = "xpath#//p-dropdown/div//input[@id='adverseEventNew:drugPanelTable:drugActiveSubsDataTable:activeSubStrengthUnit-1018_focus']/parent::div/following-sibling::label";
	public static String click_Multipleingredients = "xpath#//div[@class='tabCarouselSty']/ul/li/a/span[contains(text(),'Ingredients#1')]";

	// Indication(s)
	public static String indicationAddBtn = "xpath#//p-header/label[text()='Indication(s)']/following-sibling::span/a[text()='Add']";
	public static String indicationTerm_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:indicationDataTable:idN108BE123004_input:0']";
	public static String indicationMedDRALLTCode_Lookup = "xpath#//p-autocomplete/span/input[@id='adverseEventNew:drugPanelTable:indicationDataTable:drugIndicationMeddraLltCode:0']/ancestor::td/span/a";
	public static String indicationMedDRALLTCode_Getvalue = "xpath#//input[@id='adverseEventNew:drugPanelTable:indicationDataTable:drugIndicationMeddraLltCode:0']";
	public static String indicationsMedDRAPTCode_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:indicationDataTable:drugIndicationMeddraPtCode:0']";
	public static String dictionaryCodingBrowser_SearchTxtfield = "xpath#//input[@placeholder='Enter your Search Term']";
	public static String dictionaryCodingBrowser_SearchBtn = "xpath#//button/span[text()='Search']";
	public static String dictionaryCodingBrowser_OkBtn = "xpath#//div[contains(@class,'searchOkbtn')]/button/span[text()='OK']";

	public static String IndicationMedraLookup = "xpath#//label[contains(text(),'Indication')]/ancestor::div[@class='ui-table-wrapper ng-star-inserted']//a[@class='agLookupLink']//img";

	// Therapies#1
	public static String therapyAddBtn = "xpath#//p-header/label[text()='Therapies']/following-sibling::span/a[text()='Add']";
	public static String unitDose_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugTherapyDataTable:idN10928122014']";
	public static String unitDose_dropdown = "Unit dose";
	public static String formStrength_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugTherapyDataTable:idN10928113724']";
	public static String formStrength_dropdown = "Form Strength";
	public static String frequency_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugTherapyDataTable:idN10946122022']";
	public static String frequencyTime_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugTherapyDataTable:idN10954122024']";
	public static String frequencyTime_dropdown = "Frequency Time";
	public static String dailydoseManual_CheckBx = "xpath#//div/span/label[text()='Daily Dose']/ancestor::div[contains(@class,'agFieldWithManual')]/div/label[text()='Manual']/parent::div/p-checkbox/div//span";
	public static String durationOfDrugAdministrationManual_CheckBx = "xpath#//div/span/label[text()='Duration of Drug Administration']/ancestor::div[contains(@class,'agFieldWithManual')]/following-sibling::div/label[text()='Manual']/parent::div//span";
	public static String dailyDose_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugTherapyDataTable:dailyDose']";
	public static String dailyDose_dropdown = "Daily Dose";
	public static String therapyStartDate = "Therapy Start date";
	public static String therapyEndDate = "Therapy End date";
	public static String durationOfDrugAdministration_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugTherapyDataTable:idN107CC1131591']";
	public static String durationOfDrugAdministration_Dropdown = "Duration of Drug Administration";
	public static String lotNumber_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugTherapyDataTable:idN10388131101']";
	public static String lotExpirationDate_DateField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugTherapyDataTable:DPN105F1_IB_131102:impcalinput']";
	public static String formOfAdmin_Dropdown = "Form of admin.";
	public static String pharmaceuticalDoseFormTermID_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugTherapyDataTable:PharmaceuticalDoseFormTermId']";
	public static String routeOfAdmin_Dropdown = "Route of admin.";
	public static String routeOfAdministrationTermIDVerDateNum_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugTherapyDataTable:routeAdminFormDate']";
	public static String pharmaceuticalDoseFormTermIDVerDateNum_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugTherapyDataTable:PharmaceuticalDoseFormDate']";
	public static String routeofAdministrationTermID_Dropdown = "Route of Administration TermID";
	public static String parentsRouteOfAdmin_Dropdown = "xpath#(//span[@class='agNfSfField']//p-dropdown/div[not(contains(@class,'agNfDropdown'))])[3]";
	public static String parentRouteOfAdministrationTermID_Dropdown = "Parent Route of Administration TermID";
	public static String parentRouteOfAdministrationTermIDVerDateNum_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugTherapyDataTable:parentRouteAdminFormDate']";
	public static String dosageText_TextField = "xpath#//textarea[@id='adverseEventNew:drugPanelTable:drugTherapyDataTable:idN10217113129']";
	public static String totaldose_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:productPanelDataTable:totalDose']";
	public static String totaldose_Dropdown = "Total dose";
	public static String clickparentsRouteOfAdmin = "xpath#//p-dropdown/div//input[@id='adverseEventNew:drugPanelTable:drugTherapyDataTable:parentRouteAdmin-1020_focus']/parent::div/following-sibling::label";
	public static String lotnumber_Dropdown = "Lot";
	public static String DurationOfDrugDD = "xpath#//label[text()='Duration of Drug Administration']/ancestor::span/span//label/span";
	public static String click_MultipleTherapies = "xpath#//div[@class='tabCarouselSty']/ul/li/a/span[contains(text(),'Therapies#1')]";

	// Additional Info Code

	public static String clickAdditionalInfoCodeDrpdwn = "xpath#//p-dropdown/div//input[contains(@id,'adverseEventNew:drugPanelTable:drugAdditionalList:0:drugAddInfo-9063_focus')]/parent::div/following-sibling::label";
	public static String additionalInfoAddBtn = "xpath#//p-header/label[text()='Additional Info Code']/following-sibling::span/a[text()='Add']";

	// Labels

	public static String additionalInfoCode_Label = "xpath#//div[contains(@class,'agTopBreadCrumbsHeader')]/ul/li/a[text()='Additional Info Code']";
	public static String therapis_Label = "xpath#//div[contains(@class,'agTopBreadCrumbsHeader')]/ul/li/a[text()='Therapies']";
	public static String approval_Label = "xpath#//div[contains(@class,'agTopBreadCrumbsHeader')]/ul/li/a[text()='Approval']";
	public static String indication_Label = "xpath#//div[contains(@class,'agTopBreadCrumbsHeader')]/ul/li/a[text()='Indication(s)']";
	public static String ingrideints_Label = "xpath#//div[contains(@class,'agTopBreadCrumbsHeader')]/ul/li/a[text()='Ingredients']";
	public static String productinfo_label = "xpath#//div[contains(@class,'agTopBreadCrumbsHeader')]/ul/li/a[text()='Product Information']";

	// Device
	public static String device_FullForm = "xpath#//p-header/label[contains(text(), 'Device')]//parent::p-header//parent::div/p-header/span/a[text()='Full Form']";
	public static String device_Label = "xpath#//label[contains(text(), 'Device')]";
	public static String deviceComponentNameFreeText_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:deviceComponentName']";
	public static String deviceComponentTermIDVersionDateNumber_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:deviceComponentTermIDversion']";
	public static String deviceComponentTermID_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:deviceComponentTermID']";
	public static String commonDeviceName_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:commonDeviceName']";
	public static String brandName_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:130833']";
	public static String productCode_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:proCode']";
	public static String UDI_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:deviceUDI']";
	public static String expirationDate_TextField = "xpath#//input[@id='adverseEventNew:devicetable:130824']";
	public static String modelNumber_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:130812']";
	public static String catalogNumber_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:130813']";
	public static String serialNumber_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:130814']";
	public static String dateImplanted_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:DPN10330_DP_130822:impcalinput']";
	public static String dateExplanted_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:DPN10330_DP_130821:impcalinput']";
	public static String deviceAge_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:130815']";
	public static String deviceAgeUnit_DropDown = "xpath#//select[contains(@name,'adverseEventNew:drugPanelTable:deviceInfoTable:1308160')]";
	public static String labeledSingleUseDevice_Radio = "Labeled Single Use Device";
	public static String deviceManufactureDate_TextField = "xpath#//input[@id='adverseEventNew:devicetable:130826']";
	public static String isThisaSingleUserDevicethatwasReprocessedandReused_Radio = "Is This a Single-Use Device that was Reprocessed and Reused";
	public static String reprocessorUnit_LookUp = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:reProcessorUnit']/following::img[contains(@src, 'Lookup_Selection.svg')][1]";
	public static String reprocessorUnit_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:reProcessorUnit']";
	public static String describeOther_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:130819']";
	public static String correctionRemovalReportingNumber_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:correctionRemovalReportingNum']";
	public static String locationWhereEventNotOccured_DropDown = "xpath#//select[contains(@name,'adverseEventNew:drugPanelTable:deviceInfoTable:1308480')]";
	public static String deviceUsedFor_Radio = "Device Used For";
	public static String eventLocationOther_TextArea = "xpath#//textarea[@id='adverseEventNew:drugPanelTable:deviceInfoTable:130849']";
	public static String deviceBatchLotNumber_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:deviceBatchLotnumber']";
	public static String malfunction_Radio = "Malfunction?";
	public static String operatorOfDevice_DropDown = "xpath#//select[contains(@name,'adverseEventNew:devicetable:1308270')]";
	public static String productReturnDate_TextField = "xpath#//input[@id='adverseEventNew:devicetable:130825']";
	public static String wasThisDeviceServicedbyThirdParty_Radio = "Was this device serviced by a third party?";
	public static String productAvailableForEvaluation_Radio = "Product Available For Evaluation?";
	public static String deviceEvaluatedByManufacturer_Radio = "Device Evaluated By Manufacturer";
	public static String reasonWhyDeviceWasNotEvaluated_DropDown = "xpath#//select[contains(@name,'adverseEventNew:drugPanelTable:deviceInfoTable:reasonEvaluationNotProvided0')]";
	public static String reportSenttoManufacturerDate_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:reportSentManufDate']";
	public static String userFacility_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:userDeviceFacility']";
	public static String userFacility_LookUpIcon = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:userDeviceFacility']/following::img[contains(@src, 'Lookup_Selection.svg')][1]";
	public static String importer_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:userImporter']";
	public static String importer_LookUpIcon = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:userImporter']/following::img[contains(@src, 'Lookup_Selection.svg')][1]";
	public static String reportSenttoManufacturer_Radio = "Report Sent To Manufacturer? (If Yes, Enter Date)";
	public static String reportSenttoFda_Radio = "Report Sent to FDA?(if yes, enter date)";
	public static String reportSenttoFdaDate_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:reportSentFdaDate']";
	public static String userFacilityImportReportNumber_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:userFacilityOrImporter']";
	public static String mfr_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:mfrNumber']";
	public static String usageOfDevice_InitialUse_Radio = "Initial Use";
	public static String usageOfDevice_Other_Radio = "Other";
	public static String usageOfDevice_Problemnotedprioruse_Radio = "Problem noted prior use";
	public static String usageOfDevice_Reserviced_Radio = "Re-serviced/refurbished/fully refurbished";
	public static String usageOfDevice_ReusableMedicaldevice_Radio = "Reuse of a reusable medical device";
	public static String usageOfDevice_SingleUseMedicaldevice_Radio = "Reuse of a single use Medical device";
	public static String usageOfDevice_Unknown_Radio = "Unknown";
	public static String deviceClose = "xpath#(//span[text()='Device']//following::a[contains(@class,'titlebar-icon ui-dialog-titlebar-close')])[1]";
	public static String unknownRadio = "xpath#(//label[text()='Usage of Device']//following::label[text()='Unknown']/parent::*/descendant::label[text()='Unknown']/preceding-sibling::div/descendant::span[contains(@class,'ui-radiobutton-icon')])[1]";

	// Device manufacturer

	public static String deviceManufacturer_Div = "xpath#//label[contains(text(), 'Device manufacturer')]";
	public static String deviceManufacturer_Label = "Device manufacturer";

	public static String manufacturerAsReported_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:manufacturerAsReported:%rowNo%']";
	public static String manufacturerAsCoded_Lookup = "xpath#//input[@id= 'adverseEventNew:drugPanelTable:deviceInfoTable:ManufacturerAsCoded%rowNo%']/ancestor::td/descendant::img[contains(@src, 'Lookup_Selection.svg')]";
	public static String manufacturerAsCoded_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:ManufacturerAsCoded%rowNo%']";
	public static String manufacturerAddress_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:ManufacturerAddress:%rowNo%']";
	public static String city_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:City:%rowNo%']";
	public static String state_TextField = "xpath#//input[@id='adverseEventNew:drugPanelTable:deviceInfoTable:State:%rowNo%']";
	public static String country_DropDown = "xpath#//select[contains(@name,'adverseEventNew:drugPanelTable:deviceInfoTable:Country:%rowNo%')]";
	public static String closeDevicePopUp = "xpath#//span[text()='Device']//parent::div/a[@role='button']";
	// Device Problem Evaluation

	public static String deviceProblemEvaluation_Div = "xpath#//label[contains(text(), 'Device Problem Evaluation')]";
	public static String deviceProblemEvaluation_Label = "Device Problem Evaluation";
	public static String evaluationType_DropDown = "xpath#//select[contains(@name,'adverseEventNew:deviceProbmEvaluationtable:evaluationType:%rowNo%')]";
	public static String evaluationValue_DropDown = "xpath#//select[contains(@name,'adverseEventNew:deviceProbmEvaluationtable:evaluationValue:%rowNo%')]";

	// Product lookup

	public static String productNameTextbox = "xpath#//label[contains(text(),'Product Name')]/ancestor::div/input[@type='text']";
	public static String searchButton = "xpath#//span[contains(text(),'Search')]/ancestor::button";
	public static String okButton = "xpath#//button[@id='productLookupForm:bottomOkButton']";
	public static String cancelButton = "xpath#//button[@id='productLookupForm:bottomCancelButton']";
	public static String LibStudyFirstProductChkbox = "xpath#//tr[@data-ri='0']/td/div[@class='ui-chkbox ui-widget']";
	public static String prodLibOkButton = "xpath#//div[contains(@class,'agSearchprodcutTable')]//div/button/span[text()='OK']";
	public static String prodLibCancelButton = "xpath#//button[@label='Cancel']";
	public static String checkFirstProdInProdLib = "xpath#//p-table[@class='agcommonTblStyle proLibTblDialog']//tbody/tr[1]/td/p-tableradiobutton";
	public static String level1ProductTextbox = "xpath#//label[contains(text(),'{0}')]/ancestor::div/input[@type='text']";
	public static String productLibray_RadioBtn = "xpath#//label[text()='Product Library']/ancestor::p-radiobutton/div/child::div/span";
	public static String indication_Popup = "xpath#//span[contains(@class,'ui-dialog-title')][contains(text(),'Indications')]";
	// public static String indication_Popup =
	// "xpath#//span[contains(@class,'ui-dialog-title')][contains(text(),'INDICATIONS')]";
	public static String indicationPopup_CloseIcon = "xpath#//span[contains(@class,'ui-dialog-title')][contains(text(),'Indications')]/following-sibling::a";
	// public static String indicationPopup_CloseIcon =
	// "xpath#//span[contains(@class,'ui-dialog-title')][contains(text(),'INDICATIONS')]/following-sibling::a";
	public static String listedness_Popup = "xpath#//span[@class='ui-confirmdialog-message'][contains(text(),'recalculated')]";
	public static String listedness_PopupYesBtn = "xpath#//button[@type='button']//span[text()='Yes']";

	public static String recalculationPopupConfirmation = "xpath#//p-dialog[contains(@class,'agProductRecodingDialog')]/div[@role='dialog']/div/span[text()='Confirmation']";

	public static String ProductLookUpSearchBtn = "xpath#//span[contains(text(),'Search')]/ancestor::button";
	public static String AddBtnProduct = "xpath#//label[text()='Product(s)']/following-sibling::span/a[text()='Add']";

	public static String prodLibproductNameTextbox = "Product Name";

	// WHO DD CODE
	public static String whoDDCodeLookup = "xpath#//label[contains(text(),'WHO DD Code')]/ancestor::div/span/a/img";
	public static String whoDDCodeTextBox = "xpath#//input[@title='WHODD Code']";
	public static String whoDDCodeSearchBtn = "xpath#//span[contains(@onclick,'performWhoddPopupAdvSearchRK')]";
	public static String whoDDCodeCheckFirstProd = "xpath#//div[@id='targetPanelForWhoddLookupGrid']/div[@class='lsmv-grid-row']/span";
//	public static String whoDDCodeCheckFirstProd="xpath#//p-table[@class='agSearchprodcutTable agwhoddTbl agcommonTblStyle ng-star-inserted']//tbody/tr[1]/td/p-tableradiobutton";
	public static String whoDDCodeSelectBtn = "xpath#//span[@id='selecctBtnId']";
	public static String whoDDRadioBtn = "xpath#//label[text()='WHO DD']/ancestor::p-radiobutton/div/child::div/span";
	public static String whoDDCode_TextBox = "WHO DD Code";
	public static String whoDDCheckBox = "xpath#//p-table[@class='agSearchprodcutTable agwhoddTbl agcommonTblStyle ng-star-inserted']//tbody/tr[1]/td/p-tableradiobutton";
	public static String whoDDOKBtn = "xpath#//div[contains(@class,'ng-star-inserted')]//div/button/span[text()='OK']";

	public static String level1ProductTextbox(String label) {
		String value = level1ProductTextbox.replace("{0}", label);
		return value;

	}

	public static String ProductDescriptionTextBox = "xpath#//input[@id='adverseEventNew:drugPanelTable:productPanelDataTable::preferedProductDescription']";
	public static String productCharacterizationDrpdwn = "Product Characterization";
	public static String prductNameAsReportedTxtbox = "Product Name as Reported";
	public static String prefferedProductDescriptionTxtbox = "Preferred Product Description";
	public static String WHODDcodeTxtbox = "WHODD Code";
	public static String countryObtainedDrpdwn = "Country Obtained";
	public static String medicinalProductIdentifierTxtbox = "Medicinal Product Identifier (MPID)";
	public static String MPIDverNumTxtbox = "MPID Version Date / Number";
	public static String PhPIDTxtbox = "PhPID";
	public static String PhPIDverDateNumberTxtbox = "PhPID Version Date / Number";
	public static String cumulativeDose = "Cumulative dose to first Reaction";
	public static String gestationPeriod = "Gestation Period at time of Exposure";
	public static String actionTakenWithDrug = "Action Taken With Drug";
	public static String inventedNameTxtbox = "Invented name";
	public static String scientificNameTxtbox = "Scientific name";
	public static String trademarkNameTxtbox = "Trademark name";
	public static String strengthNameTxtbox = "Strength name";
	public static String formNameTxtbox = "Form name";
	public static String containerNameTxtbox = "Container name";
	public static String deviceNameTxtbox = "Device name";
	public static String intendedUseNameTxtbox = "Intended use name";
	public static String codingClassDrpdwn = "Coding Class";
	public static String productFlag = "Product Flag";
	public static String productType = "Product Type";
	public static String productTypeOTC = "OTC";
	public static String productTypeCOMPOUNDED = "COMPOUNDED?";
	public static String productTypeGeneric = "Generic";
	public static String productTypeBiosimilar = "Biosimilar";
	public static String NDCNumber = "NDC Number";
	public static String studyProductType = "Study Product Type";
	public static String companyProductRadio = "Company Product";
	public static String productBlindedRadio = "Product Blinded?";
	public static String lackOfEffectRadioBtn = "Lack Of Effect";
	public static String priorUseRadioBtn = "Prior use";
	public static String toleratedRadioBtn = "Tolerated";
	public static String preferredWHODDdecode_Txtfield = "Preferred WHO DD decode (B.4.k.2.1) ";

	public static String Implantable = "Implantable";
	public static String ActiveDevice = "Active Device";

	public static String Intendedtomedicinalproduct = "Intended to administer and/or remove a medicinal product";
	public static String Sterileconditions = "Sterile conditions";
	public static String Measuringfunction = "Measuring function";

	public static String Reusablesurgicalinstruments = "Reusable surgical instruments";
	public static String Software = "Reusable surgical instruments";
	public static String Procedurepacks = "Procedure packs";

	public static String Custommade = "Custom-made";
	public static String Nonmedicalpurpose = "Non-medical purpose";
	public static String Systems = "Systems";
	public static String Selftesting = "Self-testing";
	public static String NearPatienttesting = "Near-Patient testing";

	public static String Professionaltesting = "Professional testing";
	public static String CompanionDiagnostic = "Companion Diagnostic";
	public static String Reagent = "Reagent";
	public static String Instrument = "Instrument";
	public static String Devicemarketedbefore = "Device marketed before MDD/AIMDD/IVDD";

	public static String ProductDropdown = "xpath#//select[@name='adverseEventNew:drugPanelTable:productPanelDataTable:A1-1013_focus0.9655969210202142']";

	// public static String clickNFbutton =
	// "xpath#//label[text()='%s']//parent::span//parent::div//a[@class='agNfLink']";
	public static String clickNFbutton = "xpath#//label[contains(text(),'%s')]//parent::span//parent::div//a[@class='agNfLink']";
	public static String productNFDropdownSelect = "xpath#//label[contains(text(),'{0}')]/ancestor::span/p-dropdown/div[(contains(@class,'agNfDropdown'))]";

	public static String FrequencyTimeDD = "xpath#//label[text()='Frequency Time']/parent::span//p-dropdown//label/span";
	// Approval

	public static String productNavigation_Icon = "xpath#//a[@class='tabCarouselNext evAttached']";

	public static String productType_Dropdown = "Company Product";

	public static String productClick = "xpath#//li[contains(@class,'ui-state-default ui-corner-top fdeMultiTab113_{0}')]//span[contains(text(),'%s')]";
	public static String terapieClick = "xpath#//li[contains(@class,'ui-state-default ui-corner-top fdeMultiPanel930_{0}')]//span[contains(text(),'%s')]";
	public static String indicationScroll = "xpath#//label[contains(text(),'Indication(s)')]";
	public static String ProductFlagDDValue = "xpath#(//label[contains(text(),'Product Flag')])[1]/ancestor::span/p-dropdown/div[not(contains(@class,'agNfDropdown'))]";

	public static String PhPID_Txtbox = "xpath#//input[@id='adverseEventNew:drugPanelTable:productPanelDataTable:drugIndPhpid']";
	public static String PhPIDverDateNumber_Txtbox = "xpath#//input[@id='adverseEventNew:drugPanelTable:productPanelDataTable:drugIndPhpidDate-123011']";

	// Therapies
	public static String labelname = "xpath#//label[text()='%label%']";
	public static String formofAdminCodelist = "[805]";
	public static String routeofAdminCodelist = "[1020]";
	public static String getCodelist = "xpath#//label[text()='%label%']/ancestor::span/p-dropdown/preceding::label[contains(text(),'{codelist}')]";
	public static String routeofAdministrationTermID = "xpath#//input[@id='adverseEventNew:drugPanelTable:drugTherapyDataTable:routeAdminFormTermId']";

	// code window
	public static String suspectProductCodedlist = "xpath#//span[contains(@class,'suspectProductCoded')]";
	public static String suspectProductNotCodedlist = "xpath#//span[contains(@class,'suspectProductNotCoded')]";
	public static String indicationLabel = "xpath#//label[text()='Indication(s)']";
	public static String indicationtab = "xpath#//a[text()='Indication(s)']";
	public static String therapiestab = "xpath#//a[text()='Therapies']";
	public static String getListOfIndicationTerms = "xpath#//label[text()='Indication Term']//following::tbody/tr/td[2]/span[@class='agNfField']/input[contains(@id,'indicationDataTable:idN108BE123004_input:')]";
	public static String getIndicationsTerms = "xpath#//label[text()='Indication Term']//following::tbody/tr/td[2]/span[@class='agNfField']/input[contains(@id,'indicationDataTable:idN108BE123004_input:%count%')]";
	public static String suspectProductCoded = "xpath#(//span[contains(@class,'suspectProductCoded')])[%count%]";
	public static String suspectProductNotCoded = "xpath#(//span[contains(@class,'suspectProductNotCoded')])[%count%]";

	public static String getListOfIndicationinCode = "xpath#//div/p-table//thead/tr/th[text()='Indication Term']//parent::tr//parent::thead//parent::table/tbody/tr/td/a";
	public static String getCodeIndicationTerms = "xpath#(//div/p-table//thead/tr/th[text()='Indication Term']//parent::tr//parent::thead//parent::table/tbody/tr/td/a)[%count%]";

	public static String codedIcon = "xpath#//img[@id='adverseEventNew:caseCodedTrue']";
	public static String prodDescriptionList = "xpath#//span[text()='Product(s)']/following::p-table[@class='codedFlagDrugTableSty']//tbody/tr/td[3]";
	public static String prodDescription = "xpath#(//span[text()='Product(s)']/following::p-table[@class='codedFlagDrugTableSty']//tbody/tr/td[3])[%count%]";
	// public static String partialCodedIcon =
	// "xpath#//img[@id='adverseEventNew:caseCodedPartial']";
	public static String partialCodedIcon = "xpath#//img[@id='adverseEventNew:caseCodedFalse']";
	// public static String indicationStatus = "xpath#(//p-panel[@header='Drug
	// Indication']//th[text()='Status']//parent::tr//parent::thead//parent::table/tbody/tr/td[2]/span/img)[%count%]";
	public static String indicationStatus = "xpath#(//div[@id='ui-panel-27-content']//preceding::span[text()='Drug Indication']//following::thead//tr//following::tbody/tr/td[2]/span/img)[%count%]";
	// public static String productStatus =
	// "xpath#(//p-panel[@header='Product(s)']//th[text()='Status']//parent::tr//parent::thead//parent::table/tbody/tr/td[2]/span/img)[%count%]";
	public static String productStatus = "xpath#(//th[text()='Status']//parent::tr//parent::thead//parent::table/tbody/tr/td[2]/span/img)[%count%]";
	public static String arrowIcon = "xpath#//div[contains(@class,'agTreeToggle codedOpenState')]";
	public static String marketingAuthorizationHolderAsReported_Txtbox = "xpath#//input[@id='adverseEventNew:drugPanelTable:productPanelDataTable:accountName']";

	// public static String prodNameAsReportedList = "xpath#//a[text()='%text%']";
	public static String prodNameAsReportedList = "xpath#//span[text()='Product(s)']/following::p-table[@class='codedFlagDrugTableSty']//tbody/tr/td[1]/a";
	public static String prodNameAsReported = "xpath#(//span[text()='Product(s)']/following::p-table[@class='codedFlagDrugTableSty']//tbody/tr/td[1]/a)[%count%]";
	public static String confirmationYes = "xpath#//button[contains(@class,'productRecodingYes')]";

	// R2 tags
	public static String R2ProductCharacterization = "xpath#//label[text()='Product Characterization']//parent::span/label[text()='[B.4.k.1]']";
	public static String R2ProductNameAsReported = "xpath#//label[text()='Product Name as Reported']//parent::span/label[text()='[B.4.k.2.1]']";
	public static String R2CountryObtained = "xpath#//label[text()='[B.4.k.2.3]']";
	public static String R2ActionTakenWithDrug = "xpath#//label[text()='[B.4.k.16]']";
	public static String R2GestationPeriodAtTimeOfExposure = "xpath#//label[text()='[B.4.k.10a/b]']";
	public static String R2CumulativeDoseToFirstReaction = "xpath#//label[text()='[B.4.k.5.6/7]']";
	public static String R2AdditionalDrugInformation = "xpath#//label[text()='[B.4.k.19]']";
	public static String R2ActiveSubstance = "xpath#//label[text()='[B.4.k.2.2]']";
	public static String R2MAHAsReported = "xpath#//label[text()='[B.4.k.4.3]']";
	public static String R2ApprovalType = "xpath#//label[text()='[J.8]']";
	public static String R2AuthorizationCountry = "xpath#//label[text()='[B.4.k.4.2]']";
	public static String R2AuthorizationNumber = "xpath#//label[text()='[B.4.k.4.1]']";
	public static String R2IndicationTerm = "xpath#//label[text()='[B.4.k.11b ]']";
	public static String R2UnitDose = "xpath#//label[text()='[B.4.k.5.1/2]']";
	public static String R2Frequency = "xpath#//label[text()='[B.4.k.5.3]']";
	public static String R2FrequencyTime = "xpath#//label[text()='[B.4.k.5.4/5]']";
	public static String R2TherapyStartDate = "xpath#//label[text()='[B.4.k.12b]']";
	public static String R2TherapyEndDate = "xpath#//label[text()='[B.4.k.14b]']";
	public static String R2DurationOfDrugAdministration = "xpath#//label[text()='[B.4.k.15a/b]']";
	public static String R2FormOfAdmin = "xpath#//label[text()='[B.4.k.7]']";
	public static String R2RouteOfAdmin = "xpath#//label[text()='[B.4.k.8]']";
	public static String R2Lot_BatchNo = "xpath#//label[text()='[B.4.k.3]']";
	public static String R2ParentsRouteOfAdmin = "xpath#//label[text()='[B.4.k.9]']";
	public static String R2DosageText = "xpath#//label[text()='[B.4.k.6]']";

	// R3 Tags
	public static String R3ProductCharacterization = "xpath#//label[text()='Product Characterization']//parent::span/label[text()='[G.k.1]']";
	public static String R3ProductNameAsReported = "xpath#//label[text()='Product Name as Reported']//parent::span/label[text()='[G.k.2.2]']";
	public static String R3CountryObtained = "xpath#//label[text()='[G.k.2.4]']";
	public static String R3ActionTakenWithDrug = "xpath#//label[text()='[G.k.8]']";
	public static String R3InvestigationalProductBlinded = "xpath#//label[text()='[G.k.2.5]']";
	public static String R3GestationPeriodAtTimeOfExposure = "xpath#//label[text()='[G.k.6a/b]']";
	public static String R3CumulativeDoseToFirstReaction = "xpath#//label[text()='[G.k.5a/b]']";
	public static String R3MedicinalProductIdentifier_MPID = "xpath#//label[text()='[G.k.2.1.1b]']";
	public static String R3MPIDVersionDate_Number = "xpath#//label[text()='[G.k.2.1.1a]']";
	public static String R3PhPID = "xpath#//label[text()='[G.k.2.1.2b]']";
	public static String R3PhPIDVersionDate_Number = "xpath#//label[text()='[G.k.2.1.2a]']";
	public static String R3TrademarkName = "xpath#//label[text()='[G.k.2.2.EU.3]']";
	public static String R3InventedName = "xpath#//label[text()='[G.k.2.2.EU.1]']";
	public static String R3ScientificName = "xpath#//label[text()='[G.k.2.2.EU.2]']";
	public static String R3ContainerName = "xpath#//label[text()='[G.k.2.2.EU.6]']";
	public static String R3StrengthName = "xpath#//label[text()='[G.k.2.2.EU.4]']";
	public static String R3FormName = "xpath#//label[text()='[G.k.2.2.EU.5]']";
	public static String R3DeviceName = "xpath#//label[text()='[G.k.2.2.EU.7]']";
	public static String R3IntendedUseName = "xpath#//label[text()='[G.k.2.2.EU.8]']";
	public static String R3AdditionalDrugInformation = "xpath#//label[text()='[G.k.11]']";
	public static String R3ActiveSubstance = "xpath#//label[text()='[G.k.2.3.r.1]']";
	public static String R3SubstanceTermIDVerDate_Num = "xpath#//label[text()='[G.k.2.3.r.2a]']";
	public static String R3Substance_SpecifiedSubstanceTermID = "xpath#//label[text()='[G.k.2.3.r.2b]']";
	public static String R3Strength_Number = "xpath#//label[text()='[G.k.2.3.r.3a/b]']";
	public static String R3MAHAsReported = "xpath#//label[text()='[G.k.3.3]']";
	public static String R3ApprovalType = "xpath#//label[text()='[J2.4.k]']";
	public static String R3AuthorizationCountry = "xpath#//label[text()='[G.k.3.2]']";
	public static String R3AuthorizationNumber = "xpath#//label[text()='[G.k.3.1]']";
	public static String R3IndicationTerm = "xpath#//label[text()='[G.k.7.r.1]']";
	public static String R3Indication_MedDRALLTCode = "xpath#//label[text()='[G.k.7.r.2b]']";
	public static String R3UnitDose = "xpath#//label[text()='[G.k.4.r.1a/b]']";
	public static String R3FrequencyTime = "xpath#//label[text()='[G.k.4.r.2/3]']";
	public static String R3TherapyStartDate = "xpath#//label[text()='[G.k.4.r.4]']";
	public static String R3TherapyEndDate = "xpath#//label[text()='[G.k.4.r.5]']";
	public static String R3DurationOfDrugAdministration = "xpath#//label[text()='[G.k.4.r.6a/b]']";
	public static String R3FormOfAdmin = "xpath#//label[text()='[G.k.4.r.9.1]']";
	public static String R3PharmaceuticalDoseFormTermID = "xpath#//label[text()='[G.k.4.r.9.2b]']";
	public static String R3PharmaceuticalDoseFormTermIDVerDate_Num = "xpath#//label[text()='[G.k.4.r.9.2a]']";
	public static String R3RouteOfAdmin = "xpath#//label[text()='[G.k.4.r.10.1]']";
	public static String R3RouteOfAdministrationTermID = "xpath#//label[text()='[G.k.4.r.10.2b]']";
	public static String R3RouteOfAdministrationTermIDVerDateNum = "xpath#//label[text()='[G.k.4.r.10.2a]']";
	public static String R3LotBatchNo = "xpath#//label[text()='[G.k.4.r.7]']";
	public static String R3ParentRouteOfAdmin = "xpath#//label[text()='[G.k.4.r.11.1]']";
	public static String R3ParentRouteOfAdministrationTermID = "xpath#//label[text()='[G.k.4.r.11.2b]']";
	public static String R3ParentRouteOfAdministrationTermIDVerDateNum = "xpath#//label[text()='[G.k.4.r.11.2a]']";
	public static String R3DosageText = "xpath#//label[text()='[G.k.4.r.8]']";
	public static String R3AdditionalInfoCode = "xpath#//label[text()='[G.k.10.r]']";

	// Codelist tags
	public static String CLProductCharacterization = "xpath#//label[text()='[1013]']";
	public static String CLCompanyProduct = "xpath#//label[text()='Company Product']//parent::span/label[text()='[1002]']";
	public static String CLProductFlag = "xpath#//label[text()='Product Flag']//parent::span/label[text()='[5015]']";
	public static String CLCountryObtained = "xpath#//label[text()='Country Obtained']//parent::span/label[text()='[1015]']";
	public static String CLActionTakenWithDrug = "xpath#//label[text()='[1019]']";
	public static String CLProductType = "xpath#//label[text()='[9861]']";
	public static String CLCodingClass = "xpath#//label[text()='[9120]']";
	public static String CLStudyProductType = "xpath#//label[text()='[8008]']";
	public static String CLInvestigationalProductBlinded = "xpath#//label[text()='Investigational Product Blinded?']//parent::span/label[text()='[1002]']";
	public static String CLGestationPeriodAtTimeOfExposure = "xpath#//label[text()='[11]']";
	public static String CLCumulativeDoseToFirstReaction = "xpath#//label[text()='Cumulative dose to first Reaction']//parent::span/label[text()='[1018]']";
	public static String CLLackOfEffect = "xpath#//label[text()='Lack Of Effect']//parent::span/label[text()='[1002]']";
	public static String CLPrioruse = "xpath#//label[text()='Prior use']//parent::span/label[text()='[1002]']";
	public static String CLPriorUseOfEquivalentDrug = "xpath#//label[text()='Prior use of equivalent drug']//parent::span/label[text()='[1002]']";
	public static String CLBiologicalFatherExposedToDrug = "xpath#//label[text()='Biological Father exposed to Drug']//parent::span/label[text()='[1002]']";
	public static String CLTolerated = "xpath#//label[text()='Tolerated']//parent::span/label[text()='[1002]']";
	public static String CLStrength_number = "xpath#//label[text()='Strength (number)']//parent::span/label[text()='[9070]']";
	public static String CLApprovalProductFlag = "xpath#//span[text()='Approval#1']//parent::a//parent::li//parent::ul//parent::div//parent::div/div[2]//label[text()='[5015]']";
	public static String CLApprovalType = "xpath#//label[text()='[709]']";
	public static String CLAuthorizationCountry = "xpath#//label[text()='Authorization Country']//parent::span/label[text()='[1015]']";
	public static String CLClassOfDevice = "xpath#//label[text()='[5040]']";
	public static String CLMDRType = "xpath#//label[text()='[9989]']";
	public static String CLIVDRType = "xpath#//label[text()='[9990]']";
	public static String CLDeviceCommercialDate = "xpath#//label[text()='[9985]']";
	public static String CLUnitDose = "xpath#//label[text()='Unit dose']//parent::span/label[text()='[1018]']";
	public static String CLFrequencyTime = "xpath#//label[text()='[1014]']";
	public static String CLDailyDose = "xpath#//label[text()='Daily Dose']//parent::span/label[text()='[1018]']";
	public static String CLTotalDoe = "xpath#//label[text()='Total dose']//parent::span/label[text()='[1018]']";
	public static String CLFormStrength = "xpath#//label[text()='Form Strength']//parent::span/label[text()='[9070]']";
	public static String CLDurationofDrugAdministration = "xpath#//label[text()='Duration of Drug Administration']//parent::span/label[text()='[1017]']";
	public static String CLFormOfAdmin = "xpath#//label[text()='[805]']";
	public static String CLRouteOfAdmin = "xpath#//label[text()='Route of admin.']//parent::span/label[text()='[1020]']";
	public static String CLParentRouteofAdministrationTermID = "xpath#//label[text()='Parent Route of Administration TermID']//parent::span/label[text()='[1020]']";
	public static String CLTherapySite = "xpath#//label[text()='[9992]']";
	public static String CLAdditionalInfoCode = "xpath#//label[text()='[9063]']";

	// Product lookup

	public static String ProductName_TxtfieldLookup = "xpath#//label[text()='Product Name']/following-sibling::input";

	// copy blinded product and Select Study Product
	public static String copyBlindedProd_Btn = "xpath#//button[contains(@class,'agBlindCopyBtn')][text()='Copy Blinded Product']";
	public static String blindedinfo_Label = "xpath#//span[text()='Blinded Information']";
	public static String blindedConfigInfo = "xpath#//ul[@class='copyBlindedProConfig']";
	public static String blindedpopupOkBtn = "xpath#//div[contains(@class,'searchOkbtn')]//span[text()='OK']";
	public static String copiedBlindedText = "xpath#//label[@class='blindedInfoText ng-star-inserted']";
	public static String product = "xpath#//input[contains(@id,'productPanelDataTable:productCoded')]";
	public static String selectStudyProd_Btn = "xpath#//button[contains(@class,'agBlindCopyBtn')][text()='Select Study Product(s)']";
	public static String studyOKBtn = "xpath#//div[contains(@class,'searchOkbtn')]//span[text()='OK']";

	public static String productDropDownSelect = "xpath#//label[contains(text(),'{0}')]/ancestor::span/p-dropdown/div[not(contains(@class,'agNfDropdown'))]";
	public static String indicationVerification = "xpath#//input[@id='adverseEventNew:drugPanelTable:indicationDataTable:idN108BE123004_input:0']";

	public static String productrecalculate_Popup = "xpath#//p[text()='Change in product will recalculate Labelling. Do you want to continue Recoding?']";
	public static String recalculateCheckbox = "xpath#//ul[@class='productRecodinfConfg']//following::label[text()='%s%']/parent::li/p-checkbox/div";
	public static String productNameAsReported = "Product Name as Reported";
	public static String device = "Device";
	public static String drugTherapy = "Drug Therapy";
	public static String indication = "Indication";
	public static String recalculateYesBtn = "xpath#//button[contains(@class,'productRecodingYes')]";
	public static String recalculateNoBtn = "xpath#//button[contains(@class,'productRecodingNo')]";
	// Auto Suggestion
	public static String autoSuggestionProductpopup = "xpath#//div[contains(@class,'ui-autocomplete-panel')]";
	public static String autoselectPPD = "xpath#//div[@class='agAutoCompPanelBody ng-star-inserted']/span[text()='PPD']";
	public static String autoselectLTN = "xpath#//div[@class='agAutoCompPanelBody ng-star-inserted']/span[text()='LTN']";

	public static String routeOfAdminValue = "xpath#//span[text()='Buccal ( Buc )']";

	public static String nullFlavoupPopUp = "xpath#//span[text()='Current value will be cleared. Do you want to continue?']";
	public static String nullFlavoupPopUpYesButton = "xpath#//p-confirmdialog[@ngclass='confirmDialogZindexSty']//span[text()='Yes']";
	public static String clicktoRemoveNF = "xpath#//label[contains(text(),'%s')]//parent::span//parent::div//a[@class='agNfAppliedLink']/img";

	public static String productDescriptionConfirmation = "xpath#//span[@id='ui-dialog-33-label'][contains(text(),'Confirmation')]";
	public static String productDescriptionConfirmation_nameAsReported = "xpath#//label[contains(text(),'Product Name as Reported')]/parent::li/p-checkbox/div";
	public static String productDescriptionConfirmation_Yes = "xpath#//span[@id='ui-dialog-33-label'][contains(text(),'Confirmation')]/parent::div/following-sibling::div//button/span[contains(text(),'Yes')]";
	public static String productDescription_TextBox = "xpath#//label[contains(text(),'Product description')]/parent::span/parent::div//input";

	public static String productDescription_popResultWindow = "xpath#//label[contains(text(),'Product description')]/following-sibling::p-autocomplete/span/div";
	public static String productDescription_LTN = "xpath#//label[contains(text(),'Product description')]/following-sibling::p-autocomplete/span/div//li//span[contains(text(),'LTN')]";
	public static String productDescription_PPD = "xpath#//label[contains(text(),'Product description')]/following-sibling::p-autocomplete/span/div//li//span[contains(text(),'PPD')]";
	public static String productDescription_WHODD = "xpath#//label[contains(text(),'Product description')]/following-sibling::p-autocomplete/span/div//li//span[contains(text(),'WHODD')]";

	public static String productselection = "xpath#//span[contains(text(),'%s%')]";

	public static String SecondProduct = "xpath#//span[contains(text(),'2.')]";
	// public static String ThirdProduct="xpath#//span[contains(text(),'3.')]";
	public static String DeleteProduct = "xpath#(//span[contains(@class,'agAddDeleteBlock')]//a[@class='agMultiDeleteLink ng-star-inserted'])[2]";
	public static String YesBtn = "xpath#//p-confirmdialog//button//span[text()='Yes']";

	public static String therapy = "xpath#//span[contains(text(),'Therapies')]";
	
	public static String productCharacterization="xpath#//div[@id='ui-panel-34-content']/div/div/div/span/p-dropdown/div";
	public static String tradeBrandName_TextField1="xpath#//label[text()='Trade/Brand Name']/parent::div/input";
	public static String whoDD_RadioBtn = "xpath#//label[text()='WHO DD']/ancestor::p-radiobutton/div/child::div/span";
public static String checkFirstProdInWHODDLib = "xpath#//tr[1]/td/p-tableradiobutton/div/div[2]";
public static String wHODDLibOkButton = "xpath#//div[contains(@class,'searchOkbtn ')][2]/button/span[text()='OK']";




	public static String selectProduct(String text) {
		String value = productselection.replace("%s%", text);
		return value;
	}

	public static String recalculatecheckbox(String text) {
		String value = recalculateCheckbox.replace("%s%", text);
		return value;
	}

	public static String getProductNotCode(String count) {
		String value = suspectProductNotCoded.replace("%count%", count);
		return value;
	}

	public static String getProductNameAsReported(String count) {
		String value = prodNameAsReported.replace("%count%", count);
		return value;
	}

	public static String getProductCode(String count) {
		String value = suspectProductCoded.replace("%count%", count);
		return value;
	}

	public static String getProductDescription(String count) {
		String value = prodDescription.replace("%count%", count);
		return value;
	}

	// get indication terms in code
	public static String getIndicationinCode(String count) {
		String value = getCodeIndicationTerms.replace("%count%", count);
		return value;
	}

	// To get getcode list
	public static String getCodelist(String label, String codelist) {
		String value = getCodelist.replace("%label%", label);
		String value1 = value.replace("{codelist}", codelist);
		return value1;
	}

	public static String getIndicationStatus(String count) {
		String value = indicationStatus.replace("%count%", count);
		return value;
	}

	public static String getProductStatus(String count) {
		String value = productStatus.replace("%count%", count);
		return value;
	}

	// get indication terms in product
	public static String getIndication(String count) {
		String value = getIndicationsTerms.replace("%count%", count);
		return value;
	}

	// Click DropDown value
	public static String clickDropDownValue(String data) {
		String value = setdropDownValue.replace("%s", data);
		return value;
	}

	public static String productTextbox(String label) {
		String value = productTextbox.replace("{0}", label);
		return value;
	}

	public static String productRadio(String label, String testdata) {
		String value = productRadio.replace("{0}", label);
		value = value.replace("{@}", testdata);
		return value;
	}

	public static String productDropdownSelect(String label) {
		String value = productDropdownSelect.replace("{0}", label);
		return value;
	}

	public static String productEmdedDropdownSelect(String label) {
		String value = productEmdedDropdownSelect.replace("{0}", label);
		return value;
	}

	public static String productChkbox(String label, String chkValue) {
		String value = productChkbox.replace("{0}", label);
		value = value.replace("{@}", chkValue);
		return value;
	}

	public static String productEmbedTxtbox(String label) {
		String value = productEmbedTxtbox.replace("{0}", label);
		return value;
	}

	public static String checkRadioButton_Value(String label, String chkValue) {
		String value = checkRadioButton_Value.replace("{0}", label);
		value = value.replace("{@}", chkValue);
		return value;
	}

	public static String product_Navigations(String label) {
		String value = product_Navigations.replace("{0}", label);
		return value;
	}

	public static String product_Link(String label) {
		String value = product_Link.replace("{0}", label);
		return value;
	}

	public static String product_DateTextbox(String label) {
		String value = product_DateTextbox.replace("{0}", label);
		return value;
	}

	// navigate to Products
	public static String prodNavigate = "xpath#//div[@class='tabCarouselSty']/ul/li[contains(@class,'fdeMultiTab')]/a/span[contains(text(),'%text%')]";

	public static String navigateProduct(String text) {
		String value = prodNavigate;
		String value2;
		value2 = value.replace("%text%", text);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select radio button by passing
	 *                label name at runtime
	 * @Input Parameters: Label
	 * @OutputParameters:
	 * @author:Avinash K Date :27-Nov-2019 Updated by and when
	 **********************************************************************************************************/
	public static String accountLookup_selectRadioBtn(String label) {
		String value = accountLookup_selectRadioBtn.replace("%s", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select Add/Delete button by passing
	 *                label name on the Button at runtime
	 * @Input Parameters: Label (Add/Delete)
	 * @OutputParameters:
	 * @author:Ramkumar M P Date :09-Mar-2020 Updated by and when
	 **********************************************************************************************************/
	public static String clickTherapyButtons(String data) {
		String value = therapyAddBtn.replace("%s", data);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click NF button by passing label
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Yashwanth Naidu Date :23-April-2020 Updated by and when
	 **********************************************************************************************************/
	public static String click_NFBtn(String Label) {
		String value = clickNFbutton;
		String value2;
		value2 = value.replace("%s", Label);
		return value2;
	}

	public static String click_UndoNFBtn(String Label) {
		String value = clicktoRemoveNF;
		String value2;
		value2 = value.replace("%s", Label);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click the dropdown when NF button
	 * clicked name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Yashwanth Naidu Date :23-April-2020 Updated by and when
	 **********************************************************************************************************/

	public static String NFproductDropdownSelect(String label) {
		String value = productNFDropdownSelect.replace("{0}", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: To Clik on Product tab
	 * @InputParameters: position, runTimeLabel
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 26-Apr-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String clickProduct(String position, String runTimeLabel) {
		String actual = productClick;
		String temp = actual.replace("{0}", position);
		String result = temp.replace("%s", runTimeLabel);
		return result;
	}

	/**********************************************************************************************************
	 * @Objective: To Clik on Product tab
	 * @InputParameters: position, runTimeLabel
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 26-Apr-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String clickTherapie(String position, String runTimeLabel) {
		String actual = terapieClick;
		String temp = actual.replace("{0}", position);
		String result = temp.replace("%s", runTimeLabel);
		return result;
	}
}
