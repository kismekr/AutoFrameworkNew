package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public abstract class FDEMoreOptionsPageObjects {
	public static String moreOptionSwitchNavigation = "xpath#//span[@id='formSwitchId']/div/a[text()='Switch To Form']";
	public static String moreOptionsFDENavigation = "xpath#//a[.='FULL DATA ENTRY FORM']";
	public static String moreOptionsHover = "xpath#//span[contains(@class,'InqList-tooltip' )]/a[text()='More Actions']";
	// public static String moreOptionsHover =
	// "xpath#//a[@id='adverseEventNew:actionsLinkID']";
	// public static String caseReports_Icon = "xpath#//a[@title='Case Reports']";
	public static String caseReports_Icon = "xpath#//div[contains(@class,'morereportactionDiv')]/a/img";
	public static String ciomsReportList = "xpath#//a[@id='ciomsReportGenerate'][text()='CIOMS']";
	public static String deleteOkButton = "xpath#//div[@id='delteConfirmDlgMain']//div/span[@id='okCnfDlgDetails']";

	public static String moreActionHover = "xpath#//span[text()='More Action']/parent::span";
	public static String moreActionNavigation = "xpath#//div[contains(@class,'gridButtonBarClass')]/span/div[(@class='tooltipInqList')]/div/a[text()='%s']";
	public static String moreReporteroptionsHover = "xpath#(//div[@class='tooltipInqList']/div[@class='moreOPtionSubmenuparent'][contains(text(),'')]/a)[2]";
	// public static String moreReporteroptionsHover
	// ="xpath#//span[contains(text(),'More Report Actions')]";
	public static String caseSummaryLink = "xpath#//span[@class='ui-menuitem-text'][contains(text(),'Case Summary')]";
	public static String caseSummaryGenerate = "xpath#//a[@id='adverseEventNew:caseSummaryReportGenerate']";
	public static String downloadIcon = "xpath#//button[@id='download']";
	public static String ReportGenerationacess = "xpath#//span[@id='dataPrivacyAccess_title']";
	public static String PublicRadiobutton = "xpath#//*[text()='Public']";
	public static String GenerateButton = "xpath#//button[@id='generateReport']";
	public static String ciomosReport_iframeID = "openCiomosSummaryDiolog:test_adv";
	public static String pdfFrameid = "openCaseSummaryDiolog:test_adv";
	public static String cancelIcon = "xpath#//span[@id='openCaseSummaryDiolog:CaseSummaryDialog_title']/following-sibling::a[1]";
	public static String ciomsReport_cancelIcon = "xpath#//span[@id='openCiomosSummaryDiolog:CiomosSummaryDialog_title']/following-sibling::a[1]";
	public static String okButton = "xpath#//button[@id='mandatoryDialogform:okButton']//span[@class='ui-button-text ui-c'][contains(text(),'OK')]";
	public static String downLoadReports = "xpath#//ul[contains(@class,'ui-widget-content')]/li/a/span[@class='ui-menuitem-text'][text()='%s']";
	public static String reportsLink = "xpath#//div[contains(@class,'morereportactionDiv')]/div/ul/li/a[text()='%s']";
	public static String moreOptionsNavigation = "xpath#//div[contains(@class,'tooltipInqList')]/span//a[text()='%s']";
	public static String delete_Link = "Delete";
	public static String deleteAuditReasonCode_Dropdwn = "xpath#//div[@id='auditForm:C-9026']";
	public static String deleteReasonCode_Dropdwn_value = "xpath#//ul[@id='auditForm:C-9026_items']//li[contains(text(),'Other')]";
	public static String deleteAuditReason_Textarea = "xpath#//textarea[@id='auditForm:auditReason']";
	public static String deleteAuditReasonSubmit_Btn = "xpath#//button[@id='auditForm:auditSubmitButton']/span";
	public static String deleteValidationOk_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']//span[text()='OK']";
	public static String receiptNumber = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String CorrespondanceReptNumber = "xpath#//span[@id='correspondenceWindowHeader']";
	public static String NewCorrespondanceBtn = "xpath#//span[@id='newBtnId']";
	public static String CorrespondanceTo = "xpath#//textarea[@id='correspondenceToTextArea']";
	public static String CategoryDropDown = "xpath#//select[@id='correspondenceCategorySelect']//option[text()='%s']";
	public static String DocumentUpload = "xpath#//input[@id='fileAttachmentControl']";
	public static String DocumentUploadVerification = "xpath#//span[text()='500KB_File (1).pdf']";
	public static String CopyCancel = "xpath#//div[@class='row']//button[text()='Cancel']";
	public static String toAddress = "xpath#//div[@class='lsmv-grid-row']//span/strong[text()='%s']";

	public static String RefreshBtn = "xpath#//span[text()='Refresh']";
	public static String CorrespondanceBtnnew = "xpath#//div[@targetpanelid='targetPanelForCorrespondencePanel']//span[@id='newBtnId']";
	public static String VerifyRecptNumber = "xpath#//span[starts-with(text(),'Activity Log ')]";
	public static String ReptNumber = "xpath#//span[@id='activityLogFormId:addactivityDialog_title']";
	// public static String WorkflowActivity =
	// "xpath#(//div[@fieldid='wfActivity']//div[text()='Intake and
	// Assessment'])[1]";
	public static String WorkflowActivity = "xpath#(//div[@fieldid='wfActivity']//div[text()='Initial'])[1]";
	public static String ActivityLogCloseBtn = "xpath#//span[@id='closeActivitylogBtn']";
	public static String WfActivity = "xpath#(//div[@class='lsmv-grid-row'])[1]//div[@fieldid='wfActivity']";
	public static String WfActivityPrevious = "xpath#(//div[@class='lsmv-grid-row'])[1]//div[@fieldid='wfActivity']";
	public static String receiptNo = "xpath#(//div[@class='lsmv-grid-row'])[1]//div[@fieldid='receiptNo']";
	public static String DownloadActivityLog = "xpath#//div[@targetpanelid='activitylogListingBody']/span[@title='Download/Export Grid Records']";
	public static String ExportToExcelBtn = "xpath#//span[text()='Export As Excel']";
	public static String ExportToPdfBtn = "xpath#//span[text()='Export As PDF']";
	public static String DataExportCancelBtn = "xpath#//div[@id='dataExportMain']//span[text()='Cancel']";
	public static String ActionDetails = "xpath#(//div[@class='lsmv-grid-row'])[1]//div[@fieldid='actionDetails']/span";

	public static String WorkFlowName = "xpath#(//div[contains(text(),'ISP Case Processing Workflow')])[1]";
	public static String WorkflowCLose = "xpath#//span[@id='closeWfTrackBtn']";
	public static String TransitionName = "xpath#(//div[@fieldid='nonEngWfTransitionName'])[2]";
	public static String FromActivityName = "xpath#(//div[@fieldid='nonEngPreviousWfActivityName'])[2]";
	public static String ToActivityName = "xpath#(//div[@fieldid='nonEngWfaName'])[2]";
	public static String DownloadWorkflowLog = "xpath#//div[@targetpanelid='wfTrackListingBody']/span[@title='Download/Export Grid Records']";
	public static String IsAutoCompleted = "xpath#(//div[@fieldid='autoComplete'])[2]";
	public static String wfDescription = "xpath#(//div[@fieldid='latenessReason'])[2]//span";
	public static String IsAutoCompleteFailed = "xpath#(//div[@fieldId='autoCompletionFailed'])[2]";
	public static String TransitionNameNextRow = "xpath#(//div[@fieldid='nonEngWfTransitionName'])[3]";
	public static String FromActivityNameNextRow = "xpath#(//div[@fieldid='nonEngPreviousWfActivityName'])[3]";
	public static String ToActivityNameNextRow = "xpath#(//div[@fieldid='nonEngWfaName'])[3]";
	public static String IsAutoCompletedNextRow = "xpath#(//div[@fieldid='autoComplete'])[3]";
	public static String wfDescriptionNextRow = "xpath#(//div[@fieldid='latenessReason'])[3]//span";
	public static String IsAutoCompleteFailedNextRow = "xpath#(//div[@fieldId='autoCompletionFailed'])[3]";

	public static String EMailReportTo = "xpath#//textarea[@id='correspondenceToTextArea']";
	public static String CatergoryDRopdownEmailReport = "xpath#//select[@id='correspondenceCategorySelect']";
	public static String CategoryValue = "xpath#//select[@id='correspondenceCategorySelect']//option[text()='%s']";
	public static String SaveBtn = "xpath#//div[@id='correspondanceMainEmail']//div[@class='lsmv-popup-header']//button[text()='Save']";
	public static String SendEmailReportBtn = "xpath#//div[@id='correspondanceMainEmail']//div[@class='lsmv-popup-header']//button[text()='Send']";

	public static String EMailReportPopUp = "xpath#//div[@id='correspondanceMain']";
	public static String CloseiconBtn = "xpath#//div[@id='correspondanceMain']/div//span[@id='cancelBtnId']";

	// Audit Trail
	public static String AuditReptNumber = "xpath#//span[@id='adverseEventNew:caseLevelAuditDiaogId_title']";
	public static String TableNameValidtaion = "xpath#//th[@id='adverseEventNew:j_id_1rl:0:j_id_1sm:j_id_1so']";
	public static String AuditCLoseBtn = "xpath#//div[@id='adverseEventNew:caseLevelAuditDiaogId']//span[@class='ui-icon ui-icon-closethick']";
	public static String downloadAsExcel = "xpath#//span[text()='Download as Excel']";
	public static String downloadAsPDF = "xpath#//span[text()='Download as PDF']";
	public static String LastIcon = "xpath#//a[@class='ui-paginator-last ui-state-default ui-corner-all']";
	public static String Page34 = "xpath#//a[@aria-label='Page 33']";
	public static String LabellingCheck = "xpath#//td[text()='Labelling']/following-sibling::td[text()='true']";
	public static String CountryCheck = "xpath#//td[text()='Country']/following-sibling::td[text()='CUBA (CU)']";
	public static String LabellingUnlabelledCheck = "xpath#//td[text()='Labelling']/following-sibling::td[text()=' (0)']";
	public static String LabellinglabelledCheck = "xpath#//td[text()='Labelling']/following-sibling::td[text()=' (1)']";
	public static String CountryIBCheck = "xpath#//td[text()='Country']/following-sibling::td[text()='IB (2)']";
	public static String PageIcon = "xpath#(//a[@aria-label='Page %s'])[1]";
	public static String TableValuesCase = "xpath#//tbody[@id='adverseEventNew:j_id_11p_o:1:j_id_11p_1p_data']//tr/td";
	public static String Tablevalues = "xpath#//tbody[contains(@id,'adverseEventNew')]//tr/td/ancestor::div[contains(@id,'adverseEventNew')]//td";
	// Task
	public static String TaskReptNumber = "xpath#//span[@id='popUpHeaderTitle']";
	public static String TaskNewBtn = "xpath#//div[@targetpanelid='targetPanelForTaskLookup']//span[@id='newBtnId']";
	public static String SelectCaseType = "xpath#//select[@id='smartFieldNA']";
	public static String RemainderDetailsIcon = "xpath#//label[text()='Reminder Details']/preceding-sibling::span";
	public static String InputDueDate = "xpath#//input[@name='dueDate']";
	public static String TaskSaveBtn = "xpath#//div/span[text()='Save']";
	public static String Priority = "xpath#//div[text()='Normal']";
	public static String Reptno = "xpath#//div[@class='lsmv-grid-row']//div[@fieldid='receiptNo']";
	public static String CLoseTask = "xpath#//div[@id='taskListingMain']//span[text()='Close']";
	public static String commandCLose = "xpath#//div[@id='libraryDataDrag']//div[@id='lsmv-comments-close']";
	public static String CommentTask = "xpath#//textarea[@name='comments']";
	public static String ReplyStatusDD = "xpath#//select[@name='replyStatus']";
	public static String ReplyDate = "xpath#//input[@name='replyDate']";
	public static String SceduledDate = "xpath#//input[@name='taskTime']";
	public static String ActualCompletionDate = "xpath#//input[@name='actualCompletionDate']";
	public static String DistributionContactInformation = "xpath#//label[text()='Distribution Contact Information']/preceding-sibling::span";
	public static String AuthorityDD = "xpath#//select[@name='authority']";
	public static String ContactDD = "xpath#//select[@name='contact']";
	public static String ReminderOnDate = "xpath#//input[@name='reminderDate']";
	public static String DocumnentIcon = "xpath#//label[text()='Document']/preceding-sibling::span";
	public static String DocumentUploadTask = "xpath#//input[@id='uploadTaskDocs']";
	public static String FilenameValidation = "xpath#//table[@id='taskDocTable']//a[contains(@docname,'')]";
	public static String FileDescription = "xpath#//input[@name='docDesc']";
	public static String UsergroupAssignmentDetails = "xpath#//label[text()='User/Group Assignment Details']/preceding-sibling::span";
	public static String UserCheckbox = "xpath#(//div[@class='transfer-double-list-main']//ul[contains(@class,'transfer-double-list-ul')]//input[@type='checkbox'])[1]";
	public static String UserArrowBtn = "xpath#//div[@class='btn-select-arrow btn-arrow-active']";
	public static String SelectedUser = "xpath#(//div[@class='transfer-double-selected-list']//ul)[1]";
	public static String SearchTask = "xpath#//div[contains(text(),'Application User')]/ancestor::div[@class='transfer-double-content-left']//input[@placeholder='Search']";
	public static String ReferenceId = "xpath#(//div[@fieldid='relatedRefId'])[2]";

	public static String PreviousTaskchkbox = "xpath#//div[@id='targetPanelForTaskLookup']//span[@class='lsmv-grid-sel-all-chk lsmv-grid-sel-unchk']";
	public static String TaskDeleteBtn = "xpath#//div[@targetpanelid='targetPanelForTaskLookup']//span[@id='deleteBtnId']";
	public static String DeleteValidation = "xpath#//span[text()='Task Deleted Successfully']";
	public static String userChkBox = "xpath#//label[contains(text(),'%userName%')]//parent::div/label";
	// Notes
	public static String NoteReptNumber = "xpath#//div[@id='noteListingDrag']";
	public static String Description = "xpath#//div/textarea[@id='descriptionId']";
	public static String FileUpload = "xpath#//input[@id='noteAttachmentCmp']";
	public static String NoteSave = "xpath#//div[@id='newNotePanel']//button[text()='Save']";
	public static String NoteNewBtn = "xpath#//div[@targetpanelid='noteListingBody']//span[@id='newNotesAddBtn']";
	public static String DeleteBtn = "xpath#//div[@targetpanelid='noteListingBody']//span[@id='deleteNotesBtn']";
	public static String DeletePopUp = "xpath#//span[text()='Deleted Successfully']";
	public static String CLoseNote = "xpath#//div[@id='noteListingMain']//span[text()='Close']";
	public static String NotePopup = "xpath#//span[text()='Successfully Added Notes']";
	public static String NotesRecptNum = "xpath#//span[contains(text(),'Notes | ')]//following::div[@fieldid='receiptNo']//div//span[text()='%rctNum%']";
	public static String NotesDescription = "xpath#(//div[@fieldid='note'])[2]//div";
	public static String NotesCheckBox = "xpath#//div[@class='lsmv-grid-row']//span[contains(@class,'lsmv-grid-row-sel-chk lsmv-grid-sel-unchk')]";
	public static String NotesReptNum = "xpath#(//div[@fieldid='receiptNo'])[2]//div";
	public static String NoteCancel = "xpath#//div/button[text()='Cancel']";
	// Distribution Contacts
	public static String VerifyListofDistributionContacts = "xpath#//span[text()='List of Proposed Distributed Contacts']";
	public static String DistributionContactClose = "xpath#//div[@id='viewDistConactsBody']//span[text()='Close']";
	public static String distributeContactSearch = "xpath#//input[@title='Receiver Contact, Anchor Name, Distribution Contact Name']";
	public static String distributeSearch = "xpath#//div[@id='viewDistConactsBody']//span[@class='lsmv-search-icon']";
	public static String verifyOltContact = "xpath#(//div[text()='OLT']//parent::div//parent::div//parent::div//parent::div/div[@class='lsmv-grid-row']/div[@class='lsmv-grid-col lsmv-tooltip '])[9]/div[@class='lsmv-grid-col-adjust ']";

	// Send correspondence
	public static String Send_Correspondence = "xpath#//div[@class='lsmv-popup-header']//button[@labelcode='correspondence_send']";
	public static String Cancel_correspondence = "xpath#//span[@id='cancelBtnId']";
	public static String emailCorrespondence_Hdr = "xpath#//span[@id='questionnariesWindowHeader']";
	public static String correspondenceTo = "xpath#//textarea[@id='correspondenceToTextArea']";
	public static String selectpriority = "xpath#//select[@id='correspondencePrioritySelect']";
	public static String selectstatus = "xpath#//select[@id='correspondenceStatusSelect']";
	public static String selectCategory = "xpath#//select[@id='correspondenceCategorySelect']";
	public static String remindertemplate = "xpath#//span[@id='addReminderTemplate']";
	public static String selecttemplate = "xpath#//span[@id='selectTempQues']";
	public static String templatelookUP = "xpath#//span[text()='Template Lookup']";
	public static String searchtemplate = "xpath#//input[contains(@title,'TEMPLATE NAME')]";
	public static String clickRadiobtn_checkbox = "xpath#//input[@id='%label%']";
	public static String webLink_Radiobtn = "queryFmt0";
	public static String queryformatPopUP = "xpath#//span[text()='Email Data updated Successfully']";
	public static String noOfReminders = "xpath#//input[@id='noOfRemindersCorr']";
	public static String reminderInterval = "xpath#//input[@id='reminderIntervalCrr']";
	public static String selectReminderIntervalUnit = "xpath#//select[@id='reminderIntervalUnitSelectCrr']";
	public static String overRideReminder = "overrideReimnder";
	public static String turnOffReminder = "xpath#turnOffReminder";
	public static String localCorespondence = "localCorrespondenceView";
	public static String sendBtn = "xpath#//button[@labelcode='correspondence_send']";
	public static String sendEmailPopUp = "xpath#//span[@class='lsmv-info-message']";
	public static String correspondenceCC = "xpath#//textarea[@id='correspondenceCCTA']";

	public static String successIcon = "xpath#//span[@title='Success']";
	public static String failedIcon = "xpath#//span[@title='Failed']";
	public static String queuedIcon = "xpath#//span[@title='Queued']";
	public static String cancelBtn = "xpath#//button[@onclick='hideEmailCorrespondenceWindow();']";
	public static String viewCorrespondence = "xpath#//span[contains(@onclick,'viewCorrespondence')]/strong";

	// FollowUp Weblink

	public static String FollowUpModeDropDown = "xpath#(//select[@id='quesModeCombo'])[1]";
	public static String WeblinkRadioButton = "xpath#(//label[contains(text(),'Web Link')])[1]//preceding::input[1]";
	public static String PDFDocRadioButton = "xpath#(//label[contains(text(),'PDF Document')])[1]//preceding::input[1]";
	public static String confirmationOKButton = "xpath#(//span[contains(text(),'Ok')])[1]";
	public static String WeblinkReceiverTextBox = "xpath#//textarea[@id='toEmailId']";
	public static String FollowUpSendButton = "xpath#//span[text()='Send']";
	public static String emailDataRepopulate = "xpath#//div[@id='cnfDialogMain']//label";

	// Attachments
	public static String uploadBtn = "xpath#//div[@targetpanelid='targetPanelForCorrespondenceAttachmentPanel']/span[text()='Upload']";
	public static String screenloading = "xpath#//div[@class='mask-message-div']";
	public static String attachmentSuccessfully = "xpath#//span[text()='Attachment uploaded successfully']";

	// Send Correspondence
	public static String Send_CorrespondenceNew = "xpath#//div[@id='correspondenceButtonsBottom']//button[@labelcode='correspondence_send']";

	// Reply Correspondence
	public static String Reply_Correspondence = "xpath#//div[@id='correspondenceButtonsBottom']//button[@labelcode='correspondence_reply']";

	// Cancel Correspondence
	public static String Cancel_Correspondence = "xpath#//div[@id='targetPanelForCorrespondencePanel']//span[contains(text(),'Cancel')]";

	// Edit Correspondence Link
	public static String Edit_CorrespondenceLink = "xpath#(//span[@title='Incoming  Mail']/ancestor::div[@fieldid='attributes' ]/following-sibling::div[@fieldid='subject']//strong)[1]";

	// Correspondence validation
	public static String CorrespondenceTooltip = "xpath#//div[@class='lsmv-info-popup']//span[contains(text(),'Correspondence successfully')]";
	public static String loading = "xpath#//div[@class='mask-message-div']";

	// Case Score Navigation Under More OPtions
	public static String CaseScoreNavigationUnderMoreoptions = "xpath#(//span/parent::a/ancestor::div[@class='moreOPtionSubmenuparent'])[1]";
	public static String CaseScoreOPtions = "xpath#//div[contains(@class,'tooltipInqList')]//a[text()='%s']";
	public static String CAseQualityVerification = "xpath#//span[@id='adverseCaseScoreHistoryID:adverseCaseScoreDailog_title']";
	public static String CloseCaseQualityPopUp = "xpath#//div[@id='adverseCaseScoreHistoryID:adverseCaseScoreDailog']//a[@class='ui-dialog-titlebar-icon ui-dialog-titlebar-close ui-corner-all']";

	// E2B Tags Navigation under More Options
	public static String E2BTagsNavigationUnderMoreoptions = "xpath#//div[@class='moreOPtionSubmenuparent']//a//span";
	public static String E2BOPtionsCheckBoxes = "xpath#//label[text()='%s']//following::div[3]/span[contains(@class,'ui-chkbox-icon')]";

	// create new version in moreoptions
	public static String Reasonlabel = "xpath#//label[@id='createNewVersionForm:reasonId']";

	// Audit Trial
	public static String auditTrilReport = "xpath#//span[@id='adverseEventNew:audit_tolltip']";
	public static String excelDownload_Dropdown = "xpath#//label[@id='adverseEventNew:C-604_label']";
	public static String downloadBtn = "xpath#//button[@id='adverseEventNew:dwnBtnId']";
	public static String ReportdownloadIcon = "xpath#//button[@id='download']";
	public static String closeBtn = "xpath#(//button[contains(@id,'adverseEventNew')]//span[text()='Close'])[1]";
	public static String wfActivityName = "xpath#(//tbody[contains(@id,'adverseEventNew:j_id_1qg_j:0')])[1]//tr/td[6]";
	public static String auditTrailValidationElements = "xpath#(//td[@role='gridcell' and text()='%validateElement%'])[1]";
	public static String closeAuditTrial = "xpath#//span[@id='adverseEventNew:caseLevelAuditDiaogId_title']//parent::div/a";
	public static String downloadAsPDF_Btn = "xpath#//button[@id='adverseEventNew:dwnBtnId']/span[text()='Download as PDF']";

	// E2B Report Generation
	public static String e2BGenerateReport = "xpath#//a[text()='Generate E2B XML']";
	public static String validateE2BReporPopUp = "xpath#//div[@id='bconfirmationDialogDrag']//span[text()='Generate E2B XML']";
	public static String clickDTDXSDTypeDD = "xpath#//select[@id='msgType']";
	public static String setDTDXSDdropDownValue = "xpath#//select[@id='msgType']/option[contains(text(),'%s')]";
	public static String clickMHLWReportType = "xpath#//select[@id='mhwlRptType']";
	public static String setMHLWdropDownValue = "xpath#//select[@id='mhwlRptType']/option[contains(text(),'%s')]";
	public static String exportE2Bxml = "xpath#//button[text()='Export E2B XML']";
	public static String radioR2 = "xpath#//input[@id='R2']";

	public static String WfActivityName = "xpath#//span[text()='WorkFlow Activity Name']//parent::th//parent::tr//parent::thead//parent::table/tbody/tr/td[6]";
	public static String intialReceiveDataTag = "xpath#//label[text()='[A.1.6b]']";
	public static String latestReceiveDataTag = "xpath#//label[text()='[A.1.7b]']";

	// Correspondance
	public static String correspondanceHeader = "xpath#//span[@id='correspondenceWindowHeader']";
	public static String CorrespondanceMode = "xpath#//select[@id='correspondenceModeCombo']";
	public static String EmailTemplate = "xpath#//span[@title='Attach Template']";
	public static String EmailTemplateChkBox = "xpath#//span[contains(@class,'lsmv-grid-row-sel-chk')]";
	public static String EmailTemplateOkBtn = "xpath#//span[@id='selecctBtnId']";
	public static String correspondanceRefresh = "xpath#//span[@class='lsmv-refresh-icon']";
	public static String correspondanceRemainderCount = "xpath#//div[@fieldid='reminderCount']";
	public static String correspondanceScreen = "xpath#(//div[@fieldid='%fieldId'])[%index]//span";
	public static String Category = "category";
	public static String ReceiptNo = "receiptNo";
	public static String To = "to";
	public static String Subject = "subject";
	public static String Status = "status";
	public static String ReminderCount = "reminderCount";
	public static String EmailSave = "xpath#//button[@id='saveEmailButtonId']";
	public static String EmailCancel = "xpath#(//button[text()='Cancel'])[1]";

	public static String PhoneCorrespondanceTo = "xpath#//textArea[@id='correspondencePhoneToTextArea']";
	public static String PhoneCorrespondanceFrom = "xpath#//input[@id='correspondencePhoneFromInput']";
	public static String PhoneCountryCode = "xpath#//input[@id='correspondencePhoneCountryCodeInput']";
	public static String PhoneNumber = "xpath#//input[@id='correspondencePhoneNumberInput']";
	public static String PhoneCorrespandanceSubject = "xpath#//input[@id='correspondencePhoneSubject']";
	public static String PhoneCorrespandanceSave = "xpath#//button[@id='savePhoneButtonId']";
	public static String PhoneCategoryValue = "xpath#//select[@id='correspondencePhoneCategorySelect']//option[text()='%s']";
	public static String PhoneCorrespondanceCancel = "xpath#(//button[text()='Cancel'])[1]";

	public static String LetterTo = "xpath#//textarea[@id='correspondenceLetterToTextArea']";
	public static String LetterSubject = "xpath#//input[@id='correspondenceLetterSubject']";
	public static String LetterSave = "xpath#//button[@id='saveLetterButtonId']";
	public static String LetterCancel = "xpath#(//button[text()='Cancel'])[1]";
	public static String LetterCorrespondanceSavedSuccessfully = "xpath#//span[text()='Correspondence updated successfully']";

	public static String FaxTo = "xpath#//textarea[@id='correspondenceToTextArea']";
	public static String FaxSend = "xpath#//button[@labelcode='correspondence_send']";
	public static String FaxSave = "xpath#//button[@id='saveFaxButtonId']";
	public static String FaxCancel = "xpath#(//button[text()='Cancel'])[1]";

	public static String LocalDocument = "xpath#//span[@id='fileUploadBtn']";
	public static String docName = "xpath#//span[text()='%file']";
	public static String caseDocument = "xpath#//span[@id='fileUploadBtn2']";
	public static String caseDocumentCheckBox = "xpath#//span[contains(@class,'lsmv-grid-row-sel-chk')]";
	public static String caseDocumentAdd = "xpath#//span[@id='selectCaseDocBtnId']";
	public static String caseDocumentClose = "xpath#(//span[text()='Close'])[2]";

	public static String ATDownloadBtn = "xpath#//button[@id='download']";
	public static String ATReportTxt = "xpath#(//div[text()='Audit Trail Report'])[2]";

	public static String caseNoteDocName_Hyperlink = "xpath#//label[text()='Attachment']/following::div//span[text()='%s']";

	public static String createNewVersionHeader = "xpath#//span[@id='ui-id-1']";
	public static String reasonDropdown = "xpath#//span[text()='Data Correction']";
	public static String otherOptions = "xpath#//li[text()='Others']";
	public static String submitNewVersion = "xpath#//a[@id='lbl_submit']";

	public static String dsurCountryVerification = "xpath#//tr[1]/td[contains(text(),'DSUR')]";

	// Followup questionnarie split screen
	public static String FUmsg = "xpath#//span[text()='Follow-Up questionnaire generated Successfully.']";
	public static String fuquestions = "xpath#//div[@id='divContainer']";
	public static String queryRelatedToSection = "xpath#//div[@class='lv-maincontent']//label[contains(text(),'%labelname%')]";
	public static String FUQuestionaManuallyMessage = "xpath#//div[@id='cnfDialogMain']//label";
	public static String popOkBtn = "xpath#//span[@class='lsmv-grid-btnbar-btn lsmv-button'][text()='Ok']";
	public static String questionAddCancelBtn = "xpath#//span[@class='lsmv-grid-btnbar-btn lsmv-button'][text()='Cancel']";
	public static String blankQuestionMsg = "xpath#//span[contains(text(),'Blank Follow up generated')]";

	public static String product = "Queries Related To Product/Drug";
	public static String event = "Queries On Event";
	public static String patient = "Queries Related To Patient";

	public static String splitIcon = "xpath#//span[@id='fullModeQ']";
	public static String addQuestiondropdown = "xpath#//select[@id='contextTabListID']";
	public static String questionSubmitBtn = "xpath#//span[@class='lsmv-grid-btnbar-btn lsmv-button'][text()='Submit']";
	public static String productAdd = "xpath#//span[@casequeid='DrugCollection:0']";
	public static String questionTextBox = "xpath#//textarea[@id='question']";
	public static String fieldid = "xpath#//select[@id='fieldID']";
	public static String questioanaddedmesg = "xpath#//span[text()='Question added successfully']";
	public static String questionAlreadyExistsMsg = "xpath#//div[@id='cnfDialogMain']//label";
	public static String questionExistsOkBtn = "xpath#//span[contains(@onclick,'okConf')]";
	public static String questionrewriteMsg = "xpath#//span[text()='Questionnaire rewrite successfully']";

	/**********************************************************************************************************
	 * @Objective: Below method is created to check the label for the query related
	 *             based on sections
	 * @Parameters: labelname
	 * @author: Pooja S
	 * @Date: 08-Apr-2021 Updated by and when
	 **********************************************************************************************************/
	public static String queryRelatedTo(String labelname) {
		String value = queryRelatedToSection;
		String value2;
		value2 = value.replace("%labelname%", labelname);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: Below method is created to build a locator to identify file name
	 *             link
	 * @Parameters: FileName
	 * @author: Shamanth S
	 * @Date: 01-Dec-2020 Updated by and when
	 **********************************************************************************************************/
	public static String caseNoteDocName(String fileName) {
		String value = caseNoteDocName_Hyperlink;
		String value2;
		value2 = value.replace("%s", fileName);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to check the checkbox for Override
	 * Reminder and Turn Off Reminder Input Parameters: text Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Pooja S Date :14-May-2020 Updated by and when
	 **********************************************************************************************************/

	public static String clickRadiobtn_Checkbox(String text) {
		String value = clickRadiobtn_checkbox;
		String value2;
		value2 = value.replace("%s", text);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to downLoad Reports by passing reports
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String downLoadReports(String runTimeLabel) {
		String value = reportsLink;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to moreOptions menu navigation passing
	 * link name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String moreOptions(String runTimeLabel) {
		String value = moreOptionsNavigation;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to Case Score menu navigation under
	 * More options passing link name at runtime. Input Parameters: ColumnName
	 * Scenario Name Output Parameters:
	 * 
	 * @author:Wajahat Umar S Date :23-03-2020 Updated by and when
	 **********************************************************************************************************/
	public static String CategoryDropdwonValue(String runTimeLabel) {
		String value = CategoryValue;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to Case Score menu Options under CAse
	 * SCore Navigations passing link name at runtime. Input Parameters: ColumnName
	 * Scenario Name Output Parameters:
	 * 
	 * @author:Wajahat Umar S Date :23-03-2020 Updated by and when
	 **********************************************************************************************************/
	public static String CaseScoreOptions(String runTimeLabel) {
		String value = CaseScoreOPtions;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to e2B Tag menu navigation under More
	 * options passing link name at runtime. Input Parameters: ColumnName Scenario
	 * Name Output Parameters:
	 * 
	 * @author:Wajahat Umar S Date :23-03-2020 Updated by and when
	 **********************************************************************************************************/
	public static String E2BTagsNavigation(String runTimeLabel) {
		String value = E2BTagsNavigationUnderMoreoptions;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to moreOptions menu navigation passing
	 * link name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Yashwanth Naidu Date :11-March-2020
	 **********************************************************************************************************/

	public static String moreAction(String runTimeLabel) {
		String value = moreActionNavigation;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;

	}

	/**********************************************************************************************************
	 * Objective:The below method is created to e2B More Options under E2B Tag sub
	 * Menu passing link name at runtime. Input Parameters: ColumnName Scenario Name
	 * Output Parameters:
	 * 
	 * @author:Wajah Umar S Date :23-03-2020 Updated by and when
	 **********************************************************************************************************/
	public static String E2BTagsMoreOptions(String runTimeLabel) {
		String value = E2BOPtionsCheckBoxes;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String NotesRctNum(String rctNum) {
		String value = NotesRecptNum;
		value = value.replace("%rctNum%", rctNum);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click User searched in Task creation
	 * modal
	 * 
	 * @author:Karthikeyan Natarajan Date :02-07-2020 Updated by and when
	 **********************************************************************************************************/
	public static String clickUserChkBox(String userName) {
		String value = userChkBox;
		value = value.replace("%userName%", userName);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click User searched in Task creation
	 * modal
	 * 
	 * @author:Karthikeyan Natarajan Date :02-07-2020 Updated by and when
	 **********************************************************************************************************/
	public static String auditTrialValidationElements(String validationElements) {
		String value = auditTrailValidationElements;
		value = value.replace("%validateElement%", validationElements);
		return value;
	}

	public static String clickDTDXSDDropDownValue(String data) {
		String value = setDTDXSDdropDownValue.replace("%s", data);
		return value;
	}

	public static String clickMHLWDropDownValue(String data) {
		String value = setMHLWdropDownValue.replace("%s", data);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select Category Dropdown value in
	 * Phone correspondance
	 * 
	 * @author:Karthikeyan Natarajan Date :11-11-2020 Updated by and when
	 **********************************************************************************************************/
	public static String PhoneCategoryDropdwonValue(String runTimeLabel) {
		String value = PhoneCategoryValue;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select valrious columns in
	 * corresspondance screen value
	 * 
	 * @author:Karthikeyan Natarajan Date :11-11-2020 Updated by and when
	 **********************************************************************************************************/
	public static String CorrespondanceScreenValue(String fieldId, int index) {
		String value = correspondanceScreen;
		String value2;
		value2 = value.replace("%fieldId", fieldId).replace("%index", index + "");
		return value2;

	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select Category Dropdown value in
	 * Phone correspondance
	 * 
	 * @author:Karthikeyan Natarajan Date :11-11-2020 Updated by and when
	 **********************************************************************************************************/
	public static String PageNoIcon(String runTimeLabel) {
		String value = PageIcon;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}
}