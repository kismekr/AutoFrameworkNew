package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class ReportsPageObjects {

	public static String reportsHover = "xpath#//span[contains(text(),'Reports')]";
	public static String batchPrintHover = "xpath#//li[@id='headerForm:batchPrintSubMenu']/a/span[@class='ui-menuitem-text'][contains(text(),'Batch print')]";
	public static String batchPrintListing = "xpath#//span[contains(text(),'Batch print listing')]";
	public static String batchPrintListingLabel = "xpath#//div[@id='listingForm:header']/label[text()='Batch Printing']";
	public static String batchPrintConfigurations = "xpath#//span[contains(text(),'Batch print configurations')]";
	public static String batchPrintConfigurationsLabel = "xpath#//span[@id='utilityConfigList:header']/label[text()='Batch Print Configurations']";
	public static String dataExport = "xpath#//span[contains(text(),'Data export')]";
	public static String cIOMSLLREPORT = "xpath#//span[contains(text(),'CIOMS LL Report')]";
	public static String dataExportLabel = "xpath#//div[@class='CaseList_Title']/label[text()='Data Export']";
	public static String charts = "xpath#//span[contains(text(),'Charts')]";
	public static String chartsLable = "xpath#//label[@id='reportchartlist:reportsListingLabel']";
	public static String standardReports = "xpath#//span[contains(text(),'Standard reports')]";
	public static String standardReportsLable = "xpath#//label[@id='reportslist:reportsListingLabel']";
	public static String caseManagement = "xpath#//a[@id='headerForm:aecriteriaId']//span[@class='ui-menuitem-text'][contains(text(),'Case Management')]";
	public static String caseManagementLable = "xpath#//span[@class='ui-panel-title']/label[text()='SEARCH CRITERIA']";
	public static String addresslables = "xpath#//span[contains(text(),'Address labels')]";
	public static String address = "xpath#//span[@class='ui-panel-title']/label[text()='General']";
	public static String operationalReports = "xpath#//span[contains(text(),'Operational reports')]";
	public static String workflowMetricsReport = "xpath#//span[contains(text(),'Workflow metrics report')]";
	public static String workflowMetricsReportLable = "xpath#//";
	public static String batchPrintKeywordSearch = "xpath#//input[@id='listingForm:searchCriteria']";
	public static String batchPrintConfigKeywordSearch = "xpath#//input[@id='utilityConfigList:searchText']";
	public static String dataExportKeywordSearch = "xpath#//input[@id='listingForm:searchCriteria']";

	public static String ciomsLLReportsKeywordSearch = "xpath#//input[contains(@title,'Report Name')]";
	public static String chartsKeywordSearch = "xpath#//input[@placeholder='Keyword Search'][@type='text']";
	public static String standardReportsKeywordSearch = "xpath#//input[@id='reportslist:keyword']";
	public static String caseManagementRecptNo = "xpath#//input[@id='aereportCriteriaForm:receiptNo']";
	public static String addressLabelsReceviDate = "xpath#//input[@id='custom_audit:receiveddate_input']";
	public static String productSalvageCompLatesDate = "xpath#//input[@id='salvageReportCriteriaForm:contactdateId_input']";
	public static String FDAManagementDateRangeFrom = "xpath#//input[@id='wfMetricsReportForm:contactdateId_input']";
	public static String productSalvageReports = "xpath#//span[contains(text(),'Product salvage reports')]";

	public static String StandardHover = "xpath#//li[@id='headerForm:standardId']/a/span[@class='ui-menuitem-text'][contains(text(),'Standard')]";
	public static String StandardAuditTrail = "xpath#//span[contains(text(),'Audit trial')]";
	public static String StandardAdminAuditTrail = "xpath#//span[contains(text(),'Admin audit trail')]";
	public static String AuditTrailVerification = "xpath#//label[@id='message_audit:messagetypeid_label']";
	public static String selectGenerateByReportName = "xpath#//tbody[@id='reportslist:reportDataTable_data']/tr/td/label[text()='{%s}']//preceding::td/a/img[@alt='Generate']";
	public static String auditTrialGenerateReportButton = "xpath#//button[contains(@id,'_audit:generatereportlabel')]";
	public static String messageTypeSelect = "xpath#//div[@id='message_audit:messagetypeid']";
	public static String messageTypeDropdown = "xpath#//div[@id='message_audit:messagetypeid_panel']/div/ul/li[@data-label='{%s}']";
	public static String paginationCheckPoint = "xpath#//div[@role='navigation'][@aria-label='Pagination']";
	public static String auditTrialCancel = "xpath#//button[@id='dirListId:closeButton']";
	public static String auditTrialBetweenFrom = "xpath#//input[@role='textbox'][@title='From ']";
	public static String auditTrialBetweenTo = "xpath#//input[@role='textbox'][@title='To']";
	public static String auditTrailToIcon = "xpath#//button[@type='button'][@title='To']";
	public static String operationType = "xpath#//label[@id='message_audit:operationtypeid_label']";
	public static String operationTypeDropdown = "xpath#//div[@id='message_audit:operationtypeid_panel']/div/ul/li[@data-label='{%s}']";
	public static String SectionType = "xpath#//div[@id='admin_audit:sectionid']";
	public static String SectionTypeDropDown = "xpath#//div[@id='admin_audit:sectionid_panel']/div/ul/li[@data-label='{%s}']";
	public static String userName = "xpath#//input[@id='message_audit:userid']";
	public static String downloadAsExcelBtn = "xpath#//span[text()='Download as Excel']";
	public static String msgTypeDropdown = "xpath#//label[@id='message_audit:messagetypeid_label']";
	public static String norecords = "xpath#//div[text()='No Data to export.']";
	public static String okBtn = "xpath#//button[@id='confirmPopupATOkBtn']";
	public static String UpdatedValue = "xpath#(//td[text()='PREFERENCE_VALUE']/following-sibling::td[text()='0'])[1]";

	// Reports->Audit Trail
	public static String Insert = "xpath#(//tr//td[text()='Insert'])[1]";
	public static String Delete = "xpath#(//tr//td[text()='Delete'])[1]";
	public static String Update = "xpath#(//tr//td[text()='Update'])[1]";

	public static String InsertOpeartionType = "xpath#(//td[text()='{%s}']/following-sibling::td[text()='Insert'])[1]/following-sibling::td[2]";
	public static String DeleteOpeartionType = "xpath#(//td[text()='{%s}']/following-sibling::td[text()='Delete'])[1]/following-sibling::td[1]";
	public static String UpdateOpeartionTypeOldValue = "xpath#(//td[text()='Update']/ancestor::tr//td[text()='{%s}'])[1]/following-sibling::td[text()='Update']/following-sibling::td[1]";
	public static String UpdateOpeartionTypeNewValue = "xpath#(//td[text()='Update']/ancestor::tr//td[text()='{%s}'])[1]/following-sibling::td[text()='Update']/following-sibling::td[2]";

	public static String MEDDRA_CODE = "MEDDRA_CODE";
	public static String MEDDRA_PT_TERM = "MEDDRA_PT_TERM";
	public static String SOC_NAME = "SOC_NAME";
	public static String ACTIVE = "ACTIVE";
	public static String ALWAYS_BROAD_NARROW = "ALWAYS_BROAD_NARROW";

	public static String IS_LABELED = "IS_LABELED";
	public static String LABELLED_COUNTRY = "LABELLED_COUNTRY";
	public static String STRENGTH = "STRENGTH";
	public static String STRENGTH_UNIT = "STRENGTH_UNIT";
	public static String AUTO_LABELLING_ACTIVE = "AUTO_LABELLING_ACTIVE";
	public static String PRODUCT_ACTIVE = "PRODUCT_ACTIVE";
	public static String LLT_CODE = "LLT_CODE";

	public static String downloadbtn = "xpath#//button[@id='dirListId:downloadReport']";

	// Audit trail Page object
	public static String auditInfo_Label = "xpath#//span[@id='auditForm:auditDialog_title'][text()='Audit Reason']";
	public static String auditreason_Textarea = "xpath#//textarea[@id='auditForm:auditReason']";
	// public static String submit_Btn =
	// "xpath#//button[@id='auditForm:auditSubmitButton']";
	public static String submit_Btn = "xpath#//button[contains(@onclick,'Submit')]";
	// public static String cancel_Btn =
	// "xpath#//button[contains(@id,'auditForm')]/span[text()='Cancel']";
	public static String cancel_Btn = "xpath#//button[contains(@onclick,'Cancel')]";
	public static String clickAuditReason_dropdwn = "xpath#//label[@id='auditForm:C-354_label']";
	// public static String clickAuditReason_dropdwn =
	// "xpath#//select[@id='auditTrialCode']";
	public static String clickDeleteAuditReason_dropdwn = "xpath#//label[@id='auditForm:C-9026_label']";
	public static String setDeleteDropdown_Auditreason = "xpath#//ul[@id='auditForm:C-9026_items']/li[contains(text(),'%s')]";
	public static String setDropdown_Auditreason = "xpath#//ul[@id='auditForm:C-354_items']/li[contains(text(),'%s')]";
	public static String productInfoMsg = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String prodOKbtn = "xpath#//button[@id='mandatoryDialogform:okButton']/span";
	public static String reconciliation = "xpath#//label[contains(text(),'Reconciliation')]/ancestor::tr//td//img[@id='reportslist:reportDataTable:3:editLink']";
	public static String sourceMediumDropdown = "xpath#//label[@id='reconciliationReport:schedularlabel'][text()='Source Medium']/ancestor::div[@class='ui-panelgrid-cell ui-g-12 ui-md-6']//div//label[contains(text(),'All')]";
	public static String setdropDownValue = "xpath#//ul[contains(@class,'ui-selectonemenu-items')]//li[contains(@class,'ui-selectonemenu-item')][contains(text(),'{0}')]";
	public static String processingDateFrom = "xpath#//button[@title='Processing Date From'][@type='button']";
	public static String processingDateTo = "xpath#//button[@title='Processing Date To'][@type='button']";
	public static String generateReportBtn = "xpath#//span[contains(text(),'Generate Report')]/ancestor::button[@id='reconciliationReport:generatereportlabel'][@type='submit']";
	public static String assertEmailSubject = "xpath#//label[@id='ReconciliationListing:schedularReportId:1:j_id_o7'][contains(text(),'{0}')]";
	public static String selectDay = "xpath#//td[@data-handler='selectDay']/a[.='{0}']";
	public static String receiptNo = "xpath#//label[@class='ui-outputlabel ui-widget'][contains(text(),'{0}')]/ancestor::tr[@role='row']//td/label[contains(.,'RCT')]";
	public static String BackButton = "xpath#//button[@name='ReconciliationListing:backLink']";
	public static String selectMonth = "xpath#//select[@class='ui-datepicker-month']";
	
	
	
	/**********************************************************************************************************
	 * @Objective: To select Generate by report type
	 * @InputParameters: Report Name
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 02-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectGenerateByReportName(String reportName) {
		String value1 = selectGenerateByReportName;
		String value2 = value1.replace("{%s}", reportName);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: To select Message type drop-down
	 * @InputParameters: Report Name
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 02-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String messageTypeDropdown(String messageTypeName) {
		String value1 = messageTypeDropdown;
		String value2 = value1.replace("{%s}", messageTypeName);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: To select Message type dropdown
	 * @InputParameters: Report Name
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 05-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String operationTypeDropdown(String messageTypeName) {
		String value1 = operationTypeDropdown;
		String value2 = value1.replace("{%s}", messageTypeName);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: To Verify Insert Fields in Table
	 * @InputParameters: Report Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :06-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String InsertOpeartionType(String ColumnName) {
		String value1 = InsertOpeartionType;
		String value2 = value1.replace("{%s}", ColumnName);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: To Verify Update-Old Value Fields in Table
	 * @InputParameters: Report Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :06-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String UpdateOpeartionTypeOldValue(String ColumnName) {
		String value1 = UpdateOpeartionTypeOldValue;
		String value2 = value1.replace("{%s}", ColumnName);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: To Verify Update-New Value Fields in Table
	 * @InputParameters: Report Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :06-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String UpdateOpeartionTypeNewValue(String ColumnName) {
		String value1 = UpdateOpeartionTypeNewValue;
		String value2 = value1.replace("{%s}", ColumnName);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: To Verify Update-New Value Fields in Table
	 * @InputParameters: Report Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :06-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String DeleteOpeartionType(String ColumnName) {
		String value1 = DeleteOpeartionType;
		String value2 = value1.replace("{%s}", ColumnName);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: To Verify Update-New Value Fields in Table
	 * @InputParameters: Report Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :06-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String SectionTypeDropDown(String ColumnName) {
		String value1 = SectionTypeDropDown;
		String value2 = value1.replace("{%s}", ColumnName);
		return value2;
	}

	public static String getReceiptNo(String labelName) {
		String xpath = receiptNo;
		String value = null;
		value = xpath.replace("{0}", labelName);
		return value;
	}

	public static String selectDay(String labelName) {
		String xpath = selectDay;
		String value = null;
		value = xpath.replace("{0}", labelName);
		return value;
	}

	public static String selectSource(String labelName) {
		String xpath = setdropDownValue;
		String value = null;
		value = xpath.replace("{0}", labelName);
		return value;
	}
	
}
