package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

//import org.openqa.selenium.By;

public class TemplatesPageObjects {
	
	public static String templatesHover = "xpath#//span[contains(text(),'Templates')]";
	public static String templatesNew = "xpath#//a[@id='headerForm:tempNewId']";
	public static String templateID = "xpath#//input[@id='templateNewForm:tempId']";
	public static String templatesNewLable = "xpath#//span[@class='ui-panel-title']/label[text()='Template Details']";
	public static String templatesListing = "xpath#//a[@id='headerForm:tempListId']//span[@class='ui-menuitem-text'][contains(text(),'Listing')]";
	public static String basicsearchTextbox = "xpath#//input[@id='templateForm:searchFieldId']";
	public static String templatesListingLable = "xpath#//div[@id='templateForm:templateTitleId']/label[text()='All Templates']";
	public static String templatesNotification = "xpath#//a[@id='headerForm:tempnotId']/span[text()='Notifications']";
	public static String NotificationbasicsearchTextbox = "xpath#//input[@id='templateForm:searchFieldId']";
	public static String templatesNotificationLable = "xpath#//div[@id='templateForm:templateTitleId']/label[text()='Template Notification']";
	public static String templatesCancelBtn = "xpath#//button[@id='templateNewForm:cancelId']";
	public static String resultCount = "xpath#//button[@id='templateNewForm:cancelId']";
	public static String TemplateNameRow(int row) {
		return "xpath#//div[@id='ruleBuilderListform:rulesDataTable']//table//tbody/tr[" + Integer.toString(row) + "]//span[contains(@id,'ruleType')]";
	}
	public static String templatesRows = "xpath#//div[@id='templateForm:gridView']//div[@class='ui-grid-row']";
	public static String templateEditName(int row) {
		return "xpath#//div[@id='templateForm:gridView']//div[" + Integer.toString(row) + "][@class='ui-grid-row']//a[contains(@id,'viewTemplateName')]";
	}
	public static String templateEditLink(int row) {
		return "xpath#//div[@id='templateForm:gridView']//div[" + Integer.toString(row) + "][@class='ui-grid-row']//a[contains(@id,'editLinkGrid')]";
	}
	
	//ANG Templates Listing
		public static String listANG_breadCrumb = "xpath#//div[@class='ui-g-12 angListingBreadCrumbSty']/label[text()='ANG Listing']";
		
		public static String templatesANGHover = "xpath#//li[@id='headerForm:angAdminId']/a/span[text()='Ang']";
		public static String templatesANGListingHover = "xpath#//li/a[@id='headerForm:angAdminListingId']/span[text()='Listing']";
		public static String templateRecord_Label = "xpath#//td[contains(text(),'%s')]";
		public static String recordsANGListing_ChkBx = "xpath#//td[contains(text(),'%s')]/preceding-sibling::td[@class=' select-checkbox angcheckBox']";
		public static String recordsANGListing_EditIcon = "xpath#//td[contains(text(),'%s')]/preceding-sibling::td[@class='thangEdit sorting_1']/a/span";
		
		public static String treeNodeGeneral = "xpath#//li/a[text()='General']";
		public static String treeNodeGeneralExpand_icon = "xpath#//div[@id='treeId']/ul/li[@id='a2']/i";
		public static String expandAll_Btn = "xpath#//div[@class='headerBtn']/input[text()='Expand All']";
		public static String insertNewNode = "xpath#//li/a[text()='insert child']";
		public static String deleteNode = "xpath#//li/a[text()='Delete']";
		public static String newTreeNode = "xpath#(//a[@class='jstree-anchor'][text()='New Folder'])[1]";
		public static String newCustomTreeNode = "xpath#(//a[@class='jstree-anchor'][text()='%s'])[1]";
		public static String newTreeNode_Sentence = "xpath#(//a[text()='New Folder']/../ul/li/a[text()='New Sentence'])[1]";
		
		public static String treeNodeParagraphName_TextArea = "xpath#//div/input[@id='sentenceName']";
		public static String treeNodeParagraph_TextArea = "xpath#//div[@class='ang-tem-name']/textarea[@id='angInputArea']";
		public static String save_Btn = "xpath#//div[@class='headerBtn']/input[text()='Save']";
		
		public static String acknowledgementWin_Title = "xpath#//div[contains(@class,'ui-dialog-titlebar')]/span[@id='ui-id-1']";
		public static String acknowledgementWin_InfoText = "xpath#//div[@class='angInfoSty']/label";
		public static String acknowledgementWin_OKBtn = "xpath#//div[@class='angMandSty']/button[text()='Ok']";
		
		/**********************************************************************************************************
		 * @Objective: The below method is created to select the name of
		 *             specified record by passing template name at runtime.
		 * @InputParameters: Template Name
		 * @OutputParameters: Return's dynamic xpath
		 * @author: Shamanth S
		 * @Date : 20-Nov-2020
		 * @UpdatedByAndWhen:
		 **********************************************************************************************************/
		public static String labelANGTemplate_Locator(String templateName) {
			String value = templateRecord_Label;
			String value2;
			value2 = value.replace("%s", templateName);
			return value2;
		}
		
		/**********************************************************************************************************
		 * @Objective: The below method is created to select the checkbox of
		 *             specified record by passing template name at runtime.
		 * @InputParameters: Template Name
		 * @OutputParameters: Return's dynamic xpath
		 * @author: Shamanth S
		 * @Date : 20-Nov-2020
		 * @UpdatedByAndWhen:
		 **********************************************************************************************************/
		public static String selectANGTemplate_Locator(String templateName) {
			String value = recordsANGListing_ChkBx;
			String value2;
			value2 = value.replace("%s", templateName);
			return value2;
		}
		
		/**********************************************************************************************************
		 * @Objective: The below method is created to click on the edit icon of
		 *             specified record by passing template name at runtime.
		 * @InputParameters: Template Name
		 * @OutputParameters: Return's dynamic xpath
		 * @author: Shamanth S
		 * @Date : 20-Nov-2020
		 * @UpdatedByAndWhen:
		 **********************************************************************************************************/
		public static String editANGTemplate_Locator(String templateName) {
			String value = recordsANGListing_EditIcon;
			String value2;
			value2 = value.replace("%s", templateName);
			return value2;
		}
		
		/**********************************************************************************************************
		 * @Objective: The below method is created to click on the edit icon of
		 *             specified record by passing template name at runtime.
		 * @InputParameters: Template Name
		 * @OutputParameters: Return's dynamic xpath
		 * @author: Shamanth S
		 * @Date : 20-Nov-2020
		 * @UpdatedByAndWhen:
		 **********************************************************************************************************/
		public static String customParagraphNode(String paraGraphName) {
			String value = newCustomTreeNode;
			String value2;
			value2 = value.replace("%s", paraGraphName);
			return value2;
		}
	
}
