package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FollowUpRulesPageObjects {
	
	
	public static String newbtn = "xpath#//a[@id='ruleBuilderListform:newId']";
	public static String ruleKeyword_Textbox = "xpath#//input[@id='ruleBuilderListform:keywordSearch']";
	public static String edit_Icon = "xpath#//img[@id='ruleBuilderListform:rulesDataTable:0:editImgId']";
	public static String rulesearch_Icon = "xpath#//img[contains(@id,'ruleBuilderListform')][contains(@src,'search_icon')]";
	public static String paginator = "xpath#//div[@id='ruleBuilderListform:rulesDataTable_paginator_top']";
	public static String questionaryconditiondel = "xpath#//a[@id='ruleDetailsForm:deleteRuleCondition2']";
	public static String ruleconditiondel = "xpath#//a[@id='ruleDetailsForm:deleteRuleCondition']";
	public static String deletevalidation_popup = "xpath#//label[text()='Are you sure you want to delete the selected Condition ?']";
    public static String deleteyesbtn = "xpath#//button[@id='ruleDetailsForm:delVetCutomRuleConfirmId1']";
    public static String get_listofRuleName = "xpath#//tbody[@id='ruleBuilderListform:rulesDataTable_data']/ancestor::table/tbody/tr/td[4]";
    public static String columnHeader = "xpath#(//tbody[@id='ruleBuilderListform:rulesDataTable_data']/ancestor::table/tbody/tr/td[4])[{%count}]";
    
    // Basic Details //
	public static String ruleName = "xpath#//input[@id='ruleDetailsForm:ruleName']";
	public static String module_Dropdown = "xpath#//label[@id='ruleDetailsForm:ruleModule_label']";
	public static String active = "Active";
	public static String standardRule = "Standard Rule";
	public static String formLibrary = "Form Library";
	public static String fieldLibrary = "Field Library";
	public static String methodLibrary = "Method Library";
	public static String basicRules = "Basic Rules";
	public static String criteriaBuilderRules = "Criteria Builder Rules";
	public static String scriptedRules = "Scripted Rules";
	public static String displayE2BR2Tag = "Display E2B R2 Tag";
	public static String displayE2BR3Tag = "Display E2B R3 Tag";
	public static String doNotRegenerateRuleScript = "Do Not Regenerate Rule Script";
	public static String alwaysExecute = "Always Execute";
	public static String formName_Dropdown = "xpath#//label[@id='ruleDetailsForm:formList1_label']";
	public static String descriptiontextbox = "xpath#//textarea[@id='ruleDetailsForm:ruleDescription']";
	
	// Rules //
	public static String ruleContext_Dropdown = "xpath#//label[@id='ruleDetailsForm:ruleCContextList_label']";
	public static String rulecontext_General = "xpath#";
	public static String rulefield_Dropdown = "xpath#//label[@id='ruleDetailsForm:ruleFieldList_label']";
	public static String ruleCompare_Dropdown = "xpath#//label[@id='ruleDetailsForm:compareDropDown_label']";
	public static String isCaseSensitive = "Is Case Sensitive";
	public static String isEmptyCheck = "Is Empty Check";
	public static String ruleValue_textbox = "xpath#//input[@id='ruleDetailsForm:IRTTextfield']";
	public static String addToRuleBtn1 = "xpath#//button[@id='ruleDetailsForm:addToRuleButton']";
	
	
	// Questionnaires //
	public static String questionnariecontext_dropdown = "xpath#//label[@id='ruleDetailsForm:ruleCContextList2_label']";
	public static String clickAlldropdownvalue = "xpath#//label[@id='ruleDetailsForm:%label%_label']";
	public static String comparedropdown = "compareDropDown2";
	public static String fielddropdown = "ruleFieldList2";
	public static String contextdropdown = "ruleCContextList2";
	public static String selectAlldropdownvalue = "xpath#//ul[contains(@id,'%label%')]/li[text()='%s']";
	public static String questionId_icon = "xpath#//img[contains(@src,'Lookup_Selection')][contains(@id,'ruleDetailsForm')]";
	public static String questionnarielookup_label = "xpath#//span[text()='Questionnaires Lookup']";
	public static String questionName_filter = "xpath#(//label[text()='Filter by Question Name']/following::input)[1]";
	public static String question_checkbox = "xpath#(//th[contains(@id,'QuestionaryLookupForm:questionTable')]/div/div/following::div/span)[1]";
	public static String question_OkBtn = "xpath#//button[@id='QuestionaryLookupForm:okBtn2']";
	public static String addToRuleBtn2 = "xpath#//button[@id='ruleDetailsForm:addToRuleButton2']";
	public static String validationmsg = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String saveokbtn = "xpath#//button[@id='mandatoryDialogform:okButton']";
	public static String savebtn = "xpath#//button[@id='ruleDetailsForm:visibleSave']";
	public static String cancelbtn = "xpath#//button[@id='ruleDetailsForm:cancelId']";
	
	/**********************************************************************************************************
	 * Objective:The below method is created to click Context,Field,Compare and Show DropDown in
	 * Followup Rules screen by passing value at runtime and text value. Input Parameters: label
	 * name Scenario Name Output Parameters:
	 * 
	 * @author:Pooja S Date :12-May-2020 Updated by and when
	 **********************************************************************************************************/
	public static String clickDropDown(String runTimeLabel) {
		String value = clickAlldropdownvalue;
		String value2;
		value2 = value.replace("%label%", runTimeLabel);
		return value2;
	}
	
	/**********************************************************************************************************
	 * Objective:The below method is created to click Context,Field,Compare and Show DropDown in
	 * Followup Rules screen by passing value at runtime and text value. Input Parameters: ColumnName
	 * Scenario Name Output Parameters:
	 * 
	 * @author:Pooja S Date :12-May-2020 Updated by and when
	 **********************************************************************************************************/
	public static String selectDropdown(String runTimeLabel,String text) {
		String value = selectAlldropdownvalue;
		String value2;
		String value1 = value.replace("%label%", runTimeLabel);
		value2 = value1.replace("%s", text);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective:get substance name by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:Pooja S Date :12-May-2020 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderList(String num) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}