package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import org.openqa.selenium.By;

public class SourceTabPageObjects {
	
	public static String senderLookup = "xpath#//img[contains(@src,'../../images/Lookup_Selection.svg')]";
	public static String searchButton = "xpath#//span[@class='ui-button-text ui-clickable'][contains(text(),'Search')]";
	public static String cancelButton = "xpath#//span[@class='ui-button-text ui-clickable'][contains(text(),'Cancel')]";
	public static String data = "xpath#//p-table[@datakey='partnerId']//tbody[@class='ui-table-tbody']/tr";
}
