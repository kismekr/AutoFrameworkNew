package com.arisglobal.framework.components.lsmv.L10_1_1;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.Admin_CentralCodingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AdministrationCompanyUnitPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ApplicationParameterPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_PregnancyPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Administration_CentralCoding extends ToolManager {

	static String className = Administration_CentralCoding.class.getSimpleName();
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to set MedDRA Version in use in central coding.
	 * @InputParameters: Scenario Name
	 * @OutputParameters: 
	 * @author: Avinash k
	 * @Date : 28-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setMedDRAVersion(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		SystemAdministrationOperations.systemAdministrationNavigations("applicationParameters");
		agClick(ApplicationParameterPageObjects.clickLink(ApplicationParameterPageObjects.centralcodeing_Link));
		agIsVisible(Admin_CentralCodingPageObjects.codingMatchOrder_Label);
		agClick(Admin_CentralCodingPageObjects.setcodingMatchOrder(getTestDataCellValue(scenarioName, "CodingMatchOrder")));
		CommonOperations.setListDropDownValue(Admin_CentralCodingPageObjects.medDRAVersioninuse_Drpdown,
				getTestDataCellValue(scenarioName, "MedDRAVersioninuse"));
		agJavaScriptExecuctorClick(Admin_CentralCodingPageObjects.save_Btn);
		agSetStepExecutionDelay("8000");
		Reports.ExtentReportLog("", Status.INFO, "MedDRAVersion updated to::"+getTestDataCellValue(scenarioName, "MedDRAVersioninuse"), true);
		agJavaScriptExecuctorClick(Admin_CentralCodingPageObjects.ok_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: label, scenarioName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDownValue(String label, String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_PregnancyPageObjects.click_DropDown(label));
			agClick(FDE_PregnancyPageObjects.setdropDownValue(getTestDataCellValue(scenarioName, columnName)));

		}
	}
	
	}
	



