package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class RuleBuilderBFCRules_PageObjects {

	/////// Administration> Application Configurations> Rule Builder ////////

	public static String edit_Btn = "xpath#//tbody[@id='ruleBuilderListform:rulesDataTable_data']/tr/td[4]/span[text()='%RuleName%']/preceding::td[2]/a/img";
	public static String new_Btn = "xpath#//a[@id='ruleBuilderListform:newId']";
	public static String delete_Btn = "xpath#//a[@id='ruleBuilderListform:deleteRules']";
	public static String copy_Btn = "xpath#//a[@id='ruleBuilderListform:copyRules']";
	public static String cancel_Btn = "xpath#//a[@id='ruleBuilderListform:cancelList']";
	public static String regenerateRule_Btn = "xpath#//a[@id='ruleBuilderListform:ruleRegenId']";
	public static String search_TextBox = "xpath#//input[@id='ruleBuilderListform:keywordSearch']";
	public static String search_Icon = "xpath#//a[@id='ruleBuilderListform:searchId']/img";

	public static String ruleName_TextBox = "xpath#//input[@id='ruleDetailsForm:ruleName']";
	public static String module_Dropdown = "xpath#//label[@id='ruleDetailsForm:ruleModule_label']";
	public static String description_Textbox = "xpath#//textarea[@id='ruleDetailsForm:ruleDescription']";
	public static String active_Label = "Active";
	public static String standardRule_Label = "";
	public static String formLibrary_Label = "Form Library";
	public static String fieldLibrary_Label = "Field Library";
	public static String methodLirary_Label = "Method Library";
	public static String basicRules_Label = "Basic Rules";
	public static String criteriaBuilderRules_Label = "Criteria Builder Rules";
	public static String radioBtn = "xpath#//label[starts-with(normalize-space(text()),'{0}')]/../descendant::div[contains(@class,'ui-radiobutton-box')]";
	public static String e2bXMLType_Dropdown = "xpath#//label[@id='ruleDetailsForm:xmlTypeMenu_label']";
	public static String BFCPhase_Dropdown = "xpath#//label[@id='ruleDetailsForm:bfcPhasemenu_label']";
	public static String dropDownListItem = "xpath#//div[@id='%locator%_panel']//label[text()='%text%']";
	public static String R2toR3methods_Dropdown = "xpath#//label[@id='ruleDetailsForm:javamethodDefaultRules_label']";
	public static String R3toR2methods_Dropdown = "xpath#//label[@id='ruleDetailsForm:rolldownMethods_label']";
	public static String save_Btn = "xpath#//button[@id='ruleDetailsForm:visibleSave']";
	public static String CancelInEdit_Btn = "xpath#//button[@id='ruleDetailsForm:cancelId']";

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit the Rule name
	 * @InputParameters: count
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 28-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String clickEdit(String text) {
		String value = edit_Btn;
		String value1 = value.replace("%configName%", text);
		return value1;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the radio button under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Pooja S
	 * @Date : 28-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String radioButton(String radioBtnLabel) {
		String actualLocator = radioBtn;
		String value = actualLocator.replace("{0}", radioBtnLabel.trim());
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to generate xpath based on locator
	 *             and value to select from dropdown inlcuding the checkbox.
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Pooja S
	 * @Date : 16-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectListDropDown(String locator, String valueToSelect) {
		String xpath[] = locator.split("'");
		String resLocator = xpath[1].replace("_label", "");
		String actualLocator = dropDownListItem;
		String tempLocator = actualLocator.replace("%text%", valueToSelect);
		String resultLocator = tempLocator.replace("%locator%", resLocator);
		return resultLocator;
	}
	
	
	//Locators added to cover ISP-V0007 scenario
	public static String ruleBuilderEdit_Icon = "xpath#//tbody/tr/td/span[text()='{0}']/preceding::td[1]/a/img";
	public static String ruleBuilder_BreadCrumb = "xpath#//div[@id='ruleBuilderListform:header']/label[text()='Rule Builder']";
	
	public static String ruleEdit_Icon = "xpath#//tbody[@id='ruleBuilderListform:rulesDataTable_data']/tr/td/span[text()='{0}']/preceding::td[2]/a/img";
	

	public static String confirmationWinTitle = "xpath#//div/span[@id='mandatoryDialogform:mandatoryID_title']";
	public static String confirmationWinInfo_Text = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String confirmationWinOK_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']/span";
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to generate xpath based on locator
	 *             on passing valid/available RuleBuilderName.
	 * @InputParameters: RuleBuilderName
	 * @OutputParameters: Return's dynamic xpath
	 * @author: Shamanth S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectBuilderEditIcon(String ruleBuilderName) {
		String actualLocator = ruleBuilderEdit_Icon;
		String value = actualLocator.replace("{0}", ruleBuilderName.trim());
		return value;
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to generate xpath based on locator
	 *             on passing valid/available RuleName.
	 * @InputParameters: RuleName
	 * @OutputParameters: Return's dynamic xpath
	 * @author: Shamanth S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectRuleEditIcon(String ruleName) {
		String actualLocator = ruleEdit_Icon;
		String value = actualLocator.replace("{0}", ruleName.trim());
		return value;
	}
}
