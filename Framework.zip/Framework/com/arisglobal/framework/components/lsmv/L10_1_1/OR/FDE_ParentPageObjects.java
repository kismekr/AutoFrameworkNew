package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FDE_ParentPageObjects {

	// Parent Information

	public static String click_DropDown = "xpath#//label[@style='visibility: visible;'][contains(text(),'{0}')]/parent::span//p-dropdown[not (contains(@styleclass,'agNfDropdown'))]/div";
	public static String embedclick_DropDown = "xpath#//label[contains(text(),'%s')]/parent::span//p-dropdown[not (contains(@styleclass,'agNfDropdown'))]/div";
	public static String setdropDownValue = "xpath#//ul[contains(@class,'ui-dropdown-items')]/child::li/div/span[contains(text(),'{0}')]";
	public static String parentID_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentInfoTable:idN10529110102']";
	public static String parentDOB_Datefield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentInfoTable:parentDateBirth:impcalinput']";
	public static String parentAge_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentInfoTable:idN1054F110106']";
	public static String lmpofParent_Datefield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentInfoTable:lmpdateParent:impcalinput']";
	public static String parentWeight_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentInfoTable:idN1055F110111']";
	public static String parentHeight_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentInfoTable:idN1056D110113']";
	public static String parentMedicalHistorytext_Textarea = "xpath#//textarea[@id='adverseEventNew:parentPanelTable:parentInfoTable:956104']";
	public static String parentAgeUnit_Getvalue = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentInfoTable:A1-1009_focus']/ancestor::p-dropdown/div/label";
	public static String parentWeightUnit_Getvalue = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentInfoTable:idN1055F110254']/ancestor::p-dropdown/div/label";
	public static String parentHeightUnit_Getvalue = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentInfoTable:idN1056D110253']/ancestor::p-dropdown/div/label";
	public static String parentGender_Getvalue = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentInfoTable:parentSex-1007_focus']/ancestor::p-dropdown/div/label";
	public static String ethnicOrigin_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentInfoTable:parEthnicOrigin']";
	public static String ethnicOrigin_Getvalue = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentInfoTable:parEthnicOrigin']/ancestor::p-dropdown/div/label";

	// Parent Medical History

	public static String parentMedicalHistory_Label = "xpath#//label[starts-with(text(),'Parent Medical History Text')]";
	public static String pmh_FormView = "xpath#//label[text()='Parent Medical History']//..//a[text()='Form View']";
	public static String reportedDiseaseTerm_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentMedHistTable:idN105C9120204']";
	public static String medDRALLTCODEDiseaseTerm_lookup = "xpath#(//label[text()='MedDRA LLT CODE for Disease Term (Parent)']/ancestor::div/span/a)[1]";
	public static String dictionaryCodingBrowser_SearchTxtfield = "xpath#//input[@name='term']";
	public static String dictionaryCodingBrowser_SearchBtn = "xpath#//button/span[text()='Search']";
	public static String dictionaryCodingBrowser_OkBtn = "xpath#//div[contains(@class,'searchOkbtn')]/button/span[text()='OK']";
	public static String medDRAPTCODEDiseaseTerm_Txtfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentMedHistTable:medicalEpisodePtMeddraCode']";
	public static String startDate_Datefield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentMedHistTable:DPN10330_DP_120107:impcalinput']";
	public static String endDate_Datefield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentMedHistTable:DPN10330_DP_120110:impcalinput']";
	public static String comments_Textfield = "xpath#//textarea[@id='adverseEventNew:parentPanelTable:parentMedHistTable:idN1061E120111']";
	public static String continuing_radioBtn = "xpath#//label[text()='Continuing']/ancestor::div//p-radiobutton/label[text()='%s']";
	public static String get_medDRALLTCODEDiseaseTerm = "xpath#//label[text()='MedDRA LLT CODE for Disease Term (Parent)']/ancestor::div/span/a[@styleclass='agMedraTooltipLink']";
	public static String duration_Txtfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentMedHistTable:duration']";
	public static String durationUnit_Getvalue = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentMedHistTable:durationUnit']/ancestor::p-dropdown/div/label";
	public static String codingTypeUnit_Getvalue = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentInfoTable:codingType']/ancestor::p-dropdown/div/label";

	// Parent Past Therapy

	public static String ppt_FormView = "xpath#//label[text()='Parent Past Therapy']//..//a[text()='Form View']";
	public static String productDescriptionAsReported_Lookup = "xpath#//label[text()='Product Description as reported']/ancestor::div/span/a";
	public static String productDescriptionAsReported_Getvalue = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:idN10679121102']";
	public static String medicinalProductIdentifierMPID_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:parentMpid']";
	public static String mPIDVersionDateNumber_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:parentMpidDate-121118']";
	public static String phPID_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:parentPhpid']";
	public static String phPIDVersionDateNumber_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:parentPhpidDate-121119']";
	public static String therapyStartDate_datefield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:DPN10330_DP_121105:impcalinput']";
	public static String therapyEndDate_datefield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:DPN10330_DP_121107:impcalinput']";
	public static String indicationTerm_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:idN106B6121110']";
	public static String medDRALLTCODEIndicationTerm_Lookup = "xpath#//label[text()='MedDRA LLT CODE for Indication Term (Parent)']/ancestor::div/span/a";
	public static String medDRAPTCODEIndicationTerm_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:idN106D4121264']";
	public static String medDRALLTCODEIndicationTerm_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:indicationTermParentMeddraLltCode']";
	public static String reactionTerm_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:idN106D4121114']";
	public static String medDRALLTCODEReactionTerm_Lookup = "xpath#//label[text()='MedDRA LLT CODE for Reaction Term (Parent)']/ancestor::div/span/a";
	public static String medDRAPTCODEForReactionTerm_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:idN106D4121265']";
	public static String medDRALLTCODEForReactionTerm_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:reactionTermParentMeddraLltCode']";

	public static String inventedName_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:parentInventedName']";
	public static String scientificName_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:parentScientificName']";
	public static String trademarkName_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:parentTradeMarkName']";
	public static String strengthName_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:parentStrengthName']";
	public static String formName_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:parentFormName']";
	public static String containerName_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:parentContainerName']";
	public static String deviceName_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:parentDeviceName']";
	public static String intendedUseName_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:parentIntendedUseName']";
	public static String get_MedDRALLTCODEIndicationTerm = "xpath#//label[text()='MedDRA LLT CODE for Indication Term (Parent)']/ancestor::div/span/a[@styleclass='agMedraTooltipLink']";
	public static String get_MedDRALLTCODEReactionTerm = "xpath#//label[text()='MedDRA LLT CODE for Reaction Term (Parent)']/ancestor::div/span/a[@styleclass='agMedraTooltipLink']";

	// Past Therapy Substances
	public static String substanceSpecifiedSubstanceName_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastSubstancePanelDataTable:parentSubstanceName']";
	public static String substanceTermIDVerDateNum_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastSubstancePanelDataTable:parentSubstanceTermidVersion']";
	public static String substanceSpecifiedSubstanceTermID_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastSubstancePanelDataTable:parentSubstanceTermid']";
	public static String strength_Textfield = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastSubstancePanelDataTable:parentSubstanceStrengthNumber']";
	public static String strengthUnit_Getvalue = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastSubstancePanelDataTable:parentSubstanceStrengthUnit-1018_focus']/ancestor::p-dropdown/div/label";

	public static String medDRALLTCODEIndicationTerm = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:indicationTermParentMeddraLltCode']";
	public static String medDRALLTCODEForReactionTerm = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentPastTherpPanelTable:parentPastTherpTable:reactionTermParentMeddraLltCode']";
	public static String medDRALLTCODEForDiseaseTerm = "xpath#//input[@id='adverseEventNew:parentPanelTable:parentMedHistTable:medicleEpisodeMeddraLltCode']";

	// Product Lookup
	public static String productNameTextbox = "xpath#//label[contains(text(),'Product Name')]/ancestor::div/input[@type='text']";
	public static String searchButton = "xpath#//span[contains(text(),'Search')]/ancestor::button";
	public static String okButton = "xpath#//button[@type='button']/span[text()='OK']";
	public static String productLibray_RadioBtn = "xpath#//label[text()='Product Library']/ancestor::p-radiobutton/div/child::div/span";
	public static String product_RadioBtn = "xpath#//*[starts-with(normalize-space(text()),'%s')]/ancestor::tr/td/descendant::div/span[contains(@class, 'ui-radiobutton-icon')]";

	public static String productEmdedDropdownSelect = "xpath#//label[contains(text(),'{0}')]/ancestor::span/span/p-dropdown/div[not(contains(@class,'agNfDropdown'))]";

	// Label Names

	public static String ethnicOrigin_DropDown = "Ethnic origin ";
	public static String parentHeight_DropDown = "Parent Height";
	public static String strength_DropDown = "Strength (number)";
	public static String parentWeight_DropDown = "Parent Weight";
	public static String parentAge_DropDown = "Parent age";
	public static String parentGender_DropDown = "Parent Gender";
	public static String duration_DropDown = "Duration";
	public static String codingType_DropDown = "Coding Type ";

//R2 tags
	public static String R2ParentId = "xpath#//label[text()='[B.1.10.1]']";
	public static String R2ParentDOB = "xpath#//label[text()='[B.1.10.2.1b]']";
	public static String R2PArentAge = "xpath#//label[text()='[B.1.10.2.2a/b]']";
	public static String R2ParentGender = "xpath#//label[text()='[B.1.10.6]']";
	public static String R2LMPOfParent = "xpath#//label[text()='[B.1.10.3b]']";
	public static String R2ParentWeight = "xpath#//label[text()='[B.1.10.4]']";
	public static String R2ParentHeight = "xpath#//label[text()='[B.1.10.5]']";
	public static String R2ParentMedicalHistoryText = "xpath#//label[text()='[B.1.10.7.2]']";
	public static String R2ReportedDiseaseTerm_Parent = "xpath#//label[text()='[B.1.10.7.1a.2]']";
	public static String R2StartDate = "xpath#//label[text()='[B.1.10.7.1c]']";
	public static String R2EndDate = "xpath#//label[text()='[B.1.10.7.1f]']";
	public static String R2Continuing = "xpath#//label[text()='[B.1.10.7.1d]']";
	public static String R2Comments = "xpath#//label[text()='[B.1.10.7.1g]']";
	public static String R2ProductNameAsReported = "xpath#//label[text()='[B.1.10.8a]']";
	public static String R2PPTStartDate = "xpath#//label[text()='[B.1.10.8c]']";
	public static String R2PPTEndDate = "xpath#//label[text()='[B.1.10.8e]']";
	public static String R2IndicationTerm = "xpath#//label[text()='[B.1.10.8f.2]']";
	public static String R2ReactionTerm = "xpath#//label[text()='[B.1.10.8g.2]']";
	
	//R3 Tags 
	public static String R3ParentId = "xpath#//label[text()='[D.10.1]']";
	public static String R3ParentDOB = "xpath#//label[text()='[D.10.2.1]']";
	public static String R3PArentAge = "xpath#//label[text()='[D.10.2.2a/b]']";
	public static String R3ParentGender = "xpath#//label[text()='[D.10.6]']";
	public static String R3LMPOfParent = "xpath#//label[text()='[D.10.3]']";
	public static String R3ParentWeight = "xpath#//label[text()='[D.10.4]']";
	public static String R3ParentHeight = "xpath#//label[text()='[D.10.5]']";
	public static String R3ParentMedicalHistoryText = "xpath#//label[text()='[D.10.7.2]']";
	public static String R3MedDRALLTCODEForDiseaseTerm_Parent = "xpath#//label[text()='[D.10.7.1.r.1b]']";
	public static String R3StartDate = "xpath#//label[text()='[D.10.7.1.r.2]']";
	public static String R3EndDate = "xpath#//label[text()='[D.10.7.1.r.4]']";
	public static String R3Continuing = "xpath#//label[text()='[D.10.7.1.r.3]']";
	public static String R3Comments = "xpath#//label[text()='[D.10.7.1.r.5]']";
	public static String R3ProductNameAsReported = "xpath#//label[text()='[D.10.8.r.1]']";
	public static String R3MedicinalProductIdentifier_MPID = "xpath#//label[text()='[D.10.8.r.2b]']";
	public static String R3MPIDVersionDate_Number= "xpath#//label[text()='[D.10.8.r.2a]']";
	public static String R3PhPIDVersionDate_Number = "xpath#//label[text()='[D.10.8.r.3a]']";
	public static String R3PhPID = "xpath#//label[text()='[D.10.8.r.3b]']";
	public static String R3PPTStartDate = "xpath#//label[text()='[D.10.8.r.4]']";
	public static String R3PPTEndDate = "xpath#//label[text()='[D.10.8.r.5]']";
	public static String R3MedDRALLTCODEForIndicationTerm_Parent = "xpath#//label[text()='[D.10.8.r.6b]']";
	public static String R3MedDRALLTCODEForReactionTerm_Parent = "xpath#//label[text()='[D.10.8.r.7b]']";
	public static String R3InventedName = "xpath#//label[text()='[D.10.8.r.1.EU.1]']";
	public static String R3ScientificName = "xpath#//label[text()='[D.10.8.r.1.EU.2]']";
	public static String R3TrademarkName = "xpath#//label[text()='[D.10.8.r.1.EU.3]']";
	public static String R3StrengthName = "xpath#//label[text()='[D.10.8.r.1.EU.4]']";
	public static String R3FormName = "xpath#//label[text()='[D.10.8.r.1.EU.5]']";
	public static String R3ContainerName = "xpath#//label[text()='[D.10.8.r.1.EU.6]']";
	public static String R3DeviceName = "xpath#//label[text()='[D.10.8.r.1.EU.7]']";
	public static String R3IntendedUseName = "xpath#//label[text()='[D.10.8.r.1.EU.8]']";
	public static String R3Substance_SpecifiedSubstanceName = "xpath#//label[text()='[D.10.8.r.EU.r.1]']";
	public static String R3SubstanceTermIDVer_Date_Num = "xpath#//label[text()='[D.10.8.r.EU.r.2a]']";
	public static String R3Substance_Specified_Substance_TermID = "xpath#//label[text()='[D.10.8.r.EU.r.2b]']";
	public static String R3Strength_Number = "xpath#//label[text()='[D.10.8.r.EU.r.3a/b]']";
	
	//Codelist tags
	public static String CLParentAge = "xpath#//label[text()='[1016]']";
	public static String CLParentGender = "xpath#//label[text()='[1007]']";
	public static String CLparentWeight = "xpath#//label[text()='[48]']";
	public static String CLParentHeight = "xpath#//label[text()='[347]']";
	public static String ClEthnicOrigin = "xpath#//label[text()='[1022]']";
	public static String CLConsentToContactParent = "xpath#//label[text()='[7073]']";
	public static String CLDiseaseTerm = "xpath#//label[text()='[9917]']";
	public static String CLContinuing = "xpath#//label[text()='[1002]']";
	public static String CLDuration = "xpath#//label[text()='[1017]']";
	public static String CLCodingType = "xpath#//label[text()='[158]']";
	public static String CLStrength_Number = "xpath#//label[text()='[9070]']";
	
	/**********************************************************************************************************
	 * @Objective:The below method is created to click product by passing label name
	 *                at runtime.
	 * @Input Parameters: Label
	 * @OutputParameters:
	 * @author:Avinash K Date :25-Nov-2019 Updated by and when
	 **********************************************************************************************************/
	public static String select_Product(String runTimeLabel) {
		String value = product_RadioBtn;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to click drop downs by passing label
	 *                name at runtime
	 * @Input Parameters: Label
	 * @OutputParameters:
	 * @author:Avinash K Date :22-Nov-2019 Updated by and when
	 **********************************************************************************************************/

	public static String productEmdedDropdownSelect(String label) {
		String value = productEmdedDropdownSelect.replace("{0}", label);
		return value;
	}

	// Click Dropdown value
	public static String clickDropDownValue(String data) {
		String value = setdropDownValue.replace("{0}", data);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to set Continuing by passing label
	 *                name at runtime.
	 * @Input Parameters: Label
	 * @OutputParameters:
	 * @author:Avinash K Date :22-Nov-2019 Updated by and when
	 **********************************************************************************************************/
	public static String clickContinuing_RadioBtn(String runTimeLabel) {
		String value = continuing_radioBtn;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to click drop downs by passing label
	 *                name at runtime
	 * @Input Parameters: Label
	 * @OutputParameters:
	 * @author:Avinash K Date :22-Nov-2019 Updated by and when
	 **********************************************************************************************************/
	public static String click_DropDown(String label) {
		String value = click_DropDown.replace("{0}", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to click drop downs by passing label
	 *                name at runtime
	 * @Input Parameters: Label
	 * @OutputParameters:
	 * @author:Avinash K Date :22-Nov-2019 Updated by and when
	 **********************************************************************************************************/
	public static String click_EmbededDropDown(String label) {
		String value = embedclick_DropDown.replace("%s", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to set drop downs by passing label
	 *                name at runtime.
	 * @Input Parameters: Label
	 * @OutputParameters:
	 * @author:Avinash K Date :22-Nov-2019 Updated by and when
	 **********************************************************************************************************/
	public static String clickdropDownValue(String label) {
		String value = setdropDownValue.replace("{0}", label);
		return value;
	}

}
