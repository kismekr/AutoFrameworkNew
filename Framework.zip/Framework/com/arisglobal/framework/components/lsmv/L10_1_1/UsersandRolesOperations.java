package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AdministrationPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.UsersandRolesPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.aventstack.extentreports.Status;

public class UsersandRolesOperations extends ToolManager{
	public static WebElement webElement;
	static String className = UsersandRolesOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in Users and roles
	 * @InputParameters: pageObject
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void menuNavigation(String pageObject) {
		agMouseHover(AdministrationPageObjects.administrationHover);
		agClick(pageObject);
	}
	
	
	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in submission Module and verify the label name.
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void usersandRolesNavigations(String menu){
			switch (menu) {
			case "users":
				menuNavigation(UsersandRolesPageObjects.usersLink);
				agSetStepExecutionDelay("3000");
				status = agIsVisible(UsersandRolesPageObjects.userKeywordSearch);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to Users is Successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to Users is Unsuccessfull", true);
				}
				break;
			
			case "userGroups":
				menuNavigation(UsersandRolesPageObjects.userGroupsLink);
				agSetStepExecutionDelay("3000");
				status = agIsVisible(UsersandRolesPageObjects.groupKeywordSearch);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to user Groups is Successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to user Groups is Unsuccessfull", true);
				}
				break;
			case "roles":
				menuNavigation(UsersandRolesPageObjects.rolesLink);
				status = agIsVisible(UsersandRolesPageObjects.rolesKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to Roles is Successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to Roles is Unsuccessfull", true);
				}
				break;
			default:
				System.out.println("Invalid Menu Link!");
			}

	}
}