package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.arisglobal.framework.components.lsmv.L10_1.CommonOperations;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.DataExportPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.FileSystemOperations;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class DataExportOperations extends ToolManager {
	public static WebElement webElement;
	static String className = DataExportOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform menu navigation in Reports
	 *             module and verify menu based on label name.
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 15-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void menuNavigation(String pageObject) {
		agMouseHover(DataExportPageObjects.reportsHover);
		agClick(pageObject);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform menu navigation in Data
	 *             Extraction module and verify each menu based on label name.
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 15-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void dataExtractionNavigations(String menu) {
		switch (menu) {
		case "dataExtraction":
			ReportsOperations.menuNavigation("dataExport");
			agSetStepExecutionDelay("5000");
			status = agIsVisible(DataExportPageObjects.dataExportListingSearch_Textbox);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to Data Export is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Data Export is Unsuccessfull", true);
			}
			break;
		case "dataExtractionNew":
			ReportsOperations.menuNavigation("dataExport");
			agSetStepExecutionDelay("2000");
			agClick(DataExportPageObjects.new_Button);
			agSetStepExecutionDelay("2000");			
			status = agIsVisible(DataExportPageObjects.dataExtractionName_Textbox);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to Data Extractions New is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Data Extractions New is Unsuccessfull", true);
			}
			break;
		default:
			System.out.println("Invalid Menu Link!");
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 15-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(DataExportPageObjects.clickdropdown(label));
			agClick(DataExportPageObjects.selectDropdownvalue(getTestDataCellValue(scenarioName, columnName)));

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add account name
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 15-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addAccountName(String scenarioName) {
		if (getTestDataCellValue(scenarioName, "AddAccountName").equalsIgnoreCase("True")) {
			agClick(DataExportPageObjects.accountsNameLookup_icon);
			agSetStepExecutionDelay("3000");
			agIsVisible(DataExportPageObjects.accountLookup_label);
			agSetValue(DataExportPageObjects.accountsName_Txtfield, getTestDataCellValue(scenarioName, "AccountName"));
			agSetValue(DataExportPageObjects.dtdType_Txtfield, getTestDataCellValue(scenarioName, "DTDType"));

			agClick(DataExportPageObjects.lookupSearch_Btn);
			agWaitTillVisibilityOfElement(DataExportPageObjects
					.selectAccountLookupRadioBtn(getTestDataCellValue(scenarioName, "AccountName")));
			agClick(DataExportPageObjects
					.selectAccountLookupRadioBtn(getTestDataCellValue(scenarioName, "AccountName")));

			Reports.ExtentReportLog("", Status.INFO, "Data entred in Account Name", true);
			agSetStepExecutionDelay("2000");
			agJavaScriptExecuctorClick(DataExportPageObjects.lookupOK_Btn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Account Name is not added", false);
		}
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is Set Data Extraction details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 15-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setDataExtractionDetails(String scenarioName, Boolean editRecord) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agAssertVisible(DataExportPageObjects.dataExtractionLable);
		if (editRecord==false) {
			agSetValue(DataExportPageObjects.dataExtractionName_Textbox,
					getTestDataCellValue(scenarioName, "DataExtractionName"));
			agSetStepExecutionDelay("2000");
			agClick("xpath#//span[@id='qdExtractionDetails:qdeStartDate']/button/span[1]");
		}
		agJavaScriptExecuctorSendKeys(DataExportPageObjects.dataExtractionStart_Date, getTestDataCellValue(scenarioName, "DataExtractionStartDate"));
		//selectDateAndTime(scenarioName,  DataExportPageObjects.dataExtractionStart_Date, getTestDataCellValue(scenarioName, "DataExtractionStartDate"));

		agClick("xpath#//span[@id='qdExtractionDetails:qdeEndDate']/button/span[1]");
		agJavaScriptExecuctorSendKeys(DataExportPageObjects.dataExtractionEnd_Date, getTestDataCellValue(scenarioName, "DataExtractionEndDate"));
		//selectDateAndTime(scenarioName,  DataExportPageObjects.dataExtractionEnd_Date, getTestDataCellValue(scenarioName, "DataExtractionEndDate"));

		agSetStepExecutionDelay("2000");
		agClick("xpath#//span[@id='qdExtractionDetails:prevRunDate']/button/span[1]");
		agJavaScriptExecuctorSendKeys(DataExportPageObjects.dataExtractionPreviousRun_Date, getTestDataCellValue(scenarioName, "DataExtractionPreviousRunDate"));
		//selectDateAndTime(scenarioName,  DataExportPageObjects.dataExtractionPreviousRun_Date, getTestDataCellValue(scenarioName, "DataExtractionPreviousRunDate"));

		agSetStepExecutionDelay("2000");
		setDropDownValue(DataExportPageObjects.moduleType_dropdown, scenarioName, "ModuleType");
		if (getTestDataCellValue(scenarioName, "PublicUse").equalsIgnoreCase("uncheck")) {
			CommonOperations.clickCheckBoxLeftOf(DataExportPageObjects.publicUse_checkbox, "false");

			agSetStepExecutionDelay("2000");
			addAccountName(scenarioName);
			setDropDownValue(DataExportPageObjects.additionalSearchCriteria_dropdown, scenarioName,
					"AdditionalSearchCriteria");
			agSetStepExecutionDelay("2000");
			agClick(DataExportPageObjects.setPostMarket(getTestDataCellValue(scenarioName, "PostMarket")));
			agSetStepExecutionDelay("2000");
			agClick(DataExportPageObjects
					.setIncludeCaseVersion(getTestDataCellValue(scenarioName, "IncludeCaseVersion")));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		CommonOperations.clickCheckBoxLeftOf(DataExportPageObjects.exportTypeR2_checkbox,
				getTestDataCellValue(scenarioName, "ExportTypeR2"));
		CommonOperations.clickCheckBoxLeftOf(DataExportPageObjects.exportTypeR3_checkbox,
				getTestDataCellValue(scenarioName, "ExportTypeR3"));
		CommonOperations.clickCheckBoxLeftOf(DataExportPageObjects.exportTypeASCII_checkbox,
				getTestDataCellValue(scenarioName, "ExportTypeASCII"));
		agSetValue(DataExportPageObjects.description_Textbox, getTestDataCellValue(scenarioName, "Description"));

		if (getTestDataCellValue(scenarioName, "ScheduleCheck").equalsIgnoreCase("yes")
				||getTestDataCellValue(scenarioName, "ScheduleCheck").equalsIgnoreCase("check")) {
			CommonOperations.clickCheckBoxRightOf(DataExportPageObjects.schedule_CheckBox, "true");
			setDataExportSchedule(scenarioName);
		}

		CommonOperations.takeScreenShot();	

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to create a Data Export Record
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 23-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createDataExportRule(String scenarioName) {
		DataExportOperations.dataExtractionNavigations("dataExtraction");
		DataExportOperations.searchSingleRecord(scenarioName);
		if (agGetText(DataExportPageObjects.paginator).startsWith("1") && agGetText(DataExportPageObjects.paginator).endsWith("1")) {
			Reports.ExtentReportLog("", Status.PASS, "Record with the same Name created already", true);
		}
		else {
			agClick(DataExportPageObjects.new_Button);
			setDataExtractionDetails(scenarioName, false);
			Reports.ExtentReportLog("", Status.INFO, "Data set in the create page", true);
			saveDataExtractionDetails(scenarioName);
			Reports.ExtentReportLog("", Status.PASS, "Record created successfully", true);
		}
	}


	/**********************************************************************************************************
	 * @Objective: The below method is to edit a Data Export Record
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 23-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void editDataExportRule(String scenarioName) {

		DataExportOperations.dataExtractionNavigations("dataExtraction");
		DataExportOperations.searchSingleRecord(scenarioName);
		if (agGetText(DataExportPageObjects.paginator).startsWith("1") && agGetText(DataExportPageObjects.paginator).endsWith("1")) {
			Reports.ExtentReportLog("", Status.PASS, "Record with the keyed Name is availabe", true);
			//agClick(DataExportPageObjects.selectRecord_CheckBox);
			if (agIsVisible(DataExportPageObjects.recordEdit_icon)) {
				agClick(DataExportPageObjects.recordEdit_icon);
				agSetStepExecutionDelay("2000");				
				setDataExtractionDetails(scenarioName, true);
				saveDataExtractionDetails(scenarioName);
			}
			else {
				Reports.ExtentReportLog("", Status.INFO, "Record is not available for Edit", true);
			}

		}
		else {
			Reports.ExtentReportLog("", Status.FAIL, "No Record with the keyed Name available", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search for deleted batch print.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchDeleteBatchprint(String scenarioName) {
		searchSingleRecord(scenarioName);
		String paginator = agGetText(DataExportPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.FAIL, "Search for Deleted batch print: Deleted batch print is listed",
					true);
		} else {
			Reports.ExtentReportLog("", Status.PASS,
					"Search for Deleted batch print: Deleted batch print is not listed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: To perform the Record Delete Operation.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 23-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteBatchReportRecord(String scenarioName) {

		dataExtractionNavigations("dataExtraction");
		searchSingleRecord(scenarioName);
		if (agGetText(DataExportPageObjects.paginator).startsWith("1") && agGetText(DataExportPageObjects.paginator).endsWith("1")) {
			agSetStepExecutionDelay("2000");
			agWaitTillVisibilityOfElement(DataExportPageObjects.selectRecord_CheckBox);
			agClick(DataExportPageObjects.selectRecord_CheckBox);
			agClick(DataExportPageObjects.delete_Button);	
			Reports.ExtentReportLog("", Status.INFO, "Delete Confirmation", true);		
			agClick(DataExportPageObjects.deleteConfirm_Button);

			agClick(DataExportPageObjects.ackWindowInfoText);
			Reports.ExtentReportLog("", Status.INFO, agGetText(DataExportPageObjects.ackWindowInfoText), true);
			agClick(DataExportPageObjects.ackWindowInfoOK_button);

			searchDeleteBatchprint(scenarioName);	
		}
		else {
			Reports.ExtentReportLog("", Status.FAIL, "No Record with the keyed Name available", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to save after Date set
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 23-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void saveDataExtractionDetails(String scenarioName) {

		agClick(DataExportPageObjects.save_Button);
		agSetStepExecutionDelay("1000");
		if(agIsVisible(DataExportPageObjects.ackwindowErrorTitleText)) {
			Reports.ExtentReportLog("", Status.FAIL, agGetText(DataExportPageObjects.ackWindowInfoText), true);
			agClick(DataExportPageObjects.ackWindowInfoOK_button);
			ReportsOperations.menuNavigation("dataExport");
			agIsVisible(DataExportPageObjects.dataExportListingSearch_Textbox);
		}
		else {
			agIsVisible(DataExportPageObjects.ackWindowHeaderText);
			agIsVisible(DataExportPageObjects.ackWindowInfoText);
			System.out.println(agGetText(DataExportPageObjects.ackWindowInfoText));
			Reports.ExtentReportLog("", Status.PASS, agGetText(DataExportPageObjects.ackWindowInfoText), true);
			agClick(DataExportPageObjects.ackWindowInfoOK_button);
			agIsVisible(DataExportPageObjects.dataExportListingSearch_Textbox);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search a particular record.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 15-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Boolean searchSingleRecord(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(DataExportPageObjects.dataExportListingSearch_Textbox,
				getTestDataCellValue(scenarioName, "DataExtractionName"));
		agClick(DataExportPageObjects.search_Icon);
		agSetStepExecutionDelay("5000");

		if (agGetText(DataExportPageObjects.paginator).startsWith("1") && agGetText(DataExportPageObjects.paginator).endsWith("1")) {
			Reports.ExtentReportLog("", Status.PASS, "Batch record matching the exact keyed value retrieved successfully", true);
			return true;
		}
		else {
			Reports.ExtentReportLog("", Status.INFO, "No Batch record or multiple records retrieved", true);
			return false;
		}

	}

	/**********************************************************************************************************
	 * @Objective: To verify the Batch Report Progress and download.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 23-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyBatchReportGeneration(String scenarioName, String reportLocator) {

		try {
			if (searchSingleRecord(scenarioName)) {
				Boolean downloadable = false;
				for (int i = 0; i < 6; i++) {

					agSetStepExecutionDelay("3000");
					downloadable = agIsVisible(reportLocator);
					if (downloadable) {
						Reports.ExtentReportLog("", Status.PASS, "Batch report avaialble for download", true);
						agClick(reportLocator);
						Reports.ExtentReportLog("", Status.PASS, "Batch report Downloaded successfully", true);
						break;
					} else {
						Reports.ExtentReportLog("", Status.INFO,
								"Batch report not available for download yet. Try Number: " + i, true);
						agClick(DataExportPageObjects.refresh_Icon);
						searchSingleRecord(scenarioName);
						agSetStepExecutionDelay("2000");
					}

				}
				if (downloadable == false) {
					Reports.ExtentReportLog("", Status.FAIL,
							"Batch report not available for download even after one minute of waiting time", true);
				} 
			}
			else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Batch record not available or created", true);
			}
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	/**********************************************************************************************************
	 * @Objective: To verify the Batch Report Progress and download.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 23-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean reportDownload(String scenarioName, String reportType) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		dataExtractionNavigations("dataExtraction");
		boolean isDownloaded = false;
		switch (reportType.toUpperCase()) {
		case "R2":
			if (getTestDataCellValue(scenarioName, "ExportTypeR2").equalsIgnoreCase("Check")) {
				deletePreDownloadedReport(scenarioName);
				verifyBatchReportGeneration(scenarioName, DataExportPageObjects.reportR2download_icon);
				isDownloaded = true;
			}
			else {
				System.out.println("R2 Report not generated by the user");
				Reports.ExtentReportLog("", Status.INFO, "R2 Report not generated by the user", false);
			}
			break;

		case "R3":
			if (getTestDataCellValue(scenarioName, "ExportTypeR3").equalsIgnoreCase("Check")) {
				deletePreDownloadedReport(scenarioName);
				verifyBatchReportGeneration(scenarioName, DataExportPageObjects.reportR3download_icon);
				isDownloaded = true;
			}
			else {
				System.out.println("R3 Report not generated by the user");
				Reports.ExtentReportLog("", Status.INFO, "R3 Report not generated by the user", false);
			}
			break;

		case "ASCII":
			if (getTestDataCellValue(scenarioName, "ExportTypeASCII").equalsIgnoreCase("Check")) {
				deletePreDownloadedReport(scenarioName);
				verifyBatchReportGeneration(scenarioName, DataExportPageObjects.reportASCIIdownload_icon);
				isDownloaded = true;
			}
			else {
				System.out.println("ASCII Report not generated by the user");
				Reports.ExtentReportLog("", Status.INFO, "ASCII Report not generated by the user", false);
			}
			break;

		default:
			System.out.println("Incorrect Report Type keyed by the user. Keyed value is: "+reportType);
			Reports.ExtentReportLog("", Status.INFO, "Incorrect Report Type keyed by the user. Keyed value is: "+reportType, false);
			break;
		}
		return isDownloaded;
	}

	/**********************************************************************************************************
	 * @Objective: To verify the Batch Report Progress and download.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 23-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String unZipDownloadedReport(String scenarioName, String reportType) {	

		String fileName = null;

		if (reportDownload(scenarioName, reportType)) {
			agSetStepExecutionDelay("10000");
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			String destDirectory = lsmvConstants.LSMV_testDataOutput + "\\" + Reports.currenttime();
			fileName = destDirectory+"\\xml\\ADR20Q3.xml";
			String zipFilePath = lsmvConstants.LSMV_testDataOutput +"\\"+ getTestDataCellValue(scenarioName, "DataExtractionName")+".zip";

			File file = new File(zipFilePath);
			
			do{			
				//System.out.println("Waiting to get the file downloaded. Iteration "+ ++i);
				agSetStepExecutionDelay("10000");	      
			}while(!file.exists());


			FileSystemOperations.unzip(zipFilePath, destDirectory);

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "File not downloaded", false);
		}

		System.out.println("File name is, "+fileName);
		return fileName;
	}

	/**********************************************************************************************************
	 * @Objective: To verify the Batch Report Progress and download.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 30-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deletePreDownloadedReport(String scenarioName) {
		agSetStepExecutionDelay("5000");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);		
		String zipFilePath = lsmvConstants.LSMV_testDataOutput +"\\"+ getTestDataCellValue(scenarioName, "DataExtractionName")+".zip";

		//to delete pre-existing files with same name
		try {
			File file = new File(zipFilePath);
			if (file.exists()) {
				FileUtils.forceDelete(file);
				System.out.println(zipFilePath+" file deleted successfully");
			}
			else {
				System.out.println(zipFilePath+" file not available for delete");
			}
		} 
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	/**********************************************************************************************************
	 * @Objective: The below method is created to download BatchPrint export to excel.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 15-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportToexcel(String FileName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		dataExtractionNavigations("dataExtraction");
		agClick(DataExportPageObjects.refresh_Icon);
		agMouseHover(DataExportPageObjects.download_Icon);
		agClick(DataExportPageObjects.exporttoExcel_link);
		agSetStepExecutionDelay("3000");
		agWaitTillVisibilityOfElement(DataExportPageObjects.exporttoExcel_popup);

		if (agIsVisible(DataExportPageObjects.export_Button) == true) {
			agClick(DataExportPageObjects.export_Button);
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			CommonOperations.move_Downloadedexcel(FileName);
			agClick(DataExportPageObjects.exportexcelcancel_Button);
		} else {
			Reports.ExtentReportLog("Export to excel pop is not displayed", Status.INFO, "", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to compare record count with download
	 *             excel
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:Avinash K
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void recordCountVerification(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		String count = xls.getCellData("Quarterly Data Extration", 2, 4);
		String[] Totalcount = count.split(":");
		System.out.println("Total records in exported sheet is, " + Totalcount[1].trim());
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in exported excel::" + Totalcount[1].trim(),
				false);
		String applrecordcount = agGetText(DataExportPageObjects.paginator);
		String[] data = applrecordcount.split(" ");
		String recordCount = data[4];
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in application::" + recordCount, false);
		if (recordCount.equalsIgnoreCase(Totalcount[1].trim())) {
			Reports.ExtentReportLog("", Status.PASS, "Record count verification is successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Record count verification is Unsuccessfull", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select date and Time.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 23-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void selectDateAndTime(String scenarioName, String dateField, String dateTime) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String [] dateAndTime = dateTime.split(" ", 2);
		String date = dateAndTime[0];		
		String time = dateAndTime[1];

		String [] timeSplit = time.split(":", 3);
		int hour = Integer.parseInt(timeSplit[0]);
		int min = Integer.parseInt(timeSplit[1]);
		int sec = Integer.parseInt(timeSplit[2]);


		//Set Date
		agJavaScriptExecuctorSendKeys(dateField, date);
		agSetStepExecutionDelay("1000");

		//Set Hour
		if (hour>=0 && hour<24) {
			WebElement hourSlider = driver.findElement(By.xpath("//div/dl/dd[@class='ui_tpicker_hour']/div/span"));
			agClick("xpath#//div/dl/dd[@class='ui_tpicker_hour']/div/span");
			Actions builder1= new Actions(driver);
			for(int iCount = 0; iCount < hour ; iCount++) {
				builder1.moveToElement(hourSlider).click(hourSlider).sendKeys(Keys.ARROW_RIGHT).perform();	
			}
		}
		else {
			Reports.ExtentReportLog("", Status.INFO, "Incorrect hour value keyed", false);
		}

		//Set Minutes
		if (min>=0 && min<60) {
			WebElement minuteSlider = driver.findElement(By.xpath("//div/dl/dd[@class='ui_tpicker_minute']/div/span"));
			agClick("xpath#//div/dl/dd[@class='ui_tpicker_minute']/div/span");
			Actions builder1= new Actions(driver);
			for(int iCount = 0; iCount < min ; iCount++) {
				builder1.moveToElement(minuteSlider).click(minuteSlider).sendKeys(Keys.ARROW_RIGHT).perform();	
			}
		}
		else {
			Reports.ExtentReportLog("", Status.INFO, "Incorrect minute value keyed", false);
		}

		//Set Seconds
		WebElement secondSlider = driver.findElement(By.xpath("//div/dl/dd[@class='ui_tpicker_second']/div/span"));
		agClick("xpath#//div/dl/dd[@class='ui_tpicker_second']/div/span");
		Actions builder1= new Actions(driver);
		for(int iCount = 0; iCount <= sec ; iCount++) {
			builder1.moveToElement(secondSlider).click(secondSlider).sendKeys(Keys.ARROW_RIGHT).perform();	
		}

	}


	/**********************************************************************************************************
	 * @Objective: To set the Batch Print schedule.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 17-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDataExportSchedule(String scenarioName) {

		String scheduleFrequency = getTestDataCellValue(scenarioName, "ScheduleType");
		agClick(DataExportPageObjects.scheduleType_dropdown);


		switch (scheduleFrequency.toLowerCase().trim()) {
		case "one time":
			agSetStepExecutionDelay("2000");
			agClick(DataExportPageObjects.scheduleType_OneTimeOption);
			agSetValue(DataExportPageObjects.schedule_OneTime_dateField, getTestDataCellValue(scenarioName, "OneTime_Date"));
			break;

		case "daily":
			agSetStepExecutionDelay("2000");
			agClick(DataExportPageObjects.scheduleType_DailyOption);
			agSetValue(DataExportPageObjects.schedule_timeField, getTestDataCellValue(scenarioName, "Daily_Time"));
			break;

		case "weekly":
			agSetStepExecutionDelay("2000");
			agClick(DataExportPageObjects.scheduleType_WeeklyOption);
			agSetValue(DataExportPageObjects.schedule_timeField, getTestDataCellValue(scenarioName, "Weekly_time"));
			String [] day = getTestDataCellValue(scenarioName, "Weekly_Days").split(":",7);
			System.out.print("Values selected are, ");
			for (int i = 0; i < day.length; i++) {
				System.out.print(", "+day[i]);
				agWaitTillVisibilityOfElement(DataExportPageObjects.checkDays(day[i]));
				agClick(DataExportPageObjects.checkDays(day[i]));
			}
			System.out.println();
			break;

		default:
			break;
		}

	}

}