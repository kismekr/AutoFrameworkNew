package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import org.openqa.selenium.By;

public class AdministrationPageObjects {
	
	public static String administrationHover = "xpath#//span[contains(text(),'Administration')]";
	
}
