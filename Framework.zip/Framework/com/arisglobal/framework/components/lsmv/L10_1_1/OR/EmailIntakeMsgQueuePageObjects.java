package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class EmailIntakeMsgQueuePageObjects {

	public static String searchTextBox = "xpath#//input[@class='inputCmpClass lsmvGridSearchCmp']";
	public static String searchIcon = "xpath#//div[@class='gridSearchBarRight']//span[@class='lsmv-grid-search-icon']";
	public static String emptyRow = "xpath#//div[@class='lsmv-grid-row']";
	public static String refreshIcon = "xpath#//span[text()='Email Intake Message Queue']";
	public static String getTextColumn = "xpath#//div[@fieldid='%s']/div[@class='lsmv-grid-col-adjust ']";

	public static String status = "status";
	public static String receiptNo = "receiptNo";

	/**********************************************************************************************************
	 * Objective:Get column data Input Parameters: value Output Parameters:
	 * 
	 * @author:Pooja S Date :06-Apr-2021 Updated by and when
	 **********************************************************************************************************/
	public static String getTextColumn(String fldid) {
		String value = getTextColumn;
		String value2;
		value2 = value.replace("%s", fldid);
		return value2;
	}

}
