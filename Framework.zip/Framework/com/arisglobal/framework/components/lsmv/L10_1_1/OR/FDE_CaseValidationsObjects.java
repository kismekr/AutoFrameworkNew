package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FDE_CaseValidationsObjects {public static String activityLogTab = "xpath#//div[@class='agMandatoryPanel ng-star-inserted']";

//Validation Message Link xpath
public static String validationNameXpath = "xpath#//div[@class='agMandatoryPanel ng-star-inserted']//div[@class='agMandatoryContext ng-star-inserted']//a[contains(text(),'%s')]";
public static String warnings="xpath#//div[@class='agMandatoryGropuPanel']/div/div/ol/li[@class='agValWarning ng-star-inserted']";

public static String validationlist="xpath#//div[@class='agMandatoryGropuPanel']/div//li[@class='agValError ng-star-inserted']";
public static String Warninglist="xpath#//div[@class='agMandatoryGropuPanel']/div//li[@class='agValWarning ng-star-inserted']";
public static String validationPanel="xpath#//div[@class='agMandatoryGropuPanel']/div";


public static String RctNumber="xpath#//label[@id='adverseEventNew:recieptId']";
public static String ValText(String ValName) {
	String ValidationTextXpath = validationNameXpath.replace("%s", ValName);
	return ValidationTextXpath;
}

public static String validatationOr(int row) {
	return validationlist+"["+row+"]/a";
}
public static String validationSpecfic(String validationMessage) {
	return "xpath#//div/ol/li/a[contains(.,'"+validationMessage+"')]";
}
	
}
