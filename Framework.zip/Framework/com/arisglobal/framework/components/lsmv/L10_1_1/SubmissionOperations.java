package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.CommonOperations;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.DistributionContactsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDEMoreOptionsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_SubmissionTrackingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.SubmissionPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DataBaseOperations;
import com.arisglobal.framework.lib.utils.generic.FileSystemOperations;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.framework.lib.utils.projectspecific.lsmv.R3XmlCompareOperations;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class SubmissionOperations extends ToolManager {
	public static WebElement webElement;
	static String className = SubmissionOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	public static String scenarioName = "LSMV_NonCTNonSUSAR_Apprendix1";

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform menu navigation in
	 *             Submission Module
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void menuNavigation(String menu) {
		agMouseHover(SubmissionPageObjects.submissionHover);
		agClick(SubmissionPageObjects.SubmissionMenuNavigations(menu));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform menu navigation in
	 *             Submission Module
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void PrintbtnNavigtn(String menu) {
		agMouseHover(SubmissionPageObjects.PrintBtnhover);
		agClick(SubmissionPageObjects.PrintButtonNavigation(menu));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Sub menu navigation in
	 *             Submission module
	 * @InputParameters: subMenu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void subMenuNavigations(String subMenu) {
		agMouseHover(SubmissionPageObjects.submissionHover);
		agMouseHover(SubmissionPageObjects.correspondenceHover);
		agClick(SubmissionPageObjects.SubmissionSubMenuNavigations(subMenu));
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in
	 *             submission Module and verify the label name.
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void submission_MenuNavigations(String menu) {
		switch (menu) {
		case "submissionListing":
			menuNavigation("Submission listing");
			// status = agIsVisible(SubmissionPageObjects.submissionListingKeywordSearch);
			status = agIsVisible(SubmissionPageObjects.SubmissionSearchBox);
			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "Navigation to Submission listing is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Submission listing is Unsuccessfull", true);
			}
			break;
		case "failedDistribution":
			menuNavigation("Failed distribution");
			status = agIsVisible(SubmissionPageObjects.submissionFailedKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to failed Distribution is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to failed Distribution is Unsuccessfull", true);
			}
			break;
		case "unreadCorrespondence":
			subMenuNavigations("Unread correspondence");
			status = agIsVisible(SubmissionPageObjects.submissionUnreadCorrKeySearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to unread Correspondence is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to unread Correspondence is Unsuccessfull", true);
			}
			break;
		case "unresolvedCorrespondence":
			subMenuNavigations("Unresolved correspondence");
			status = agIsVisible(SubmissionPageObjects.submissionUnresloveCorrKeySearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to unresolved Correspondence is successfull",
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to unresolved Correspondence is Unsuccessfull",
						true);
			}
			break;

		case "outOfWorkflowListing":
			menuNavigation("Out of workflow listing");
			status = agIsVisible(SubmissionPageObjects.submissionOutofWorkflowSubID);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to out Of Workflow Listing is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to out Of Workflow Listing is Unsuccessfull",
						true);
			}
			break;
		case "submissionReports":
			menuNavigation("Submission reports");
			status = agIsVisible(SubmissionPageObjects.submissionReportsLatestdate);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to submission Reports is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to submission Reports is Unsuccessfull", true);
			}
			break;
		default:
			System.out.println("Invalid Menu Link!");
		}

	}

	/**********************************************************************************************************
	 * @Objective:Search receipt number
	 * @InputParameters: Receipt number
	 * @OutputParameters: void
	 * @author:WajahatUmar S
	 * @Date : 20/02/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SubmissionSearchCase(String rctNumber) {
		// TODO Auto-generated method stub
		agSetValue(SubmissionPageObjects.SubmissionSearchBox, rctNumber);
		agClick(SubmissionPageObjects.SearchIcon);
		agWaitTillInvisibilityOfElement(CaseListingPageObjects.oWS_SearchLoading);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 6-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(DistributionContactsPageObjects.clickdropdown(label));
			agClick(DistributionContactsPageObjects
					.selectDropdownvalue(getTestDataCellValue(scenarioName, columnName)));

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to For Submission Validation
	 *             popup(action)
	 * @InputParameters:
	 * @OutputParameters:void
	 * @author:WajahatUmar S
	 * @Date :20-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SubmissionOkButton() {
		if (ToolManager.agIsVisible(FullDataEntryFormPageObjects.ActionOkBtn) == true) {
			ToolManager.agClick(FullDataEntryFormPageObjects.ActionOkBtn);
		} else {
			ToolManager.agIsVisible(FullDataEntryFormPageObjects.actComp_ValidationError);
			ToolManager.agClick(FullDataEntryFormPageObjects.ActionOkBtn);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search the created case in case
	 *             Submission listing and edit
	 * @InputParameters: Scenario Name, sheetName, columnName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 17-Mar-2020
	 * @UpdatedByAndWhen:Yashwanth Naidu - 16-04-2020/Pooja on 28-May-2020
	 **********************************************************************************************************/
	public static void searchCaseAndEdit(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		SubmissionOperations.submission_MenuNavigations("submissionListing");
		agSetStepExecutionDelay("2000");
		// agSetValue(SubmissionPageObjects.SubmissionSearchBox,"31");
		agSetValue(SubmissionPageObjects.SubmissionSearchBox, getTestDataCellValue(scenarioName, columnName));
		agClick(SubmissionPageObjects.SearchIcon);
		agSetStepExecutionDelay("4000");
		agClick(SubmissionPageObjects.aerno_Link);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search the AerNo
	 * @InputParameters: Scenario Name, sheetName, columnName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @return
	 * @Date : 04-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	/**********************************************************************************************************
	 * @Objective: The below method is created to search the AerNo
	 * @InputParameters: Scenario Name, sheetName, columnName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @return
	 * @Date : 04-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String searchAerNo(String scenarioName, String sheetName, String columnName) {
		Reports.ExtentReportLog("", Status.INFO, "Search AERNO Started", true);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		try {
			SubmissionOperations.submission_MenuNavigations("submissionListing");
			agSetStepExecutionDelay("2000");
			// agSetValue(SubmissionPageObjects.SubmissionSearchBox,"31");
			agSetValue(SubmissionPageObjects.SubmissionSearchBox, getTestDataCellValue(scenarioName, columnName));
			agJavaScriptExecuctorClick(SubmissionPageObjects.SearchIcon);
			agSetStepExecutionDelay("2000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			// agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
			Reports.ExtentReportLog("", Status.INFO, "Search AERNO Completed", true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return getTestDataCellValue(scenarioName, columnName);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 19-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setReportStatusDownValue(String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(SubmissionPageObjects.clickReportStatus);
			agClick(SubmissionPageObjects.SetReportStatusDropdown(getTestDataCellValue(scenarioName, columnName)));

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Tnformed Authority and submit
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 19-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setInformedandSubmit(String scenarioName, String scenarioName1, String index) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		SubmissionOperations.clickContactName(scenarioName);// Added by pooja to filter the contact name
		agSetValue(SubmissionPageObjects.generalEmailAddress,
				getTestDataCellValue(scenarioName, "General_EmailAddress"));
		agSetValue(SubmissionPageObjects.generalCCEmailAddress,
				getTestDataCellValue(scenarioName, "General_CCEmailAddress"));
		// SubmissionOperations.clickLocalLabeling();
		// SubmissionOperations.setSubmissionLocalLabelling("LSMV_SubmissionTracking4",
		// "0");
		// SubmissionOperations.subMenuNavigations("Informed Authority");
		agClick(SubmissionPageObjects.navigateToInformAuthorityTab);
		SubmissionOperations.setReportStatusDownValue(scenarioName, "InformedAuthority_ReportingStatus");
		agSetStepExecutionDelay("4000");
		agSetValue(SubmissionPageObjects.dateInformedTextBox,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "InformedAuthority_DateInformed")));
		clickLocalLabeling();
		setSubmissionLocalLabelling(scenarioName1, index);
		//clickRegenerate();
		agMouseHover(FullDataEntryFormPageObjects.actions_BtnSub);
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.completeActivity_link);
		agSetStepExecutionDelay("10000");
		// agClick(SubmissionPageObjects.setWorkflownotes);
		// agSetValue(SubmissionPageObjects.setWorkflownotes,
		// getTestDataCellValue(scenarioName, "InformedAuthority_WorkflowNotes"));
		// agClick(SubmissionPageObjects.workflownotesadd_btn);
		// agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
		CommonOperations.takeScreenShot();
		agClick(SubmissionPageObjects.ok_btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set the contact name
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 30-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickReportFormat(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		agClick(SubmissionPageObjects.filter_icon);
		agSetValue(SubmissionPageObjects.Contactname_textbox, getTestDataCellValue(scenarioName, "ContactName"));
		agClick(SubmissionPageObjects.AERNo_textbox);
		agJavaScriptExecuctorScrollRight();
		agClick(SubmissionPageObjects.clickReportFormat(getTestDataCellValue(scenarioName, "ReportFormat")));
		Reports.ExtentReportLog("", Status.INFO, "Report Name clicked", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set the contact name
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 26-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickContactName(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorClick(SubmissionPageObjects.filter_icon);
		agSetValue(SubmissionPageObjects.Contactname_textbox, getTestDataCellValue(scenarioName, "ContactName"));
		agClick(SubmissionPageObjects.AERNo_textbox);
		agJavaScriptExecuctorScrollRight();
		agClick(SubmissionPageObjects.aerno_Link);
		Reports.ExtentReportLog("", Status.INFO, "Contact name provided with Aer No", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to filter the contact name in
	 *             submission listing screen
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 16-july-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void filtersubmissionContactName(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		agClick(SubmissionPageObjects.filter_icon);
		agSetValue(SubmissionPageObjects.Contactname_textbox, getTestDataCellValue(scenarioName, "ContactName"));
		agClick(SubmissionPageObjects.AERNo_textbox);
		Reports.ExtentReportLog("", Status.INFO, "Contact name provided with Aer No", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download FDA3500A (Drug) Report
	 * @InputParameters: ReportName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :08-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downLoadReport(String ReportName) {
		agSetStepExecutionDelay("5000");
		agSwitchFrame(SubmissionPageObjects.Pdfframeid);
		CommonOperations.takeScreenShot();
		agClick(SubmissionPageObjects.Pdfdownload);
		agSwitchToDefaultFrame();
		agClick(SubmissionPageObjects.cancelIcon);
		try {
			Thread.sleep(8000);
		} catch (InterruptedException e) // Hard wait is used reason file to get download taking time
		{
			e.printStackTrace();
		}
	}

	/**********************************************************************************************************
	 * @Objective:Search receipt number
	 * @InputParameters: scenarioname,sheetname,columnname
	 * @OutputParameters: void
	 * @author:Pooja S
	 * @Date : 31-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SubmissionSearchCase_RctNo(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetStepExecutionDelay("3000");
		String RCTno = CommonOperations.getData(scenarioName,sheetName, columnName);
		System.out.println(RCTno);
		agSetValue(SubmissionPageObjects.SubmissionSearchBox, RCTno);
		agClick(SubmissionPageObjects.SearchIcon);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective:Search receipt number and wait till Processing is complete
	 * @InputParameters:scenarioName, sheetName, columnName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 24-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SubmissionSearchCaseAndWait(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		SubmissionOperations.submission_MenuNavigations("submissionListing");
		agSetStepExecutionDelay("5000");
		agWaitTillVisibilityOfElement(SubmissionPageObjects.SubmissionSearchBox);
		agSetValue(SubmissionPageObjects.SubmissionSearchBox, getTestDataCellValue(scenarioName, columnName));
		CommonOperations.takeScreenShot();
		agClick(SubmissionPageObjects.SearchIcon);
		agWaitTillInvisibilityOfElement(SubmissionPageObjects.processingIcon);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective:Get Message#
	 * @InputParameters:scenarioName, sheetName
	 * @OutputParameters: Message#
	 * @author:Mythri Jain
	 * @Date : 24-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void getMessageNumberCT(String scenarioName, String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetStepExecutionDelay("3000");
		agJavaScriptExecuctorScrollToElement(SubmissionPageObjects.messageNo1);
		String MessageNumber1 = agGetText(SubmissionPageObjects.messageNo1);
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "SubmissionMessageNo1",
				MessageNumber1);
		Reports.ExtentReportLog("Get Message# of Submitted case", Status.PASS,
				"Submitted case is displayed :: Message # -" + MessageNumber1, true);
		agJavaScriptExecuctorScrollToElement(SubmissionPageObjects.messageNo2);
		String MessageNumber2 = agGetText(SubmissionPageObjects.messageNo2);
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "SubmissionMessageNo2",
				MessageNumber2);
		Reports.ExtentReportLog("Get Message# of Submitted case", Status.PASS,
				"Submitted case is displayed :: Message # -" + MessageNumber2, true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective:Get Message#
	 * @InputParameters:scenarioName, sheetName
	 * @OutputParameters: Message#
	 * @author:Mythri Jain
	 * @Date : 26-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getMessageNumber(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetStepExecutionDelay("3000");
		agJavaScriptExecuctorScrollToElement(SubmissionPageObjects.messageNo1);
		String MessageNumber1 = agGetText(SubmissionPageObjects.messageNo1);
		System.out.println(MessageNumber1);
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, columnName, MessageNumber1);
		Reports.ExtentReportLog("Get Message# of Submitted case", Status.PASS,
				"Submitted case is displayed :: Message # -" + MessageNumber1, true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		return MessageNumber1;
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is create to download xml in E2B
	 *             MessageQueueListing
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @throws InterruptedException
	 * @Date : 21-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downloadXML(String OldFileName, String NewFileName) throws InterruptedException {
		agWaitTillVisibilityOfElement(SubmissionPageObjects.clickXML);
		agClick(SubmissionPageObjects.clickXML);
		agWaitTillVisibilityOfElement(SubmissionPageObjects.downloadButton);
		agClick(SubmissionPageObjects.downloadButton);
		Thread.sleep(10000);
		FileSystemOperations.pickLatestFileFromDownloads();
		E2BMessageQueueOperations.Verify_DownloadedXml(NewFileName);
		agClick(SubmissionPageObjects.closeDownloadPopUp);

	}

	/**********************************************************************************************************
	 * @Objective: The Below method is create to Verification of Case Management
	 *             Documents, Cover Letter.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 28-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerificationofCaseManagementDocumentsandCoverLetter(String scenarioName, String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		if (agIsVisible(SubmissionPageObjects.LocalDocumentVerification) == true) {
			Reports.ExtentReportLog("Local Drive Document Uploaded Successfully", Status.PASS,
					" Local Drive Document Uploaded Successfully", true);
		} else {
			Reports.ExtentReportLog("Local Drive Document Upload Failed", Status.FAIL,
					"Local Drive Document Upload Failed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is create to Addition of Local Drive Documents.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 28-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AdditionofLocalDriveDocuments(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agClick(SubmissionPageObjects.LocalDriveUploadDocumnetBtn);
		agWaitTillVisibilityOfElement(SubmissionPageObjects.UploadDocumentPopUp);
		agSetStepExecutionDelay("2000");
		agSetValue(SubmissionPageObjects.AdditionalDocumentUpload,
				lsmvConstants.LSMV_testDataInput + "\\" + getTestDataCellValue(scenarioName, columnName));
		agSetStepExecutionDelay("3000");
		agWaitTillVisibilityOfElement(SubmissionPageObjects.LocalDriveDocFileName);
		agSetValue(SubmissionPageObjects.DocumentDescription, "TestAutomation");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(SubmissionPageObjects.SubmitBtn);
		agWaitTillVisibilityOfElement(SubmissionPageObjects.LocalDocumentVerification);
		if (agIsVisible(SubmissionPageObjects.LocalDocumentVerification) == true) {
			Reports.ExtentReportLog("Local Drive Document Uploaded Successfully", Status.PASS,
					" Local Drive Document Uploaded Successfully", true);
		} else {
			Reports.ExtentReportLog("Local Drive Document Upload Failed", Status.FAIL,
					"Local Drive Document Upload Failed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click Regenerate button
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void clickRegenerate() {
		agClick(SubmissionPageObjects.regenerateBtn);
		agWaitTillVisibilityOfElement(SubmissionPageObjects.validationpopUp);
		agClick(SubmissionPageObjects.okBtn);
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set the local labeling data in
	 *             submission screen
	 * @InputParameters: ScenarioName, index
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setSubmissionLocalLabelling(String scenarioName, String index) {
		agSetStepExecutionDelay("2000");
		agClick(SubmissionPageObjects.addBtn);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		setListDropDownValue(index, SubmissionPageObjects.product,
				FDE_Products.getData(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"));
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
		setListDropDownValue(index, SubmissionPageObjects.reportedTerm,
				FDE_Events.getData(scenarioName, "Events_EventInformation_ReportedTerm"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(SubmissionPageObjects.locator(index, SubmissionPageObjects.labelled));
		setCountryListDropDownValue(index, SubmissionPageObjects.countryLabeling,
				getTestDataCellValue(scenarioName, "Submission_LabelingCountry"));
		setListDropDownValue(index, SubmissionPageObjects.labelled,
				getTestDataCellValue(scenarioName, "Submission_Labeled"));
		agClick(SubmissionPageObjects.saveBtn);
		agWaitTillVisibilityOfElement(SubmissionPageObjects.validationpopUp);
		agClick(SubmissionPageObjects.okBtn);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the local labeling data in
	 *             submission screen
	 * @InputParameters: ScenarioName, index
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifySubmissionLocalLabelling(String scenarioName, String index) {
		agSetStepExecutionDelay("2000");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		agCheckPropertyText(
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"),
				SubmissionPageObjects.locator(index, SubmissionPageObjects.product));
		agAssertContainsText(SubmissionPageObjects.verifyLabels(index, SubmissionPageObjects.productCharacterization),
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductCharacterization"));
		agAssertContainsText(SubmissionPageObjects.verifyLabels(index, SubmissionPageObjects.productType),
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductFlag"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"),
				SubmissionPageObjects.locator(index, SubmissionPageObjects.reportedTerm));
		agAssertContainsText(SubmissionPageObjects.verifyLabels(index, SubmissionPageObjects.lowlevelTerm),
				getTestDataCellValue(scenarioName, "Events_EventInformation_EventMedDRALLTCode_SearchTerm"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertContainsText(SubmissionPageObjects.verifyLabels(index, SubmissionPageObjects.medraVersion),
				getTestDataCellValue(scenarioName, "Submission_MedraVersion"));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Submission_Labeled"),
				SubmissionPageObjects.locator(index, SubmissionPageObjects.labelled));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Submission_LabelingCountry"),
				SubmissionPageObjects.countryLocator(index, SubmissionPageObjects.countryLabeling));
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The Below method is create to Verification of Report Generation
	 *             for each contact .
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 28-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerificationofReportGenerationforEachContact(String scenarioName, String sheetName,
			String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		searchAerNo(scenarioName, sheetName, columnName);
		ArrayList<String> Names = FDE_SubmissionTrackingOperation.GetContactListFromExcel();
		int count = Names.size() - 1;
		for (int i = 0; i < count; i++) {
			String Contact = Names.get(i);
			if (agIsVisible(SubmissionPageObjects.ContactName(Contact)) == true) {
				Reports.ExtentReportLog("", Status.INFO, "Contact Exist", true);
				if (agIsVisible(SubmissionPageObjects.ReportFormatE2B(Contact)) == true) {
					agSetStepExecutionDelay("2000");
					agJavaScriptExecuctorClick(SubmissionPageObjects.ReportFormatE2B(Contact));
					agSetStepExecutionDelay("3000");
					CommonOperations.takeScreenShot();
					agJavaScriptExecuctorClick(SubmissionPageObjects.EasyViewBtn);
					agSetStepExecutionDelay("3000");
					agSwitchFrame(SubmissionPageObjects.ReportFormatE2BEasyView_iframeID);
					CommonOperations.takeScreenShot();
					agClick(FDEMoreOptionsPageObjects.downloadIcon);
					agSwitchToDefaultFrame();
					agClick(SubmissionPageObjects.ReportFormat_cancelIcon);
					agSetStepExecutionDelay("2000");
					agClick(SubmissionPageObjects.XmlReportCloseIcon);
					agMouseHover(SubmissionPageObjects.ReportFormatHover(Contact));
					agJavaScriptExecuctorClick(SubmissionPageObjects.ReportFormatHoverClick(Contact, "1"));
					agSetStepExecutionDelay("3000");
					agSwitchFrame(SubmissionPageObjects.ReportFormatE2B_iframeID);
					CommonOperations.takeScreenShot();
					agClick(FDEMoreOptionsPageObjects.downloadIcon);
					agSwitchToDefaultFrame();
					agClick(SubmissionPageObjects.ReportFormatE2B_CancelIcon);
					agSetStepExecutionDelay("3000");
					agMouseHover(SubmissionPageObjects.ReportFormatHover(Contact));
					agJavaScriptExecuctorClick(SubmissionPageObjects.ReportFormatHoverClick(Contact, "2"));
					agSetStepExecutionDelay("3000");
					agSwitchFrame(SubmissionPageObjects.ReportFormatE2B_iframeID);
					CommonOperations.takeScreenShot();
					agClick(FDEMoreOptionsPageObjects.downloadIcon);
					agSwitchToDefaultFrame();
					agClick(SubmissionPageObjects.ReportFormatE2B_CancelIcon);
					agSetStepExecutionDelay("3000");
					Reports.ExtentReportLog("", Status.PASS,
							"Verification of Report Generation for " + Contact + " Sucessfull", true);
				} else {
					agClick(SubmissionPageObjects.ReportFormatNonE2B(Contact));
					agSetStepExecutionDelay("3000");
					agSwitchFrame(SubmissionPageObjects.ReportFormatNonE2B_iframeID);
					CommonOperations.takeScreenShot();
					agClick(FDEMoreOptionsPageObjects.downloadIcon);
					agSwitchToDefaultFrame();
					agClick(SubmissionPageObjects.ReportFormatNonE2B_CancelIcon);
					agSetStepExecutionDelay("2000");
					Reports.ExtentReportLog("", Status.PASS,
							"Verification of Report Generation for " + Contact + " Sucessfull", true);
				}
			} else {
				// click on next table if it could able to find in first table.
				if (agIsVisible(FDE_SubmissionTrackingPageObjects.NxtTableBtn)) {
					agClick(FDE_SubmissionTrackingPageObjects.NxtTableBtn);
				} else if (agIsVisible(FDE_SubmissionTrackingPageObjects.FirstTable)) {
					// Moved back to first table.
					agClick(FDE_SubmissionTrackingPageObjects.FirstTable);

				} else {
					Reports.ExtentReportLog("", Status.FAIL,
							"Verification of Report Generation for " + Contact + " UnSucessfull", true);
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the local labeling data in
	 *             submission screen
	 * @InputParameters: ScenarioName, index
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void clickLocalLabeling() {
		agSetStepExecutionDelay("2000");
		// agClick(SubmissionPageObjects.aerno_Link);
		agWaitTillVisibilityOfElement(SubmissionPageObjects.localDataEntry);
		agClick(SubmissionPageObjects.localDataEntry);
		agClick(SubmissionPageObjects.localLabeling);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select list type drop down value.
	 * @InputParameters: locator, valueToSelect, id
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 02-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setListDropDownValue(String index, String id, String valueToSelect) {
		if (!valueToSelect.equalsIgnoreCase("#skip#")) {
			agJavaScriptExecuctorClick(SubmissionPageObjects.locator(index, id));
			agJavaScriptExecuctorClick(SubmissionPageObjects.selectListDropDown(index, id, valueToSelect));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select country list type drop down
	 *             value.
	 * @InputParameters: locator, valueToSelect, id
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 02-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCountryListDropDownValue(String index, String id, String valueToSelect) {
		if (!valueToSelect.equalsIgnoreCase("#skip#")) {
			agJavaScriptExecuctorClick(SubmissionPageObjects.countryLocator(index, id));
			agJavaScriptExecuctorClick(SubmissionPageObjects.selectCountryListDropdown(index, id, valueToSelect));
		}
	}

	/**********************************************************************************************************
	 * @Objective: Submission processor and compare XML
	 * @InputParameters: AERNo, ScenarioName
	 * @OutputParameters:NA
	 * @author:Dushyanth Mahesh
	 * @Date : 15-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void submission_Processor(String recieptNumber, String AERNo, String ScenarioName)
			throws InterruptedException {

		ScenarioName = "PairwiseTesting_5_R3Import_L10101";
		SubmissionOperations.SubmissionAERNoSearch(AERNo, "Automation_E2B_R3_Standard");
		SubmissionOperations.WPAdownloadXML(recieptNumber, "E2BReport", ScenarioName);

		R3XmlCompareOperations.compareR3XML(lsmvConstants.LSMV_xslFilePath, lsmvConstants.LSMV_WPAsourceFolderPath,
				lsmvConstants.LSMV_WPAdestFolderPath, lsmvConstants.LSMV_compFolderPath, ScenarioName);

	}

	/**********************************************************************************************************
	 * @Objective:Search AERNO number
	 * @InputParameters:scenarioName, sheetName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 24-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SubmissionAERNoSearch(String AERNO, String ContactName) {
		SubmissionOperations.submission_MenuNavigations("submissionListing");
		agSetStepExecutionDelay("5000");
		agClick(SubmissionPageObjects.refershIcon);
		agClick(SubmissionPageObjects.refershIcon);
		agWaitTillVisibilityOfElement(SubmissionPageObjects.SubmissionSearchBox);
		agSetValue(SubmissionPageObjects.SubmissionSearchBox, AERNO);
		agClick(SubmissionPageObjects.SearchIcon);
		agWaitTillInvisibilityOfElement(SubmissionPageObjects.processingIcon);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		boolean norecordAvailable = agIsVisible(SubmissionPageObjects.noRecToDispLabel);
		int counter = 0;
		while (norecordAvailable && counter < 15) {
			agSetStepExecutionDelay("3000");
			agClick(SubmissionPageObjects.refershIcon);
			agWaitTillVisibilityOfElement(SubmissionPageObjects.SubmissionSearchBox);
			agSetValue(SubmissionPageObjects.SubmissionSearchBox, AERNO);
			agClick(SubmissionPageObjects.SearchIcon);
			agWaitTillInvisibilityOfElement(SubmissionPageObjects.processingIcon);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			norecordAvailable = agIsVisible(SubmissionPageObjects.noRecToDispLabel);
			counter++;
		}
		agClick(SubmissionPageObjects.filter_icon);
		agSetValue(SubmissionPageObjects.Contactname_textbox, ContactName);
		agClick(SubmissionPageObjects.AERNo_textbox);
		Reports.ExtentReportLog("", Status.INFO, "Contact name provided with Aer No", true);
		CommonOperations.incremAlmStepNo("False", "Pass", "Contact Name:"+ContactName+" provided with AER No:"+AERNO, true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		

	}

	/**********************************************************************************************************
	 * @Objective: The Below method is create to download xml in E2B
	 *             MessageQueueListing
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @throws InterruptedException
	 * @Date : 21-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void WPAdownloadXML(String recieptNumber, String OldFileName, String NewFileName) {
		agWaitTillVisibilityOfElement(SubmissionPageObjects.clickXML);
		agClick(SubmissionPageObjects.clickXML);
		agWaitTillVisibilityOfElement(SubmissionPageObjects.downloadButton);
		agClick(SubmissionPageObjects.downloadButton);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		E2BMessageQueueOperations.Verify_WPADownloadedXml(recieptNumber, OldFileName, NewFileName);
		agClick(SubmissionPageObjects.closeDownloadPopUp);
		

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to refresh in submission listing
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 27-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void RefreshSubmissionScreen(String sceName) {
		Reports.ExtentReportLog("", Status.INFO, "Refresh the page till AERNO Dislayed Started", true);
		try {
			String AERNO = SubmissionOperations.searchAerNo(sceName, "dataassessmentoperations", "AERNo");
			for (int i = 1; i < 20; i++) {
				agSetStepExecutionDelay("2000");
				agSetValue(SubmissionPageObjects.SubmissionSearchBox, AERNO);
				agJavaScriptExecuctorClick(SubmissionPageObjects.SearchIcon);
				if (agIsVisible(FDE_SubmissionTrackingPageObjects.NoRecordFoundMsg) == true) {
					agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);

				} else if (agGetText(SubmissionPageObjects.aerno_Link).contains(AERNO)) {
					Reports.ExtentReportLog("", Status.INFO, "Contacts Uploaded in Submission Screen", true);
					break;
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.INFO, "Refresh the page till AERNO Dislayed Fails", true);

		}
		Reports.ExtentReportLog("", Status.INFO, "Refresh the page till AERNO Dislayed ENds", true);
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is create to Verification of Report Generation
	 *             for each contact .
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 28-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyGenerationofBfarmReport() {

		try {

			Reports.ExtentReportLog("", Status.INFO,
					"Verification of Bfarm Report Generation in Submission Listing Screen Started", true);
			ArrayList<String> Names = FDE_SubmissionTrackingOperation.GetContactListFromExcel();
			int count = Names.size() - 1;
			for (int i = 0; i < count; i++) {
				String Contact = Names.get(i);
				if (agIsVisible(SubmissionPageObjects.clickReportFormat(SubmissionPageObjects.BfArM)) == true) {
					if (agGetText(SubmissionPageObjects.ContactName(Contact)).contains("BfArM")) {
						agJavaScriptExecuctorClick(SubmissionPageObjects.ContactName(Contact));
						agSetStepExecutionDelay("3000");
						agClick(SubmissionPageObjects.InformedAuthorityTab);
						if (agIsVisible(SubmissionPageObjects.InformedAuthorityBfarmReport) == true) {
							Reports.ExtentReportLog("", Status.INFO, "Befarm Report is created for " + Contact + "",
									true);

						}
						agClick(SubmissionPageObjects.SourceDocumentVerification);
						agGetCurrentWindow();
						agSetStepExecutionDelay("6000");
						Reports.ExtentReportLog("", Status.INFO, "Befarm Report In PDF Format", true);
						// FDE_Operations.openReports("BfArM");
						// FDE_Operations.downloadPDF();
						CommonOperations.move_DownloadedReport("Bfarm_REPORT", scenarioName);

						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_General",
								"Gen_CaseSpecificInformation_CountryOfDetection");

						// CommonOperations.verifyDataVisible_DownloadedReport("CIOMS_REPORT",
						// scenarioName, "FDE_Patient", "Patient_PatientIdentifiers_PatientID");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_Patient",
								"Patient_PatientIdentifiers_Gender");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_Patient",
								"Patient_PatientIdentifiers_AgeAtTheTimeOfEvent");
						// CommonOperations.verifyDataVisible_DownloadedReport("CIOMS_REPORT",
						// scenarioName, "FDE_Patient",
						// "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent_Units");
						// CommonOperations.verifyDataVisible_DownloadedReport("CIOMS_REPORT",
						// scenarioName, "FDE_Patient",
						// "Patient_PatientIdentifiers_MedHistoryAndConcurCond");

						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_Events",
								"Events_EventInformation_ReportedTerm");

						// CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT",
						// scenarioName,
						// "FDE_Products", "Products_ProductInformation_ProductCharacterization");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Products", "Products_ProductInformation_ProductDescription_ProductName");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Products", "Products_Indications_IndicationTerm");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Products", "Products_Therapies_DailyDose");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Products", "Products_Therapies_DailyDoseUnit");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Products", "Products_Therapies_RouteOfAdmin");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Products", "Products_Ingredients_ActiveSubstance");
						// CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT",
						// scenarioName,
						// "FDE_Products", "Products_Therapies_LotNumber");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Products", "Products_Therapies_FormOfAdmin");

						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Literature", "Literature_LiteratureInformation_ArticleTitle");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Literature", "Literature_LiteratureInformation_JournalTitle");

						// CommonOperations.verifyDataVisible_DownloadedReport("CIOMS_REPORT",
						// scenarioName, "FDE_Narrative", "Narrative_EventDescription");

						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_LabData",
								"Labdata_Tests_TestName");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_LabData",
								"Labdata_Tests_TestResultValue");
						// CommonOperations.verifyDataVisible_DownloadedReport("CIOMS_REPORT",
						// scenarioName, "FDE_LabData", "Labdata_Tests_TestResultValueUnit");
						// //commented due to value not been set while entering data
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_LabData",
								"Labdata_Tests_NormalValueLow");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_LabData",
								"Labdata_Tests_NormalValueHigh");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_LabData",
								"Labdata_ResultofTests_LabComments");
						// CommonOperations.verifyDataVisible_DownloadedReport("CIOMS_REPORT",
						// scenarioName, "FDE_LabData", "Labdata_Tests_ResultUnstructuredDataFreeText");
						agCloseCurrentWindow();
						agSetStepExecutionDelay("6000");
						agGetWindowControlByInstance(1);
						agGetCurrentWindow();

						agClick(SubmissionPageObjects.DocumentSubmisionTab);
						agSetStepExecutionDelay("3000");
						agClick(SubmissionPageObjects.REgulatoryDocumnet);
						agGetCurrentWindow();
						agSetStepExecutionDelay("6000");
						Reports.ExtentReportLog("", Status.INFO, "Befarm Report in PDF Format under Document Section",
								true);
						// FDE_Operations.openReports("BfArM");
						// FDE_Operations.downloadPDF();
						CommonOperations.move_DownloadedReport("Bfarm_REPORT", scenarioName);

						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_General",
								"Gen_CaseSpecificInformation_CountryOfDetection");

						// CommonOperations.verifyDataVisible_DownloadedReport("CIOMS_REPORT",
						// scenarioName, "FDE_Patient", "Patient_PatientIdentifiers_PatientID");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_Patient",
								"Patient_PatientIdentifiers_Gender");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_Patient",
								"Patient_PatientIdentifiers_AgeAtTheTimeOfEvent");
						// CommonOperations.verifyDataVisible_DownloadedReport("CIOMS_REPORT",
						// scenarioName, "FDE_Patient",
						// "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent_Units");
						// CommonOperations.verifyDataVisible_DownloadedReport("CIOMS_REPORT",
						// scenarioName, "FDE_Patient",
						// "Patient_PatientIdentifiers_MedHistoryAndConcurCond");

						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_Events",
								"Events_EventInformation_ReportedTerm");

						// CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT",
						// scenarioName,
						// "FDE_Products", "Products_ProductInformation_ProductCharacterization");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Products", "Products_ProductInformation_ProductDescription_ProductName");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Products", "Products_Indications_IndicationTerm");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Products", "Products_Therapies_DailyDose");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Products", "Products_Therapies_DailyDoseUnit");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Products", "Products_Therapies_RouteOfAdmin");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Products", "Products_Ingredients_ActiveSubstance");
						// CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT",
						// scenarioName,
						// "FDE_Products", "Products_Therapies_LotNumber");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Products", "Products_Therapies_FormOfAdmin");

						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Literature", "Literature_LiteratureInformation_ArticleTitle");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName,
								"FDE_Literature", "Literature_LiteratureInformation_JournalTitle");

						// CommonOperations.verifyDataVisible_DownloadedReport("CIOMS_REPORT",
						// scenarioName, "FDE_Narrative", "Narrative_EventDescription");

						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_LabData",
								"Labdata_Tests_TestName");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_LabData",
								"Labdata_Tests_TestResultValue");
						// CommonOperations.verifyDataVisible_DownloadedReport("CIOMS_REPORT",
						// scenarioName, "FDE_LabData", "Labdata_Tests_TestResultValueUnit");
						// //commented due to value not been set while entering data
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_LabData",
								"Labdata_Tests_NormalValueLow");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_LabData",
								"Labdata_Tests_NormalValueHigh");
						CommonOperations.verifyDataVisible_DownloadedReport("Bfarm_REPORT", scenarioName, "FDE_LabData",
								"Labdata_ResultofTests_LabComments");
						// CommonOperations.verifyDataVisible_DownloadedReport("CIOMS_REPORT",
						// scenarioName, "FDE_LabData", "Labdata_Tests_ResultUnstructuredDataFreeText");
						agCloseCurrentWindow();
						agSetStepExecutionDelay("6000");
						agGetWindowControlByInstance(1);
						agGetCurrentWindow();
						break;
					}

				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Reports.ExtentReportLog("", Status.INFO,
				"Verification of Bfarm Report Generation in Submission Listing Screen Completed", true);
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is create to submit Olt Contact locally in
	 *             Submission listing
	 * @InputParameters: scenarioName,index
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date:11-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void submitOLTDistributeContacts(String scenarioName, String AERNo) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Reports.ExtentReportLog("", Status.INFO, "Submit Distribute Contacts Started", true);
		try {
			/*
			 * agIsVisible(SubmissionPageObjects.OltContact);
			 * agClick(SubmissionPageObjects.OltContact);
			 */
			agWaitTillVisibilityOfElement(SubmissionPageObjects.OLTAERNoClick(AERNo));
			agClick(SubmissionPageObjects.OLTAERNoClick(AERNo));
			if (agIsVisible(SubmissionPageObjects.ok_btn))
				agClick(SubmissionPageObjects.ok_btn);
			agWaitTillVisibilityOfElement(SubmissionPageObjects.localSubmission);
			SubmissionOperations.subMenuNavigations("Informed Authority");
			agSetStepExecutionDelay("2000");
			SubmissionOperations.setReportStatusDownValue(scenarioName, "InformedAuthority_ReportingStatus");
			agSetStepExecutionDelay("4000");
			agSetValue(SubmissionPageObjects.dateInformedTextBox, CommonOperations
					.returnDateTime(getTestDataCellValue(scenarioName, "InformedAuthority_DateInformed")));

			if (scenarioName.equalsIgnoreCase("PWTest_sce4_FDE_OLTZerothVersion")) {
				SubmissionOperations.setReasonForNotReportingDownValue(scenarioName, "ReasonForNotReporting");
				agClick(SubmissionPageObjects.submissionSave);

			} else {
				agMouseHover(FullDataEntryFormPageObjects.Submissionlistingactions_Btn);
				agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.completeActivity_link);
			}

			agSetStepExecutionDelay("10000");
			agWaitTillVisibilityOfElement(SubmissionPageObjects.contactSubmissionPopUp);
			agClick(SubmissionPageObjects.ok_btn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		} catch (Exception e) {
			e.printStackTrace();
		}
		Reports.ExtentReportLog("", Status.INFO, "Submit Distribute Contacts Completed", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 27-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setReasonForNotReportingDownValue(String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(SubmissionPageObjects.clickNotReportStatus);
			agClick(SubmissionPageObjects.SetNotReportStatusDropdown(getTestDataCellValue(scenarioName, columnName)));

		}
	}

	/**********************************************************************************************************
	 * @Objective: Submission processor and compare XML
	 * @InputParameters: AERNo, ScenarioName
	 * @OutputParameters:NA
	 * @author:Dushyanth Mahesh
	 * @Date : 15-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void submission_Processor(String recieptNumber, String AERNo, String ScenarioName, String contactName,
			String creationType) throws InterruptedException {

		// ScenarioName = "PairwiseTesting_20_R3Import_13072020";
		SubmissionOperations.SubmissionAERNoSearch(AERNo, contactName);
		SubmissionOperations.WPAdownloadXML(recieptNumber, "E2BReport", ScenarioName);

		// if (creationType.equalsIgnoreCase("R3XML"))
		// R3XmlCompareOperations.compareR3XML(lsmvConstants.LSMV_xslFilePath,
		// lsmvConstants.LSMV_WPAsourceFolderPath,
		// lsmvConstants.LSMV_WPAdestFolderPath, lsmvConstants.LSMV_compFolderPath,
		// ScenarioName);
		// else if (creationType.equalsIgnoreCase("R2XML"))
		// R2XmlCompareOperations.compareR2XML(lsmvConstants.LSMV_xslFilePath,
		// lsmvConstants.LSMV_WPAsourceFolderPath,
		// lsmvConstants.LSMV_WPAdestFolderPath, lsmvConstants.LSMV_compFolderPath,
		// ScenarioName);

	}

	/**********************************************************************************************************
	 * @Objective: The Below method is create to submit locally in SUbmission
	 *             listing
	 * @InputParameters: scenarioName,index
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date:21-July-2020
	 * @UpdatedByAndWhen:WajahatUmar S on 06/08/2020
	 **********************************************************************************************************/
	public static void submitDistributeContacts(String scenarioName, String index) {
		Reports.ExtentReportLog("", Status.INFO, "Submit Distribute Contacts Started", true);
		try {
			List<WebElement> ContactCount = agGetElementList(SubmissionPageObjects.listOfContacts);
			for (int i = 0; i < ContactCount.size(); i++) {
				agSetStepExecutionDelay("2000");
				agIsVisible(SubmissionPageObjects.getContacts(Integer.toString(i + 1)));
				agJavaScriptExecuctorClick(SubmissionPageObjects.getContacts(Integer.toString(i + 1)));
				// SubmissionOperations.subMenuNavigations("Informed Authority");
				agClick(SubmissionPageObjects.navigateToInformAuthorityTab);
				agMouseHover(FullDataEntryFormPageObjects.Submissionlistingactions_Btn);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.completeActivity_link);
				agSetStepExecutionDelay("10000");
				status = agIsVisible(SubmissionPageObjects.datainformPopUp);
				if (status) {
					agClick(SubmissionPageObjects.ok_btn);
					if (scenarioName.equalsIgnoreCase("LSMV_DeleteteNullifiedCase")
							|| scenarioName.equalsIgnoreCase("LSMV_DeleteteNullifiedCaseV1")) {
						Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
						SubmissionOperations.setReportStatusDownValue(scenarioName,
								"InformedAuthority_ReportingStatus");
						agSetStepExecutionDelay("4000");
						agSetValue(SubmissionPageObjects.dateInformedTextBox, CommonOperations
								.returnDateTime(getTestDataCellValue(scenarioName, "InformedAuthority_DateInformed")));
						agClick(SubmissionPageObjects.navigateToGeneralTab);
						agIsVisible(SubmissionPageObjects.submissionDueDate);
						agSetValue(SubmissionPageObjects.submissionDueDate, CommonOperations
								.returnDateTime(getTestDataCellValue(scenarioName, "Submission_DueDate")));
						clickLocalLabeling();
						agClick(SubmissionPageObjects.regenerateBtn);
					} else {
						clickLocalLabeling();
						setSubmissionLocalLabelling(scenarioName, index);
						clickRegenerate();
						agIsVisible(SubmissionPageObjects.getContacts(Integer.toString(i + 1)));
						agJavaScriptExecuctorClick(SubmissionPageObjects.getContacts(Integer.toString(i + 1)));
						// SubmissionOperations.subMenuNavigations("Informed Authority");
						agClick(SubmissionPageObjects.navigateToInformAuthorityTab);
						SubmissionOperations.setReportStatusDownValue(scenarioName,
								"InformedAuthority_ReportingStatus");
						agSetStepExecutionDelay("4000");
						agSetValue(SubmissionPageObjects.dateInformedTextBox, CommonOperations
								.returnDateTime(getTestDataCellValue(scenarioName, "InformedAuthority_DateInformed")));
						agMouseHover(FullDataEntryFormPageObjects.actions_Btn);
						agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.completeActivity_link);
						agSetStepExecutionDelay("10000");
					}
				}
				agWaitTillVisibilityOfElement(SubmissionPageObjects.contactSubmissionPopUp);
				agClick(SubmissionPageObjects.ok_btn);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Reports.ExtentReportLog("", Status.INFO, "Submit Distribute Contacts Completed", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search the receiptno
	 * @InputParameters: Scenario Name, sheetName, columnName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 22-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchReceiptNo(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		SubmissionOperations.submission_MenuNavigations("submissionListing");
		agSetStepExecutionDelay("2000");
		agSetValue(SubmissionPageObjects.SubmissionSearchBox, getTestDataCellValue(scenarioName, columnName));
		agClick(SubmissionPageObjects.SearchIcon);
		agSetStepExecutionDelay("2000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify nullification icon in
	 *             submission listing
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 22-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyNullificationIconinSubmissionListing() {
		Reports.ExtentReportLog("", Status.INFO, "verify nullification icon in submission listing Started", true);
		try {
			agSetStepExecutionDelay("10000");
			List<WebElement> ContactCount = agGetElementList(SubmissionPageObjects.listOfContacts);
			for (int i = 0; i < ContactCount.size(); i++) {

				status = agIsVisible(SubmissionPageObjects.checkNullificationIcon(Integer.toString(i + 1)));
				if (status) {
					Reports.ExtentReportLog("", Status.INFO, "Nullification Icon exist and visible", true);
				} else {
					Reports.ExtentReportLog("", Status.INFO, "Nullification Icon is not exist", true);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Reports.ExtentReportLog("", Status.INFO, "verify nullification icon in submission listing Completed", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to do Bulk And Batch Print and
	 *             Download
	 * @InputParameters: ScenarioName
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 03-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void BulkAndBatchPrintDownload(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Bulk And Batch Print and Download Starts ", true);

		Connection dbCon = null;
		try {
			submission_MenuNavigations("submissionListing");
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);
			ResultSet rs = DataBaseOperations.performRead(dbCon,
					"SELECT * FROM dataassessmentoperations WHERE Scenario = '" + scenarioName + "'");
			rs.last();
			rs.beforeFirst();
			rs.next();
			String AERNo = rs.getString("AERNo");
			agWaitTillInvisibilityOfElement(SubmissionPageObjects.LoadingIcon);
			agWaitTillVisibilityOfElement(SubmissionPageObjects.SubmissionSearchBox);
			BulkAndBatchDownload(AERNo);
			BulkAndBatchPrint(AERNo);
			Reports.ExtentReportLog("", Status.INFO, "Bulk And Batch Print and Download Ends ", true);
		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, "Bulk And Batch Print and Download Failed ", true);
		} finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to do Bulk And Batch Download
	 * @InputParameters: AERNo
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 03-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void BulkAndBatchDownload(String AERNo) {
		Reports.ExtentReportLog("", Status.INFO, "Bulk And Batch Download Starts ", true);
		try {
			agSetValue(SubmissionPageObjects.SubmissionSearchBox, AERNo);
			agClick(SubmissionPageObjects.SearchIcon);
			agWaitTillInvisibilityOfElement(SubmissionPageObjects.processingIcon);
			agClick(SubmissionPageObjects.filter_icon);
			agWaitTillVisibilityOfElement(SubmissionPageObjects.ReportFormat);
			agClick(SubmissionPageObjects.ReportFormat);
			agClick(SubmissionPageObjects.ReportFormatE2BClick);
			// Batch Download
			List<WebElement> checkBox = agGetElementList(SubmissionPageObjects.checkBox);
			int numberOfRows = checkBox.size();
			for (int index = 1; index <= numberOfRows; index++) {
				try {
					if (!agIsVisible(SubmissionPageObjects.CheckBoxBulkAndBatch.replace("%index", index + ""))) {
						continue;
					}
					agClick(SubmissionPageObjects.CheckBoxBulkAndBatch.replace("%index", index + ""));
					agMouseHover(SubmissionPageObjects.DownloadButtonHover);
					agWaitTillVisibilityOfElement(SubmissionPageObjects.DownloadAsBatch);
					agClick(SubmissionPageObjects.DownloadAsBatch);
					agClick(SubmissionPageObjects.CheckBoxBulkAndBatch.replace("%index", index + ""));
				} catch (Exception ex) {
					System.out.println(ex);
				}
			}

			// Bulk Download
			agClick(SubmissionPageObjects.SelectAllCheckBox);
			agMouseHover(SubmissionPageObjects.DownloadButtonHover);
			agWaitTillVisibilityOfElement(SubmissionPageObjects.DownloadAsBulk);
			agClick(SubmissionPageObjects.DownloadAsBulk);
			agClick(SubmissionPageObjects.filter_icon);
			Reports.ExtentReportLog("", Status.INFO, "Bulk And Batch Download Ends ", true);
		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.INFO, "Bulk And Batch Download Failed ", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to do Bulk And Batch Print
	 * @InputParameters: AERNo
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 03-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void BulkAndBatchPrint(String AERNo) {
		Reports.ExtentReportLog("", Status.INFO, "Bulk And Batch Print Starts ", true);
		try {
			agSetValue(SubmissionPageObjects.SubmissionSearchBox, AERNo);
			agClick(SubmissionPageObjects.SearchIcon);
			agWaitTillInvisibilityOfElement(SubmissionPageObjects.processingIcon);
			agClick(SubmissionPageObjects.SelectAllCheckBox);
			// Batch Print
			batchPrint();
			// Bulk Print
			agSetStepExecutionDelay("5000");
			agMouseHover(SubmissionPageObjects.PrintButtonHover);
			agWaitTillVisibilityOfElement(SubmissionPageObjects.BulkPrint);
			agJavaScriptExecuctorClick(SubmissionPageObjects.BulkPrint);
			agSetStepExecutionDelay(Constants.defaultGlobalStepExecutionDelay + "");
			Thread.sleep(15000);
			Reports.ExtentReportLog("", Status.INFO, "Bulk And Batch Print Ends ", true);

		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.INFO, "Bulk And Batch Print Failed ", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to do Batch Print
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 03-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void batchPrint() {
		try {
			agMouseHover(SubmissionPageObjects.PrintButtonHover);
			agWaitTillVisibilityOfElement(SubmissionPageObjects.BatchPrint);
			agJavaScriptExecuctorClick(SubmissionPageObjects.BatchPrint);
			int i = 0, sz = agGetWindowCount();
			agSetStepExecutionDelay("5000");
			while (!(sz == 2) && i < 75) {
				sz = agGetWindowCount();
				i++;
				System.out.println("Waiting" + i);
			}
			agGetCurrentWindow();
			agSetStepExecutionDelay("3000");
			Reports.ExtentReportLog("", Status.PASS, "Batch Print is Successfull", true);
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) // Hard wait is used reason file to get download taking time
			{
				e.printStackTrace();

			}
			agCloseCurrentWindow();
			agGetWindowControlByInstance(1);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} catch (Exception ex) {
			Reports.ExtentReportLog("", Status.FAIL, " Batch Print Failed", true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify Literature Reference in
	 *             Submission
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 09-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyLiteratureReference(String scenarioName) {
		agSetStepExecutionDelay("2000");
		agClick(SubmissionPageObjects.expandSourceDocs);
		agIsVisible(SubmissionPageObjects.sourceDocsLink);
		agIsVisible(SubmissionPageObjects.sourceDocsLiteratureCheck);
		System.out.print("literature reference is available in submission");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created filter the list by AER and Contact
	 *             value
	 * @Pre-requisite: User Should be directed to the Submission listing pae
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 02-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void filterByContactNameAndAERNumber(String scenarioAER, String scenarioContact) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "DataAssessmentOperations");
		String aerNo = DataAssessmentOperations.getData(scenarioAER, "AERNo");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(SubmissionPageObjects.filter_icon);
		agSetStepExecutionDelay("4000");
		agClick(SubmissionPageObjects.Contactname_textbox);
		agSetValue(SubmissionPageObjects.Contactname_textbox, getTestDataCellValue(scenarioContact, "ContactName"));
		agClick(SubmissionPageObjects.AERNo_textbox);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(SubmissionPageObjects.AERNo_textbox, aerNo);
		agClick(SubmissionPageObjects.SearchIcon);
		agSetStepExecutionDelay("3000");
		agClick(SubmissionPageObjects.statusColumnHeader);
		Reports.ExtentReportLog("", Status.PASS, "", true);
		agWaitTillVisibilityOfElement(SubmissionPageObjects.aerno_Link);
		Reports.ExtentReportLog("", Status.INFO, "Contact name provided with Aer No is filtered", false);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to validate EasyView Content
	 * @Pre-requisite: The list the Submissions Listing page should be filtered and
	 *                 in focus In LSMV_ConfigurationSettings sheet, set
	 *                 openPDFExternally as TRUE
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 02-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyEasyViewContent(String scenarioName, String scenarioName2) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String contact = getTestDataCellValue(scenarioName, "ContactName");

		agJavaScriptExecuctorClick(SubmissionPageObjects.ReportFormatE2B(contact));
		agSetStepExecutionDelay("6000");
		agWaitTillVisibilityOfElement(SubmissionPageObjects.EasyViewBtn);
		agJavaScriptExecuctorClick(SubmissionPageObjects.EasyViewBtn);
		agSetStepExecutionDelay("5000");

		int k = 0, sz = agGetWindowCount();
		agSetStepExecutionDelay("5000");
		while (!(sz == 2) && k < 75) {
			sz = agGetWindowCount();
			k++;
			System.out.println("Waiting" + k);
		}
		// switching the driver control to Context View window
		agGetCurrentWindow();

		// Waiting for the file to get downloaded
		File file = new File(lsmvConstants.LSMV_testDataOutput + "\\" + "EasyView_.pdf");
		do {
			agSetStepExecutionDelay("3000");
		} while (!file.exists());

		// Moving the File
		String path = lsmvConstants.LSMV_testDataOutput + "\\" + Reports.currenttime();
		lsmvConstants.path = path;
		FileSystemOperations.createFolder(path);
		FileSystemOperations.moveFile("EasyView_.pdf", lsmvConstants.LSMV_testDataOutput, path);

		if (FDE_General.getData(scenarioName2, "Gen_AdditionalDocumentsAvailable").equalsIgnoreCase("Yes")) {
			PDFOperations.pdfverificationForVisible(lsmvConstants.path + "\\" + "EasyView_.pdf", "Yes(1)");
			PDFOperations.pdfverificationForVisible(lsmvConstants.path + "\\" + "EasyView_.pdf", FDE_General
					.getData(scenarioName2, "Gen_AdditionalDocumentsAvailable_ListOfDocumentsHeldByTheSender"));
		} else {
			PDFOperations.pdfverificationForVisible(lsmvConstants.path + "\\" + "EasyView_.pdf",
					FDE_General.getData(scenarioName2, "Gen_AdditionalDocumentsAvailable"));
		}

		agCloseCurrentWindow();
		agGetWindowControlByInstance(1);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		agClick(SubmissionPageObjects.closeDownloadPopUp);
	}

	/**********************************************************************************************************
	 * @Objective:
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @throws InterruptedException
	 * @Date : 04-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String downloadPDFFile(String scenarioName){
		String fileName = null;
		String path = null;
		agWaitTillVisibilityOfElement(SubmissionPageObjects.clickXML);
		agClick(SubmissionPageObjects.clickXML);
		agWaitTillVisibilityOfElement(SubmissionPageObjects.EasyViewBtn);
		agClick(SubmissionPageObjects.EasyViewBtn);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int i = 0, sz = agGetWindowCount();
		agSetStepExecutionDelay("5000");
		while (!(sz == 2) && i < 75) {
			sz = agGetWindowCount();
			i++;
			System.out.println("Waiting" + i);
		}
		agGetCurrentWindow();
		agSetStepExecutionDelay("3000");
		
		// Move File
		fileName = "EasyView_.pdf";
		path = lsmvConstants.LSMV_testDataOutput + "\\" + Reports.currenttime();
		lsmvConstants.path = path;
		System.out.println(lsmvConstants.path);
		FileSystemOperations.createFolder(path);
		agSetStepExecutionDelay("5000");
		
		String tempFilePath = lsmvConstants.LSMV_testDataOutput + "\\" + "EasyView_.pdf";
		File file = new File(tempFilePath);		
		do{			
			//System.out.println("Waiting to get the file downloaded. Iteration "+ ++i);
			agSetStepExecutionDelay("5000");	      
		}while(!file.exists());
		
		FileSystemOperations.moveFile(fileName, lsmvConstants.LSMV_testDataOutput, path);
		
		agCloseCurrentWindow();
		agGetWindowControlByInstance(1);

		Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
		agClick(SubmissionPageObjects.closeDownloadPopUp);
		
		return path + "\\" + fileName;
	}

	/**********************************************************************************************************
	 * @Objective: Push the case to 'Submit' or 'Do Not Submit' Activity
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @throws InterruptedException
	 * @Date : 04-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void pushToSubmitOrDoNotSubmit(String scenarioAER, String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "DataAssessmentOperations");
		String aerNo = DataAssessmentOperations.getData(scenarioAER, "AERNo");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String submitVal = getTestDataCellValue(scenarioName, "Submission_Activity");
		System.out.println("submitVal: " + submitVal);

		agWaitTillVisibilityOfElement(
				SubmissionPageObjects.EditAEr(aerNo));
		agClick(SubmissionPageObjects.EditAEr(aerNo));

		setReportingStatus(scenarioName);

		agSetStepExecutionDelay("2000");
		agClick(SubmissionPageObjects.selectActivity);
		agClick(SubmissionPageObjects.selectActivity_DropDown(submitVal));

		Reports.ExtentReportLog("", Status.PASS, "", true);	
		agMouseHover(SubmissionPageObjects.actions_Btn);
		agClick(SubmissionPageObjects.completeActivity_Btn);
		agWaitTillVisibilityOfElement(SubmissionPageObjects.contactSubmissionPopUp);
		Reports.ExtentReportLog("", Status.PASS, "", true);	
		
		if (agGetText(SubmissionPageObjects.acknowledgement_type).toUpperCase().contains("INFO")) {
			Reports.ExtentReportLog("", Status.INFO,
					"Acknowledgement: " + agGetText(SubmissionPageObjects.acknowledgement_message), true);
		} else {
			Reports.ExtentReportLog("", Status.INFO,
					"Acknowledgement: " + agGetText(SubmissionPageObjects.acknowledgement_message), true);
		}
		agClick(SubmissionPageObjects.ok_btn);
	}

	/**********************************************************************************************************
	 * @Objective: Push the case to 'Submit' or 'Do Not Submit' Activity
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @throws InterruptedException
	 * @Date : 04-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setReportingStatus(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String reasonVal = getTestDataCellValue(scenarioName, "ReportingStatus");

		agClick(SubmissionPageObjects.localSubmission_Menu("Informed Authority"));
		agWaitTillVisibilityOfElement(SubmissionPageObjects.LS_ReportingStatus_Dropdown);
		agClick(SubmissionPageObjects.LS_ReportingStatus_Dropdown);
		agClick(SubmissionPageObjects.reportStatus_DropdownSelect(reasonVal));
		Reports.ExtentReportLog("", Status.INFO, "Drop down value selected", true);
		agSetValue(SubmissionPageObjects.reason_TextArea, getTestDataCellValue(scenarioName, "ReportingStatus_Reason"));
		Reports.ExtentReportLog("", Status.INFO, "Reporting reason keyed", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify the Activity Due Date
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @throws:
	 * @Date : 15-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyActivityDueDate(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Activity Due Date Verification Starts", false);
			submission_MenuNavigations("submissionListing");
			agWaitTillInvisibilityOfElement(SubmissionPageObjects.LoaderIcon);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, DataAssessmentOperations.class.getSimpleName());
			String AERNo = getTestDataCellValue(scenarioName, "AERNo");
			agSetValue(SubmissionPageObjects.SubmissionSearchBox, AERNo);
			agClick(SubmissionPageObjects.SearchIcon);
			agWaitTillInvisibilityOfElement(SubmissionPageObjects.processingIcon);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, WorkFlowOperations.class.getSimpleName());
			agClick(SubmissionPageObjects.filter_icon);
			agSetStepExecutionDelay("4000");
			agClick(SubmissionPageObjects.Contactname_textbox);
			agSetValue(SubmissionPageObjects.Contactname_textbox, getTestDataCellValue(scenarioName, "ContactName"));
			agClick(SubmissionPageObjects.ReportFormat);
			agWaitTillVisibilityOfElement(SubmissionPageObjects.aerno_Link);
			agClick(SubmissionPageObjects.aerno_Link);
			agWaitTillInvisibilityOfElement(SubmissionPageObjects.aerno_Link);
			String submissionStatus = agGetText(SubmissionPageObjects.SubmissionStatus);
			verifyActivityDueDate(scenarioName, submissionStatus);
			if (!submissionStatus.equalsIgnoreCase("Submission Review")) {
				agMouseHover(FullDataEntryFormPageObjects.Submissionlistingactions_Btn);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.completeActivity_link);
				agWaitTillVisibilityOfElement(SubmissionPageObjects.ActionCompletedSucessfully);
				agClick(SubmissionPageObjects.ActionCompletedSucessfullyOK);
				agWaitTillInvisibilityOfElement(SubmissionPageObjects.ActionCompletedSucessfullyOK);
			} else {
				agClick(SubmissionPageObjects.cancelBtn);
				agWaitTillInvisibilityOfElement(SubmissionPageObjects.cancelBtn);
			}
			Reports.ExtentReportLog("", Status.INFO, "Activity Due Date Verification Ends", false);
		} catch (Exception ex) {
			Reports.ExtentReportLog("", Status.FAIL, "Activity Due Date Verification Failed", false);

		}
	}

	/**********************************************************************************************************
	 * @Objective: Verify the Activity Due Date
	 * @InputParameters: scenarioName, Submission Status
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @throws:
	 * @Date : 15-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyActivityDueDate(String scenarioName, String submissionStatus) {
		String CaseDueDate = "";
		String DueDateValue = "";
		String AffDueDateTimeLine = "";
		String reportDays = getTestDataCellValue(scenarioName, "ReportDays");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, FDE_General.class.getSimpleName());
		String LRD = CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Gen_CaseDates_LatestReceivedDate"));
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, WorkFlowOperations.class.getSimpleName());
		switch (submissionStatus) {
		case "Initial":
			CaseDueDate = getTestDataCellValue(scenarioName, "InitialCaseDueDate");
			DueDateValue = getTestDataCellValue(scenarioName, "InitialActivityDueDateValue");
			AffDueDateTimeLine = getTestDataCellValue(scenarioName, "AffDueDateTimeLine");
			if (CaseDueDate.equalsIgnoreCase("Submission Due Date")) {
				ActivityDueDateUsingSubmissionDueDate(LRD, reportDays, DueDateValue);
			} else if (CaseDueDate.equalsIgnoreCase("Affiliate Submission Due Date")) {
				ActivityDueDateUsingAffiliateDueDate(AffDueDateTimeLine, DueDateValue);
			}
			break;
		case "Local Submission":
			CaseDueDate = getTestDataCellValue(scenarioName, "LocalSubmissionCaseDueDate");
			DueDateValue = getTestDataCellValue(scenarioName, "LocalSubmissionActivityDueDateValue");
			AffDueDateTimeLine = getTestDataCellValue(scenarioName, "AffDueDateTimeLine");

			if (CaseDueDate.equalsIgnoreCase("Submission Due Date")) {
				ActivityDueDateUsingSubmissionDueDate(LRD, reportDays, DueDateValue);
			} else if (CaseDueDate.equalsIgnoreCase("Affiliate Submission Due Date")) {
				ActivityDueDateUsingAffiliateDueDate(AffDueDateTimeLine, DueDateValue);
			}
			break;
		case "Submission Review":
			CaseDueDate = getTestDataCellValue(scenarioName, "SubmissionReviewCaseDueDate");
			DueDateValue = getTestDataCellValue(scenarioName, "SubmissionReviewActivityDueDateValue");
			AffDueDateTimeLine = getTestDataCellValue(scenarioName, "AffDueDateTimeLine");
			if (CaseDueDate.equalsIgnoreCase("Submission Due Date")) {
				ActivityDueDateUsingSubmissionDueDate(LRD, reportDays, DueDateValue);
			} else if (CaseDueDate.equalsIgnoreCase("Affiliate Submission Due Date")) {
				ActivityDueDateUsingAffiliateDueDate(AffDueDateTimeLine, DueDateValue);
			}
			break;
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verify the Activity Due Date using Submission Due Date
	 * @InputParameters: Latest Received Date, reportDays, DueDateValue
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @throws:
	 * @Date : 15-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ActivityDueDateUsingSubmissionDueDate(String LRD, String reportDays, String DueDateValue) {
		int noOfDays = Integer.parseInt(DueDateValue) * Integer.parseInt(reportDays) / 100;
		int modValue = Integer.parseInt(DueDateValue) % 2;
		if (modValue != 0)
			noOfDays = noOfDays + 1;
		if (modValue != 0)
			noOfDays = noOfDays + 1;
		int actDate = Integer.parseInt(reportDays) - noOfDays;
		String calculatedADD = CommonOperations.returnDateTime("d-" + actDate + ":m:y");
		String ADD = agGetAttribute("value", SubmissionPageObjects.ADD);
		if (ADD.equalsIgnoreCase(calculatedADD)) {
			Reports.ExtentReportLog("", Status.PASS,
					"Activity Due Date is calculated correctly as per Submission Due Date", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Activity Due Date is calculated incorrectly as per Submission Due Date", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: Verify the Activity Due Date using Afiiliate Due Date
	 * @InputParameters: Timeline,DueDateValue
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @throws:
	 * @Date : 15-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ActivityDueDateUsingAffiliateDueDate(String timeline, String DueDateValue) {
		int noOfDays = Integer.parseInt(DueDateValue) * Integer.parseInt(timeline) / 100;
		int modValue = Integer.parseInt(DueDateValue) % 2;
		if (modValue != 0)
			noOfDays = noOfDays + 1;
		String calculatedADD = CommonOperations.returnDateTime("d+" + noOfDays + ":m:y");
		String ADD = agGetAttribute("value", SubmissionPageObjects.ADD);
		if (ADD.equalsIgnoreCase(calculatedADD)) {
			Reports.ExtentReportLog("", Status.PASS,
					"Activity Due Date is calculated correctly as per Affiliate Due Date", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Activity Due Date is calculated incorrectly as per Affiliate Due Date", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to validate EasyView Content by
	 *             selecting the contact name
	 * @Pre-requisite:
	 * @InputParameters: scenarioName,Filename
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 16-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void easyViewContentVerification(String scenarioName, String fileName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String contact = getTestDataCellValue(scenarioName, "ContactName");

		agJavaScriptExecuctorClick(SubmissionPageObjects.ReportFormatE2B(contact));
		agSetStepExecutionDelay("6000");
		agWaitTillVisibilityOfElement(SubmissionPageObjects.EasyViewBtn);
		Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
		agJavaScriptExecuctorClick(SubmissionPageObjects.EasyViewBtn);
		agSetStepExecutionDelay("5000");

		// Download
		FDE_Operations.downloadPDFinListing();

		// Move file to destination
		CommonOperations.move_DownloadedPDF(fileName);

		agClick(SubmissionPageObjects.closeDownloadPopUp);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to retreive the Patient ID
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 16-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void getPatientIDAndVerifyInXMLView(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String contact = getTestDataCellValue(scenarioName, "ContactName");

		agJavaScriptExecuctorClick(SubmissionPageObjects.ReportFormatE2B(contact));
		agSetStepExecutionDelay("6000");
		// String patientID = "";
		String lines[] = agGetText(SubmissionPageObjects.submissionViewText).split("&nbsp;");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		for (String line : lines) {
			System.out.println("line :" + line);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Patient");
			if (line.contains(
					getTestDataCellValue("LSMV_ISPV0036_OQ_Update", "Patient_PatientIdentifiers_PatientID"))) {
				// patientID = line.split("Passcode for Weblink :")[1].trim();
				Reports.ExtentReportLog("", Status.PASS, "Patient ID Matched", true);
				break;
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Patient ID not Matched", true);

			}

		}
		agClick(SubmissionPageObjects.closeDownloadPopUp);
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is create to download xml , move and rename the
	 *             old filename to new filename in E2B MessageQueueListing based on
	 *             the selection of contacts
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @throws InterruptedException
	 * @Date : 16-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String downloadXML(String OldFileName, String NewFileName, String scenarioName)
			throws InterruptedException {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String contact = getTestDataCellValue(scenarioName, "ContactName");

		agJavaScriptExecuctorClick(SubmissionPageObjects.ReportFormatE2B(contact));
		agSetStepExecutionDelay("6000");

		agWaitTillVisibilityOfElement(SubmissionPageObjects.downloadButton);
		agClick(SubmissionPageObjects.downloadButton);
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int i = 0, sz = agGetWindowCount();
		agSetStepExecutionDelay("5000");
		while (!(sz == 2) && i < 75) {
			sz = agGetWindowCount();
			i++;
			System.out.println("Waiting" + i);
		}
		agGetCurrentWindow();
		agSetStepExecutionDelay("3000");

		// String path = lsmvConstants.LSMV_destFolderPath;
		String path = lsmvConstants.LSMV_testDataOutput + "\\" + Reports.currenttime();
		lsmvConstants.path = path;
		System.out.println(lsmvConstants.path);
		System.out.println("lsmvConstants.LSMV_testDataOutput: " + lsmvConstants.LSMV_testDataOutput);

		FileSystemOperations.createFolder(path);
		FileSystemOperations.moveFile(OldFileName + ".xml", lsmvConstants.LSMV_testDataOutput, path);
		FileSystemOperations.renameFile(path, OldFileName + ".xml", NewFileName + ".xml");

		// if (agIsExists(path)) {
		//
		// System.out.println("File exists");
		// Reports.ExtentReportLog("", Status.INFO, "XML file exist", true);
		// } else {
		//
		// System.out.println("File doesn't exist in specifiled path");
		// Reports.ExtentReportLog("", Status.INFO, "XML file not exist", true);
		// }

		// E2BMessageQueueOperations.Verify_DownloadedXml(OldFileName, NewFileName);
		agClick(SubmissionPageObjects.closeDownloadPopUp);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		return path + "\\" + NewFileName + ".xml";

	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to validate E2B EasyView Content
	 * @Pre-requisite: 
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 02-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyE2BR2AdditionalDocTag(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String contact = getTestDataCellValue(scenarioName, "ContactName");

		agClick(SubmissionPageObjects.ReportFormatE2B(contact));
		agSetStepExecutionDelay("2000");
		if(agIsExists(SubmissionPageObjects.submissionXMLView_AddDocR2Tag)) {
			//agClick(SubmissionPageObjects.submissionXMLView_AddDocR2Tag);
			agSetStepExecutionDelay("2000");
		}
		
		if(agIsExists(SubmissionPageObjects.submissionXMLView_DocListR2Tag)) {
		//agClick(SubmissionPageObjects.submissionXMLView_DocListR2Tag);
		agSetStepExecutionDelay("2000");
		}
		
		if (agIsExists(SubmissionPageObjects.submissionXMLView_AddDocR2Tag)) {
			Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
		}
		else {
			Reports.ExtentReportLog("", Status.FAIL, "Not As Expected", true);
		}

		agClick(SubmissionPageObjects.closeDownloadPopUp);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to validate E2B EasyView Content
	 * @Pre-requisite: 
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 02-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyE2BR3_AdditionalDocTag(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String contact = getTestDataCellValue(scenarioName, "ContactName");

		agClick(SubmissionPageObjects.ReportFormatE2B(contact));
		agSetStepExecutionDelay("2000");
		
		if(agIsExists(SubmissionPageObjects.submissionXMLView_AddDocR3Tag_1)) {
			//agClick(SubmissionPageObjects.submissionXMLView_AddDocR3Tag_1);
			agSetStepExecutionDelay("2000");
		}		
		
		if(agIsExists(SubmissionPageObjects.submissionXMLView_AddDocR3Tag_2)) {
			//agClick(SubmissionPageObjects.submissionXMLView_AddDocR3Tag_2);
			agSetStepExecutionDelay("2000");
		}
		
		if (agIsExists(SubmissionPageObjects.submissionXMLView_AddDocR3Tag_1)) {
			Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
		}
		else {
			Reports.ExtentReportLog("", Status.FAIL, "Not As Expected", true);
		}

		agClick(SubmissionPageObjects.closeDownloadPopUp);
	}
	
	/**********************************************************************************************************
	 * @Objective:
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @throws InterruptedException
	 * @Date : 04-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String downloadXMLFile(String scenarioName) throws InterruptedException {
		String fileName = null;
		String path = null;
		agWaitTillVisibilityOfElement(SubmissionPageObjects.clickXML);
		agClick(SubmissionPageObjects.clickXML);
		agWaitTillVisibilityOfElement(SubmissionPageObjects.downloadButton);
		agClick(SubmissionPageObjects.downloadButton);
		Thread.sleep(10000);

		// Move File
		fileName = "E2BReport.xml";
		path = lsmvConstants.LSMV_testDataOutput + "\\" + Reports.currenttime();
		lsmvConstants.path = path;
		System.out.println(lsmvConstants.path);
		FileSystemOperations.createFolder(path);
		
		String tempFilePath = lsmvConstants.LSMV_testDataOutput + "\\" + "E2BReport.xml";
		File file = new File(tempFilePath);		
		do{			
			//System.out.println("Waiting to get the file downloaded. Iteration "+ ++i);
			agSetStepExecutionDelay("5000");	      
		}while(!file.exists());

		agSetStepExecutionDelay("5000");	      
		FileSystemOperations.moveFile(fileName, lsmvConstants.LSMV_testDataOutput, path);
		
		Reports.ExtentReportLog("", Status.PASS, "", true);		
		agClick(SubmissionPageObjects.closeDownloadPopUp);
		
		return path + "\\" + fileName;
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to click on report 
	 * @Pre-requisite: 
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date : 02-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void Report(String rpname) {
		agClick(SubmissionPageObjects.reportLink(rpname));
	}
	
	

}
