package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class QuestionsPageObjects {
	
	public static String newbtn = "xpath#//a[text()='New']";
	public static String questionname_textbox = "xpath#//textarea[contains(@id,'questionnaireName')]";
	public static String questiontype_Dropdown = "xpath#";
	public static String context_Dropdown = "xpath#";
	public static String selectAlldropdownvalue = "xpath#//ul[contains(@id,'questionnariesFormDetails')]/li[text()='%s']";
	public static String clickAlldropdownvalue = "xpath#//label[@id='questionnariesFormDetails:%label%_label']";
	public static String questionTypelabel = "questionType";
	public static String modulelabel = "ruleModule";
	public static String formnamelabel = "formList1";
	public static String contextlabel = "ruleCContextList";
	public static String fieldlabel = "fieldList";
	public static String componentlabel = "questionnaireComponent";
	public static String displayOrderTextbox = "xpath#//input[@name='questionnariesFormDetails:questionnaire_Index']";
	public static String edit_Icon = "xpath#//img[@id='questionnarieslisting:questionaryDataTable:0:editIcon']";
	public static String Activelabel = "Active";
	public static String savebtn = "xpath#//button[@id='questionnariesFormDetails:visibleSave']/span[text()='Save']";
	public static String validationPopUp = "xpath#//span[text()='Action  Completed Successfully']";
	public static String questionNo = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String saveOkButton = "xpath#//button[@id='mandatoryDialogform:okButton']/span[text()='OK']";
	public static String paginator = "xpath#//div[@id='questionnarieslisting:questionaryDataTable_paginator_top']";
	public static String get_ListofQuestionName = "xpath#//tbody[@id='questionnarieslisting:questionaryDataTable_data']/ancestor::table/tbody/tr/td[4]";
	public static String columnHeader = "xpath#(//tbody[@id='questionnarieslisting:questionaryDataTable_data']/ancestor::table/tbody/tr/td[4])[{%count}]";
	public static String search_Icon = "xpath#//a[@id='questionnarieslisting:defaultSearch']";
	public static String keywordSearch_TxtField = "xpath#//input[@id='questionnarieslisting:keyword']";
	public static String cancelbtn = "xpath#//button[@id='questionnariesFormDetails:cancel']";
	
	/**********************************************************************************************************
	 * Objective:The below method is created to click Form Name,Module,Field,Component  and Show DropDown in
	 * Libraries question screen by passing label name at runtime. Input Parameters: label
	 * name Scenario Name Output Parameters:
	 * 
	 * @author:Pooja S Date :08-May-2020 Updated by and when
	 **********************************************************************************************************/
	public static String clickDropDown(String runTimeLabel) {
		String value = clickAlldropdownvalue;
		String value2;
		value2 = value.replace("%label%", runTimeLabel);
		return value2;
	}
	
	/**********************************************************************************************************
	 * Objective:he below method is created to click Form Name,Module,Field,Component  and Show DropDown in
	 * Libraries question screen by passing value at runtime. Input Parameters: ColumnName
	 * Scenario Name Output Parameters:
	 * 
	 * @author:Pooja S Date :08-May-2020 Updated by and when
	 **********************************************************************************************************/
	public static String selectDropdown(String runTimeLabel) {
		String value = selectAlldropdownvalue;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective:get Question name by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:Pooja S Date :08-May-2020 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderList(String num) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}
	
}
