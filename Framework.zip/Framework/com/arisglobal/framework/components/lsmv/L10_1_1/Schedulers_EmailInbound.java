package com.arisglobal.framework.components.lsmv.L10_1_1;


import com.arisglobal.framework.components.lsmv.L10_1_1.OR.EmailInboundSchedulers;
import com.arisglobal.framework.lib.main.ToolManager;

public class Schedulers_EmailInbound extends ToolManager {

	/**********************************************************************************************************
	 * @Objective: The below method is created to fetch RCT number from Activity Log.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Sagar S
	 * @Date : 05-04-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String getRCTNumber() {

		String[] rctNo = null;
		Boolean excFlag = Boolean.TRUE;
		agClick(EmailInboundSchedulers.activityLogTab);
		int tabelCnt = ToolManager.agGetElementList(EmailInboundSchedulers.logTableRowCount).size();

		for (int i = 1;i<=tabelCnt && excFlag;i++)
		{
			if (agGetText(EmailInboundSchedulers.getActionTaken(Integer.toString(i))).equalsIgnoreCase("Create"))
			{
				String rctText = agGetText(EmailInboundSchedulers.getRCTTxt(Integer.toString(i)));
				System.out.println(rctText);
				rctNo = rctText.split(" ");
				System.out.println(rctNo[1]);
				excFlag = Boolean.FALSE;
			}
			else
				i++;
		}	
		return rctNo[1];
	}

}
