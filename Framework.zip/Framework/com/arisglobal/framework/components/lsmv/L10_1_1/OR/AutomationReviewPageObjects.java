package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class AutomationReviewPageObjects {

	public static String automationReviewTab = "xpath#//span[text()='Automation Review']";
	public static String loader = "xpath#//img[@id='headerForm:j_id_1f']";
	public static String duplicatePolicy = "xpath#//div[@class='FdeduplicateSummary']//label";
	public static String Levellist = "xpath#//div[@class='FdeduplicateSummary']//tbody/tr/td[1]";
	public static String listofLevels = "xpath#//div[@class='FdeduplicateSummary']//tbody/tr[%count%]/td[1]";
	public static String foundCaseCounts = "xpath#//div[@class='FdeduplicateSummary']//tbody/tr[%count%]/td[3]";
	public static String listOfCase = "xpath#//div[text()='No records to display']";
	public static String criteriaApplied="xpath#//table[contains(@class,'duplicateSummaryTable')]//tr[1]/td//table/tr/td[1]";
	
	/**********************************************************************************************************
	 * @Objective:The below method is created to get the level runtime in Automation review tab
	 * @Input Parameters: 
	 * @Output Parameters:
	 * @author:Yashwanth Naidu
	 * @Date :11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String listOfLevelIndex(String count) {
		String value = listofLevels;
		String value2;
		value2 = value.replace("%count%", count);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective:The below method is created to get the counts of level runtime in Automation review tab
	 * @Input Parameters: 
	 * @Output Parameters:
	 * @author:Yashwanth Naidu
	 * @Date :11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String foundCaseAtLevel(String count) {
		String value = foundCaseCounts;
		String value2;
		value2 = value.replace("%count%", count);
		return value2;
	}
	
	public static String dupToggler = "xpath#//a[@id='adverseEventNew:dupCheckDetailsPnl_toggler']";
	public static String dupCheckHeader = "xpath#//*[contains(text(),'Duplicate Check Summary Details')]";
//	public static String rowsCount = "xpath#//tbody[@id='adverseEventNew:dupChckDataTable_data']//tr/td[3]/label";
	public static String rowsCount = "xpath#//table[contains(@class,'duplicateSummaryTable')]/tbody//tr/td[3]/a";
	public static String dupLevelLbl(int row) {
		return "xpath#//table[contains(@class,'duplicateSummaryTable')]/tbody/tr["+Integer.toString(row)+"]/td[1]";
	}
	public static String caseCountLbl(int row) {
		return "xpath#//table[contains(@class,'duplicateSummaryTable')]/tbody//tr["+Integer.toString(row)+"]/td[3]/a";
	}
	//div[@id='dataAssessmentDupSearchGrid']//div[@fieldid='aerNo']/div[contains(@class,'adjust')]
	public static String dataAssesRowsCount = "xpath#//div[@id='dataAssessmentDupSearchGrid']//div[@class='lsmv-grid-row']";
	public static String dataAssessAER(int row) {
		return "xpath#//div[@id='dataAssessmentDupSearchGrid']//div[@class='lsmv-grid-row']["+Integer.toString(row)+"]/div[@fieldid='aerNo']/div[contains(@class,'adjust')]";
	}
	public static String noRecrdsDiv = "xpath#//div[@id='dataAssessmentDupSearchGrid']//div[@class='lsmv-grid-row'][1][text()='No records to display']";
}
