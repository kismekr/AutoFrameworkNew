package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FDE_NarrativePageObjects {
	public static String eventDescriptionAdd_Button = "xpath#(//a[contains(@title,'Add')])[1]";
	public static String eventDescriptionDelete_Button = "xpath#(//a[contains(@title,'Delete')])[1]";

	public static String reactionDescriptionAsPerReporterAdd_Button = "xpath#(//a[contains(@title,'Add')])[2]";
	public static String reactionDescriptionAsPerReporterDelete_Button = "xpath#(//a[contains(@title,'Delete')])[2]";

	public static String companyRemarksAdd_Button = "xpath#(//a[contains(@title,'Add')])[3]";
	public static String companyRemarksDelete_Button = "xpath#(//a[contains(@title,'Delete')])[3]";

	public static String pharmacovigilanceCommentsAdd_Button = "xpath#(//a[contains(@title,'Add')])[4]";
	public static String pharmacovigilanceCommentsDelete_Button = "xpath#(//a[contains(@title,'Delete')])[4]";

	public static String summaryDescriptionAdd_Button = "xpath#(//a[contains(@title,'Add')])[5]";
	public static String summaryDescriptionDelete_Button = "xpath#(//a[contains(@title,'Delete')])[5]";

	public static String senderDiagnosisAdd_Button = "xpath#(//a[contains(@title,'Add')])[6]";
	public static String senderDiagnosisDelete_Button = "xpath#(//a[contains(@title,'Delete')])[6]";

	public static String caseSummaryandReportersCommentsAdd_Button = "xpath#(//a[contains(@title,'Add')])[7]";
	public static String caseSummaryandReportersCommentsDelete_Button = "xpath#(//a[contains(@title,'Delete')])[7]";

	public static String eventDescriptionEdit_Button = "xpath#//a[contains(text(),'Edit')]";
	public static String eventDescription_Textarea = "xpath#//textarea[@id='adverseEventNew:956106']";
	public static String additionalComments_Textarea = "xpath#//textarea[@id='adverseEventNew:956150']";
	public static String additionalManufacturerNarrative_Textarea = "xpath#//textarea[@id='adverseEventNew:956148']";
	public static String correctedData_Textarea = "xpath#//textarea[@id='inboundMessage.aerInfo.safetyReport.patient.summary.correcteddata']";
	public static String evaluationSummary_Textarea = "xpath#//textarea[@id='inboundMessage.aerInfo.safetyReport.patient.summary.evaluationsummary']";
	public static String reactionDescriptionAsPerReporter_Textarea = "xpath#//textarea[@id='adverseEventNew:956108']";
	public static String companyRemarks_Textarea = "xpath#//textarea[@id='adverseEventNew:956110']";
	public static String pharmacovigilanceComments_Textarea = "xpath#//textarea[@id='adverseEventNew:956112']";
	public static String summaryDescription_Textarea = "xpath#//textarea[@id='adverseEventNew:956114']";
	public static String senderDiagnosisTerm_Textbox = "xpath#//input[contains(@id,'114108')]";
	public static String senderDiagnosisMedDRALLTCode_Textbox = "xpath#//input[@id='adverseEventNew:senderDiagnosisPanelDataTable:narrativeMeddraLltCode:0']";
	public static String senderDiagnosisMedDRAPTCode_Textbox = "xpath#//input[@id='adverseEventNew:senderDiagnosisPanelDataTable:narrativeMeddraPtCode:0']";
	public static String doNotUseANG_Checkbox = "xpath#//label[text()='Event Description']//following::span//p-checkbox[@class='ng-untouched ng-pristine ng-valid']/div";
	public static String rationaleLabel = "xpath#//label[text()='Rationale for Not Reporting ']";

	public static String searchTermLookUpTextbox = "xpath#//label[contains(text(),'Search Term')]//input";
	public static String searchTermLookUpBtn = "xpath#//div[contains(@class,'searchOkbtn')]//button";
	public static String selectTermFromList = "xpath#//p-table[@class='agSearchprodcutTable agcommonTblStyle CodingDictionarytbl ng-star-inserted']//td[text()='%s']";
	public static String termOkBtn = "xpath#//div[@class='col-md-12 searchOkbtn ng-star-inserted']//button";

	public static String medDRALLTCodesuggestionItem = "xpath#//div[@id='adverseEventNew:errorMessage_container']//following::div//li[1]";
	public static String senderDiagnosisMedDRALLTCode_Lookup = "xpath#//a[@class='agLookupLink']//img";
	// public static String senderDiagnosisTermTextbox =
	// "xpath#//input[contains(@id,'adverseEventNew:senderDiagnosisPanelDataTable:idN10198114108')]";
	public static String caseSummaryAndReportersCommentsText_Textarea = "xpath#//textarea[@id='adverseEventNew:summaryRptCommentsPanelDataTable:caseSummaryReportiveCommentsText:0']";
	public static String caseSummaryAndReportersCommentsLanguage_DropDown = "xpath#//select[contains(@name,'summaryRptCommentsPanelDataTable')]";
	public static String caseSummaryAndReportersCommentsLanguage_DropDownLabel = "xpath#//select[contains(@name,'adverseEventNew:summaryRptCommentsPanelDataTable:caseSummaryReportiveCommentsText')]//ancestor::div[2]";

	public static String langOkBtn = "xpath//button[@id='narrativeLanguageOkBtn']";

	public static String remarks1Textarea = "xpath#//label[text()='Remarks 1 ']//ancestor::div[1]//textarea";
	public static String remarks2Textarea = "xpath#//label[text()='Remarks 2 ']//ancestor::div[1]//textarea";
	public static String remarks3Textarea = "xpath#//label[text()='Remarks 3 ']//ancestor::div[1]//textarea";
	public static String remarks4Textarea = "xpath#//label[text()='Remarks 4 ']//ancestor::div[1]//textarea";

	// R2 Tags
	public static String R2EventDescription = "xpath#//label[text()='[B.5.1]']";
	public static String R2ReactionDescriptionAsPerReporter = "xpath#//label[text()='[B.5.2]']";
	public static String R2CompanyRemarks_SenderComments = "xpath#//label[text()='[B.5.4]']";
	public static String R2SenderDiagnosisTerm = "xpath#//label[text()='[B.5.3b]']";

	// R3 Tags
	public static String R3EventDescription = "xpath#//label[text()='[H.1]']";
	public static String R3ReactionDescriptionAsPerReporter = "xpath#//label[text()='[H.2]']";
	public static String R3CompanyRemarks_SenderComments = "xpath#//label[text()='[H.4]']";
	public static String R3CaseSummaryAndReportersCommentsText = "xpath#//label[text()='[H.5.r.1a]']";
	public static String R3CaseSummaryAndReportersCommentsLanguage = "xpath#//label[text()='[H.5.r.1b]']";
	public static String R3SenderDiagnosisMedDRALLTCode = "xpath#//label[text()='[H.3.r.1b]']";

	public static String additionalInformation = "xpath#//textarea[@id='adverseEventNew:114185']";

	// Codelist
	public static String CLCaseSummaryAndReportersCommentsLanguage = "xpath#//label[text()='[9065]']";

	public static String selectTermFromList(String runTimeLabel) {
		String value = selectTermFromList;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	// Objects listed for ANG Related scenarios
	public static String editANG_btn = "xpath#//label[text()='Event Description']/following-sibling::a[@class='angNarrativeLink ng-star-inserted'][text()='Edit']";
	public static String contextViewANG_btn = "xpath#//button/span[text()='Context View']";

	public static String nonEditableTextLocator = "xpath#//div[@class='editableDiv']//span[text()='%s']";
	public static String showNonEditableTexts_CheckBx = "Show non-editable texts";
	public static String showManualStatements_CheckBx = "Show Manual Statements";
	public static String OK_Btn = "xpath#//button/span[text()='OK']";
	public static String regenerate_Btn = "xpath#//div[@class='col-md-12 searchOkbtn']/button/span[text()='REGENERATE']";
	public static String regenerateConfirmation_Title = "xpath#//div/span[text()='Confirmation']";
	public static String regenerateConfirmYes_Btn = "xpath#//div/button/span[text()='Yes']";
	public static String regenerateConfirmNo_Btn = "xpath#//div/button/span[text()='No']";
	// added by rashmi
	public static String doNotUseANG_AdditionalCommentCheckbox = "xpath#//label[text()='Additional Comments ']/./following-sibling::span//div";
	public static String additionalInformation_Textarea = "xpath#//textarea[@id='adverseEventNew:114185']";

	public static String checkBoxRightOf = "xpath#//span[starts-with(normalize-space(text()),'{0}')]/following::div[1]/div/span";

	public static String additionalInfoTextArea = "xpath#//textarea[@id='adverseEventNew:114185']";
	public static String additionalInfoLink = "xpath#//a[text()='Additional Information']";

	/**********************************************************************************************************
	 * @Objective: The below method is created to build locator on the fly using
	 *             Partial Locator, textValue
	 * @InputParameters: Partial Locator, textValue
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String narrativeTextLocatorBuilder(String nonEditableText) {
		String value = nonEditableTextLocator;
		String value2;
		value2 = value.replace("%s", nonEditableText);
		return value2;
	}

	public static String showNonEditableTextsCheckBox = "xpath#//span[starts-with(normalize-space(text()),'Show non-editable texts')]/following::div[1]/div[2]/span";
	public static String resultLocator = null;

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox right of
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Naresh
	 * @Date : 25-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String checkBoxRightOf(String checkBoxLabel) {
		String actualLocator = checkBoxRightOf;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}

	public static String bannerTag_icon = "xpath#//div/i[@class='pi pi-angle-up']";
	public static String changeLog_Label = "xpath#//a[text()='Change Log']";
	public static String tableRecords_MultiElements = "xpath#//tbody[@class='ui-table-tbody']/tr";

	public static String contextTreeNode_LeadStmnt = "xpath#//li/a[text()='Lead Statement']";
	public static String evetDesc_LeadStmnt = "xpath#//span/span[@class='editableAngDiv'][text()='Information was received from an investigator in ']";
	public static String contextTreeNode_LastRecvdDt = "xpath#//li/a[text()='Latest received date']";
	public static String evetDesc_LastRecvdDt = "xpath#//span/span[@class='editableAngDiv'][contains(text(),'Tracking of Changes:')]";

}
