package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class TherapeuticAreaPageObjects {
	
	
	public static String new_Btn = "xpath#//a[@id='therapeuticForm:newId']";
	public static String therapeuticArea_Lable = "xpath#//label[@id='therapeuticDetailsForm:therapeuticArea'][text()='Therapeutic Area']";
	public static String therapeuticArea_TxtField = "xpath#//input[@id='therapeuticDetailsForm:therapeuticName']";
	public static String description_TextArea = "xpath#//textarea[@id='therapeuticDetailsForm:therapeauticDesc']";
	public static String save_Btn = "xpath#//button[@id='therapeuticDetailsForm:visibleSave']";
	public static String therapeuticKeywords_Txtarea = "xpath#//textarea[@id='therapeuticDetailsForm:therapeauticKeywords']";
	
	
	public static String keywordSearchLookup_TxtField = "xpath#//input[@id='pharmacologicalClassLookupForm:keywordId']";
    public static String lookupsearch_Btn = "xpath#//button[@id='pharmacologicalClassLookupForm:subSearchButton']";
	public static String checkbox_lookup = "xpath#//td/span[text()='%s']/ancestor::td/preceding::td[@class='ui-selection-column']/div/child::div/span";
	public static String lookupOk_Btn = "xpath#//button[@id='pharmacologicalClassLookupForm:okButtonBottom']";
	public static String validation_Popup = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	//public static String deletevalidation_Popup = "xpath#//div[@id='listingForm:deleteconfirm']";
	public static String deletevalidation_Popup = "xpath#//span[@class='ui-confirm-dialog-message']";
	public static String downloadIcon = "xpath#//a[@id='therapeuticForm:actionId']";
	public static String exporttoExcel_link = "xpath#//button[contains(@id,'therapeuticForm:excelID')]/span[text()='Export To Excel']";
	public static String exporttoExcel_popup = "xpath#//span[@id='listingForm:columnSelectionDialogId_title']";
	public static String export_Btn= "xpath#//button[@id='therapeuticForm:submitId']";
	public static String exportexcelcancel_Btn= "xpath#//button[@id='therapeuticForm:cancelDialogId']";
	public static String edit_Icon= "xpath#//img[@id='therapeuticForm:therapeuticDataTable:0:editIcon']";
	public static String cancel_Btn= "xpath#//button[@id='therapeuticDetailsForm:cancelId']";
	
	
	public static String validationOk_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']";
	public static String keywordSearch_TxtField = "xpath#//input[@id='therapeuticForm:keyword']";
	public static String search_Icon = "xpath#//a[@id='therapeuticForm:searchTherapeutic']";
	public static String paginator = "xpath#//div[@id='therapeuticForm:therapeuticDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String get_TherapeuticArea = "xpath#//tbody[@id='therapeuticForm:therapeuticDataTable_data']/tr/td[contains(@class,'EditIcon')]/following-sibling::td[1]";
	public static String refresh_Icon = "xpath#//a[@id='therapeuticForm:refreshImage']";
	public static String listingScreen_CheckBoxs = "xpath#//td[text()='%s']/ancestor::tbody[@id='therapeuticForm:therapeuticDataTable_data']/tr/td/div/child::div/span";
	public static String delete_Btn = "xpath#//a[@id='therapeuticForm:deleteId']";
	public static String deletePopupYes_Btn = "xpath#//button[@id='therapeuticForm:confirmation_yes']";
	public static String noRecordsFound = "xpath#//tbody[@id='listingForm:moietyDataTable_data']/tr/td[text()='No records found.']";
	public static String get_ListofTherapeuticArea= "xpath#//tbody[@id='therapeuticForm:therapeuticDataTable_data']/ancestor::table/tbody/tr/td[3]";
 	public static String columnHeader = "xpath#(//tbody[@id='therapeuticForm:therapeuticDataTable_data']/ancestor::table/tbody/tr/td[3])[{%count}]";

	
	/**********************************************************************************************************
	 * Objective:The below method is created to send value by passing value at runtime.
	 * Input Parameters: runTimeLabel
	 * Scenario Name Output
	 * Parameters:
	 * @author:Avinash K Date :17-Oct-2019 Updated by and when   	 
	**********************************************************************************************************/		
    		
    public static String selectCheckbox(String runTimeLabel) {
        String value = checkbox_lookup;
        String value2;
        value2 = value.replace("%s", runTimeLabel);
        return value2;
    }
	
	/**********************************************************************************************************
	 * @Objective:get substance name by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:DushyanthMahesh Date :16-September-2019 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderList(String num) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}
	/**********************************************************************************************************
	 * Objective:The below method is created to select checkbox by passing value at runtime.
	 * Input Parameters: runTimeLabel
	 * Scenario Name Output
	 * Parameters:
	 * @author:Avinash K Date :18-Oct-2019 Updated by and when   	 
	**********************************************************************************************************/		
    		
    public static String selectListingCheckbox(String runTimeLabel) {
        String value = listingScreen_CheckBoxs;
        String value2;
        value2 = value.replace("%s", runTimeLabel);
        return value2;
    }
	
	
	
}
