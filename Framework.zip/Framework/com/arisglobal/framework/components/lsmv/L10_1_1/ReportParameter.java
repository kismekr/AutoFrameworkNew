package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ReportparameterPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class ReportParameter extends ToolManager {

	public static WebElement webElement;
	static String className = ReportParameter.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 19-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(ReportparameterPageObjects.selectGeneralDroprdown(label));
			agClick(ReportparameterPageObjects.clickDropDownValue(getTestDataCellValue(scenarioName, columnName)));

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform navigations in report type
	 *             in report parameter page
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 18-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void reportTypeNavigations(String menu) {

		switch (menu) {
		case "MedWatch":
			agClick(ReportparameterPageObjects.medWatchLink);
			status = agIsVisible(ReportparameterPageObjects.medWatchHeader);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to MedWatch is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to MedWatch is Unsuccessfull", true);
			}
			break;
		case "CIOMS":
			agClick(ReportparameterPageObjects.ciomsLink);
			status = agIsVisible(ReportparameterPageObjects.ciomsHeader);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to CIOMS is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to CIOMS is Unsuccessfull", true);
			}
			break;
		case "CIOMS_LL":
			agClick(ReportparameterPageObjects.ciomsLink_LL);
			status = agIsVisible(ReportparameterPageObjects.cioms_LLHeader);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to CIOMS_LL is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to CIOMS_LL is Unsuccessfull", true);
			}
			break;
		case "BfArM":
			agClick(ReportparameterPageObjects.BfArMLink);
			status = agIsVisible(ReportparameterPageObjects.BfArMHeader);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to BfArM is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to BfArM is Unsuccessfull", true);
			}
			break;
		default:
			System.out.println("Invalid Menu Link!");
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is going to call setReportParameter method to
	 *             add parameters .
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 19-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void configureReportParameter(String scenarioName) {
		setReportParameter(scenarioName);

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is going to set all the parameters for CIOMS
	 *             report.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 19-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setReportParameter(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		setDropDownValue(ReportparameterPageObjects.dataOfReport, scenarioName, "CIOMS_Date of Report");
		setDropDownValue(ReportparameterPageObjects.printMfrContactNo, scenarioName, "CIOMS_Print Mfr Control No");
		setDropDownValue(ReportparameterPageObjects.pharmaCovComments, scenarioName,
				"CIOMS_Pharmacovigilance comments");
		agSetValue(ReportparameterPageObjects.set_Textfields("Missing text"),
				getTestDataCellValue(scenarioName, "CIOMS_Missing text"));
		agSetValue(ReportparameterPageObjects.set_Textfields("Missing date"),
				getTestDataCellValue(scenarioName, "CIOMS_Missing date"));
		agSetValue(ReportparameterPageObjects.set_Textfields("Imprecise date"),
				getTestDataCellValue(scenarioName, "CIOMS_Imprecise date"));
		setDropDownValue(ReportparameterPageObjects.dateFormat, scenarioName, "CIOMS_Date format");
		setDropDownValue(ReportparameterPageObjects.versionWithTerm, scenarioName, "CIOMS_Version with term");
		agClick(ReportparameterPageObjects.saveReportParameter);

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is going to set all the parameters for MedWatch
	 *             report.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 28-Sept-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void configureMedWatchReportParameter(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		setDropDownValue(ReportparameterPageObjects.medWatchVersionWithTerm, scenarioName, "MedWatch_Versionwithterm");
		setDropDownValue(ReportparameterPageObjects.printMultiplePrimaryReporters, scenarioName,
				"MedWatch_PrintMultiplePrimaryReport");
		setDropDownValue(ReportparameterPageObjects.pharmacovigilanceComments, scenarioName,
				"MedWatch_PharmacovigilanceComments");
		agClick(ReportparameterPageObjects.saveReportParameter);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is going to set all the parameters for BfArM
	 *             report.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 29-Sept-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void configureBfArMReportParameter(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(ReportparameterPageObjects.set_Textfields("Missing date"),
				getTestDataCellValue(scenarioName, "BfArM_MissingDate"));
		agSetValue(ReportparameterPageObjects.set_Textfields("Missing text"),
				getTestDataCellValue(scenarioName, "BfArM_MissingText"));
		setDropDownValue(ReportparameterPageObjects.drugIndicationWithDrugName, scenarioName,
				"BfArM_drugIndicationWithDrugName");
		setDropDownValue(ReportparameterPageObjects.codeDecodeOfDisease, scenarioName, "BfArM_codeDecodeOfDisease");
		setDropDownValue(ReportparameterPageObjects.causalityAssignment, scenarioName, "BfArM_causalityAssignment");
		setDropDownValue(ReportparameterPageObjects.printLiteratureData, scenarioName, "BfArM_printLiteratureData");
		setDropDownValue(ReportparameterPageObjects.printLabData, scenarioName, "BfArM_printLabData");
		setDropDownValue(ReportparameterPageObjects.labrotaryDataFormat, scenarioName, "BfArM_labrotaryDataFormat");
		setDropDownValue(ReportparameterPageObjects.printPharmacovigilanceComments, scenarioName,
				"BfArM_printPharmacovigilanceComments");
		setDropDownValue(ReportparameterPageObjects.printCausalityInformation, scenarioName,
				"BfArM_printCausalityInformation");
		setDropDownValue(ReportparameterPageObjects.printFollowupNoOrVersionNo, scenarioName,
				"BfArM_printFollowupNoOrVersionNo");
		setDropDownValue(ReportparameterPageObjects.printLLTOrPT, scenarioName, "BfArM_printLLTOrPT");
		setDropDownValue(ReportparameterPageObjects.printMedDRACodeWithDecodes, scenarioName,
				"BfArM_printMedDRACodeWithDecodes");
		setDropDownValue(ReportparameterPageObjects.PrintMedDRAVersion, scenarioName, "BfArM_PrintMedDRAVersion");
		setDropDownValue(ReportparameterPageObjects.DateofReportnotAvailableinIArecord, scenarioName,
				"BfArM_DateofReportnotAvailableinIArecord");
		agClick(ReportparameterPageObjects.saveReportParameter);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is going to set all the parameters for CIOMSLL
	 *             report.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 23-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void configureCIOMSLLReportParameter(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSelectByVisibleText(ReportparameterPageObjects.causality,
				getTestDataCellValue(scenarioName, "CIOMSLL_Casuality"));
		agSelectByVisibleText(ReportparameterPageObjects.medraCode,
				getTestDataCellValue(scenarioName, "CIOMSLL_MedraCode_Decode"));

		agSelectByVisibleText(ReportparameterPageObjects.LLT_PTCode,
				getTestDataCellValue(scenarioName, "CIOMSLL_LLT_PT"));
		agSelectByVisibleText(ReportparameterPageObjects.pvComments,
				getTestDataCellValue(scenarioName, "CIOMSLL_PVComments"));

		agSetValue(ReportparameterPageObjects.set_Textfields(ReportparameterPageObjects.titlePharmacovigilanceLable),
				getTestDataCellValue(scenarioName, "CIOMSLL_TitlePVComments"));

		agSetValue(ReportparameterPageObjects.set_Textfields(ReportparameterPageObjects.pageTitle),
				getTestDataCellValue(scenarioName, "CIOMSLL_PageTitle"));

		agSetValue(ReportparameterPageObjects.set_Textfields(ReportparameterPageObjects.companyUnt),
				getTestDataCellValue(scenarioName, "CIOMSLL_CompanyUnit"));

		agSelectByVisibleText(ReportparameterPageObjects.eventDescription,
				getTestDataCellValue(scenarioName, "CIOMSLL_PrintEventDescription"));

		agSelectByVisibleText(ReportparameterPageObjects.mostSuspectProduct,
				getTestDataCellValue(scenarioName, "CIOMSLL_MostSuspectProduct"));

		agSelectByVisibleText(ReportparameterPageObjects.productIngrdients,
				getTestDataCellValue(scenarioName, "CIOMSLL_Ingredients"));

		agSelectByVisibleText(ReportparameterPageObjects.seriousNess,
				getTestDataCellValue(scenarioName, "CIOMSLL_Seriousness"));

		agSelectByVisibleText(ReportparameterPageObjects.labeling,
				getTestDataCellValue(scenarioName, "CIOMSLL_PrintLabelling"));

		agSelectByVisibleText(ReportparameterPageObjects.AERNumberVersion,
				getTestDataCellValue(scenarioName, "CIOMSLL_AERnumberVersion"));

		agClick(ReportparameterPageObjects.saveReportParameter);
	}

}
