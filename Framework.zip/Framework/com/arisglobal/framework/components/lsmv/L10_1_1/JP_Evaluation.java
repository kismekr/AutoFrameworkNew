package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.JP_EvaluationPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class JP_Evaluation  extends ToolManager {
	public static WebElement webElement;
	static String className = JP_Evaluation.class.getSimpleName();
	static boolean status;
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to add general information data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 03-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/		
	public static void jpnGeneralInformation(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		//agSetValue(JP_EvaluationPageObjects.jpnRegClockStartDate,getTestDataCellValue(scenarioName, "aer_Reg_Japaneseregulatoryclockstartdate"));
		agSetValue(JP_EvaluationPageObjects.commentOnRegStartDate,getTestDataCellValue(scenarioName, "aer_Reg_Commentonregulatorystartdate"));
		agClick(JP_EvaluationPageObjects.genInformationtab);
		agSetValue(JP_EvaluationPageObjects.retrospectiveSurveyOfInfection,getTestDataCellValue(scenarioName, "geninfo_Retrospectivesurveyofinfection"));
		agSetValue(JP_EvaluationPageObjects.japaneseCounterMeasurement,getTestDataCellValue(scenarioName, "geninfo_japanesecountermeasurement"));
		agSetValue(JP_EvaluationPageObjects.otherComments,getTestDataCellValue(scenarioName, "geninfo_othercomments"));		
	 }
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to click on Japan Domestic Full Data entey
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 06-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/		
	public static void switchToJpnDomesticFDE(String scenarioName) {
		agSetStepExecutionDelay("3000");
		agWaitTillVisibilityOfElement(JP_EvaluationPageObjects.JpnDomesticFDE);
		agJavaScriptExecuctorClick(JP_EvaluationPageObjects.JpnDomesticFDE);
		agWaitTillInvisibilityOfElement(JP_EvaluationPageObjects.centerGridloader);	
		 agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		status = agIsVisible(JP_EvaluationPageObjects.jpEvaluation);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS,
					"Case moved to japan workflow" , true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Case not moved to japan workflow", true);
		}		
	}

}
