package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class QueryByExamplePageObjects {

	public static String QBEIcon = "xpath#//a[@id='headerForm:QBE_HEADER']/img";
	public static String fieldLibraryHeader = "xpath#//span[text()='Field Library']";
	public static String showAllFields = "xpath#//input[@id='showAllFields']";
	public static String showAllFieldsList = "xpath#//div[@class='childFieldsPanel']/div";

	public static String aeAdditionalInformation = "xpath#//div[text()='AE Additional Information		']";
	public static String aerCloseDate = "xpath#//div[text()='AER Close Date		']";
	public static String aerNumber = "xpath#//div[@fieldlabel='aer number' and @title='AER Number -> Case Specific Information -> General']";
	public static String aerVersion = "xpath#//div[text()='AER Version		']";
	public static String aesi = "xpath#//div[text()='AESI		']";
	public static String apgarScore1Min = "xpath#//div[text()='APGAR Score 1 Minute		']";
	public static String apgarScore10Min = "xpah#//div[text()='APGAR Score 10 Minute		']";
	public static String apgarScore5Min = "xpath#//div[text()='APGAR Score 5 Minute		']";
	public static String artgNumber = "xpath#//div[text()='ARTG number		']";
	public static String aborginal = "xpath#//div[text()='Aborginal		']";
	public static String accessToOCT = "xpath#//div[text()='Access To OTC		']";
	public static String actionTakenWithDrug = "xpath#//div[text()='Action Taken With Drug		']";
	public static String actionToBeTaken = "xpath#//div[text()='Action to be taken		']";
	public static String actionsTakenWithDrug = "xpath#//div[text()='Action(s) Taken With Drug		']";
	public static String activeSubstance = "xpath#//div[text()='Active Substance		']";
	public static String activityComplitionDate = "xpath#//div[text()='Activity Completion Date		']";
	public static String activityEntryDate = "xpath#//div[text()='Activity Entry date		']";
	public static String activityName = "xpath#//div[text()='Activity Name		']";
	public static String activityCompletedBy = "xpath#//div[text()='Activity completed by		']";
	public static String actualCompletionDate = "xpath#//div[text()='Actual Completion Date		']";
	public static String additionalComments = "xpath#//div[text()='Additional Comments		']";
	public static String additionalInfo = "xpath#//div[text()='Additional Info		']";
	public static String additionalInfoCode = "xpath#//div[text()='Additional Info Code		']";
	public static String additionalInformation = "xpath#//div[text()='Additional Information		']";
	public static String aditionalLiteratureInformation = "xpath#//div[text()='Additional Literature Information		']";
	public static String additionalManufacturerNarrative = "xpath#//div[text()='Additional Manufacturer Narrative		']";
	public static String additionalDrugInformation = "xpath#//div[text()='Additional drug information		']";
	public static String admissionDuration = "xpath#//div[text()='Admission Duration		']";
	public static String age = "xpath#//div[text()='Age		']";
	public static String ageGroup = "xpath#//div[text()='Age Group		']";
	public static String ageUnit = "xpath#//div[text()='Age Unit		']";
	public static String ageAtTheTimeOfEvent = "xpath#//div[text()='Age at the Time of Event		']";
	public static String alsoReportedTo = "//div[text()='Also Reported To		']";
	public static String alwaysSeriousEvent = "//div[text()='Always Serious Event		']";
	public static String anticiptedEvents = "xpath#//div[text()='Anticipated Events		']";
	public static String approvalType = "//xpath#div[text()='Approval Type		']";
	public static String articleTitle = "xpath#//div[text()='Article Title		']";
	public static String accessRelationship = "xpath#//div[text()='Assess Relationship		']";
	public static String assessmentMethod = "xpath#//div[text()='Assessment Method		']";
	public static String assignedBy = "xpath#//div[text()='Assigned By		']";
	public static String assignedOn = "xpath#//div[text()='Assigned On		']";
	public static String assignedTo = "xpath#//div[text()='Assigned To		']";
	public static String authority = "xpath#//div[text()='Authority		']";

	public static String authorityNoCompNo = "xpath#//div[text()='Authority No/Comp Number		']";
	public static String authorizationCountry = "xpath#//div[text()='Authorization Country		']";
	public static String authorizationNumber = "xpath#//div[text()='Authorization Number		']";
	public static String authorizedRepresentative = "xpath#//div[text()='Authorized Representative		']";
	public static String autopsyDeterminedCauseOfDeath = "xpath#//div[text()='Autopsy Determined Cause of Death		']";
	public static String autopsyDone = "xpath#//div[text()='Autopsy Done?		']";
	public static String basicUDIDIEudamedDI = "xpath#//div[text()='Basic UDI-DI/Eudamed-DI		']";
	public static String basisOfSimilarIncidentIdentification = "xpath#//div[text()='Basis of similar incident identification		']";
	public static String biologicalFatherExposedToDrug = "xpath#//div[text()='Biological Father exposed to Drug		']";
	public static String biosimilar = "xpath#//div[text()='Biosimilar		']";
	public static String birthOutcome = "xpath#//div[text()='Birth Outcome		']";
	public static String birthWeight = "xpath#//div[text()='Birth weight		']";
	public static String birthWeightUnit = "xpath#//div[text()='Birth weight unit		']";
	public static String blindingTechnique = "xpath#//div[text()='Blinding technique		']";
	public static String bodyMassIndex = "xpath#//div[text()='Body mass index		']";
	public static String bodySurfaceIndex = "xpath#//div[text()='Body surface index		']";
	public static String brandName = "//div[text()='Brand Name		']";
	public static String casNumber = "xpath#//div[text()='CAS Number		']";
	public static String cdc = "xpath#//div[text()='CDC		']";
	public static String ceNumber = "xpath#//div[text()='CE Number		']";
	public static String compounded = "xpath#//div[text()='COMPOUNDED?		']";
	public static String cpdAuthorizationCountry = "xpath#//div[text()='CPD Authorization Country		']";
	public static String ctNotificationSubmissionTimes = "xpath#//div[text()='CT notification submission times		']";
	public static String caseApprovalDate = "xpath#//div[text()='Case Approval Date		']";
	public static String caseCodeBroken = "xpath#//div[text()='Case Code Broken		']";
	public static String caseCodeBrokenOn = "xpath#Case Code Broken On		";
	public static String caseCoded = "xpath#//div[text()='Case Coded		']";
	public static String caseDueDate = "xpath#//div[text()='Case Due date		']";
	public static String caseInitialApprovalDate = "xpath#//div[text()='Case Initial Approval Date		']";
	public static String caseOwner = "xpath#//div[text()='Case Owner		']";
	public static String caseSignificance = "xpath#//div[text()='Case Significance		']";
	public static String caseStatus = "xpath#//div[text()='Case Status		']";
	public static String caseSummaryAndReportersCommentsLanguage = "xpath#//div[text()='Case Summary and Reporters Comments Language		']";
	public static String caseSummaryAndReportersCommentsText = "xpath#//div[text()='Case Summary and Reporters Comments Text		']";
	public static String caseType = "xpath#//div[text()='Case Type		']";
	public static String catalogueNumber = "xpath#//div[text()='Catalogue Number		']";
	public static String category = "xpath#//div[text()='Category		']";
	public static String causalitySource = "xpath#//div[text()='Causality Source		']";
	public static String causedByDrugInteraction = "xpath#//div[text()='Caused By Drug Interaction		']";
	public static String causedByLackOfEffect = "xpath#//div[text()='Caused by Lack of Effect		']";
	public static String causedProlongedHospitalization = "xpath#//div[text()='Caused/Prolonged Hospitalization		']";
	public static String causedprolongedhospitalization = "xpath#//div[text()='Caused/prolonged hospitalization		']";
	public static String centerNumber = "xpath#//div[text()='Center Number		']";
	public static String cessationDate = "xpath#//div[text()='Cessation date		']";
	public static String city = "xpath#//div[text()='City		']";
	public static String classOfDevice = "xpath#//div[text()='Class of device		']";
	public static String clinicalDrugCode = "xpath#//div[text()='Clinical Drug Code		']";
	public static String clinicalNonClinicalClassification = "//div[text()='Clinical/non-clinical classification		']";
	public static String codingClass = "xpath#//div[text()='Coding Class		']";
	public static String codingType = "xpath#//div[text()='Coding Type		']";
	public static String combinationProductReport = "xpath#//div[text()='Combination Product Report		']";
	public static String commentOnRegulatoryClockStartDate = "xpath#//div[text()='Comment on regulatory clock start date		']";
	public static String comments = "xpath#//div[text()='Comments		']		";
	public static String commentsOnDeterminationOfSimilarIncidents = "xpath#//div[text()='Comments on determination of similar incidents		']";
	public static String commentsReasonText = "xpath#//div[text()='Comments/Reason Text		']";
	public static String commonDeviceName = "xpath#//div[text()='Common Device Name		']";
	public static String companyCausality = "xpath#//div[text()='Company Causality		']";
	public static String companyProduct = "xpath#//div[text()='Company Product		']";
	public static String companyReceivedDate = "xpath#//div[text()='Company Received Date		']";
	public static String companyUnit = "xpath#//div[text()='Company Unit		']		";
	public static String competentAuthority = "xpath#//div[text()='Competent Authority		']";
	public static String concomitantTherapies = "xpath//div[text()='Concomitant Therapies		']";
	public static String conditionTreated = "xpath#//div[text()='Condition treated		']";
	public static String congenitalAnomaly = "xpath#//div[text()='Congenital Anomaly		']";
	public static String congenitalAnomalyType = "xpath#//div[text()='Congenital Anomaly Type		']";
	public static String congenitalAnomalyBirthDefect = "xpath#//div[text()='Congenital Anomaly/Birth Defect?		']";
	public static String consentToContactParent = "xpath#//div[text()='Consent To Contact Parent		']";
	public static String consentToContact = "xpath#//div[text()='Consent to Contact		']";
	public static String consentToContactPatient = "xpath#//div[text()='Consent to contact Patient		']";
	public static String contact = "xpath#//div[text()='Contact		']";
	public static String containerName = "xpath#//div[text()='Container Name		']";
	public static String Containername = "xpath#//div[text()='Container name		']";
	public static String continueSurvey = "xpath#//div[text()='Continue survey?		']";
	public static String Continuing = "xpath#//div[text()='Continuing		']";
	public static String continuing = "xpath#//div[text()='Continuing?		']";
	public static String contraceptiveFailure = "xpath#//div[text()='Contraceptive failure		']";
	public static String contraceptivesUsed = "xpath#//div[text()='Contraceptives Used		']";
	public static String correctedData = "xpath#//div[text()='Corrected Data		']";
	public static String correction = "xpath#//div[text()='Correction		']";
	public static String correctionRemovalReportingNumber = "xpath#//div[text()='Correction/Removal Reporting Number		']";
	public static String correspondenceDate = "xpath#//div[text()='Correspondence Date		']";
	public static String correspondenceStatus = "xpath#//div[text()='Correspondence Status		']";
	public static String country = "xpath#//div[text()='Country		']";
	public static String countryObtained = "xpath#//div[text()='Country Obtained		']";
	public static String countryOfDetection = "xpath#//div[text()='Country of Detection		']";
	public static String countrypPublished = "xpath#//div[text()='Country published		']";
	public static String criteriaForDevicesInMarket = "xpath#//div[text()='Criteria For Devices In Market		']";
	public static String crossReferencedIND = "xpath#//div[text()='Cross Referenced IND#		']";
	public static String cumulativeDoseToFirstReactionUnit = "xpath#//div[text()='Cumulative Dose to First Reaction :Unit		']";
	public static String cumulativeDoseToFirstReaction = "xpath#//div[text()='Cumulative dose to first Reaction		']";
	public static String cumulativedoseTofirstReactionUnit = "xpath#//div[text()='Cumulative dose to first Reaction :Unit		']";
	public static String currentDeviceLocation = "xpath#//div[text()='Current Device Location		']";
	public static String currentPregnancy = "xpath#//div[text()='Current Pregnancy		']";
	public static String dme = "xpath#//div[text()='DME		']";
	public static String dailyDose = "xpath#//div[text()='Daily Dose		']";
	public static String dailyDoseUnit = "xpath#//div[text()='Daily Dose: Unit		']";
	public static String dataAssesment = "xpath#//div[text()='Data Assesment		']";

	public static String ruleExpOperator = "xpath#//select[@class='ruleExpOperator']";
	public static String selectOperator = "xpath#//select[@class='ruleExpOperator']/option[text()='{0}']";
	public static String clickCondition = "xpath#//span[text()='Condition']";
	public static String ruleConditionFieldPanel = "xpath#//div[@class='lsmv-rule-conddField-panel']/div";
	public static String fieldSearch = "xpath#//input[@id='fieldLibSearchCmp']";
	public static String searchIcon = "xpath#//input[@id='fieldLibSearchCmp']//parent::div/span[@class='lsmv-search-icon']";
	public static String conditionOpertor = "xpath#//select[@class='conddOperator']";
	public static String secondconditionOpertor = "xpath#(//select[@class='conddOperator'])[2]";
	public static String selectCondOperator = "xpath#//select[@class='conddOperator']/option[text()='{0}']";
	public static String selectSecondCondOperator = "xpath#(//select[@class='conddOperator'])[2]/option[text()='{0}']";
	public static String valueSearchIcon = "xpath#//input[@class='conddRhsElement i18n_pl']//parent::div/span[@class='lsmv-search-icon']";
	public static String secondvalueSearchIcon = "xpath#(//input[@class='conddRhsElement i18n_pl']//parent::div/span[@class='lsmv-search-icon'])[2]";
	public static String listOfLibraryDataPopUP = "xpath#//span[text()='List of Library data']";
	public static String librarySearchTextbox = "xpath#//div[@id='targetPanelForDataLibLookup']//input";
	public static String librarySearchIcon = "xpath#//div[@id='targetPanelForDataLibLookup']//span[@class='lsmv-grid-search-icon']";
	public static String checkSearchResultCheckbox = "xpath#(//span[@class='lsmv-grid-chk-sticky lsmv-grid-row-sel-chk lsmv-grid-sel-unchk'])[1]";
	public static String selectBtn = "xpath#//span[text()='Select']";
	public static String clickGetCount = "xpath#//span[text()='Get Count']";
	public static String countResult = "xpath#//span[@id='qbeExpRecsCountInp']";
	public static String clickSearch = "xpath#//div[@class='lsmv-panel-header']//span[text()='Search']";
	public static String backToQbeHeader = "xpath#//span[text()='Back to QBE']";
	public static String paginationCount = "xpath#//span[@class='htmlPaginationInfo']";
	public static String searchedResult = "xpath#//div[@fieldlabel='{0}']";
	public static String codelistHeader = "xpath#//div[@id='codelistDataDrag']//span[text()='List of Code list']";
	public static String codelistSearch = "xpath#//div[@id='targetPanelForCodeistDataLookup']//input[@class='inputCmpClass lsmvGridSearchCmp']";
	public static String codelistSearchIcon = "xpath#//div[@id='targetPanelForCodeistDataLookup']//Span[@class='lsmv-grid-search-icon']";
	public static String verisonDD = "xpath#//select[@id='versionFilterCmp']";
	public static String selectVersion = "xpath#//select[@id='versionFilterCmp']/option[text()='{0}']";
	public static String codelistCheckBox = "xpath#//div[@id='targetPanelForCodeistDataLookup']//span[@class='lsmv-grid-chk-sticky lsmv-grid-row-sel-chk lsmv-grid-sel-unchk']";
	public static String codelistSelectBtn = "xpath#//div[@id='targetPanelForCodeistDataLookup']//span[text()='Select']";
	public static String clickGroup = "xpath#//div[@class='expressionGroupBtnBar']//span[text()='Group']";
	public static String conditionTree = "xpath#//div[@class='lsmv-exp-panel lsmv-tree-str-last']";
	public static String treeConditionClick = "xpath#//div[@class='lsmv-exp-panel lsmv-tree-str-last']//span[text()='Condition']";
	public static String treeRuleExpOperator = "xpath#//div[@class='lsmv-exp-panel lsmv-tree-str-last']//select[@class='ruleExpOperator']";	
	public static String selectTreeOperator = "xpath#//div[@class='lsmv-exp-panel lsmv-tree-str-last']//option[text()='{0}']";
	public static String firstTreeExpCondtion = "xpath#//div[@class='lsmv-exp-panel lsmv-tree-str-last']//div[@class='expConddPanel lsmv-tree-str-last expConddPanelSel']";

	public static String clearbtn = "xpath#//div[@class='lsmv-panel-header']//span[text()='Clear']";
	public static String clearConfirmationPopUP = "xpath#//div[@id='confirmPopupMain']//span[text()='Confirmation']";
	public static String confirmPopupOkBtn = "xpath#//button[@id='confirmPopupOkBtn']";

	public static String saveCriteria = "xpath#//span[text()='Save']";
	public static String saveQBEpopUpHeader = "xpath#//span[text()='Save QBE Expression']";
	public static String saveCriteriaName = "xpath#//input[@id='criteriaName']";
	public static String visibleTo = "xpath#//input[@id='{0}']";
	public static String saveInSaveCriteria = "xpath#//button[text()='Save']";
	public static String saveCriteriaMessage = "xpath#//span[text()='Criteria saved successfully.']";
	public static String saveCriteriaDD = "xpath#//input[@id='savedCriteriaInp']";
	public static String criteriaName = "xpath#//div[text()='{0}']";
	public static String deleteSavedCriteria = "xpath#//div[text()='{0}']//parent::div/span";
	public static String deleteConfirmation = "xpath#//div[@id='confirmPopupDrag']//span[text()='Confirmation']";
	public static String deleteOkBtn = "xpath#//button[@id='confirmPopupOkBtn']";
	public static String deleteMessage = "xpath#//span[text()='Criteria deleted successfully.']";

	public static String searchValueToCompare_TextBox = "xpath#//div[@class='lsmv-rule-conddField-panel']/div//input[@class='conddRhsElement i18n_pl']";
	public static String receiptNoLink = "xpath#//a[@class='receiptNoSty']";

	public static String expandFieldLibrary = "xpath#//div[@onclick='expandChildEntitiesSection(this)']//span[text()='General ']";
	public static String caseUnit = "xpath#//span[text()='Case Units ']";

	// Distribution Attributes
	public static String distributionDetails = "xpath#//span[text()='Distribution Details ']";
	public static String acknowledgementReceivedDate = "xpath#//div[@fieldlabel='Acknowledgement Received Date']";
	public static String authorityNoCompanyNo = "xpath#//div[@fieldlabel='Authority No./ Company No.']";
	public static String commentReasonText = "xpath#//div[@fieldlabel='Comments/Reason Text']";
	public static String dateInformed = "xpath#//div[@fieldlabel='Date Informed']";
	public static String distributedDate = "xpath#//div[@fieldlabel='Distributed Date']";
	public static String distributionContactName = "xpath#//div[@fieldlabel='Distribution Contact Name']";
	public static String e2bMessageType = "xpath#//div[@fieldlabel='E2B Message Type']";
	public static String Final = "xpath#//div[@fieldlabel='Final']";
	public static String followUpType = "xpath#//div[@fieldlabel='Follow-up Type']";
	public static String healthAuthority = "xpath#//div[@fieldlabel='Health Authority']";
	public static String localCriteriaReportType = "xpath#//div[@parententityid= 'distributionUnit.flpath']//div[@fieldlabel='Local Criteria Report Type']";
	public static String locallyExpedited = "xpath#//div[@parententityid= 'distributionUnit.flpath']//div[@fieldlabel='Locally Expedited']";
	public static String MDNReceivedDate = "xpath#//div[@fieldlabel='MDN Received Date']";
	public static String mediumDetails = "xpath#//div[@fieldlabel='Medium Details']";
	public static String reasonForNotReporting = "xpath#//div[@fieldlabel='Reason For Not Reporting']";
	public static String reasonForNullificationAmendment = "xpath#//div[@parententityid= 'distributionUnit.flpath']//div[@fieldlabel='Reason for Nullification / Amendment']";
	public static String receiverOrganization = "xpath#//div[@fieldlabel='Receiver Organization']";
	public static String recipientCountry = "xpath#//div[@fieldlabel='Recipient Country']";
	public static String removeReasonComment = "xpath#//div[@fieldlabel='Remove Reason Comment']";
	public static String reportFormat = "xpath#//div[@fieldlabel='Report Format']";
	public static String reporterMedium = "xpath#//div[@fieldlabel='Report Medium']";
	public static String distributionReportType = "xpath#//div[@parententityid= 'distributionUnit.flpath']//div[@fieldlabel='Report Type']";
	public static String reportForNullificationAmendment = "xpath#//div[@fieldlabel='Report for Nullification / Amendment']";
	public static String reportingStatus = "xpath#//div[@fieldlabel='Reporting Status']";
	public static String safteryReportId = "xpath#//div[@parententityid= 'distributionUnit.flpath']//div[@fieldlabel='Safety Report ID']";
	public static String DistributionStatus = "xpath#//div[@parententityid= 'distributionUnit.flpath']//div[@fieldlabel='Status']";
	public static String submissionDueDate = "xpath#//div[@parententityid= 'distributionUnit.flpath']//div[@fieldlabel='Submission Due Date']";
	public static String submittedDate = "xpath#//div[@fieldlabel='Submitted Date']";
	public static String typeOfAckReceived = "xpath#//div[@fieldlabel='Type Of Ack Received']";
	public static String XMLDOCTYPE = "xpath#//div[@fieldlabel='XML DOC TYPE']";
	public static String recieptNo = "xpath#//div[@fieldlabel = 'Receipt No']";

	public static String clicklabelling = "xpath#//span[text()='Labeling ']";
	public static String ListofcodelistHeader = "xpath#//div[@id='countryCLDataDrag']//span[text()='List of Code list']";
	public static String countrySearchTextBox = "xpath#//div[@id='targetPanelForCountryCLDataLookup']//input";
	public static String countrySearchIcon = "xpath#//div[@id='targetPanelForCountryCLDataLookup']//span[@class='lsmv-grid-search-icon']";
	public static String countryDSUR = "xpath#//div[text()='DSUR']";
	public static String selectSearchResultCheckbox = "xpath#//div[@id='targetPanelForCountryCLDataLookup']//span[@class='lsmv-grid-chk-sticky lsmv-grid-row-sel-chk lsmv-grid-sel-unchk']";
	public static String countryCodelistSelectBtn = "xpath#//span[@id='conCllSelecctBtnId']";
	public static String clickCaseSpecification = "xpath#//span[text()='Case Specific Information ']";
	public static String aerNoTextBox = "xpath#//input[@class='conddRhsElement i18n_pl']";

	// case series
	public static String caseSeries = "xpath#//a[text()='Save Series']";
	public static String caseSeriesPopUpHeader = "xpath#//span[text()='Save Series']";
	public static String caeSeriesName = "xpath#//div[@id='htmlSaveCaseSeriesDailog']//div/input";
	public static String clickSeriesDD = "xpath#//select[@id='caseSeriesTypeSelector']";
	public static String selectSeries = "xpath#//select[@id='caseSeriesTypeSelector']/option[text()='{0}']";
	public static String saveCaseSeries = "xpath#//button[@onclick='saveCaseSeries()']";
	public static String saveConfirmationPopUp = "xpath#//span[text()='Action Completed Successfully']";
	public static String okBtn = "xpath#//div[@id='htmlValidationDailog']//a[@class='btn btn-secondary']";

	public static String clickProduct = "xpath#//span[text()='Product(s) ']";
	public static String clickProductInformation = "xpath#//span[text()='Product Information ']";
	public static String aprovalStatusDD = "xpath#//select[@id='approvalTypeComboId']";
	public static String approvalStatus = "xpath#//option[text()='{0}']";
	public static String selectCase = "xpath#//a[text()='{0}']";
	public static String selectAerCase = "xpath#(//a[@id='{0}'])[3]";

	public static String prferedProductDesc = "xpath#//div[@fieldid='113777']//div[@fieldlabel='Preferred Product Description']";

	//
	public static String ExpandCaseDocumentBtn = "xpath#//span[contains(text(),'Case Documents')]/parent::div[contains(@class,'lsmv-collapsible')]";
	public static String SourceDocumentBtn = "xpath#//span[@onclick='expandChildFieldSection(this)' and @title='Source Documents']";
	public static String SupportDocumentBtn = "xpath#//span[@onclick='expandChildFieldSection(this)' and @title='Support Documents']";
	public static String Date = "xpath#//div[@class='lsmv-fieldLibField lsmv-fieldLibField-active']//div[@class='fieldLabelData' and contains(text(),'Date')]";
	public static String DocumentCategory = "xpath#//div[@class='lsmv-fieldLibField lsmv-fieldLibField-active']//div[@class='fieldLabelData' and contains(text(),'Document Category')]";
	public static String Filename = "xpath#//div[@class='lsmv-fieldLibField lsmv-fieldLibField-active']//div[@class='fieldLabelData' and contains(text(),'Filename')]";
	public static String StartDate = "xpath#//div//input[@class='conddRhsElement i18n_pl' and @placeholder='DD-MMM-YYYY']";
	public static String EndDate = "xpath#(//div//span/following-sibling::input[@class='conddRhsElement2' and @placeholder='DD-MMM-YYYY'])[1]";
	public static String DocumentCategoryValue = "xpath#//input[contains(@title,'Document Category')]/parent::div//div//input[@placeholder='Select/Enter Value to Compare']";
	public static String FileNameValue = "xpath#//input[contains(@title,'Filename')]/parent::div//div//input[@placeholder='Select/Enter Value to Compare']";

	public static String ReciptNoList = "xpath#//a[@class='receiptNoSty']";
	public static String ReciptNoSingle = "xpath#(//a[@class='receiptNoSty'])[%s]";
	public static String meddraBrowserLookUp = "xpath#//span[text()='MedDRA Browser/SMQ CMQ lookup']";
	public static String SOCHLGTHLTlookUP = "xpath#//button[text()='SOC/HLGT/HLT Lookup']";
	public static String SOCInput = "xpath#//div[@id='targetPanelForCountryCLDataLookup']//input";
	public static String SOCSearch = "xpath#//div[@targetpanelid='targetPanelForCountryCLDataLookup']//span[@class='lsmv-grid-search-icon']";
	public static String checkSOCSearchResultCheckbox = "xpath#(//span[@class='lsmv-grid-chk-sticky lsmv-grid-row-sel-chk lsmv-grid-sel-unchk'])[1]";

	// public static String selectConditions =
	// "xpath#(//select[@class='conddOperator'])['{0}']";
	public static String selectConditions = "xpath#//div[@class='lsmv-rule-conddField-panel']/div[{0}]//select[@class='conddOperator']";
	public static String selectSearchIcon = "xpath#//div[@class='lsmv-rule-conddField-panel']/div[{0}]//span[@class='lsmv-search-icon']";
		
	public static String selectChildConditions = "xpath#//div[@class='lsmv-rule-childExp-panel']//div[@class='lsmv-rule-conddField-panel']/div[{0}]//select[@class='conddOperator']";
	public static String selectChildSearchIcon = "xpath#//div[@class='lsmv-rule-childExp-panel']//div[@class='lsmv-rule-conddField-panel']/div[{0}]//span[@class='lsmv-search-icon']";
	
	public static String workflowStatusDD = "Xpath#//label[text()='Workflow Status :']//parent::div/select[@id='wfStatusComboId']";
	public static String workflowStatus = "xpath#//option[text()='{0}']";
	public static String clickExclusionGroup = "xpath#//div[@class='expressionGroupBtnBar']//span[text()='Exclusion Group']";
	public static String fromDate = "xpath#//div[@class='conddRhsElementDiv form-group']/input";
	public static String toDate = "xpath#//div[@class='conddRhsElement2Div form-group']/input";
	public static String qbeBuilderHeader = "xpath#//span[text()='QBE Builder']";

	public static String activityLog = "xpath#//span[text()='Activity Logs ']";
	public static String actionTaken = "xpath#//div[@fieldlabel='Action Taken']";
	public static String activityLogDATEandTime = "xpath#//div[@fieldlabel='Date And Time']";
	public static String takenBy = "xpath#//div[@fieldlabel='Taken By']";
	public static String workflowActivity = "xpath#//div[@fieldlabel='WorkFlow Activity']";
	public static String librarySearch = "xpath#//div[@targetpanelid='targetPanelForDataLibLookup']//span[@class='lsmv-grid-search-icon']";
	public static String workflowActivityExist = "xpath#//div[text()='{0}']";
	public static String textboxvalue = "xpath#(//div[@class='conddRhsElementDiv form-group']/input)['[0]']";
	public static String DateandTimeFromDate = "xpath#(//div[@class='conddRhsElementDiv form-group']/input)[3]";

	public static String FDE = "xpath#(//div[text()='Full Data Entry']//parent::div//parent::div/span)[1]";
	public static String MR = "xpath#(//div[text()='Medical Review']//parent::div//parent::div/span)[1]";
	public static String selectCaseforExport = "xpath#(//a[@id='{0}'])[1]//parent::div//parent::span//parent::td//parent::tr//input";
	public static String exportBtn = "xpath#//button[@id='e2bExport']";
	public static String qbeExport = "xpath#//a[@id='qbe_export_lbl']";

	public static String getRCTNoList = "xpath#//table[@id='qbeListingTable']//tbody/tr/td[2]/a[@class='receiptNoSty']";
	public static String getRCTNo = "xpath#(//table[@id='qbeListingTable']//tbody/tr/td[2]/a[@class='receiptNoSty'])[%count%]";

	public static String clickMedwatch = "xpath#//table[@id='qbeListingTable']//tbody/tr/td[7]/span/img[contains(@src,'listing')]";
	public static String clickMedwatchReport = "xpath#//a[text()='MEDWATCH 3500A']";

	public static String DocumnetSearchIcon = "xpath#//input[@placeholder='Select/Enter Value to Compare']/following-sibling::span[@class='lsmv-search-icon' and @codelistid='316']";
	public static String CodeListSearchTextBox = "xpath#//input[@placeholder='Search...']";
	public static String CodeListSearchBtn = "xpath#//span[@class='lsmv-grid-search-icon']";
	public static String CodeListCheckBox = "xpath#//span[@class='lsmv-grid-chk-sticky lsmv-grid-row-sel-chk lsmv-grid-sel-unchk']";
	public static String SelectBtn = "xpath#//span[@id='clLkupSelecctBtnId']";

	public static String RecptNumber = "xpath#//a[text()='%s']";
	public static String excludeConditionTree = "xpath#//div[@class='lsmv-exp-panel exclusionGroupPanelClass lsmv-tree-str-last']";
	public static String excludeTreeRuleExpOperator = "xpath#//div[@class='lsmv-exp-panel exclusionGroupPanelClass lsmv-tree-str-last']//select[@class='ruleExpOperator']";	
	public static String excludeSelectTreeOperator = "xpath#//div[@class='lsmv-exp-panel exclusionGroupPanelClass lsmv-tree-str-last']//option[text()='{0}']";
	public static String excludeTreeConditionClick = "xpath#//div[@class='lsmv-exp-panel exclusionGroupPanelClass lsmv-tree-str-last']//span[text()='Condition']";

	public static String closeListOfLibraryDataPopUp = "xpath#//div[@id='targetPanelForDataLibLookup']//span[text()='Cancel']";
	public static String nextPage = "xpath#//i[@class='listingPageRightIcon']";
	
	public static String completeActivity  = "xpath#(//div[text()='Complete Activity']//parent::div//parent::div/span)[1]";
	public static String copy  = "xpath#(//div[text()='Copy']//parent::div//parent::div/span)[1]";
	
	public static String qbeDownload = "xpth#//div[@class='gridSearchBarRight']/span[text()='Download' and @onclick='exportQbeSearchData()']";
	public static String exportColumnPopUP = "xpath#//span[text()='Select Columns to Export']";
	public static String QBEExportBtn = "xpath#//a[text()='Export']";
	public static String SortRecieptNumber="xpath#//th[contains(@class,'htmlRctNoColumn ADL_table_receiptNo sorting')and text()='Receipt#']";
	public static String StartDate1 = "xpath#(//div//input[@class='conddRhsElement i18n_pl' and @placeholder='DD-MMM-YYYY'])[2]";
	public static String EndDate1 = "xpath#(//div//span/following-sibling::input[@class='conddRhsElement2' and @placeholder='DD-MMM-YYYY'])[4]";
	public static String DocumentCategoryValue1 = "xpath#(//input[contains(@title,'Document Category')]/parent::div//div//input[@placeholder='Select/Enter Value to Compare'])[2]";
	public static String FileName2="xpath#(//input[contains(@title,'Filename')]/parent::div//div//input[@placeholder='Select/Enter Value to Compare'])[2]";
	public static String ClickFileName="xpath#//tr[@class='odd'][1]//a[@class='receiptNoSty']";
	public static String AERNumbertextBox="xpath#//input[contains(@title,'AER Number -> Case Specific Information -> General')]/parent::div//div//input[@placeholder='Select/Enter Value to Compare']";
	public static String FileName1="xpath#(//input[contains(@title,'Filename')]/parent::div//div//input[@placeholder='Select/Enter Value to Compare'])[1]";
	public static String DocumnetSearchIcon1 = "xpath#(//input[@placeholder='Select/Enter Value to Compare']/following-sibling::span[@class='lsmv-search-icon' and @codelistid='316'])[2]";
	public static String NotEqualOp="xpath#//input[@title='Document Category -> Support Documents -> Case Documents']/parent::div//select";
	public static String NotEqualOpSelect="xpath#//input[@title='Document Category -> Support Documents -> Case Documents']/parent::div//select//option[text()='Not Equals']";
	
	public static String NoRecord = "xpath#//td[text()='No records found']";
	public static String SOCCodelistHeader  = "xpath#(//span[text()='List of Code list'])[3]";
	public static String firstvalueSearchIcon = "xpath#(//input[@class='conddRhsElement i18n_pl']//parent::div/span[@class='lsmv-search-icon'])[1]";
    public static String searchedReceiptNo = "xpath#//a[contains(text(),'{0}')]";

	
	/*
	 * =============================================================================
	 * ==========================
	 */

    public static String searchedReceiptNo(String label) {
		String value = searchedReceiptNo.replace("{0}", label);
		return value;
	}
    
	public static String checkCaseforExportInListing(String Data) {
		String value = selectCaseforExport.replace("{0}", Data);
		return value;
	}

	public static String checkCaseInListing(String Data) {
		String value = selectCase.replace("{0}", Data);
		return value;
	}
	
	public static String checkAerCaseInListing(String Data) {
		String value = selectAerCase.replace("{0}", Data);
		return value;
	}

	public static String selectApprovalStatus(String label) {
		String value = approvalStatus.replace("{0}", label);
		return value;
	}

	public static String selectSeriesType(String label) {
		String value = selectSeries.replace("{0}", label);
		return value;
	}

	public static String selectExpressionOperator(String label) {
		String value = selectOperator.replace("{0}", label);
		return value;
	}

	public static String selectTreeExpressionOperator(String label) {
		String value = selectTreeOperator.replace("{0}", label);
		return value;
	}
	
	public static String selectExcludeTreeExpressionOperator(String label) {
		String value = excludeSelectTreeOperator.replace("{0}", label);
		return value;
	}

	public static String selectConditionOperator(String label) {
		String value = selectCondOperator.replace("{0}", label);
		return value;
	}

	public static String selectSecondConditionOperator(String label) {
		String value = selectSecondCondOperator.replace("{0}", label);
		return value;
	}

	public static String selectVersionDroprdown(String label) {
		String value = selectVersion.replace("{0}", label);
		return value;
	}

	public static String selectSearchedResult(String label) {
		String value = searchedResult.replace("{0}", label);
		return value;
	}

	public static String selectVisibleTo(String label) {
		String value = visibleTo.replace("{0}", label);
		return value;
	}

	public static String verifyCriteria(String label) {
		String value = criteriaName.replace("{0}", label);
		return value;
	}

	public static String deleteCriteria(String label) {
		String value = deleteSavedCriteria.replace("{0}", label);
		return value;
	}

	public static String selectCondition(String label) {
		String value = selectConditions.replace("{0}", label);
		return value;
	}
	
	public static String selectChildCondition(String label) {
		String value = selectChildConditions.replace("{0}", label);
		return value;
	}

	public static String selectSearch(String label) {
		String value = selectSearchIcon.replace("{0}", label);
		return value;
	}
	
	public static String selectChildSearch(String label) {
		String value = selectChildSearchIcon.replace("{0}", label);
		return value;
	}

	public static String selectWorkflowStatus(String label) {
		String value = workflowStatus.replace("{0}", label);
		return value;
	}

	public static String WorkflowActivity(String label) {
		String value = workflowActivityExist.replace("{0}", label);
		return value;
	}

	public static String setTextBoxValue(String label) {
		String value = textboxvalue.replace("{0}", label);
		return value;
	}

	public static String RecptNumber(String i) {
		String value = ReciptNoSingle.replace("%s", i);

		return value;
	}

	public static String RNumber(String i) {
		String value = RecptNumber.replace("%s", i);

		return value;
	}
	public static String aerNoCheckBox(String aerNo) {
		return "xpath#//a[text()='"+aerNo+"(0)']/ancestor::tr//input[@type='checkbox']";
		
	}
	public static String moreOptionsBtn = "xpath#//button[text()='More Options']";
	public static String createNewVersLink = "xpath#//a[@id='createNewVersion']";
	public static String submitBtn = "xpath#//a[@id='cl_submit']";
	public static String workflowActivitySelect = "xpath#//select[@name='workflowActivityList']";
	public static String reasonSelect = "xpath#//select[@name='aerReasonForVersion']";
	public static String aerCommsForVersTxtArea = "xpath#//textarea[@name='aerCommentsForVersion']";
	public static String newVersionMsg = "xpath#//div[@id='newVersionDailog']/div/div[2]";
	public static String newVersionOkBtn = "xpath#//div[@id='newVersionDailog']//input[@type='button']";
	
	public static String CaseStatus = "xpath#//img[@title='Approved']";
}