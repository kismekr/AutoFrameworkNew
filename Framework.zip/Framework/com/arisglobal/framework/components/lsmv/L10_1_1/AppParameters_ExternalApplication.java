package com.arisglobal.framework.components.lsmv.L10_1_1;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AppParameters_CaseManagementPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AppParameters_ExternalApplicationPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.WorkFlowPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AppParameters_ExternalApplication extends ToolManager {
	static String className = "AppParameters_ExternalAppln";

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Set data in General Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar s
	 * @Date :25-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void SetExternalApplication(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			CommonOperations.clickCheckBoxLeftOf(AppParameters_ExternalApplicationPageObjects.includeInALS_CheckBox,
					getTestDataCellValue(scenarioName, "IncludeinALS"));
			if(getTestDataCellValue(scenarioName, "IncludeinALS").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_ExternalApplicationPageObjects.includeInALS_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_ExternalApplicationPageObjects.includeInALS_CheckBox,
								getTestDataCellValue(scenarioName, "IncludeinALS"));
				}
			}
			
			
			if(getTestDataCellValue(scenarioName, "LiteratureAutoAccept").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_ExternalApplicationPageObjects.literatureAutoAccept_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_ExternalApplicationPageObjects.literatureAutoAccept_CheckBox,
								getTestDataCellValue(scenarioName, "LiteratureAutoAccept"));
				}
			}
			
			CommonOperations.setListDropDownValue(AppParameters_ExternalApplicationPageObjects.language_Dropdown,
					getTestDataCellValue(scenarioName, "Language"));
			CommonOperations.setListDropDownValue(AppParameters_ExternalApplicationPageObjects.searchType_Dropdown,
					getTestDataCellValue(scenarioName, "SearchType"));

			CommonOperations.setListDropDownValue(
					AppParameters_ExternalApplicationPageObjects.postalCodeIntegration_Dropdown,
					getTestDataCellValue(scenarioName, "PostalCodeIntegration"));

			if(getTestDataCellValue(scenarioName, "IntegrateMoxtraChat").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_ExternalApplicationPageObjects.integrateCRM_Radio))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_ExternalApplicationPageObjects.integrateCRM_Radio,
								getTestDataCellValue(scenarioName, "IntegrateMoxtraChat"));
				}
			}
			if(getTestDataCellValue(scenarioName, "EnableTranslator").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_ExternalApplicationPageObjects.enableTranslator_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_ExternalApplicationPageObjects.enableTranslator_CheckBox,
								getTestDataCellValue(scenarioName, "EnableTranslator"));
				}
			}
			if(getTestDataCellValue(scenarioName, "EnabletextIndexing").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(	AppParameters_ExternalApplicationPageObjects.enableTextIndexing_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(	AppParameters_ExternalApplicationPageObjects.enableTextIndexing_CheckBox,
								getTestDataCellValue(scenarioName, "EnabletextIndexing"));
				}
			}
			
			if(getTestDataCellValue(scenarioName, "EnabletextIndexing").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(	AppParameters_ExternalApplicationPageObjects.enableTextIndexing_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(	AppParameters_ExternalApplicationPageObjects.enableTextIndexing_CheckBox,
								getTestDataCellValue(scenarioName, "EnabletextIndexing"));
				}
			}
			if(getTestDataCellValue(scenarioName, "EnableFreeTextSearch").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(	AppParameters_ExternalApplicationPageObjects.enableFreeTextSearch_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(	AppParameters_ExternalApplicationPageObjects.enableFreeTextSearch_CheckBox,
								getTestDataCellValue(scenarioName, "EnableFreeTextSearch"));
				}
			}
			
		

			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> External Application Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read data in General Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar s
	 * @Date :25-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadAppParameters_ExternalApplicationDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_ExternalApplicationPageObjects.includeInALS_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "IncludeinALS", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "IncludeinALS",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_ExternalApplicationPageObjects.literatureAutoAccept_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LiteratureAutoAccept",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LiteratureAutoAccept",
						"false");
			}
			String DefaultCompanyProduct = agGetText(AppParameters_ExternalApplicationPageObjects.language_Dropdown);
			if (DefaultCompanyProduct.contains("--Select--")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Language", "#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Language",
						DefaultCompanyProduct);
			}
			String DefaultCompanyProduct1 = agGetText(AppParameters_ExternalApplicationPageObjects.searchType_Dropdown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SearchType",
					DefaultCompanyProduct1);

			String DefaultCompanyProduct2 = agGetText(
					AppParameters_ExternalApplicationPageObjects.postalCodeIntegration_Dropdown);
			if (DefaultCompanyProduct2.contains("--Select--")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "PostalCodeIntegration",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "PostalCodeIntegration",
						DefaultCompanyProduct2);
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_ExternalApplicationPageObjects.integrateMoxtraChat_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "IntegrateMoxtraChat",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "IntegrateMoxtraChat",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_ExternalApplicationPageObjects.enableTranslator_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableTranslator",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableTranslator",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_ExternalApplicationPageObjects.enableTextIndexing_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnabletextIndexing",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnabletextIndexing",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_ExternalApplicationPageObjects.enableFreeTextSearch_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableFreeTextSearch",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableFreeTextSearch",
						"false");
			}
			Reports.ExtentReportLog("", Status.INFO,
					"Read Entered Data in Application Parameters >> External Application Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set data in DMS Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 01-Dec-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setAppParameters_ExternalApplicationTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Application Parameters >>External Application Tab Started ", true);
		SetExternalApplication(scenarioName);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Application Parameters >>External Application Tab Completed", true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read data in DMS Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 01-Dec-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadAppParameters_ExternalApplicationTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO,
				"Read Data Entered in Application Parameters >>External Application Tab Started", true);
		ReadAppParameters_ExternalApplicationDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO,
				"Read Data Entered in Application Parameters >>External Application Tab Completed", true);
	}

}
