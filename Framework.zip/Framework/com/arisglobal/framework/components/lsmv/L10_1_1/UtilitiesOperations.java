package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AdministrationPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.UtilitiesPageObjects;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.aventstack.extentreports.Status;

public class UtilitiesOperations extends ToolManager{
	public static WebElement webElement;
	static String className = UtilitiesOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	
	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in Utilities
	 * @InputParameters: pageObject
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void menuNavigation(String pageObject) {

		agMouseHover(AdministrationPageObjects.administrationHover);
		agClick(pageObject);
	}
	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in
	 * Administration > Utilities and verify the label name
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
  	public static void  utilitiesNavigations(String menu){

			switch (menu) {
			case "e2BValidator":
				menuNavigation(UtilitiesPageObjects.e2BValidatorLink);
				status = agIsVisible(UtilitiesPageObjects.e2BValidatorLabel);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to e2B Validator is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to e2B Validator is Unsuccessfull", true);
				}
				break;
			case "formDesigner":
				menuNavigation(UtilitiesPageObjects.formDesignerLink);
				status = agIsVisible(UtilitiesPageObjects.formKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to form Designer is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to form Designer is Unsuccessfull", true);
				}
				break;
			case "e2BMetatdata":
				menuNavigation(UtilitiesPageObjects.e2BMetatdataLink);
				status = agIsVisible(UtilitiesPageObjects.E2BMETADATAKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to e2BMetatdata is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to e2BMetatdata is Unsuccessfull", true);
				}
				break;
				
			case "bulkImportConfigurations":
				menuNavigation(UtilitiesPageObjects.bulkImportConfigLink);
				 status = agIsVisible(UtilitiesPageObjects.bulkImportConfigKeywordSearch);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to bulk ImportConfigurations is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to bulk ImportConfigurations is Unsuccessfull", true);
				}
				break;
			case "dictionaryImport":
				menuNavigation(UtilitiesPageObjects.dictionaryImportLink);
				
				 status = agIsVisible(UtilitiesPageObjects.dictionaryImportKeywordSearch);
				
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to dictionary Import is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to dictionary Import is Unsuccessfull", true);
				}
				break;
			case "dictionaryImpactAnalysis":
				menuNavigation(UtilitiesPageObjects.dictionaryImpactAnalysisLink);
				 
				 status = agIsVisible(UtilitiesPageObjects.dictionaryImpactAnalysisLabel);
			
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to dictionary ImpactAnalysis is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to dictionary ImpactAnalysis is Unsuccessfull", true);
				}
				break;
			case "caselibraryImpactAnalysis":
				menuNavigation(UtilitiesPageObjects.case_libraryImpactAnalysisLink);
				status = agIsVisible(UtilitiesPageObjects.caseImpactAnalysisLabel);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to case library ImpactAnalysis is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to case library ImpactAnalysis is Unsuccessfull", true);
				}
				break;
			default:
				System.out.println("Invalid Menu Link!");
			}
	
	}
}