package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public abstract class FDEFormCopyWindowPageObjects {

	public static String copyLink = "xpath#//div[@id='adverseEventNew:moreButtonsDiv']//tr[4]//ancestor::td[@class='value']/a[contains(@id,'adverseEventNew:j_id')]";
	public static String copyCaseCommentTextarea = "xpath#//textarea[@id='copycommentsTextarea']";
	public static String copyButton = "xpath#//div/button[text()='Copy']";
	public static String copyCaseReceiptNumber = "xpath#//div[contains(@class,'validationDialogPanel')]";
	public static String validationPopup = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String cancelIcon = "xpath#//span[@id='openCaseSummaryDiolog:CaseSummaryDialog_title']/following-sibling::a[1]";
	public static String okButton = "xpath#//button[@class='buttonBg' and text()='OK']";
	public static String copyCheckboxs = "xpath#//div[@class='panelBorderCopy']//child::tr/td/label[contains(text(),'%s')]";
	public static String copyMultipleCheckBox = "xpath#//label[contains(@id,'safetyCopyForm') and contains(text(),'Copy Into Multiple Cases')]";
	public static String noOfCopiesTextBox = "xpath#//input[@id='safetyCopyForm:noOfCopiesId_input']";
	public static String downLoadReports = "xpath#//ul[contains(@class,'ui-widget-content')]/li/a/span[@class='ui-menuitem-text'][contains(text(),'%s')]";
	public static String moreOptionsNavigation = "xpath#//div[@id='adverseEventNew:moreButtonsDiv']/child::table/tbody/tr/td/a[contains(text(),'%s')]";
	public static String VerifyReciptNumber = "xpath#//span[starts-with(text(),'Copy >')]";
	public static String SourceDocumentCheckBox = "xpath#//input[@id='checkAllsourcedocs']/following-sibling::span";
	public static String SupportDocumentCheckBox = "xpath#//input[@id='checkAllsuportdocs']/following-sibling::span";
	// Label names
	public static String receiptDetails_CheckBox = "Receipt Details";
	public static String ClassfyasNew_CheckBox = "Classify as New";
	public static String Correspondence_CheckBox = "Correspondence";
	public static String Documents_CheckBox = "Documents";
	public static String Notes_CheckBox = "Notes";
	public static String LinkedCases_CheckBox = "xpath#//div[@id='safetyCopyForm:linkedcases']";
	public static String LinkCopiedCase_CheckBox = "Link Copied Case";

	public static String FormData_CheckBox = "Form Data";
	public static String Retain_ActivityChkbox = "Retain Activity";
	public static String General_CheckBox = "General";

	public static String Source_CheckBox = "Source";

	public static String Reporter_CheckBox = "Reporter";
	public static String Study_CheckBox = "Study";

	public static String Patient_CheckBox = "Patient";
	public static String Parent_CheckBox = "Parent";
	public static String Product_CheckBox = "Product(s)";
	public static String Event_CheckBox = "Event(s)";
	public static String Narrative_CheckBox = "Narrative";

	public static String Pregnancy_CheckBox = "Pregnancy";
	public static String LabData_CheckBox = "Lab Data";
	public static String Literature_CheckBox = "Literature";
	public static String EditCopiedCase_CheckBox = "Edit Copied Case";
	public static String CopyInto_CheckBox = "Copy Into Multiple Cases";

}