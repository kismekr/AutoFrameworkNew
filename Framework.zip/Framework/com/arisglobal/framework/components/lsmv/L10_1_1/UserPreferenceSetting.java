package com.arisglobal.framework.components.lsmv.L10_1_1;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.LoginPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.UserPreferenceSettingPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.aventstack.extentreports.Status;

public class UserPreferenceSetting extends ToolManager {

	/**********************************************************************************************************
	 * @Objective: The below method is to set Adverse Event Listing Sorting
	 *             Preferences-Ascending.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 22-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void EventListingAscendingSort() {
		agClick(LoginPageObjects.LSMVDisplaySettings);
		agClick(UserPreferenceSettingPageObjects.LSMV_UserPrefernce);
		agSetStepExecutionDelay("2000");
		agClick(UserPreferenceSettingPageObjects.PrimarySortColumnDropDown);
		agClick(UserPreferenceSettingPageObjects.PrimarySortColumnDDValue);
		agClick(UserPreferenceSettingPageObjects.EventListingSortOrderAscending);
		agClick(UserPreferenceSettingPageObjects.UserPrefernceSaveBtn);
		Reports.ExtentReportLog("", Status.INFO, "User Prefernce Set", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		ToolManager.agWaitTillVisibilityOfElement(UserPreferenceSettingPageObjects.ConfirmationOkBtn);
		agClick(UserPreferenceSettingPageObjects.ConfirmationOkBtn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to set Adverse Event Listing Sorting
	 *             Preferences-Descending.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 22-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void EventListingDescendingSort() {
		agClick(LoginPageObjects.LSMVDisplaySettings);
		agClick(UserPreferenceSettingPageObjects.LSMV_UserPrefernce);
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorClick(UserPreferenceSettingPageObjects.PrimarySortColumnDropDown);
		agJavaScriptExecuctorClick(UserPreferenceSettingPageObjects.PrimarySortColumnDDValue);
		agClick(UserPreferenceSettingPageObjects.EventListingSortOrderDesending);
		Reports.ExtentReportLog("", Status.INFO, "User Prefernce Set", true);
		agClick(UserPreferenceSettingPageObjects.UserPrefernceSaveBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		ToolManager.agWaitTillVisibilityOfElement(UserPreferenceSettingPageObjects.ConfirmationOkBtn);
		agClick(UserPreferenceSettingPageObjects.ConfirmationOkBtn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to check whether Recept number has sorted in
	 *             Ascending order.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 22-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void CaselistingAscendingCheck() {
		agSetStepExecutionDelay("3000");
		CaseManagementOperations.menuNavigation("Case listing");
		// CaseManagementOperations.menusubmenuNavigation("Case listing");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		String FirstReceiptNumber = agGetText(UserPreferenceSettingPageObjects.oddRecptNumber);
		String SecondReceiptNumber = agGetText(UserPreferenceSettingPageObjects.EvenRecptNumber);
		int OddReptNumber = Integer.parseInt(FirstReceiptNumber.substring(FirstReceiptNumber.length() - 2));
		int EvenReptNumber = Integer.parseInt(SecondReceiptNumber.substring(SecondReceiptNumber.length() - 2));
		System.out.println(OddReptNumber);
		System.out.println(EvenReptNumber);
		if (EvenReptNumber > OddReptNumber) {
			Reports.ExtentReportLog("Case Listing (Receipt Numbers) are in Ascending Order", Status.PASS,
					"Case Listing in Ascending Order", true);
		} else {
			Reports.ExtentReportLog("Case Listing (Receipt Numbers) are not in Ascending Order", Status.FAIL,
					"Case Listing are not in Ascending Order", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to check whether Recept number has sorted in
	 *             Desending order.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 22-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void CaselistingDescendingCheck() {
		agSetStepExecutionDelay("3000");
		CaseManagementOperations.menuNavigation("Case listing");
		// CaseManagementOperations.menusubmenuNavigation("Case listing");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		String FirstReceiptNumber = agGetText(UserPreferenceSettingPageObjects.oddRecptNumber);
		String SecondReceiptNumber = agGetText(UserPreferenceSettingPageObjects.EvenRecptNumber);
		int OddReptNumber = Integer.parseInt(FirstReceiptNumber.substring(FirstReceiptNumber.length() - 2));
		int EvenReptNumber = Integer.parseInt(SecondReceiptNumber.substring(SecondReceiptNumber.length() - 2));
		if (EvenReptNumber < OddReptNumber) {
			Reports.ExtentReportLog("Case Listing (Receipt Numbers) are in Desending Order", Status.PASS,
					"Case Listing in Descending Order", true);
		} else {
			Reports.ExtentReportLog("Case Listing (Receipt Numbers) are not in Descending Order", Status.FAIL,
					"Case Listing are not in Descending Order", true);
		}

	}

}
