package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public abstract class OutofWorkFlowPageObjects {
    public static String outofWorkFlowLabel = "xpath#//label[text()='Out of workflow Status']";
    public static String selectDropdown = "xpath#//ul[contains(@class,'ui-selectonemenu-items') and contains(@id,'adverseEventArchiveform')]/child::li[contains(text(),'%s')]";
    public static String clickDropDown = "xpath#//label[contains(@id,'adverseEventArchiveform')][contains(text(),'%s')]/ancestor::div[contains(@class,'ui-panelgrid-cell formField')]//div/label";
    public static String outofWorkFlowDropDown = "xpath#//select[@id='adverseEventArchiveform:archiveASI-9059_input']";
    public static String receiptNoTextBox= "xpath#//input[@name='receiptNumber']";
    public static String searchButton = "xpath#//button[@id='advSearchButton']";
    public static String outofWorkFlowGetReceiptID = "xpath#//a[@id='ADL:ADT:0:receiptNoIdView']/span";
    public static String OutofworkflowStatus = "xpath#//input[@id='adverseEventArchiveform:archiveASI-9059_focus']/ancestor::div[@class='ui-helper-hidden-accessible']/following-sibling::label";
    public static String setOutofworkflowStatusDropDownValue = "xpath#//input[@class='ui-selectonemenu-filter ui-inputfield ui-inputtext ui-widget ui-state-default ui-corner-all ui-state-hover']";
    public static String outofworkflowStatusDropDownValueSelect = "xpath#//ul[@id='adverseEventArchiveform:archiveASI-9059_items']/li[contains(text(),";
    public static String get_Archivestatus = "xpath#//span[@id='ADL:ADT:0:remove1']";
    public static String receiptNumberlink = "xpath#//a[@id='ADL:ADT:0:receiptNoIdView']";
    public static String receiptNo_textfield = "xpath#//input[@id='adverseEventAdvanceform:receiptNoId']";
    
    public static String outofWorkflowChkbox="xpath#//label[text()='Out of workflow']/preceding-sibling::input[@id='outOfWorkflow']";
    public static String SearchBtn="xpath#//label[text()='Advance Search']/ancestor::div[@class='advHeader']//button[@id='advSearchButton']";
    public static String DeleteIcon="xpath#(//td[@class=' ADL_table_receiptNo']//img[@class='hideElementInListing'])[%s]";
    public static String FirstReptNumber="xpath#(//img[@class='hideElementInListing']/ancestor::tr)[%s]//a[@class='receiptNoSty']";
    public static String OutofWOrkflowValidation="xpath#//li[@title='Display Cases:Out of workflow']";
    public static String WorkflowStatus="xpath#//label[@id='adverseEventNew:caseStatusIdMah']";
public static String Noreorcfound = "xpath#//td[contains(text(),'No matching records found')]";
/**********************************************************************************************************
	 * Objective:The below method is created click DropDown by passing label name at runtime.
	 * Input Parameters: ColumnName
	 * Scenario Name Output
	 * Parameters:
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when   	 
**********************************************************************************************************/

public static String clickDropDown(String runTimeLabel) {
    String value = clickDropDown;
    String value2;
    value2 = value.replace("%s", runTimeLabel);
    return value2;
}
/**********************************************************************************************************
 * Objective:The below method is created to select Dropdown by passing label name at runtime.
 * Input Parameters: ColumnName
 * Scenario Name Output
 * Parameters:
 * @author:Avinash K Date :12-Jul-2019 Updated by and when   	 
**********************************************************************************************************/
public static String selectDropdown(String runTimeLabel) {
    String value = selectDropdown;
    String value2;
    value2 = value.replace("%s", runTimeLabel);
    return value2;
}

/**********************************************************************************************************
 * Objective:The below method is created to select Dropdown by passing label name at runtime.
 * Input Parameters: ColumnName
 * Scenario Name Output
 * Parameters:
 * @author:Avinash K Date :12-Jul-2019 Updated by and when   	 
**********************************************************************************************************/
public static String RecptNumber(String i) {
	String value =  FirstReptNumber.replace("%s", i);
   
    return value;
}
}