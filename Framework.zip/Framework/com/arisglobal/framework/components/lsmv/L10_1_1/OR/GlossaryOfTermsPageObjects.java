package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class GlossaryOfTermsPageObjects
{
	public static String newButton = "xpath#//a[@id='glossarylist:tabView:newId']";
	public static String deleteButton = "xpath#//a[@id='glossarylist:tabView:deleteId']";
	public static String importButton = "xpath#//a[contains(@id,'glossarylist:tabView:j')][contains(@aria-label,'Import Glossary')]";
	public static String downloadTemplateLink = "xpath#//a[@id='glossarylist:tabView:Export']";
	public static String editIcon = "xpath#//img[@id='glossarylist:tabView:glossaryDataTable:0:editLink1']";
	public static String exportGlossaryList_link= "xpath#//button[@id='glossarylist:tabView:excel']";
	public static String downloadGlossaryListIcon= "xpath#//a[contains(@class,'exportXml')]//img";
	public static String export_Btn= "xpath#//button[@id='glossarylist:tabView:submitId']";
	public static String cancelExport_Btn= "xpath#//button[@id='glossarylist:tabView:cancelDialogId']";
	public static String deleteYes_Button= "xpath#//button[@id='glossarylist:tabView:confirmation_yes']";
	public static String keywordSearchTextbox = "xpath#//input[@id='glossarylist:tabView:searchText']";
	public static String keywordSearchLookUp = "xpath#//a[contains(@id,'glossarylist:tabView:findButton')]";
	public static String exportIcon = "xpath#//img[@id='glossarylist:tabView:j_id_n7']";
	public static String quickColumnFilterIcon = "xpath#//img[@id='glossarylist:tabView:j_id_nf']";
	public static String columnSelectionIcon = "xpath#//button[@id='glossarylist:tabView:glossaryDataTable:toggler']";
	public static String refreshIcon = "xpath#//img[@id='glossarylist:tabView:j_id_nk']";
	public static String refreshlabel = "xpath#//label[@id='glossarylist:tabView:j_id_nl']";
	
	public static String previousPagePaginatorIcon = "xpath#//a[@aria-label='Previous Page']";
	public static String nextPagePaginatorIcon = "xpath#//a[@aria-label='Next Page']";	
	public static String noRecsFound = "xpath#//*[@class='ui-widget-content ui-datatable-empty-message']/child::td[@colspan='4']";
	
	//NewSection
	public static String saveButton = "xpath#//button[@id='glossaryForm:visibleSave']";
	public static String cancelButton = "xpath#//button[@id='glossaryForm:cancelId']";
	public static String termTextbox = "xpath#//input[@id='glossaryForm:glossaryTerm']";
	public static String descriptionTextArea = "xpath#//textarea[@id='glossaryForm:glossaryDesc']";
	public static String charLimitInfo = "xpath#//span[@id='glossaryForm:displayForGlossaryDesc']";
	public static String completedSuccessfullyMsg = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String errorMsg = "xpath#//label[contains(@class,'ui-outputlabel ui-widget warninglink' )]";
	
	//Common
	public static String successfulLabel = "xpath#//span[@id='mandatoryDialogform:mandatoryID_title']";
	public static String validationOk_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']";
	public static String confirmOk_Btn = "xpath#//button[@id='glossarylist:tabView:confirmation_yes']";
	
	//ImportSection
	public static String importExcelTitle = "xpath#//span[@id='uploadForm:uploadExcelDialog_title']";
	public static String uploadFileButton = "xpath#//input[@type='file'][@id='uploadForm:j_id_r9_input']";
	public static String uploadButton = "xpath#//button[@id='uploadForm:uploadFileButton3']";
	public static String cancelButton2 = "xpath#//button[@id='uploadForm:closeButton']";
	
	//Delete
	public static String successfulMsg = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String selectRec = "xpath#//td[@role='gridcell']/div[@class='ui-chkbox ui-widget']/div[2]/span";
	public static String deletevalidation_Popup = "xpath#//div[@id='glossarylist:tabView:deleteconfirm']/div[2]/span[@class='ui-confirm-dialog-message']";


	
}
