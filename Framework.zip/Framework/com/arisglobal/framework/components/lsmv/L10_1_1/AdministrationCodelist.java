package com.arisglobal.framework.components.lsmv.L10_1_1;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AdministrationCodelistPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AdministrationCodelist extends ToolManager{
	
	static String className = AdministrationCodelist.class.getSimpleName();
	static boolean status;
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify codelist.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchCodeList(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(AdministrationCodelistPageObjects.keywordSearchTextbox,
				getTestDataCellValue(scenarioName, "SearchText"));		
		agClick(AdministrationCodelistPageObjects.keywordSearchIcon);
		agSetStepExecutionDelay("2000");
		agIsVisible(AdministrationCodelistPageObjects.codelistName);
		Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
		Reports.ExtentReportLog("", Status.PASS,"<br />"+ "The Respective CODELIST 9744 NAME: COUNTRY_CORE_IB is listed", false);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to edit  codelist and verify DSUR code
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 05-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void EditCodelistandVerify(String scenarioName) {
		status = agIsVisible(AdministrationCodelistPageObjects.codelistName);
		if(status) {
			//Reports.ExtentReportLog("", Status.PASS, "Codelist Name Exist", true);
			agClick(AdministrationCodelistPageObjects.editCodeList);
			agWaitTillVisibilityOfElement(AdministrationCodelistPageObjects.codeListNameHeader);
			agJavaScriptExecuctorScrollToElement(AdministrationCodelistPageObjects.DSURCodelist);
			status = agIsVisible(AdministrationCodelistPageObjects.DSURCodelist);
			if(status) {
				Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
				Reports.ExtentReportLog("", Status.PASS,"<br />"+ "The respective DSUR codelist decode is available", false);
				agClick(AdministrationCodelistPageObjects.cancelBtn);				
			}else {
				Reports.ExtentReportLog("", Status.FAIL, "The respective DSUR codelist decode is not available", true);			
			}
		}else {
			Reports.ExtentReportLog("", Status.FAIL, "Codelist Name not Exist", true);			
		}		
	}
}
