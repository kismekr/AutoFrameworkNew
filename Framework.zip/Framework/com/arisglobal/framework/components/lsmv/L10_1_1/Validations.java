package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.CommonOperations;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDEContactLookupPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDELookupsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_CausalityPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_EventsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_LabDataPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_LiteraturePageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_ParentPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_PatientPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_ProductsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_ReporterPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_SourcePageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_StudyLookUpPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_StudyPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.Product_LookupPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ValidationPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Validations extends ToolManager {

	static boolean status;
	public static boolean validationExists;
	public static String currentWorkFlow = "";

	/**********************************************************************************************************
	 * @Objective: The below Method is create to check the colon(:) the validation
	 *             message
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 14-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static int CharcterOccurence(String value, String ch) {
		int count = 0;
		System.out.println(value.length());
		for (int j = 0; j < value.length(); j++) {
			if (ch.charAt(0) == value.charAt(j)) {
				count++;
			}
		}
		return count;
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to split value till colon(:) and get
	 *             the rule name
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 14-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String splitData(String validationMessage, String rex) {
		String value = null;
		if (CharcterOccurence(validationMessage, rex) > 2) {

			if (validationMessage.contains("CUST-")) {
				value = (validationMessage.split(rex))[2].trim();
			} else {
				value = (validationMessage.split(rex))[1].trim();
			}

		} else if (CharcterOccurence(validationMessage, rex) > 1) {
			value = (validationMessage.split(rex))[1].trim();
		} else {

			if (validationMessage.contains(rex)) {
				value = (validationMessage.split(rex))[0].trim();
			} else {
				value = (validationMessage.split(" "))[0] + " " + (validationMessage.split(" "))[1];
			}
		}
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to get the validations and resolve all
	 *             validation and move to next activity
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 14-May-2020
	 * @UpdatedByAndWhen: Karthikeyan Natarajan, 10-Jun-2020
	 **********************************************************************************************************/
	public static void getValidations() {
		try {
			if (agIsExists(ValidationPageObjects.validationsList) && validationExists) {
				Reports.ExtentReportLog("", Status.INFO, "Validation Exists", true);
				List<WebElement> ElementCount = agGetElementList(ValidationPageObjects.validationsList);
				for (int i = 0; i < ElementCount.size(); i++) {
					String value;
					if (!agIsVisible(ValidationPageObjects.selectValidationByIndex(String.valueOf(1)))) {
						Reports.ExtentReportLog("", Status.INFO, "Validation/warning not exist", true);
						continue;
					}
					try {
						agSetStepExecutionDelay("4000");
						value = ElementCount.get(i).getText();
						agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
					} catch (StaleElementReferenceException ex) {
						value = agGetText(ValidationPageObjects.selectValidationByIndex(String.valueOf(1)));
					}
					// String value =
					// agGetText(ValidationPageObjects.selectValidation(String.valueOf(1)));
					String Result = Validations.splitData(value, ":");
					if (Result.equalsIgnoreCase("ISP-V0023")) {
						if (value.contains("Patient"))
							resolveV0023("ISP-V0023:  Patient");
						else if (value.contains("Parent"))
							resolveV0023("ISP-V0023:  Parent");
					}
					System.out.println("Result: "+Result);
					Validations.resolveValidation(Result);
				}

				status = agIsVisible(ValidationPageObjects.validationsList);
				if (status) {
					Reports.ExtentReportLog("", Status.FAIL, "Validation/Warnings exist", true);
					validationExists = true;
				} else {
					Reports.ExtentReportLog("", Status.PASS, "", true);
					Reports.ExtentReportLog("", Status.INFO, "Validation/warning not exist", true);
					validationExists = false;
					// Unable to get text of currentflow due to change in Complete Activity Flow So
					// commenting the line.
					if (agIsVisible(CaseListingPageObjects.caseActHeader))
						currentWorkFlow = agGetText(CaseListingPageObjects.caseActHeader);
					else if (agIsVisible(CaseListingPageObjects.keywordSearchTextbox))
						currentWorkFlow = "";
				}
			}

		} catch (Exception e) {
			Reports.ExtentReportLog("", Status.FAIL, "Error Resolvong Failed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: label, columnName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 14-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setProductDropDownValue(String label, String columnName) {

		agClick(FDE_ProductsPageObjects.productDropdownSelect(label));
		agClick(FDE_GeneralPageObjects.clickDropDownValue(columnName));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: label, columnName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 14-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setDropDownValue(String label, String columnName) {

		agClick(FDE_GeneralPageObjects.selectGeneralDroprdown(label));
		agSetGlobalTimeOut("30");
		agClick(FDE_GeneralPageObjects.clickDropDownValue(columnName));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to move case from one activity to
	 *             next activity
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 14-May-2020
	 * @UpdatedByAndWhen:Karthikeyan Natarajan, 10-Jun-2020
	 **********************************************************************************************************/
	public static void completeActivityFlow(String activityName) {
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
		agWaitTillVisibilityOfElement(CaseListingPageObjects.caseActHeader);
		String WorkFlowheader = agGetText(CaseListingPageObjects.caseActHeader);
		CommonOperations.takeScreenShot();

		switch (activityName) {

		case "Case Approval":

			if (WorkFlowheader.equalsIgnoreCase("Final Review")) {
				CommonOperations.setActivity("Send to Case Approval");
			}

			break;

		case "Distribute":

			if (WorkFlowheader.equalsIgnoreCase("Case Approval (Auto)")) {
				CommonOperations.setActivity("Send to Distribute");
			}

			break;

		case "Distribute Transit":

			if (WorkFlowheader.equalsIgnoreCase("Distribute") || WorkFlowheader.equalsIgnoreCase("Minor Change")) {
				CommonOperations.setActivity("Send to Distribute Transit");
			}

			break;

		case "Quality Review":
			if (WorkFlowheader.equalsIgnoreCase("Full Data Entry")) {
				CommonOperations.setActivity("Send to Quality Review");
			}

			break;
		case "Final Review":

			if (WorkFlowheader.equalsIgnoreCase("Medical Review")) {
				CommonOperations.setActivity("Send to Final Review");
			}

			break;

		case "Exit":
			if (WorkFlowheader.equalsIgnoreCase("Non Case")) {
				CommonOperations.setActivity("Send to Exit");
			} else if (WorkFlowheader.equalsIgnoreCase("Distribute Transit")) {
				CommonOperations.setActivity("Exit");
			}
			break;
		case "Minor Change":

			if (WorkFlowheader.equalsIgnoreCase("Distribute Transit")) {
				CommonOperations.setActivity("Send to Minor Change");
			}

			break;

		case "Non Case":
			if (WorkFlowheader.equalsIgnoreCase("Initial")) {
				CommonOperations.setActivity("Send to Non Case");
			}

			break;

		case "Full Data Entry":
			if (WorkFlowheader.equalsIgnoreCase("Review")) {
				CommonOperations.setActivity("Send to Full Data Entry");
			}

			break;

		case "Review":
			if (WorkFlowheader.equalsIgnoreCase("Intake and Assessment")
					|| WorkFlowheader.equalsIgnoreCase("Translation")) {
				CommonOperations.setActivity("Send to Review");
			}
			break;

		case "Intake and Assessment":

			if (WorkFlowheader.equalsIgnoreCase("Non Case")) {
				CommonOperations.setActivity("Send to Intake and Assessment");
			}

			break;

		case "Medical Review":
			if (WorkFlowheader.equalsIgnoreCase("Quality Review")) {
				CommonOperations.setActivity("Send to Medical Review");
			}

			break;

		case "Supplemental Review":
			if (WorkFlowheader.equalsIgnoreCase("Medical Review")) {
				CommonOperations.setActivity("Send to Supplemental  Review");
			}

			break;

		case "Case Deletion":
			if (WorkFlowheader.equalsIgnoreCase("Case Deletion")) {
				CommonOperations.setActivity("Delete Confirmed");
			}

			break;

		}
		agMouseHover(FullDataEntryFormPageObjects.actions_Btn);
		// agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.completeActivity_link);
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.completeActivity_link);
		agSetStepExecutionDelay("5000");
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		agSetStepExecutionDelay("5000");
		if (agIsExists(ValidationPageObjects.validationsList)) {
			validationExists = true;
			Reports.ExtentReportLog("", Status.PASS, "Action Un completed with Validation Errors", true);

			if (agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully)) {
				// System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
				Reports.ExtentReportLog("", Status.PASS, "Action completed without Validation Errors", true);
				agClick(FullDataEntryFormPageObjects.ActionOkBtn);
			}
		} else if (agIsVisible(FullDataEntryFormPageObjects.completeAct_WarningLabel)) {
			validationExists = false;
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.warning_YesBtn);
			Reports.ExtentReportLog("", Status.PASS, "Action completed with Validation Errors", true);
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.ActionOkBtn);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.actComp_Sucessfully);

		} else if (agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully)) {
			validationExists = false;
			// System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
			Reports.ExtentReportLog("", Status.PASS, "Action completed without Validation Errors", true);
			agClick(FullDataEntryFormPageObjects.ActionOkBtn);
		} else if (agIsVisible(FullDataEntryFormPageObjects.ActionOkBtn)) {
			validationExists = false;
			// System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
			Reports.ExtentReportLog("", Status.PASS, "Action completed wit Validation Errors", true);
			agClick(FullDataEntryFormPageObjects.ActionOkBtn);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetStepExecutionDelay("3000");
		if (agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully)) {
			validationExists = false;
			// System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
			Reports.ExtentReportLog("", Status.PASS, "Action completed without Validation Errors", true);
			agClick(FullDataEntryFormPageObjects.ActionOkBtn);
		}
		if (activityName.equalsIgnoreCase("Exit")) {
			agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
			System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.PASS, "Case saved", true);
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to resolve validations occurred while
	 *             complete activity
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 14-May-2020
	 * @UpdatedByAndWhen: Karthikeyan Natarajan, 10-Jun-2020
	 **********************************************************************************************************/
	public static void resolveValidation(String activityName) {

		switch (activityName) {

		case "ISP-V0092":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(FDE_ReporterPageObjects
					.select_RadioButtons(FDE_ReporterPageObjects.primarySourceRegulatory_Radiobtn, ("Yes")));

			break;

		case "Product(s)(Product)":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(ValidationPageObjects.productInformation);
			String value = agGetAttribute("title", FDE_ProductsPageObjects.productDescriptionTextbox);
			if (value.isEmpty()) {
				agClick(FDE_ProductsPageObjects.productDescriptionLookup);
				agClick(FDE_ProductsPageObjects.productLibray_RadioBtn);

				agSetValue(FDE_ProductsPageObjects
						.level1ProductTextbox(Product_LookupPageObjects.prodLibproductNameTextbox), "Anacin");

				agClick(FDE_ProductsPageObjects.searchButton);
				agClick(FDE_ProductsPageObjects.checkFirstProdInProdLib);
				if (agIsVisible(FDE_ProductsPageObjects.indication_Popup) == true) {
					agClick(FDE_ProductsPageObjects.indicationPopup_CloseIcon);
				}
				agClick(FDE_ProductsPageObjects.prodLibOkButton);
				if (agIsVisible(FDE_ProductsPageObjects.listedness_Popup) == true) {
					agClick(FDE_ProductsPageObjects.listedness_PopupYesBtn);
				}

				if (agIsVisible(FDE_ProductsPageObjects.recalculationPopupConfirmation) == true) {
					agClick(FDE_ProductsPageObjects.listedness_PopupYesBtn);
				}

			} else
				setProductDropDownValue(FDE_ProductsPageObjects.productCharacterizationDrpdwn, "Suspect ( Sus ) ");
			completeActivityFlow("Review");
			break;

		case "ISP-V0062":
			agClick(ValidationPageObjects.selectValidation(activityName));
			CommonOperations.setFDEDropDownValue(FDE_LabDataPageObjects.testResultValueUnit_DropDown, "kilogram (kg) ");

			break;

		case "V0107":
			agClick(ValidationPageObjects.selectValidation(activityName));
			CommonOperations.setFDEDropDownValue(FDE_SourcePageObjects.sourceDropdown, "Affiliate ");

			break;

		case "ISP-V0059":
			agClick(ValidationPageObjects.selectValidation(activityName));
			setDropDownValue(FDE_GeneralPageObjects.reportType_Dropdown, "Other ");
			if (agIsExists(FDE_GeneralPageObjects.alreadyCodedWarning)) {

				agClick(FDE_GeneralPageObjects.recodeYesBtn);
			}

			break;

		case "ISP-V0015":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(CommonPageObjects.selectRadioButton("Seriousness", "No"));
			break;

		case "ISP-V0068":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_ProductsPageObjects.lotNumber_TextField, "LotId1001");
			break;

		case "ISP-V0054":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetStepExecutionDelay("5000");
			agClick(FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.actionTakenWithDrug));
			agClick(FDE_ProductsPageObjects.clickDropDownValue("Unknown"));
			agSetStepExecutionDelay(Constants.defaultGlobalStepExecutionDelay + "");
			break;

		case "ISP-V0012":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_EventsPageObjects.reportedTerm_Textfield, "ReportedTermId1001");
			break;

		case "ISP-V0022":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(FDE_PatientPageObjects.click_DropDown(FDE_PatientPageObjects.gender_DropDown));
			agClick(FDE_PatientPageObjects.setdropDownValue("Prefer Not to Disclose ( MSK )"));
			break;

		case "ISP-V0037":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(FDE_ReporterPageObjects.click_DropDown(FDE_ReporterPageObjects.qualification_DropDown));
			agClick(FDE_ReporterPageObjects.click_DropDown(FDE_ReporterPageObjects.qualification_DropDown));
			agClick(FDE_ReporterPageObjects.setdropDownValue("Third Party Servicer"));
			break;

		case "ISP-V0091":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(CommonPageObjects.selectRadioButton("Seriousness ", "No"));
			break;

		case "ISP-V0016":
			agClick(ValidationPageObjects.selectValidation(activityName));
			boolean isVisible = agIsVisible(FDE_EventsPageObjects.setdropDownValue("Unknown ( unk )"));
			do {
				agClick(FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.outCome_DropDown));
				isVisible = agIsVisible(FDE_EventsPageObjects.setdropDownValue("Unknown ( unk )"));

			} while (isVisible);
			// agClick(FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.outCome_DropDown));
			// agClick(FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.outCome_DropDown));
			agClick(FDE_EventsPageObjects.setdropDownValue("Unknown ( unk )"));
			break;

		case "ISP-V0043":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.countryDetection_DropDown));
			agClick(FDE_EventsPageObjects.setdropDownValue("FOREIGN"));
			break;

		case "ISP-V0061":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClearText(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.cessationdate_Date));
			break;

		case "ISP-V0045":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_PatientPageObjects.set_WeightHeight_TxtField.replace("%s", "Height"), "250");
			agClick(FDE_PatientPageObjects.click_embeddedDrpdwn(FDE_PatientPageObjects.height_DropDown));
			agClick(FDE_PatientPageObjects.setdropDownValue("Centimeters"));

			break;

		case "ISP-V0065":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(CommonPageObjects.selectRadioButton("Pregnant?", "No"));
			break;

		case "ISP-V0066":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetStepExecutionDelay("5000");
			agClick(ValidationPageObjects.confirmationOkButton);
			agSetValue(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.protocolNo_Textbox),
					"ProtcolNo1001");
			agClick(FDE_StudyPageObjects.clickDroprdown(FDE_StudyPageObjects.studyType_DropDown));
			agClick(FDE_StudyPageObjects.setdropDownValue("Clinical Trial"));
			agClick(ValidationPageObjects.confirmationYesButton);
			break;

		case "ISP-V0107":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(ValidationPageObjects.primarySourceCheckBox);
			break;
		case "ISP-V0028":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(FDE_ReporterPageObjects.click_Checkboxs(FDE_ReporterPageObjects.primaryReporter_Checkbox));
			break;

		case "ISP-V0033":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(FDE_GeneralPageObjects.initial_Followup_RadioBtn(FDE_GeneralPageObjects.initialRadiobtn));
			break;
		// Pooja
		case "ISP-V0003":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(FDE_StudyPageObjects.protocolNo_Lookup);
			agSetStepExecutionDelay("3000");
			agSetValue(FDE_StudyLookUpPageObjects.studyNo_TextField, "Study-0001");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agClick(FDE_StudyLookUpPageObjects.search_button);
			agSetStepExecutionDelay("4000");
			agClick(FDE_StudyLookUpPageObjects.radioButton("Study-0001"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agClick(FDE_StudyLookUpPageObjects.ok_button);
			break;

		case "ISP-V0038":
			agClick(ValidationPageObjects.selectValidation(activityName));
			if (agGetText(FDE_SourcePageObjects.ReferenceNumberTextBox).isEmpty()) {
				agSetValue(FDE_SourcePageObjects.ReferenceNumberTextBox, "Test123");
			} else {
				CommonOperations.setFDEDropDownValue(FDE_SourcePageObjects.referenceTypeDropdown, "Co-License Partner");
			}
			break;

		case "ISP-V0041":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_SourcePageObjects.dateReceivedTextBox, getCurrentDate());
			break;

		case "ISP-V0007":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_GeneralPageObjects.latestReceiveDate, getCurrentDate());
			break;

		case "ISP-V0056":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.patientID_Textbox), "PIDTEST");
			completeActivityFlow("Quality Review");
			break;

		case "ISP-V0093":
			agClick(ValidationPageObjects.selectValidation(activityName));
			if (agGetText(FDE_ProductsPageObjects.productEmbedTxtbox(FDE_ProductsPageObjects.gestationPeriod))
					.isEmpty()) {
				agSetValue(FDE_ProductsPageObjects.productEmbedTxtbox(FDE_ProductsPageObjects.gestationPeriod), "10");
			} else {
				CommonOperations.setFDEDropDownValue(FDE_ProductsPageObjects.gestationPeriod, "Month ( M )");
			}
			break;

		case "ISP-V0081":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_PatientPageObjects.set_WeightHeight(FDE_PatientPageObjects.weight_DropDown), "68");
			break;

		case "ISP-V0047":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_LabDataPageObjects.testName_Textbox, "Fever of unknown origin");
			break;

		case "ISP-V0026":
			agClick(ValidationPageObjects.selectValidation(activityName));
			CommonOperations.setFDEDropDownValue(FDE_PatientPageObjects.ageTimeEvent_DropDown, "Year(s) ( Y )");
			break;

		case "ISP-V0029":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetStepExecutionDelay("2000");
			agJavaScriptExecuctorClick(
					FDE_ReporterPageObjects.click_DropDown(FDE_ReporterPageObjects.Country_DropDown));
			agClick(FDE_ReporterPageObjects.setdropDownValue("GERMANY ( DEU ) "));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			break;

		case "ISP-V0024":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.patientID_Textbox),
					"PID-167281");
			break;

		case "CASE FLAGS":
			if (agIsVisible(ValidationPageObjects.selectValidation(activityName)) == true)
				FDE_Operations.FDE_Navigations(FullDataEntryFormPageObjects.dataAssessment_Link);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.dataAssessment_Label);
			agIsVisible(FullDataEntryFormPageObjects.dataAssessment_Label);
			agClick(FullDataEntryFormPageObjects
					.dataAssessment_links(FullDataEntryFormPageObjects.dataAssessmentNew_Link));
			agSetStepExecutionDelay("5000");
			if (agIsVisible(FullDataEntryFormPageObjects.dataAssessment_WarningPopup) == true) {
				agClick(FullDataEntryFormPageObjects.dataAssessment_WarningPopup_YesBtn);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agIsVisible(FullDataEntryFormPageObjects.dataAssessment_header);
			CommonOperations.agwaitTillVisible(FullDataEntryFormPageObjects.dataAssessment_header, 10, 1000);

			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.dataAssessment_header);
			agSetValue(FullDataEntryFormPageObjects.dataAssesComments_TxtArea, "Data assesment as new");
			CommonOperations.takeScreenShot();
			agClick(FullDataEntryFormPageObjects.classifyCase_Btn);
			agWaitTillVisibilityOfElement(CaseListingPageObjects.validationPopup);
			String Validation = agGetText(CaseListingPageObjects.validationPopup);
			status = agIsVisible(CaseListingPageObjects.validationPopup);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Data assesed as New :: Validation-" + Validation, true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Data assesed as New Unsuccessfull", true);
			}
			agClick(CaseListingPageObjects.PopupOkButton);
			completeActivityFlow("Full Data Entry");
			break;

		case "V0003":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.processingUnit_Dropdown));
			agClick(FDE_GeneralPageObjects.clickDropDownValue("Arisglobal"));
			break;

		case "ISP-V0090":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(FDE_ReporterPageObjects.select_RadioButtons(FDE_ReporterPageObjects.personType_Radiobtn, "Author"));
			break;

		case "ISP-V0013":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_EventsPageObjects.reportedTerm_Textfield, "FEVER");
			break;

		case "ISP-V0034":
			agClick(ValidationPageObjects.selectValidation(activityName));
			setProductDropDownValue(FDE_ProductsPageObjects.productCharacterizationDrpdwn, "Suspect ( Sus ) ");
			break;

		case "ISP-V0057":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.firstName_Textbox),
					"Test First Name");
			agWaitTillInvisibilityOfElement(ValidationPageObjects.selectValidation(activityName));
			// completeActivityFlow("Quality Review");
			break;

		case "CUST-V081":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(FDE_GeneralPageObjects.senderOrganizationasCodedLookup);
			agClick(FDELookupsPageObjects.companyUnit_Radiobtn);
			agSetValue(FDELookupsPageObjects.set_Textfields(FDELookupsPageObjects.companyUnitName_Textfield), "INDIA");
			agClick(FDELookupsPageObjects.searchSenderButton);
			agSetStepExecutionDelay("2000");
			agClick(FDELookupsPageObjects.radioButton);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CommonOperations.takeScreenShot();
			agClick(FDELookupsPageObjects.senderOkBtn);
			break;

		case "ISP-V0014":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.seriousness_Radiobtn, "Yes"));
			completeActivityFlow("Review");
			boolean V0019 = agIsVisible(ValidationPageObjects.selectValidation("ISP-V0019"));
			if (V0019)
				resolveValidation("ISP-V0019");
			break;

		case "V0109":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_ProductsPageObjects.activeSubstance_TextField, "ActiveSubstance123");
			break;

		case "ISP-V0019":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(FDE_EventsPageObjects.select_RadioButtons(FDE_EventsPageObjects.death_Radiobtn, "Yes"));
			completeActivityFlow("Review");
			break;

		case "CUST-V007":
			agClick(ValidationPageObjects.selectValidation(activityName));
			CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.Company_Dropdown, "Reasonable possibility");
			break;

		case "ISP-V0009":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.prductNameAsReportedTxtbox),
					"Auto-DOLO FRESH");
			break;

		case "V0002":
			agClick(ValidationPageObjects.selectValidation(activityName));
			CommonOperations.setFDEDropDownValue(FDE_SourcePageObjects.sourceDropdown, "Clinical Trial");
			break;

		case "ISP-V0053":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(ValidationPageObjects.arrowIcon);
			FDE_Operations.tabNavigation("Reporter");
			agClick(FDE_ReporterPageObjects.select_RadioButtons(FDE_ReporterPageObjects.healthProfessional_Radiobtn,
					"Yes"));
			break;

		case "ISP-V0036":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.patientID_Textbox),
					"PID-167281");
			break;

		case "ISP-V0039":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate),
					getCurrentDate());
			break;

		case "ISP-V0089":
			agClick(ValidationPageObjects.selectValidation(activityName));
			if (agIsVisible(ValidationPageObjects.literatureReferenceBox) == true) {
				agClick(ValidationPageObjects.literatureReferenceBox);
			} else {
				agClick(ValidationPageObjects.arrowIcon);
				FDE_Operations.tabNavigation("Literature");
				agSetValue(FDE_LiteraturePageObjects.articleTitle_Textbox, "ArticleTitle");
				agSetValue(FDE_LiteraturePageObjects.journalTitle_Textbox, "JournalTitle");
				agSetValue(FDE_LiteraturePageObjects.publicationDate_Textbox, getCurrentDate());
				agSetValue(FDE_LiteraturePageObjects.issue_Textbox, "Literature Issue");
				agSetValue(FDE_LiteraturePageObjects.pageFrom_Textbox, "1");
				agSetValue(FDE_LiteraturePageObjects.pageTo_Textbox, "2");
				agSetValue(FDE_LiteraturePageObjects.edition_Textbox, "Literature Edition");
				agSetValue(FDE_LiteraturePageObjects.digitalObjectIdentifier_Textbox, "1");
				agSetValue(FDE_LiteraturePageObjects.additionalLiteratureInfo_Textbox,
						"AdditionalLiteratureInformation");
				FDE_Operations.LSMVSaveReconsile();
				if (agIsVisible(ValidationPageObjects.selectValidation(activityName)) == true) {
					agClick(ValidationPageObjects.selectValidation(activityName));
					agClick(ValidationPageObjects.literatureReferenceBox);
				} else {
					agClick(ValidationPageObjects.arrowIcon);
					FDE_Operations.tabNavigation("Reporter");
					agClick((FDE_ReporterPageObjects.literatureReference).replace("%label%",
							FDE_ReporterPageObjects.literatureReference_Textbox));
					agClick(ValidationPageObjects.literatureReferenceBox);
				}
			}
			break;

		case "ISP-V0010":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.prductNameAsReportedTxtbox),
					"Auto-DOLO FRESH");
			break;

		case "ISP-V0005":
			agClick(ValidationPageObjects.selectValidation(activityName));
			String LRD = agGetText(FDE_GeneralPageObjects.latestReceiveDate);
			String IRD = agGetText(FDE_GeneralPageObjects.initialReceiveDate);
			if (LRD.compareToIgnoreCase(IRD) > 0) {
				agClearText(FDE_GeneralPageObjects.initialReceiveDate);
				agSetValue(FDE_GeneralPageObjects.initialReceiveDate, LRD);
			} else if (LRD.compareToIgnoreCase(IRD) < 0) {
				agClearText(FDE_GeneralPageObjects.initialReceiveDate);
				agSetValue(FDE_GeneralPageObjects.initialReceiveDate, LRD);
			}
			break;

		case "ISP-V0008":
			agClick(ValidationPageObjects.selectValidation(activityName));
			String LRD1 = agGetText(FDE_GeneralPageObjects.latestReceiveDate);
			String IRD1 = agGetText(FDE_GeneralPageObjects.initialReceiveDate);
			if (LRD1.compareToIgnoreCase(IRD1) > 0) {
				agClearText(FDE_GeneralPageObjects.initialReceiveDate);
				agSetValue(FDE_GeneralPageObjects.initialReceiveDate, LRD1);
			} else if (LRD1.compareToIgnoreCase(IRD1) < 0) {
				agClearText(FDE_GeneralPageObjects.initialReceiveDate);
				agSetValue(FDE_GeneralPageObjects.initialReceiveDate, LRD1);
			}
			break;

		case "ISP-V0048":
			agClick(ValidationPageObjects.selectValidation(activityName));
			CommonOperations.setFDEDropDownValue(FDE_LabDataPageObjects.testResultCode_DropDown, "Positive");
			break;

		case "ISP-V0030":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.primarySourceCountry));
			agClick(FDE_GeneralPageObjects.clickDropDownValue("GERMANY ( DEU ) "));
			break;

		case "ISP-V0025":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_PatientPageObjects.ageAtEvent, "50");
			break;

		case "ISP-V0085":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agClick(FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.primarySourceCountry));
			agClick(FDE_GeneralPageObjects.clickDropDownValue("GERMANY ( DEU ) "));
			break;

		case "ISP-V0088":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetValue(FDE_StudyPageObjects.setData_Textfields(FDE_StudyPageObjects.protocolNo_Textbox),
					"ProtcolNo1001");
			break;

		case "ISP-V0027":
			agClick(ValidationPageObjects.selectValidation(activityName));
			boolean isVis = agIsVisible(FDE_ReporterPageObjects.setdropDownValue("Third Party Servicer"));
			do {
				agClick(FDE_ReporterPageObjects.click_DropDown(FDE_ReporterPageObjects.qualification_DropDown));
				isVis = agIsVisible(FDE_ReporterPageObjects.setdropDownValue("Third Party Servicer"));
			} while (isVis);
			// agClick(FDE_ReporterPageObjects.click_DropDown(FDE_ReporterPageObjects.qualification_DropDown));
			// agClick(FDE_ReporterPageObjects.click_DropDown(FDE_ReporterPageObjects.qualification_DropDown));
			agClick(FDE_ReporterPageObjects.setdropDownValue("Third Party Servicer"));
			break;

		case "ISP-V0021":
			agClick(ValidationPageObjects.selectValidation(activityName));
			boolean isVisibleError = agIsVisible(FDE_EventsPageObjects.setdropDownValue("Unknown ( unk )"));
			do {
				agClick(FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.outCome_DropDown));
				isVisibleError = agIsVisible(FDE_EventsPageObjects.setdropDownValue("Unknown ( unk )"));
			} while (isVisibleError);
			agClick(FDE_EventsPageObjects.setdropDownValue("Unknown ( unk )"));
			break;

		case "V0111":
			agClick(ValidationPageObjects.selectValidation(activityName));
			setProductDropDownValue(FDE_ProductsPageObjects.studyProductType, "Auxiliary product");
			break;

		case "ISP-V0044":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetStepExecutionDelay("3000");
			setProductDropDownValue(FDE_ProductsPageObjects.codingClassDrpdwn, "Blinded");
			agSetStepExecutionDelay(Constants.defaultGlobalStepExecutionDelay + "");
			break;

		case "ISP-V0040":
			agClick(ValidationPageObjects.selectValidation(activityName));
			CommonOperations.setFDEDropDownValue(FDE_SourcePageObjects.sourceDropdown, "Affiliate ");
			break;

		case "V0112":
			agClick(ValidationPageObjects.selectValidation(activityName));
			setProductDropDownValue(FDE_ProductsPageObjects.studyProductType, "Auxiliary product");
			break;
		case "At least":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetStepExecutionDelay("5000");
			agClick(FDEContactLookupPageObjects.contactLookUpIcon);
			agSetValue(FDEContactLookupPageObjects.FirstNameTextbox, "Scott");
			agSetValue(FDEContactLookupPageObjects.LastNameTextbox, "Tiger");
			agClick(FDEContactLookupPageObjects.SearchButton);
			agClick(FDEContactLookupPageObjects.CheckBox);
			agClick(FDEContactLookupPageObjects.OkButton);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			break;
		case "ISP-V0046":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agSetStepExecutionDelay("3000");
			agClick(FDE_CausalityPageObjects.e2BCausalityLink);
			agClick(FDE_CausalityPageObjects.clicksource_Dropdown("1"));
			agClick(FDE_CausalityPageObjects.set_Dropdown("1", "Reporter"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			completeActivityFlow("Review");
			break;
		
		case "ISP-V0067":
			agClick(ValidationPageObjects.selectValidation(activityName));
			agWaitTillVisibilityOfElement(FDE_GeneralPageObjects.additionalDocumentsAvailableRadio("No"));
			CommonOperations.verifyRadioButton(FDE_GeneralPageObjects.additionalDocumentsAvailableLabel, "No");
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects.additionalDocumentsAvailableRadio("No"));
			agSetStepExecutionDelay("3000");
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.SaveButton);
			Reports.ExtentReportLog("", Status.PASS, "As Expected", true); 
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.SaveButton);
			break;
		}

		boolean status = agIsVisible(ValidationPageObjects.selectValidation(activityName));
		if (status)
			Reports.ExtentReportLog("", Status.FAIL, "Eror Id: " + activityName + " is not resolved", true);
		else
			Reports.ExtentReportLog("", Status.INFO, "Eror Id: " + activityName + " is resolved Successfully", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to resolve validatio of V0023 and its
	 *             two diferent components - Parent and Pateint
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 10-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	private static void resolveV0023(String activityName) {
		// String value=CommonOperations.returnDateTime("d:m:y-20");
		String currentDate = getCurrentDate();
		String year = currentDate.split("-")[2];
		String newDOB = currentDate.split("-")[0] + "-" + currentDate.split("-")[1] + "-"
				+ (Integer.parseInt(year) - 20);
		agClick(ValidationPageObjects.selectValidation(activityName));
		if (activityName.contains("Patient")) {
			agSetValue(FDE_PatientPageObjects.setData_Datesfields(FDE_PatientPageObjects.patientDOB_Date), newDOB);
			agClick(FDE_PatientPageObjects.setData_Datesfields(FDE_PatientPageObjects.patientDOB_Date));
		}

		else {
			agSetValue(FDE_ParentPageObjects.parentDOB_Datefield, newDOB);
			agClick(FDE_ParentPageObjects.parentDOB_Datefield);
		}
		agSetStepExecutionDelay("3000");
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to retreive current date
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 10-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	private static String getCurrentDate() {
		String currentDate = null;
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDateTime todayDate = LocalDateTime.now();
		currentDate = dateTimeFormatter.format(todayDate);
		return currentDate;
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to get the Error/warning validations
	 *             and resolve all validation and move to next activity fr
	 *             preveliged users
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 03-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void getBlindingUnBlindingProductValidations_PrevUsers(String scenarioName) {
		try {

			if (agIsExists(ValidationPageObjects.validationAllList)) {
				Reports.ExtentReportLog("", Status.INFO, "Validation Exists", true);
				String unBlindProd;
				String blindProd;
				unBlindProd = Validations.getUnBlindProduct();
				blindProd = Validations.getBlindProduct();
				String Result = null;

				Validations.verifyValidationForBlindingUnBlinding_PrevUsers(Result, scenarioName, unBlindProd,
						blindProd);

				status = agIsVisible(ValidationPageObjects.validationAllList);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Validation/Warnings exist", true);
					validationExists = true;
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Validation/warning not exist", true);
					validationExists = false;
				}
			}

		} catch (Exception e) {
			Reports.ExtentReportLog("", Status.FAIL, "Error Verification of validations Failed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to verify the validations for the
	 *             blinding and unblinding products for previleged users
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 03-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyValidationForBlindingUnBlinding_PrevUsers(String result, String scenarioName,
			String unBlindProd, String blindProd) {

		List<WebElement> ElementCount = agGetElementList(ValidationPageObjects.validationAllList);
		for (int i = 0; i < ElementCount.size(); i++) {
			String value;
			try {
				agSetStepExecutionDelay("4000");
				value = ElementCount.get(i).getText();
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			} catch (StaleElementReferenceException ex) {
				value = agGetText(ValidationPageObjects.columnHeaderList(String.valueOf(i)));
			}

			result = Validations.getValidationNumber(value);
			if (result.equalsIgnoreCase("#1:V0109")) {
				agClick(ValidationPageObjects.columnHeaderList(Integer.toString(i + 1)));

				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
				agAssertExists(ValidationPageObjects.blindedProduct);
				if (blindProd.equalsIgnoreCase(getTestDataCellValue(scenarioName,
						"Products_ProductInformation_ProductDescription_ProductName"))) {
					Reports.ExtentReportLog("", Status.PASS, "Validation Exists for " + blindProd + ": Blinded Product"
							+ "- " + result + ":" + "Verified Successfully", true);

				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Validation not Exists for " + blindProd
							+ ":Blinded Product" + "- " + result + ":" + "Verified Successfully", true);
				}

			}

			else if (result.equalsIgnoreCase("#2:V0109")) {
				agClick(ValidationPageObjects.columnHeaderList(Integer.toString(i + 1)));
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "Product_LookupOperations");
				agAssertExists(ValidationPageObjects.unBlindedProduct);
				if (unBlindProd.equalsIgnoreCase(getTestDataCellValue(scenarioName, "ProductLibraryProductName"))) {
					Reports.ExtentReportLog("", Status.PASS, "Validation Exists for " + unBlindProd
							+ ": UnBlinded Product" + "- " + result + ":" + "Verified Successfully", true);

				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Validation not Exists for " + unBlindProd
							+ ":UnBlinded Product" + "- " + result + ":" + "Verified Successfully", true);
				}

			}

			else if (result.equalsIgnoreCase("#2:V0112")) {
				agClick(ValidationPageObjects.columnHeaderList(Integer.toString(i + 1)));

				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "Product_LookupOperations");
				agAssertExists(ValidationPageObjects.unBlindedProduct);
				if (unBlindProd.equalsIgnoreCase(getTestDataCellValue(scenarioName, "ProductLibraryProductName"))) {
					Reports.ExtentReportLog("", Status.PASS, "Validation Exists for " + unBlindProd
							+ ": UnBlinded Product" + "- " + result + ":" + "Verified Successfully", true);

				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Validation not Exists for " + unBlindProd
							+ ":UnBlinded Product" + "- " + result + ":" + "Verified Successfully", true);
				}
			}

			else if (result.equalsIgnoreCase("#1:ISP-V0054")) {
				agClick(ValidationPageObjects.columnHeaderList(Integer.toString(i + 1)));

				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
				agAssertExists(ValidationPageObjects.blindedProduct);
				if (blindProd.equalsIgnoreCase(getTestDataCellValue(scenarioName,
						"Products_ProductInformation_ProductDescription_ProductName"))) {
					Reports.ExtentReportLog("", Status.PASS, "Validation Exists for " + blindProd + ": Blinded Product"
							+ "- " + result + ":" + "Verified Successfully", true);

				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Validation not Exists for " + blindProd
							+ ":Blinded Product" + "- " + result + ":" + "Verified Successfully", true);
				}

			}

			else if (result.equalsIgnoreCase("#2:ISP-V0054")) {
				agClick(ValidationPageObjects.columnHeaderList(Integer.toString(i + 1)));

				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "Product_LookupOperations");
				agAssertExists(ValidationPageObjects.unBlindedProduct);
				if (unBlindProd.equalsIgnoreCase(getTestDataCellValue(scenarioName, "ProductLibraryProductName"))) {
					Reports.ExtentReportLog("", Status.PASS, "Validation Exists for " + unBlindProd
							+ ": UnBlinded Product" + "- " + result + ":" + "Verified Successfully", true);

				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Validation not Exists for " + unBlindProd
							+ ":UnBlinded Product" + "- " + result + ":" + "Verified Successfully", true);
				}
			}

			else if (result.equalsIgnoreCase("#1:V0111")) {
				agClick(ValidationPageObjects.columnHeaderList(Integer.toString(i + 1)));
				agAssertExists(ValidationPageObjects.blindedProduct);
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
				if (blindProd.equalsIgnoreCase(getTestDataCellValue(scenarioName,
						"Products_ProductInformation_ProductDescription_ProductName"))) {
					Reports.ExtentReportLog("", Status.PASS, "Validation Exists for " + blindProd + ": Blinded Product"
							+ "- " + result + ":" + "Verified Successfully", true);

				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Validation not Exists for " + blindProd
							+ ":Blinded Product" + "- " + result + ":" + "Verified Successfully", true);
				}

			} else if (result.equalsIgnoreCase("#2:V0111")) {
				agClick(ValidationPageObjects.columnHeaderList(Integer.toString(i + 1)));

				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "Product_LookupOperations");
				agAssertExists(ValidationPageObjects.unBlindedProduct);
				if (unBlindProd.equalsIgnoreCase(getTestDataCellValue(scenarioName, "ProductLibraryProductName"))) {
					Reports.ExtentReportLog("", Status.PASS, "Validation Exists for " + unBlindProd
							+ ": UnBlinded Product" + "- " + result + ":" + "Verified Successfully", true);

				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Validation not Exists for " + unBlindProd
							+ ":UnBlinded Product" + "- " + result + ":" + "Verified Successfully", true);
				}

			}

			else if (result.equalsIgnoreCase("#1:ISP-V0044")) {
				agClick(ValidationPageObjects.columnHeaderList(Integer.toString(i + 1)));

				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
				agAssertExists(ValidationPageObjects.blindedProduct);
				if (blindProd.equalsIgnoreCase(getTestDataCellValue(scenarioName,
						"Products_ProductInformation_ProductDescription_ProductName"))) {
					Reports.ExtentReportLog("", Status.PASS, "Validation Exists for " + blindProd + ": Blinded Product"
							+ "- " + result + ":" + "Verified Successfully", true);

				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Validation not Exists for " + blindProd
							+ ":Blinded Product" + "- " + result + ":" + "Verified Successfully", true);
				}

			}

			else if (result.equalsIgnoreCase("#2:ISP-V0044")) {
				agClick(ValidationPageObjects.columnHeaderList(Integer.toString(i + 1)));

				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "Product_LookupOperations");
				agAssertExists(ValidationPageObjects.unBlindedProduct);
				if (unBlindProd.equalsIgnoreCase(getTestDataCellValue(scenarioName, "ProductLibraryProductName"))) {
					Reports.ExtentReportLog("", Status.PASS, "Validation Exists for " + unBlindProd
							+ ": UnBlinded Product" + "- " + result + ":" + "Verified Successfully", true);

				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Validation not Exists for " + unBlindProd
							+ ":UnBlinded Product" + "- " + result + ":" + "Verified Successfully", true);
				}

			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Validation Not Exists : Not Verified Successfully" + result,
						true);
			}

		}

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to get the Error/warning validations
	 *             and resolve all validation and move to next activity for
	 *             unpreveliged users
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 03-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void getBlindingUnBlindingProductValidations_UnPrevUsers(String scenarioName) {
		try {

			if (agIsExists(ValidationPageObjects.validationAllList)) {
				Reports.ExtentReportLog("", Status.INFO, "Validation Exists", true);
				// String unBlindProd;
				String blindProd;
				// unBlindProd = Validations.getUnBlindProduct();
				blindProd = Validations.getBlindProduct();
				String Result = null;

				Validations.verifyValidationForBlindingUnBlinding_UnPrevUsers(Result, scenarioName, blindProd);

				status = agIsVisible(ValidationPageObjects.validationAllList);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Validation/Warnings exist", true);
					validationExists = true;
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Validation/warning not exist", true);
					validationExists = false;
				}
			}

		} catch (Exception e) {
			Reports.ExtentReportLog("", Status.FAIL, "Error Verification of validations Failed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to verify the validations for the
	 *             blinding and unblinding products for Unprevileged users
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 03-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyValidationForBlindingUnBlinding_UnPrevUsers(String result, String scenarioName,
			String blindProd) {

		List<WebElement> ElementCount = agGetElementList(ValidationPageObjects.validationAllList);
		for (int i = 0; i < ElementCount.size(); i++) {
			String value;
			try {
				agSetStepExecutionDelay("4000");
				value = ElementCount.get(i).getText();
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			} catch (StaleElementReferenceException ex) {
				value = agGetText(ValidationPageObjects.columnHeaderList(String.valueOf(i)));
			}

			result = Validations.getValidationNumber(value);
			if (result.equalsIgnoreCase("#1:V0109")) {
				agClick(ValidationPageObjects.columnHeaderList(Integer.toString(i + 1)));

				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
				agAssertNotExists(ValidationPageObjects.unBlindedProduct);
				if (blindProd.equalsIgnoreCase(getTestDataCellValue(scenarioName,
						"Products_ProductInformation_ProductDescription_ProductName"))) {
					Reports.ExtentReportLog("", Status.PASS, "Validation Exists for " + blindProd + ": Blinded Product"
							+ "- " + result + ":" + "Verified Successfully", true);

				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Validation not Exists for " + blindProd
							+ ":Blinded Product" + "- " + result + ":" + "Verified Successfully", true);
				}

			}

			else if (result.equalsIgnoreCase("#1:V0112")) {
				agClick(ValidationPageObjects.columnHeaderList(Integer.toString(i + 1)));

				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
				agAssertNotExists(ValidationPageObjects.unBlindedProduct);
				if (blindProd.equalsIgnoreCase(getTestDataCellValue(scenarioName,
						"Products_ProductInformation_ProductDescription_ProductName"))) {
					Reports.ExtentReportLog("", Status.PASS, "Validation Exists for " + blindProd + ": Blinded Product"
							+ "- " + result + ":" + "Verified Successfully", true);

				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Validation not Exists for " + blindProd
							+ ":Blinded Product" + "- " + result + ":" + "Verified Successfully", true);
				}

			}

			else if (result.equalsIgnoreCase("#1:ISP-V0054")) {
				agClick(ValidationPageObjects.columnHeaderList(Integer.toString(i + 1)));

				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
				agAssertNotExists(ValidationPageObjects.unBlindedProduct);
				if (blindProd.equalsIgnoreCase(getTestDataCellValue(scenarioName,
						"Products_ProductInformation_ProductDescription_ProductName"))) {
					Reports.ExtentReportLog("", Status.PASS, "Validation Exists for " + blindProd + ": Blinded Product"
							+ "- " + result + ":" + "Verified Successfully", true);

				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Validation not Exists for " + blindProd
							+ ":Blinded Product" + "- " + result + ":" + "Verified Successfully", true);
				}

			}

			else if (result.equalsIgnoreCase("#1:V0111")) {
				agClick(ValidationPageObjects.columnHeaderList(Integer.toString(i + 1)));
				agAssertNotExists(ValidationPageObjects.unBlindedProduct);
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
				if (blindProd.equalsIgnoreCase(getTestDataCellValue(scenarioName,
						"Products_ProductInformation_ProductDescription_ProductName"))) {
					Reports.ExtentReportLog("", Status.PASS, "Validation Exists for " + blindProd + ": Blinded Product"
							+ "- " + result + ":" + "Verified Successfully", true);

				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Validation not Exists for " + blindProd
							+ ":Blinded Product" + "- " + result + ":" + "Verified Successfully", true);
				}

			}

			else if (result.equalsIgnoreCase("#1:ISP-V0044")) {
				agClick(ValidationPageObjects.columnHeaderList(Integer.toString(i + 1)));

				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
				agAssertNotExists(ValidationPageObjects.unBlindedProduct);
				if (blindProd.equalsIgnoreCase(getTestDataCellValue(scenarioName,
						"Products_ProductInformation_ProductDescription_ProductName"))) {
					Reports.ExtentReportLog("", Status.PASS, "Validation Exists for " + blindProd + ": Blinded Product"
							+ "- " + result + ":" + "Verified Successfully", true);

				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Validation not Exists", true);
				}

			}

		}

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to split value till colon(: Second
	 *             colon) and get the rule name number with #Sequence number
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 04-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getValidationNumber(String validationMessage) {
		String value = null;
		String num[] = validationMessage.split(": ");
		System.out.println(num[0]);
		value = num[0].trim();
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to get the unblind product
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 04-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getUnBlindProduct() {
		String unBlindProduct = agGetText(ValidationPageObjects.unBlindedProduct);
		String unBlind[] = unBlindProduct.split("1. ");
		System.out.println(unBlind[1]);
		String unBlindProd = unBlind[1].trim();
		return unBlindProd;
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to get the blind product
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 04-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getBlindProduct() {
		if (agIsVisible(FDE_ProductsPageObjects.unBlinded_link) == true) {
			FDE_Products.product_Link("BlindingUnBlinding", "BlindedProduct_1");
			agSetStepExecutionDelay("2000");
		}
		String blindProduct = agGetText(ValidationPageObjects.blindedProduct);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		String blind[] = blindProduct.split("1. ");
		System.out.println(blind[1]);
		String blindProd = blind[1].trim();
		return blindProd;
	}
	
	/**********************************************************************************************************
	 * @Objective: This method is used to verify whether case landed in given activity
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS 
	 * @Date : 04-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void processedActivityVerification(String Activity) {
		String currentActiviy;
		if(agIsVisible(CaseListingPageObjects.hirchyCurrentActivity)) {
			String[] data = agGetText(CaseListingPageObjects.hirchyCurrentActivity).replace(".", "##").split("##");
			currentActiviy=data[1].trim();
		}else {
			currentActiviy=agGetText(CaseListingPageObjects.caseCurrentActivity);
		}
		if(Activity.equalsIgnoreCase(currentActiviy)) {
			Reports.ExtentReportLog("", Status.PASS,
					"case landed in -" + currentActiviy, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"case landed in-" + currentActiviy, true);
		}
	}
	/**********************************************************************************************************
	 * @Objective: This method is used to Process workflow activity
	 * 	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS 
	 * @Date : 04-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void CompleteWfActivities(String scenarioName, String sheet, String RctSceario) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "WorkflowControl");
	
		String[] ActualCurrentAct = Multimaplibraries.getTestDataCellValue(scenarioName, "CurentActivity").split(",");
		String[] ProcessingAct = Multimaplibraries.getTestDataCellValue(scenarioName, "ProcessingActivity").split(",");
		
		for (int actnum = 0; actnum < ProcessingAct.length; actnum++) {
			
			Validations.completeWorkFlowActivity(ActualCurrentAct[actnum]+","+ProcessingAct[actnum]);
			
			if(FDE_CaseValidations.validationExists()) {
				
			FDE_CaseValidations.verifyValidations(scenarioName, "WorkflowControl");
			Reports.ExtentReportLog("", Status.INFO,
					"Case is in Activity: " + ActualCurrentAct[actnum], true);
			String ValidationSupressionScenario = scenarioName+"##"+ActualCurrentAct[actnum]+","+ProcessingAct[actnum];
			FDE_CaseValidations.validationsSupressionDriver(ValidationSupressionScenario);
			
			CaseListingOperations.searchCase_Edit(RctSceario, sheet, "ReceiptNo");
			
			System.out.println("[actnum+1] "+(actnum+1));
			System.out.println("ActualCurrentAct[actnum+1] "+ActualCurrentAct[actnum+1]);
			processedActivityVerification(ActualCurrentAct[actnum+1]);	
			/*Reports.ExtentReportLog("", Status.INFO,
					"Case processed to Activity: " + ActualCurrentAct[actnum+1], true);*/
		}else {
			
			if(!ActualCurrentAct[actnum+1].equalsIgnoreCase("Delete")) {
			CaseListingOperations.searchCase_Edit(RctSceario, sheet, "ReceiptNo");
			processedActivityVerification(ActualCurrentAct[actnum+1]);
			}
			/*Reports.ExtentReportLog("", Status.INFO,
					"Case processed to Activity1: " + ActualCurrentAct[actnum+1], true);*/
		}
	}
}		
	/**********************************************************************************************************
	 * @Objective: The below method is created to move case from one activity to
	 *             next activity
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi Krishna RS
	 * @Date : 14-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void completeWorkFlowActivity(String activityName) {
		boolean flag = true;
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
		agWaitTillVisibilityOfElement(CaseListingPageObjects.caseActHeader);
		String currentActiviy = "";
		if (agIsVisible(CaseListingPageObjects.hirchyCurrentActivity)) {
			String[] data = agGetText(CaseListingPageObjects.hirchyCurrentActivity).replace(".", "##").split("##");
			System.out.println(data[1].trim() + "**Data");
			currentActiviy = data[1].trim();
		} else {
			currentActiviy = agGetText(CaseListingPageObjects.caseCurrentActivity);
		}

		String WorkFlowheader = agGetText(CaseListingPageObjects.caseActHeader);
		Constants.highlightObjects = false;
		CommonOperations.takeScreenShot();

		flag = false;
		String[] Activity = activityName.split(",");
		String ActualCurrentAct = Activity[0];
		String ProcessingAct = Activity[1];
		if (currentActiviy.equalsIgnoreCase(ActualCurrentAct)) {
			CommonOperations.setActivity(ProcessingAct);
			flag = true;
			Reports.ExtentReportLog("", Status.PASS, "<br />"+"Case is in :- "+ currentActiviy+" ", false);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "<br />"+"Case is in :-" + currentActiviy+" Activity"
					+ " But it suppose to be in " + ActualCurrentAct+" Activity", true);
		}

		 agMouseHover(FullDataEntryFormPageObjects.actions_Btn);
		// agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.completeActivity_link);
		if (flag) {
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.completeActivity_link);

			Constants.highlightObjects = true;
			agSetStepExecutionDelay("5000");
			agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
			try {
				Thread.sleep(30000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			agSetStepExecutionDelay("5000");
			if (agIsExists(ValidationPageObjects.validationsList)) {
				validationExists = true;
				Reports.ExtentReportLog("", Status.PASS, "<br />"+"Action Un completed with Validation Errors", true);

				if (agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully)) {
					// System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
					Reports.ExtentReportLog("", Status.PASS, "<br />"+"Action completed without Validation Errors", true);
					agClick(FullDataEntryFormPageObjects.ActionOkBtn);
				}
			} else if (agIsVisible(FullDataEntryFormPageObjects.completeAct_WarningLabel)) {
				validationExists = false;
				agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.warning_YesBtn);
				Reports.ExtentReportLog("", Status.PASS, "Action completed with Validation Errors", true);
				agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.ActionOkBtn);
				agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.actComp_Sucessfully);

			} else if (agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully)) {
				validationExists = false;
				// System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
				Reports.ExtentReportLog("", Status.PASS, "<br />"+"Action completed without Validation Errors", true);
				agClick(FullDataEntryFormPageObjects.ActionOkBtn);
			} else if (agIsVisible(FullDataEntryFormPageObjects.ActionOkBtn)) {
				validationExists = false;
				// System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
				Reports.ExtentReportLog("", Status.PASS, "<br />"+"Action completed wit Validation Errors", true);
				agClick(FullDataEntryFormPageObjects.ActionOkBtn);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agSetStepExecutionDelay("10000");
			if (agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully)) {
				validationExists = false;
				// System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
				Reports.ExtentReportLog("", Status.PASS, "<br />"+"Action completed without Validation Errors", true);
				agClick(FullDataEntryFormPageObjects.ActionOkBtn);
			}
			if (activityName.equalsIgnoreCase("Exit")) {
				agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
				System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				Reports.ExtentReportLog("", Status.PASS, "<br />"+"Case saved", true);
				agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		Constants.highlightObjects = true;
	}	
	
}