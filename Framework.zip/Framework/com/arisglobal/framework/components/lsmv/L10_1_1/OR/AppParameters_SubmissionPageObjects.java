package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class AppParameters_SubmissionPageObjects {

	////////////////////////// Administration >> System Administration >>
	////////////////////////// Application Parameters >> Submission
	////////////////////////// /////////////////////////////
	/////////////////////////////////////////// Submission >> Advanced Search Field
	////////////////////////// ////////////////////////////////////////////////////////

	public static String advancedSearchField_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Advanced Search Field']";
	public static String advancedSearchField_Button = "xpath#//div[@id = 'applicationParameterForm:picklistDuplicateSearchFieldS2']/descendant::button[@title = '%option%']";
	public static String advancedSearchField_List = "xpath#//div[@id = 'applicationParameterForm:picklistDuplicateSearchFieldS2']/descendant::ul[contains(@class, 'picklist-source')]/li[text() = '%value%']";
	public static String advancedSearchFieldSelected_List = "xpath#(//div[@id = 'applicationParameterForm:picklistDuplicateSearchFieldS2']//ul)[2]//li";
	/////////////////////////////////////////// Submission >> Out-Of-Workflow
	/////////////////////////////////////////// Advance Search Fields
	/////////////////////////////////////////// ////////////////////////////////////////////////////////

	public static String outOfWorkflowAdvanceSearchFields_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Out-Of-Workflow Advance Search Fields']";
	public static String outOfWorkflowAdvanceSearchFields_Button = "xpath#//div[@id = 'applicationParameterForm:picklistDuplicateSearchFieldS4']/descendant::button[@title = '%option%']";
	public static String outOfWorkflowAdvanceSearchFields_List = "xpath#//div[@id = 'applicationParameterForm:picklistDuplicateSearchFieldS4']/descendant::ul[contains(@class, 'picklist-source')]/li[text() = '%value%']";
	public static String outOfWorkflowAdvanceSearchFieldsSelected_List = "xpath#(//div[@id = 'applicationParameterForm:submissionArchiveAdvancedSearchFieldPanel_content']//ul)[2]//li";
	/////////////////////////////////////////// Submission >> Submission Reports
	/////////////////////////////////////////// Search Fields
	/////////////////////////////////////////// ////////////////////////////////////////////////////////

	public static String submissionReportsSearchFields_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Submission Reports Search Fields']";
	public static String submissionReportsSearchFields_Button = "xpath#//div[@id = 'applicationParameterForm:picklistDuplicateSearchFieldS3']/descendant::button[@title = '%option%']";
	public static String submissionReportsSearchFields_List = "xpath#//div[@id = 'applicationParameterForm:picklistDuplicateSearchFieldS3']/descendant::ul[contains(@class, 'picklist-source')]/li[text() = '%value%']";
	public static String submissionReportsSearchFieldsSelected_List = "xpath#(//div[@id = 'applicationParameterForm:submissionReportsSearchFieldPanel_content']//ul)[2]//li";
	/////////////////////////////////////////// Submission >> Informed Authority
	/////////////////////////////////////////// Fields
	/////////////////////////////////////////// ///////////////////////////////////////////////////////////////

	public static String informedAuthorityFields_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Informed Authority Fields']";
	public static String editDecisionDate_CheckBox = "Edit Decision Date";
	public static String editDateInformedToDistributor_CheckBox = "Edit Date Informed To Distributor";
	public static String editDateofReport_CheckBox = "Edit Date of Report";
	public static String editRespondDate_CheckBox = "Edit Respond Date";
	public static String editReportMedium_CheckBox = "Edit Report Medium";
	public static String editReportType_CheckBox = "Edit Report Type";

	/////////////////////////////////////////// Submission >> Submission
	/////////////////////////////////////////// Out-Of-Workflow
	/////////////////////////////////////////// ///////////////////////////////////////////////////////////////

	public static String submissionOutOfWorkflow_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Submission Out-Of-Workflow']";
	public static String outOfWorkflowFailedSubmissions_CheckBox = "Out-Of-Workflow Failed Submissions";
	public static String outOfWorkflowSubmissionsOlderThan_TextBox = "xpath#//input[@id ='applicationParameterForm:archiveSubmissionsOlderThan']";
	public static String outOfWorkflowSubmissionsOlderThanUnit_DropDown = "xpath#//div[@id='applicationParameterForm:D-506']//label";
	public static String outOfWorkflowSubmissionsOlderThanUnit_DropDownValue = "xpath#//div[@id='applicationParameterForm:D-506_2']//label";
	public static String yearRangeToDisplayOutOfWorkflowData_DropDown = "xpath#//div[@id='applicationParameterForm:yearsArchiveData']//label";
	public static String maximumPackageSizeKB_TextBox = "xpath#//input[@id ='applicationParameterForm:maxPackageSize']";
	public static String convertSubmissionSupportDocumentintoPDF_CheckBox = "Convert Submission Support Document(s) into PDF";
	public static String submittingUnitAccess_DropDown = "xpath#//div[@id='applicationParameterForm:submissionContactGrpAndRole']//label";
	public static String maximumNumberOfCasesForAssigning_TextBox = "xpath#//input[@id ='applicationParameterForm:noOfCasesForAssig']";
	public static String temporaryFilePathforEmailScheduler_TextBox = "xpath#//input[@id ='applicationParameterForm:temporaryFilePathForEmailScheduler']";
	public static String retryCountForFailureEmailSubmission_TextBox = "xpath#//input[@id ='applicationParameterForm:emailRetryCount']";
	public static String allowLabelingOnlyForSuspectProducts_CheckBox = "Allow Labeling Only For Suspect Products";
	public static String sendAlertEmailifMDNnotReceivedBy_TextBox = "xpath#//input[@id ='applicationParameterForm:mdnLblId']";
	public static String sendAlertEmailifMDNnotReceivedByUnit_DropDown = "xpath#//select[@id='applicationParameterForm:mdnScanFreqId']";
	public static String sendAlertEmailforAcknowledgementNotReceivedbydays_List = "xpath#//label[text()= 'Send alert email for acknowledgement not received by(days) ']/ancestor::tr/descendant::li[text() = '%value%']";
	public static String sendAlertEmailforCaseApproachingDueDateforSubmissioninNextdays_List = "xpath#//label[text()= 'Send alert email for case approaching due date for submission in next(days)']/ancestor::tr/descendant::li[text() = '%value%']";
	public static String sendAlertEmailforAcknowledgementNotReceivedDD = "xpath#";

}
