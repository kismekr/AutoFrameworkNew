package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class DuplicateSearchPageObjects {

	public static String duplicateSearch = "xpath#//li/a[contains(text(),'Duplicate Search')]";
	public static String SearchButton = "xpath#//button[@id='dupSearchButton']";
	public static String SearchLoopkup = "xpath#//button[@class='ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only']//span[contains(text(),'Search')]";
	public static String ProductLookUp = "xpath#//div[@id='productId']//a[@class='htmlAdvLookupIcon']//img";
	public static String ProductNameLookUp = "xpath#//label[(text()='Product Name')]/following-sibling::input[@type='text']";
	// public static String
	// ProductRadioBtn="xpath#//div//span[@class='ui-radiobutton-icon
	// ui-clickable']";
	public static String ProductRadioBtn = "xpath#(//div[@role='dialog']//div[@class='ui-table-wrapper ng-star-inserted']//span[@class='ui-radiobutton-icon ui-clickable'])[1]";
	public static String OkBtn = "xpath#//span[contains(text(),'Ok')]";
	public static String PatientID = "xpath#//input[@name='patientId']";
	public static String CountryDropDown = "xpath#//select[@name='reporterCountry']";
	public static String ResetBtn = "xpath#//button[contains(text(),'Reset')]";
	public static String PatientGenderDropDown = "xpath#//select[@name='patientSex']";
	public static String ProductNameasReported = "xpath#//input[@name='reportedMedicinalProduct']";
	public static String PostalCode = "xpath#//input[@name='reporterZipCode']";
	public static String PatientDOB = "xpath#//input[@name='patientDob']";
	public static String ReporterDropDown = "xpath#//select[@name='reportType']";
	public static String PrimarySourceCountryDropDown = "xpath#//select[@name='sourceCountry']";
	public static String PatientAge = "xpath#//input[@name='patientAge']";
	public static String Study = "xpath#//input[@name='study']";
	public static String PatientageDropdown = "xpath#//select[@name='patientAgeUnit']";
	public static String CloseBtn = "xpath#//div[@class='dupHeader']//button[text()='Close']";

	public static String productChaacterzation_Dropdown = "xpath#//select[@class='adv_class_drop_1013 select2-hidden-accessible']";
	public static String getRCTNumberList = "xpath#//table[@id='dupListingTable']//td[@class=' Dupl_table_receiptNo']";
	public static String getRCTNumber = "xpath#(//table[@id='dupListingTable']//td[@class=' Dupl_table_receiptNo'])[%count%]";

	// General Details
	public static String authorityNum = "xpath#//input[@name='authorityNo']";
	public static String LRDFromRecvDate = "xpath#//input[@name='contactFromDateReceived']";
	public static String LRDToRecvDate = "xpath#//input[@name='contactToDateReceived']";
	public static String safetyReportID = "xpath#//input[@name='safetyReportId']";
	public static String primarySourceCountry_Dropdown = "xpath#//select[@name='sourceCountry']";
	public static String reportType_Dropdown = "xpath#//select[@name='reportType']";
	public static String countryDetection_Dropdown = "xpath#//select[@name='caseCountry']";

	// Event Details
	public static String onsetDate = "xpath#//input[@name='aeOnsetDate']";
	public static String reportedTerm = "xpath#//input[@name='reportedTerm']";

	// Literature Details
	public static String articleTitle = "xpath#//input[@name='literatureTitle']";
	public static String journalTitle = "xpath#//input[@name='literatureJournalTitle']";
	public static String literatureRef = "xpath#//input[@name='literatureReference']";

	// Patient Details
	public static String patientDOB = "xpath#//input[@name='patientDob']";
	public static String gender_dropDown = "xpath#//select[@name='patientSex']";
	public static String patientAgeUnit_Dropdown = "xpath#//select[@name='patientAgeUnit']";
	public static String ageTimeEvent = "xpath#//input[@name='patientAge']";
	public static String patientID = "xpath#//input[@name='patientId']";
	public static String hospitalRecordNo = "xpath#//input[@name='patHospitalRecNo']";
	public static String GPrecordNo = "xpath#//input[@name='patRecordNumber']";

	// Source Details
	public static String referenceType_Dropdown = "xpath#//select[@name='referenceType']";
	public static String referenceNum = "xpath#//input[@name='otherReferenceNum']";

	// Study Details
	public static String ProtocolNoLookup = "xpath#//label[text()='Protocol No']/parent::div//a[@class='htmlAdvLookupIcon']//img";
	public static String ProtocolSearchIcon = "xpath#//button[@class='agOnEnterSearch ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only']//span[text()='Search']";
	public static String sponsorStudyNo = "xpath#//input[@name='study']";
	public static String studyOkBtn = "xpath#(//span[contains(text(),'OK')])[2]";
	public static String centerNo = "xpath#//input[@name='siteno']";
	public static String subjectID = "xpath#//input[@name='subjectId']";

	// Reporter Details
	public static String firstName = "xpath#//input[@name='contactFirstname']";
	public static String LastName = "xpath#//input[@name='contactLastName']";
	public static String state = "xpath#//input[@name='reporterState']";
	public static String postalCode = "xpath#//input[@name='reporterZipCode']";
	public static String country_Dropdown = "xpath#//select[@name='reporterCountry']";

}
