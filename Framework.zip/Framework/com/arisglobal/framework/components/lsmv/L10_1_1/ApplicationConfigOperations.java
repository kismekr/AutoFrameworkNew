package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AdministrationPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ApplicationConfigPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ApplicationConfig_WorkFlowPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ReportparameterPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

import test.expectedexceptions.ParametersExceptionTest;

public class ApplicationConfigOperations extends ToolManager {
	public static WebElement webElement;
	static String className = ApplicationConfigOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in
	 *             Application configurations.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void menuNavigation(String menu) {
		agMouseHover(AdministrationPageObjects.administrationHover);
		agClick(menu);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in
	 *             Administration > Application configurations and verify the label
	 *             name
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void applicationConfigurationsNavigations(String menu) {
		
		switch (menu) {
		case "forms":
			menuNavigation(ApplicationConfigPageObjects.formsLink);
			status = agIsVisible(ApplicationConfigPageObjects.formsKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "Navigation to forms is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to forms is Unsuccessfull", true);
			}
			break;
		case "workFlow":
			menuNavigation(ApplicationConfigPageObjects.workFlowLink);
			status = agIsVisible(ApplicationConfigPageObjects.workFlowKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "Navigation to workFlow is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to workFlow is Unsuccessfull", true);
			}
			break;
		case "ruleBuilder":
			menuNavigation(ApplicationConfigPageObjects.ruleBuilderLink);
			status = agIsVisible(ApplicationConfigPageObjects.ruleBuilderLabel);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
				Reports.ExtentReportLog("", Status.INFO, "Navigation to ruleBuilder is successfull", false);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to ruleBuilder is Unsuccessfull", true);
			}
			break;

		case "scriptedRules":
			menuNavigation(ApplicationConfigPageObjects.scriptedRulesLink);
			status = agIsVisible(ApplicationConfigPageObjects.scriptedKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to scripted Rules is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to scripted Rules is Unsuccessfull", true);
			}
			break;
		case "supplementFields":
			menuNavigation(ApplicationConfigPageObjects.supplementFieldsLink);
			status = agIsVisible(ApplicationConfigPageObjects.supplementFieldsLabel);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to supplement Fields is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to supplement Fields is Unsuccessfull", true);
			}
			break;
		case "duplicateCheckPolicies":
			menuNavigation(ApplicationConfigPageObjects.duplicatecheckpoliciesLink);
			status = agIsVisible(ApplicationConfigPageObjects.duplicatecheckKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to duplicateCheck Policies is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to duplicateCheck Policies is Unsuccessfull",
						true);
			}
			break;
		case "xmlDocConfiguration":
			menuNavigation(ApplicationConfigPageObjects.xmldocConfigurationLink);
			status = agIsVisible(ApplicationConfigPageObjects.xmldocConfigNewButton);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to xmlDoc Configuration is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to xmlDoc Configuration is Unsuccessfull", true);
			}
			break;
		case "importConfiguration":
			menuNavigation(ApplicationConfigPageObjects.importConfigurationLink);
			status = agIsVisible(ApplicationConfigPageObjects.importConfigKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to Import Configuration is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Import Configuration is Unsuccessfull", true);
			}
			break;
		case "reportParameter":
			menuNavigation(ApplicationConfigPageObjects.reportParamaterLink);
			status = agIsVisible(ReportparameterPageObjects.reportTypeHeader);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to Report Parameter is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Report Parameter is Unsuccessfull", true);
			}
			break;
		default:
			System.out.println("Invalid Menu Link!");
		}
		
	}
	
	/**********************************************************************************************************
	 * @Objective: To direct user to specific WorkFlow Edit screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void navigateWorkflowEditScreen(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String workflowName = getTestDataCellValue(scenarioName, "WorkFlowConfigurationName");
		
		agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.workFlowListingBreadCrumb);
		agClick(ApplicationConfig_WorkFlowPageObjects.searchBar_TxtArea);
		agSetValue(ApplicationConfig_WorkFlowPageObjects.searchBar_TxtArea, workflowName);
		agClick(ApplicationConfig_WorkFlowPageObjects.search_Icon);
		agSetStepExecutionDelay("3000");
		agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.paginator);
		if (agGetText(ApplicationConfig_WorkFlowPageObjects.paginator).startsWith("1")&&agGetText(ApplicationConfig_WorkFlowPageObjects.paginator).endsWith("1")) {
			Reports.ExtentReportLog("", Status.PASS, "", true);
			Reports.ExtentReportLog("", Status.INFO, "WorkFlow Config record matching the exact keyed value retrieved successfully", false);
		}
		else {
			Reports.ExtentReportLog("", Status.FAIL, "WorkFlow Config record not retrieved", true);
		}		
		agClick(ApplicationConfig_WorkFlowPageObjects.recordEdit_Icon);

		agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.workFlowListingBreadCrumb);
		Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
	}
	
	/**********************************************************************************************************
	 * @Objective: To ensure Auto Narrative Generation is enabled
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ensureNarrativeGenerationEnabled(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		
		agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.workFlowListingBreadCrumb);
		agClick(ApplicationConfig_WorkFlowPageObjects.searchBar_TxtArea);
		agSetValue(ApplicationConfig_WorkFlowPageObjects.searchBar_TxtArea, getTestDataCellValue(scenarioName, "WorkFlowConfigurationName"));
		agClick(ApplicationConfig_WorkFlowPageObjects.search_Icon);
		agSetStepExecutionDelay("3000");
		agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.paginator);
		if (agGetText(ApplicationConfig_WorkFlowPageObjects.paginator).startsWith("1")&&agGetText(ApplicationConfig_WorkFlowPageObjects.paginator).endsWith("1")) {
			Reports.ExtentReportLog("", Status.PASS, "WorkFlow Config record matching the exact keyed value retrieved successfully", true);
		}
		else {
			Reports.ExtentReportLog("", Status.FAIL, "WorkFlow Config record not retrieved", true);
		}		
		agClick(ApplicationConfig_WorkFlowPageObjects.recordEdit_Icon);
		
		agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.workFlowPageTitleBreadScrumb(getTestDataCellValue(scenarioName, "WorkFlowConfigurationName")));
		agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.configurationMenuItem_Label);
		agClick(ApplicationConfig_WorkFlowPageObjects.configurationMenuItem_Label);
		agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.fullDataEntryActivity_Label);
		agClick(ApplicationConfig_WorkFlowPageObjects.fullDataEntryActivity_Label);
		agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.workFlowTransitionHeader_Label);
		agClick(ApplicationConfig_WorkFlowPageObjects.workFlowTransitionHeader_Label);
		agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.configSubMenuItem_Label);
		agClick(ApplicationConfig_WorkFlowPageObjects.configSubMenuItem_Label);
		agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.configAssessmentType_Label);
		agJavaScriptExecuctorScrollToElement(ApplicationConfig_WorkFlowPageObjects.eventDescCheckBox_Label);
		agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.generateNarrativeHeader_Label);
		CommonOperations.clickCheckBoxLeftOf(ApplicationConfig_WorkFlowPageObjects.generateNarrativeHeader_Label,"true");
		Reports.ExtentReportLog("", Status.PASS, "Auto Narrative Generate option is selected", true);
		
		agClick(ApplicationConfig_WorkFlowPageObjects.save_Btn);
		agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.confirmationWinTitle);
		System.out.println("Acknowledgement after Save: "+agGetText(ApplicationConfig_WorkFlowPageObjects.confirmationWinInfo_Text));
		Reports.ExtentReportLog("", Status.PASS, "Info: "+agGetText(ApplicationConfig_WorkFlowPageObjects.confirmationWinInfo_Text), true);
		agClick(ApplicationConfig_WorkFlowPageObjects.confirmationWinOK_Btn);
	}
	
	/**********************************************************************************************************
	 * @Objective: To ensure Auto Narrative Generation is enabled
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void configureWorkFlow_UpdateValidation(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.workFlowPageTitleBreadScrumb(getTestDataCellValue(scenarioName, "WorkFlowConfigurationName")));
		agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.configurationMenuItem_Label);
		agClick(ApplicationConfig_WorkFlowPageObjects.configurationMenuItem_Label);
		
		
		String str= getTestDataCellValue(scenarioName, "NoActivitiesToUpdate");
		double noOfActivitiesToUpdate = Double.parseDouble(str); 
		int iCount = (int)noOfActivitiesToUpdate;
		
		Reports.ExtentReportLog("", Status.PASS, "As Expected", false);
		for (int i = 1; i <= iCount; i++) {
			agClick(ApplicationConfig_WorkFlowPageObjects
					.selectTransitionActivityNode(getTestDataCellValue(scenarioName, "TransitionName"+i)));
			agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.subMenuHeader_Validations);
			agClick(ApplicationConfig_WorkFlowPageObjects.subMenuHeader_Validations);

			//select Rule Type
			agClick(ApplicationConfig_WorkFlowPageObjects.config_pivotType);
			
			agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.ruleNameHeader_Label);
			
			if (!agIsExists(ApplicationConfig_WorkFlowPageObjects.selectRuleNameLocator
					(getTestDataCellValue(scenarioName, "RuleName")))) {
				//addCompanyPivotRule(scenarioName);
				Reports.ExtentReportLog("", Status.INFO, "Expected Rule is not available by the name, " 
						+ getTestDataCellValue(scenarioName, "RuleName"), true);
				//return;
			}
			
			agJavaScriptExecuctorScrollToElement(ApplicationConfig_WorkFlowPageObjects.selectRuleNameLocator
					(getTestDataCellValue(scenarioName, "RuleName")));
			Reports.ExtentReportLog("", Status.INFO, "Before the changes", true);
			agJavaScriptExecuctorClick(ApplicationConfig_WorkFlowPageObjects.onSaveRadioBtnLable(
					getTestDataCellValue(scenarioName, "RuleName"), getTestDataCellValue(scenarioName, "OnSave"+i)));
			agJavaScriptExecuctorClick(ApplicationConfig_WorkFlowPageObjects.onCompleteRadioBtnLable(
					getTestDataCellValue(scenarioName, "RuleName"),	getTestDataCellValue(scenarioName, "OnCompleteActivity"+i)));
			Reports.ExtentReportLog("", Status.INFO, "Even Types selected value captured", true);
			

			Reports.ExtentReportLog("", Status.PASS, "", true);
			Reports.ExtentReportLog("", Status.PASS, "<br />" + "Activity"+i+ ": "+ getTestDataCellValue(scenarioName, "TransitionName"+i), false);
			Reports.ExtentReportLog("", Status.PASS, "<br />" + "ON Save: " + getTestDataCellValue(scenarioName, "OnSave"+i), false);
			Reports.ExtentReportLog("", Status.PASS, "<br />" + "ON Complete Activity: "+ getTestDataCellValue(scenarioName, "OnCompleteActivity"+i), false);

		}

		//Final Save
		agClick(ApplicationConfig_WorkFlowPageObjects.save_Btn);
		agWaitTillVisibilityOfElement(ApplicationConfig_WorkFlowPageObjects.confirmationWinTitle);
		Reports.ExtentReportLog("", Status.INFO, "Info: "+agGetText(ApplicationConfig_WorkFlowPageObjects.confirmationWinInfo_Text), true);
		Reports.ExtentReportLog("", Status.PASS, "Validation is associated and Saved.", true);
		agClick(ApplicationConfig_WorkFlowPageObjects.confirmationWinOK_Btn);
	}
	

	/**********************************************************************************************************
	 * @Objective: To Create a new Pivot Rule
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: 
	 * @Date : 
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addCompanyPivotRule(String scenarioName) {
		//Code to add new rule to be scripted on demand
	}

}