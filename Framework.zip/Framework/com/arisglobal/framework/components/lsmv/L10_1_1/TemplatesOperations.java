package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.TemplatesPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.SeleniumActions;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class TemplatesOperations extends ToolManager{
	public static WebElement webElement;
	static String className = TemplatesOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;


	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in templates Module
	 * @InputParameters: pageObject
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/		
	public static void menuNavigation(String pageObject) {
		agMouseHover(TemplatesPageObjects.templatesHover);
		agClick(pageObject);
	}


	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in templates Module and verify the label name
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void templatesNavigations(String menu) {

		switch (menu) {
		case "templatesNew":
			menuNavigation(TemplatesPageObjects.templatesNew);
			status = agIsVisible(TemplatesPageObjects.templateID);
			agSetStepExecutionDelay("1000");
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation totemplates New is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Full data entry form is Unsuccessfull", true);
			}
			break;
		case "templatesListing":
			menuNavigation(TemplatesPageObjects.templatesListing);
			status = agIsVisible(TemplatesPageObjects.basicsearchTextbox);
			agSetStepExecutionDelay("1000");
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to templates Listing is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to templates Listing is Unsuccessfull", true);
			}
			break;
		case "templatesNotifications":
			menuNavigation(TemplatesPageObjects.templatesNotification);
			status = agIsVisible(TemplatesPageObjects.NotificationbasicsearchTextbox);
			agSetStepExecutionDelay("1000");
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to templates Notifications is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to templates Notifications is Unsuccessfull", true);
			}
			break;
		default:
			System.out.println("Invalid Menu Link!");
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to Search and edit the Template Name from Listing screen.
	 * @InputParameters: Template Name and Yes or No to Click edit button.
	 * @OutputParameters:
	 * @author: MP Ramkumar
	 * @Date : 19-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	

	public static void searchNeditTemplate(String TemplateName, String editYesNo) {
		List<WebElement> ruleRows=agGetElementList(TemplatesPageObjects.resultCount);
		int rowSize=ruleRows.size();
		int foundRow=0;
		String spanText=null;
		for (int iRow=1;iRow<=rowSize;iRow++) {
			spanText=agGetText(TemplatesPageObjects.TemplateNameRow(iRow));
			if(TemplateName.equalsIgnoreCase(spanText)) {
				foundRow=iRow;
				break;
			}
		}
		if(editYesNo == "Yes") {
			agClick(TemplatesPageObjects.TemplateNameRow(foundRow));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to find and click on Edit button of a template
	 * @InputParameters: Find and Click on Edit button
	 * @OutputParameters:
	 * @author: Kishore
	 * @Date : 03-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	

	public static void editTemplate(String TemplateName) {
		List<WebElement> tempRows = agGetElementList(TemplatesPageObjects.templatesRows);
		int rowSize = tempRows.size();
		int foundRow = 0;

		String spanText = null;
		for (int iRow = 1; iRow <= rowSize; iRow++) {
			spanText = agGetText(TemplatesPageObjects.templateEditName(iRow));
			if (TemplateName.equalsIgnoreCase(spanText)) {
				foundRow = iRow;
				break;
			}
		}
		if(foundRow!= 0) {
			agClick(TemplatesPageObjects.templateEditLink(foundRow));
			Reports.ExtentReportLog("Template Listing", Status.PASS,"Navigation Passed",true);
		}
		else {
			agClick(TemplatesPageObjects.templateEditLink(foundRow));
			Reports.ExtentReportLog("Template Listing", Status.FAIL,"Navigation Failed",true);
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below Method is created to traverse to ANG Template Listing screen
	 * @InputParameters: NA
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 20-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/		
	public static void menuNavigation_ANGListing() {
		if (agIsExists(TemplatesPageObjects.listANG_breadCrumb)) {
			Reports.ExtentReportLog("", Status.INFO,"User is in ANG Listing screen already",true);
		}
		else {
			agMouseHover(TemplatesPageObjects.templatesHover);
			agMouseHover(TemplatesPageObjects.templatesANGHover);
			agClick(TemplatesPageObjects.templatesANGListingHover);
			Reports.ExtentReportLog("", Status.INFO,"User Directed to ANG Listing screen",true);
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below Method is created to traverse to ANG Template Listing screen
	 * @InputParameters: NA
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 23-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/		
	public static void template_AddNewStatement(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		
		agWaitTillVisibilityOfElement(TemplatesPageObjects.listANG_breadCrumb);
		Boolean isTemplateAvailable =  agIsExists(TemplatesPageObjects.labelANGTemplate_Locator
				(getTestDataCellValue(scenarioName, "TemplateName")));
		System.out.println(TemplatesPageObjects.labelANGTemplate_Locator
				(getTestDataCellValue(scenarioName, "TemplateName")));
		if (isTemplateAvailable) {
			agClick(TemplatesPageObjects.editANGTemplate_Locator(getTestDataCellValue(scenarioName, "TemplateName")));
			
			agWaitTillVisibilityOfElement(TemplatesPageObjects.treeNodeParagraphName_TextArea);
			agMouseHover(TemplatesPageObjects.treeNodeGeneral);
			
			//performing right-click operation
			WebElement element = null;
			try {
				if (TemplatesPageObjects.treeNodeGeneral.indexOf("#//") > 0 || TemplatesPageObjects.treeNodeGeneral.indexOf("#(//") > 0) {
					Actions actions = new Actions(driver);
					element = SeleniumActions.findElement(Constants.driver, TemplatesPageObjects.treeNodeGeneral);
					actions.contextClick(element).perform();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			agClick(TemplatesPageObjects.insertNewNode);
			agSetStepExecutionDelay("3000");
			agWaitTillVisibilityOfElement(TemplatesPageObjects.newTreeNode);
			agJavaScriptExecuctorScrollToElement(TemplatesPageObjects.newTreeNode);
						
			//performing right-click operation
			WebElement element2 = null;
			try {
				if (TemplatesPageObjects.newTreeNode.indexOf("#//") > 0 || TemplatesPageObjects.newTreeNode.indexOf("#(//") > 0) {
					Actions actions = new Actions(driver);
					element2 = SeleniumActions.findElement(Constants.driver, TemplatesPageObjects.newTreeNode);
					actions.contextClick(element2).perform();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			agClick(TemplatesPageObjects.insertNewNode);
			agSetStepExecutionDelay("3000");
			agWaitTillVisibilityOfElement(TemplatesPageObjects.newTreeNode_Sentence);
			agJavaScriptExecuctorScrollToElement(TemplatesPageObjects.newTreeNode_Sentence);
			agClick(TemplatesPageObjects.newTreeNode_Sentence);
			
			//newTreeNode_Sentence
			agSetValue(TemplatesPageObjects.treeNodeParagraph_TextArea, getTestDataCellValue(scenarioName, "NewSentence"));
			Reports.ExtentReportLog("", Status.INFO, "Data Keyed on New Template",true);
			
			//Folder Name
			agClick(TemplatesPageObjects.newTreeNode);			
			agSetValue(TemplatesPageObjects.treeNodeParagraphName_TextArea, getTestDataCellValue(scenarioName, "ParagraphName"));
			
			agClick(TemplatesPageObjects.save_Btn);
			
			agWaitTillVisibilityOfElement(TemplatesPageObjects.acknowledgementWin_Title);
			Reports.ExtentReportLog("", Status.INFO, agGetText(TemplatesPageObjects.acknowledgementWin_InfoText),true);
			agClick(TemplatesPageObjects.acknowledgementWin_OKBtn);
			
		}
		else {
			Reports.ExtentReportLog("Template Listing", Status.FAIL,"Expected Template record is not avaialbel by the name, "
									+getTestDataCellValue(scenarioName, "TemplateName"),true);
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below Method is created to traverse to ANG Template Listing screen
	 * @InputParameters: NA
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 23-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/		
	public static void template_DeleteStatement(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		
		agWaitTillVisibilityOfElement(TemplatesPageObjects.listANG_breadCrumb);
		Boolean isTemplateAvailable =  agIsExists(TemplatesPageObjects.labelANGTemplate_Locator
				(getTestDataCellValue(scenarioName, "TemplateName")));
		if (isTemplateAvailable) {
			agClick(TemplatesPageObjects.editANGTemplate_Locator(getTestDataCellValue(scenarioName, "TemplateName")));
			agWaitTillVisibilityOfElement(TemplatesPageObjects.treeNodeParagraphName_TextArea);
			agMouseHover(TemplatesPageObjects.treeNodeGeneral);
			
			//to expand General Tree Node
			agClick(TemplatesPageObjects.expandAll_Btn);
			agSetStepExecutionDelay("5000");
			agJavaScriptExecuctorScrollToElement(TemplatesPageObjects.customParagraphNode(getTestDataCellValue(scenarioName, "ParagraphName")));
			
			//performing right-click operation
			WebElement element = null;
			try {
				if (TemplatesPageObjects.customParagraphNode(getTestDataCellValue(scenarioName, "ParagraphName")).indexOf("#//") > 0 
						|| TemplatesPageObjects.customParagraphNode(getTestDataCellValue(scenarioName, "ParagraphName")).indexOf("#(//") > 0) {
					Actions actions = new Actions(driver);
					element = SeleniumActions.findElement(Constants.driver, TemplatesPageObjects.customParagraphNode(getTestDataCellValue(scenarioName, "ParagraphName")));
					actions.contextClick(element).perform();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			Reports.ExtentReportLog("", Status.INFO, "Deleting",true);
			agClick(TemplatesPageObjects.deleteNode);
			Reports.ExtentReportLog("", Status.INFO, "Node Deleted Successfully",true);
			agSetStepExecutionDelay("3000");
			agClick(TemplatesPageObjects.save_Btn);
			
			agWaitTillVisibilityOfElement(TemplatesPageObjects.acknowledgementWin_Title);
			Reports.ExtentReportLog("", Status.PASS, agGetText(TemplatesPageObjects.acknowledgementWin_InfoText),true);
			agClick(TemplatesPageObjects.acknowledgementWin_OKBtn);
		}
	}

}