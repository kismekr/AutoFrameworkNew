package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class AppParameters_CaseManagementPageObjects {

	////////////////////////// Administration >> System Administration >>
	////////////////////////// Application Parameters >> Case Management
	////////////////////////// /////////////////////////////////
	/////////////////////////////////////////// Case Management >> Receipt Numbering
	////////////////////////// Format
	////////////////////////// ///////////////////////////////////////////////////////

	public static String receiptPrefix_TextBox = "xpath#//input[@id ='applicationParameterForm:receiptNumberingFormatId']";
	public static String receiptDateFormat_DropDown = "xpath#//div[@id='applicationParameterForm:I-5009']//label";
	public static String receiptSeparator_DropDown = "xpath#//div[@id='applicationParameterForm:dateSep']//label";
	public static String receiptResetSequenceBy_DropDown = "xpath#//div[@id='applicationParameterForm:resetSequenceByMenu']//label";
	public static String receiptPadding_DropDown = "xpath#//div[@id='applicationParameterForm:rctPaddingId']//label";
	public static String receiptFormatScripts_DropDown = "xpath#//div[@id='applicationParameterForm:lsmvRctScriptDropdown']//label";

	/////////////////////////////////////////// Case Management >> LRN Numbering
	/////////////////////////////////////////// Format
	/////////////////////////////////////////// ///////////////////////////////////////////////////////

	public static String lrnNumberingFormat_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'LRN Numbering Format']";
	public static String lrnPrefix_TextBox = "xpath#//input[@id ='applicationParameterForm:lrnNumberingFormatId']";
	public static String lrnDateFormat_DropDown = "xpath#//div[@id='applicationParameterForm:I1-5009']//label";
	public static String lrnDateFormatSequence_DropDown = "xpath#//div[@id='applicationParameterForm:lrnDateSequenceId']//label";
	public static String lrnCountry_CheckBox = "Country";
	public static String lrnCountrySequence_DropDown = "xpath#//div[@id='applicationParameterForm:lrnCountrySequenceID']//label";
	public static String lrnReportType_CheckBox = "Report Type";
	public static String lrnReportTypeSequence_DropDown = "xpath#//div[@id='applicationParameterForm:lrnReportTypeSequenceID']//label";
	public static String lrnSeparator_DropDown = "xpath#//div[@id='applicationParameterForm:dateSep1']";
	public static String lrnResetSequenceBy_DropDown = "xpath#//div[@id='applicationParameterForm:resetSequenceByMenu1']//label";
	public static String lrnPadding_DropDown = "xpath#//div[@id='applicationParameterForm:lrnPaddingId']//label";

	/////////////////////////////////////////// Case Management >> AER Numbering
	/////////////////////////////////////////// Format
	/////////////////////////////////////////// ///////////////////////////////////////////////////////

	public static String aerNumberingFormat_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'AER Numbering Format']";
	public static String aerPrefix_TextBox = "xpath#//input[@id ='applicationParameterForm:navaPrefix1']";
	public static String aerPrefixSequence_DropDown = "xpath#//div[@id='applicationParameterForm:aerSequenceID']//label";
	public static String aerDateFormat_DropDown = "xpath#//div[@id='applicationParameterForm:navadateFormat1']//label";
	public static String aerDateFormatSequence_DropDown = "xpath#//div[@id='applicationParameterForm:dateSequenceID']//label";
	public static String aerCountry_CheckBox = "Country";
	public static String aerCountrySequence_DropDown = "xpath#//div[@id='applicationParameterForm:countrySequenceID']//label";
	public static String aerReportType_CheckBox = "Report Type";
	public static String aerReportTypeSequence_DropDown = "xpath#//div[@id='applicationParameterForm:reportTypeSequenceID']//label";
	public static String aerSeparator_DropDown = "xpath#//div[@id='applicationParameterForm:navaSepartaion1']//label";
	public static String aerResetSequenceBy_DropDown = "xpath#//div[@id='applicationParameterForm:c1nava1']//label";
	public static String aerStartAERVersionNoFrom_TextBox = "xpath#//input[@id ='applicationParameterForm:startAerVerNoFrom']";
	public static String aerPadding_DropDown = "xpath#//div[@id='applicationParameterForm:aerPaddingId']//label";
	public static String aerFormatScripts_DropDown = "xpath#//div[@id='applicationParameterForm:lsmvAerScriptDropdown']//label";

	/////////////////////////////////////////// Case Management >> Case Management
	/////////////////////////////////////////// /////////////////////////////////////////////////////////

	public static String caseManagement_Label = "xpath#//div[@id = 'applicationParameterForm:aePanel_header']/descendant::label[text() = 'Case Management']";
	public static String maxNOofCasesDayUser_TextBox = "xpath#//input[@id ='applicationParameterForm:maxNumberOfCasesOpenedId']";
	public static String archiveSafetyCasesOlderThan_TextBox = "xpath#//input[@id ='applicationParameterForm:archiveCasesOlderThanId']";
	public static String archiveSafetyCasesOlderThan_DropDown = "xpath#//div[@id='applicationParameterForm:D-5064']//label";
	public static String maxNumberOfRecordsAdvancedFlexibleSearch_TextBox = "xpath#//input[@id ='applicationParameterForm:maxNoOfRecordsForSearchId']";
	public static String icsrLocalMessageNumberSchema_TextBox = "xpath#//input[@id ='applicationParameterForm:icsr_localmessagenumb']";
	public static String sequenceLength_TextBox = "xpath#//input[@id ='applicationParameterForm:icsr_localseq']";
	public static String noOfCasestoCopy_TextBox = "xpath#//input[@id ='applicationParameterForm:noOfCopiesId_input']";

	public static String notifyARISgWhenFollowupCaseIsDisposed_CheckBox = "Notify ARISg when  a follow up case is being Disposed";
	public static String displayReporterContactFirstandLastNameDuplicateSearch_CheckBox = "Display Reporter/Contact First and Last name in Duplicate Search";
	public static String autoDispositionOfE2BCases_CheckBox = "Auto Disposition of E2B cases";
	public static String includeAllAERVersionsfromARISg_CheckBox = "Include All AER versions from ARISg";
	public static String migrateCorrespondenceRecordstoCCM_CheckBox = "Migrate Correspondence Records to CCM";
	public static String dontsendAECaseSummarySheettoArisg_CheckBox = "Don";
	public static String displayAECaseTagging_CheckBox = "Display AE CaseTagging";
	public static String displayAESuggestedFAQs_CheckBox = "Display AE Suggested FAQ";
	public static String includeCasesFromallWorkflowinLookup_CheckBox = "Include Cases from all Workflow in Lookup";
	public static String includeCasesFromAllWorkflowDuplicateSearch_CheckBox = "Include Cases from all Workflow in Duplicate Search";
	public static String alwaysShowTwoPanelCaseformLayout_CheckBox = "Always Show two panel Case form layout";
	public static String enableAutoRanking_CheckBox = "Enable Auto Ranking";
	public static String performNLPOnE2BImport_CheckBox = "Perform NLP on E2B Import";
	public static String enableANGEdit_CheckBox = "Enable ANG";
	public static String disableManualANGEdit_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Disable Manual ANG Edit']";
	public static String disableManualANGEdit_CheckBox = "Disable Manual ANG Edit";
	public static String displayWorkflowStatusTree_CheckBox = "Display Workflow Status Tree";
	public static String enableContactCaseReporter_CheckBox = "Enable Contact CaseReporter";
	public static String enableSubmissionTracking_CheckBox = "Enable Submission Tracking";
	public static String allowManualSelectionofIMEDME_CheckBox = "IME/DME";
	public static String allowAccesstoEnableSUSAR_CheckBox = "SUSAR";
	public static String allowManualSelectionOfAssessRelationship_CheckBox = "Assess Relationship";
	public static String allowManualSelectionofAESI_CheckBox = "AESI";
	public static String allowManualSelectionofMedicallyConfirmed_CheckBox = "Medically Confirmed";
	public static String allowManualSelectionofIsAlwaysSeriousEvent_CheckBox = "Always Serious Event";
	public static String allowManualSelectionofCaseSignificance_CheckBox = "Case Significance";
	public static String enableTypeAheadForAutosuggestionFullDataEntryForm_CheckBox = "Enable Type Ahead For Autosuggestion in Full Data Entry Form";
	public static String alertOnCaseAssignment_CheckBox = "Alert on Case Assignment";
	public static String createContactfromEmailInbound_CheckBox = "Create Contact from Email Inbound";
	public static String allowPPDLevelCoding_CheckBox = "Allow PPD Level Coding";
	public static String enableAgeGroup_CheckBox = "Age Group";
	public static String enableAutopsyDone_CheckBox = "Autopsy Done";
	
	public static String enableExemptedEvents_CheckBox = "Exempted Events";
	public static String enableAnticipatedEvents_CheckBox = "Anticipated Events";
	public static String enableEventMedicallyConfirmed_CheckBox = "Event Medically Confirmed";
		
	public static String enableFollowUpQeriesCaptcha_CheckBox = "Enable Follow-up queries Captcha";
	public static String percentageOfSDDforCDD_TextBox = "xpath#//input[@id ='applicationParameterForm:sddpercentageforCDD']";
	public static String displaySupplementFieldsLike_Radio = "Display Supplement Fields Like";
	public static String defaultValuesforEventSeriousnessCriteria_Radio = "Default Values for Event Seriousness Criteria";
	public static String watermarkTextforReports_TextBox = "xpath#//input[@id ='applicationParameterForm:waterMarkTextForReportd']";
	public static String defaultDueDateforSWM_Radio = "Default Due Date for SWM";
	public static String closeCorrespondenceInDays_TextBox = "xpath#//input[@id ='applicationParameterForm:corresClosDays']";
	public static String EnableManulFlag="xpath#//label[text()='Enable Manual Flag']";
	public static String enableAESICheckBox="xpath#//div[@id='applicationParameterForm:enableAESI']//span";
	public static String enableAccessRelationshipCheckBox="xpath#//div[@id='applicationParameterForm:enableCausalityAccessRelation']//span";
	public static String enableSUSARCheckBox="xpath#//div[@id='applicationParameterForm:enableSusar']//span";
	public static String enableIMECheckBox="xpath#//div[@id='applicationParameterForm:enableIMEDME']//span";
	
	/////////////////////////////////////////// Case Management >> Labeling
	/////////////////////////////////////////// /////////////////////////////////////////////////////////

	public static String labeling_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Labeling']";
	public static String autoProductLabeling_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Auto Product Labeling']";
	public static String defaultDueDate_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Default Due Date for SWM']";
	public static String autoProductLabeling_CheckBox = "Auto Product Labeling";
	public static String defaultLabeling_Radio = "Default Labeling";
	public static String AutoLabellingRadio = "Default Labeling for Datasheet";
	
	public static String CoreLabellingrecordCheckedClinical="xpath#//div[@id='applicationParameterForm:defaultCOREClinical']//span[contains(@class,'check')]";
	public static String CoreLabellingrecordclinical="xpath#//div[@id='applicationParameterForm:defaultCOREClinical']//span";
	public static String IBLabellingrecordCheckedclinical="xpath#//div[@id='applicationParameterForm:defaultCOREClinical']//span[contains(@class,'check')]";
	public static String IBLabellingrecordclinical="xpath#//div[@id='applicationParameterForm:defaultCOREClinical']//span[contains(@class,'check')]";
	public static String CoreLabellingrecordCheckedPostMarket="xpath#//div[@id='applicationParameterForm:defaultCORESpontanious']//span[contains(@class,'check')]";
	public static String CoreLabellingrecordclinicalPostMarket="xpath#//div[@id='applicationParameterForm:defaultCORESpontanious']//span";
	public static String IBLabellingrecordCheckedclinicalPostMarket="xpath#//div[@id='applicationParameterForm:defaultCORESpontanious']//span[contains(@class,'check')]";
	public static String IBLabellingrecordclinicalPostMarket="xpath#//div[@id='applicationParameterForm:defaultCORESpontanious']//span[contains(@class,'check')]";
	
	// Create Default Core Labeling Record_CheckBox
	// Create Default IB Labeling Record_CheckBox

	/////////////////////////////////////////// Case Management >> Follow-up
	/////////////////////////////////////////// Questionnaires ID Format
	/////////////////////////////////////////// ///////////////////////////////

	public static String followUpQuestionnairesIDFormat_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Follow-up Questionnaires ID Format']";
	public static String faqPrefix_TextBox = "xpath#//input[@id ='applicationParameterForm:irtfuFormatPrefix']";
	public static String caseNumber_DropDown = "xpath#//div[@id='applicationParameterForm:irtfuFormatcaseno']//label";
	public static String separator_DropDown = "xpath#//div[@id='applicationParameterForm:irtfuFormatSepartaion']//label";
	public static String resetSequenceBy_DropDown = "xpath#//div[@id='applicationParameterForm:irtfuFormatsques']//label";

	/////////////////////////////////////////// Case Management >> Web Service URL
	/////////////////////////////////////////// Details
	/////////////////////////////////////////// ////////////////////////////////////////////////

	public static String webServiceURLDetails_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Web Service URL Details']";
	public static String contactWebService_TextBox = "xpath#//input[@id ='applicationParameterForm:contactWebServiceId']";
	public static String contactWebServiceUserName_TextBox = "xpath#//input[@id ='applicationParameterForm:contactWebServiceId1']";
	public static String contactWebServicePassword_TextBox = "xpath#//input[@id ='applicationParameterForm:contactWebServiceId2']";
	public static String authenticationRequired_CheckBox = "xpath#//div[@id='applicationParameterForm:integrationContact']/descendant::span[contains(@class, 'ui-icon-blank')]";
	public static String attachmentWebService_TextBox = "xpath#//input[@id ='applicationParameterForm:attachmentWebServiceId']";
	public static String attachmentWebServiceUserName_TextBox = "xpath#//input[@id ='applicationParameterForm:attachmentWebServiceId1']";
	public static String attachmentWebServicePassword_TextBox = "xpath#//input[@id ='applicationParameterForm:attachmentWebServiceId2']";
	public static String attachWebServAuthRequired_CheckBox = "xpath#//div[@id='applicationParameterForm:integrationAttachment']/descendant::span[contains(@class, 'ui-icon-blank')]";
	public static String activityWebService_TextBox = "xpath#//input[@id ='applicationParameterForm:activityWebServiceId']";
	public static String activityWebServiceUserName_TextBox = "xpath#//input[@id ='applicationParameterForm:activityWebServiceId1']";
	public static String activityWebServicePassword_TextBox = "xpath#//input[@id ='applicationParameterForm:activityWebServiceId2']";
	public static String actWebServAuthRequired_CheckBox = "xpath#//div[@id='applicationParameterForm:integrationActivity']/descendant::span[contains(@class, 'ui-icon-blank')]";

	/////////////////////////////////////////// Case Management >> Duplicate Search
	/////////////////////////////////////////// Field
	/////////////////////////////////////////// ////////////////////////////////////////////////////

	public static String duplicateSearchField_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Duplicate Search Field']";
	public static String duplicateSearchField_Button = "xpath#//div[@id = 'applicationParameterForm:picklistDuplicateSearchField']/descendant::button[@title = '%option%']";
	public static String duplicateSearchField_List = "xpath#//div[@id = 'applicationParameterForm:picklistDuplicateSearchField']/descendant::ul[contains(@class, 'picklist-source')]/li[text() = '%value%']";
	public static String maxCriteriaForDuplicateBroadSearchReport_DropDown = "xpath#//div[@id='applicationParameterForm:maxCriteriaForDupSearchMenu']";
	public static String maxNumberOfRecordsforDuplicateSearch_TextBox = "xpath#//input[@id ='applicationParameterForm:maxNoOfRecordsForDupSearchId']";
	public static String AeosSearchField_SelectedList = "xpath#(//div[@id='applicationParameterForm:picklistAoseSearchField']//ul)[2]/li";
	public static String DuplicateSearchField_SelectedList = "xpath#(//div[@id='applicationParameterForm:duplicateSearchFieldPanel']//ul)[2]/li";
	public static String AdvanceSEarchField_SelectedList = "xpath#(//div[@id='applicationParameterForm:advancedSearchFieldPanel']//ul)[2]/li";
	public static String RelatableMapping_SelectedList = "xpath#(//div[@id='applicationParameterForm:RelatednessMappingPanel']//ul)[2]/li";
	/////////////////////////////////////////// Case Management >> AOSE Search Field
	/////////////////////////////////////////// ////////////////////////////////////////////////////

	public static String aoseSearchField_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'AOSE Search Field']";
	public static String aoseSearchField_Button = "xpath#//div[@id = 'applicationParameterForm:picklistAoseSearchField']/descendant::button[@title = '%option%']";
	public static String aoseSearchField_List = "xpath#//div[@id = 'applicationParameterForm:picklistAoseSearchField']/descendant::ul[contains(@class, 'picklist-source')]/li[text() = '%value%']";

	/////////////////////////////////////////// Case Management >> Advanced Search
	/////////////////////////////////////////// Field
	/////////////////////////////////////////// ////////////////////////////////////////////////////

	public static String advancedSearchField_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'AOSE Search Field']";
	public static String advancedSearchField_Button = "xpath#//div[@id = 'applicationParameterForm:picklistDuplicateSearchField1']/descendant::button[@title = '%option%']";
	public static String advancedSearchField_List = "xpath#//div[@id = 'applicationParameterForm:picklistDuplicateSearchField1']/descendant::ul[contains(@class, 'picklist-source')]/li[text() = '%value%']";

	/////////////////////////////////////////// Case Management >> Relatedness
	/////////////////////////////////////////// Mapping Maintenance
	/////////////////////////////////////////// ////////////////////////////////////////////////////

	public static String relatednessMappingMaintenance_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Relatedness Mapping Maintenance']";
	public static String relatednessMappingMaintenance_Button = "xpath#//div[@id = 'applicationParameterForm:CasualityRelatedlistId']/descendant::button[@title = '%option%']";
	public static String causality_List = "xpath#//div[@id = 'applicationParameterForm:CasualityRelatedlistId']/descendant::ul[contains(@class, 'picklist-source')]/li[text() = '%value%']";

	/////////////////////////////////////////// Case Management >> Causality Source
	/////////////////////////////////////////// Derivation
	/////////////////////////////////////////// ///////////////////////////////////////////////

	public static String causalitySourceDerivation_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Causality Source Derivation']";
	public static String causalitySourceDerivation_Add = "xpath#//div[contains(@id, 'applicationParameterForm:cuasalityRep')]/descendant::a[contains(@id, 'applicationParameterForm:add')]";
	public static String reportType_DropDown = "xpath#//div[@id='applicationParameterForm:cuasalityConfigDataTable:%rowNO%:DS-1001']//label";
	public static String studyType_DropDown = "xpath#//div[@id='applicationParameterForm:cuasalityConfigDataTable:%rowNO%:ST-1004']//label";
	public static String reporterCausality_DropDown = "xpath#//div[@id='applicationParameterForm:cuasalityConfigDataTable:%rowNO%:RC-9055']//label";
	public static String companyCausality_DropDown = "xpath#//div[@id='applicationParameterForm:cuasalityConfigDataTable:%rowNO%:CM-9055']//label";
	public static String method_DropDown = "xpath#//div[@id='applicationParameterForm:cuasalityConfigDataTable:%rowNO%:CC-9056']//label";

	/////////////////////////////////////////// Case Management >> Export -
	/////////////////////////////////////////// Department
	/////////////////////////////////////////// ///////////////////////////////////////////////

	public static String exportDepartment_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Export - Department']";
	public static String sourceDocument_CheckBox = "Source Document";
	public static String supportDocument_CheckBox = "Support Document";
	public static String summarySheet_CheckBox = "Summary Sheet";
	public static String includeReceiptNumberWaterMark_CheckBox = "Include Receipt Number WaterMark";
	public static String includeTotalPageWaterMark_CheckBox = "Include Total Page(s) WaterMark";
	public static String includeLRNNumberWaterMark_CheckBox = "Include LRN Number WaterMark";
	public static String includeRegistrationCompletionDateWaterMark_CheckBox = "Include Registration Completion Date WaterMark";
	public static String includeDepartmentWaterMark_CheckBox = "Include Department WaterMark";
	public static String includeAerNoWaterMark_CheckBox = "Include AerNo WaterMark";
	public static String allowReImportforFailedE2BCases_CheckBox = "Allow Re-Import for Failed E2B Cases";
	public static String firstAlert_CheckBox = "1st Alert";
	public static String firstAlertInterval_DropDown = "xpath#//div[@id='applicationParameterForm:A1-9064']//label";
	public static String secondAlert_CheckBox = "2nd Alert";
	public static String secondAlertInterval_DropDown = "xpath#//div[@id='applicationParameterForm:A2-9064']//label";
	public static String thirdAlert_CheckBox = "3rd Alert";
	public static String thirdAlertInterval_DropDown = "xpath#//div[@id='applicationParameterForm:A3-9064']//label";

	/////////////////////////////////////////// Case Management >> Data Assessment
	/////////////////////////////////////////// Configurations
	/////////////////////////////////////////// ///////////////////////////////////////////////

	public static String dataAssessmentConfigurations_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Data Assessment Configurations']";
	public static String followUpCaseAutoMerge_CheckBox = "Follow Up Case Auto Merge";
	public static String followUpCaseAutoMergeRule_DropDown = "xpath#//div[@id='applicationParameterForm:lsmvFollowupDropdown']//label";
	public static String reconciliation_CheckBox = "Support Document";

	/////////////////////////////////////////// Case Management >> Data Extraction
	/////////////////////////////////////////// Folder Location
	/////////////////////////////////////////// ///////////////////////////////////////////////

	public static String dataExtractionFolderLocation_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Data Extraction Folder Location']";
	public static String dataExtractionFolderLocation_TextBox = "xpath#//input[@id ='applicationParameterForm:location']";
	public static String dataExtractionLogo_TextBox = "xpath#//input[@id ='applicationParameterForm:qdeLogoPathId']";

	/////////////////////////////////////////// Case Management >> Other Medically
	/////////////////////////////////////////// Important Condition Info
	/////////////////////////////////////////// ///////////////////////////////////////////////

	public static String otherMedicallyImportantConditionInfo_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and starts-with(normalize-space(text()),'Other Medically Important Condition Info')]";
	public static String otherMedicallyImportantConditionInfo_TextBox = "xpath#//textarea[@id ='applicationParameterForm:medicallyConfirm']";

	public static String DefaultSheetUnlabelled = "xpath#//label[text()='Default Labeling for Datasheet']/parent::td//label[text()='Unlabeled']/parent::td//div[@class='ui-radiobutton-box ui-widget ui-corner-all ui-state-default ui-state-active']";
	public static String DefauktSheetBlank = "xpath#//label[text()='Default Labeling for Datasheet']/parent::td//label[text()='Blank']/parent::td//div[contains(@class,'ui-radiobutton-box')]";
	public static String Save = "xpath#//button[@id='applicationParameterForm:visibleSave']";
	public static String SaveOkBtn = "xpath#//button[@id='mandatoryDialogform:okButton']";

	
/////////////////////////////////////////// Case Management >> Receipt Numbering Format
///////////////////////////////////////////Avinash k 09-Feb-2021
/////////////////////////////////////////// ///////////////////////////////////////////////
	
	public static String getPrefix = "xpath#//input[@id='applicationParameterForm:receiptNumberingFormatId']";
	public static String getSeparator = "xpath#//label[@id='applicationParameterForm:dateSep_label']";
	public static String getDateFormat = "xpath#//label[@id='applicationParameterForm:I-5009_label']";
	public static String errorMSG = "xpath#//div[@id='lockErrMsg']";
	
	
	public static String enableManualFlag_label="xpath#//label[text()='Enable Manual Flag']";
	
	
}

