package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class ANGPageObjects {

	public static String contextViewBtn = "xpath#//span[text()='Context View']";
	public static String editBtn = "xpath#//span/a[text()='Edit']";
	public static String refreshBtn = "xpath#//span[text()='REFRESH']";
	public static String textarea_Description = "xpath#(//span[contains(@class,'doNtUseAngClass ng-star-inserted')])[1]//following-sibling::textarea[contains(@id,'adverseEventNew')][contains(@class,'ng-pristine')]";
	public static String okBtn = "xpath#//div[contains(@class,'searchOkbtn')]//span[text()='OK']";
	public static String regenerateBtn = "xpath#//div[contains(@class,'searchOkbtn')]//span[text()='REGENERATE']";
	public static String AutoNarrative = "xpath#//div[@class='editableDiv']/span";
	public static String NonEditableTextBox = "xpath#//p-checkbox[@name='angShowEditables']//span";
	public static String NonEditableText = "xpath#//div[@class='editableDiv']//span[contains(@id,'f')]";
	public static String EditableText = "xpath#//div[@class='editableDiv']//span[contains(@id,'a')]/span[@class='editableAngDiv']";
	public static String CloseBtn = "xpath#//a//span[@class='pi pi-times']";

	public static String Editable = "xpath#(//div[@class='editableDiv']//span[contains(@id,'a')]/span[@class='editableAngDiv'])['%s']";

	/**********************************************************************************************************
	 * Objective:The below method is created to downLoad Reports by passing reports
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String Edit(String runTimeLabel) {
		String value = Editable;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

}
