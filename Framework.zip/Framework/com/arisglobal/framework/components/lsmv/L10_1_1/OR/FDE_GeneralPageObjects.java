package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FDE_GeneralPageObjects {

	public static String companyUnit = "xpath#//input[@id='adverseEventNew:basicDetailsDataTable:companyUnit_focus']/ancestor::div[@class='ui-helper-hidden-accessible']/following-sibling::label";
	public static String setdropDownValue = "xpath#//ul[contains(@class,'ui-dropdown-items')]/child::li/div/span[contains(text(),'%s ')]";
	public static String dropDownValueSelect = "xpath#//div[@class='ui-helper-clearfix ng-star-inserted']/span	";
	public static String getCompanyUnitValue = "xpath#//input[@id='adverseEventNew:basicDetailsDataTable:companyUnit_focus']/ancestor::div[@class='ui-helper-hidden-accessible']/following-sibling::label/span";
	public static String initialReceiveDate = "xpath#//input[@id='adverseEventNew:basicDetailsDataTable:RecievedDate-102121_input']";
	public static String latestReceiveDate = "xpath#//input[@id='adverseEventNew:basicDetailsDataTable:contactDate-102123_input']";
	public static String companyReceivedDate = "xpath#//input[@id='adverseEventNew:basicDetailsDataTable:TriageDate-102199_input']";
	public static String regulatoryStartDate = "xpath#//input[@id='adverseEventNew:general:regulatoryClockStartDate']";
	public static String caseDueDate = "xpath#//input[@id='adverseEventNew:general:caseDuedate']";
	public static String submissionDueDate = "xpath#//input[@id='adverseEventNew:general:submissionDueDate']";
	public static String aerCloseDate = "xpath#//input[@id='adverseEventNew:general:aerCloseDate']";
	public static String caseManagemntLabel = "xpath#//a[@id='//a[@id='adverseEventNew:administrationId']']";
	public static String patientidTextbox = "xpath#//input[@id='adverseEventNew:patientPanelTable:patientIdentifierTable:idN102DC106102']";
	public static String productname = "xpath#//input[@id='adverseEventNew:drugPanelTable:productPanelDataTable:productCoded']";
	public static String senderOrganizationasCodedLookup = "xpath#//a[@class='agLookupLink']//img";
	public static String lastNameLookup = "xpath#//a[@class='agLookupLink ng-star-inserted']//img";
	public static String getAssignToValue = "xpath#//input[@id='adverseEventNew:generalPanelTable:generalPanelDataTable:assignTo']/ancestor::div[@class='ui-helper-hidden-accessible']/following-sibling::label/span";
	public static String firstName = "xpath#//input[@id='adverseEventNew:contactsDataTable:0:personFirstName_input']";
	public static String productName = "xpath#//input[@id='adverseEventNew:drugPanelTable:productPanelDataTable:productCoded']";
	// public static String generalCommonDropdownSelect =
	// "xpath#//label[@style='visibility:
	// visible;'][text()='{0}']/ancestor::span/p-dropdown/div";
	public static String generalCommonDropdownSelect = "xpath#//label[text()='{0}']/ancestor::span/p-dropdown/div";
	public static String ReportClassifiDropdown = "xpath#//input[@id='adverseEventNew:basicDetailsDataTable:PR-9747_focus']/following::div[@class='ui-multiselect-label-container']/label";
	public static String textFields = "xpath#//label[@style='visibility: visible;'][contains(text(),'%s')]/ancestor::span/input";
	public static String SetreportClassifiDropdown = "xpath#//div[@class='ui-multiselect-items-wrapper']/ul/li/div/child::div/following::label[text()='%s']";
	public static String getData_senderOrgLookupField = "xpath#//input[@id='adverseEventNew:basicDetailsDataTable:accountName_lookup_input']";
	public static String get_RecieptId = "xpath#//label[@id='adverseEventNew:recieptId']";
	public static String get_FirstName = "xpath#//input[@id='adverseEventNew:contactsDataTable:0:personFirstName_input']";
	public static String get_LastName = "xpath#//input[@id='adverseEventNew:contactsDataTable:0:personAutoComplete_input']";
	public static String get_EmailId = "xpath#//input[@id='adverseEventNew:contactsDataTable:0:personEmailId_input']";
	public static String medicallyConfirmedRadio = "xpath#//label[@style='visibility: visible;'][contains(text(),'Medically Confirmed')]/ancestor::div/span/span//label[contains(text(),'{@}')]/ancestor::p-radiobutton/div";
	public static String nullificationAmendmentRadio = "xpath#//label[contains(text(),'{0}')]/ancestor::p-radiobutton/div";
	public static String manualChkbox = "xpath#//label[contains(text(),'Manual')]/following-sibling::p-checkbox/div//span";
	public static String reasonForNullAmend = "xpath#//label[contains(text(),'Reason for Nullification / Amendment')]/ancestor::span/textarea";
	public static String locallyExpeditedNF = "xpath#//label[@style='visibility: visible;'][contains(text(),'Locally Expedited')]/ancestor::div/span/a[@class='agNfLink']";
	public static String locallyExpeditedAppliedNF = "xpath#//label[@style='visibility: visible;'][contains(text(),'Locally Expedited')]/ancestor::div/span/a[@class='agNfAppliedLink']";
	public static String get_ReportClassification = "xpath#//label[@style='visibility: visible;'][contains(text(),'Report Classification')]/ancestor::span/p-multiselect/div/div[2]";
	public static String labelNames_Header = "xpath#//p-header/label[text()='%s']";
	public static String alreadyCodedWarning = "xpath#//span[@class='ui-confirmdialog-message']";
	public static String recodeYesBtn = "xpath#//p-confirmdialog//div//div[3]//button[1]";
	public static String recodeNoBtn = "xpath#//p-confirmdialog//div//div[3]//button[2]";
	public static String caseSeriousness_Label = "xpath#//label[text()='Case Seriousness']";
	public static String MedicallyConfirmedEnabled = "xpath#//label[contains(text(),'Medically Confirmed')]//label[contains(text(),'%s')]/parent::span//p-radiobutton//span[@class='ui-radiobutton-icon ui-clickable pi pi-circle-on']";

	public static String Dropdown = "xpath#(//ul[contains(@class,'ui-dropdown-items ')]/child::li//span[text()='CUBA ( CUB ) '])[2]";
	public static String verify_Datesfields = "xpath#//label[contains(@style,'visibility: visible;')][contains(text(),'%s')]/following-sibling::span/input[1]";
	public static String initialReceiveDateLabel = "Initial Received Date";
	public static String latestReceiveDatelabel = "Latest Received Date";
	public static String companyReceivedDatelabel = "Company Received Date";
	public static String regulatoryStartDatelabel = "Regulatory Clock Start Date";
	public static String caseDueDatelabel = "Case Due Date";
	public static String submissionDueDatelabel = "Submission Due Date";
	public static String aerCloseDatelabel = "AER Close Date";
	public static String SUSAR_CheckBox = "SUSAR";
	public static String SUSAR_Label = "xpath#//label[text()='SUSAR']";
	public static String Nullification_Checkbox = "Nullification";
	public static String Nullification_Label = "xpath#//label[text()='Nullification']";
	public static String SusarCheckBoxSelected = "xpath#//label[text()='SUSAR']/parent::span//p-checkbox//div[contains(@class,'ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active')]";

	// Company unit Dropdown
	public static String CompanyUnit_DropDown = "xpath#//select[@name='adverseEventNew:basicDetailsDataTable:companyUnit_focus']";
	public static String CaseUnit_Text = "xpath#//label[text()='Case Units']";

	// Source Label
	public static String SourceLabel = "xpath#//span[text()='1. Source']";
	public static String ReporterLabel = "xpath#//span[text()='1. Reporter']";
	public static String PatientLabel = "xpath#//label[contains(text(),'Patient Identifiers')]";
	public static String ParentLabel = "xpath#//label[text()='Parent Information']";

	// Case Report DropDown labels
	public static String reportType_Dropdown = "Report Type";
	public static String reportCategory_Dropdown = "Report Category";
	public static String reportClassification_Dropdown = "Report Classification";
	public static String reportPriority_Dropdown = "Report Priority";
	public static String reportReceivingMedium_Dropdown = "Report Receiving Medium";
	public static String reportReceivingFormat_Dropdown = "Report Receiving Format";
	public static String NonCaseAssessmentReason_Dropdown = "Non-Case Assessment Reason";
	public static String caseOwner = "Case Owner";

	// public static String assignTo_Dropdown= "Assign To";
	public static String assignTo_Dropdown = "#xpath//select[@name='adverseEventNew:generalPanelTable:generalPanelDataTable:assignTo']";
	public static String companyUnit_Dropdown = "Company Unit";
	public static String processingUnit_Dropdown = "Processing Unit";
	public static String localCriteriaReportType_Dropdown = "Local Criteria Report Type";
	public static String senderOrganization_LookupField = "Sender Organization as Reported";
	public static String senderOrganizationReporter_Textfield = "Sender Organization as Reported";
	public static String caseSpecificInfo_labelName = "Case Specific Information";
	public static String caseReport_labelName = "Case Report";
	public static String contact_labelName = "Contact";
	public static String caseReportlabel = "xpath#//label[text()='Case Report']";
	public static String caseSpecificationlabel = "xpath#//label[text()='Case Specific Information']";
	public static String contactlabel = "xpath#//p-panel[@id='fdeContactPanel']//label[text()='Contact']";
	// public static String contactlabel =
	// "xpath#//p-header/i[@class='LineMantatory']/following::label[text()='CONTACT']";
	public static String caseOwner_Dropdown = "Case Owner";

	// General Seriousness
	public static String seriousness_Radiobtn = "Seriousness";
	public static String requiredIntervenation_Radiobtn = "Required Intervention";
	public static String death_Radiobtn = "Death?";
	public static String lifeThreatening_Radiobtn = "Life Threatening?";
	public static String congenitalAnomalyBirthDefect_Radiobtn = "Congenital Anomaly/Birth Defect?";
	public static String caused_prolongedhospitalization_Radiobtn = "Caused/Prolonged Hospitalization";
	public static String disability_PermanentDamage_Radiobtn = "Disability/Permanent Damage?";
	public static String OtherMedicallyCondition_Radiobtn = "Other Medically Important Condition";

	public static String noncaseReasonDropdown = "xpath#//label[text()='Non-Case Assessment Reason']//following-sibling::p-dropdown";
	public static String noncaseDropdownValue = "xpath#//span[contains(text(),'%value')]";
	public static String noDropDownValue = "xpath#//ul[contains(@class,'ui-dropdown-items')]/child::li[2]";

	public static String ReportTypeStudy = "xpath#//span[text()='Report from study']";
	public static String ReportTypeChangeConfirmation = "xpath#//form[@id='fdeAngularForm']/div/p-confirmdialog/div/div[1]/span";
	public static String ReportTypeChangeConfirmation_Yes = "xpath#//form[@id='fdeAngularForm']/div/p-confirmdialog/div/div[3]/button[1]/span[contains(text(),'Yes')]";

	// Set report
	public static String reportClassification(String label) {
		String value = SetreportClassifiDropdown.replace("%s", label);
		return value;
	}

	// label Names
	public static String labelNames_Header(String label) {
		String value = labelNames_Header.replace("%s", label);
		return value;
	}

	// RadioButton
	public static String initial_Followup_RadioBtn = "xpath#//p-radiobutton/div/following::label[text()='%s']";
	public static String initialRadiobtn = "Initial";
	public static String followUpRadiobtn = "Follow-Up";
	public static String FollowUpRefNo = "xpath#//input[@id='adverseEventNew:basicDetailsDataTable:dataForBasic']";

	// Case Specific Information
	public static String initial_Followup_RadioBtn(String label) {
		String value = initial_Followup_RadioBtn.replace("%s", label);
		return value;
	}

	public static String ReporterClassification = "xpath#//label[text()='Report Classification']/parent::span//div[@class='ui-multiselect-label-container']//label[text()='--Select--']";
	public static String SelectAllCheckbxReporterClassification = "xpath#//div[contains(@class,'ui-multiselect-header')]//div[@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default']";
	public static String UnSelectAllCheckbxReporterClassification = "xpath#//div[contains(@class,'ui-multiselect-header')]//div[@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']";
	public static String ReporterClassificationValue = "xpath#//label[text()='%s']/parent::li//div[@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default']";
	// public static String
	// NonCaseReporterClassification="xpath#//label[text()='Non-Case']/parent::li//div[@class='ui-chkbox-box
	// ui-widget ui-corner-all ui-state-default']";
	// public static String
	// InvalidReporterClassification="xpath#//label[text()='Non-Case']/parent::li//div[@class='ui-chkbox-box
	// ui-widget ui-corner-all ui-state-default']";

	public static String NONAECase = "Non-AE Case";
	public static String Invalid = "Invalid";
	public static String NonAE = "Non-Case";

	public static String ReporterClassificationValue(String Label) {
		String value = ReporterClassificationValue.replace("%s", Label);
		return value;
	}

	// AssignTo
	public static String AssignTo = "Assign To";
	public static String userRadiobtn = "User";
	public static String groupRadiobtn = "Group";
	public static String assignToRadioBtn = "xpath#//span[contains(@class,'agUserGroupRadio')]/p-radiobutton/label[text()='%s']";
	// Case Specific Information
	public static String primarySourceCountry = "Primary Source Country";
	public static String countryOfDetection = "Country of Detection";
	public static String locallyExpedited = "Locally Expedited";
	public static String caseSignificance = "Case Significance";
	public static String nullification = "Nullification";
	public static String amendment = "Amendment";
	public static String overallTransmissionStatus = "Overall transmission status";
	public static String caseSpecificInfo = "xpath#//label[text()='Case Specific Information']";

	// Case Significance
	public static String casesignifcancemanual = "Case Significance";
	public static String casesignificanceclassvalue = " ";
	public static String casesignificance = "Case Significance";
	public static String Casesignificancevalue = "xpath#(//div[contains(@class,'agCaseSigWithManual')]/span/label[text()='Case Significance']/following-sibling::p-dropdown/div/div/following::label/span[text()='--Select--'])[1]";

	// Additional Documents Available
	public static String additionalDocumentsAvailableRadio = "xpath#//p-radiobutton[@name='addtionalDocuments']//label[text()='%s']//preceding::span[1]";
	public static String additionalDocumentsAvailableLabel = "Additional Documents Available";
	public static String listOfDocumentsHeldByTheSenderTextarea = "xpath#//textarea[@id='adverseEventNew:generalPanelTable:documentDetailsDataTable:listOfDocsHeldBySender:0']";
	public static String listOfDocHeldByTheSenderTextarea = "xpath#//textarea[@id='adverseEventNew:generalPanelTable:documentDetailsDataTable:listOfDocsHeldBySender:%s']";
	public static String isDocumentIncludedListCheckbox = "xpath#//input[@id='adverseEventNew:generalPanelTable:documentDetailsDataTable:isDocumentIncluded:%s']//parent::div//following-sibling::div//span";
	public static String documentNameTextbox = "xpath#//input[@id='adverseEventNew:generalPanelTable:documentDetailsDataTable:fileName:0']";
	public static String additionalDocumentsAdd_Btn = "xpath#//label[text()='Additional Documents Available']/following::span/a[text()='Add']";

	// Case References
	public static String initialSenderDropdown = "xpath#//select[@name='adverseEventNew:generalPanelTable:administrativeDetailsDataTable:initialSender-9125_focus']";
	public static String safetyReportIDtextbox = "xpath#//input[@id='adverseEventNew:generalPanelTable:administrativeDetailsDataTable:idN100CB10614411']";
	public static String AuthorityNoCompNumbertextbox = "xpath#//input[@id='adverseEventNew:generalPanelTable:administrativeDetailsDataTable:idN10149102128']";
	public static String safetyReportIdAsExportedtextbox = "xpath#//input[@id='adverseEventNew:generalPanelTable:administrativeDetailsDataTable:idN10149102997']";
	public static String initialSender = "Initial Sender";

	// E2B Case References in Previous Transmissions
	public static String e2BCaseReferencesinPreviousTransmissionsLabel = "E2B Case References in Previous Transmissions";
	public static String duplicateSourcetextbox = "xpath#//input[@id='adverseEventNew:generalPanelTable:generalPreviouslyReportedTable:idN1027B103102:0']";
	public static String duplicateNumbertextbox = "xpath#//input[@id='adverseEventNew:generalPanelTable:generalPreviouslyReportedTable:idN1028B103104:0']";
	public static String duplicateSourcedisabled = "xpath#//input[@id='adverseEventNew:generalPanelTable:generalPreviouslyReportedTable:idN1027B103102:0'][@disabled]";
	public static String duplicateNumberdisabled = "xpath#//input[@id='adverseEventNew:generalPanelTable:generalPreviouslyReportedTable:idN1028B103104:0'][@disabled]";
	public static String e2BprefCheckbox = "xpath#//label[text()='E2B Case References in Previous Transmissions']//parent::p-header//span[contains(@class,'ui-chkbox-icon')]//parent::div";

	public static String e2BTransmissionsNF = "xpath#//label[contains(text(),'E2B')]/ancestor::p-header/span/span/a/img";
	public static String e2BTransmissionsNF_Dropdown = "xpath#//div/input[contains(@id,'generalPreviouslyReportedTable')]/../../label/span[text()='--Select--']";
	public static String e2BTransmissionsNF_DropdownVal = "xpath#//div/ul/li/div/span[text()='No Information ']";

	// Additional Documents Available
	public static String DocumentName_LookUP = "xpath#//td[@class='ng-star-inserted']//a[@class='agLookupLink']//img[contains(@src,'Lookup_Selection')]";
	public static String DocumentName_Checkbox = "xpath#//td[contains(text(),'%s')]/../td/p-tableradiobutton/div/div/span[contains(@class,'ui-radiobutton-icon')]";
	public static String DocumentName_Okbtn = "xpath#//div[@class='col-md-12 searchOkbtn ng-star-inserted']//button//span[text()='OK']";
	public static String AddDocAvail_Label = "xpath#//a[text()='Additional Documents Available']";

	// FDA Dates
	public static String FDAInitialReceivedDate = "FDA Initial Received Date";
	public static String FDAInitialLatestDate = "FDA Latest Received Date";

	// Case Type
	public static String preMarket_Radiobtn = "xpath#//div[contains(@class,'radiobutton')]/following-sibling::label[text()='Pre-Market']";
	public static String postMarket_Radiobtn = "xpath#//div[contains(@class,'radiobutton')]/following-sibling::label[text()='Post-Market']";
	public static String caseTypeManual_checkbox = "xpath#(//label[contains(text(),'Manual')]/following-sibling::p-checkbox/div//span)[3]";

	// E2B Sender Contact section
	public static String E2BSenderContact_header = "xpath#//p-header/label[text()='E2B Sender Contact']";

	public static String senderContact_DropDowns = "xpath#//div/span/label[text()='%s']/following-sibling::p-dropdown/div[contains(@class,'ui-dropdown')]";
	public static String senderType_Dropdown = "Sender Type";
	public static String senderTitle_Dropdown = "Title";
	public static String senderCountry_Dropdown = "Sender Country";

	public static String senderContact_TextFields = "xpath#//div/span/label[text()='%s']/following-sibling::input[contains(@class,'ui-inputtext')]";
	public static String senderDepartment_TxtField = "Sender Department";
	public static String senderFirstName_TxtField = "Sender First Name";
	public static String senderMidName_TxtField = "Sender Middle Name";
	public static String senderLastName_TxtField = "Sender Last Name";
	public static String senderStreetAdd_TxtField = "Sender Street Address";
	public static String senderCity_TxtField = "Sender City";
	public static String senderState_TxtField = "Sender State";
	public static String senderPostCode_TxtField = "Sender Postcode";
	public static String senderTelephone_TxtField = "Sender Telephone";
	public static String senderTeleExtn_TxtField = "Sender Telephone extension";
	public static String senderTeleCountryCode_TxtField = "Sender Telephone country code";
	public static String senderFax_TxtField = "Sender Fax";
	public static String senderFaxExtn_TxtField = "Sender fax extension";
	public static String senderFaxCountryCode_TxtField = "Sender fax country code";
	public static String sendeEmailAddr_TxtField = "Sender E-mail Address";

	// r2 tags
	public static String R2WWUID = "xpath#//label[text()='[A.1.12]']";
	public static String R2initialReceivedDate = "xpath#//label[text()='[A.1.6b]']";
	public static String R2latestReceivedDate = "xpath#//label[text()='[A.1.7b]']";
	public static String R2combinationProdReport = "xpath#//label[text()='[A.1.FDA.15]']";
	public static String R2reportType = "xpath#//label[text()='[A.1.4]']";
	public static String R2otherSafteyRef = "xpath#//label[text()='[B.1.3]']";
	public static String R2primarySourceCountry = "xpath#//label[text()='[A.1.1]']";
	public static String R2countryOfDetection = "xpath#//label[text()='[A.1.2]']";
	public static String R2locallyExpedited = "xpath#//label[text()='[A.1.9]']";
	public static String R2MedicallyConfirmed = "xpath#//label[text()='[A.1.14]']";
	public static String R2Nullification = "xpath#//label[text()='[A.1.13]']";
	public static String R2AmadmentReason = "xpath#//label[text()='[A.1.13.1]']";
	public static String R2Seriousness = "xpath#//label[text()='[A.1.5.1]']";
	public static String R2Death = "xpath#//label[text()='[A.1.5.2a]']";
	public static String R2LifeThreathening = "xpath#//label[text()='[A.1.5.2b]']";
	public static String R2Caused_ProlongedHospitalization = "xpath#//label[text()='[A.1.5.2c]']";
	public static String R2Disability_PermanentDamage = "xpath#//label[text()='[A.1.5.2d]']";
	public static String R2CongenitalAnomaly_BirthDefect = "xpath#//label[text()='[A.1.5.2e]']";
	public static String R2OtherMedicallyImportantCondition = "xpath#//label[text()='[A.1.5.2f]']";
	public static String R2AdditionalDocumentsAvailable = "xpath#//label[text()='[A.1.8.1]']";
	public static String R2ListOfDocumentsHeldByTheSender = "xpath#//label[text()='[A.1.8.2]']";
	public static String R2SafetyReportID = "xpath#//label[text()='[A.1.0.1]']";
	public static String R2AuthorityNo_CompNumber = "xpath#//label[text()='[A.1.10.1/2]']";
	public static String R2E2BCaseReferences = "xpath#//label[text()='[A.1.11]']";
	public static String R2DuplicateSource = "xpath#//label[text()='[A.1.11.1]']";
	public static String R2DuplicateNumber = "xpath#//label[text()='[A.1.11.2]']";

	// r3 tags
	public static String R3LocalCriteriaReportType = "xpath#//label[text()='[FDA.C.1.7.1]']";
	public static String R3WWUID = "xpath#//label[text()='[C.1.10.r]']";
	public static String R3initialReceivedDate = "xpath#//label[text()='[C.1.4]']";
	public static String R3latestReceivedDate = "xpath#//label[text()='[C.1.5]']";
	public static String R3combinationProdReport = "xpath#//label[text()='[FDA.C.1.12]']";
	public static String R3reportType = "xpath#//label[text()='[C.1.3]']";
	public static String R3otherSafteyRef = "xpath#//label[text()='[ACK.B.r.2]']";
	public static String R3locallyExpedited = "xpath#//label[text()='[C.1.7]']";
	public static String R3Nullification = "xpath#//label[text()='[C.1.11.1]']";
	public static String R3AmadmentReason = "xpath#//label[text()='[C.1.11.2]']";
	public static String R3AdditionalDocumentsAvailable = "xpath#//label[text()='[C.1.6.1]']";
	public static String R3ListOfDocumentsHeldByTheSender = "xpath#//label[text()='[C.1.6.1.r.1]']";
	public static String R3IsDocumentIncluded = "xpath#//label[text()='[C.1.6.1.r.2]']";
	public static String R3InitialSender = "xpath#//label[text()='[C.1.8.2]']";
	public static String R3SafetyReportID = "xpath#//label[text()='[C.1.1]']";
	public static String R3AuthorityNo_CompNumber = "xpath#//label[text()='[C.1.8.1]']";
	public static String R3E2BCaseReferencesInPreviousTransmissions = "xpath#//label[text()='[C.1.9.1]']";
	public static String R3DuplicateSource = "xpath#//label[text()='[C.1.9.1.r.1]']";
	public static String R3DuplicateNumber = "xpath#//label[text()='[C.1.9.1.r.2]']";

	// codeList
	public static String CLlocalCriteriaReportType = "xpath#//label[text()='[9742]']";
	public static String CLCombinationProductReport = "xpath#//label[text()='[4]']";
	public static String CLReportType = "xpath#//label[text()='[1001]']";
	public static String CLReportCategory = "xpath#//label[text()='[8140]']";
	public static String CLReportClassification = "xpath#//label[text()='[9747]']";
	public static String CLReportPriority = "xpath#//label[text()='[145]']";
	public static String CLReportReceivingMedium = "xpath#//label[text()='[501]']";
	public static String CLReportReceivingFormat = "xpath#//label[text()='[9034]']";
	public static String CLInitial = "xpath#//label[text()='[2029]']";
	public static String CLOverallLatenessReason = "xpath#//label[text()='[9922]']";
	public static String CLNonCaseAssessmentReason = "xpath#//label[text()='[9924]']";
	public static String CLTurnOffTouchLess = "xpath#//label[text()='Turn Off Touch Less']//parent::span/label[text()='[4]']";
	public static String CLPrimarySourceCountry = "xpath#//label[text()='Primary Source Country']//parent::span/label[text()='[1015]']";
	public static String CLCountryOfDetection = "xpath#//label[text()='Country of Detection']//parent::span/label[text()='[1015]']";
	public static String CLCaseSignificance = "xpath#//label[text()='[9605]']";
	public static String CLLocallyExpedited = "xpath#//label[text()='[9748]']";
	public static String CLMedicallyConfirmed = "xpath#//label[text()='Medically Confirmed']//parent::span/label[text()='[1002]']";
	public static String CLNullification = "xpath#//label[text()='[9604]']";
	public static String CLOverallTransmissionStatus = "xpath#//label[text()='[194]']";
	public static String CLSeriousness = "xpath#//label[text()='Seriousness']//parent::span/label[text()='[1002]']";
	public static String CLDeath = "xpath#//label[text()='Death?']//parent::span/label[text()='[1002]']";
	public static String CLLifeThreatening = "xpath#//label[text()='Life Threatening?']//parent::span/label[text()='[1002]']";
	public static String CLCaused_ProlongedHospitalization = "xpath#//label[text()='Caused/Prolonged Hospitalization']//parent::span/label[text()='[1002]']";
	public static String CLDisability_PermanentDamage = "xpath#//label[text()='Disability/Permanent Damage?']//parent::span/label[text()='[1002]']";
	public static String CLCongenitalAnomaly_BirthDefect = "xpath#//label[text()='Congenital Anomaly/Birth Defect?']//parent::span/label[text()='[1002]']";
	public static String CLOtherMedicallyImportantCondition = "xpath#//label[text()='Other Medically Important Condition']//parent::span/label[text()='[1002]']";
	public static String CLRequiredIntervention = "xpath#//label[text()='Required Intervention']//parent::span/label[text()='[1002]']";
	public static String CLIsDocumentIncluded = "xpath#//label[text()='Is Document Included?']//parent::th/label[text()='[4]']";
	public static String CLInitialSender = "xpath#//label[text()='[9125]']";

	public static String primarySourceCountryValue = "xpath#//span[text()='UNITED STATES OF AMERICA ( USA )']";
	public static String countryOfDetectionValue = "xpath#(//span[text()='UNITED STATES OF AMERICA ( USA )'])[2]";

	public static String reportPriorityField = "xpath#//label[text()='Report Priority']";
	public static String reportPriorityNull = "xpath#//label[text()='Report Priority']/ancestor::span/p-dropdown/div//label/span";
	public static String caseReference = "xpath#//a[text()='Case References']";

	// -----------------

	public static String isDocumentIncludedListCheckbox(String rowNo) {
		String value = isDocumentIncludedListCheckbox.replace("%s", rowNo);
		return value;
	}

	public static String listOfDocHeldByTheSenderTextarea(String rowNo) {
		String value = listOfDocHeldByTheSenderTextarea.replace("%s", rowNo);
		return value;
	}

	public static String additionalDocumentsAvailableRadio(String label) {
		String value = additionalDocumentsAvailableRadio.replace("%s", label);
		return value;
	}

	public static String DocumentName_Checkbx(String label) {
		String value = DocumentName_Checkbox.replace("%s", label);
		return value;
	}

	public static String assignToRadioBtn(String label) {
		String value = assignToRadioBtn.replace("%s", label);
		return value;
	}

	// public static String CaseSignificanceDropdown =
	// "xpath#//select[contains(@name,'adverseEventNew:generalPanelTable:generalPanelDataTable:caseVersionSignificance-9123')]";
	public static String CaseSignificanceDropdown = "xpath#//label[contains(text(),'Case Significance')]/parent::span/parent::div//p-dropdown/div//span[not( contains(@class,'ui-dropdown-trigger-icon ui-clickable pi pi-caret-down'))]";
	public static String readCaseSignificanceDDVal = "xpath#//label[contains(text(),'Case Significance')]/parent::span/span/p-dropdown/div/label/span";

	public static String reportClassificationDropdown = "xpath#//label[text()='Report Classification']/parent::span//div[@class='ui-multiselect-label-container']//label";
	public static String selectReportClassificationValue = "xpath#//ul[contains(@class,'ui-multiselect-items ')]/li//label[text()='%value%']";

	public static String selectReportClassification(String value) {
		String res = generalCommonDropdownSelect.replace("%value%", value);
		return res;
	}

	// Case Specific Information

	public static String selectGeneralDroprdown(String label) {
		String value = generalCommonDropdownSelect.replace("{0}", label);
		return value;
	}

	// Click Dropdown value
	public static String clickDropDownValue(String data) {
		String value = setdropDownValue.replace("%s", data);
		return value;
	}

	// Set data in Text field by passing label at runtime
	public static String setTextField(String label) {
		String value = textFields.replace("%s", label);
		return value;
	}

	public static String medicallyConfirmedRadio(String testdata) {
		String value = medicallyConfirmedRadio.replace("{@}", testdata);
		return value;
	}

	public static String nullificationAmendmentRadio(String label) {
		String value = nullificationAmendmentRadio.replace("{0}", label);
		return value;
	}

	public static String ReportClassification = "xpath#//label[text()='Report Classification']/parent::span//div[@class='ui-multiselect-label-container']//label";

	/**********************************************************************************************************
	 * Objective:The below method is created to set data in date field by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Mithun M P Date :29-Nov-2019
	 **********************************************************************************************************/
	public static String setData_Datesfields(String runTimeLabel) {
		String value = verify_Datesfields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to set data in drop down for choosing
	 * non case assessment reason
	 * 
	 * @author:Karthikeyan Natarajan , 23-Jul-20
	 **********************************************************************************************************/
	public static String selectnoncasereasondropdownValue(String label) {
		String value = noncaseDropdownValue;
		String value2;
		value2 = value.replace("%value", label);
		return value2;

	}

	/**********************************************************************************************************
	 * Objective:The below method is created to set data in text fields of E2B
	 * Sender Contact section Input Parameters: Column label; declared above as
	 * class variables
	 * 
	 * @author:Shamanth S Date :09-Sep-2020
	 **********************************************************************************************************/
	public static String setData_E2BSenderContact_TextFfield(String runTimeLabel) {
		String value = senderContact_TextFields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select data from drop down fields of
	 * E2B Sender Contact section Input Parameters: Column label; declared above as
	 * class variables
	 * 
	 * @author:Shamanth S Date :09-Sep-2020
	 **********************************************************************************************************/
	public static String setData_E2BSenderContact_DropDowns(String runTimeLabel) {
		String value = senderContact_DropDowns;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	// Add multiple Docs
	public static String listOfDocumentsHeldByTheSender_Textarea = "xpath#//textarea[@id='adverseEventNew:generalPanelTable:documentDetailsDataTable:listOfDocsHeldBySender:%s%']";
	public static String documentName_Textbox = "xpath#//input[@id='adverseEventNew:generalPanelTable:documentDetailsDataTable:fileName:%s%']";

	/**********************************************************************************************************
	 * Objective:The below method is created to select data from drop down fields of
	 * E2B Sender Contact section Input Parameters: Column label; declared above as
	 * class variables
	 * 
	 * @author:Shamanth S Date :09-Sep-2020
	 **********************************************************************************************************/
	public static String additionalDocLocatorBuilder(String locator, int recNumber) {
		String recNumber1 = Integer.toString(recNumber);
		String value = locator;
		String value2;
		value2 = value.replace("%s%", recNumber1);
		return value2;
	}

	// Drop
	public static String CaseOwnerSearchFiled = "xpath#//label[@style='visibility: visible;'][text()='Case Owner']/ancestor::span/p-dropdown/div/label";
	public static String CaseOwnerSearchKeyFiled = "xpath#//div[@class='ui-dropdown-filter-container ng-tns-c2-98 ng-star-inserted']/input";
	// Quality Review screen
	public static String allEvaluated_Checkbox = "xpath#//span[(text()=' Check all Evaluated: ')]/p-checkbox/div/div[2]/span";
	public static String actionToBeTaken_DropDown = "xpath#//div[@class='col-md-6 qcReviewPanelResDrpBtn']/p-dropdown/div/label";
	public static String dropDown_NoActionNeeded = "xpath#//ul/li/span[contains(text(),'needed')]";
	public static String Confirmation_Text = "xpath#//div/span[@class='ui-confirmdialog-message']";
	public static String ConfirmationYes_Btn = "xpath#//p-confirmdialog/div/div/button/span[text()='Yes']";

	public static String setStudyProductdropDownValue = "xpath#//ul[contains(@class,'ui-dropdown-items')]/child::li/div/span[contains(text(),'%s')]";

	public static String clickStudyProductDropDownValue(String data) {
		String value = setStudyProductdropDownValue.replace("%s", data);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to get the xpath of Medically Confirmed
	 * Radio button which can be used to verify whether it is selected a case level
	 * 
	 * @author:Abhisek Ghosh Date :18-Feb-2021
	 **********************************************************************************************************/
	// public static String medicallyConfirmedRadioSelection =
	// "xpath#//label[@style='visibility: visible;'][contains(text(),'Medically
	// Confirmed')]/ancestor::div/span/span//label[contains(text(),'{@}')]/ancestor::p-radiobutton/div/div[2]";
	public static String medicallyConfirmedRadioSelection = "xpath#//label[contains(text(),'Medically Confirmed')]/parent::span/span//p-radiobutton//label[contains(text(),'{@}')]";
	public static String medicallyConfirmedRadioBtn = "xpath#//label[contains(text(),'Initial')]/parent::span/span//p-radiobutton//label[contains(text(),'No')]/parent::p-radiobutton//span";

	public static String medicallyConfirmedLabel = "Medically Confirmed";
	public static String caseSignificanceLabel = "Case Significance";
	public static String verifyLabel = "xpath#//label[contains(text(),'%s%')]";

	public static String verifyMedicallyConfirmedRadioSelection(String testdata) {
		String value = medicallyConfirmedRadioSelection.replace("{@}", testdata);
		return value;
	}

	public static String select_MedicallyConfirmedRadioSelection(String testdata) {
		String value = medicallyConfirmedRadioSelection.replace("{@}", testdata);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to navigate at specific label field by
	 * passing label name at runtime. Input Parameters: label name maintained in
	 * Event Object Repository Parameters:
	 * 
	 * @author:Abhisek Ghosh Date : 18-Feb-2021
	 **********************************************************************************************************/

	public static String labelField(String runTimeLabel) {
		String value = verifyLabel;
		String value2;
		value2 = value.replace("%s%", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Abhisek Ghosh
	 * @Date : 19-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	// public static String manualCheckBoxSelection_General =
	// "xpath#//label[starts-with(normalize-space(text()),'{0}')]/parent::span/parent::div/following-sibling::div[3]//p-checkbox/div/div[2]";
	public static String manualCheckBoxSelection_General = "xpath#(//label[starts-with(normalize-space(text()),'{0}')]/parent::span/parent::div/following-sibling::div/label[contains(text(), 'Manual')])[1]/parent::div//p-checkbox/div/div[2]";

	// public static String setdropDownValue =
	// "xpath#//span[contains(text(),'%s')]";

	public static String manualCheckBoxSelection_General(String checkBoxLabel) {
		String actualLocator = manualCheckBoxSelection_General;
		String resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}

}
