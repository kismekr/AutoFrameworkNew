package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.BatchPrintConfigurationsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CIMOSLLReportsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_SubmissionTrackingPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class CIMOSLLReportsOperations extends ToolManager {
	public static WebElement webElement;
	static String className = CIMOSLLReportsOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to search and edit the CIOMS LL
	 *             Reports.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void search(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		agSetValue(CIMOSLLReportsPageObjects.cimosLLReportsSearchTextbox,
				getTestDataCellValue(scenarioName, "ReportName"));
		agJavaScriptExecuctorClick(CIMOSLLReportsPageObjects.searchIcon);
		agIsVisible(CIMOSLLReportsPageObjects.paginator);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search the deleted CIOMS LL
	 *             Reports.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchDeletedCIOMSLLReports(String scenarioName) {
		search(scenarioName);
		String paginator = agGetText(CIMOSLLReportsPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "ReportName"),
					CIMOSLLReportsPageObjects.get_ListofReportName);
			Reports.ExtentReportLog("", Status.FAIL, "Search CIOMS LL Reports: CIOMS LL Reports Listed", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS, "Search CIOMS LL Reports: CIOMS LL Reports Not Listed", true);
		}
		agClick(CIMOSLLReportsPageObjects.refresh_Btn);
		agIsVisible(CIMOSLLReportsPageObjects.cimosLLReportsSearchTextbox);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created search and create CIOMS LL Reports.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 2-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreateCIOMSLLReports(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		if (verifysearchData(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS, "CIOMS LL Reports already exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "ReportName"),
					CIMOSLLReportsPageObjects.get_ListofReportName);
		} else {
			createCIOMSLLReports(scenarioName);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Batch Name exist or not
	 *             based on CIOMS LL Reports
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Boolean verifysearchData(String scenarioName) {
		Boolean falg = false;
		agWaitTillVisibilityOfElement(CIMOSLLReportsPageObjects.paginator);
		String paginator = agGetText(CIMOSLLReportsPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			List<WebElement> list = agGetElementList(CIMOSLLReportsPageObjects.get_ListofReportName);
			String columnHeader = null;
			for (int j = 1; j <= list.size(); j++) {
				columnHeader = agGetText(CIMOSLLReportsPageObjects.columnHeaderVerification(Integer.toString(j)));
				if (getTestDataCellValue(scenarioName, "ReportName").equalsIgnoreCase(columnHeader)) {
					falg = true;
					break;
				}
			}
		}
		return falg;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set drop down CIOMS LL Reports.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 31-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDownValues(String runTimeLabel, String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(CIMOSLLReportsPageObjects.clickdropdown(runTimeLabel));
			agClick(CIMOSLLReportsPageObjects.setdropdown(getTestDataCellValue(scenarioName, columnName)));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create CIOMS LL Reports.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 31-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createCIOMSLLReports(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(CIMOSLLReportsPageObjects.new_Btn);
		agSetStepExecutionDelay("3000");
		if (getTestDataCellValue(scenarioName, "CIMOSReportType").equalsIgnoreCase("Drug")) {
			agClick(CIMOSLLReportsPageObjects.drugRadioBtn);
		}
		if (getTestDataCellValue(scenarioName, "CIMOSReportType").equalsIgnoreCase("Device")) {
			agClick(CIMOSLLReportsPageObjects.deviceRadioBtn);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		agSetValue(CIMOSLLReportsPageObjects.setTextFields(CIMOSLLReportsPageObjects.reportName_Txtfield),
				getTestDataCellValue(scenarioName, "ReportName"));

		// agSetStepExecutionDelay("3000");
		// agClick(CIMOSLLReportsPageObjects.datesSelect(CIMOSLLReportsPageObjects.lrdFromDate));
		// agClick(CIMOSLLReportsPageObjects.todaySelect);

		// agClick(CIMOSLLReportsPageObjects.datesSelect(CIMOSLLReportsPageObjects.lrdToDate));
		// agJavaScriptExecuctorClick(CIMOSLLReportsPageObjects.todaySelect);

		agSelectByVisibleText(CIMOSLLReportsPageObjects.reportFormat_Dropdown,
				getTestDataCellValue(scenarioName, "ReportFormat"));

		if (getTestDataCellValue(scenarioName, "ProductRequired").equalsIgnoreCase("Yes")) {
			addProduct(scenarioName);
		}
		agSelectByVisibleText(CIMOSLLReportsPageObjects.mostSuspect_Dropdown,
				getTestDataCellValue(scenarioName, "SuspectProduct"));

		agSetValue(CIMOSLLReportsPageObjects.setTextFields(CIMOSLLReportsPageObjects.approvalNo_Txtfield),
				getTestDataCellValue(scenarioName, "ApprovalNo"));

		agSelectByVisibleText(CIMOSLLReportsPageObjects.approvalCountry_Dropdown,
				getTestDataCellValue(scenarioName, "ApprovalCountry"));

		agSelectByVisibleText(CIMOSLLReportsPageObjects.approvalType_Dropdown,
				getTestDataCellValue(scenarioName, "ApprovalType"));

		agSelectByVisibleText(CIMOSLLReportsPageObjects.routeofAdmin_Dropdown,
				getTestDataCellValue(scenarioName, "RouteOfAdmin"));

		agSelectByVisibleText(CIMOSLLReportsPageObjects.formofAdmin_Dropdown,
				getTestDataCellValue(scenarioName, "FormOFAdmin"));

		agSelectByVisibleText(CIMOSLLReportsPageObjects.reportType_Dropdown,
				getTestDataCellValue(scenarioName, "ReportType"));

		agSelectByVisibleText(CIMOSLLReportsPageObjects.labelled_Dropdown,
				getTestDataCellValue(scenarioName, "Labelled"));

		agSelectByVisibleText(CIMOSLLReportsPageObjects.includeUnApprovedCases_Dropdown,
				getTestDataCellValue(scenarioName, "IncludeUnapprovedCases"));

		agSelectByVisibleText(CIMOSLLReportsPageObjects.caseSeriousness_Dropdown,
				getTestDataCellValue(scenarioName, "CaseSeriousness"));

		agSelectByValue(CIMOSLLReportsPageObjects.printSelectionCriteria,
				getTestDataCellValue(scenarioName, "PrintSelectionCriteria"));

		if (getTestDataCellValue(scenarioName, "ProtocolNoRequired").equalsIgnoreCase("Yes")) {
			addProtocolNumber(scenarioName);
		}
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		// agClick(CIMOSLLReportsPageObjects.clickdropdown(CIMOSLLReportsPageObjects.scheduledReport_dropdown));
		// agClick(CIMOSLLReportsPageObjects
		// .setscheduledReport_dropdown(getTestDataCellValue(scenarioName,
		// "ScheduledReport")));
		//
		// setDropDownValues(CIMOSLLReportsPageObjects.blindingType_dropdown,
		// scenarioName, "BlindingType");
		//
		// setDropDownValues(CIMOSLLReportsPageObjects.scheduleType_dropdown,
		// scenarioName, "ScheduleType");
		// setDatesCalender(CommonOperations.returnDateTime(getTestDataCellValue(scenarioName,
		// "DateTime")),
		// CIMOSLLReportsPageObjects.dateTime);
		//
		// setDropDownValues(CIMOSLLReportsPageObjects.days_dropdown, scenarioName,
		// "Days");
		// setDropDownValues(CIMOSLLReportsPageObjects.months_dropdown, scenarioName,
		// "Months");
		// setDropDownValues(CIMOSLLReportsPageObjects.date_dropdown, scenarioName,
		// "Date");

		Reports.ExtentReportLog("", Status.INFO, "Data entered in CIOMS LL Reports", true);
		agClick(CIMOSLLReportsPageObjects.generateBtn);
		agSetStepExecutionDelay("2000");
		agWaitTillInvisibilityOfElement(CIMOSLLReportsPageObjects.successfulllyMessage);
		agIsVisible(CIMOSLLReportsPageObjects.cimosLLReportsSearchTextbox);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search and edit the batch print.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndEdit(String scenarioName, Boolean edit) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(BatchPrintConfigurationsPageObjects.batchPrintListingSearchTextbox,
				getTestDataCellValue(scenarioName, "BatchConfigurationName"));
		agClick(BatchPrintConfigurationsPageObjects.searchIcon);
		agIsVisible(BatchPrintConfigurationsPageObjects.paginator);
		CommonOperations.takeScreenShot();
		if (edit == true) {
			agClick(BatchPrintConfigurationsPageObjects.editIcon);
			agSetStepExecutionDelay("3000");
			agIsVisible(BatchPrintConfigurationsPageObjects.get_ListofconfigrationName);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CommonOperations.takeScreenShot();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add Product in CIOMS LL Reports.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addProduct(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(CIMOSLLReportsPageObjects.productLookupIcon);
		agSetStepExecutionDelay("5000");
		agSetValue(CIMOSLLReportsPageObjects.productLookupsearchTextField,
				getTestDataCellValue(scenarioName, "ProductDescription"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(CIMOSLLReportsPageObjects.productLookupSearchIcon);
		agSetStepExecutionDelay("2000");
		agClick(CIMOSLLReportsPageObjects
				.productlookupSelectAllcheckbox(getTestDataCellValue(scenarioName, "ProductDescription")));
		Reports.ExtentReportLog("", Status.INFO, "Product is selected", true);
		agClick(CIMOSLLReportsPageObjects.productLookupSelectBtn);
		agIsVisible(CIMOSLLReportsPageObjects.generate_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add Protocol Number in CIOMS LL
	 *             Reports.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addProtocolNumber(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(CIMOSLLReportsPageObjects.protocolNoLookupIcon);
		agSetStepExecutionDelay("5000");
		agSetValue(CIMOSLLReportsPageObjects.protocolNosearchTextField,
				getTestDataCellValue(scenarioName, "ProtocolNumber"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(CIMOSLLReportsPageObjects.protocolNoSearchIcon);
		agSetStepExecutionDelay("2000");
		agClick(CIMOSLLReportsPageObjects
				.protocolNoSelectcheckbox(getTestDataCellValue(scenarioName, "ProtocolNumber")));
		Reports.ExtentReportLog("", Status.INFO, "Study is selected", true);
		agClick(CIMOSLLReportsPageObjects.protocolNoSelectBtn);
		agIsVisible(CIMOSLLReportsPageObjects.generate_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: Select date in JS calendar
	 * @InputParameters: Date , label
	 * @OutputParameters:NA
	 * @author:Mithun M P
	 * @Date : 06-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDatesCalender(String date, String label) {
		if (!date.trim().equalsIgnoreCase("#skip#")) {
			String[] Date = date.split("-");
			agClick(CIMOSLLReportsPageObjects.setDatesTextboxes(label));
			agSetStepExecutionDelay("2000");
			agClick(CIMOSLLReportsPageObjects.monthClick(label));
			agClick(CIMOSLLReportsPageObjects.monthDropdown(Date[1]));
			agClick(CIMOSLLReportsPageObjects.yearClick(label));
			agClick(CIMOSLLReportsPageObjects.yearDropdown(Date[2]));

			char[] temp = Date[0].toCharArray();

			/*
			 * System.out.println(temp); char result; if(temp[0] =='0') { result = temp[1];
			 * System.out.println(result);
			 */

			agClick(CIMOSLLReportsPageObjects.dateSelect(label, String.valueOf(temp)));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			/*
			 * } else { agClick(CIMOSLLReportsPageObjects.dateSelect(Date[0]));
			 * System.out.println("Date: "+Date[0]); System.out.println("Date1:"+Date[1]); }
			 */
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete CIOMS LL Reports.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteBatchPrint(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		searchAndEdit(scenarioName, false);
		String paginator = agGetText(CIMOSLLReportsPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "ReportName"),
					CIMOSLLReportsPageObjects.get_ListofReportName);
			Reports.ExtentReportLog("", Status.PASS, "Batch Name Found", true);
			agClick(CIMOSLLReportsPageObjects.selectListingCheckbox(getTestDataCellValue(scenarioName, "ReportName")));
			delete(scenarioName);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Batch Name Not Found", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete CIOMS LL Reports.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void delete(String scenarioName) {
		agClick(CIMOSLLReportsPageObjects.delete_Btn);
		CommonOperations.setDeleteAuditInfo(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search for deleted CIOMS LL
	 *             Reports.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchDeleteBatchprint(String scenarioName) {
		searchAndEdit(scenarioName, false);
		String paginator = agGetText(CIMOSLLReportsPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.FAIL, "Search for Deleted batch print: Deleted batch print is listed",
					true);
		} else {
			Reports.ExtentReportLog("", Status.PASS,
					"Search for Deleted batch print: Deleted batch print is not listed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download CIOMS LL Reports export
	 *             to excel.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 15-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportToexcel(String FileName) {
		agSetStepExecutionDelay("2000");
		agMouseHover(CIMOSLLReportsPageObjects.downloadIcon);
		agJavaScriptExecuctorClick(CIMOSLLReportsPageObjects.downloadIcon);
		agJavaScriptExecuctorClick(CIMOSLLReportsPageObjects.exportAllData_Radio);
		CommonOperations.takeScreenShot();
		if (agIsVisible(CIMOSLLReportsPageObjects.exportToExcel_Btn) == true) {
			agClick(CIMOSLLReportsPageObjects.exportToExcel_Btn);
			try {
				Thread.sleep(15000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			CommonOperations.move_XLSDownloadedexcel(FileName);
			Reports.ExtentReportLog("Excel Downloaded successfully", Status.INFO, "", true);
			agClick(CIMOSLLReportsPageObjects.cancel_Btn);
		} else {
			Reports.ExtentReportLog("Export to excel pop is not displayed", Status.INFO, "", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to compare record count with download
	 *             excel
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:Avinash K
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void recordCountVerification(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		String count = xls.getCellData("CIOMS LL Reports", 2, 4);
		String[] Totalcount = count.split(":");
		System.out.println(Totalcount[1].trim());
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in exported excel::" + Totalcount[1].trim(),
				false);
		String applrecordcount = agGetText(CIMOSLLReportsPageObjects.paginator);
		String[] data = applrecordcount.split(" ");
		String recordCount = data[4];
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in application::" + recordCount, false);
		if (recordCount.equalsIgnoreCase(Totalcount[1].trim())) {
			Reports.ExtentReportLog("", Status.PASS, "Record count verification is successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Record count verification is Unsuccessfull", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create CIOMS LL Reports.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 27-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createNewCIOMSLLReports(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "DataAssessmentOperations");
		Reports.ExtentReportLog("", Status.INFO, "Create New CIOMSLL Report", true);
		agClick(CIMOSLLReportsPageObjects.new_Btn);
		agSetStepExecutionDelay("3000");

		agSetValue(CIMOSLLReportsPageObjects.setTextFields(CIMOSLLReportsPageObjects.aerNo_Txtfield),
				getTestDataCellValue(scenarioName, "AERNo"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (getTestDataCellValue(scenarioName, "CIMOSReportType").equalsIgnoreCase("Drug")) {
			agClick(CIMOSLLReportsPageObjects.drugRadioBtn);
		}
		if (getTestDataCellValue(scenarioName, "CIMOSReportType").equalsIgnoreCase("Device")) {
			agClick(CIMOSLLReportsPageObjects.deviceRadioBtn);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(CIMOSLLReportsPageObjects.setTextFields(CIMOSLLReportsPageObjects.reportName_Txtfield),
				getTestDataCellValue(scenarioName, "ReportName"));

		// agSetStepExecutionDelay("3000");
		// agClick(CIMOSLLReportsPageObjects.datesSelect(CIMOSLLReportsPageObjects.lrdFromDate));
		// agClick(CIMOSLLReportsPageObjects.todaySelect);

		// agClick(CIMOSLLReportsPageObjects.datesSelect(CIMOSLLReportsPageObjects.lrdToDate));
		// agJavaScriptExecuctorClick(CIMOSLLReportsPageObjects.todaySelect);

		// agSelectByVisibleText(CIMOSLLReportsPageObjects.reportFormat_Dropdown,
		// getTestDataCellValue(scenarioName, "ReportFormat"));

		if (getTestDataCellValue(scenarioName, "ProductRequired").equalsIgnoreCase("Yes")) {
			addProduct(scenarioName);
		}
		// agSelectByVisibleText(CIMOSLLReportsPageObjects.mostSuspect_Dropdown,
		// getTestDataCellValue(scenarioName, "SuspectProduct"));

		// agSetValue(CIMOSLLReportsPageObjects.setTextFields(CIMOSLLReportsPageObjects.approvalNo_Txtfield),
		// getTestDataCellValue(scenarioName, "ApprovalNo"));
		//
		// agSelectByVisibleText(CIMOSLLReportsPageObjects.approvalCountry_Dropdown,
		// getTestDataCellValue(scenarioName, "ApprovalCountry"));
		//
		// agSelectByVisibleText(CIMOSLLReportsPageObjects.approvalType_Dropdown,
		// getTestDataCellValue(scenarioName, "ApprovalType"));
		//
		// agSelectByVisibleText(CIMOSLLReportsPageObjects.routeofAdmin_Dropdown,
		// getTestDataCellValue(scenarioName, "RouteOfAdmin"));
		//
		// agSelectByVisibleText(CIMOSLLReportsPageObjects.formofAdmin_Dropdown,
		// getTestDataCellValue(scenarioName, "FormOFAdmin"));

		agSelectByVisibleText(CIMOSLLReportsPageObjects.reportType_Dropdown,
				getTestDataCellValue(scenarioName, "ReportType"));

		agSelectByVisibleText(CIMOSLLReportsPageObjects.labelled_Dropdown,
				getTestDataCellValue(scenarioName, "Labelled"));

		agSelectByVisibleText(CIMOSLLReportsPageObjects.includeUnApprovedCases_Dropdown,
				getTestDataCellValue(scenarioName, "IncludeUnapprovedCases"));

		agSelectByVisibleText(CIMOSLLReportsPageObjects.caseSeriousness_Dropdown,
				getTestDataCellValue(scenarioName, "CaseSeriousness"));

		agSelectByValue(CIMOSLLReportsPageObjects.printSelectionCriteria,
				getTestDataCellValue(scenarioName, "PrintSelectionCriteria"));

		if (getTestDataCellValue(scenarioName, "ProtocolNoRequired").equalsIgnoreCase("Yes")) {
			addProtocolNumber(scenarioName);
		}
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		Reports.ExtentReportLog("", Status.INFO, "Data entered in CIOMS LL Reports", true);
		agClick(CIMOSLLReportsPageObjects.generateBtn);
		agSetStepExecutionDelay("2000");
		agWaitTillInvisibilityOfElement(CIMOSLLReportsPageObjects.successfulllyMessage);
		agIsVisible(CIMOSLLReportsPageObjects.cimosLLReportsSearchTextbox);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to refresh and generate the CIOMS LL
	 *             Reports.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 27-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void refreshToGenerateReport() {
		for (int i = 1; i < 20; i++) {
			agSetStepExecutionDelay("5000");
			agClick(CIMOSLLReportsPageObjects.refresh_Btn);
			String Expectedmsg = agGetText(CIMOSLLReportsPageObjects.statusCompleted);
			agIsVisible(CIMOSLLReportsPageObjects.statusCompleted);
			if (Expectedmsg.equals("COMPLETED")) {
				Reports.ExtentReportLog("", Status.PASS, "Download icon is present and report status is Completed ",
						true);
				break;
			} else
				agSetStepExecutionDelay("5000");
			agClick(FDE_SubmissionTrackingPageObjects.refresh_Btn);

		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to refresh and generate the CIOMS LL
	 *             Reports.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 27-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downloadCIOMSLLReport(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(CIMOSLLReportsPageObjects.downlaodIcon);

		try {
			Thread.sleep(8000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String fileName = getTestDataCellValue(scenarioName, "ReportName");
		agSetStepExecutionDelay("5000");
		CommonOperations.move_DownloadedPDF(fileName);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search CIOMS LL Reports.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndDeleteCIOMSLLReports(String scenarioName) {
		agSetStepExecutionDelay("2000");
		search(scenarioName);
		if (verifysearchData(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS, "CIOMSLL Report exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "ReportName"),
					CIMOSLLReportsPageObjects.get_ListofReportName);
			agSetStepExecutionDelay("2000");
			agJavaScriptExecuctorClick(CIMOSLLReportsPageObjects.deleteCheckBox);
			agJavaScriptExecuctorClick(CIMOSLLReportsPageObjects.delete_Btn);
			agWaitTillInvisibilityOfElement(CIMOSLLReportsPageObjects.deleteMessage);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} else {
			Reports.ExtentReportLog("", Status.INFO, "CIOMSLL Report Not exists!", true);
		}
		agIsVisible(CIMOSLLReportsPageObjects.cimosLLReportsSearchTextbox);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created search the new CIOMSLL Report
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 02-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchCIOMSLLReports(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		search(scenarioName);
		String paginator = agGetText(CIMOSLLReportsPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "ReportName"),
					CIMOSLLReportsPageObjects.get_ListofReportName);
			Reports.ExtentReportLog("", Status.PASS, "Search CIOMSLL Report: CIOMSLL Report Listed" + scenarioName,
					true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Search CIOMSLL Report: CIOMSLL Report  Not Listed" + scenarioName,
					true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

}