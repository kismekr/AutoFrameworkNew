package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDEMoreOptionsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.OutofWorkFlowPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class OutofWorkflowListingOperations extends ToolManager{
	public static WebElement webElement;
	static String className = OutofWorkflowListingOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to select dropdown value in outofWorkFlow listing.
	 * @InputParameters: LabelName, value
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void setDropDown_outofWorkFlow(String LabelName,String columnName){
	        agClick(OutofWorkFlowPageObjects.clickDropDown(LabelName));
	        agClick(OutofWorkFlowPageObjects.selectDropdown(columnName));
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to perform search in outofWorkFlow listing.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void outofWorkFlowSearch(String scenarioName){
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(CaseListingPageObjects.searchLinks(CaseListingPageObjects.outOfWorkflowSearch_link));
		//setDropDown_outofWorkFlow("Out of workflow Status",getTestDataCellValue(scenarioName, "OutofworkflowStatus"));
		agSetValue(OutofWorkFlowPageObjects.receiptNoTextBox,getTestDataCellValue(scenarioName, "ReceiptNo"));
		agClick(OutofWorkFlowPageObjects.searchButton);
		CommonOperations.waitTillCaseVisible();
		Reports.ExtentReportLog("", Status.INFO,"Case is successfully listed in Out of WorkFlow listing", true);
		
	}
	
	
	
	
	
	
	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
	
	/**********************************************************************************************************
	 * @Objective: This method is created to Write data into excel sheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, columnName, data);
	}
}