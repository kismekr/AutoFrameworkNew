package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import com.arisglobal.framework.lib.main.ToolManager;

public class CodingPageObjects extends ToolManager {
	
	public static String codingHover = "xpath#//a[@class='ui-menuitem-link ui-submenu-link ui-corner-all']/span[contains(text(),'Coding')]";
	public static String codingInboxandReviewMedDRA = "xpath#//a[@id='headerForm:codingInbox']//span[@class='ui-menuitem-text'][contains(text(),'Coding Inbox and Review-MedDRA')]";
	public static String codingInboxMedraHeader = "xpath#//span[text()='Coding Inbox - MedDRA']";
	public static String codingInboxandReviewWhoDD = "xpath#//a[@id='headerForm:whoddCodingInbox']//span[@class='ui-menuitem-text'][contains(text(),'Coding Inbox and Review-WHO DD')]";
	public static String codingInboxWhoDDHeader = "xpath#//span[text()='Coding Inbox - WHO DD']";

	public static String gridcolumnPreferenceIcon ="xpath#//span[@class='lsmv-col-sel-icon']";
	public static String selectAllColumns = "xpath#//input[@class='selectAllCustColChkbox']";
	public static String closeColumnPreferencePopUp = "xpath#//span[@class='close-lsmv-hover-popup']";
	public static String saveGridCustom = "xpath#//span[@class='lsmv-grid-custom-save']";
	public static String saveConfirmation = "xpath#//span[text()='Grid Column Preference saved successfully.']";
	
	
	public static String aerNO = "xpath#//span[text()='AER NO.']";
	public static String receiptNO = "xpath#//span[text()='RECEIPT NO.']";
	public static String productNameAsReporter = "xpath#//span[text()='PRODUCT NAME AS REPORTED']";
	public static String dictionaryVersion = "xpath#//span[text()='DICTIONARY VERSION']";
	public static String submissionDueDate = "xpath#//span[text()='SUBMISSION DUE DATE']";
	public static String caseDueDate = "xpath#//span[text()='CASE DUE DATE']";
	public static String centralCodingReceivedDate = "xpath#//span[text()='CENTRAL CODING RECEIVED DATE']";
	public static String caseSeriousness = "xpath#//span[text()='CASE SERIOUSNESS']";
	public static String routeoFAdmin =  "xpath#//span[text()='ROUTE OF ADMIN']";
	public static String indication = "xpath#//span[text()='INDICATION']";
	public static String matchFound = "xpath#//span[text()='MATCH FOUND']";
	public static String codingComment = "xpath#//span[text()='CODING COMMENT']";
	public static String processingUnit = "xpath#//span[text()='PROCESSING UNIT']";
	public static String resolved = "xpath#//span[text()='RESOLVED']";
	public static String caseOwner = "xpath#//span[text()='CASE OWNER']";
	public static String reportedTerm = "xpath#//span[text()='REPORTED TERM']";
	public static String termType = "xpath#//span[text()='TERM TYPE']";
	public static String productDescription = "xpath#//span[text()='PRODUCT DESCRIPTION']";
	public static String receivedDate = "xpath#//span[text()='RECEIVED DATE']";
	public static String eventSeriousness = "xpath#//span[text()='EVENT SERIOUSNESS']";
	
	public static String clickExportIcon = "xpath#//span[@class='lsmv-grid-export-icon']";
	public static String exportConfigurationHeader = "xpath#//span[text()='Data Export Configurations']";
	public static String exportAsExcelBtn = "xpath#//span[text()='Export As Excel']";
	public static String exportAsPDFBtn = "xpath#//span[text()='Export As PDF']";
	public static String cancel = "xpath#//span[text()='Cancel']";
	
	public static String filterIcon = "xpath#//span[@class='lsmv-grid-quick-filter-icon']";
	public static String receiptNoInput = "xpath#//div[@fieldid='receiptNo']//input[@class='quickFilterInputCmp']";
	public static String filterAerNo = "xpath#//div[@fieldid='aerNo']//input[@class='quickFilterInputCmp']";
	public static String noRecordFound = "xpath#//div[text()=' No records to display']";

	public static String clickFilterCriteria = "xpath#//span[@title='Click to show filter criteria']";
	public static String filterCriteriaReceiptNo = "xpath#//div[@class='form-group']//input[@fieldid='receiptNo']";
	public static String searchBtn = "xpath#//span[text()='Search']";
	public static String clearBtn = "xpath#//span[text()='Clear']";
	public static String closeBtn = "xpath#//span[text()='Close']";
	
	public static String inputreceiptNo ="xpath#//input[@class='inputCmpClass lsmvGridSearchCmp']";
	public static String clickSearch = "xpath#//span[@class='lsmv-search-icon']";
	public static String clickProductName = "xpath#//span[text()='Actin']";
	public static String codingBrowser = "xpath#//div[@class='lsmv-popup-header']";
	public static String begensWithCheckBox = "xpath#//input[@title='Begins with']";
	public static String btnSearch = "xpath#//span[@id='btnSearch']";
	public static String searchLoader = "xpath#//img[@id='headerForm:j_id_1f']";
	public static String checkSearchProduct = "xpath#//div[text()='ACTINE']//parent::div//parent::div/span[@class='lsmv-grid-row-sel-chk lsmv-grid-sel-unchk']";
	public static String clickClassifyBtn = "xpath#//span[text()='Classify']";
	public static String multipleMatchTermPopUp= "xpath#//span[text()='Multiple matching terms are available. Do you want to classify all ?']";
	public static String yesBtn = "xpath#//button[text()='Yes']";
	public static String classifyConfirmation= "xpath#//div[@class='lsmv-info-popup-body']/span[text()='Term(s) Classified Successfully.']";
	
	public static String viewDD = "xpath#//select[@id='triageSelector']";
	public static String vtaViewDD = "xpath#//select[@id='vtaTriageSelector']";
	public static String viewDropdownSelect = "xpath#//option[text()='{0}']";
	public static String verifyYes = "xpath#//span[text()='RESOLVED']//parent::div//parent::div//parent::div//parent::div//parent::div//div[text()='Yes']";
	public static String verifyResolvedProduct = "xpath#//span[text()='Actin']//parent::div//parent::div//parent::div//div[text()='Yes']";
	
	public static String dictionaryCodingBrowserPopUp = "xpath#//span[text()='Dictionary Coding Browser']";
	public static String VTAReviewAndApprovalTab = "xpath#//span[@id='vtaReviewApprovalTab']";
	public static String searchInVTAReview = "xpath#//div[@id='targetPanelForVtaReviewApprovalGrid']//input[@class='inputCmpClass lsmvGridSearchCmp']";
	public static String searchIcon = "xpath#//div[@id='targetPanelForVtaReviewApprovalGrid']//span[@class='lsmv-search-icon']";
	public static String clickSearchResult = "xpath#//span[text()='FEVER M']";
	public static String clickCheckBox= "xpath#//span[text()='FEVER M']//parent::div//parent::div//parent::div/span[@class='lsmv-grid-row-sel-chk lsmv-grid-sel-unchk']";
	public static String approveVTABtn  ="xpath#//span[text()='Approve']";
	public static String approveConfirmation = "xpath#//span[text()='Term(s) Approved Successfully!']";
	
	public static String VTAReviewAndApprovalWhoDDTab = "xpath#//span[@id='vtaReviewTab']";
	public static String searchInVTAReviewWhoDD= "xpath#//div[@id='targetPanelForWhoddVtaReviewApprovalGrid']//input[@class='inputCmpClass lsmvGridSearchCmp']";
	public static String WhoDDsearchIcon = "xpath#//div[@id='targetPanelForWhoddVtaReviewApprovalGrid']//span[@class='lsmv-search-icon']";
	public static String WhoDDclickCheckBox= "xpath#//span[text()='Actin']//parent::div//parent::div//parent::div/span[@class='lsmv-grid-row-sel-chk lsmv-grid-sel-unchk']";
	public static String VTASecondLevelYesBtn = "xpath#//div[@id='addTowhoddVtaConfirmationDialog']//parent::div//button[text()='Yes']";
	public static String multipleMatchTermSecondLevelPopUp = "xpath#//span[text()='Do you want to add to VTA List ?']";
	public static String VTAApprovalMsg = "xpath#//span[@class='VTA(s) Added & Term(s) Approved Successfully!']";
	public static String VTAApprovedYes = "xpath#//span[text()='APPROVED']//parent::div//parent::div//parent::div//parent::div//parent::div//div[text()='Yes']";
	
	
	
	public static String selectViewDroprdown(String label) {
		String value = viewDropdownSelect.replace("{0}", label);
		return value;
	}

}
