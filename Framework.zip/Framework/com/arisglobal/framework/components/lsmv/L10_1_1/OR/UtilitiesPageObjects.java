package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import org.openqa.selenium.By;

public class UtilitiesPageObjects {
	
	public static String e2BValidatorLink  = "xpath#//span[contains(text(),'E2B Validator')]";
	public static String formDesignerLink = "xpath#//span[contains(text(),'Form designer')]";
	public static String formDesignerLabel = "xpath#//div[@class='CaseList_Title']/label[text()='Form Designer']";
	public static String e2BMetatdataLink = "xpath#//span[contains(text(),'E2B Metatdata')]";
	public static String e2BMetatdataLabel= "xpath#//label[@id='xmlLibListform:depttitleId']";
	public static String bulkImportConfigLink = "xpath#//span[contains(text(),'Bulk import configurations')]";
	public static String bulkImportConfigLabel = "xpath#//label[@id='importConfigListForm:j_id_lk']";
	public static String dictionaryImportLink = "xpath#//span[contains(text(),'Dictionary import')]";
	public static String dictionaryImportLabel = "xpath#//form[@id='dictionaryimportform']//following-sibling::app-root[1]//child::app-dictionary-status[1]/child::div[1]/child::h5[1]";
	public static String dictionaryImpactAnalysisLink = "xpath#//span[contains(text(),'Dictionary impact analysis')]";
	public static String case_libraryImpactAnalysisLink = "xpath#//span[contains(text(),'Case/library impact analysis')]";
	public static String e2BValidatorLabel  = "xpath#//span[contains(text(),'Validate')]";
	public static String formKeywordSearch  = "xpath#//input[@id='formList:keyword']";
	public static String E2BMETADATAKeywordSearch  = "xpath#//input[@id='xmlLibListform:keywordSearch']";
	public static String bulkImportConfigKeywordSearch  = "xpath#//input[@id='importConfigListForm:searchText']";
	public static String dictionaryImportKeywordSearch  = "xpath#//input[@placeholder='Keyword Search']";
	public static String dictionaryImpactAnalysisLabel  = "xpath#//div[contains(text(),'Select Dictionary Type :')]";
	public static String caseImpactAnalysisLabel  = "xpath#//label[contains(text(),'Dictionary Type:')]";
	
	
	
}
