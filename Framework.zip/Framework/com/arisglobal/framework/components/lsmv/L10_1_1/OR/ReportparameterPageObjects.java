package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class ReportparameterPageObjects {

	public static String medWatchLink = "xpath#//div[@id='reportParamsGrid']//span[@title='MedWatch']";
	public static String ciomsLink = "xpath#//div[@id='reportParamsGrid']//span[@title='CIOMS']";
	public static String ciomsLink_LL = "xpath#//div[@id='reportParamsGrid']//span[@title='CIOMS_LL']";
	public static String BfArMLink = "xpath#//div[@id='reportParamsGrid']//span[@title='BfArM']";
	public static String reportTypeHeader = "xpath#//div[@id='leftPanel']/div/span[contains(text(),'Report Type')]";
	public static String ciomsHeader = "xpath#//span[contains(text(),'Report Parameters > CIOMS ')]";
	public static String medWatchHeader = "xpath#//span[contains(text(),'Report Parameters > MedWatch')]";
	public static String cioms_LLHeader = "xpath#//span[contains(text(),'Report Parameters > CIOMS_LL')]";
	public static String BfArMHeader = "xpath#//span[contains(text(),'Report Parameters > BfArM')]";
	public static String dataOfReport = "2";
	public static String printMfrContactNo = "3";
	public static String dateFormat = "7";
	public static String versionWithTerm = "9";
	public static String pharmaCovComments = "956112";
	public static String saveReportParameter = "xpath#//span[@id='saveBtnId']";

	public static String cimosReportDropdown = "xpath#//div[@fieldid='parameterValue']//select[@fieldid='parameterValue'][@id='%s']";
	public static String searchIcon = "xpath#//div[@class ='lsmv-field-text']/span[@class='lsmv-search-icon']";
	public static String cimosReportDropdownValue = "xpath#//option[contains(text(),'%s')]";
	public static String set_Textfields = "xpath#//div[@fieldid='parameterName']//div[text()='%s']//parent::div//parent::div//parent::div//input[@fieldid='parameterValue']";

	public static String medWatchVersionWithTerm = "300003";
	public static String printMultiplePrimaryReporters = "300004";
	public static String pharmacovigilanceComments = "300001";

	public static String drugIndicationWithDrugName = "4006";
	public static String codeDecodeOfDisease = "4008";
	public static String causalityAssignment = "4009";
	public static String printLiteratureData = "4013";
	public static String printLabData = "4014";
	public static String labrotaryDataFormat = "4017";
	public static String printPharmacovigilanceComments = "4018";
	public static String printCausalityInformation = "4020";
	public static String printFollowupNoOrVersionNo = "4007";
	public static String printLLTOrPT = "4010";
	public static String printMedDRACodeWithDecodes = "4011";
	public static String PrintMedDRAVersion = "4012";
	public static String DateofReportnotAvailableinIArecord = "4001";

	// CIOMS LL Report

	public static String causality = "xpath#//select[@fieldid='parameterValue'][@id='100001']";
	public static String medraCode = "xpath#//select[@fieldid='parameterValue'][@id='100002']";
	public static String LLT_PTCode = "xpath#//select[@fieldid='parameterValue'][@id='100003']";
	public static String pvComments = "xpath#//select[@fieldid='parameterValue'][@id='100004']";
	public static String eventDescription = "xpath#//select[@fieldid='parameterValue'][@id='100006']";
	public static String mostSuspectProduct = "xpath#//select[@fieldid='parameterValue'][@id='100007']";
	public static String productIngrdients = "xpath#//select[@fieldid='parameterValue'][@id='100008']";
	public static String seriousNess = "xpath#//select[@fieldid='parameterValue'][@id='100009']";
	public static String labeling = "xpath#//select[@fieldid='parameterValue'][@id='100010']";
	public static String AERNumberVersion = "xpath#//select[@fieldid='parameterValue'][@id='100012']";

	public static String titlePharmacovigilanceLable = "Title for the Pharmacovigilance Comments";
	public static String pageTitle = "Parameter configure as to what can be printed in the Page Title";
	public static String companyUnt = "Parameter configure as to print company unit";

	public static String selectGeneralDroprdown(String label) {
		String value = cimosReportDropdown.replace("%s", label);
		return value;
	}

	public static String clickDropDownValue(String data) {
		String value = cimosReportDropdownValue.replace("%s", data);
		return value;
	}

	public static String set_Textfields(String label) {
		String value = set_Textfields.replace("%s", label);
		return value;
	}
}
