package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import org.openqa.selenium.By;

public class SchedulersPageObjects {
	
	public static String schedulersClick = "xpath#//a[@id='headerForm:schedulersId']//ancestor::span[1]";
	public static String stopE2BImportScheduler = "xpath#//a[contains(@id,'schlistForm:schDataTable:14')]/img[contains(@id,'error')]";
	public static String startE2BImportScheduler = "xpath#//a[contains(@id,'schlistForm:schDataTable:14')]/img[contains(@id,'start1')]";
	public static String okButton = "xpath#//button[@id='mandatoryDialogform:okButton']";
	public static String emailInbound = "xpath#//tbody[@id='schlistForm:schDataTable_data']/tr/td/a[@id='schlistForm:schDataTable:20:Edit']";
}
