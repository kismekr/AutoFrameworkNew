package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import com.arisglobal.framework.lib.main.ToolManager;

public class SubmissionPageObjects extends ToolManager {

	public static String submissionListing = "xpath#//span[contains(text(),'Submission listing')]";
	public static String failedDistribution = "xpath#//span[contains(text(),'Failed distribution')]";
	public static String failedDistributionLabel = "xpath#//div[@id='SFDL:breadCrumbsLabelId']/label[text()='Failed Distribution Cases']";
	public static String submissionListingLable = "xpath#//div[@class='CaseList_Title']/label[text()='Submission Listings']";

	public static String unreadCorrespondence = "xpath#//span[contains(text(),'Unread correspondence')]";
	public static String unreadCorrespondenceLable = "xpath#//div[@class='CaseList_Title']/label[text()='Unread Correspondence']";
	public static String unresolvedCorrespondence = "xpath#//a[@id='headerForm:submissionUnresolvedCorrespondenceId']//span[@class='ui-menuitem-text'][contains(text(),'Unresolved correspondence')]";
	public static String unresolvedCorrespondenceLable = "xpath#//div[@class='CaseList_Title']/label[text()='Unresolved Correspondence']";
	public static String outofworkflowListing = "xpath#//span[contains(text(),'Out of workflow listing')]";
	public static String outofworkflowListingLable = "xpath#//span[@class='ui-panel-title']/label[text()='General']";
	public static String submissionReports = "xpath#//span[contains(text(),'Submission reports')]";
	public static String submissionReportsLable = "xpath#//span[@class='ui-panel-title']/label[text()='General']";

	// Submission Module Menu Navigation validation point
	public static String submissionMenu = "xpath#//div[@id='headerForm:menuMainId']//ul[@class='ui-menu-list ui-helper-reset']/child::li/a/span[contains(text(),'Submission')]/following::ul/li/a/span[contains(text(),'%s')]";
	public static String submissionHover = "xpath#//a[@class='ui-menuitem-link ui-submenu-link ui-corner-all']//span[@class='ui-menuitem-text'][contains(text(),'Submission')]";
	public static String submissionSubMenu = "xpath#//div[@id='headerForm:menuMainId']//ul[@class='ui-menu-list ui-helper-reset']/child::li/a/span[contains(text(),'Submission')]//following::ul/li/a/following::ul/li/a/span[contains(text(),'%s')]";
	public static String correspondenceHover = "xpath#//li[@id='headerForm:submissionCorrespondenceId']/child::a[1]/child::span[text()='Correspondence']";
	public static String submissionListingKeywordSearch = "xpath#//input[@placeholder='Search...']";
	public static String submissionFailedKeywordSearch = "xpath#//input[@id='SFDL:keywordSearch']";
	public static String submissionUnreadCorrKeySearch = "xpath#//input[@id='unreadCorrListform:keywordSearch']";
	public static String submissionUnresloveCorrKeySearch = "xpath#//input[@id='unresolvedCorrespondenceForm:keyword']";
	public static String submissionOutofWorkflowSubID = "xpath#//input[@id='submissionArchiveAdvanceform:uniqueId']";
	public static String submissionReportsLatestdate = "xpath#//input[@id='submissionReportsForm:latestReceivedFromId_input']";
	public static String submissionListingsHeader = "xpath#//label[@id='SDL:j_id_1h0']";

	public static String SubmissionListingCheckboxRow = "xpath#//tr[@data-ri='%s']//div[@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default']";
	public static String PrintBtnhover = "xpath#//div[@class='DelCommon deleteNewUI subDelCommon']//a[text()='Print']";
	public static String printbtnmenu = "xpath#//a[text()='Print']/parent::div/following-sibling::div//a[text()='%s']";
	public static String DocumentCloseBtn = "xpath#//div[@id='openDocumentDiolog:documentDialog']//a[@aria-label='Close']";
	public static String LocalSubmissionBtn = "xpath#//a[contains(text(),'Local Submission')]";
	public static String EditAER = "xpath#(//span[contains(text(),'%s')])[1]";
	public static String ActivityLabelSubmit = "xpath#//div[@id='submissionMessageNew:j_id_3ab']";
	public static String SubmissionworkflowNote = "xpath#//textarea[@name='submissionWfNotesForm:noteTextArea']";
	public static String SubmissionworkflowAddBtn = "xpath#//button[@id='submissionWfNotesForm:addwfNotesID']//span";
	public static String LocalSubmissionValidation = "xpath#//label[text()='Local Submission']";

	// public static String
	// SubmissionSearchBox="xpath#//input[@placeholder='Search...']";
	public static String SubmissionSearchBox = "xpath#//input[@placeholder='Search...']";
	// public static String SearchIcon = "xpath#//span[@class='lsmv-search-icon']";
	public static String SearchIcon = "xpath#//span[@class='lsmv-grid-search-icon']";
	// public static String SearchIcon="xpath#//a[@id='SDL:searchId']";
	// public static String
	// aerNumberlink="xpath#//span[contains(@onclick,'editSubmissionMessage')]";
	public static String aerNumberlink = "xpath#//span[contains(@onclick,'editSub')]";
	public static String reportingStatus_Dropdown = "Reporting Status";
	public static String dateInformedTextBox = "xpath#//input[@id='submissionMessageNew:dateInformedNew_input']";
	public static String clickReportStatus = "xpath#//label[@id='submissionMessageNew:reportingStatusNew_label']";
	public static String setReportStatus = "xpath#//ul[@id='submissionMessageNew:reportingStatusNew_items']/child::li[text()='%s']";
	public static String setWorkflownotes = "xpath#//textarea[@id='submissionWfNotesForm:noteTextArea']";
	public static String workflownotesadd_btn = "xpath#//button[@id='submissionWfNotesForm:addwfNotesID']/span[contains(text(),'Add')]";
	public static String ok_btn = "xpath#//button[@id='mandatoryDialogform:okButton']/span[contains(text(),'OK')]";
	public static String generalEmailAddress = "xpath#//textarea[@id='submissionMessageNew:emailid']";
	public static String generalCCEmailAddress = "xpath#//textarea[@id='submissionMessageNew:ccEmailid']";

	// Submission and OutofWorkflow Listing
	public static String submissionListingAdvanceSearch = "xpath#//a[text()='Advanced Search']";
	public static String submissionListingDistributedDateText = "xpath#//label[@id='submissionAdvanceform:j_id_25s']";
	public static String submissionListingSubmissiondueFromDate = "xpath#//input[@name='submissionAdvanceform:submission_due_date_from_input']";
	public static String submissionListingSubmissiondueToDate = "xpath#//input[@name='submissionAdvanceform:submission_due_date_to_input']";
	public static String submissionListingAdvSearchBtn = "xpath#//div[@class='inner-but']//button[@id='submissionAdvanceform:advanceSearchButton']";
	public static String submissionListingsTextLoad = "xpath#//label[@id='SDL:j_id_1fy']";
	public static String submissionListingReset_btn = "xpath#//span[contains(text(),'Reset')]";
	public static String submissionListingSavedCriteriaLoad = "xpath#//label[contains(text(),'Saved Criteria')]";
	public static String submissionListingAERNO = "xpath#//input[@id='submissionAdvanceform:fileNameId']";
	public static String submissionOutofWorkflowDistFromDate = "xpath#//input[@name='submissionArchiveAdvanceform:submission_gen_Date_from_input']";
	public static String submissionOutofWorkflowDistToDate = "xpath#//input[@name='submissionArchiveAdvanceform:submission_gen_Date_to_input']";
	public static String submissionOutofWorkflowResubmitLoad = "xpath#//label[contains(text(),'Re-submit')]";
	public static String submissionOutofWorkflowBack_btn = "xpath#//Span[contains(text(),'Back')]";
	public static String submissionLoading = "xpath#//label[@id='submissionXmlViewForm:j_id_4yu']";
	public static String submissionOutofWorkflowSearch_Btn = "xpath#//button//span[text()='Search']";
	public static String submissionOutofWorkflowAERNO = "xpath#//input[@name='submissionArchiveAdvanceform:fileNameId']";
	public static String submissionListingAERLook_UP = "xpath#//img[@title='Submission Aer Lookup']";
	public static String submissionListingAERLook_UPlabel = "xpath#//span[text()='Submission AER Lookup']";
	public static String submissionAER_Search = "xpath#//span[text()='Search ']";
	public static String submission_SearchResultslabel = "xpath#//div[text()='Search Results']";
	public static String submission_AERCheckBox = "xpath#//tbody[@id='submissionAerLookupForm:submissionAerNoTable:submissionLookUpDataTableMulti_data']/tr[@data-ri='0']/td/div/div/span";
	public static String submission_AEROKBtn = "xpath#//button[@name='submissionAerLookupForm:bottomOkButton']//span[text()='OK']";
	public static String submissionOutofWorkFlowAER_ChckBox = "xpath#//tr[@data-ri='0']//span";
	public static String submissionOutofWorkFlow_AdvSearch = "xpath#//button[@id='submissionArchiveAdvanceform:advanceSearchButton']";
	public static String AllEnabledCheckBoxes = "xpath#(//span[@class='ui-chkbox-icon ui-icon ui-c ui-icon-check'])[2]";
	public static String submissionPaginator = "xpath#//div[@id='SDL:SDT_paginator_top']";
	// public static String
	// Loading="xpath#//label[@id='submissionXmlViewForm:j_id_4yu']";

	public static String refershIcon = "xpath#//div[@class='gridSearchBarleft']/span";

	// Masking in submission listing
	public static String reportFormat = "xpath#//span[text()='%s']";
	public static String FDA = "FDA 3500A";
	public static String BfArM = "BfArM";
	public static String CIMOS = "CIOMS I";
	public static String E2B = "E2B";
	public static String Paginator = "xpath#//div[@class='lsmv-grid-pager-class']";
	public static String filter_icon = "xpath#//span[@class='lsmv-grid-quick-filter-icon']";
	public static String Contactname_textbox = "xpath#//div[@title='Contact Name']/div/span[text()='Contact Name']/following::input[@fieldid='recepient']";
	public static String AERNo_textbox = "xpath#//div[contains(@title,'AER')]/div/span[contains(text(),'AER')]/following::input[@fieldid='aerNumber']";
	public static String Pdfdownload = "xpath#//button[@id='download']";
	public static String Patientinfo_label = "xpath#//div[text()='A. PATIENT INFORMATION']";
	public static String Pdfframeid = "openDocumentDiolog:test_adv";
	public static String cancelIcon = "xpath#//span[@id='openDocumentDiolog:documentDialog_title']/following-sibling::a[1]";
	public static String ReportFormatclick = "xpath#//span[text()='FDA3500A (Drug)']";
	public static String ReportFormat = "xpath#//div[@title='Report Format']/div/span[text()='Report Format']/following::input[@class='select2-search__field'][1]";
	public static String Reportformatfilter = "xpath#//div[@class='ui-selectcheckboxmenu-items-wrapper']/ul/li/div/child::div/following::label[text()='%s']";
	public static String reportformatlink = "xpath#//a[text()='']";
	public static String ReportFormatE2BClick = "xpath#//li[text()='E2B']";
	public static String SelectAllCheckBox = "xpath#//span[@class='lsmv-grid-sel-all-chk lsmv-grid-sel-unchk']";
	public static String DownloadButtonHover = "xpath#(//span[text()='Download'])[1]";
	public static String PrintButtonHover = "xpath#(//span[text()='Print'])[1]";
	public static String DownloadAsBatch = "xpath#//a[text()='Download As Batch']";
	public static String DownloadAsBulk = "xpath#//a[text()='Download As Bulk']";
	public static String BatchPrint = "xpath#//a[text()='Batch Print']";
	public static String BulkPrint = "xpath#//a[text()='Bulk Print']";
	public static String checkBox = "xpath#(//span[contains(@class,'lsmv-grid-row-sel-chk')][1])";
	public static String CheckBoxBulkAndBatch = "xpath#(//span[contains(@class,'lsmv-grid-row-sel-chk')][1])[%index]";
	public static String DownloadContactName = "xxpath#//div[@fieldId='recepient']//div//div//span//child::span";
	public static String LoadingIcon = "img[@id='headerForm:j_id_1f']";

	public static String messageNo1 = "xpath#(//div[@fieldid='messageNo'])[3]";
	public static String messageNo2 = "xpath#(//span[contains(text(),'EV')]//following-sibling::div)[2]";
	public static String processingIcon = "xpath#//span[@class='lsmv-process-icon']";
	public static String clickXML = "xpath#//span[text()='E2B']";
	public static String downloadButton = "xpath#//button[@id='submissionXmlViewForm:viewFileLink3']";
	public static String closeDownloadPopUp = "xpath#//span[text()='Close']";
	public static String contactname = "xpath#//span[contains(@onclick,'viewSubmission')]/span[text()='%s']";

	public static String CoverLetterDocumentVerification = "xpath#//a[@id='submissionMessageNew:viewAttchCoverLetter']";
	public static String SourceDocumentVerification = "xpath#//a[contains(@id,'reportFormatView')]";

	public static String AdditionalDocumentUpload = "xpath#//input[@id='submissionUploadForm:uploadDocId_input']";
	public static String LocalDriveUploadDocumnetBtn = "xpath#//div[@id='submissionMessageNew:localDrivePanelId']//a[contains(@class,'ui-commandlink ui-widget displayUpload')]";
	public static String UploadDocumentPopUp = "xpath#//div[@id='submissionUploadForm:submissionUploadDialogId']";
	public static String DocumentDescription = "xpath#//textarea[@id='submissionUploadForm:docDescription']";
	public static String SubmitBtn = "xpath#//button[@id='submissionUploadForm:submissionUploadSubmit']";
	public static String LocalDriveDocFileName = "xpath#//label[contains(text(),'.pdf')]";
	public static String LocalDocumentVerification = "xpath#//a[contains(@id,'viewAttachFileLink1')]";

	// Regenerate operations
	public static String regenerateBtn = "xpath#//span[text()='Regenerate']";
	public static String validationpopUp = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String okBtn = "xpath#//button[contains(@id,'mandatoryDialogform:okButton')]";

	// Submission local labelling
	public static String addBtn = "xpath#//button[@id='submissionMessageNew:ostadd']/span[text()='Add']";
	public static String selectAllDropdown = "xpath#//thead[@id='submissionMessageNew:ostlocalLabellingDataTable_head']//following::tbody//select[contains(@id,'ostlocalLabellingDataTable:%index%:%id%')]";
	public static String saveBtn = "xpath#//button[@id='submissionMessageNew:editSaveId']";
	public static String product = "drugTableList";
	public static String lowlevelTerm = "lltCodeTableList";
	public static String productType = "prodTypeList";
	public static String productCharacterization = "drugTypeList";
	public static String preferedTerm = "ptTermTableList";
	public static String medraVersion = "medraVersionOstValueId";
	public static String reportedTerm = "reactionTableList";
	public static String countryLabeling = "countryTableList";
	public static String labelled = "localLabellingTableList";
	public static String dropDownListItem = "xpath#//li[text()='{0}'][contains(@id,'{1}')]";

	// Local Data Entry
	public static String localDataEntry = "xpath#//a[@id='submissionMessageNew:localDataEntry']//span[text()='Local Data Entry']";
	public static String aerno_Link = "xpath#(//div[@id='submissionListingPanel']//div[@fieldid='aerNumber']//div/following::span[contains(@onclick,'editSubmissionMessage')])[1]";
	public static String localLabeling = "xpath#//span[text()='Local labelling']";
	public static String locator = "xpath#//label[contains(@id,'ostlocalLabellingDataTable:%index%:%id%Lsmv_label')]";
	public static String countryLocator = "xpath#//label[contains(@id,'ostlocalLabellingDataTable:%index%:%id%_label')]";
	public static String verifyLabels = "xpath#//label[contains(@id,'ostlocalLabellingDataTable:%index%:%id%')]";

	public static String REgulatoryDocumnet = "xpath#//tbody//a[contains(@id,'reportFormatViewId')]";
	// Document
	public static String DocumentSubmisionTab = "xpath#//a[@id='submissionMessageNew:documents']";

	// Informed Authority
	public static String InformedAuthorityTab = "xpath#//a[@id='submissionMessageNew:informedAuthority']";
	public static String InformedAuthorityBfarmReport = "xpath#//tbody[@id='submissionMessageNew:InformedAuthorityDataNew_data']//td[text()='BfArM']";

	public static String ContactName = "xpath#//span[contains(@onclick,'viewSubmission')]//span[text()='%s']";
	public static String CoverDocumnentVerifcation = "xpath#//a[contains(@id,'submissionMessageNew:viewAttchCoverLetter')]";
	public static String ReportFormatE2B = "xpath#//span[text()='%s']/ancestor::div[@fieldid='recepient']/following-sibling::div//span[text()='E2B']";
	public static String ReportFormatNonE2B = "xpath#//span[text()='%s']/ancestor::div[@fieldid='recepient']/following-sibling::div[@fieldid='reportFormat']//span";
	public static String ReportFormatNonE2B_iframeID = "openDocumentDiolog:test_adv";
	public static String ReportFormatE2BEasyView_iframeID = "openEasyViewDiolog:test_adv";
	public static String ReportFormatE2B_iframeID = "openRctCaseSummaryDiolog:test_adv";
	public static String EasyViewBtn = "xpath#//button[@id='submissionXmlViewForm:easyViewXml']//span";
	public static String ReportFormat_cancelIcon = "xpath#//span[@id='openEasyViewDiolog:easyViewDialog_title']/following-sibling::a[1]";
	public static String ReportFormatNonE2B_CancelIcon = "xpath#//div[@id='openDocumentDiolog:documentDialog']//a";
	public static String XmlReportCloseIcon = "xpath#//button[contains(@id,'submissionXmlViewForm')]/span[text()='Close']";
	public static String ReportFormatE2B_CancelIcon = "xpath#//div[@id='openRctCaseSummaryDiolog:rctCaseSummaryDialog']//a";
	public static String ReportFormatHover = "xpath#//span[text()='%s']/ancestor::div[@fieldid='recepient']/following-sibling::div//span[@class='listing_reports']";
	public static String ReportFormatHoverClick = "xpath#//span[text()='%s']/ancestor::div[@fieldid='recepient']/following-sibling::div//span//a['%i']";

	public static String listOfContacts = "xpath#//div[@id='submissionListingPanel']/div[@class='lsmv-grid-row']/div[@fieldid='recepient']//div/span[1]/span";
	public static String getSubmissonContacts = "xpath#(//div[@id='submissionListingPanel']/div[@class='lsmv-grid-row']/div[@fieldid='aerNumber']//div/span/span[1])[%count%]";
	public static String localSubmission = "xpath#//label[text()='Local Submission']";
	public static String NullificationIcon = "xpath#(//div[@id='submissionListingPanel']/div[@class='lsmv-grid-row']/div[@fieldid='sucessId']/div[@class='lsmv-grid-col-adjust '])[%count%]/div/span[@class='sub-nullification_review-iocn']";
	public static String noRecToDispLabel = "xpath#//div[text()=' No records to display']";
	public static String OltContact = "xpath#//div[@id='submissionListingPanel']/div[@class='lsmv-grid-row']/div[@fieldid='recepient']//div/span[1]/span[text()='Automation_NonE2B_BfArM']";
	public static String OLTAERNo = "xpath#(//span[contains(text(),'%value')])[1]";

	public static String clickNotReportStatus = "xpath#//label[@id='submissionMessageNew:reasonNew_label']";
	public static String setNotReportStatus = "xpath#//ul[@id='submissionMessageNew:reasonNew_items']/child::li[text()='%s']";
	public static String submissionSave = "xpath#//button[@id='submissionMessageNew:editSaveId']";
	public static String contactSubmissionPopUp = "xpath#//span[@id='mandatoryDialogform:mandatoryID_title']";
	public static String datainformPopUp = "xpath#//span[text()='Action Completed with Validation Error(s)']";
	
	public static String ackOK = "xpath#//button[@id='mandatoryDialogform:okButton']/span[text()='OK']";

	public static String navigateToInformAuthorityTab = "xpath#//div[@id='submissionMessageNew:subFormDetailsTab']//span[text()='Informed Authority']";
	public static String navigateToGeneralTab = "xpath#//div[@id='submissionMessageNew:subFormDetailsTab']//span[text()='General']";
	public static String submissionDueDate = "xpath#//input[@id='submissionMessageNew:subDueDateId_input']";
	public static String expandSourceDocs = "xpath#//div[@class='submicenterLayoutParent1 subtoggleExpand']";
	public static String sourceDocsLink = "xpath#//a[contains(@id,'submissionMessageNew:submissionDocumentsDataTable')]";
	public static String sourceDocsLiteratureCheck = "xpath#//div[contains(@class,'ui-selectbooleancheckbox ui-chkbox ui-widget checkboxBG')]";

	// Verify Activity Due Date
	public static String LoaderIcon = "xpath#//img[@id='headerForm:j_id_1i']";
	public static String ADD = "xpath#//input[@id='submissionMessageNew:activityDueDateId_input']";
	public static String ActionCompletedSucessfully = "xpath#//span[@id='mandatoryDialogform:mandatoryID_title']";
	public static String SubmissionStatus = "xpath#(//div[@id='submissionMessageNew:header']//label)[3]";
	public static String ActionCompletedSucessfullyOK = "xpath#//button[@id='mandatoryDialogform:okButton']";
	public static String SDD = "xpath#//input[@id='submissionMessageNew:subDueDateId_input']";
	public static String cancelBtn = "xpath#//button[@id='submissionMessageNew:editCancelId']";

	public static String submissionViewText = "xpath#//div[@id='submissionXmlViewForm:iframePanelForXmlnew']";
	public static String statusColumnHeader = "xpath#//div[@id='submissionListingPanel']//div/span[text()='Status']";
	
	//E2B XML View
	public static String submissionXMLView_DocListR2Tag = "xpath#//label/font[text()='<documentlist>']";
	public static String submissionXMLView_AddDocR2Tag = "xpath#//label/font[text()='<additionaldocument>']";
	public static String submissionXMLView_AddDocR3Tag_1 = "xpath#(//label/font[contains(text(),'<document')])[1]";
	public static String submissionXMLView_AddDocR3Tag_2 = "xpath#//label/font[contains(text(),'Available')]";

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Distributed contact Name
	 *             from List .
	 * @InputParameters: contName , format
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 03-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String ContactName(String label) {
		String value = ContactName.replace("%s", label);
		return value;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Report Format Based on
	 *             Contact Name.
	 * @InputParameters: contName , format
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 03-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String ReportFormatE2B(String label) {
		String value = ReportFormatE2B.replace("%s", label);
		return value;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Report Format Based on
	 *             Contact Name.
	 * @InputParameters: contName , format
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 03-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String ReportFormatNonE2B(String label) {
		String value = ReportFormatNonE2B.replace("%s", label);
		return value;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Report Format Based on
	 *             Contact Name.
	 * @InputParameters: contName , format
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 03-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String ReportFormatHover(String label) {
		String value = ReportFormatHover.replace("%s", label);
		return value;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Report Format Based on
	 *             Contact Name.
	 * @InputParameters: contName , format
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 03-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String ReportFormatHoverClick(String label, String label1) {
		String value = ReportFormatHoverClick.replace("%s", label);
		String value1 = value.replace("%i", label1);
		return value1;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the labels based on index
	 *             and id
	 * @InputParameters: index,id
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 02-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String verifyLabels(String index, String id) {
		String value = verifyLabels.replace("%index%", index);
		String temp = value.replace("%index%", index);
		String result = temp.replace("%id%", id);
		return result;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to generate xpath based on index and
	 *             id for country locator[change in label]
	 * @InputParameters: index,id
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String countryLocator(String index, String id) {
		String value = countryLocator.replace("%index%", index);
		String temp = value.replace("%index%", index);
		String result = temp.replace("%id%", id);
		return result;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to generate xpath based on
	 *             locator,index and value to select from dropdown.
	 * @InputParameters: id, valueToSelect ,index
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Pooja S
	 * @Date : 02-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectCountryListDropdown(String index, String id, String valueToSelect) {
		String xpath[] = countryLocator(index, id).split("'");
		String resLocator = xpath[1].replace("_label", "");
		String actualLocator = dropDownListItem;
		String tempLocator = actualLocator.replace("{0}", valueToSelect);
		String resultLocator = tempLocator.replace("{1}", resLocator);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to generate xpath based on
	 *             locator,index and value to select from dropdown.
	 * @InputParameters: locator, valueToSelect ,index
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Pooja S
	 * @Date : 02-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectListDropDown(String index, String id, String valueToSelect) {
		String xpath[] = locator(index, id).split("'");
		String resLocator = xpath[1].replace("_label", "");
		String actualLocator = dropDownListItem;
		String tempLocator = actualLocator.replace("{0}", valueToSelect);
		String resultLocator = tempLocator.replace("{1}", resLocator);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to generate xpath based on index and
	 *             id
	 * @InputParameters: id,index
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 02-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String locator(String index, String id) {
		String value = locator;
		String temp = value.replace("%index%", index);
		String result = temp.replace("%id%", id);
		return result;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click the contact name. Input
	 * Parameters: label Scenario Name Parameters:
	 * 
	 * @author:Pooja S:30-Mar-2020 Updated by and when
	 * 
	 **********************************************************************************************************/
	public static String clickContactName(String label) {
		String value = contactname;
		String value2;
		value2 = value.replace("%s", label);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click the report formats. Input
	 * Parameters: label Scenario Name Parameters:
	 * 
	 * @author:Pooja S:30-Mar-2020 Updated by and when
	 * 
	 **********************************************************************************************************/
	public static String clickReportFormat(String label) {
		String value = reportFormat;
		String value2;
		value2 = value.replace("%s", label);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to perform menu navigation by passing
	 * menu name at runtime. Input Parameters: menu Scenario Name Output Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/

	public static String SubmissionMenuNavigations(String menu) {
		String value = submissionMenu;
		String value2;
		value2 = value.replace("%s", menu);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to perform SubMenu navigation by
	 * passing menu name at runtime. Input Parameters: menu Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String SubmissionSubMenuNavigations(String menu) {
		String value = submissionSubMenu;
		String value2;
		value2 = value.replace("%s", menu);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to perform SubMenu navigation by
	 * passing menu name at runtime. Input Parameters: menu Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String PrintButtonNavigation(String menu) {
		String value = printbtnmenu;
		String value2;
		value2 = value.replace("%s", menu);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is Select Check box by its Row Num Input
	 * Parameters: menu Scenario Name Output Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/

	public static String CheckBox(String rownum) {
		String value = SubmissionListingCheckboxRow;
		String value2;
		value2 = value.replace("%s", rownum);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is Select any two Check box from the table Input
	 * Parameters: menu Scenario Name Output Parameters:
	 * 
	 * @author:WajahatUmar S Date :19-Feb-2020 Updated by and when
	 **********************************************************************************************************/
	public static void SelectanytwoCases() {
		for (int i = 0; i < 2; i++) {
			String Value = String.valueOf(i);
			ToolManager.agWaitTillVisibilityOfElement(SubmissionPageObjects.CheckBox(Value));
			ToolManager.agClick(SubmissionPageObjects.CheckBox(Value));
		}
	}

	/**********************************************************************************************************
	 * Objective:The below method Edit AER field/name Input Parameters: label
	 * Scenario Name Output Parameters:
	 * 
	 * @author:WajahatUmar S Date :20-Feb-2020 Updated by and when
	 **********************************************************************************************************/
	public static String EditAEr(String label) {
		String value = EditAER;
		String value2;
		value2 = value.replace("%s", label);
		return value2;

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select dropdown value by passing
	 *                value at runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Mythri Jain Date : 18-Mar-2020 Updated by and when
	 **********************************************************************************************************/

	public static String SetReportStatusDropdown(String runTimeLabel) {
		String value = setReportStatus;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String OLTAERNoClick(String runtimeLabel) {
		String value = OLTAERNo.replace("%value", runtimeLabel);
		return value;
	}

	public static String SetNotReportStatusDropdown(String runTimeLabel) {
		String value = setNotReportStatus;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String getContacts(String count) {
		String value = getSubmissonContacts.replace("%count%", count);
		return value;
	}

	public static String checkNullificationIcon(String count) {
		String value = NullificationIcon.replace("%count%", count);
		return value;
	}

	// Submit Drop down
	public static String selectActivity = "xpath#//div[@class='ButtonDiv selectonmenubt']/div[@id='submissionMessageNew:j_id_4ce']";
	public static String selectActivity_DropDown = "xpath#//ul[@id='submissionMessageNew:j_id_4ce_items']/li[text()='%s']";
	public static String selectActivity_Submit = "Submit";
	public static String selectActivity_DoNotSubmit = "Do Not Submit";

	public static String actions_Btn = "xpath#//button[@id='submissionMessageNew:j_id_4cj']/span[text()='Actions']";
	public static String completeActivity_Btn = "xpath#//td/a[@id='submissionMessageNew:completeActivity']";

	public static String acknowledgement_type = "xpath#(//tbody[@id='mandatoryDialogform:mandatoryDatatable_data']/tr/td/label)[1]";
	public static String acknowledgement_message = "xpath#(//tbody[@id='mandatoryDialogform:mandatoryDatatable_data']/tr/td/label)[2]";

	// Set Reasons
	public static String localSubmission_Menu = "xpath#//a/span[text()='%s']";
	public static String localSubmission_MenuLocalDataEntry = "Local Data Entry";
	public static String localSubmission_MenuInformedAuthority = "Informed Authority";
	public static String LS_ReportingStatus_Dropdown = "xpath#//td/div[contains(@id,'InformedAuthorityDataNew:0')]";
	public static String reportStatus_DropdownSelect = "xpath#//ul[contains(@id,'InformedAuthorityDataNew:0')]/li[text()='%s']";
	public static String reason_TextArea = "xpath#//div/textarea[@id='submissionMessageNew:commentsNew']";

	public static String selectActivity_DropDown(String runTimeLabel) {
		String value = selectActivity_DropDown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String localSubmission_Menu(String runTimeLabel) {
		String value = localSubmission_Menu;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String reportStatus_DropdownSelect(String runTimeLabel) {
		String value = reportStatus_DropdownSelect;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}
	public static String CIOMSLink="xpath#(//a[.='CIOMS I'])[1]";
	public static String reportLink(String reportName) {
		return "xpath#(//a[.='"+reportName+"'])[1]";
		
	}
}
