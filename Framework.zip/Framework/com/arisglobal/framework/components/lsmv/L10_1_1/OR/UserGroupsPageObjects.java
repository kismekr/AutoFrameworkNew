package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class UserGroupsPageObjects {
	
	public static String userGroupNew_label = "xpath#//label[text()='User Group Details']";
	public static String userGroup_TxtField = "xpath#//input[@id='usergroupDetailsForm:groupName']";
	public static String emailAddress_TxtField= "xpath#//input[@id='usergroupDetailsForm:usergroupemails']";
	public static String description_Txtarea= "xpath#//textarea[@id='usergroupDetailsForm:usergroupDesc']";
	public static String groupKeywordSearch= "xpath#//input[@id='usergroupForm:keyword']";
	public static String clickGroupTypeDropdown= "xpath#//label[text()='Group Type']/following::div/span[@class='ui-icon ui-icon-triangle-1-s ui-c']";
	public static String setGroupTypeDropdown= "xpath#//ul[@id='usergroupDetailsForm:groupType_items']/li[text()='%s']";
	public static String save_Btn= "xpath#//button[@id='usergroupDetailsForm:visibleSave']";
	public static String cancel_Btn= "xpath#//button[@id='usergroupDetailsForm:cancelId']";
	public static String validationOk_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']";
 	public static String validation_Popup = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String search_Icon = "xpath#//a[@id='usergroupForm:searchgroups']/img";
	public static String paginator = "xpath#//div[@id='usergroupForm:usergroupDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String refresh_Icon = "xpath#//a[@id='usergroupForm:refreshImage']";
	public static String new_Btn="xpath#//a[@id='usergroupForm:newId']";
	public static String delete_Btn = "xpath#//a[@id='usergroupForm:deleteId']";
	public static String get_UserGroups = "xpath#//tbody[@id='usergroupForm:usergroupDataTable_data']/tr/td[@class='EditIcon']/following-sibling::td[1]";
	public static String edit_Icon= "xpath#//img[@id='usergroupForm:usergroupDataTable:0:editImgId']";
	public static String get_GroupType= "xpath#//label[@id='usergroupDetailsForm:groupType_label']";
	public static String listingScreen_CheckBoxs = "xpath#//td/a[text()='%s']/ancestor::tr/td/div/child::div/span";
	public static String columnHeader = "xpath#(//tbody[@id='usergroupForm:usergroupDataTable_data']/tr/td[@class='EditIcon']/following-sibling::td[1])[{%count}]";
	public static String downloadIcon = "xpath#//a[@id='usergroupForm:actionId']";
	public static String exporttoExcel_link = "xpath#//button[contains(@id,'usergroupForm:excelID')]/span[text()='Export To Excel']";
	public static String exporttoExcel_popup = "xpath#//span[@id='listingForm:columnSelectionDialogId_title']";
	public static String export_Btn= "xpath#//button[@id='usergroupForm:submitId']";
	public static String exportexcelcancel_Btn= "xpath#//button[@id='usergroupForm:cancelDialogId']";
	
	
	
	/**********************************************************************************************************
	 * @Objective:Set group type dropdown value
	 * @Parameters: Case data attribute value
	 * @author:Avinash Date :12-Nov-2019 Updated by and when
	 **********************************************************************************************************/
	public static String setGroupType(String num) {
		String value = setGroupTypeDropdown;
		String value2;
		value2 = value.replace("%s", num);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: Get user group column count 
	 * @Parameters: Case data attribute value
	 * @author:Avinash Date :12-Nov-2019 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderList(String num) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective:The below method is created to select checkbox by passing value at runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name Output
	 * @Parameters:
	 * @author:Avinash K Date :12-Nov-2019 Updated by and when   	 
	**********************************************************************************************************/		
    		
    public static String selectListingCheckbox(String runTimeLabel) {
        String value = listingScreen_CheckBoxs;
        String value2;
        value2 = value.replace("%s", runTimeLabel);
        return value2;
    }
}
