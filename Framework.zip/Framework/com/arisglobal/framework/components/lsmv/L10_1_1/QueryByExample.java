package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_CaseDocumentsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.QueryByExamplePageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;
import com.mysql.cj.ParseInfo;

public class QueryByExample extends ToolManager {
	static String className = QueryByExample.class.getSimpleName();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to navigate to QBE and verify all the
	 *             fields
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 07-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void navigateToQBE(String scenarioName) {
		agSetStepExecutionDelay("10000");
		agIsVisible(QueryByExamplePageObjects.QBEIcon);
		agClick(QueryByExamplePageObjects.QBEIcon);

		int i = 0, sz = agGetWindowCount();
		agSetStepExecutionDelay("5000");
		while (!(sz == 2) && i < 75) {
			sz = agGetWindowCount();
			i++;
			System.out.println("Waiting" + i);
		}
		agGetCurrentWindow();

		status = agIsVisible(QueryByExamplePageObjects.fieldLibraryHeader);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Navigate to QBE Successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Navigate to QBE not Successfully", true);
		}

		agJavaScriptExecuctorClick(QueryByExamplePageObjects.showAllFields);
		verifyAllFieldsCounts(scenarioName);
		verifyExpandCollapsedFieldLibrary();
		// verifyShowAllFields();
	}

	public static void movetoQBETab() {
		agSetStepExecutionDelay("10000");
		agIsVisible(QueryByExamplePageObjects.QBEIcon);
		agClick(QueryByExamplePageObjects.QBEIcon);

		int i = 0, sz = agGetWindowCount();
		agSetStepExecutionDelay("5000");
		while (!(sz == 2) && i < 75) {
			sz = agGetWindowCount();
			i++;
			System.out.println("Waiting" + i);
		}
		agGetCurrentWindow();
		status = agIsVisible(QueryByExamplePageObjects.fieldLibraryHeader);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Navigate to QBE Successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Navigate to QBE not Successfully", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify expand and collapsed
	 *             functionality
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 12-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyExpandCollapsedFieldLibrary() {
		agClick(QueryByExamplePageObjects.expandFieldLibrary);
		status = agIsVisible(QueryByExamplePageObjects.caseUnit);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Field library expanded Successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Field library not expanded Successfully", true);
		}

		agClick(QueryByExamplePageObjects.expandFieldLibrary);
		status = agIsVisible(QueryByExamplePageObjects.caseUnit);
		if (status) {
			Reports.ExtentReportLog("", Status.FAIL, "Field library no collapsed Successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS, "Field library collapsed Successfully", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Show all fields counts
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 09-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyAllFieldsCounts(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String count = getTestDataCellValue(scenarioName, "AllFieldCounts");
		String[] AllFieldCount = count.split("[.]", 0);
		String showAllFieldCounts = AllFieldCount[0];
		System.out.println(showAllFieldCounts);

		List<WebElement> fieldCount = agGetElementList(QueryByExamplePageObjects.showAllFieldsList);
		String fieldsTotal = Integer.toString(fieldCount.size());
		System.out.println(fieldsTotal);

		if (showAllFieldCounts.equalsIgnoreCase(fieldsTotal)) {
			Reports.ExtentReportLog("", Status.PASS, " Show All Field Counts Matched Successfully ", true);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "New Fileds added in the show all Field counts ", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify all the fields
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 07-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyShowAllFields() {
		agAssertVisible(QueryByExamplePageObjects.aeAdditionalInformation);
		agAssertVisible(QueryByExamplePageObjects.aerCloseDate);
		agAssertVisible(QueryByExamplePageObjects.aerNumber);
		agAssertVisible(QueryByExamplePageObjects.aerVersion);
		agAssertVisible(QueryByExamplePageObjects.aesi);
		agAssertVisible(QueryByExamplePageObjects.apgarScore1Min);
		agAssertVisible(QueryByExamplePageObjects.apgarScore10Min);
		agAssertVisible(QueryByExamplePageObjects.apgarScore5Min);
		agAssertVisible(QueryByExamplePageObjects.artgNumber);
		agAssertVisible(QueryByExamplePageObjects.aborginal);
		agAssertVisible(QueryByExamplePageObjects.accessToOCT);
		agAssertVisible(QueryByExamplePageObjects.acknowledgementReceivedDate);
		agAssertVisible(QueryByExamplePageObjects.actionTakenWithDrug);
		agAssertVisible(QueryByExamplePageObjects.actionToBeTaken);
		agAssertVisible(QueryByExamplePageObjects.actionsTakenWithDrug);
		agAssertVisible(QueryByExamplePageObjects.activeSubstance);
		agAssertVisible(QueryByExamplePageObjects.activityComplitionDate);
		agAssertVisible(QueryByExamplePageObjects.activityEntryDate);
		agAssertVisible(QueryByExamplePageObjects.activityName);
		agAssertVisible(QueryByExamplePageObjects.activityCompletedBy);
		agAssertVisible(QueryByExamplePageObjects.actualCompletionDate);
		agAssertVisible(QueryByExamplePageObjects.additionalComments);
		agAssertVisible(QueryByExamplePageObjects.additionalInfo);
		agAssertVisible(QueryByExamplePageObjects.additionalInfoCode);
		agAssertVisible(QueryByExamplePageObjects.additionalInformation);
		agAssertVisible(QueryByExamplePageObjects.aditionalLiteratureInformation);
		agAssertVisible(QueryByExamplePageObjects.additionalManufacturerNarrative);
		agAssertVisible(QueryByExamplePageObjects.additionalDrugInformation);
		agAssertVisible(QueryByExamplePageObjects.admissionDuration);
		agAssertVisible(QueryByExamplePageObjects.age);
		agAssertVisible(QueryByExamplePageObjects.ageGroup);
		agAssertVisible(QueryByExamplePageObjects.ageUnit);
		agAssertVisible(QueryByExamplePageObjects.ageAtTheTimeOfEvent);
		agAssertVisible(QueryByExamplePageObjects.alsoReportedTo);
		agAssertVisible(QueryByExamplePageObjects.alwaysSeriousEvent);
		agAssertVisible(QueryByExamplePageObjects.anticiptedEvents);
		agAssertVisible(QueryByExamplePageObjects.approvalType);
		agAssertVisible(QueryByExamplePageObjects.articleTitle);
		agAssertVisible(QueryByExamplePageObjects.accessRelationship);
		agAssertVisible(QueryByExamplePageObjects.assessmentMethod);
		agAssertVisible(QueryByExamplePageObjects.assignedBy);
		agAssertVisible(QueryByExamplePageObjects.assignedOn);
		agAssertVisible(QueryByExamplePageObjects.assignedTo);
		agAssertVisible(QueryByExamplePageObjects.authority);
		agAssertVisible(QueryByExamplePageObjects.authorityNoCompanyNo);
		agAssertVisible(QueryByExamplePageObjects.authorityNoCompNo);
		agAssertVisible(QueryByExamplePageObjects.authorizationCountry);
		agAssertVisible(QueryByExamplePageObjects.authorizationNumber);
		agAssertVisible(QueryByExamplePageObjects.authorizedRepresentative);
		agAssertVisible(QueryByExamplePageObjects.autopsyDeterminedCauseOfDeath);
		agAssertVisible(QueryByExamplePageObjects.autopsyDone);
		agAssertVisible(QueryByExamplePageObjects.basicUDIDIEudamedDI);
		agAssertVisible(QueryByExamplePageObjects.basisOfSimilarIncidentIdentification);
		agAssertVisible(QueryByExamplePageObjects.biologicalFatherExposedToDrug);
		agAssertVisible(QueryByExamplePageObjects.biosimilar);
		agAssertVisible(QueryByExamplePageObjects.birthOutcome);
		agAssertVisible(QueryByExamplePageObjects.birthWeight);
		agAssertVisible(QueryByExamplePageObjects.birthWeightUnit);
		agAssertVisible(QueryByExamplePageObjects.blindingTechnique);
		agAssertVisible(QueryByExamplePageObjects.bodyMassIndex);
		agAssertVisible(QueryByExamplePageObjects.bodySurfaceIndex);
		agAssertVisible(QueryByExamplePageObjects.brandName);
		agAssertVisible(QueryByExamplePageObjects.casNumber);
		agAssertVisible(QueryByExamplePageObjects.cdc);
		agAssertVisible(QueryByExamplePageObjects.ceNumber);
		agAssertVisible(QueryByExamplePageObjects.compounded);
		agAssertVisible(QueryByExamplePageObjects.cpdAuthorizationCountry);
		agAssertVisible(QueryByExamplePageObjects.ctNotificationSubmissionTimes);
		agAssertVisible(QueryByExamplePageObjects.caseApprovalDate);
		agAssertVisible(QueryByExamplePageObjects.caseCodeBroken);
		agAssertVisible(QueryByExamplePageObjects.caseCodeBrokenOn);
		agAssertVisible(QueryByExamplePageObjects.caseCoded);
		agAssertVisible(QueryByExamplePageObjects.caseDueDate);
		agAssertVisible(QueryByExamplePageObjects.caseInitialApprovalDate);
		agAssertVisible(QueryByExamplePageObjects.caseOwner);
		agAssertVisible(QueryByExamplePageObjects.caseSignificance);
		agAssertVisible(QueryByExamplePageObjects.caseStatus);
		agAssertVisible(QueryByExamplePageObjects.caseSummaryAndReportersCommentsLanguage);
		agAssertVisible(QueryByExamplePageObjects.caseSummaryAndReportersCommentsText);
		agAssertVisible(QueryByExamplePageObjects.caseType);
		agAssertVisible(QueryByExamplePageObjects.catalogueNumber);
		agAssertVisible(QueryByExamplePageObjects.category);
		agAssertVisible(QueryByExamplePageObjects.causalitySource);
		agAssertVisible(QueryByExamplePageObjects.causedByDrugInteraction);
		agAssertVisible(QueryByExamplePageObjects.causedByLackOfEffect);
		agAssertVisible(QueryByExamplePageObjects.causedProlongedHospitalization);
		agAssertVisible(QueryByExamplePageObjects.causedprolongedhospitalization);
		agAssertVisible(QueryByExamplePageObjects.centerNumber);
		agAssertVisible(QueryByExamplePageObjects.cessationDate);
		agAssertVisible(QueryByExamplePageObjects.city);
		agAssertVisible(QueryByExamplePageObjects.classOfDevice);
		agAssertVisible(QueryByExamplePageObjects.clinicalDrugCode);
		agAssertVisible(QueryByExamplePageObjects.clinicalNonClinicalClassification);
		agAssertVisible(QueryByExamplePageObjects.codingClass);
		agAssertVisible(QueryByExamplePageObjects.codingType);
		agAssertVisible(QueryByExamplePageObjects.combinationProductReport);
		agAssertVisible(QueryByExamplePageObjects.commentOnRegulatoryClockStartDate);
		agAssertVisible(QueryByExamplePageObjects.comments);
		agAssertVisible(QueryByExamplePageObjects.commentsOnDeterminationOfSimilarIncidents);
		agAssertVisible(QueryByExamplePageObjects.commentsReasonText);
		agAssertVisible(QueryByExamplePageObjects.commonDeviceName);
		agAssertVisible(QueryByExamplePageObjects.companyCausality);
		agAssertVisible(QueryByExamplePageObjects.companyProduct);
		agAssertVisible(QueryByExamplePageObjects.companyReceivedDate);
		agAssertVisible(QueryByExamplePageObjects.companyUnit);
		agAssertVisible(QueryByExamplePageObjects.competentAuthority);
		agAssertVisible(QueryByExamplePageObjects.concomitantTherapies);
		agAssertVisible(QueryByExamplePageObjects.conditionTreated);
		agAssertVisible(QueryByExamplePageObjects.congenitalAnomaly);
		agAssertVisible(QueryByExamplePageObjects.congenitalAnomalyType);
		agAssertVisible(QueryByExamplePageObjects.congenitalAnomalyBirthDefect);
		agAssertVisible(QueryByExamplePageObjects.consentToContactParent);
		agAssertVisible(QueryByExamplePageObjects.consentToContact);
		agAssertVisible(QueryByExamplePageObjects.consentToContactPatient);
		agAssertVisible(QueryByExamplePageObjects.contact);
		agAssertVisible(QueryByExamplePageObjects.containerName);
		agAssertVisible(QueryByExamplePageObjects.Containername);
		agAssertVisible(QueryByExamplePageObjects.continueSurvey);
		agAssertVisible(QueryByExamplePageObjects.Continuing);
		agAssertVisible(QueryByExamplePageObjects.continuing);
		agAssertVisible(QueryByExamplePageObjects.contraceptiveFailure);
		agAssertVisible(QueryByExamplePageObjects.contraceptivesUsed);
		agAssertVisible(QueryByExamplePageObjects.correctedData);
		agAssertVisible(QueryByExamplePageObjects.correction);
		agAssertVisible(QueryByExamplePageObjects.correctionRemovalReportingNumber);
		agAssertVisible(QueryByExamplePageObjects.correspondenceDate);
		agAssertVisible(QueryByExamplePageObjects.correspondenceStatus);
		agAssertVisible(QueryByExamplePageObjects.country);
		agAssertVisible(QueryByExamplePageObjects.countryObtained);
		agAssertVisible(QueryByExamplePageObjects.countryOfDetection);
		agAssertVisible(QueryByExamplePageObjects.countrypPublished);
		agAssertVisible(QueryByExamplePageObjects.criteriaForDevicesInMarket);
		agAssertVisible(QueryByExamplePageObjects.crossReferencedIND);
		agAssertVisible(QueryByExamplePageObjects.cumulativeDoseToFirstReactionUnit);
		agAssertVisible(QueryByExamplePageObjects.cumulativeDoseToFirstReaction);
		agAssertVisible(QueryByExamplePageObjects.cumulativedoseTofirstReactionUnit);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search using (And/OR)Operator with
	 *             multiple condition and verify result
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 08-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchByOperator(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		selectExpOperator(scenarioName, "RuleOperator");
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
		searchAndSelectField(scenarioName, "SearchField1");
		selectFirstOperator(scenarioName, "ConditionOperator");
		agClick(QueryByExamplePageObjects.valueSearchIcon);
		agIsVisible(QueryByExamplePageObjects.listOfLibraryDataPopUP);
		agSetValue(QueryByExamplePageObjects.librarySearchTextbox, getTestDataCellValue(scenarioName, "Value1"));
		agClick(QueryByExamplePageObjects.librarySearchIcon);
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSearchResultCheckbox);
		agClick(QueryByExamplePageObjects.selectBtn);
		CommonOperations.takeScreenShot();
		agClick(QueryByExamplePageObjects.clickCondition);
		agClearText(QueryByExamplePageObjects.fieldSearch);
		searchAndSelectField(scenarioName, "SearchField2");
		selectSecondcondOperator(scenarioName, "ConditionOperator");
		agClick(QueryByExamplePageObjects.secondvalueSearchIcon);
		agIsVisible(QueryByExamplePageObjects.codelistHeader);
		agSetValue(QueryByExamplePageObjects.codelistSearch, getTestDataCellValue(scenarioName, "Value2"));
		agClick(QueryByExamplePageObjects.codelistSearchIcon);
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.codelistCheckBox);
		agClick(QueryByExamplePageObjects.codelistSelectBtn);
		agClick(QueryByExamplePageObjects.clickGetCount);
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		CommonOperations.takeScreenShot();
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		changeVersion("All Version");
		agSetStepExecutionDelay("5000");
		String searchCount = agGetText(QueryByExamplePageObjects.paginationCount);
		String Result = getTotalCount();

		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.PASS, scenarioName + " Counts Matched Successfully ", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, scenarioName + " Counts Not Matched Successfully ", true);
		}
		agClick(QueryByExamplePageObjects.backToQbeHeader);
		clearQuery();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search using (And/OR)Grouping with
	 *             multiple condition and verify result
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 08-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchByGroup(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		selectExpOperator(scenarioName, "RuleOperator");
		agClick(QueryByExamplePageObjects.clickGroup);
		agIsVisible(QueryByExamplePageObjects.conditionTree);
		selectTreeExpOperator(scenarioName, "TreeRuleOperator");
		agClick(QueryByExamplePageObjects.treeConditionClick);
		agIsVisible(QueryByExamplePageObjects.firstTreeExpCondtion);
		searchAndSelectField(scenarioName, "SearchField1");
		selectFirstOperator(scenarioName, "ConditionOperator");
		agClick(QueryByExamplePageObjects.valueSearchIcon);
		agIsVisible(QueryByExamplePageObjects.listOfLibraryDataPopUP);
		agSetValue(QueryByExamplePageObjects.librarySearchTextbox, getTestDataCellValue(scenarioName, "Value1"));
		agClick(QueryByExamplePageObjects.librarySearchIcon);
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSearchResultCheckbox);
		agClick(QueryByExamplePageObjects.selectBtn);
		CommonOperations.takeScreenShot();
		agClick(QueryByExamplePageObjects.treeConditionClick);
		agClearText(QueryByExamplePageObjects.fieldSearch);
		searchAndSelectField(scenarioName, "SearchField2");
		selectSecondcondOperator(scenarioName, "ConditionOperator");
		agClick(QueryByExamplePageObjects.secondvalueSearchIcon);
		agIsVisible(QueryByExamplePageObjects.codelistHeader);
		agSetValue(QueryByExamplePageObjects.codelistSearch, getTestDataCellValue(scenarioName, "Value2"));
		agClick(QueryByExamplePageObjects.codelistSearchIcon);
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.codelistCheckBox);
		agClick(QueryByExamplePageObjects.codelistSelectBtn);
		agClick(QueryByExamplePageObjects.clickGetCount);
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		CommonOperations.takeScreenShot();
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("5000");
		changeVersion("All Version");
		agSetStepExecutionDelay("5000");
		String searchCount = agGetText(QueryByExamplePageObjects.paginationCount);
		String Result = getTotalCount();

		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.PASS, scenarioName + " Counts Matched Successfully ", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, scenarioName + " Counts Not Matched Successfully ", true);
		}
		agClick(QueryByExamplePageObjects.backToQbeHeader);
		clearQuery();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create searched criteria and save
	 *             the criteria
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 08-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void saveSearchedCriteria(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		selectExpOperator(scenarioName, "RuleOperator");
		agClick(QueryByExamplePageObjects.clickGroup);
		agIsVisible(QueryByExamplePageObjects.conditionTree);
		selectTreeExpOperator(scenarioName, "TreeRuleOperator");
		agClick(QueryByExamplePageObjects.treeConditionClick);
		agIsVisible(QueryByExamplePageObjects.firstTreeExpCondtion);
		searchAndSelectField(scenarioName, "SearchField1");
		selectFirstOperator(scenarioName, "ConditionOperator");
		agClick(QueryByExamplePageObjects.valueSearchIcon);
		agIsVisible(QueryByExamplePageObjects.listOfLibraryDataPopUP);
		agSetValue(QueryByExamplePageObjects.librarySearchTextbox, getTestDataCellValue(scenarioName, "Value1"));
		agClick(QueryByExamplePageObjects.librarySearchIcon);
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSearchResultCheckbox);
		agClick(QueryByExamplePageObjects.selectBtn);
		CommonOperations.takeScreenShot();
		agClick(QueryByExamplePageObjects.saveCriteria);
		agIsVisible(QueryByExamplePageObjects.saveQBEpopUpHeader);
		agSetValue(QueryByExamplePageObjects.saveCriteriaName, getTestDataCellValue(scenarioName, "CriteriaName"));
		agClick(QueryByExamplePageObjects.selectVisibleTo(getTestDataCellValue(scenarioName, "VisibleTo")));
		agClick(QueryByExamplePageObjects.saveInSaveCriteria);
		status = agIsVisible(QueryByExamplePageObjects.saveCriteriaMessage);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Criteria Saved Successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "criteria not Saved Successfully", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created verify saved criteria
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 09-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySavedCriteria(String scenarioName) {
		agClick(QueryByExamplePageObjects.saveCriteriaDD);
		agSetStepExecutionDelay("2000");
		status = agIsVisible(
				QueryByExamplePageObjects.verifyCriteria(getTestDataCellValue(scenarioName, "CriteriaName")));
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Saved Criteria is visible Successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Saved Criteria is not visible Successfully", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete saved criteria
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 09-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteSavedCriteria(String scenarioName) {
		// agClick(QueryByExamplePageObjects.saveCriteriaDD);
		agSetStepExecutionDelay("2000");
		agIsVisible(QueryByExamplePageObjects.verifyCriteria(getTestDataCellValue(scenarioName, "CriteriaName")));
		agClick(QueryByExamplePageObjects.deleteCriteria(getTestDataCellValue(scenarioName, "CriteriaName")));
		agIsVisible(QueryByExamplePageObjects.deleteConfirmation);
		agClick(QueryByExamplePageObjects.deleteOkBtn);
		status = agIsVisible(QueryByExamplePageObjects.deleteMessage);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Criteria is deleted Successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Criteria is not deleted Successfully", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Expression operator
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 08-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void selectExpOperator(String scenarioName, String columnName) {
		agClick(QueryByExamplePageObjects.ruleExpOperator);
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects.selectExpressionOperator(getTestDataCellValue(scenarioName, columnName)));
	}

	public static void selectTreeExpOperator(String scenarioName, String columnName) {
		agClick(QueryByExamplePageObjects.treeRuleExpOperator);
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects.selectTreeExpressionOperator(getTestDataCellValue(scenarioName, columnName)));
	}
	
	public static void selectExcludeTreeExpOperator(String scenarioName, String columnName) {
		agClick(QueryByExamplePageObjects.excludeTreeRuleExpOperator);
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects.selectExcludeTreeExpressionOperator(getTestDataCellValue(scenarioName, columnName)));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select condition operator
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 08-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void selectFirstOperator(String scenarioName, String columnName) {
		agClick(QueryByExamplePageObjects.conditionOpertor);
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects.selectConditionOperator(getTestDataCellValue(scenarioName, columnName)));
	}

	public static void selectSecondcondOperator(String scenarioName, String columnName) {
		agClick(QueryByExamplePageObjects.secondconditionOpertor);
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects
				.selectSecondConditionOperator(getTestDataCellValue(scenarioName, columnName)));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search field and select field
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 09-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndSelectField(String scenarioName, String columnName) {
		agSetValue(QueryByExamplePageObjects.fieldSearch, getTestDataCellValue(scenarioName, columnName));
		agClick(QueryByExamplePageObjects.searchIcon);
		clickSearchResult(getTestDataCellValue(scenarioName, columnName));
	}

	public static void searchAndSelectPreferedProdDesc(String scenarioName, String columnName) {
		agSetValue(QueryByExamplePageObjects.fieldSearch, getTestDataCellValue(scenarioName, columnName));
		agClick(QueryByExamplePageObjects.searchIcon);
		agClick(QueryByExamplePageObjects.prferedProductDesc);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select version
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 08-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void changeVersion(String label) {
		agClick(QueryByExamplePageObjects.verisonDD);
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects.selectVersionDroprdown(label));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to get the total counts
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 08-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getTotalCount() {
		String searchCount = agGetText(QueryByExamplePageObjects.paginationCount);
		String[] result = searchCount.split(" ");
		String result1 = result[4];
		return result1;
	}
	
	public static String getPagelCount() {
		String searchCount = agGetText(QueryByExamplePageObjects.paginationCount);
		String[] result = searchCount.split(" ");
		String result1 = result[2];
		return result1;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click searched result.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 08-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickSearchResult(String label) {
		agClick(QueryByExamplePageObjects.selectSearchedResult(label));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created clear the searched query conditions .
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 09-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clearQuery() {
		agClick(QueryByExamplePageObjects.clearbtn);
		agIsVisible(QueryByExamplePageObjects.clearConfirmationPopUP);
		agClick(QueryByExamplePageObjects.confirmPopupOkBtn);
		agClearText(QueryByExamplePageObjects.fieldSearch);
	}

	public static void clearQueryOkBtn() {
		agClick(QueryByExamplePageObjects.confirmPopupOkBtn);
		agClearText(QueryByExamplePageObjects.fieldSearch);
		CommonOperations.captureScreenShot(true);
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to search the receipt number by using
	 *             condition and verify get the count
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 09-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchReceiptNum(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		selectExpOperator(scenarioName, "RuleOperator");
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
		agSetValue(QueryByExamplePageObjects.fieldSearch, getTestDataCellValue(scenarioName, "SearchField1"));
		agClick(QueryByExamplePageObjects.searchIcon);
		agClick(QueryByExamplePageObjects.recieptNo);
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		String RctNo = FDE_General.getData(scenarioName, "ReceiptNo");
		agSetValue(QueryByExamplePageObjects.searchValueToCompare_TextBox, RctNo);
		agClick(QueryByExamplePageObjects.clickGetCount);
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		CommonOperations.takeScreenShot();
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		changeVersion("All Version");
		agSetStepExecutionDelay("5000");
		String Result = getTotalCounts();

		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.PASS, scenarioName + " Counts Matched Successfully ", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, scenarioName + " Counts Not Matched Successfully ", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the RCT Number
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 09-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyRCTNum(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		agSetStepExecutionDelay("2000");
		String RecieptNum = agGetText(QueryByExamplePageObjects.receiptNoLink);
		if (RecieptNum.equalsIgnoreCase(getTestDataCellValue(scenarioName, "ReceiptNo"))) {
			Reports.ExtentReportLog("", Status.PASS, "Receipt number Matched Successfully." + RecieptNum, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Receipt number not Matched Successfully." + RecieptNum, true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the RCT Number is approved or not
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date : 22-feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyRCTStatus() {
		if (agIsVisible(QueryByExamplePageObjects.receiptNoLink)) {
			if (agIsVisible(QueryByExamplePageObjects.CaseStatus)) {
				Reports.ExtentReportLog("", Status.FAIL, "Receipt numberis Approved", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Receipt number not Approved", true);
			}

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Receipt number not Approved", true);
		}

		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify distribution attributed in
	 *             Field Library
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 12-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyDistributionAttributes() {

		agClick(QueryByExamplePageObjects.distributionDetails);
		agAssertVisible(QueryByExamplePageObjects.acknowledgementReceivedDate);
		agAssertVisible(QueryByExamplePageObjects.authorityNoCompanyNo);
		agAssertVisible(QueryByExamplePageObjects.commentReasonText);
		agAssertVisible(QueryByExamplePageObjects.dateInformed);
		agAssertVisible(QueryByExamplePageObjects.distributedDate);
		agAssertVisible(QueryByExamplePageObjects.distributionContactName);
		agAssertVisible(QueryByExamplePageObjects.e2bMessageType);
		agAssertVisible(QueryByExamplePageObjects.Final);
		agAssertVisible(QueryByExamplePageObjects.followUpType);
		agAssertVisible(QueryByExamplePageObjects.healthAuthority);
		agAssertVisible(QueryByExamplePageObjects.localCriteriaReportType);
		agAssertVisible(QueryByExamplePageObjects.locallyExpedited);
		agAssertVisible(QueryByExamplePageObjects.MDNReceivedDate);
		agAssertVisible(QueryByExamplePageObjects.mediumDetails);
		agAssertVisible(QueryByExamplePageObjects.reasonForNotReporting);
		agAssertVisible(QueryByExamplePageObjects.reasonForNullificationAmendment);
		agAssertVisible(QueryByExamplePageObjects.receiverOrganization);
		agAssertVisible(QueryByExamplePageObjects.recipientCountry);
		agAssertVisible(QueryByExamplePageObjects.removeReasonComment);
		agAssertVisible(QueryByExamplePageObjects.reportFormat);
		agAssertVisible(QueryByExamplePageObjects.reporterMedium);
		agAssertVisible(QueryByExamplePageObjects.distributionReportType);
		agAssertVisible(QueryByExamplePageObjects.reportForNullificationAmendment);
		agAssertVisible(QueryByExamplePageObjects.reportingStatus);
		agAssertVisible(QueryByExamplePageObjects.safteryReportId);
		agAssertVisible(QueryByExamplePageObjects.DistributionStatus);
		agAssertVisible(QueryByExamplePageObjects.submissionDueDate);
		agAssertVisible(QueryByExamplePageObjects.submittedDate);
		agAssertVisible(QueryByExamplePageObjects.typeOfAckReceived);
		agAssertVisible(QueryByExamplePageObjects.XMLDOCTYPE);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to close the current window and
	 *             return to main window.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 12-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void closeCurrentBrowserWindow() {
		agCloseCurrentWindow();
		agGetWindowControlByInstance(1);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to get the total counts
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 21-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getTotalCounts() {
		String searchCount = agGetText(QueryByExamplePageObjects.paginationCount);
		String[] result = searchCount.split("of");
		result = result[1].split("1-1");
		String count = result[0].toString().trim();
		return count;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify DSUR country in QBE search
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDSURinQBE(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(QueryByExamplePageObjects.clicklabelling);
		selectExpOperator(scenarioName, "RuleOperator");
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
		searchAndSelectField(scenarioName, "SearchField1");
		selectFirstOperator(scenarioName, "ConditionOperator");
		agClick(QueryByExamplePageObjects.valueSearchIcon);
		agIsVisible(QueryByExamplePageObjects.ListofcodelistHeader);
		agSetValue(QueryByExamplePageObjects.countrySearchTextBox, getTestDataCellValue(scenarioName, "Value1"));
		agClick(QueryByExamplePageObjects.countrySearchIcon);
		// status = agIsVisible(QueryByExamplePageObjects.countryDSUR);
		// if (status) {
		// Reports.ExtentReportLog("", Status.PASS, "", true);
		// } else {
		// Reports.ExtentReportLog("", Status.FAIL, "DSUR county not exist
		// Successfully.", true);
		// }
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.selectSearchResultCheckbox);
		agClick(QueryByExamplePageObjects.countryCodelistSelectBtn);
		agClick(QueryByExamplePageObjects.clickGetCount);
		agIsVisible(QueryByExamplePageObjects.countResult);
		Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
		Reports.ExtentReportLog("", Status.INFO, " The search criteria is entered ", false);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify search counts with QBE
	 *             listing counts
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySearchResult(String scenarioName) {
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		changeVersion("All Version");
		agSetStepExecutionDelay("5000");
		String searchCount = agGetText(QueryByExamplePageObjects.paginationCount);
		String Result = getTotalCount();

		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.INFO, scenarioName + " Counts Matched Successfully ", false);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, scenarioName + " Counts Not Matched Successfully ", true);
		}
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		checkCaseInListing(getTestDataCellValue(scenarioName, "ReceiptNo"));
		closeCurrentBrowserWindow();
	}
	
	public static void SearchResultVerification(String scenarioName) {
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		changeVersion("All Version");
		agSetStepExecutionDelay("5000");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		agJavaScriptExecuctorScrollToElement(QueryByExamplePageObjects.checkCaseInListing(getTestDataCellValue(scenarioName, "ReceiptNo")));
		checkAerCaseInListing(getTestDataCellValue(scenarioName, "ReceiptNo"));
		String searchCount = agGetText(QueryByExamplePageObjects.paginationCount);
		String Result = getTotalCount();

		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.INFO, scenarioName + " Counts Matched Successfully ", false);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, scenarioName + " Counts Not Matched Successfully ", true);
		}
		CommonOperations.captureScreenShot(true);
		closeCurrentBrowserWindow();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search using Aer no. and create
	 *             case series in QBE listing
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 26-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createCaseSeriesInQBE(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// agClick(QueryByExamplePageObjects.expandFieldLibrary);
		// agClick(QueryByExamplePageObjects.clickCaseSpecification);
		selectExpOperator(scenarioName, "RuleOperator");
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
		if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries")
				|| scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Repeat")) {

			agClick(QueryByExamplePageObjects.clickProduct);
			agIsVisible(QueryByExamplePageObjects.clickProductInformation);
			agClick(QueryByExamplePageObjects.clickProductInformation);
			searchAndSelectPreferedProdDesc(scenarioName, "SearchField1");
			selectFirstOperator(scenarioName, "ConditionOperator");
			agSetValue(QueryByExamplePageObjects.aerNoTextBox,
					getTestDataCellValue("DSUREnhancementCaseSeries", "Value1"));
		}
		if (!scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries")
				|| scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Repeat")) {
			searchAndSelectField(scenarioName, "SearchField1");
			selectFirstOperator(scenarioName, "ConditionOperator");
		}

		if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Susar_2")) {
			selectFirstOperator(scenarioName, "ConditionOperator");
			agSetValue(QueryByExamplePageObjects.aerNoTextBox,
					FDE_General.getTestDataCellValue("DSUREnhancementCaseSeries_Susar_2", "ReceiptNo"));
		}
		// else if(scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries") ||
		// scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Repeat")) {
		// selectFirstOperator(scenarioName, "ConditionOperator");
		// agSetValue(QueryByExamplePageObjects.aerNoTextBox,getTestDataCellValue("DSUREnhancementCaseSeries",
		// "Value1"));
		// }
		else if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Susar_4")) {
			agSetValue(QueryByExamplePageObjects.aerNoTextBox,
					FDE_General.getTestDataCellValue("DSUREnhancementCaseSeries_Susar_4", "ReceiptNo"));
		} else if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Susar_3")) {
			agSetValue(QueryByExamplePageObjects.aerNoTextBox,
					FDE_General.getTestDataCellValue("DSUREnhancementCaseSeries_Susar_3", "ReceiptNo"));
		} else if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Susar_2_1")) {
			agSetValue(QueryByExamplePageObjects.aerNoTextBox,
					FDE_General.getTestDataCellValue("DSUREnhancementCaseSeries_Susar_2_1", "ReceiptNo"));
		}

		SelectApprovalStatus(scenarioName);
		agClick(QueryByExamplePageObjects.clickGetCount);
		agIsVisible(QueryByExamplePageObjects.countResult);
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		changeVersion("All Version");
		if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries")
				|| scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Repeat")) {

			String data1 = FDE_General.getData("DSUREnhancementCaseSeries", "ReceiptNo");
			checkCaseInListing(data1);
			String data2 = FDE_General.getData("DSUREnhancementCaseSeriesV1", "ReceiptNo");
			checkCaseInListing(data2);
			String data3 = FDE_General.getData("DSUREnhancementCaseSeries_Susar", "ReceiptNo");
			checkCaseInListing(data3);
			String data4 = FDE_General.getData("DSUREnhancementCaseSeries_Susar_1", "ReceiptNo");
			checkCaseInListing(data4);
		}
		if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Susar_2")) {
			checkCaseInListing(FDE_General.getTestDataCellValue("DSUREnhancementCaseSeries_Susar_2", "ReceiptNo"));
		} else if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Susar_2_1")) {
			checkCaseInListing(FDE_General.getTestDataCellValue("DSUREnhancementCaseSeries_Susar_2_1", "ReceiptNo"));
		} else if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Repeat")) {
			String Scenario = "DSUREnhancementCaseSeries_Repeat";
			CreateCaseSeriesAsNew(Scenario);
		} else if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Susar_4")) {
			checkCaseInListing(FDE_General.getTestDataCellValue("DSUREnhancementCaseSeries_Susar_4", "ReceiptNo"));
		} else if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Susar_3")) {
			checkCaseInListing(FDE_General.getTestDataCellValue("DSUREnhancementCaseSeries_Susar_3", "ReceiptNo"));
		}
		CreateCaseSeriesAsNew(scenarioName);
		closeCurrentBrowserWindow();
	}
	
	public static void checkListingCase(String Data) {
		status = agIsVisible(QueryByExamplePageObjects.checkCaseInListing(Data));
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "", true);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Case is not listed ", true);
		}
	}

	public static void checkCaseInListing(String Data) {
		status = agIsVisible(QueryByExamplePageObjects.checkCaseInListing(Data));
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Case is listed ", true);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Case is not listed ", true);
		}
	}
	
	public static void checkAerCaseInListing(String Data) {
		status = agIsVisible(QueryByExamplePageObjects.checkAerCaseInListing(Data));
		if (status) {
			Reports.ExtentReportLog("", Status.INFO, "Case is listed", false);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Aer Case is not listed ", false);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select approval status
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 09-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SelectApprovalStatus(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(QueryByExamplePageObjects.aprovalStatusDD);
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects.selectApprovalStatus(getTestDataCellValue(scenarioName, "Approval_Status")));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is use to create case series in QBE listing
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 26-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void CreateCaseSeriesAsNew(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agIsVisible(QueryByExamplePageObjects.caseSeries);
		agClick(QueryByExamplePageObjects.caseSeries);
		agIsVisible(QueryByExamplePageObjects.caseSeriesPopUpHeader);
		driver.findElement(By.xpath("//div[@id='htmlSaveCaseSeriesDailog']//div/input")).sendKeys(Keys.ENTER);
		driver.findElement(By.xpath("//div[@id='htmlSaveCaseSeriesDailog']//div/input"))
				.sendKeys(getTestDataCellValue(scenarioName, "Case_Series_Name"));
		selectSeriesType(scenarioName, "Case_Series_Type");
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.saveCaseSeries);
		agIsVisible(QueryByExamplePageObjects.saveConfirmationPopUp);
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.okBtn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select case series type in Case
	 *             series PopUp
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 26-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void selectSeriesType(String scenarioName, String columnName) {
		agClick(QueryByExamplePageObjects.clickSeriesDD);
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects.selectSeriesType(getTestDataCellValue(scenarioName, columnName)));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Navigate to QBE Page
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 16-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void NavigateToQBE() {
		agSetStepExecutionDelay("10000");
		agIsVisible(QueryByExamplePageObjects.QBEIcon);
		agClick(QueryByExamplePageObjects.QBEIcon);

		int i = 0, sz = agGetWindowCount();
		agSetStepExecutionDelay("5000");
		while (!(sz == 2) && i < 75) {
			sz = agGetWindowCount();
			i++;
			System.out.println("Waiting" + i);
		}
		agGetCurrentWindow();

		status = agIsVisible(QueryByExamplePageObjects.fieldLibraryHeader);
		if (status) {
			Reports.ExtentReportLog("", Status.INFO, "Navigate to QBE Successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Navigate to QBE not Successfully", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to To Search Case Based on Source
	 *             Document
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 16-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SearchCaseBasedonSourceDocument(String scenarioName, String Condition) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Search Based on Source Document Started", true);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			if (agIsVisible(QueryByExamplePageObjects.ExpandCaseDocumentBtn) == true) {
				agClick(QueryByExamplePageObjects.ExpandCaseDocumentBtn);
			}
			agWaitTillVisibilityOfElement(QueryByExamplePageObjects.SourceDocumentBtn);
			agClick(QueryByExamplePageObjects.SourceDocumentBtn);

			if(Condition.equalsIgnoreCase("SearchBasedonDate")) {
				agWaitTillVisibilityOfElement(QueryByExamplePageObjects.Date);
				agClick(QueryByExamplePageObjects.Date);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
				agSetValue(QueryByExamplePageObjects.StartDate, CommonOperations
						.returnDateTime(FDE_General.getData(scenarioName, "Gen_CaseDates_InitialReceivedDate")));
				agSetValue(QueryByExamplePageObjects.EndDate, CommonOperations
						.returnDateTime(FDE_General.getData(scenarioName, "Gen_CaseDates_LatestReceivedDate")));
				CommonOperations.captureScreenShot(true);
			}
		
			
			
			if (Condition.equalsIgnoreCase("MultipleFileName")) {
				agClick(QueryByExamplePageObjects.Filename);

				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseDocumentsOperations");
				agSetValue(QueryByExamplePageObjects.FileNameValue,
						FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "Filename"));
				
//				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,className);
//				agClick(QueryByExamplePageObjects.Filename);
//
//				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
//				agSetStepExecutionDelay("3000");
//				agClick(QueryByExamplePageObjects.clickCondition);
//				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
//				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseDocumentsOperations");
//				agSetValue(QueryByExamplePageObjects.FileName2,
//						FDE_CaseDocumentsOperations.getTestDataCellValue("QBEBasedonCaseDocuments_017", "Filename"));
				CommonOperations.captureScreenShot(true);
				
			}
			
			
			if (Condition.equalsIgnoreCase("SearchBasedonFileName")) {
				agClick(QueryByExamplePageObjects.Filename);

				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseDocumentsOperations");
				agSetValue(QueryByExamplePageObjects.FileNameValue,
						FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "Filename"));
				CommonOperations.captureScreenShot(true);
			} else if (Condition.equalsIgnoreCase("SearchBasedonDocumentCategory")) {
				agClick(QueryByExamplePageObjects.DocumentCategory);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
				agClick(QueryByExamplePageObjects.DocumnetSearchIcon);
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseDocumentsOperations");
				agSetValue(QueryByExamplePageObjects.CodeListSearchTextBox,
						FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "SourceDocs_DocCategory"));
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.codelistSearchIcon);
				agSetStepExecutionDelay("3000");
				agJavaScriptExecuctorClick(QueryByExamplePageObjects.CodeListCheckBox);
				agJavaScriptExecuctorClick(QueryByExamplePageObjects.SelectBtn);
				CommonOperations.captureScreenShot(true);
			} else if (Condition.equalsIgnoreCase("SearchBasedonDocumentCategoryAndFileName")) {
				agClick(QueryByExamplePageObjects.DocumentCategory);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);

				agClick(QueryByExamplePageObjects.Filename);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseDocumentsOperations");
				agClick(QueryByExamplePageObjects.DocumnetSearchIcon);
				agSetValue(QueryByExamplePageObjects.CodeListSearchTextBox,
						FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "SourceDocs_DocCategory"));
				agSetStepExecutionDelay("3000");
				agJavaScriptExecuctorClick(QueryByExamplePageObjects.codelistSearchIcon);
				agSetStepExecutionDelay("3000");
				agJavaScriptExecuctorClick(QueryByExamplePageObjects.CodeListCheckBox);
				agJavaScriptExecuctorClick(QueryByExamplePageObjects.SelectBtn);

				agSetValue(QueryByExamplePageObjects.FileNameValue,
						FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "Filename"));
				CommonOperations.captureScreenShot(true);
			} else if (Condition.equalsIgnoreCase("SearchBasedonDocumentCategoryAndFileNameAndDate")) {

				agWaitTillVisibilityOfElement(QueryByExamplePageObjects.Date);
				agClick(QueryByExamplePageObjects.Date);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);

				agClick(QueryByExamplePageObjects.DocumentCategory);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);

				agClick(QueryByExamplePageObjects.Filename);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
				agClick(QueryByExamplePageObjects.StartDate);
				agSetValue(QueryByExamplePageObjects.StartDate, CommonOperations
						.returnDateTime(FDE_General.getData(scenarioName, "Gen_CaseDates_InitialReceivedDate")));
				agClick(QueryByExamplePageObjects.EndDate);
				agSetValue(QueryByExamplePageObjects.EndDate, CommonOperations
						.returnDateTime(FDE_General.getData(scenarioName, "Gen_CaseDates_LatestReceivedDate")));
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseDocumentsOperations");
				agClick(QueryByExamplePageObjects.DocumnetSearchIcon);
				agSetValue(QueryByExamplePageObjects.CodeListSearchTextBox,
						FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "SourceDocs_DocCategory"));

				agClick(QueryByExamplePageObjects.codelistSearchIcon);
				agSetStepExecutionDelay("3000");
				agJavaScriptExecuctorClick(QueryByExamplePageObjects.CodeListCheckBox);
				agJavaScriptExecuctorClick(QueryByExamplePageObjects.SelectBtn);

				agSetValue(QueryByExamplePageObjects.FileNameValue,
						FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "Filename"));
				CommonOperations.captureScreenShot(true);
			}
			agClick(QueryByExamplePageObjects.clickSearch);

			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.INFO, "Search Based on Source Document Ended", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to To Search Case Based on Source
	 *             Document
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 16-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SearchCaseBasedonSupportDocument(String scenarioName, String Condition) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Search Based on Support Document Started", true);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			if (agIsVisible(QueryByExamplePageObjects.ExpandCaseDocumentBtn) == true) {
				agClick(QueryByExamplePageObjects.ExpandCaseDocumentBtn);
			}
			agWaitTillVisibilityOfElement(QueryByExamplePageObjects.SupportDocumentBtn);
			
			agJavaScriptExecuctorClick(QueryByExamplePageObjects.SupportDocumentBtn);
			agSetStepExecutionDelay("2000");
			if(Condition.equalsIgnoreCase("SearchBasedonDate")) {
				agWaitTillVisibilityOfElement(QueryByExamplePageObjects.Date);
				agClick(QueryByExamplePageObjects.Date);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
				agSetValue(QueryByExamplePageObjects.StartDate, CommonOperations
						.returnDateTime(FDE_General.getData(scenarioName, "Gen_CaseDates_InitialReceivedDate")));
				agSetValue(QueryByExamplePageObjects.EndDate, CommonOperations
						.returnDateTime(FDE_General.getData(scenarioName, "Gen_CaseDates_LatestReceivedDate")));
				CommonOperations.captureScreenShot(true);
			}
		
			if (Condition.equalsIgnoreCase("SearchBasedonFileName")) {
				agClick(QueryByExamplePageObjects.Filename);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseDocumentsOperations");
				agSetValue(QueryByExamplePageObjects.FileNameValue,
						FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "SupportFilename"));
				CommonOperations.captureScreenShot(true);
			} else if (Condition.equalsIgnoreCase("SearchBasedonDocumentCategory")) {
				agClick(QueryByExamplePageObjects.DocumentCategory);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseDocumentsOperations");
				agClick(QueryByExamplePageObjects.DocumnetSearchIcon);
				agSetValue(QueryByExamplePageObjects.CodeListSearchTextBox,
						FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "SupportDocs_DocCategory"));
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.codelistSearchIcon);
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.CodeListCheckBox);
				agClick(QueryByExamplePageObjects.SelectBtn);
				CommonOperations.captureScreenShot(true);
			} else if (Condition.equalsIgnoreCase("SearchBasedonDocumentCategoryAndFileName")) {
				agClick(QueryByExamplePageObjects.DocumentCategory);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);

				agClick(QueryByExamplePageObjects.Filename);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseDocumentsOperations");
				agClick(QueryByExamplePageObjects.DocumnetSearchIcon);
				agSetValue(QueryByExamplePageObjects.CodeListSearchTextBox,
						FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "SupportDocs_DocCategory"));

				agClick(QueryByExamplePageObjects.codelistSearchIcon);
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.CodeListCheckBox);
				agClick(QueryByExamplePageObjects.SelectBtn);
				agSetValue(QueryByExamplePageObjects.FileNameValue,
						FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "SupportFilename"));
				CommonOperations.captureScreenShot(true);
			} else if (Condition.equalsIgnoreCase("SearchBasedonDocumentCategoryAndFileNameAndDate")) {

				agWaitTillVisibilityOfElement(QueryByExamplePageObjects.Date);
				agClick(QueryByExamplePageObjects.Date);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);

				agClick(QueryByExamplePageObjects.DocumentCategory);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);

				agClick(QueryByExamplePageObjects.Filename);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
				agSetValue(QueryByExamplePageObjects.StartDate, CommonOperations
						.returnDateTime(FDE_General.getData(scenarioName, "Gen_CaseDates_InitialReceivedDate")));
				agSetValue(QueryByExamplePageObjects.EndDate, CommonOperations
						.returnDateTime(FDE_General.getData(scenarioName, "Gen_CaseDates_LatestReceivedDate")));
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseDocumentsOperations");
				agClick(QueryByExamplePageObjects.DocumnetSearchIcon);
				agSetValue(QueryByExamplePageObjects.CodeListSearchTextBox,
						FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "SupportDocs_DocCategory"));
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.codelistSearchIcon);
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.CodeListCheckBox);
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.SelectBtn);

				agSetValue(QueryByExamplePageObjects.FileNameValue,
						FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "SupportFilename"));
				CommonOperations.captureScreenShot(true);
			}else if (Condition.equalsIgnoreCase("SearchBasedonNotDocumentCategoryAndFileNameAndDate")) {

				agWaitTillVisibilityOfElement(QueryByExamplePageObjects.Date);
				agClick(QueryByExamplePageObjects.Date);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);

				agClick(QueryByExamplePageObjects.DocumentCategory);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);

				agClick(QueryByExamplePageObjects.Filename);
				selectExpOperator("AndWithLIKEoperator", "RuleOperator");
				agClick(QueryByExamplePageObjects.clickCondition);
				agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
				agSetValue(QueryByExamplePageObjects.StartDate, CommonOperations
						.returnDateTime(FDE_General.getData(scenarioName, "Gen_CaseDates_InitialReceivedDate")));
				agSetValue(QueryByExamplePageObjects.EndDate, CommonOperations
						.returnDateTime(FDE_General.getData(scenarioName, "Gen_CaseDates_LatestReceivedDate")));
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseDocumentsOperations");
				
				agClick(QueryByExamplePageObjects.NotEqualOp);
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.NotEqualOpSelect);
				
				agClick(QueryByExamplePageObjects.DocumnetSearchIcon);

				agSetValue(QueryByExamplePageObjects.CodeListSearchTextBox,
						FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "SupportDocs_DocCategory"));
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.codelistSearchIcon);
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.CodeListCheckBox);
				agSetStepExecutionDelay("3000");
				agClick(QueryByExamplePageObjects.SelectBtn);

				agSetValue(QueryByExamplePageObjects.FileNameValue,
						"sdef.xls");
				CommonOperations.captureScreenShot(true);
			}
			agClick(QueryByExamplePageObjects.clickSearch);

			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.INFO, "Search Based on Support Document Ended", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void SearchBasedonSourceSupportDcouments(String scenarioName,String scenarioName1) {
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (agIsVisible(QueryByExamplePageObjects.ExpandCaseDocumentBtn) == true) {
			agClick(QueryByExamplePageObjects.ExpandCaseDocumentBtn);
		}
		agWaitTillVisibilityOfElement(QueryByExamplePageObjects.SourceDocumentBtn);
		agClick(QueryByExamplePageObjects.SourceDocumentBtn);
		
		
		agWaitTillVisibilityOfElement(QueryByExamplePageObjects.Date);
		agClick(QueryByExamplePageObjects.Date);
		selectExpOperator("AndWithLIKEoperator", "RuleOperator");
		agSetStepExecutionDelay("3000");
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);

		agClick(QueryByExamplePageObjects.DocumentCategory);
		selectExpOperator("AndWithLIKEoperator", "RuleOperator");
		agSetStepExecutionDelay("3000");
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);

		agClick(QueryByExamplePageObjects.Filename);
		selectExpOperator("AndWithLIKEoperator", "RuleOperator");
		agSetStepExecutionDelay("3000");
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
		agClick(QueryByExamplePageObjects.StartDate);
		agSetValue(QueryByExamplePageObjects.StartDate, CommonOperations
				.returnDateTime(FDE_General.getData(scenarioName, "Gen_CaseDates_InitialReceivedDate")));
		agClick(QueryByExamplePageObjects.EndDate);
		agSetValue(QueryByExamplePageObjects.EndDate, CommonOperations
				.returnDateTime(FDE_General.getData(scenarioName, "Gen_CaseDates_LatestReceivedDate")));
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseDocumentsOperations");
		agClick(QueryByExamplePageObjects.DocumnetSearchIcon);
		agSetValue(QueryByExamplePageObjects.CodeListSearchTextBox,
				FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "SourceDocs_DocCategory"));

		agClick(QueryByExamplePageObjects.codelistSearchIcon);
		agSetStepExecutionDelay("3000");
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.CodeListCheckBox);
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.SelectBtn);

		agSetValue(QueryByExamplePageObjects.FileNameValue,
				FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName, "Filename"));
		if (agIsVisible(QueryByExamplePageObjects.ExpandCaseDocumentBtn) == true) {
			agClick(QueryByExamplePageObjects.ExpandCaseDocumentBtn);
		}
		agWaitTillVisibilityOfElement(QueryByExamplePageObjects.SupportDocumentBtn);
		agClick(QueryByExamplePageObjects.SupportDocumentBtn);
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agWaitTillVisibilityOfElement(QueryByExamplePageObjects.Date);
		agClick(QueryByExamplePageObjects.Date);
		selectExpOperator("AndWithLIKEoperator", "RuleOperator");
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);

		agClick(QueryByExamplePageObjects.DocumentCategory);
		selectExpOperator("AndWithLIKEoperator", "RuleOperator");
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);

		agClick(QueryByExamplePageObjects.Filename);
		selectExpOperator("AndWithLIKEoperator", "RuleOperator");
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		agSetValue(QueryByExamplePageObjects.StartDate1, CommonOperations
				.returnDateTime(FDE_General.getData(scenarioName1, "Gen_CaseDates_InitialReceivedDate")));
		agSetValue(QueryByExamplePageObjects.EndDate1, CommonOperations
				.returnDateTime(FDE_General.getData(scenarioName1, "Gen_CaseDates_LatestReceivedDate")));
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseDocumentsOperations");
		agClick(QueryByExamplePageObjects.DocumnetSearchIcon1);
		agSetValue(QueryByExamplePageObjects.CodeListSearchTextBox,
				FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName1, "SupportDocs_DocCategory"));
		agSetStepExecutionDelay("3000");
		agClick(QueryByExamplePageObjects.codelistSearchIcon);
		agSetStepExecutionDelay("3000");
		agClick(QueryByExamplePageObjects.CodeListCheckBox);
		agSetStepExecutionDelay("3000");
		agClick(QueryByExamplePageObjects.SelectBtn);

		agSetValue(QueryByExamplePageObjects.FileName2,
				FDE_CaseDocumentsOperations.getTestDataCellValue(scenarioName1, "SupportFilename"));
		CommonOperations.captureScreenShot(true);
		
		agClick(QueryByExamplePageObjects.clickSearch);
		
		
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to To Search Retrive
	 *             Cases(Requirement Specific)
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 17-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SearchResultRetreiveCases(String Scenario) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Search Receipt Numbers Based on Conditions Started", true);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			// ArrayList<String> Names = QueryByExample.GetReciptNumbersList();
			//
			// int count = Names.size();
			// ArrayList<String> Al = new ArrayList<>();
				
			agClick(QueryByExamplePageObjects.SortRecieptNumber);
			agSetStepExecutionDelay("2000");
			agClick(QueryByExamplePageObjects.SortRecieptNumber);
			
			
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
			String AER0 = FDE_General.getTestDataCellValue("QBEBasedonCaseDocuments_001", "ReceiptNo");
			String AER1 = FDE_General.getTestDataCellValue("QBEBasedonCaseDocuments_002", "ReceiptNo");
			String AER2 = FDE_General.getTestDataCellValue("QBEBasedonCaseDocuments_003", "ReceiptNo");
			String AER3 = FDE_General.getTestDataCellValue("QBEBasedonCaseDocuments_004", "ReceiptNo");
			String AER4 = FDE_General.getTestDataCellValue("QBEBasedonCaseDocuments_005", "ReceiptNo");
			String AER5 = FDE_General.getTestDataCellValue("QBEBasedonCaseDocuments_006", "ReceiptNo");
			String AER6 = FDE_General.getTestDataCellValue("QBEBasedonCaseDocuments_007", "ReceiptNo");
			String AER7 = FDE_General.getTestDataCellValue("QBEBasedonCaseDocuments_008", "ReceiptNo");

			String AER8 = FDE_General.getTestDataCellValue("QBEBasedonCaseDocuments_009", "ReceiptNo");
			String AER9 = FDE_General.getTestDataCellValue("QBEBasedonCaseDocuments_010", "ReceiptNo");
			String AER10 = FDE_General.getTestDataCellValue("QBEBasedonCaseDocuments_011", "ReceiptNo");
			String AER11 = FDE_General.getTestDataCellValue("QBEBasedonCaseDocuments_012", "ReceiptNo");
			String AER12 = FDE_General.getTestDataCellValue("QBEBasedonCaseDocuments_013", "ReceiptNo");
			String AER13 = FDE_General.getTestDataCellValue("QBEBasedonCaseDocuments_014", "ReceiptNo");
			String AER14 = FDE_General.getTestDataCellValue("QBEBasedonCaseDocuments_015", "ReceiptNo");

			// loop to find contacts in Search Box
			// for (int i = 0; i < count; i++) {
			// String ReciptNO = Names.get(i);
			// Al.add(i, ReciptNO);
			//
			// }
			agSetStepExecutionDelay("3000");
			
			if(Scenario.equalsIgnoreCase("0")) {
				
				if (agIsVisible(QueryByExamplePageObjects.RNumber(AER0)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER1)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER2)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER3)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER4)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER5)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER6)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER7)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER8)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER9)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER10)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER11)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER12)) == true				
						
						) 
				{
					Reports.ExtentReportLog("", Status.PASS, "As Expected"+
							"<br />"+"Support Documents" + 
							"<br />"+"Date From" + 
							"<br />"+CommonOperations.returnDateTime(FDE_General.getData("QBEBasedonCaseDocuments_001", "Gen_CaseDates_InitialReceivedDate"))+ 
							"<br />"+"To "+ 
							"<br />"+CommonOperations.returnDateTime(FDE_General.getData("QBEBasedonCaseDocuments_001", "Gen_CaseDates_LatestReceivedDate"))+ "\n  Corresponding cases which matches the criteria as specified in the Test Data are displayed'+", true);
				}	
				
			}
			if(Scenario.equalsIgnoreCase("00")) {
				
				if (agIsVisible(QueryByExamplePageObjects.RNumber(AER0)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER1)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER2)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER3)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER4)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER5)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER6)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER7)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER8)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER9)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER10)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER11)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER12)) == true				
						
						) 
				{
					Reports.ExtentReportLog("", Status.PASS, "As Expected"+
							"<br />"+"Source Documents" + 
							"<br />"+"Date From" + 
							"<br />"+CommonOperations.returnDateTime(FDE_General.getData("QBEBasedonCaseDocuments_001", "Gen_CaseDates_InitialReceivedDate"))+ 
							"<br />"+"To "+ 
							"<br />"+CommonOperations.returnDateTime(FDE_General.getData("QBEBasedonCaseDocuments_001", "Gen_CaseDates_LatestReceivedDate"))+ "\n  Corresponding cases which matches the criteria as specified in the Test Data are displayed'+", true);
				}	
				
			}
			
			
			
			if(Scenario.equalsIgnoreCase("1")) {
				
				if (agIsVisible(QueryByExamplePageObjects.RNumber(AER0)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER1)) == true) {
					Reports.ExtentReportLog("", Status.PASS,"Scenario 1 " +AER0 + " and " + AER1 + " Exist for the Given Condition <br />", true);
					//CommonOperations.captureScreenShot(true);
				}
			}
			
			else if(Scenario.equalsIgnoreCase("S1")) {
				if (agIsVisible(QueryByExamplePageObjects.RNumber(AER0)) == true
					) {
					Reports.ExtentReportLog("", Status.PASS, "As Expected"+
							"<br />"+"Support Documents" + 
							"<br />"+"Document Category" + 
							"<br />"+"Adverse Event Report Form" + 
							"<br />"+"File Name:sabc.pdf" + 
							"<br />"+"Date" + 
							"<br />"+"From: "+
							"<br />"+CommonOperations.returnDateTime(FDE_General.getData("QBEBasedonCaseDocuments_001", "Gen_CaseDates_InitialReceivedDate"))+ 
							"<br />"+"To: " + 
							"<br />"+CommonOperations.returnDateTime(FDE_General.getData("QBEBasedonCaseDocuments_001", "Gen_CaseDates_LatestReceivedDate"))+ 
							" \nCorresponding cases "+AER0+" which matches the criteria as specified in the Test Data are displayed<br />", true);
					
				}
			}
			else if(Scenario.equalsIgnoreCase("S13")) {
				if (agIsVisible(QueryByExamplePageObjects.RNumber(AER12)) == true
					) {
					Reports.ExtentReportLog("", Status.PASS,"As Expected"+
							"<br />"+AER12 + " Exist for the Given Condition", true);
					CommonOperations.captureScreenShot(true);
					
				}
			}
			else if(Scenario.equalsIgnoreCase("2")) {
				if (agIsVisible(QueryByExamplePageObjects.RNumber(AER0)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER1)) == true) {
					Reports.ExtentReportLog("", Status.PASS, "Scenario 2 " +AER0 + " and " + AER1 + "  Exist for the Given Condition<br />", true);
					//CommonOperations.captureScreenShot(true);
				}
			
			}
			else if(Scenario.equalsIgnoreCase("3")) {
				if (agIsVisible(QueryByExamplePageObjects.RNumber(AER2)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER3)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER4)) == true) {
					Reports.ExtentReportLog("", Status.INFO, "Scenario3 " +AER2 + "," + AER3 + "and" + AER4 + "  Exist for the Given Condition<br />",
							true);
					//CommonOperations.captureScreenShot(true);
				}
				
			}
			else if(Scenario.equalsIgnoreCase("4")) {
				if (agIsVisible(QueryByExamplePageObjects.RNumber(AER2)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER3)) == true) {
					Reports.ExtentReportLog("", Status.PASS,"Scenario 4 " + AER2 + " and " + AER3 + "  Exist for the Given Condition<br />", true);
					//CommonOperations.captureScreenShot(true);
				}
			}
			else if(Scenario.equalsIgnoreCase("5")) {
				
				if (agIsVisible(QueryByExamplePageObjects.RNumber(AER2)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER3)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER4)) == true) {
					Reports.ExtentReportLog("", Status.PASS,"Scenario 5 " + AER2 + "," + AER3 + " and " + AER4 + " Exist for the Given Condition<br />",
							true);
					//CommonOperations.captureScreenShot(true);
				}
			}
			else if(Scenario.equalsIgnoreCase("6")) {
				if (agIsVisible(QueryByExamplePageObjects.RNumber(AER5)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER6)) == true) {
					Reports.ExtentReportLog("", Status.PASS, "Scenario 6 " +AER5 + " and " + AER6 + "  Exist for the Given Condition<br />", true);
				//	CommonOperations.captureScreenShot(true);
				}
				
			}
			
			else if(Scenario.equalsIgnoreCase("7")) {
				if (agIsVisible(QueryByExamplePageObjects.RNumber(AER7)) == true
						&& agIsVisible(QueryByExamplePageObjects.RNumber(AER9)) == true) {
					Reports.ExtentReportLog("", Status.PASS, "Scenario 7 " +AER7 + " and " + AER9 + "  Exist for the Given Condition<br />", true);
				//	CommonOperations.captureScreenShot(true);
				}
				
			}
			else if(Scenario.equalsIgnoreCase("S8")) {
				 if (agIsVisible(QueryByExamplePageObjects.RNumber(AER10)) == true) {
						Reports.ExtentReportLog("", Status.PASS, "As Expected"+
								"<br />"+"Source Documents" + 
								"<br />"+"Document Category:" + 
								"<br />"+"E2B Summary sheet" + 
								"<br />"+"File Name:mno1.pdf" +  
								"<br />"+"Date\r\n" + 
								"<br />"+"From:"+CommonOperations.returnDateTime(FDE_General.getData("QBEBasedonCaseDocuments_001", "Gen_CaseDates_InitialReceivedDate"))+ 
								"<br />"+
								"<br />"+"To: " + 
								"<br />"+CommonOperations.returnDateTime(FDE_General.getData("QBEBasedonCaseDocuments_001", "Gen_CaseDates_LatestReceivedDate"))+ 
								"\n Corresponding cases "+AER0+" which matches the criteria as specified in the Test Data are displayed<br />", true);
						
				 }
			}else if(Scenario.equalsIgnoreCase("8")) {
				if (agIsVisible(QueryByExamplePageObjects.RNumber(AER8)) == true) {
					Reports.ExtentReportLog("", Status.PASS,"Scenario 8 " + AER8+ "  Exist for the Given Condition<br />", true);
					//CommonOperations.captureScreenShot(true);
				}
			}
			
			else if(Scenario.equalsIgnoreCase("9")) {
				 if (agIsVisible(QueryByExamplePageObjects.RNumber(AER5)) == true
							&& agIsVisible(QueryByExamplePageObjects.RNumber(AER6)) == true
							&& agIsVisible(QueryByExamplePageObjects.RNumber(AER7)) == true
							&& agIsVisible(QueryByExamplePageObjects.RNumber(AER9)) == true
							&& agIsVisible(QueryByExamplePageObjects.RNumber(AER10)) == true
							&& agIsVisible(QueryByExamplePageObjects.RNumber(AER11)) == true
							&& agIsVisible(QueryByExamplePageObjects.RNumber(AER12)) == true) {
						Reports.ExtentReportLog("", Status.PASS,"Scenario 9 " + AER5 + ',' + AER6 + ',' + AER7 + ',' + ',' + AER9 + ','
								+ AER10 + ',' + AER11 + ',' + AER12 + " Exist for the Given Condition<br />", true);
						
					//	CommonOperations.captureScreenShot(true);
				 }
						
			}
			else if(Scenario.equalsIgnoreCase("10")) {
				if (agIsVisible(QueryByExamplePageObjects.RNumber(AER10)) == true) {
					Reports.ExtentReportLog("", Status.PASS,"Scenario 10 " + AER10 + "  Exist for the Given Condition<br />\"", true);
				//	CommonOperations.captureScreenShot(true);
				}
				
			}
			else if(Scenario.equalsIgnoreCase("11")) {
				if (agIsVisible(QueryByExamplePageObjects.RNumber(AER11)) == true) {
					Reports.ExtentReportLog("", Status.PASS, "Scenario 11 " +AER11 + " Exist for the Given Condition<br />", true);
					//CommonOperations.captureScreenShot(true);
				}
				
				
			}
				 
			else if(Scenario.equalsIgnoreCase("12")) {
				if (agIsVisible(QueryByExamplePageObjects.RNumber(AER11)) == true) {
					Reports.ExtentReportLog("", Status.PASS, "Scenario 12 " +AER11 + " Exist for the Given Condition<br />", true);
					//CommonOperations.captureScreenShot(true);
				}
				
				
			}
				 
			else if(Scenario.equalsIgnoreCase("13")) {
				if (agIsVisible(QueryByExamplePageObjects.RNumber(AER12)) == true) {
					Reports.ExtentReportLog("", Status.PASS,"Scenario 13 " + AER12 + "  Exist for the Given Condition<br />", true);
					//CommonOperations.captureScreenShot(true);
				}
				
			}
				else if(Scenario.equalsIgnoreCase("14")) {	
					if (agIsVisible(QueryByExamplePageObjects.RNumber(AER0)) == true
							&& agIsVisible(QueryByExamplePageObjects.RNumber(AER1)) == true
							&& agIsVisible(QueryByExamplePageObjects.RNumber(AER2)) == true) {
						Reports.ExtentReportLog("", Status.PASS,"Scenario 14 " + AER0 + "," + AER1 + " and " + AER2 + " Exist for the Given Condition<br />",
								true);
						//CommonOperations.captureScreenShot(true);
				}
			}else if(Scenario.equalsIgnoreCase("")) {
				Reports.ExtentReportLog("", Status.PASS, "As Expected"+
						"<br />"+ "Support Documents" + 
						"<br />"+"Document Category" + 
						"<br />"+"E2B Summary sheet" +  			
						"<br />"+"File Name:abc.pdf" + 
						"<br />"+"Date" + 
						"<br />"+"From: "+
						"<br />"+CommonOperations.returnDateTime(FDE_General.getData("QBEBasedonCaseDocuments_001", "Gen_CaseDates_InitialReceivedDate"))+ 
						"<br />"+"To: "+
						"<br />"+ CommonOperations.returnDateTime(FDE_General.getData("QBEBasedonCaseDocuments_001", "Gen_CaseDates_LatestReceivedDate"))+ 
						"<br />"+"Support Documents" + 
						"<br />"+"Document Category:Adverse Event Report/Form" + 
						"<br />"+"File Name:sabc.pdf" + 
						"<br />"+"Date" + 
						"<br />"+"From: "+
						CommonOperations.returnDateTime(FDE_General.getData("QBEBasedonCaseDocuments_001", "Gen_CaseDates_InitialReceivedDate"))+ 
						"<br />"+"To: " + 
						"<br />"+CommonOperations.returnDateTime(FDE_General.getData("QBEBasedonCaseDocuments_001", "Gen_CaseDates_LatestReceivedDate"))+ 
						
						
						"\n Corresponding cases "+AER0+" which matches the criteria as specified in the Test Data are displayed<br />", true);
			}
			
			
			Reports.ExtentReportLog("", Status.INFO, "Search Receipt Numbers Based on Conditions Ended", true);
			agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
			agClick(QueryByExamplePageObjects.backToQbeHeader);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to To Search Retrive
	 *             Cases(Requirement Specific)
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 17-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void RetreiveCase() {
		Reports.ExtentReportLog("", Status.INFO, "Search Receipt Numbers Based on Conditions Started", true);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		String AER14 = FDE_General.getTestDataCellValue("QBEBasedonCaseDocuments_015", "ReceiptNo");
		if (agIsVisible(QueryByExamplePageObjects.RNumber(AER14)) == true) {
			Reports.ExtentReportLog("", Status.PASS, AER14 + " Receipt Numbers Exist", true);
			agClick(QueryByExamplePageObjects.RNumber(AER14));

			int i = 0, sz = agGetWindowCount();
			agSetStepExecutionDelay("5000");
			while (!(sz == 2) && i < 75) {
				sz = agGetWindowCount();
				i++;
				System.out.println("Waiting" + i);
			}
			agGetCurrentWindow();
			FDE_Operations.FDE_Navigations("Case Documents");
			if (agIsVisible(FDE_CaseDocumentsPageObjects.FileName) == true) {
				Reports.ExtentReportLog("", Status.INFO, "User is Able to View the Supported Documents", true);
			} else {
				Reports.ExtentReportLog("", Status.INFO, "User is UnaSble to View the Supported Documents", true);
			}

		}
	}


	/**********************************************************************************************************
	 * @Objective: The below method is to Get list of Contacts from the Excel Sheet
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 18-February-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> GetReciptNumbersList() {

		ArrayList Al = new ArrayList<>();
		String st1;

		for (int i = 0; i < 11; i++) {

			Al.add(i, agGetElementList(QueryByExamplePageObjects.ReciptNoList));
		}
		return Al;
	}

	// /**********************************************************************************************************
	// * @Objective: The below method is to Get list of Contacts from the Excel
	// Sheet
	// * @InputParameters: Scenario Name
	// * @OutputParameters:
	// * @author:WajahatUmar S
	// * @Date : 18-February-2020
	// * @UpdatedByAndWhen:
	// **********************************************************************************************************/
	// public static ArrayList<String> GetReptListListFromExcel(String scenarioName)
	// {
	// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
	// ArrayList Al = new ArrayList<>();
	// String st1;
	//
	// for (int i = 0; i < 17; i++) {
	//
	// Al.add(i, agGetElementList(FDE_General.getTestDataCellValue(scenarioName,
	// "ReceiptNo")));
	// }
	// return Al;
	//
	// }

	/**********************************************************************************************************
	 * @Objective: The below method is created to search based on MedDRA PT for
	 *             Disease Term
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 21-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchByMedicalHistory(String scenarioName , String ALMStepNo , String Result1 ,String Result2 ,String Result3) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.almStepNumber(ALMStepNo);
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.showAllFields);
		selectExpOperator(scenarioName, "RuleOperator");
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
		searchAndSelectField(scenarioName, "SearchField1");
		if(getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}	
		Reports.ExtentReportLog("", Status.PASS, "As Expected", false);
		Reports.ExtentReportLog("", Status.PASS,"<br />" + " MedDRA PT for Disease Term.", false);
		
		int ALMStepNoCount1 = Integer.parseInt(ALMStepNo);
		int ALMStepsAddition1 = ALMStepNoCount1 + 1;
		String ALMCount1 = Integer.toString(ALMStepsAddition1);
		CommonOperations.almStepNumber(ALMCount1);
		selectFirstOperator(scenarioName, "ConditionOperator");
		agClick(QueryByExamplePageObjects.valueSearchIcon);
		agIsVisible(QueryByExamplePageObjects.meddraBrowserLookUp);
		if(getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}	
		Reports.ExtentReportLog("", Status.PASS, "As Expected", false);
		Reports.ExtentReportLog("", Status.PASS,"<br />" + " SOC lookup ", false);
		
		int ALMStepNoCount2 = Integer.parseInt(ALMCount1);
		int ALMStepsAddition2 = ALMStepNoCount2 + 1;
		String ALMCount2 = Integer.toString(ALMStepsAddition2);
		CommonOperations.almStepNumber(ALMCount2);		
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.SOCHLGTHLTlookUP);
		agSetStepExecutionDelay("8000");
		if(getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}	

		Reports.ExtentReportLog("", Status.PASS, "As Expected", false);
		
		int ALMStepNoCount3 = Integer.parseInt(ALMCount2);
		int ALMStepsAddition3 = ALMStepNoCount3 + 1;
		String ALMCount3 = Integer.toString(ALMStepsAddition3);
		CommonOperations.almStepNumber(ALMCount3);		
		agSetValue(QueryByExamplePageObjects.SOCInput, getTestDataCellValue(scenarioName, "Value1"));
		agClick(QueryByExamplePageObjects.SOCSearch);
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSOCSearchResultCheckbox);	
		if(getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}	
		Reports.ExtentReportLog("", Status.PASS, "As Expected", false);
		Reports.ExtentReportLog("", Status.PASS,"<br />" + " SOC CODE: 10007541", false);
		Reports.ExtentReportLog("", Status.PASS,"<br />" + " SOC NAME: Cardiac disorders", false);

		
		int ALMStepNoCount4 = Integer.parseInt(ALMCount3);
		int ALMStepsAddition4 = ALMStepNoCount4 + 1;
		String ALMCount4 = Integer.toString(ALMStepsAddition4);
		CommonOperations.almStepNumber(ALMCount4);	
		agClick(QueryByExamplePageObjects.selectBtn);
		agClick(QueryByExamplePageObjects.clickGetCount);
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		CommonOperations.captureScreenShot(true);
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		changeVersion("All Version");
		agSetStepExecutionDelay("5000");
		
		agClick(QueryByExamplePageObjects.SortRecieptNumber);
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects.SortRecieptNumber);
		
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		checkAerCaseInListing(Result1);
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CopyCase");
		checkAerCaseInListing(Result2);
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		checkAerCaseInListing(Result3);
		CommonOperations.captureScreenShot(true);
		String Result = getTotalCount();
		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.INFO, "Counts Matched Successfully ", false);
		} else {
			Reports.ExtentReportLog("", Status.INFO, " Counts Not Matched Successfully ", false);
		}
		Reports.ExtentReportLog("", Status.PASS, "As Expected", false);
		
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search for scenarios 1 result
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 21-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchScenarios1(String Result1 , String Result2, String Result3) {
		searchScenarios1_Scenario_1("Search1_Scenario_1_Condition_1", Result1 , Result2, Result3);
		searchScenarios1_Scenario_2("Search1_Scenario_2_Condition_1" , Result1 , Result2, Result3);
		searchScenarios1_Scenario_3("Search1_Scenario_3_Condition_1" , Result1 , Result2, Result3);
		searchScenarios1_Scenario_4("Search1_Scenario_4_Condition_1" , Result1 , Result2, Result3);
		searchScenarios1_Scenario_5("Search1_Scenario_5_Condition_1" , Result1 , Result2, Result3);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search based on scenario_1 under
	 *             search scenarios 1 condition
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 21-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchScenarios1_Scenario_1(String scenarioName ,String Result1 ,String Result2, String Result3) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// agJavaScriptExecuctorClick(QueryByExamplePageObjects.showAllFields);
		selectExpOperator(scenarioName, "RuleOperator");
		for (int i = 1; i <= 4; i++) {
			agClick(QueryByExamplePageObjects.clickCondition);
			agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
			searchAndSelectField("Search1_Scenario_1_Condition_" + i, "SearchField1");
			//selectConditionOperator("Search1_Scenario_1_Condition_" + i, "ConditionOperator", i);
			clickSearch(i);
			agIsVisible(QueryByExamplePageObjects.meddraBrowserLookUp);
			agJavaScriptExecuctorClick(QueryByExamplePageObjects.SOCHLGTHLTlookUP);
			agSetValue(QueryByExamplePageObjects.SOCInput,
					getTestDataCellValue("Search1_Scenario_1_Condition_" + i, "Value1"));
			agClick(QueryByExamplePageObjects.SOCSearch);
			agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSOCSearchResultCheckbox);
			agClick(QueryByExamplePageObjects.selectBtn);
			agClearText(QueryByExamplePageObjects.fieldSearch);
		}
		SelectWorkflowStatus(scenarioName);
		agClick(QueryByExamplePageObjects.clickGetCount);
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		CommonOperations.captureScreenShot(true);
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		changeVersion("All Version");
		agSetStepExecutionDelay("5000");
		
		agClick(QueryByExamplePageObjects.SortRecieptNumber);
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects.SortRecieptNumber);
		
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		checkAerCaseInListing(Result1);
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CopyCase");
		checkAerCaseInListing(Result2);
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		checkAerCaseInListing(Result3);
		CommonOperations.captureScreenShot(true);
		String Result = getTotalCount();
		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.INFO, " Counts Matched Successfully ", false);
		} else {
			Reports.ExtentReportLog("", Status.INFO, " Counts Not Matched Successfully ", false);
		}
		agClick(QueryByExamplePageObjects.backToQbeHeader);
		clearQuery();
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to search the receipt number by using
	 *             condition and verify get the count
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 18-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAERNum(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		selectExpOperator("AndWithLIKEoperator", "RuleOperator");
		
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
		agClick(QueryByExamplePageObjects.showAllFields);
		
		
		agSetValue(QueryByExamplePageObjects.fieldSearch, getTestDataCellValue(scenarioName, "SearchField1"));
		agClick(QueryByExamplePageObjects.searchIcon);
		agSetStepExecutionDelay("2000");
	
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.aerNumber);
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "DataAssessmentOperations");
		agSetValue(QueryByExamplePageObjects.AERNumbertextBox, getTestDataCellValue(scenarioName, "AERNo"));
		agSetStepExecutionDelay("2000");
		CommonOperations.captureScreenShot(true);
		agClick(QueryByExamplePageObjects.clickSearch);
		
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select condition operator based on
	 *             loop
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 21-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void selectConditionOperator(String scenarioName, String columnName, int i) {
		String Count = String.valueOf(i);
		agClick(QueryByExamplePageObjects.selectCondition(Count));
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects.selectConditionOperator(getTestDataCellValue(scenarioName, columnName)));
	}
	
	public static void selectChildConditionOperator(String scenarioName, String columnName, int i) {
		String Count = String.valueOf(i);
		agClick(QueryByExamplePageObjects.selectChildCondition(Count));
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects.selectConditionOperator(getTestDataCellValue(scenarioName, columnName)));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select search icon based on loop
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 21-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickSearch(int i) {
		String Count = String.valueOf(i);
		agClick(QueryByExamplePageObjects.selectSearch(Count));
	}
	
	public static void clickChildSearch(int i) {
		String Count = String.valueOf(i);
		agClick(QueryByExamplePageObjects.selectChildSearch(Count));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Workflow status
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 21-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SelectWorkflowStatus(String scenarioName) {
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.workflowStatusDD);
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects.selectWorkflowStatus(getTestDataCellValue(scenarioName, "Workflow_Status")));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search based on scenario_1 under
	 *             search scenarios 2 condition
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 21-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchScenarios1_Scenario_2(String scenarioName ,String Result1 ,String Result2, String Result3) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// agJavaScriptExecuctorClick(QueryByExamplePageObjects.showAllFields);
		selectExpOperator(scenarioName, "RuleOperator");
		for (int i = 1; i <= 2; i++) {
			agClick(QueryByExamplePageObjects.clickCondition);
			agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
			searchAndSelectField("Search1_Scenario_2_Condition_" + i, "SearchField1");
			//selectConditionOperator("Search1_Scenario_2_Condition_" + i, "ConditionOperator", i);
			clickSearch(i);
			agIsVisible(QueryByExamplePageObjects.meddraBrowserLookUp);
			agJavaScriptExecuctorClick(QueryByExamplePageObjects.SOCHLGTHLTlookUP);
			agSetValue(QueryByExamplePageObjects.SOCInput,
					getTestDataCellValue("Search1_Scenario_2_Condition_" + i, "Value1"));
			agClick(QueryByExamplePageObjects.SOCSearch);
			agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSOCSearchResultCheckbox);
			agClick(QueryByExamplePageObjects.selectBtn);
			agClearText(QueryByExamplePageObjects.fieldSearch);
		}
		agClick(QueryByExamplePageObjects.clickGroup);
		agIsVisible(QueryByExamplePageObjects.conditionTree);
		for (int j = 3; j <= 4; j++) {
			selectTreeExpOperator("Search1_Scenario_2_Condition_" + j, "TreeRuleOperator");
			agClick(QueryByExamplePageObjects.treeConditionClick);
			searchAndSelectField("Search1_Scenario_2_Condition_" + j, "SearchField1");
			//selectChildConditionOperator("Search1_Scenario_2_Condition_" + (j-2), "ConditionOperator", (j-2));
			clickChildSearch((j-2));
			agIsVisible(QueryByExamplePageObjects.meddraBrowserLookUp);
			agJavaScriptExecuctorClick(QueryByExamplePageObjects.SOCHLGTHLTlookUP);
			agSetValue(QueryByExamplePageObjects.SOCInput,
					getTestDataCellValue("Search1_Scenario_2_Condition_" + j, "Value1"));
			agClick(QueryByExamplePageObjects.SOCSearch);
			agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSOCSearchResultCheckbox);
			agClick(QueryByExamplePageObjects.selectBtn);
			agClearText(QueryByExamplePageObjects.fieldSearch);
		}
		for (int k = 2; k <= 3; k++) {
			if (k == 2) {
				SelectApprovalStatus("Search1_Scenario_2_Condition_" + k);
			} else {
				SelectApprovalStatus("Search1_Scenario_2_Condition_" + k);
			}
			agClick(QueryByExamplePageObjects.clickGetCount);
			String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
			CommonOperations.captureScreenShot(true);
			agClick(QueryByExamplePageObjects.clickSearch);
			agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
			agSetStepExecutionDelay("3000");
			changeVersion("All Version");
			agSetStepExecutionDelay("5000");
			if (k == 2) {
				
				agClick(QueryByExamplePageObjects.SortRecieptNumber);
				agSetStepExecutionDelay("2000");
				agClick(QueryByExamplePageObjects.SortRecieptNumber);
				
				//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
				checkAerCaseInListing(Result1);
			} else {
				
				agClick(QueryByExamplePageObjects.SortRecieptNumber);
				agSetStepExecutionDelay("2000");
				agClick(QueryByExamplePageObjects.SortRecieptNumber);
				
				//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CopyCase");
				checkAerCaseInListing(Result2);
				//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
				checkAerCaseInListing(Result3);
			}
			CommonOperations.captureScreenShot(true);
			String Result = getTotalCount();
			if (getcountResult.equals(Result)) {
				Reports.ExtentReportLog("", Status.INFO, " Counts Matched Successfully ", false);
			} else {
				Reports.ExtentReportLog("", Status.INFO, " Counts Not Matched Successfully ", false);
			}
			agClick(QueryByExamplePageObjects.backToQbeHeader);
			agSetStepExecutionDelay("2000");
			agIsVisible(QueryByExamplePageObjects.qbeBuilderHeader);
		}

		clearQuery();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search based on scenario_1 under
	 *             search scenarios 3 condition
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 21-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchScenarios1_Scenario_3(String scenarioName ,String Result1 , String Result2, String Result3) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// agJavaScriptExecuctorClick(QueryByExamplePageObjects.showAllFields);
		selectExpOperator(scenarioName, "RuleOperator");
		for (int i = 1; i <= 4; i++) {
			agClick(QueryByExamplePageObjects.clickCondition);
			agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
			searchAndSelectField("Search1_Scenario_3_Condition_" + i, "SearchField1");
			//selectConditionOperator("Search1_Scenario_3_Condition_" + i, "ConditionOperator", i);
			clickSearch(i);
			agIsVisible(QueryByExamplePageObjects.meddraBrowserLookUp);
			agJavaScriptExecuctorClick(QueryByExamplePageObjects.SOCHLGTHLTlookUP);
			agSetValue(QueryByExamplePageObjects.SOCInput,
					getTestDataCellValue("Search1_Scenario_3_Condition_" + i, "Value1"));
			agClick(QueryByExamplePageObjects.SOCSearch);
			agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSOCSearchResultCheckbox);
			agClick(QueryByExamplePageObjects.selectBtn);
			agClearText(QueryByExamplePageObjects.fieldSearch);
		}
		SelectWorkflowStatus(scenarioName);
		agClick(QueryByExamplePageObjects.clickGetCount);
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		CommonOperations.captureScreenShot(true);
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		changeVersion("All Version");
		agSetStepExecutionDelay("5000");
		
		agClick(QueryByExamplePageObjects.SortRecieptNumber);
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects.SortRecieptNumber);
		
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		checkAerCaseInListing(Result1);
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CopyCase");
		checkAerCaseInListing(Result2);
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		checkAerCaseInListing(Result3);
		CommonOperations.captureScreenShot(true);
		String Result = getTotalCount();
		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.INFO, " Counts Matched Successfully ", false);
		} else {
			Reports.ExtentReportLog("", Status.INFO, " Counts Not Matched Successfully ", false);
		}
		agClick(QueryByExamplePageObjects.backToQbeHeader);
		clearQuery();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search based on scenario_1 under
	 *             search scenarios 4 condition
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 21-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchScenarios1_Scenario_4(String scenarioName ,String Result1 ,String Result2, String Result3) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// agJavaScriptExecuctorClick(QueryByExamplePageObjects.showAllFields);
		selectExpOperator(scenarioName, "RuleOperator");
		for (int i = 1; i <= 2; i++) {
			agClick(QueryByExamplePageObjects.clickCondition);
			agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
			searchAndSelectField("Search1_Scenario_4_Condition_" + i, "SearchField1");
			//selectConditionOperator("Search1_Scenario_4_Condition_" + i, "ConditionOperator", i);
			clickSearch(i);
			agIsVisible(QueryByExamplePageObjects.meddraBrowserLookUp);
			agJavaScriptExecuctorClick(QueryByExamplePageObjects.SOCHLGTHLTlookUP);
			agSetValue(QueryByExamplePageObjects.SOCInput,
					getTestDataCellValue("Search1_Scenario_4_Condition_" + i, "Value1"));
			agClick(QueryByExamplePageObjects.SOCSearch);
			agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSOCSearchResultCheckbox);
			agClick(QueryByExamplePageObjects.selectBtn);
			agClearText(QueryByExamplePageObjects.fieldSearch);
		}
		agClick(QueryByExamplePageObjects.clickExclusionGroup);
		agIsVisible(QueryByExamplePageObjects.excludeConditionTree);
		for (int j = 3; j <= 4; j++) {
			selectExcludeTreeExpOperator("Search1_Scenario_4_Condition_" + j, "TreeRuleOperator");
			agClick(QueryByExamplePageObjects.excludeTreeConditionClick);
			searchAndSelectField("Search1_Scenario_4_Condition_" + j, "SearchField1");
			//selectChildConditionOperator("Search1_Scenario_4_Condition_" + (j-2), "ConditionOperator", (j-2));
			clickChildSearch((j-2));
			agIsVisible(QueryByExamplePageObjects.meddraBrowserLookUp);
			agJavaScriptExecuctorClick(QueryByExamplePageObjects.SOCHLGTHLTlookUP);
			agSetValue(QueryByExamplePageObjects.SOCInput,
					getTestDataCellValue("Search1_Scenario_4_Condition_" + j, "Value1"));
			agClick(QueryByExamplePageObjects.SOCSearch);
			agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSOCSearchResultCheckbox);
			agClick(QueryByExamplePageObjects.selectBtn);
			agClearText(QueryByExamplePageObjects.fieldSearch);
		}
		SelectApprovalStatus("Search1_Scenario_4_Condition_1");
		agClick(QueryByExamplePageObjects.clickGetCount);
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		CommonOperations.captureScreenShot(true);
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		changeVersion("All Version");
		agSetStepExecutionDelay("5000");
		
		agClick(QueryByExamplePageObjects.SortRecieptNumber);
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects.SortRecieptNumber);
		
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		checkAerCaseInListing(Result1);
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CopyCase");
		checkAerCaseInListing(Result2);
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		checkAerCaseInListing(Result3);
		CommonOperations.captureScreenShot(true);
		String Result = getTotalCount();
		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.INFO, " Counts Matched Successfully ", false);
		} else {
			Reports.ExtentReportLog("", Status.INFO, " Counts Not Matched Successfully ", false);
		}
		agClick(QueryByExamplePageObjects.backToQbeHeader);

		clearQuery();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search based on scenario_1 under
	 *             search scenarios 5 condition
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 21-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchScenarios1_Scenario_5(String scenarioName ,String Result1 ,String Result2, String Result3) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// agJavaScriptExecuctorClick(QueryByExamplePageObjects.showAllFields);
		for (int i = 1; i <= 2; i++) {
			selectExpOperator("Search1_Scenario_5_Condition_" + i, "RuleOperator");
			agClick(QueryByExamplePageObjects.clickCondition);
			agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
			searchAndSelectField("Search1_Scenario_5_Condition_" + i, "SearchField1");
			//selectConditionOperator("Search1_Scenario_5_Condition_" + i, "ConditionOperator", i);
			clickSearch(i);
			agIsVisible(QueryByExamplePageObjects.meddraBrowserLookUp);
			agJavaScriptExecuctorClick(QueryByExamplePageObjects.SOCHLGTHLTlookUP);
			agSetValue(QueryByExamplePageObjects.SOCInput,
					getTestDataCellValue("Search1_Scenario_5_Condition_" + i, "Value1"));
			agClick(QueryByExamplePageObjects.SOCSearch);
			agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSOCSearchResultCheckbox);
			agClick(QueryByExamplePageObjects.selectBtn);
			agClearText(QueryByExamplePageObjects.fieldSearch);
		}
		SelectWorkflowStatus(scenarioName);
		agClick(QueryByExamplePageObjects.clickGetCount);
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		CommonOperations.captureScreenShot(true);
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		changeVersion("All Version");
		agSetStepExecutionDelay("5000");
		
		agClick(QueryByExamplePageObjects.SortRecieptNumber);
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects.SortRecieptNumber);
		
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		checkAerCaseInListing(Result1);
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CopyCase");
		checkAerCaseInListing(Result2);
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		checkAerCaseInListing(Result3);
		CommonOperations.captureScreenShot(true);
		String Result = getTotalCount();
		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.INFO, " Counts Matched Successfully ", false);
		} else {
			Reports.ExtentReportLog("", Status.INFO, " Counts Not Matched Successfully ", false);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to move back to QBE builder page
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 22-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void backToQBE() {
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agClick(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("2000");
		agIsVisible(QueryByExamplePageObjects.qbeBuilderHeader);
	}
	
	public static void backToQBEWithComfirmation() {
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agClick(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("2000");
		agIsVisible(QueryByExamplePageObjects.qbeBuilderHeader);
		agClick(QueryByExamplePageObjects.clearbtn);
		agIsVisible(QueryByExamplePageObjects.clearConfirmationPopUP);
		CommonOperations.captureScreenShot(true);		
	}

	public static void DOBSearchField(String scenarioName ,  String ALMStepNo, String Result1 , String Result2, String Result3) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.almStepNumber(ALMStepNo);
		selectExpOperator(scenarioName, "RuleOperator");
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
		searchAndSelectField(scenarioName, "SearchField1");	
		if(getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			agSetStepExecutionDelay("5000");
			CommonOperations.captureScreenShot(true);
		}	
		Reports.ExtentReportLog("", Status.PASS, "As Expected", false);
		Reports.ExtentReportLog("", Status.PASS,"<br />" + "Patient DOB ", false);
				
		int ALMStepNoCount = Integer.parseInt(ALMStepNo);
		int ALMStepsAddition = ALMStepNoCount + 1;
		String ALMCount = Integer.toString(ALMStepsAddition);
		CommonOperations.almStepNumber(ALMCount);
		//selectFirstOperator(scenarioName, "ConditionOperator");
		CommonOperations.captureScreenShot(true);		
		Reports.ExtentReportLog("", Status.PASS, "As Expected", false);
		Reports.ExtentReportLog("", Status.PASS,"<br />" + "Equals, Not Equals ", false);
		
		
		int ALMStepNoCount1 = Integer.parseInt(ALMCount);
		int ALMStepsAddition1 = ALMStepNoCount1 + 1;
		String ALMCount1 = Integer.toString(ALMStepsAddition1);
		CommonOperations.almStepNumber(ALMCount1);	
		agSetValue(QueryByExamplePageObjects.fromDate, getTestDataCellValue(scenarioName, "FromDate"));
		agSetValue(QueryByExamplePageObjects.toDate, getTestDataCellValue(scenarioName, "ToDate"));
		agClick(QueryByExamplePageObjects.clickGetCount);
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		CommonOperations.captureScreenShot(true);
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		changeVersion("All Version");
		agSetStepExecutionDelay("5000");		
		verifyCaseInListing(Result1,Result2,Result3);
		CommonOperations.captureScreenShot(true);	
		String Result = getTotalCount();
		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.INFO, " Counts Matched Successfully ", false);
		} else {
			Reports.ExtentReportLog("", Status.INFO, " Counts Not Matched Successfully ", false);
		}
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to search based on DOB fields
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 22-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void CommonDOBSearchField(String scenarioName, String Result1 , String Result2, String Result3) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		selectExpOperator(scenarioName, "RuleOperator");
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
		searchAndSelectField(scenarioName, "SearchField1");
		if(getTestDataCellValue(scenarioName, "NotEqualFlag").equalsIgnoreCase("YES")) {
			selectFirstOperator(scenarioName, "ConditionOperator");
		}
		agSetValue(QueryByExamplePageObjects.fromDate, getTestDataCellValue(scenarioName, "FromDate"));
		agSetValue(QueryByExamplePageObjects.toDate, getTestDataCellValue(scenarioName, "ToDate"));
		agClick(QueryByExamplePageObjects.clickGetCount);
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		CommonOperations.captureScreenShot(true);
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		changeVersion("All Version");
		agSetStepExecutionDelay("5000");
		verifyCaseInListing(Result1,Result2,Result3);
		CommonOperations.captureScreenShot(true);
		String Result = getTotalCount();
		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.INFO, " Counts Matched Successfully ", false);
		} else {
			Reports.ExtentReportLog("", Status.INFO, " Counts Not Matched Successfully ", false);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created verify activity log attributes
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 22-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyActivityLogAttributes() {

		agClick(QueryByExamplePageObjects.activityLog);
		agSetStepExecutionDelay("3000");
		agAssertVisible(QueryByExamplePageObjects.actionTaken);
		agAssertVisible(QueryByExamplePageObjects.activityLogDATEandTime);
		agAssertVisible(QueryByExamplePageObjects.takenBy);
		agAssertVisible(QueryByExamplePageObjects.workflowActivity);
		CommonOperations.captureScreenShot(true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify workflow activities
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 22-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyWorkflowActivity(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.showAllFields);
		selectExpOperator(scenarioName, "RuleOperator");
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
		searchAndSelectField(scenarioName, "SearchField1");
		selectFirstOperator(scenarioName, "ConditionOperator");
		agClick(QueryByExamplePageObjects.valueSearchIcon);
		agIsVisible(QueryByExamplePageObjects.listOfLibraryDataPopUP);
		String WorkFlowActivity = getTestDataCellValue(scenarioName, "Value1");
		String[] totalRecords = WorkFlowActivity.split(",");

		for (int i = 0; i < totalRecords.length; i++) {
			agSetValue(QueryByExamplePageObjects.librarySearchTextbox,totalRecords[i]);
			agClick(QueryByExamplePageObjects.librarySearch);
			status = agIsVisible(
					QueryByExamplePageObjects.WorkflowActivity(totalRecords[i]));
			if (status) {
				CommonOperations.captureScreenShot(true);
			} else {
				Reports.ExtentReportLog("", Status.INFO, " Workflow Activity not Exist ", false);
			}
			agClearText(QueryByExamplePageObjects.librarySearchTextbox);
			agSetStepExecutionDelay("3000");
		}
		agIsVisible(QueryByExamplePageObjects.closeListOfLibraryDataPopUp);	
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.closeListOfLibraryDataPopUp);	
		clearQuery();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search based on search scenario 2
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 22-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchScenarios2(String Result1) {
		searchScenarios2_Scenario_1("Search2_Scenario_1_Condition_1" , Result1);
		searchScenarios2_Scenario_2("Search2_Scenario_2_Condition_1");
		searchScenarios2_Scenario_3("Search2_Scenario_3_Condition_1" , Result1);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search based on search scenario 2
	 *             using scenario1
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 22-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchScenarios2_Scenario_1(String scenarioName ,String Result1) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		//agJavaScriptExecuctorClick(QueryByExamplePageObjects.showAllFields);
		selectExpOperator(scenarioName, "RuleOperator");
		for (int i = 1; i <= 4; i++) {
			agClick(QueryByExamplePageObjects.clickCondition);
			searchAndSelectField("Search2_Scenario_1_Condition_" + i, "SearchField1");
			//selectConditionOperator("Search2_Scenario_1_Condition_" + i, "ConditionOperator", i);
			if (i == 1) {
				clickSearch(i);
				agIsVisible(QueryByExamplePageObjects.listOfLibraryDataPopUP);
				agSetValue(QueryByExamplePageObjects.librarySearchTextbox,
						getTestDataCellValue("Search2_Scenario_1_Condition_" + i, "Value1"));
				agClick(QueryByExamplePageObjects.librarySearch);
				agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSOCSearchResultCheckbox);
				agClick(QueryByExamplePageObjects.selectBtn);
			} else if (i == 2) {
				clickSearch(i);
				agIsVisible(QueryByExamplePageObjects.listOfLibraryDataPopUP);
				agSetValue(QueryByExamplePageObjects.librarySearchTextbox,
						getTestDataCellValue("Search2_Scenario_1_Condition_" + i, "Value1"));
				agClick(QueryByExamplePageObjects.librarySearch);
				agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSOCSearchResultCheckbox);
				agClick(QueryByExamplePageObjects.selectBtn);
			} else if (i == 3) {
				agSetValue(QueryByExamplePageObjects.DateandTimeFromDate,CommonOperations
						.returnDateTime(getTestDataCellValue("Search2_Scenario_1_Condition_" + i, "FromDate")));
			} else {
				clickSearch(i);
				agIsVisible(QueryByExamplePageObjects.listOfLibraryDataPopUP);
				agSetValue(QueryByExamplePageObjects.librarySearchTextbox,
						getTestDataCellValue("Search2_Scenario_1_Condition_" + i, "Value1"));
				agClick(QueryByExamplePageObjects.librarySearch);
				agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSOCSearchResultCheckbox);
				agClick(QueryByExamplePageObjects.selectBtn);
			}
		}
		SelectWorkflowStatus(scenarioName);
		agClick(QueryByExamplePageObjects.clickGetCount);
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		CommonOperations.captureScreenShot(true);
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		changeVersion("All Version");
		agSetStepExecutionDelay("5000");
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		checkAerCaseInListing(Result1);
		CommonOperations.captureScreenShot(true);
		String Result = getTotalCount();
		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.INFO, " ", false);
		} else {
			Reports.ExtentReportLog("", Status.INFO, " Counts Not Matched Successfully ", false);
		}
		agClick(QueryByExamplePageObjects.backToQbeHeader);
		clearQuery();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search based on search scenario 2
	 *             using scenario2
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 22-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchScenarios2_Scenario_2(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		selectExpOperator(scenarioName, "RuleOperator");
		for (int i = 1; i <= 2; i++) {
			agClick(QueryByExamplePageObjects.clickCondition);
			searchAndSelectField("Search2_Scenario_2_Condition_" + i, "SearchField1");
			//selectConditionOperator("Search2_Scenario_2_Condition_" + i, "ConditionOperator", i);
			if (i == 1) {
				clickSearch(i);
				agIsVisible(QueryByExamplePageObjects.listOfLibraryDataPopUP);
				agSetValue(QueryByExamplePageObjects.librarySearchTextbox,
						getTestDataCellValue("Search2_Scenario_2_Condition_" + i, "Value1"));
				agClick(QueryByExamplePageObjects.librarySearch);
				agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSOCSearchResultCheckbox);
				agClick(QueryByExamplePageObjects.selectBtn);
			} else {
				clickSearch(i);
				agIsVisible(QueryByExamplePageObjects.listOfLibraryDataPopUP);
				agSetValue(QueryByExamplePageObjects.librarySearchTextbox,
						getTestDataCellValue("Search2_Scenario_2_Condition_" + i, "Value1"));
				agClick(QueryByExamplePageObjects.librarySearch);
				agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSOCSearchResultCheckbox);
				agClick(QueryByExamplePageObjects.selectBtn);
			}
		}
		SelectWorkflowStatus(scenarioName);
		agClick(QueryByExamplePageObjects.clickGetCount);
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		CommonOperations.captureScreenShot(true);
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		changeVersion("All Version");
		agSetStepExecutionDelay("10000");
//		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
//		checkAerCaseInListing(getTestDataCellValue("LSMV_OQ_QBE_Search_Main", "ReceiptNo"));
//		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CopyCase");
//		checkAerCaseInListing(getTestDataCellValue("LSMV_OQ_QBE_Search_Copy", "CopiedReceiptNo"));
//		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
//		checkAerCaseInListing(getTestDataCellValue("LSMV_OQ_QBE_Search_NewVersion", "ReceiptNo"));
		CommonOperations.captureScreenShot(true);
		String Result = getTotalCount();
		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.INFO, " Counts Matched Successfully ", false);
		} else {
			Reports.ExtentReportLog("", Status.INFO, " Counts Not Matched Successfully ", false);
		}
		agClick(QueryByExamplePageObjects.backToQbeHeader);
		clearQuery();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search based on search scenario 2
	 *             using scenario3
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 22-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchScenarios2_Scenario_3(String scenarioName , String Result1) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		//agJavaScriptExecuctorClick(QueryByExamplePageObjects.showAllFields);
		selectExpOperator(scenarioName, "RuleOperator");
		for (int i = 1; i <= 4; i++) {
			agClick(QueryByExamplePageObjects.clickCondition);
			searchAndSelectField("Search2_Scenario_3_Condition_" + i, "SearchField1");
			//selectConditionOperator("Search2_Scenario_3_Condition_" + i, "ConditionOperator", i);
			if (i == 1) {
				clickSearch(i);
				agJavaScriptExecuctorClick(QueryByExamplePageObjects.FDE);
				agJavaScriptExecuctorClick(QueryByExamplePageObjects.MR);
				agClick(QueryByExamplePageObjects.selectBtn);
			} else if (i == 2) {
				clickSearch(i);
				agJavaScriptExecuctorClick(QueryByExamplePageObjects.completeActivity);
				//agJavaScriptExecuctorClick(QueryByExamplePageObjects.copy);
				agClick(QueryByExamplePageObjects.selectBtn);
			} else if (i == 3) {
				agSetValue(QueryByExamplePageObjects.DateandTimeFromDate, CommonOperations
						.returnDateTime(getTestDataCellValue("Search2_Scenario_3_Condition_" + i, "FromDate")));
			} else {
				clickSearch(i);
				agIsVisible(QueryByExamplePageObjects.listOfLibraryDataPopUP);
				agSetValue(QueryByExamplePageObjects.librarySearchTextbox,
						getTestDataCellValue("Search2_Scenario_3_Condition_" + i, "Value1"));
				agClick(QueryByExamplePageObjects.librarySearch);
				agJavaScriptExecuctorClick(QueryByExamplePageObjects.checkSOCSearchResultCheckbox);
				agClick(QueryByExamplePageObjects.selectBtn);
			}
		}
		SelectWorkflowStatus(scenarioName);
		agClick(QueryByExamplePageObjects.clickGetCount);
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		CommonOperations.captureScreenShot(true);
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		changeVersion("All Version");
		agSetStepExecutionDelay("5000");
		//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		checkAerCaseInListing(Result1);
		CommonOperations.captureScreenShot(true);
		String Result = getTotalCount();
		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.INFO, " Counts Matched Successfully ", false);
		} else {
			Reports.ExtentReportLog("", Status.INFO, " Counts Not Matched Successfully ", false);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created export based on case Scenrio_2 of 3
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 22-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportCase() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		agClick(QueryByExamplePageObjects
				.checkCaseforExportInListing(FDE_General.getTestDataCellValue("LSMV_OQ_QBE_Search_Main", "ReceiptNo")));
		agSetStepExecutionDelay("2000");
		driver.findElement(By.xpath("//div[@class='gridSearchBarRight']/span[3][text()='Download']")).click();
		agIsVisible(QueryByExamplePageObjects.exportColumnPopUP);
		agSetStepExecutionDelay("5000");
		CommonOperations.captureScreenShot(true);
		agJavaScriptExecuctorClick(QueryByExamplePageObjects.QBEExportBtn);	
		agSetStepExecutionDelay("3000");
		agClick(QueryByExamplePageObjects.backToQbeHeader);
		clearQuery();
		closeCurrentBrowserWindow();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the AER Number
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 28-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyRCTNumbers(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		String Rctno = "";
		agSetStepExecutionDelay("2000");
		List<WebElement> list = agGetElementList(QueryByExamplePageObjects.getRCTNoList);
		for (int i = 1; i <= list.size(); i++) {
			Rctno = agGetText(QueryByExamplePageObjects.getRCTNo.replace("%count%", Integer.toString(i)));
			if (Rctno.equalsIgnoreCase(getTestDataCellValue(scenarioName, "ReceiptNo"))) {
				Reports.ExtentReportLog("", Status.PASS, "Receipt number Matched Successfully." + Rctno, true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Receipt number not Matched Successfully." + Rctno, true);
			}
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click report name
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 28-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickReport() {
		agSetStepExecutionDelay("2000");
		agClick(QueryByExamplePageObjects.clickMedwatch);
		agClick(QueryByExamplePageObjects.clickMedwatchReport);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search the Active substance
	 *             condition and verify get the count
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 09-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchProductIngredients(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		selectExpOperator(scenarioName, "RuleOperator");
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
		agSetValue(QueryByExamplePageObjects.fieldSearch, getTestDataCellValue(scenarioName, "SearchField1"));
		agClick(QueryByExamplePageObjects.searchIcon);
		agClick(QueryByExamplePageObjects.activeSubstance);
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		String sub = FDE_Products.getData(scenarioName, "Products_Ingredients_ActiveSubstance");
		agSetValue(QueryByExamplePageObjects.searchValueToCompare_TextBox, sub);
		agClick(QueryByExamplePageObjects.clickGetCount);
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		CommonOperations.takeScreenShot();
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		changeVersion("All Version");
		agSetStepExecutionDelay("5000");
		String Result = getTotalCounts();

		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.PASS, scenarioName + " Counts Matched Successfully ", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, scenarioName + " Counts Not Matched Successfully ", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the ReceiptNo and Aer No in QBE listing Page
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 15-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCaseInListingScreen(String TotalCounts) {
		String PageCount = null;
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		String Result1 = getTestDataCellValue("LSMV_OQ_QBE_Search_Main", "ReceiptNo");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CopyCase");
		String Result2 = getTestDataCellValue("LSMV_OQ_QBE_Search_Copy", "CopiedReceiptNo");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");	
		String Result3 = getTestDataCellValue("LSMV_OQ_QBE_Search_NewVersion", "ReceiptNo");
		boolean Result1Verify = false;
		boolean Result2Verify = false;
		boolean Result3Verify = false;
		int value = Integer.parseInt(TotalCounts) / 20;
		for (int i = 0 ; i<=value ; i++) {
			PageCount = getPagelCount();
		
		if(TotalCounts.equalsIgnoreCase(PageCount)) {
			
			if(Result1Verify == false) {
				//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
				status = agIsVisible(QueryByExamplePageObjects.checkCaseInListing(Result1));
				if(status) {
					agJavaScriptExecuctorScrollToElement(QueryByExamplePageObjects.checkCaseInListing(Result1));
					checkAerCaseInListing(Result1);
					Result1Verify = true;
				}
			}
			if(Result2Verify == false) {
				//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CopyCase");
				status = agIsVisible(QueryByExamplePageObjects.checkCaseInListing(Result2));
				if(status) {
					agJavaScriptExecuctorScrollToElement(QueryByExamplePageObjects.checkCaseInListing(Result2));
					checkAerCaseInListing(Result2);
					Result2Verify = true;
				}
			}
			if(Result3Verify == false) {
				//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");			
				status = agIsVisible(QueryByExamplePageObjects.checkCaseInListing(Result3));
				if(status) {
					agJavaScriptExecuctorScrollToElement(QueryByExamplePageObjects.checkCaseInListing(Result3));
					checkAerCaseInListing(Result3);
					Result3Verify = true;
				}
			}
			break;
		}else {
			if(Result1Verify == false) {
				//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
				status = agIsVisible(QueryByExamplePageObjects.checkCaseInListing(Result1));
				if(status) {
					agJavaScriptExecuctorScrollToElement(QueryByExamplePageObjects.checkCaseInListing(Result1));
					checkAerCaseInListing(Result1);
					Result1Verify = true;
				}
			}
			if(Result2Verify == false) {
				//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CopyCase");
				status = agIsVisible(QueryByExamplePageObjects.checkCaseInListing(Result2));
				if(status) {
					agJavaScriptExecuctorScrollToElement(QueryByExamplePageObjects.checkCaseInListing(Result2));
					checkAerCaseInListing(Result2);
					Result2Verify = true;
				}
			}
			if(Result3Verify == false) {
				//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");			
				status = agIsVisible(QueryByExamplePageObjects.checkCaseInListing(Result3));
				if(status) {
					agJavaScriptExecuctorScrollToElement(QueryByExamplePageObjects.checkCaseInListing(Result3));
					checkAerCaseInListing(Result3);
					Result3Verify = true;
				}
			}
		}
		if(!TotalCounts.equalsIgnoreCase(PageCount)) {
			agClick(QueryByExamplePageObjects.nextPage);
			agSetStepExecutionDelay("3000");
			}	
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the ReceiptNo and Aer No in QBE listing Page
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 19-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCaseInListing(String Result1 , String Result2, String Result3) {
//		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
//		String Result1 = getTestDataCellValue("LSMV_OQ_QBE_Search_Main", "ReceiptNo");
//		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CopyCase");
//		String Result2 = getTestDataCellValue("LSMV_OQ_QBE_Search_Copy", "CopiedReceiptNo");
//		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");	
//		String Result3 = getTestDataCellValue("LSMV_OQ_QBE_Search_NewVersion", "ReceiptNo");
		
		agClick(QueryByExamplePageObjects.SortRecieptNumber);
		agSetStepExecutionDelay("3000");
		agClick(QueryByExamplePageObjects.SortRecieptNumber);
		
		status = agIsVisible(QueryByExamplePageObjects.checkCaseInListing(Result1));
		if(status) {
			//agJavaScriptExecuctorScrollToElement(QueryByExamplePageObjects.checkCaseInListing(Result1));
			checkAerCaseInListing(Result1);
		}
		status = agIsVisible(QueryByExamplePageObjects.checkCaseInListing(Result2));
		if(status) {
			//agJavaScriptExecuctorScrollToElement(QueryByExamplePageObjects.checkCaseInListing(Result2));
			checkAerCaseInListing(Result2);
		}
		status = agIsVisible(QueryByExamplePageObjects.checkCaseInListing(Result3));
		if(status) {
			//agJavaScriptExecuctorScrollToElement(QueryByExamplePageObjects.checkCaseInListing(Result3));
			checkAerCaseInListing(Result3);
		}	
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to navigate to QBE and verify all the
	 *             fields
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Padmapriya
	 * @Date : 13-O1-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchCaseStatusDelete(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("10000");
		agClick(QueryByExamplePageObjects.clickCondition);
		agClick(QueryByExamplePageObjects.showAllFields);
		agSetValue(QueryByExamplePageObjects.fieldSearch, getTestDataCellValue(scenarioName, "SearchField1"));
		agClick(QueryByExamplePageObjects.searchIcon);
		agClick(QueryByExamplePageObjects.caseStatus);
		
		Reports.ExtentReportLog("", Status.PASS, "Condition" , true);
		//agSetValue(QueryByExamplePageObjects.searchValueToCompare_TextBox, "Delete");
		//agClick(QueryByExamplePageObjects.clickSearch);		
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to navigate to QBE and verify all the
	 *             fields
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Padmapriya
	 * @Date : 13-O1-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void selectTheCodelist(String scenarioName) {
	Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
	agClick(QueryByExamplePageObjects.firstvalueSearchIcon);
	agSetStepExecutionDelay("5000");
	agIsVisible(QueryByExamplePageObjects.codelistHeader);
	agSetValue(QueryByExamplePageObjects.codelistSearch, getTestDataCellValue(scenarioName, "Value1"));
	agClick(QueryByExamplePageObjects.codelistSearchIcon);
	agJavaScriptExecuctorClick(QueryByExamplePageObjects.codelistCheckBox);
	agClick(QueryByExamplePageObjects.codelistSelectBtn);
	agClick(QueryByExamplePageObjects.clickSearch);	
	Reports.ExtentReportLog("", Status.PASS, "selectTheCodelist" , true);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to navigate to QBE and verify all the
	 *             fields
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Padmapriya
	 * @Date : 13-O1-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void openTheSearchedCase(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if(agIsVisible(QueryByExamplePageObjects.searchedReceiptNo(getTestDataCellValue(scenarioName, "DeletedReceiptNo")))) {
			agClick(QueryByExamplePageObjects.searchedReceiptNo(getTestDataCellValue(scenarioName, "DeletedReceiptNo")));	
		 Reports.ExtentReportLog("", Status.PASS, "Receipt number found." , true);
		}
			else {
				Reports.ExtentReportLog("", Status.FAIL, "Receipt number not found.", true);			
	}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the ReceiptNo and Aer No in QBE listing Page
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Kishore K R
	 * @Date : 16-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createNewVersion(String scenarioName) {
		
		getTestData(lsmvConstants.LSMV_testData, "DataAssessmentOperations");
		agClick(QueryByExamplePageObjects.aerNoCheckBox(getTestDataCellValue(scenarioName, "AERNo")));
		agMouseHover(QueryByExamplePageObjects.moreOptionsBtn);
		agClick(QueryByExamplePageObjects.createNewVersLink);	
		getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.incremAlmStepNo();
		if(agIsVisible(QueryByExamplePageObjects.workflowActivitySelect)) {
			Reports.ExtentReportLog("", Status.PASS, "Create New Version window is opened ", true);
		}
		else {
			Reports.ExtentReportLog("", Status.FAIL, "Create New Version window not opened ", true);
		}
		String wa=getTestDataCellValue(scenarioName, "WorkflowActivity");
		String reason=getTestDataCellValue(scenarioName, "Reason");
		String cmmts=getTestDataCellValue(scenarioName, "Comments");
		agSelectByVisibleText(QueryByExamplePageObjects.workflowActivitySelect, wa);
		agSelectByVisibleText(QueryByExamplePageObjects.reasonSelect, reason);
		agSetValue(QueryByExamplePageObjects.aerCommsForVersTxtArea, cmmts);
		Reports.ExtentReportLog("", Status.PASS, "Workflow Activity: "+wa+" and Reason:"+reason+" is selected", true);
		CommonOperations.incremAlmStepNo();
		agClick(QueryByExamplePageObjects.submitBtn);
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the new version is created in Case Opened
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Kishore K R
	 * @Date : 16-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyNewVersion() {
		if(agIsVisible(QueryByExamplePageObjects.newVersionMsg)) {
			Reports.ExtentReportLog("", Status.PASS, "New Version creation successfull - "+agGetText(QueryByExamplePageObjects.newVersionMsg), true);
			agClick(QueryByExamplePageObjects.newVersionOkBtn);			
		}
		else {
			Reports.ExtentReportLog("", Status.FAIL, "New Version creation unsuccessfull", true);
		}
		
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to search the receipt number by using
	 *             condition and verify get the count
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 09-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchReceiptNum(String scenarioName,String rctsheet) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		selectExpOperator(scenarioName, "RuleOperator");
		agClick(QueryByExamplePageObjects.clickCondition);
		agIsVisible(QueryByExamplePageObjects.ruleConditionFieldPanel);
		agSetValue(QueryByExamplePageObjects.fieldSearch, getTestDataCellValue(scenarioName, "SearchField1"));
		agClick(QueryByExamplePageObjects.searchIcon);
		agClick(QueryByExamplePageObjects.recieptNo);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, rctsheet);
		String RctNo = FDE_General.getData(scenarioName, "ReceiptNo");
		agSetValue(QueryByExamplePageObjects.searchValueToCompare_TextBox, RctNo);
		agClick(QueryByExamplePageObjects.clickGetCount);
		String getcountResult = agGetText(QueryByExamplePageObjects.countResult);
		CommonOperations.takeScreenShot();
		agClick(QueryByExamplePageObjects.clickSearch);
		agIsVisible(QueryByExamplePageObjects.backToQbeHeader);
		agSetStepExecutionDelay("3000");
		//changeVersion("All Version");
		agSetStepExecutionDelay("5000");
		String Result = getTotalCounts();

		if (getcountResult.equals(Result)) {
			Reports.ExtentReportLog("", Status.PASS, scenarioName + " Counts Matched Successfully ", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, scenarioName + " Counts Not Matched Successfully ", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to navigate to QBE and verify all the
	 *             fields
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Padmapriya
	 * @Date : 13-O1-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void openTheSearchedCase(String scenarioName,String SheetName,String ColumnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, SheetName);
		String RctNum=getTestDataCellValue(scenarioName, ColumnName);
		if(agIsVisible(QueryByExamplePageObjects.searchedReceiptNo(RctNum))) {
			agClick(QueryByExamplePageObjects.searchedReceiptNo(RctNum));	
		 Reports.ExtentReportLog("", Status.PASS, "Receipt number found." , true);
		}
			else {
				Reports.ExtentReportLog("", Status.FAIL, "Receipt number not found.", true);			
	}
		try {
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Robot ref=new Robot();
			ref.keyPress(KeyEvent.VK_ENTER);
			ref.keyRelease(KeyEvent.VK_ENTER);
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
}
