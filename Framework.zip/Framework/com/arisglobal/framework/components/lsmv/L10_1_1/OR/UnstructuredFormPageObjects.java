package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class UnstructuredFormPageObjects {
	
	/////////////////////////////// Case Management >> New Case >> Unstructured Form /////////////////////////////
	//////////////////////////////////////////// Basic Details //////////////////////////////////////////////////
	public static String confirmBtn = "xpath#//span[@id='confirmBtn']";
	public static String companyUnit_DropDown = "xpath#//span[@id='select2-companyUnitDropDown-container']";	
	public static String senderUnit_TextBox = "xpath#//input[@id ='senderUnit']";
	public static String senderUnit_LookUp = "xpath#//input[@id ='senderUnit']/following::span[1]";	
	public static String processingUnit_DropDown = "xpath#//span[@id='select2-processingUnitDropdown-container']";
	public static String reportReceivingMedium_DropDown = "xpath#//div[@id='adverseEventNew:basicDetailsDataTable:A1-501']";
	public static String reportReceivingFormat_DropDown = "xpath#//div[@id='adverseEventNew:basicDetailsDataTable:formType-9034']";
	public static String priority_DropDown = "xpath#//div[@id='adverseEventNew:basicDetailsDataTable:A1-145']";
	public static String overrideAutoCalculationRule_CheckBox = "Override Auto Calculation Rule";
	public static String latestReceivedDate_TextBox = "xpath#//input[@id ='latestReceivedDate']";
	public static String initialReceivedDate_TextBox = "xpath#//input[@id ='initialReceivedDate']";
	public static String companyReceivedDate_TextBox = "xpath#//input[@id ='companyReceivedDate']";
	public static String reportType_DropDown = "xpath#//span[@id='select2-reportTypeDd-container']";
	public static String reportClassification_DropDown = "xpath#//div[@id='adverseEventNew:basicDetailsDataTable:A1-8140']";
	
	//////////////////////////////////////////// Source Document(s) //////////////////////////////////////////////////////////////
	
	public static String sourceDocument_UploadLink = "xpath#//div[@id='adverseEventNew:sourceUpload_input']";

	//////////////////////////////////////////// Support Document(s) ////////////////////////////////////////////////////////////

	public static String supportDocument_UploadLink = "xpath#//div[@id='adverseEventNew:supportDocUpload_input']";

	//////////////////////////////////////////// Assign To //////////////////////////////////////////////////////////////////////
	
	public static String assignTo_Radio = "xpath#//table[@id='adverseEventNew:assignto']//label[contains(text(),'%radioLabel%')]";
	public static String assignTo_DropDown = "xpath#//div[@id='adverseEventNew:userGrp']";
	
	////////////////////////////////////////////Contact ////////////////////////////////////////////////////////////////////////

	public static String contact_Div = "xpath#//label[contains(@id, 'adverseEventNew') and text() = 'Contact']";
	public static String contact_Label = "Contact";
	public static String lastName_LookUpIcon = "xpath#//a[contains(@id, 'selectCntLink:contactLookup')]/img[contains(@id, 'adverseEventNew:contactsDataTable:%rowNo%:selectCntLink:')]";
	public static String caseReporter_CheckBox = "xpath#//div[@id= 'adverseEventNew:contactsDataTable:0:isReporterCheckBox']/div/span";
	
	//////////////////////////////////////////// UNSTRUCTURED FORM /////////////////////////////////////////////////////////////
	
	public static String unstructuredFORM_Label = "xpath#//label[contains(@id, 'adverseEventNew') and text() = 'UNSTRUCTURED FORM']";
	public static String analyze_Button = "xpath#//button[@id = 'adverseEventNew:analysisvalidation']";
	
	public static String narrativeSummary_Link = "xpath#//a[@id='adverseEventNew:narrativeSummary']";
	public static String narrativeDetails_Link = "xpath#//a[@id='adverseEventNew:narrativeDetails']";
	public static String corpusUpdate_Link = "xpath#//a[@id='adverseEventNew:machineLearning']";
	
	public static String contactlookUP = "xpath#//div[@id='unstContact']//span[@class='lsmv-lookup-icon']";
	public static String Searchfilter = "xpath#//span[@title='Click to show filter criteria']";
	public static String SearchVisible = "xpath#//span[text()='Search']";
	
	public static String firstName = "xpath#//input[@fieldid='FIRST_NAME_IN_UPPER']";
	public static String LastName = "xpath#//input[@fieldid='LAST_NAME_IN_UPPER']";
	public static String searchBtn = "xpath#//span[text()='Search']";	
	public static String selectContactCheckbox = "xpath#(//div[text()='%ss%']//parent::div//parent::div/span)[1]";
	public static String SelectBtn = "xpath#//span[@id='selecctBtnId']";
	public static String saveButton = "xpath#//button[text() ='Save']";
	public static String saveConfirmationPopUp = "xpath#//span[text() ='Action  Completed Successfully']";
	public static String receiptNumber= "xpath#//div[@id ='responseMessage']/label[1]";
	public static String saveOkButton = "xpath#//div[@class='ui-dialog-buttonset']/button[text()='Ok']";
	public static String ConfirmButton = "xpath#//button[text()='Confirm']";
	public static String backToListing = "xpath#//span[text()='Back to Listing']";
	
	
	//**********************************************************************************************************
		public static String selectContact(String runTimeLabel) {
			String resultLocator;
			resultLocator = selectContactCheckbox.replace("%ss%", runTimeLabel);
			return resultLocator;
		}

}
