package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDEMoreOptionsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_EventsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_ProductsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DataBaseOperations;
import com.arisglobal.framework.lib.utils.generic.FileSystemOperations;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_Operations extends ToolManager {
	static String className = FDE_Operations.class.getSimpleName();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method will click the more options link.
	 * @InputParameters: object
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 24-jun-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void MoreOptionsLinksNavigation(String object) {

		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agSetStepExecutionDelay("1000");
		agJavaScriptExecuctorClick(object);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create a FDE case with mandatory
	 *             data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 24-jun-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createCase(String scenarioName) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CaseManagementOperations.caseManagement_MenuNavigations("fullDataEntryForm");

		FDE_General.LSMVSetGeneralBasicDetails(scenarioName);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
		if (getTestDataCellValue(scenarioName, "FDE_Source").equalsIgnoreCase("Yes")) {
			tabNavigation("Source");
			FDE_Source.setSourceDetails(scenarioName);
		}
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
		if (getTestDataCellValue(scenarioName, "FDE_Reporter").equalsIgnoreCase("Yes")) {
			tabNavigation("Reporter");
			FDE_Reporter.set_ReporterData(scenarioName);
		}
		// FDE_Reporter.set_ReporterData(scenarioName);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
		if (getTestDataCellValue(scenarioName, "FDE_Study").equalsIgnoreCase("Yes")) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
			if (FDE_General.getData(scenarioName, "Gen_CaseReport_ReportType").equalsIgnoreCase("Report from study")) {
				tabNavigation("Study");
				FDE_Study.set_StudyData(scenarioName);

				if (scenarioName.equalsIgnoreCase("BlindingUnBlinding")) {
					FDE_Study.copy_Product("BlindingUnBlinding");
				}
			}
		}
		// tabNavigation("Study");
		// FDE_Study.set_StudyData(scenarioName);

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
		if (getTestDataCellValue(scenarioName, "FDE_Patient").equalsIgnoreCase("Yes")) {
			tabNavigation("Patient");
			FDE_Patient.set_Patient(scenarioName);
		}
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
		if (getTestDataCellValue(scenarioName, "FDE_Parent").equalsIgnoreCase("Yes")) {
			tabNavigation("Parent");
			FDE_Parent.LSMVSetParentDetails(scenarioName);
		}
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
		if (getTestDataCellValue(scenarioName, "FDE_Products").equalsIgnoreCase("Yes")) {
			tabNavigation("Product(s)");
			FDE_Products.setProductData(scenarioName);
		}
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
		if (getTestDataCellValue(scenarioName, "FDE_Events").equalsIgnoreCase("Yes")) {
			tabNavigation("Event(s)");
			FDE_Events.set_Events(scenarioName);
		}
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
		if (getTestDataCellValue(scenarioName, "FDE_Narrative").equalsIgnoreCase("Yes")) {
			tabNavigation("Narrative");
			FDE_Narrative.setNarrativeData(scenarioName);
		}
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
		if (getTestDataCellValue(scenarioName, "FDE_Causality").equalsIgnoreCase("Yes")) {
			FDE_Operations.tabNavigation("Causality");
			FDE_Causality.CausalityInformation(scenarioName);
		}
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
		if (getTestDataCellValue(scenarioName, "FDE_Pregnancy").equalsIgnoreCase("Yes")) {
			tabNavigation("Pregnancy");
			FDE_Pregnancy.set_PregnancyDetails(scenarioName);
		}
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
		if (getTestDataCellValue(scenarioName, "FDE_LabData").equalsIgnoreCase("Yes")) {
			tabNavigation("Lab Data");
			FDE_LabData.set_TestsData(scenarioName);
		}
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
		if (getTestDataCellValue(scenarioName, "FDE_Literature").equalsIgnoreCase("Yes")) {
			tabNavigation("Literature");
			FDE_Literature.set_Literature(scenarioName);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in FDE data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 24-jun-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void caseData_Verification(String scenarioName) {
		tabNavigation("General");
		FDE_General.generalDetails_Verification(scenarioName);
		tabNavigation("Source");
		FDE_Source.verifySourceDetails(scenarioName);
		tabNavigation("Reporter");
		FDE_Reporter.reporterData_Verification(scenarioName);
		tabNavigation("Study");
		FDE_Study.verify_StudyData(scenarioName);
		tabNavigation("Patient");
		FDE_Patient.patientData_Verification(scenarioName);
		tabNavigation("Parent");
		FDE_Parent.parent_Verification(scenarioName);
		tabNavigation("Product(s)");
		FDE_Products.productData_Verification(scenarioName);
		tabNavigation("Event(s)");
		FDE_Events.verify_Event(scenarioName);
		tabNavigation("Narrative");
		FDE_Narrative.verifyNarrativeData(scenarioName);
		tabNavigation("Pregnancy");
		FDE_Pregnancy.verify_PregnancyDetails(scenarioName);
		tabNavigation("Lab Data");
		FDE_LabData.testsData_Verification(scenarioName);
		tabNavigation("Literature");
		FDE_Literature.literatureInformation_Verification(scenarioName);

		/*
		 * if(agIsVisible(FullDataEntryFormPageObjects.navigation_Validation)==true) {
		 * agClick(FullDataEntryFormPageObjects.navigation_Validation_YesBtn); }
		 */

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download CaseSummaryReport in FDE
	 *             form.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downloadCaseSummaryReport(String scenarioName) {
		String downloadPath = lsmvConstants.LSMV_testDataOutput;
		status = PDFOperations.isFileDownloaded(downloadPath,
				"SUMMARY_" + FDE_General.getData(scenarioName, "ReceiptNo") + ".pdf");
		if (status) {
			Reports.ExtentReportLog("Casesummary report is downloaded successfully", Status.PASS, "", true);
		} else {
			Reports.ExtentReportLog("Casesummary report is Not downloaded successfully", Status.FAIL, "", true);

		}
		agClick(FDEMoreOptionsPageObjects.cancelIcon);
	}

	/**********************************************************************************************************
	 * @Objective: The below method will search the case based on Receipt ID and
	 *             edit the case to perform copy case.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 24-jun-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void copyCase(String scenarioName) {
		FDE_CopyCase.copyCase(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to open Reports in FDE form.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void openReports(String ReportName) {
		agSetStepExecutionDelay("2000");
		agMouseHover(FDEMoreOptionsPageObjects.caseReports_Icon);

		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// agMouseHover(FDEMoreOptionsPageObjects.downLoadReports(ReportName));
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.downLoadReports(ReportName));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to save the FDE case
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void LSMVSave(String scenarioName, String sheetName) {
		agSetStepExecutionDelay("5000");
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.SaveButton);
		// FDE_Operations.resolveValidation();
		if (agIsVisible(CommonPageObjects.auditInfo_Label) == true) {
			CommonOperations.handelAuditInfo(scenarioName);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.writeRecptNo_FDESave(scenarioName, sheetName);
		agAssertContainsText(FullDataEntryFormPageObjects.receiptNumber,
				FDE_General.getData(scenarioName, "SaveMessage"));
		String receiptNumber = agGetText(FullDataEntryFormPageObjects.receiptNumber);
		status = agIsVisible(FullDataEntryFormPageObjects.receiptNumber);
		if (status) {

			if (scenarioName.contains("QBEBasedonCaseDocuments")) {
				Reports.ExtentReportLog("LSMV create new case receipt", Status.PASS,
						"<br />" + "The case is saved as " + receiptNumber, false);

			} else {
				Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
				Reports.ExtentReportLog("LSMV create new case receipt", Status.PASS,
						"<br />" + "The case is saved as " + receiptNumber, false);
			}

		} else {
			Reports.ExtentReportLog("LSMV create new case receipt", Status.FAIL, "The case is not saved", true);
		}
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
		String RecieptNumberPrefix = getTestDataCellValue("LSMV_ISP_Config", "ReceiptPrefix");

		if (receiptNumber.contains(RecieptNumberPrefix)) {
			Reports.ExtentReportLog("", Status.PASS,
					"Receipt Numbering Format - Prefix is getting Mapped in Created Reciept Number", true);

		} else {
			// Reports.ExtentReportLog("", Status.FAIL,
			// "Receipt Numbering Format - Prefix is getting Mapped in Created Reciept
			// Number", true);
		}
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);
		agSetStepExecutionDelay(String.valueOf((Constants.defaultGlobalStepExecutionDelay)));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to save the updated case
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 31-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void LSMVSaveUpdate(String scenarioName, String sheetName) {
		agSetStepExecutionDelay("5000");
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.SaveButton);
		// FDE_Operations.resolveValidation();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.agwaitTillVisible(FullDataEntryFormPageObjects.receiptNumber, 20, 10000);
		String receiptNumber = agGetText(FullDataEntryFormPageObjects.receiptNumber);

		String[] arrOfStr = receiptNumber.split("AE Case '");
		arrOfStr = arrOfStr[1].split("' Successfully Updated");
		String receiptNum = arrOfStr[0].trim();

		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "ReceiptNo", receiptNum);
		if (receiptNumber.contains("Successfully Updated")) {
			Reports.ExtentReportLog("LSMV create new case receipt", Status.PASS,
					"Case updation successfull :: Validation-" + receiptNum, true);
		} else {
			Reports.ExtentReportLog("LSMV create new case receipt", Status.FAIL,
					"Case updation unsuccessfull :: Validation-" + receiptNum, true);
		}

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
		String RecieptNumberPrefix = getTestDataCellValue("LSMV_ISP_Config", "ReceiptPrefix");

		if (receiptNumber.contains(RecieptNumberPrefix)) {
			Reports.ExtentReportLog("", Status.PASS,
					"Receipt Numbering Format - Prefix is getting Mapped in Created Reciept Number", true);

		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Receipt Numbering Format - Prefix is getting Mapped in Created Reciept Number", true);
		}
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to close validation
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Avinash K
	 * @Date : 09-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ValidationClose() {
		agSetStepExecutionDelay("5000");
		if (agIsVisible(FullDataEntryFormPageObjects.ActionOkBtn) == true) {
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.ActionOkBtn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to save the FDE case for reconsile
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar s
	 * @Date : 12-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void LSMVSaveReconsile() {
		agSetStepExecutionDelay("3000");
		// agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.SaveButton);
		agClick(FullDataEntryFormPageObjects.SaveButton);
		// agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.receiptNumber);
		// String receiptNumber = agGetText(FullDataEntryFormPageObjects.receiptNumber);
		// status = agIsVisible(FullDataEntryFormPageObjects.receiptNumber);
		// if (status) {
		// Reports.ExtentReportLog("Save Successful", Status.PASS,
		// "Save Case" + receiptNumber, true);
		// } else {
		// Reports.ExtentReportLog("Save UnSuccessful", Status.FAIL,
		// "Save UnSuccessful" + receiptNumber, true);
		// }
		agSetStepExecutionDelay("5000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		// if (agIsVisible(FullDataEntryFormPageObjects.saveOkButton) == true) {
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
		Reports.ExtentReportLog("", Status.PASS, "As Expected", true);

		Reports.ExtentReportLog("", Status.INFO, "<br />" + "The Case is saved", false);
		agClick(FullDataEntryFormPageObjects.saveOkButton);

		// }
	}

	public static void LSMVSaveTheCase() {
		agSetStepExecutionDelay("5000");
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.SaveButton);
		agClick(FullDataEntryFormPageObjects.SaveButton);
		agSetStepExecutionDelay("5000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to save the FDE case when AER No is
	 *             displayed
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 10-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void LSMV_AERNo_Save(String scenarioName, String sheetName) {
		agSetStepExecutionDelay("5000");
		agClick(FullDataEntryFormPageObjects.SaveButton);
		if (agIsVisible(CommonPageObjects.auditInfo_Label) == true) {
			CommonOperations.handelAuditInfo(scenarioName);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.writeRecptNo_FDE_AER_Save(scenarioName, sheetName);
		agAssertContainsText(FullDataEntryFormPageObjects.receiptNumber,
				FDE_General.getData(scenarioName, "SaveMessage"));
		String receiptNumber = agGetText(FullDataEntryFormPageObjects.receiptNumber);
		status = agIsVisible(FullDataEntryFormPageObjects.receiptNumber);
		if (status) {
			Reports.ExtentReportLog("LSMV create new case receipt", Status.PASS,
					"New case creation successfull :: Validation-" + receiptNumber, true);
		} else {
			Reports.ExtentReportLog("LSMV create new case receipt", Status.FAIL,
					"New case creation unsuccessfull :: Validation-" + receiptNumber, true);
		}
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
		String RecieptNumberPrefix = getTestDataCellValue("LSMV_ISP_Config", "ReceiptPrefix");

		if (receiptNumber.contains(RecieptNumberPrefix)) {
			Reports.ExtentReportLog("", Status.PASS,
					"Receipt Numbering Format - Prefix is getting Mapped in Created Reciept Number", true);

		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Receipt Numbering Format - Prefix is getting Mapped in Created Reciept Number", true);
		}
		agClick(FullDataEntryFormPageObjects.saveOkButton);

	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify lookup screen in FDE from
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	/*
	 * 
	 * public static void verifyLookups(String menu) { WebDriver driver =
	 * Constants.driver; switch (menu) { case
	 * "generalTab_SenderOrganizationasCoded":
	 * agClick(GeneralPageObjects.senderOrganizationasCodedLookup);
	 * agClick(SenderOrganizationLookupPageObjects.searchButton); //
	 * agGetElementList(locator) java.util.List<WebElement> senderdata = driver
	 * .findElements(By.xpath(
	 * "//p-table[@datakey='partnerId']//tbody[@class='ui-table-tbody']/tr"));
	 * System.out.println("Size :" + senderdata.size()); if (senderdata.size() > 0)
	 * { Reports.
	 * ExtentReportLog("Data in Sender Organization as Coded lookup is present",
	 * Status.PASS, "", true);
	 * agClick(SenderOrganizationLookupPageObjects.cancelButton); } else { Reports.
	 * ExtentReportLog("Data in Sender Organization as Coded lookup is not present",
	 * Status.FAIL, "", true);
	 * agClick(SenderOrganizationLookupPageObjects.cancelButton); } break; case
	 * "generalTab_LastName": agClick(GeneralPageObjects.lastNameLookup);
	 * agClick(FDEContactLookupPageObjects.SearchButton); java.util.List<WebElement>
	 * contact = driver.findElements(By.xpath(
	 * "//p-table[@class='agcommonTblStyle agContactLookupTbl']//tbody[@class='ui-table-tbody']/tr"
	 * )); System.out.println("Size :" + contact.size()); if (contact.size() > 0) {
	 * Reports.ExtentReportLog("Data in Last Name lookup is present", Status.PASS,
	 * "", true); agClick(SenderOrganizationLookupPageObjects.cancelButton); } else
	 * { Reports.ExtentReportLog("Data in Last Name lookup is not present",
	 * Status.FAIL, "", true);
	 * agClick(SenderOrganizationLookupPageObjects.cancelButton); } case
	 * "sourceTab_sender": agClick(GeneralPageObjects.navigateSourceTab);
	 * agClick(sourceTabPageObjects.senderLookup);
	 * agClick(sourceTabPageObjects.searchButton); java.util.List<WebElement> Sender
	 * = driver .findElements(By.xpath(
	 * "//p-table[@datakey='partnerId']//tbody[@class='ui-table-tbody']/tr"));
	 * System.out.println("Size :" + Sender.size()); if (Sender.size() > 0) {
	 * Reports.ExtentReportLog("Data in sender lookup is present", Status.PASS, "",
	 * true); agClick(sourceTabPageObjects.cancelButton); } else {
	 * Reports.ExtentReportLog("Data in sender lookup is not present", Status.FAIL,
	 * "", true); agClick(sourceTabPageObjects.cancelButton); }
	 * 
	 * }
	 * 
	 * }
	 */

	/**********************************************************************************************************
	 * @Objective: The below method is created to delink the case
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 30-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deLinkCase(String scenarioName) {
		FDEFormCaseLinkOperations.deLinkCase(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify linked reason data in link
	 *             AE case PopUp
	 * @InputParameters: scenarioName, verify
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 30-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyLinkedData(String scenarioName, String verify)

	{
		FDEFormCaseLinkOperations.verifyLinkedData(scenarioName, verify);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to link case
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 29-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void caseLink(String scenarioName) {
		FDEFormCaseLinkOperations.caseLink(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to tab navigations in FDE from
	 * @InputParameters: TabName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :14-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void tabNavigation(String TabName) {

		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.tabNavigation(TabName));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to FDE navigations in FDE from
	 * @InputParameters: TabName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :14-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void FDE_Navigations(String TabName) {
		agSetStepExecutionDelay("5000");
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.FDE_tabNavigation(TabName));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: This method is created for downloading a pdf from the PDF
	 *             download screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Avinash K
	 * @Date : 21.5.2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downloadPDF() {

		int i = 0, sz = agGetWindowCount();
		agSetStepExecutionDelay("5000");
		while (!(sz == 2) && i < 75) {
			sz = agGetWindowCount();
			i++;
			System.out.println("Waiting" + i);
		}
		agGetCurrentWindow();
		agSetStepExecutionDelay("3000");
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.downloadIcon);
		// CommonOperations.captureScreenShot(true);
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.downloadIcon);
		// agClick(FDEMoreOptionsPageObjects.downloadIcon);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) // Hard wait is used reason file to get download taking time
		{
			e.printStackTrace();

		}
		agCloseCurrentWindow();
		agGetWindowControlByInstance(1);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download CIMOS report
	 * @InputParameters: ReportName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :29-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downLoadCIMOSReport(String ReportName) {
		agAssertExists(FullDataEntryFormPageObjects.reporterHeader(ReportName));
		agSwitchFrame(FDEMoreOptionsPageObjects.ciomosReport_iframeID);
		CommonOperations.takeScreenShot();
		agClick(FDEMoreOptionsPageObjects.downloadIcon);
		agSwitchToDefaultFrame();
		agClick(FDEMoreOptionsPageObjects.ciomsReport_cancelIcon);
		try {
			Thread.sleep(8000);
		} catch (InterruptedException e) // Hard wait is used reason file to get download taking time
		{
			e.printStackTrace();

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to save and exit from the case
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :10-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void saveAndExit() {
		agClick(FullDataEntryFormPageObjects.saveAndExit);
		// agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.completeActivtyLoading);
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.receiptNumber);
		String validation = agGetText(FullDataEntryFormPageObjects.receiptNumber);
		Reports.ExtentReportLog("", Status.INFO, "validation :" + validation, true);

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
		String RecieptNumberPrefix = getTestDataCellValue("LSMV_ISP_Config", "ReceiptPrefix");

		if (validation.contains(RecieptNumberPrefix)) {
			Reports.ExtentReportLog("", Status.PASS,
					"Receipt Numbering Format - Prefix is getting Mapped in Created Reciept Number", true);

		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Receipt Numbering Format - Prefix is getting Mapped in Created Reciept Number", true);
		}

		if (agIsVisible(FullDataEntryFormPageObjects.saveOkButton)) {
			agClick(FullDataEntryFormPageObjects.saveOkButton);
		}
		status = agIsVisible(CaseListingPageObjects.keywordSearchTextbox);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Save and exit is successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Save and exit is Unsuccessfull", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Click on save and exit
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date :05-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void saveExit() {
		agClick(FullDataEntryFormPageObjects.saveAndExit);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.completeActivtyLoading);
		String validation = agGetText(FullDataEntryFormPageObjects.receiptNumber);
		Reports.ExtentReportLog("", Status.INFO, "validation :" + validation, true);
	}

	/**********************************************************************************************************
	 * @Objective: Click on OK button validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date :05-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void okOnValidation() {
		if (agIsVisible(FullDataEntryFormPageObjects.saveOkButton)) {
			agSetStepExecutionDelay("5000");
			agClick(FullDataEntryFormPageObjects.saveOkButton);
			Reports.ExtentReportLog("", Status.PASS, "Click OK on validation successfull", true);
		}
		/*
		 * agSetStepExecutionDelay("5000"); status =
		 * agIsVisible(CaseListingPageObjects.keywordSearchTextbox); if (status) {
		 * Reports.ExtentReportLog("", Status.PASS, "Save and exit is successfull",
		 * true); }
		 */ else {
			Reports.ExtentReportLog("", Status.FAIL, "Click OK on validation Unsuccessfull", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to approve the case
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :10-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void approveCase() {
		boolean record_found = false;
		for (int i = 0; i < 4; i++) {
			agMouseHover(FullDataEntryFormPageObjects.actions_Btn);
			agClick(FullDataEntryFormPageObjects.completeActivity_link);
			agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.completeActivtyLoading);
			String validation = agGetText(FullDataEntryFormPageObjects.receiptNumber);
			Reports.ExtentReportLog("", Status.INFO, "Validation :" + validation, true);
			agClick(FullDataEntryFormPageObjects.saveOkButton);
			if (agIsExists(FullDataEntryFormPageObjects.approvedLabel) == true) {
				record_found = true;
				Reports.ExtentReportLog("", Status.PASS, "Case Approved", true);
				break;
			}

		}

		if (!record_found) {
			Reports.ExtentReportLog("", Status.FAIL, "Case not approved", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set data in Report generation with
	 *             public and blinded/unblinded Access
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :29-Aug-2019
	 * @UpdatedByAndWhen:Pooja S on 03-Sep-2020
	 **********************************************************************************************************/
	public static void setReportGenerationAccess(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (agIsVisible(FullDataEntryFormPageObjects.reportGenerationWindow) == true) {
			if (agIsVisible(FullDataEntryFormPageObjects.generationAccess) == true) {
				Reports.ExtentReportLog("", Status.INFO, "Masked and UnMasked selection", false);
				if (getTestDataCellValue(scenarioName, "Masked").equalsIgnoreCase("True")) {
					agJavaScriptExecuctorClick(FullDataEntryFormPageObjects
							.reportGenerationAccess(FullDataEntryFormPageObjects.maskedLabel));
				} else if (getTestDataCellValue(scenarioName, "UnMasked").equalsIgnoreCase("True")) {
					agJavaScriptExecuctorClick(FullDataEntryFormPageObjects
							.reportGenerationAccess(FullDataEntryFormPageObjects.unMaskedLabel));
				}
			}
			if (getTestDataCellValue(scenarioName, "BlindedReport").equalsIgnoreCase("True")
					&& getTestDataCellValue(scenarioName, "BlindedReport").length() > 0) {
				Reports.ExtentReportLog("", Status.INFO, "Blinded and UnBlinded Report selection", false);
				agJavaScriptExecuctorClick(
						FullDataEntryFormPageObjects.clickRadioButton(FullDataEntryFormPageObjects.blinded_radioBtn));
				agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.reportGenerationWindow);
			} else if (getTestDataCellValue(scenarioName, "UnblindedReport").equalsIgnoreCase("True")
					&& getTestDataCellValue(scenarioName, "UnblindedReport").length() > 0) {
				agJavaScriptExecuctorClick(
						FullDataEntryFormPageObjects.clickRadioButton(FullDataEntryFormPageObjects.unblinded_radioBtn));
				agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.reportGenerationWindow);
			}
		}
		// CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set data in Report generation with
	 *             public and blinded/unblinded Access
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date :29-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createCaseWithGeneralDetails(String scenarioName) {
		CaseManagementOperations.caseManagement_MenuNavigations("fullDataEntryForm");
		FDE_General.LSMVSetGeneralBasicDetails(scenarioName);

	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify delete label in FDE form.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 06-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCaseDelete() {
		agClick(CaseListingPageObjects.receiptNumberlink);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
		status = agIsVisible(FullDataEntryFormPageObjects.deleted_Lable);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Deleted label is displayed", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Deleted label is not displayed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Archive Status Activity Log
	 *             in outofWorkFlow listing.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 23-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyArchived() {
		agClick(CaseListingPageObjects.receiptNumberlink);
		agSetStepExecutionDelay("6000");
		status = agIsVisible(FullDataEntryFormPageObjects.archived_Lable);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Archived label is displayed", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Archived label is not displayed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify case is active.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 06-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCaseIsActive() {
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
		status = agIsVisible(FullDataEntryFormPageObjects.active_Lable);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Active label is displayed", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Active label is not displayed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download CIOMS Report
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 20-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void openCIOMSReport(String ReportName) {
		agMouseHover(FDEMoreOptionsPageObjects.caseReports_Icon);
		agSetStepExecutionDelay("3000");
		agMouseHover(FDEMoreOptionsPageObjects.ciomsReportList);
		agClick(FDEMoreOptionsPageObjects.ciomsReportList);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetStepExecutionDelay("5000");
		agIsVisible(FullDataEntryFormPageObjects.reporterHeader(ReportName));
		// agMouseHover(FDEMoreOptionsPageObjects.downLoadReports(ReportName));
		// agClick(FDEMoreOptionsPageObjects.downLoadReports(ReportName));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to capture Validations/Warnings
	 *             ScreenShot
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 05-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void resolveValidation() {
		agSetStepExecutionDelay("2000");
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.commonLoader);
		status = agIsVisible(FullDataEntryFormPageObjects.validationsWarning);
		if (status) {

			CommonOperations.takeScreenShot();
			Reports.ExtentReportLog("", Status.FAIL, "Case has Validations/Warnings", true);

		} else {
			Reports.ExtentReportLog("", Status.PASS, "Case has no Validations/Warnings", true);
			CommonOperations.takeScreenShot();

		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add ReceiptNo and Workflow status
	 *             to lsmv_wpa_controller table.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void LSMVAddToWPAController(String scenarioName, String sheetName) {

		CommonOperations.agwaitTillVisible(FullDataEntryFormPageObjects.caseReceiptNo, 5, 1000);
		CommonOperations.writeReceiptNo(scenarioName, sheetName);
		CommonOperations.writeWorkFlowStatus(scenarioName, sheetName);
	}

	/**********************************************************************************************************
	 * @Objective: To Clcik on Minimize Validations/Warnings
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 26-May-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clcikMinimizeValidation() {
		agSetStepExecutionDelay("2000");
		agClick(FullDataEntryFormPageObjects.clickMinimizeVal);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: This method is created for downloading a pdf from the PDF
	 *             download screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Avinash K
	 * @Date : 30.6.2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void downloadReports() {
		try {
			Thread.sleep(8000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		agGetCurrentWindow();
		agSwitchFrameByIndex(0);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		agClick(FDEMoreOptionsPageObjects.ReportdownloadIcon);

		try {
			Thread.sleep(8000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		agSwitchToDefaultFrame();
		agCloseCurrentWindow();
		// agGetCurrentWindow();
		agGetWindowControlByInstance(1);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to save the FDE case
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 07-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void LSMVSaveToDB(String scenarioName, String sheetName) {
		agSetStepExecutionDelay("5000");
		agClick(FullDataEntryFormPageObjects.SaveButton);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.handelAuditInfo(scenarioName);
		Connection dbCon = null;
		int rowCount = 0;
		dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
				Constants.DB_Password);

		String rctNum = CommonOperations.trimReceiptNo(scenarioName, sheetName);

		DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set Receipt_Number= '" + rctNum
				+ "' where Scenario='" + scenarioName + "'");

		DataBaseOperations.performWrite(dbCon,
				"update lsmv_wpa_controller set Workflow_Status='Intake and Assessment' where Scenario='" + scenarioName
						+ "'");

		DataBaseOperations.performWrite(dbCon,
				"update fde_general set ReceiptNo= '" + rctNum + "' where Scenario='" + scenarioName + "'");

		DataBaseOperations.performWrite(dbCon, "update dataassessmentoperations set ReceiptNo= '" + rctNum
				+ "' where Scenario='" + scenarioName + "'");

		status = agIsVisible(FullDataEntryFormPageObjects.receiptNumber);

		if (status) {
			Reports.ExtentReportLog("LSMV create new case receipt", Status.PASS,
					"New case creation successfull :: Validation-" + rctNum, true);
		} else {
			Reports.ExtentReportLog("LSMV create new case receipt", Status.FAIL,
					"New case creation unsuccessfull :: Validation-" + rctNum, true);
		}
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Cases via Full Data Entry form
	 * @InputParameters: scenarioName, creationType
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 03-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void E2EFDECaseCreation(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "FDE Case Creation for scenario " + scenarioName + " started",
					false);
			FDE_Operations.createCase(scenarioName);
			FDE_Operations.LSMVSave(scenarioName, "FDE_General");
			FDE_Operations.LSMVAddToWPAController(scenarioName, "lsmv_wpa_controller");
			Reports.ExtentReportLog("", Status.INFO, "FDE Case Creation for scenario " + scenarioName + " ended",
					false);
		} catch (Exception ex) {
			Reports.ExtentReportLog("", Status.FAIL, "FDE case creation for scenario " + scenarioName + " failed",
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: To set masked/unmasked Report Generation access when clicked on
	 *             reports icon in case edited screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setMaskedUnMaskedReportGeneratedAccess(String scenarioName) {
		agSetStepExecutionDelay("2000");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Masked").equalsIgnoreCase("True")
				&& agIsVisible(FullDataEntryFormPageObjects.generationAccess) == true) {
			agJavaScriptExecuctorClick(
					FullDataEntryFormPageObjects.reportGenerationAccess(FullDataEntryFormPageObjects.maskedLabel));
		} else if (getTestDataCellValue(scenarioName, "UnMasked").equalsIgnoreCase("True")
				&& agIsVisible(FullDataEntryFormPageObjects.generationAccess) == true) {
			agJavaScriptExecuctorClick(
					FullDataEntryFormPageObjects.reportGenerationAccess(FullDataEntryFormPageObjects.unMaskedLabel));
		}
		if (agIsVisible(FullDataEntryFormPageObjects.clickGenerateReport) == true)
			agClick(FullDataEntryFormPageObjects.clickGenerateReport);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: This method is created for downloading a pdf from the PDF
	 *             download screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 11-10-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downloadPDFinListing() {

		int i = 0, sz = agGetWindowCount();
		agSetStepExecutionDelay("5000");
		while (!(sz == 2) && i < 75) {
			sz = agGetWindowCount();
			i++;
			System.out.println("Waiting" + i);
		}
		agGetCurrentWindow();
		// agClick(FDEMoreOptionsPageObjects.downloadIcon);
		try {
			Thread.sleep(15000);
		} catch (InterruptedException e) // Hard wait is used reason file to get download taking time
		{
			e.printStackTrace();

		}
		agCloseCurrentWindow();
		agGetWindowControlByInstance(1);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Out of workflow label.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth naidu
	 * @Date : 28-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCaseOutOfWorkflow(String Worfklow) {
		try {
			agClick(CaseListingPageObjects.receiptNumberlink);
			agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
			String caseWorkflow = agGetText(FullDataEntryFormPageObjects.archived_Lable);
			if (Worfklow.equalsIgnoreCase(caseWorkflow)) {
				Reports.ExtentReportLog("", Status.PASS, "Case is moved successfully to Out Of Workflow", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Case is not moved successfully to Out Of Workflow", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Verification of Out of Workflow Failed", true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Change of Product and Event
	 *             Type
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void EventAndProductTypeChange(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Product and Event Change Starts", false);
			ProductTypeChange(scenarioName);
			ProductRanking(scenarioName);
			EventTypeChange(scenarioName);
			EventRanking(scenarioName);
			Reports.ExtentReportLog("", Status.INFO, "Product and Event Change Ends", false);
		} catch (Exception ex) {
			Reports.ExtentReportLog("", Status.FAIL, "Product and Event Change Failed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Change of Product and Event
	 *             Type
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ProductTypeChange(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Product Type Change Starts", false);
			CaseListingOperations.searchCaseAndEdit(scenarioName, "lsmv_wpa_controller", "Receipt_Number");
			tabNavigation("Product(s)");
			String rctNum = agGetText(FullDataEntryFormPageObjects.caseReceiptNo);
			int count = ProductOrEventCount();
			for (int index = 1; index <= count; index++) {
				agClick(FullDataEntryFormPageObjects.EventOrProductCount.replace("%count", index + "."));
				String productName = agGetAttribute("value",
						FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.prductNameAsReportedTxtbox));
				System.out.println(productName);
				productTypeChange("Biosimilar", "Drug", rctNum, productName);
				CaseListingOperations.searchCaseAndEdit(scenarioName, "lsmv_wpa_controller", "Receipt_Number");
				tabNavigation("Product(s)");
				agClick(FullDataEntryFormPageObjects.EventOrProductCount.replace("%count", index + "."));
				productTypeChange("COMPOUNDED", "Cosmetics", rctNum, productName);
				CaseListingOperations.searchCaseAndEdit(scenarioName, "lsmv_wpa_controller", "Receipt_Number");
				tabNavigation("Product(s)");
				agClick(FullDataEntryFormPageObjects.EventOrProductCount.replace("%count", index + "."));
				productTypeChange("Generic", "Combination", rctNum, productName);
				CaseListingOperations.searchCaseAndEdit(scenarioName, "lsmv_wpa_controller", "Receipt_Number");
				tabNavigation("Product(s)");
				agClick(FullDataEntryFormPageObjects.EventOrProductCount.replace("%count", index + "."));
				productTypeChange("OTC", "Vaccine", rctNum, productName);
				CaseListingOperations.searchCaseAndEdit(scenarioName, "lsmv_wpa_controller", "Receipt_Number");
				tabNavigation("Product(s)");
				agClick(FullDataEntryFormPageObjects.EventOrProductCount.replace("%count", index + "."));
				resetProductType();
			}
			Reports.ExtentReportLog("", Status.INFO, "Product Type Change Ends", false);
		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, "Product Type Change Failed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Change of Product and Event
	 *             Type
	 * @InputParameters: productType , productFlag , reportType, recieptNo
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void productTypeChange(String productType, String productFlag, String recieptNo, String productName) {
		agClick(FullDataEntryFormPageObjects.ProductTypeCheckBox(productType));
		Reports.ExtentReportLog("", Status.INFO, "Product Type Selected as " + productType, true);
		agClick(FDE_ProductsPageObjects.Click_ProductFlag_DropDown);
		agClick(FDE_ProductsPageObjects.clickDropDownValue(productFlag));
		Reports.ExtentReportLog("", Status.INFO, "Product Flag Selected as " + productFlag, true);
		agClick(FullDataEntryFormPageObjects.SaveButton);
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.SaveOk);
		if (agIsVisible(FullDataEntryFormPageObjects.SaveOk)) {
			agClick(FullDataEntryFormPageObjects.SaveOk);
			agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.SaveOk);
		}
		FDE_Operations.openReports("Case Summary");
		System.out.println("Downloaded");
		boolean status = agIsVisible(CommonPageObjects.blindedUnblindedReportPopUP);
		if (status) {
			agJavaScriptExecuctorClick(CommonPageObjects.checkMaskedReport);

			status = agIsVisible(CommonPageObjects.checkBlindedUnblindedReport);
			if (status) {
				agJavaScriptExecuctorClick(CommonPageObjects.checkBlindedUnblindedReport);
			}
			agClick(CommonPageObjects.clickGenerateReport);
		}
		CommonOperations.downloadPDF("Case Summary");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String rootPath = lsmvConstants.LSMV_testDataOutput + "\\" + recieptNo;
		lsmvConstants.path = rootPath;
		FileSystemOperations.createFolder(rootPath);
		String currentFileName = "SUMMARY_" + recieptNo + ".pdf";
		String newFileName = productName + "_" + productType + "_" + productFlag + "_" + recieptNo + ".pdf";
		FileSystemOperations.renameFile(lsmvConstants.LSMV_testDataOutput, currentFileName, newFileName);
		FileSystemOperations.moveFile(newFileName, lsmvConstants.LSMV_testDataOutput, rootPath);
		PDFOperations.pdfverificationForVisible(rootPath + "\\" + newFileName, productType);
		PDFOperations.pdfverificationForVisible(rootPath + "\\" + newFileName, productFlag);
		PDFOperations.pdfverificationForVisible(rootPath + "\\" + newFileName, productName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to reset the Product types choosen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void resetProductType() {
		agClick(FullDataEntryFormPageObjects.ProductTypeCheckBox("Biosimilar"));
		agClick(FullDataEntryFormPageObjects.ProductTypeCheckBox("COMPOUNDED"));
		agClick(FullDataEntryFormPageObjects.ProductTypeCheckBox("Generic"));
		agClick(FullDataEntryFormPageObjects.ProductTypeCheckBox("OTC"));
		Reports.ExtentReportLog("", Status.INFO, "Product Type Selection Reverted", true);
		agClick(FullDataEntryFormPageObjects.SaveButton);
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.SaveOk);
		if (agIsVisible(FullDataEntryFormPageObjects.SaveOk)) {
			agClick(FullDataEntryFormPageObjects.SaveOk);
			agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.SaveOk);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to count the number of products or
	 *             events
	 * @InputParameters:
	 * @OutputParameters: Number of events or products
	 * @author:Karthikeyan Natarajan
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static int ProductOrEventCount() {
		int count = 1;
		int value = 0;

		while (agIsVisible(FullDataEntryFormPageObjects.EventOrProductCount.replace("%count", count + "."))) {
			count++;
			value++;
		}
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Change of Product and Event
	 *             Type
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void EventTypeChange(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Product Type Change Starts", false);
			CaseListingOperations.searchCaseAndEdit(scenarioName, "lsmv_wpa_controller", "Receipt_Number");
			tabNavigation("Event(s)");
			String rctNum = agGetText(FullDataEntryFormPageObjects.caseReceiptNo);
			int count = ProductOrEventCount();
			for (int index = 1; index <= count; index++) {
				agClick(FullDataEntryFormPageObjects.EventOrProductCount.replace("%count", index + "."));
				String eventName = agGetAttribute("value", FDE_EventsPageObjects.reportedTerm_Textfield);
				System.out.println(eventName);
				eventTypeChange("Incident", eventName, rctNum);
				eventTypeChange("Adverse Event/Reaction", eventName, rctNum);
				eventTypeChange("Both", eventName, rctNum);
			}
			Reports.ExtentReportLog("", Status.INFO, "Product Type Change Ends", false);
		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, "Product Type Change Failed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Change of Product and Event
	 *             Type
	 * @InputParameters: productType , productFlag , reportType, recieptNo
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void eventTypeChange(String eventType, String eventName, String recieptNo) {
		String type = eventType;
		if (eventType.contains("Adverse Event"))
			type = "AE";
		agClick(FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.eventType_DropDown));
		agClick(FDE_EventsPageObjects.setdropDownValue(eventType));

		Reports.ExtentReportLog("", Status.INFO, "Event Type Selected as " + eventType, true);
		agClick(FullDataEntryFormPageObjects.SaveButton);
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.SaveOk);
		if (agIsVisible(FullDataEntryFormPageObjects.SaveOk)) {
			agClick(FullDataEntryFormPageObjects.SaveOk);
			agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.SaveOk);
		}
		FDE_Operations.openReports("Case Summary");
		System.out.println("Downloaded");
		boolean status = agIsVisible(CommonPageObjects.blindedUnblindedReportPopUP);
		if (status) {
			agJavaScriptExecuctorClick(CommonPageObjects.checkMaskedReport);

			status = agIsVisible(CommonPageObjects.checkBlindedUnblindedReport);
			if (status) {
				agJavaScriptExecuctorClick(CommonPageObjects.checkBlindedUnblindedReport);
			}
			agClick(CommonPageObjects.clickGenerateReport);
		}
		CommonOperations.downloadPDF("Case Summary");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String rootPath = lsmvConstants.LSMV_testDataOutput + "\\" + recieptNo;
		lsmvConstants.path = rootPath;
		FileSystemOperations.createFolder(rootPath);
		String currentFileName = "SUMMARY_" + recieptNo + ".pdf";
		String newFileName = eventName + "_" + type + "_" + recieptNo + ".pdf";
		FileSystemOperations.renameFile(lsmvConstants.LSMV_testDataOutput, currentFileName, newFileName);
		FileSystemOperations.moveFile(newFileName, lsmvConstants.LSMV_testDataOutput, rootPath);
		PDFOperations.pdfverificationForVisible(rootPath + "\\" + newFileName, eventName);
		PDFOperations.pdfverificationForVisible(rootPath + "\\" + newFileName, eventType);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Product Ranking
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ProductRanking(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Event Product Starts", false);
			CaseListingOperations.searchCaseAndEdit(scenarioName, "lsmv_wpa_controller", "Receipt_Number");
			tabNavigation("Product(s)");
			int count = ProductOrEventCount();
			HashMap<Integer, String> suspect = new HashMap<Integer, String>();
			HashMap<Integer, String> interacting = new HashMap<Integer, String>();
			ArrayList<String> rank = new ArrayList<String>();
			int rankSus = 1, rankInter = 1;
			System.out.println(count);
			for (int index = 1; index <= count; index++) {
				agClick(FullDataEntryFormPageObjects.EventOrProductCount.replace("%count", index + "."));
				String productChar = agGetText(FullDataEntryFormPageObjects.productCharText);
				String productName = agGetAttribute("value",
						FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.prductNameAsReportedTxtbox));
				if (productChar.contains("Suspect")) {
					suspect.put(rankSus, productName);
					rankSus++;
				} else if (productChar.contains("Interacting")) {
					interacting.put(rankInter, productName);
					rankInter++;
				}
			}
			rank.addAll(suspect.values());
			rank.addAll(interacting.values());
			System.out.println(rank);
			agClick(FullDataEntryFormPageObjects.RankButton);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.DontRankCheckBox);
			for (int index = 1; index <= rank.size(); index++) {
				agAssertContainsText(FullDataEntryFormPageObjects.RankProductName.replace("%s", index + ""),
						rank.get(index - 1));
			}
			agClick(FullDataEntryFormPageObjects.RankOKBtn);

			Reports.ExtentReportLog("", Status.INFO, "Product Ranking Ends", false);
		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, "Product Ranking Failed", false);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Event Ranking
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void EventRanking(String scenarioName) {
		try {

			Reports.ExtentReportLog("", Status.INFO, "Event Ranking Starts", false);
			CaseListingOperations.searchCaseAndEdit(scenarioName, "lsmv_wpa_controller", "Receipt_Number");
			tabNavigation("Event(s)");
			int count = ProductOrEventCount();
			HashMap<Integer, String> serious = new HashMap<Integer, String>();
			HashMap<Integer, String> nonSerious = new HashMap<Integer, String>();
			ArrayList<String> rank = new ArrayList<String>();
			int rankSerious = 1, rankNonSerious = 1;
			for (int index = 1; index <= count; index++) {
				agClick(FullDataEntryFormPageObjects.EventOrProductCount.replace("%count", index + "."));
				boolean value = EventSeriousnessSelected();
				String eventName = agGetAttribute("value", FDE_EventsPageObjects.reportedTerm_Textfield);
				if (value) {
					serious.put(rankSerious, eventName);
					rankSerious++;
				} else {
					nonSerious.put(rankNonSerious, eventName);
					rankNonSerious++;
				}
			}
			rank.addAll(serious.values());
			rank.addAll(nonSerious.values());
			System.out.println(rank);
			agClick(FullDataEntryFormPageObjects.RankButton);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.DontRankCheckBox);
			// Auto Rank
			for (int index = 1; index <= rank.size(); index++) {
				agAssertContainsText(FullDataEntryFormPageObjects.RankEventName.replace("%s", index + ""),
						rank.get(index - 1));
			}

			// Manual Rank
			agClick(FullDataEntryFormPageObjects.DontRankCheckBox);
			System.out.println("");
			agJavaScriptExecuctorScrollToElement(FullDataEntryFormPageObjects.RankEventDrag.replace("%s", "2"));
			agDragAndDrop(FullDataEntryFormPageObjects.RankEventDrag.replace("%s", "2"),
					FullDataEntryFormPageObjects.RankEventDrag.replace("%s", "1"));
			agClick(FullDataEntryFormPageObjects.RankOKBtn);
			Reports.ExtentReportLog("", Status.INFO, "Event Ranking Ends", false);

		} catch (

		Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, "Event Ranking Failed", false);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to check whethere Event Seriouseness
	 *             is YES
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean EventSeriousnessSelected() {
		boolean value = false;
		String selected = agGetAttribute("class", FullDataEntryFormPageObjects.SeriousnessYes);
		if (selected.contains("ui-state-active"))
			value = true;
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: To read a validation displayed on Save/Complete of a case
	 * @InputParameters: ScenarioName, Action (save or complete) and
	 *                   validationExpected in Boolean
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 26-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean readValidation(String scenarioName, String action, boolean isValExpected) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "WFConfiguration_Validations");
		boolean validationDisplayed = false;
		String validation = null;

		try {
			if (action.equalsIgnoreCase("save") && isValExpected) {
				validation = agGetText(FullDataEntryFormPageObjects.notiftnV0067_locator(
						getTestDataCellValue(scenarioName, "OnSaveRadioBtn"),
						getTestDataCellValue(scenarioName, "RuleName")));
				Reports.ExtentReportLog("", Status.INFO, "Expected Validation displayed.", true);
				System.out.println("Validation Statement: " + validation);
			} else if (action.equalsIgnoreCase("complete") && isValExpected) {
				if (agIsExists(FullDataEntryFormPageObjects.notiftnV0067_locator(
						getTestDataCellValue(scenarioName, "OnCompleteRadioBtn"),
						getTestDataCellValue(scenarioName, "RuleName")))) {
					validation = agGetText(FullDataEntryFormPageObjects.notiftnV0067_locator(
							getTestDataCellValue(scenarioName, "OnCompleteRadioBtn"),
							getTestDataCellValue(scenarioName, "RuleName")));
				} else {
					validation = agGetText(FullDataEntryFormPageObjects
							.validationSideNotification(getTestDataCellValue(scenarioName, "RuleName")));
				}
				Reports.ExtentReportLog("", Status.INFO, "Expected Validation displayed.", true);
				System.out.println("Validation Statement: " + validation);
			}

			// added by Pooja
			else if (action.equalsIgnoreCase("save") && isValExpected == false) {
				if (agIsExists(FullDataEntryFormPageObjects.notiftnV0067_locator(
						getTestDataCellValue(scenarioName, "OnCompleteRadioBtn"),
						getTestDataCellValue(scenarioName, "RuleName")))) {
					validation = agGetText(FullDataEntryFormPageObjects.notiftnV0067_locator(
							getTestDataCellValue(scenarioName, "OnCompleteRadioBtn"),
							getTestDataCellValue(scenarioName, "RuleName")));
					Reports.ExtentReportLog("", Status.FAIL, "UnExpected Validation displayed.", true);
					System.out.println("Validation Statement: " + validation);
				}
			} else if (action.equalsIgnoreCase("complete") && isValExpected == false) {
				if (agIsExists(FullDataEntryFormPageObjects.notiftnV0067_locator(
						getTestDataCellValue(scenarioName, "OnCompleteRadioBtn"),
						getTestDataCellValue(scenarioName, "RuleName")))) {
					validation = agGetText(FullDataEntryFormPageObjects.notiftnV0067_locator(
							getTestDataCellValue(scenarioName, "OnCompleteRadioBtn"),
							getTestDataCellValue(scenarioName, "RuleName")));
					Reports.ExtentReportLog("", Status.FAIL, "Expected Validation displayed.", true);
					System.out.println("Validation Statement: " + validation);
				}

			}
		} catch (

		Exception e) {
			System.out.println("Failed to read Validation Statement");
			e.printStackTrace();
		}

		if (validation != null && isValExpected) {
			validationDisplayed = true;
			Reports.ExtentReportLog("", Status.PASS, "As Expected.", true);
			Reports.ExtentReportLog("", Status.INFO, "Expected Validation displayed. " + validation, true);
		} else if (validation == null && isValExpected) {
			Reports.ExtentReportLog("", Status.FAIL, "Not As Expected." + "<br />" + validation, false);
			Reports.ExtentReportLog("", Status.FAIL, "Expected Validation NOT displayed.", true);
		} /*
			 * else if (validation == null && isValExpected == false) {
			 * Reports.ExtentReportLog("", Status.PASS, "As Expected." + "<br />" +
			 * validation, true); Reports.ExtentReportLog("", Status.INFO,
			 * "No Validation displayed as expected.", true); }
			 */

		// added by Pooja
		else if (validation != null && isValExpected == false) {
			Reports.ExtentReportLog("", Status.FAIL, "Not As Expected." + "<br />" + validation, false);
			Reports.ExtentReportLog("", Status.FAIL, "Validation displayed.", true);
		} else if (validation == null && isValExpected == false) {
			Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
			Reports.ExtentReportLog("", Status.INFO, "No Validation displayed as expected.", true);
		}

		return validationDisplayed;
	}

	/**********************************************************************************************************
	 * @Objective: The method is to only save the case and not to click on
	 *             Validations OK button
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 26-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void saveCase() {
		agSetStepExecutionDelay("5000");
		agClick(FullDataEntryFormPageObjects.SaveButton);
		agSetStepExecutionDelay("3000");

		// agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
		// agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);

		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to save the FDE case
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void caseSave(String scenarioName, String sheetName) {
		agSetStepExecutionDelay("5000");
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.SaveButton);
		// FDE_Operations.resolveValidation();
		if (agIsVisible(CommonPageObjects.auditInfo_Label) == true) {
			CommonOperations.handelAuditInfo(scenarioName);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.writeRecptNo_FDESave(scenarioName, sheetName);
		agAssertContainsText(FullDataEntryFormPageObjects.receiptNumber,
				FDE_General.getData(scenarioName, "SaveMessage"));
		String receiptNumber = agGetText(FullDataEntryFormPageObjects.receiptNumber);
		status = agIsVisible(FullDataEntryFormPageObjects.receiptNumber);
		if (status) {
			Reports.ExtentReportLog("LSMV create new case receipt", Status.PASS,
					"New case creation successfull :: Validation-" + receiptNumber, true);
		} else {
			Reports.ExtentReportLog("LSMV create new case receipt", Status.FAIL,
					"New case creation unsuccessfull :: Validation-" + receiptNumber, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The method is to only save the case and to click on Validations
	 *             OK button
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 23-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickSaveOKBtn() {
		if (agIsVisible(FullDataEntryFormPageObjects.saveOkButton)) {
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
			agClick(FullDataEntryFormPageObjects.saveOkButton);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to close case in case listing
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Praveen Patil
	 * @Date : 22-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void closeCase() {
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.LSMVCancel);
		agClick(FullDataEntryFormPageObjects.LSMVCancel);
		Reports.ExtentReportLog("", Status.INFO, "Case is closed", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to save the updated case
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Ramkumar M P
	 * @Date : 30-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void LSMVSaveNupdate(String scenarioName, String sheetName) {
		agSetStepExecutionDelay("5000");
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.SaveButton);
		// FDE_Operations.resolveValidation();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.agwaitTillVisible(FullDataEntryFormPageObjects.receiptNumber, 20, 10000);
		String receiptNumber = agGetText(FullDataEntryFormPageObjects.receiptNumber);
		String copyofrctno = receiptNumber;
		if (receiptNumber.contains("Successfully Updated")) {
			String[] arrOfStr = receiptNumber.split("AE Case '");
			arrOfStr = arrOfStr[1].split("' Successfully Updated");
			String receiptNum = arrOfStr[0].trim();
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "UpdatedRCTNo", receiptNum);
			Reports.ExtentReportLog("Save Successfull: ", Status.PASS, "Successfull: " + receiptNum, true);
		} else {
			if (agGetText(FullDataEntryFormPageObjects.receiptNumber).contains("saved successfully")) {
				String findcase = "";
				if (agGetText(FullDataEntryFormPageObjects.receiptNumber).contains("Receipt number"))
					findcase = "Receipt number: ";
				if (agGetText(FullDataEntryFormPageObjects.receiptNumber).contains("Receipt Number"))
					findcase = "Receipt Number: ";
				String[] arrOfStr = receiptNumber.split(findcase);
				arrOfStr = arrOfStr[1].split("saved successfully");
				String receiptNum = arrOfStr[0].trim();
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "ReceiptNo",
						receiptNum);
				Reports.ExtentReportLog("LSMV Update the receipt", Status.PASS, "Save Successfull:  " + receiptNumber,
						true);
			} else {
				Reports.ExtentReportLog("LSMV Update the receipt", Status.FAIL,
						"ssave Un Successfull: - Following Message Displayed " + receiptNumber, true);
			}
		}
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is switch between cases
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date : 30-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SwtichRCT(String scenarioName, String sheet) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "sheet");
		String ReceiptNo = getTestDataCellValue(scenarioName, "ReceiptNo");
		if (!agGetText(FullDataEntryFormPageObjects.RecptTablabel).equalsIgnoreCase(ReceiptNo)) {
			agClick(FullDataEntryFormPageObjects.SelectRCT(ReceiptNo));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is close RCT
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date : 30-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void CloseRCT(String scenarioName, String sheet) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "sheet");
		String ReceiptNo = getTestDataCellValue(scenarioName, "ReceiptNo");
		agClick(FullDataEntryFormPageObjects.CloseRCT(ReceiptNo));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is edit given RCT
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date : 30-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void EditRCTFDE() {
		if (agIsVisible(FullDataEntryFormPageObjects.editRCt)) {
			agClick(FullDataEntryFormPageObjects.editRCt);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is edit given RCT as per Case Significance
	 *             scenario
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 04-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void editFDE_CaseSignificanceScenarios(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "CaseSignificanceScenarios");
		// if(scenarioName.toLowerCase().contains("scenario5")) {
		if (!getTestDataCellValue(scenarioName, "Patient_Therapy_ProductName").equalsIgnoreCase("#skip#")) {
			tabNavigation("Patient");
			if (!getTestDataCellValue(scenarioName, "Patient_RemoveTherapy").equalsIgnoreCase("#skip#")
					|| getTestDataCellValue(scenarioName, "Patient_RemoveTherapy").equalsIgnoreCase("true")) {
				// FDE_Events.keyEventOnset_CessationDateAsText(scenarioName);
				FDE_Patient.deletePatientPastTherapy(scenarioName, getTestDataCellValue(scenarioName, "TherapyRowNo"));

			} else
				FDE_Patient.setPatientPastTherapyProduct(scenarioName,
						getTestDataCellValue(scenarioName, "TherapyRowNo"));
		}

		if (!getTestDataCellValue(scenarioName, "Event_OnsetDate_AsText").equalsIgnoreCase("#skip#")
				|| !getTestDataCellValue(scenarioName, "Event_CessationDate").equalsIgnoreCase("#skip#")) {
			tabNavigation("Event(s)");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Events.keyEventOnset_CessationDateAsText(scenarioName);
			// FDE_Events.set_Events(scenarioName);
		}

		if (scenarioName.toLowerCase().contains("scenario3")) {
			if (!getTestDataCellValue(scenarioName, "Patient_MedHistory_StartDate_AsText").equalsIgnoreCase("#skip#")
					|| !getTestDataCellValue(scenarioName, "Patient_MedHistory_StopDate_AsText")
							.equalsIgnoreCase("#skip#")) {
				System.out.println("ScenarioName: " + scenarioName);
				tabNavigation("Patient");
				FDE_Patient.setMedHistoryStart_StopDate(scenarioName);
			}

		}

		if (scenarioName.toLowerCase().contains("scenario2")) {

			if (!getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent_Manual")
					.equalsIgnoreCase("#skip#")
					|| !getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent")
							.equalsIgnoreCase("#skip#")) {
				tabNavigation("Patient");
				FDE_Patient.setAgeAtTheTimeOfEvent(scenarioName);
			}

			if (!getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeGroup").equalsIgnoreCase("#skip#")) {
				tabNavigation("Patient");
				FDE_Patient.setAgeGroup(scenarioName);
			}

		}

		if (scenarioName.toLowerCase().contains("scenario13")) {

			if (!getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome").equalsIgnoreCase("#skip#")) {

				FDE_Events.setEventOutcome(scenarioName);
			}

		}

		if (scenarioName.toLowerCase().contains("scenario20")) {

			if (!getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm")
					.equalsIgnoreCase("#skip#")) {

				tabNavigation("Event(s)");
				agSetStepExecutionDelay("3000");
				agSetValue(FDE_EventsPageObjects.reportedTerm_Textfield,
						getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
				agSetStepExecutionDelay("8000");
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

				Reports.ExtentReportLog("", Status.INFO,
						"Event set to :" + getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"),
						true);
			}

			if (!getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome").equalsIgnoreCase("#skip#")) {
				tabNavigation("Event(s)");
				FDE_Events.setEventOutcome(scenarioName);
			}

			if (!getTestDataCellValue(scenarioName, "Patient_DeathDetails_AutopsyDone_Manual")
					.equalsIgnoreCase("#skip#")
					|| !getTestDataCellValue(scenarioName, "Patient_DeathDetails_AutopsyDone")
							.equalsIgnoreCase("#skip#")) {
				tabNavigation("Patient");
				FDE_Patient.setAutopsyDetail(scenarioName);
			}

		}

		if (scenarioName.toLowerCase().contains("scenario29")) {

			if (!getTestDataCellValue(scenarioName, "Labeling").equalsIgnoreCase("#skip#")) {

				tabNavigation("Labeling");
				agSetStepExecutionDelay("3000");
				FDE_Labelling.setLabel_caseSignificanceScenario(scenarioName);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

				Reports.ExtentReportLog("", Status.INFO,
						"Labeling set to :" + getTestDataCellValue(scenarioName, "Labeling"), true);
			}

		}

	}
}