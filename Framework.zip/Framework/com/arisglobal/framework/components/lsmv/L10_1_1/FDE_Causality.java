package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_CausalityPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_EventsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_LabellingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_ProductsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ProductsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.CommonOperations;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_Causality extends ToolManager {
	static String className = FDE_Causality.class.getSimpleName();
	static String eventsSheet = FDE_Events.class.getSimpleName();
	static String productoperations = ProductsOperations.class.getSimpleName();
	static String productsSheet = FDE_Products.class.getSimpleName();
	static boolean status;
	static String[] skipData={"#skip#"};

	
	/**********************************************************************************************************
	 * @Objective: To add Casuality information
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Rashmi
	 * @Date : 03-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SetCausality(String rownumber,String scenarioName) {
	
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agSetStepExecutionDelay("3000");
		CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.selectReporterDropdown(rownumber),
				getTestDataCellValue(scenarioName, "Reporter_Casuality"));
		CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.selectCompanyDropdown(rownumber),
				getTestDataCellValue(scenarioName, "Company_Casuality"));
				
		CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.selectRechallengeDropdown(rownumber),
				getTestDataCellValue(scenarioName, "ReChallenge"));
		

		CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.selectDechallengeDropdown(rownumber),
				getTestDataCellValue(scenarioName, "Causality_Dechallenge"));
		
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, " : Casuality Information", false);
		// }
	}
	
	
	/**********************************************************************************************************
	 * @Objective: To get Blinded product list
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 28-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void getBlindedProducts() {
		agClick(FDE_CausalityPageObjects.blindedButton);
		agAssertExists(FDE_CausalityPageObjects.unblindedButton);
		if (agIsVisible(FDE_CausalityPageObjects.unblindedButton)) {
			clickBlindedDropDown();
		}
	}

	/**********************************************************************************************************
	 * @Objective: To click Blinded DropDown
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 28-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickBlindedDropDown() {
		agClick(FDE_CausalityPageObjects.productDropdown);
		List<WebElement> list = agGetElementList(FDE_CausalityPageObjects.productList);
		for (int i = 1; i <= list.size(); i++) {
			Reports.ExtentReportLog("Blinded and Normal Products", Status.INFO,
					"" + agGetText(FDE_CausalityPageObjects.productGetText(Integer.toString(i))), true);
			System.out.println(agGetText(FDE_CausalityPageObjects.productGetText(Integer.toString(i))));
		}
		agClick(FDE_CausalityPageObjects.productDropdown);
	}

	/**********************************************************************************************************
	 * @Objective: click Unblinded DropDown
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 28-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickUnblindedDropDown() {
		agClick(FDE_CausalityPageObjects.productDropdown);
		List<WebElement> list = agGetElementList(FDE_CausalityPageObjects.productList);
		for (int i = 1; i <= list.size(); i++) {
			System.out.println(agGetText(FDE_CausalityPageObjects.productGetText(Integer.toString(i))));
			Reports.ExtentReportLog("Unblinded and Normal Products", Status.INFO,
					"" + agGetText(FDE_CausalityPageObjects.productGetText(Integer.toString(i))), true);
		}
		agClick(FDE_CausalityPageObjects.productDropdown);
	}

	/**********************************************************************************************************
	 * @Objective: To get UnBlinded product list
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 28-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void getUnblindedProducts() {
		// agClick(FDE_CausalityPageObjects.unblindedButton);
		agAssertExists(FDE_CausalityPageObjects.blindedButton);
		if (agIsVisible(FDE_CausalityPageObjects.blindedButton)) {
			clickUnblindedDropDown();
		}
	}

	/**********************************************************************************************************
	 * @Objective: To Verify AESI Checkbox
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 27-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyAESICheck(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		verifyCheckBox(FDE_CausalityPageObjects.AESI_CheckBox, getTestDataCellValue(scenarioName, "Causality_AESI"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Check/Uncheck Operation on
	 *             CheckBox under Specified Label
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author: Avinash
	 * @Date : 30-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCheckBox(String label, String boolCheck) {
		if (!label.trim().contains("#skip#") && !boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = agGetAttribute("class", FDE_CausalityPageObjects.checkBoxUnder(label));
			if (boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check")) {
				if (!checkBoxStatus.contains("ui-state-active")) {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is not checked", true);
				} else {
					Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is checked", false);
				}
			} else if (boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck")) {
				if (checkBoxStatus.contains("ui-state-active")) {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is checked", true);
				} else {
					Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is not checked", false);
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: To add result in E2B Causality
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 30-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addE2BCausalityResult(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_CausalityPageObjects.e2BCausalityLink);
		agClick(FDE_CausalityPageObjects.e2BCausalityAddLink);
		CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.result_Dropdown,
				getTestDataCellValue(scenarioName, "Causality_E2BCausality_Result"));
	}

	/**********************************************************************************************************
	 * @Objective: To add Casuality information
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 03-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void CausalityInformation(String scenarioName) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,
		// "ConfigurationSettings");
		// if (getTestDataCellValue(scenarioName,
		// "FDE_Causality").equalsIgnoreCase("Yes")) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Susar")) {
			agIsVisible(FDE_LabellingPageObjects.blindedButton);
			agClick(FDE_LabellingPageObjects.blindedButton);
		} else if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Susar1")) {
			agIsVisible(FDE_LabellingPageObjects.unblindedButton);
			agClick(FDE_LabellingPageObjects.unblindedButton);
		}

		if (getTestDataCellValue(scenarioName, "SelectCausalityProduct").equalsIgnoreCase("YES")) {
			agClick(FDE_LabellingPageObjects.labelingProductClick);
			agClick(FDE_LabellingPageObjects.labelingProduct(getTestDataCellValue(scenarioName, "CausalityProduct")));
		}

		agSetStepExecutionDelay("3000");
		CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.Reporter_Dropdown,
				getTestDataCellValue(scenarioName, "Reporter_Casuality"));
		CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.Company_Dropdown,
				getTestDataCellValue(scenarioName, "Company_Casuality"));
		CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.Dechallenge_Dropdown,
				getTestDataCellValue(scenarioName, "Causality_Dechallenge"));
		CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.Rechallenge_Dropdown,
				getTestDataCellValue(scenarioName, "ReChallenge"));
		if (getTestDataCellValue(scenarioName, "Causality_StartLatency_Manual").equalsIgnoreCase("check")) {
			agClick(FDE_CausalityPageObjects.startLatency_CheckBoxUnder);
			agSetValue(FDE_CausalityPageObjects.Causality_StartLatency,
					getTestDataCellValue(scenarioName, "Causality_StartLatency"));
			CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.startLatencyUnit_Dropdown,
					getTestDataCellValue(scenarioName, "Causality_StartLatency_Unit"));
		}
		if (getTestDataCellValue(scenarioName, "Causality_EndLatency_Manual").equalsIgnoreCase("check")) {
			agClick(FDE_CausalityPageObjects.endLatency_CheckBoxUnder);
			agSetValue(FDE_CausalityPageObjects.Causality_EndLatency,
					getTestDataCellValue(scenarioName, "Causality_EndLatency"));
			CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.EndLatencyUnit_Dropdown,
					getTestDataCellValue(scenarioName, "Causality_EndLatency_Unit"));
		}
		if(getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			agSetStepExecutionDelay("5000");
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, " : Casuality Information", false);
		
		String[] ColumnName = {"CausalityProduct","Reporter_Casuality","Company_Casuality","Causality_Dechallenge","ReChallenge"};
		String[] ColumnTitles = {"Product","Reporter_Casuality","Company_Casuality","Dechallenge","Rechallenge"};
		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, skipData);
		
		// }
	}

	/**********************************************************************************************************
	 * @Objective: Verify rollover from Action Taken With Drug field from Product to
	 *             Action Taken With Drug in Causality screen
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 30-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyActionTakenWithDrug(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");

		if (agGetText(FDE_CausalityPageObjects.ActionTakenWithDrug).equalsIgnoreCase(
				FDE_Products.getTestDataCellValue(scenarioName, "Products_ProductInformation_ActionTakenWithDrug"))) {
			Reports.ExtentReportLog("", Status.PASS, " : Verify rollover from Action Taken With Drug field", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					" : Verify rollover from Action Taken With Drug field Doesnt Match", false);
		}

	}

	/**********************************************************************************************************
	 * @Objective: To Set E2B Causality Source data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 24-Apr-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSourceDropDownValue(String Row, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_CausalityPageObjects.clicksource_Dropdown(Row));
			agClick(FDE_CausalityPageObjects.set_Dropdown(Row, (getTestDataCellValue(scenarioName, columnName))));
		}
	}

	/**********************************************************************************************************
	 * @Objective: To Set E2B Causality Method data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 24-Apr-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setMethodDropDownValue(String Row, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_CausalityPageObjects.clickmethod_Dropdown(Row));
			agClick(FDE_CausalityPageObjects.set_Dropdown(Row, (getTestDataCellValue(scenarioName, columnName))));
		}
	}

	/**********************************************************************************************************
	 * @Objective: To Set E2B Causality Result data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 24-Apr-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setResultDropDownValue(String Row, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_CausalityPageObjects.clickresul_Dropdown(Row));
			agClick(FDE_CausalityPageObjects.set_Dropdown(Row, (getTestDataCellValue(scenarioName, columnName))));
		}
	}

	/**********************************************************************************************************
	 * @Objective: To add E2B Causality data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 23-Apr-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addE2BCausality(String Row, String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (agIsExists(FDE_CausalityPageObjects.e2bRecord)) {
			agSetStepExecutionDelay("2000");
			setSourceDropDownValue(Row, scenarioName, "Causality_E2BCausality_Source");
			setMethodDropDownValue(Row, scenarioName, "Causality_E2BCausality_Method");
			setResultDropDownValue(Row, scenarioName, "Causality_E2BCausality_Result");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} else {
			agSetStepExecutionDelay("2000");
			agClick(FDE_CausalityPageObjects.e2bAdd_Button);
			setReportedTermDropDownValue(Row, scenarioName, "Causality_ReportedTerm");
			setSourceDropDownValue(Row, scenarioName, "Causality_E2BCausality_Source");
			setMethodDropDownValue(Row, scenarioName, "Causality_E2BCausality_Method");
			setResultDropDownValue(Row, scenarioName, "Causality_E2BCausality_Result");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: To Clcik on E2B Causality tab
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 26-Apr-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void clcikE2BCausality() {
		agSetStepExecutionDelay("2000");
		agClick(FDE_CausalityPageObjects.e2BCausalityLink);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: To Clcik on second E2B Causality tab
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 26-Apr-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clcikSecondCausality() {
		agSetStepExecutionDelay("2000");
		agClick(FDE_CausalityPageObjects.clickSecondCausality);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: To Verify the AESI Check box based on prerequisite conditions on
	 *             products[Auto-DOLO FRESH] and compare with the events and
	 *             products wrt to to case level
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 04-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyAESIinCausality(String rctNumber) {
		Reports.ExtentReportLog("", Status.INFO, "Verification of AESI in causality started", true);
		try {
			String aesiproductLTTerm = null;
			FDE_Operations.tabNavigation("Event(s)");
			agSetStepExecutionDelay("2000");
			String eventReportedTerm = agGetAttribute("value", FDE_EventsPageObjects.reportedTerm_Textfield);
			System.out.println(eventReportedTerm);// fever
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Operations.tabNavigation("Product(s)");
			agSetStepExecutionDelay("2000");
			String product = agGetAttribute("value", FDE_ProductsPageObjects.productDescription_Lookupfield);
			System.out.println(product);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			// FDE_Operations.saveAndExit();
			ProductsOperations.productsNavigations("productsListing");
			agSetStepExecutionDelay("3000");
			agAssertVisible(ProductsPageObjects.ListingkeywordSearchTextbox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agSetValue(ProductsPageObjects.ListingkeywordSearchTextbox, product);
			agClick(ProductsPageObjects.ListingkeywordSearchIcon);
			agSetStepExecutionDelay("2000");
			ProductsOperations.editProduct();
			String aesiProduct = agGetAttribute("value", ProductsPageObjects.preferredProductDescTextBox);
			System.out.println(aesiProduct);// Auto DOO Fresh
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CommonOperations.takeScreenShot();
			ProductsOperations.productsNavigations("AE'sOfSpecialInterest");
			agSetStepExecutionDelay("3000");
			String aePaginator = agGetText(ProductsPageObjects.aePaginator);
			// Verifies only for one event term
			if (aePaginator != null && aePaginator.startsWith("1")) {
				List<WebElement> list = agGetElementList(ProductsPageObjects.aesigetLLTTerm);
				aesiproductLTTerm = agGetAttribute("value", ProductsPageObjects.aesigetLLTTerm);
				Reports.ExtentReportLog("", Status.PASS, "PT Term Exists::", true);
				System.out.println(aesiproductLTTerm);
			} else {
				Reports.ExtentReportLog("", Status.INFO, "PT Term doesnt Exists::", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CaseManagementOperations.caseManagement_MenuNavigations("caseListing");
			CaseListingOperations.searchCase(rctNumber);
			CaseListingOperations.searchEdit();
			FDE_Operations.tabNavigation("Causality");
			agSetStepExecutionDelay("2000");
			agJavaScriptExecuctorScrollToElement(FDE_CausalityPageObjects.endLatencyLabel);
			if (aesiproductLTTerm == null) {
				boolean aesiCheck = agIsVisible(FDE_CausalityPageObjects.AESICheckboxChecked);
				if (aesiCheck == false) {
					Reports.ExtentReportLog("", Status.PASS, "AESI Check box Unchecked", true);
					CommonOperations.takeScreenShot();
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "AESI Check box checked", true);
				}
			} else if (aesiProduct.equalsIgnoreCase(product) && aesiproductLTTerm.equalsIgnoreCase(eventReportedTerm)) {
				boolean aesiCheck = agIsVisible(FDE_CausalityPageObjects.AESICheckboxChecked);
				if (aesiCheck) {
					Reports.ExtentReportLog("", Status.PASS, "AESI Check box checked", true);
					CommonOperations.takeScreenShot();
				}
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "AESI Check box not checked", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "AESI Check box verification in causality is not verified" + e,
					true);
		}
		Reports.ExtentReportLog("", Status.INFO, "Verification of AESI in causality ended", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Check/Uncheck Operation
	 *             from the application
	 * @InputParameters: label
	 * @OutputParameters:NA
	 * @author: Pooja S
	 * @Date : 10-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verificationOfCheckBox(String label) {
		if (!label.trim().contains("#skip#")) {
			String checkBoxStatus = agGetAttribute("class", FDE_CausalityPageObjects.checkBoxUnder(label));
			if (checkBoxStatus.contains("ui-state-active")) {
				Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is checked", true);
			} else {
				Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is not checked", true);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: To Set E2B Causality Source data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 5-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setReportedTermDropDownValue(String Row, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agJavaScriptExecuctorClick(FDE_CausalityPageObjects.clickReportTerm_Dropdown(Row));
			agJavaScriptExecuctorClick(FDE_CausalityPageObjects.setReportTerm_Dropdown(Row,
					(getTestDataCellValue(scenarioName, columnName))));
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verify rollover from Action Taken With Drug[B.4.k.16][G.k.8]
	 *             field from Product to Action Taken With Drug[B.4.k.16][G.k.8] in
	 *             Causality screen for each product upon save, import and export of
	 *             the case.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 17-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyActionTakenWithDrug_RollOver() {
		Reports.ExtentReportLog("", Status.INFO,
				"Auto Rollover verification of Action Taken With Drug field in causality is started", true);
		try {
			FDE_Operations.tabNavigation("Product(s)");
			agSetStepExecutionDelay("3000");
			String actionTakenDrug_Product = agGetText(
					FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.actionTakenWithDrug));
			CommonOperations.takeScreenShot();
			System.out.println(actionTakenDrug_Product);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Operations.tabNavigation("Causality");
			String actionTakenDrug_Casuality = agGetText(FDE_CausalityPageObjects.ActionTakenWithDrug);
			CommonOperations.takeScreenShot();
			System.out.println(actionTakenDrug_Casuality);
			if (actionTakenDrug_Product.equalsIgnoreCase(actionTakenDrug_Casuality)) {
				Reports.ExtentReportLog("", Status.PASS,
						"Auto Rollover verification of Action Taken With Drug field in causality is matched", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Auto Rollover verification of Action Taken With Drug field in causality is not matched", true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Auto Rollover verification of Action Taken With Drug field in causality is not verified" + e,
					true);
		}
		Reports.ExtentReportLog("", Status.INFO,
				"Auto Rollover verification of Action Taken With Drug field in causality is ended", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to handle Validation Messages in
	 *             causality Screen.
	 * @InputParameters: NA
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 13-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void handleValidationMessage() {
		agWaitTillVisibilityOfElement(FDE_CausalityPageObjects.confirmationPopup);
		agSetStepExecutionDelay("5000");
		if (agIsVisible(FDE_CausalityPageObjects.confirmationPopup) == true) {
			CommonOperations.takeScreenShot();
			agClick(FDE_CausalityPageObjects.confirmPOPupNoBtn);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: Verify R2 tags in Causality tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 20-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyCausalityR2Tags() {
		Reports.ExtentReportLog("", Status.INFO, "********Causality R2 tag verification Started*******", true);
		agAssertVisible(FDE_CausalityPageObjects.R2Actiontakenwiththedrug);
		agAssertVisible(FDE_CausalityPageObjects.R2Rechallenge);
		agAssertVisible(FDE_CausalityPageObjects.R2StartLatency);
		agAssertVisible(FDE_CausalityPageObjects.R2EndLatency);
		Reports.ExtentReportLog("", Status.INFO, "********Causality R2 tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify R3 tags in Causality tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 20-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyCausalityR3Tags() {
		Reports.ExtentReportLog("", Status.INFO, "********Causality R3 tag verification Started*******", true);
		agAssertVisible(FDE_CausalityPageObjects.R3Actiontakenwiththedrug);
		agAssertVisible(FDE_CausalityPageObjects.R3Rechallenge);
		agAssertVisible(FDE_CausalityPageObjects.R3StartLatency);
		agAssertVisible(FDE_CausalityPageObjects.R3EndLatency);
		Reports.ExtentReportLog("", Status.INFO, "********Causality R3 tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify codelist tags in Causality tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 20-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCausalityCodeList() {
		Reports.ExtentReportLog("", Status.INFO, "********Causality codelist tag verification Started*******", true);
		agAssertVisible(FDE_CausalityPageObjects.CLReportercausality);
		agAssertVisible(FDE_CausalityPageObjects.CLCoumpanycausality);
		agAssertVisible(FDE_CausalityPageObjects.CLDechallenge);
		agAssertVisible(FDE_CausalityPageObjects.CLRechallenge);
		agAssertVisible(FDE_CausalityPageObjects.CLStartLatency);
		agAssertVisible(FDE_CausalityPageObjects.CLEndLatency);
		Reports.ExtentReportLog("", Status.INFO, "********Causality codelist tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Reporter ,Company,Dechallenge
	 *             and Rechallenge for all events in causality Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 28-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_Causality(String scenarioName, int i) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		
		if(scenarioName.equalsIgnoreCase("LSMV_CaseSignificance_AutoDerivation_Scenario16_C1") || 
				scenarioName.equalsIgnoreCase("LSMV_CaseSignificance_AutoDerivation_Scenario19_C1") ||
				scenarioName.toLowerCase().contains(("LSMV_CaseSignificance_scenario18").toLowerCase()) ||
				scenarioName.toLowerCase().contains(("LSMV_CaseSignificance_scenario30").toLowerCase())) {
			agSetStepExecutionDelay("3000");
			agClick(FDE_CausalityPageObjects.Rep_Dropdown.replace("%count%", (Integer.toString(i))));
			agClick(FDE_CausalityPageObjects.selectDropdown(getTestDataCellValue(scenarioName, "Reporter_Casuality")));

			agClick(FDE_CausalityPageObjects.Com_Dropdown.replace("%count%", (Integer.toString(i))));
			agClick(FDE_CausalityPageObjects.selectDropdown(getTestDataCellValue(scenarioName, "Company_Casuality")));
		}else {
		agSetStepExecutionDelay("3000");
		agClick(FDE_CausalityPageObjects.Rep_Dropdown.replace("%count%", (Integer.toString(i))));
		agClick(FDE_CausalityPageObjects.selectDropdown(getTestDataCellValue(scenarioName, "Reporter_Casuality")));

		agClick(FDE_CausalityPageObjects.Com_Dropdown.replace("%count%", (Integer.toString(i))));
		agClick(FDE_CausalityPageObjects.selectDropdown(getTestDataCellValue(scenarioName, "Company_Casuality")));

		agClick(FDE_CausalityPageObjects.Rechallen_Dropdown.replace("%count%", (Integer.toString(i))));
		agClick(FDE_CausalityPageObjects.selectDropdown(getTestDataCellValue(scenarioName, "ReChallenge")));

		agClick(FDE_CausalityPageObjects.Dechallen_Dropdown.replace("%count%", (Integer.toString(i))));
		agClick(FDE_CausalityPageObjects.selectDropdown(getTestDataCellValue(scenarioName, "Causality_Dechallenge")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		
		}
		}

	/**********************************************************************************************************
	 * @Objective: Below method is created to select product in causality
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 28-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SelectProductLabeling(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_LabellingPageObjects.labelingProductClick);
		agSetStepExecutionDelay("2000");
		agClick(FDE_LabellingPageObjects.labelingProduct(getTestDataCellValue(scenarioName, "CausalityProduct")));
	}

	/**********************************************************************************************************
	 * @Objective: Below method is created to verify data in Company causality
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 05-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCompanyCausality(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Company_Casuality"),
				FDE_CausalityPageObjects.companyCasuality);
		Reports.ExtentReportLog("", Status.PASS, "Company causality value updated successfully", true);
		String[] ColumnName = {"Company_Casuality"};
		String[] ColumnTitles = {"Company_Casuality"};
		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, skipData);
	}
	/**********************************************************************************************************
	 * @Objective: To add 2nd E2B Causality data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 03-Feb-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addSecE2BCausality(String Row, String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetStepExecutionDelay("2000");
			agClick(FDE_CausalityPageObjects.e2bAdd_Button);
			setReportedTermDropDownValue(Row, scenarioName, "Causality_ReportedTerm");
			setSourceDropDownValue(Row, scenarioName, "Causality_E2BCausality_Source");
			setMethodDropDownValue(Row, scenarioName, "Causality_E2BCausality_Method");
			setResultDropDownValue(Row, scenarioName, "Causality_E2BCausality_Result");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	
/**********************************************************************************************************
 * @Objective: To Verify Manual Checkbox
 * @InputParameters: scenarioName
 * @OutputParameters:
 * @author:Wajahat Umar S
 * @Date : 10-Feb-2019
 * @UpdatedByAndWhen:
 **********************************************************************************************************/
public static void MaualCheckBoxExistAESIAccessRelationship() {
	
	try {
		if(agIsVisible(FDE_CausalityPageObjects.AESIManualCheckBox)==true) {
			agJavaScriptExecuctorScrollToElement(FDE_CausalityPageObjects.AESIManualCheckBox);
			Reports.ExtentReportLog("", Status.PASS,
					"AESI Manual CheckBox is Present", true);
			if(agIsVisible(FDE_CausalityPageObjects.AESICheckboxChecked)==true) {
				
			}else {
				agClick(FDE_CausalityPageObjects.AESIManualCheckBox);
				agSetStepExecutionDelay("2000");
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				agClick(FDE_CausalityPageObjects.AESICheckbx);
				Reports.ExtentReportLog("", Status.PASS,
						"AESI Checkbox is Checked and Verified as Editable", true);
			}
			
		}else {
			Reports.ExtentReportLog("", Status.FAIL,
					"AESI Manual CheckBox is Not Present", true);
		}
		if(agIsVisible(FDE_CausalityPageObjects.AccessRelationShipCheckBox)==true) {
			Reports.ExtentReportLog("", Status.PASS,
					"Access Relationship Manual CheckBox is Present", true);
			agSetStepExecutionDelay("2000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agClick(FDE_CausalityPageObjects.AccessRelationShipCheckBoxClick);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.AccessRelationShip_Dropdown,
					getTestDataCellValue("CopyCase", "AccessRelationship"));
			
			Reports.ExtentReportLog("", Status.PASS,
					"Access Relationship is Selected and Verified as Editable", true);
			
		}else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Access Relationship Manual CheckBox is Not Present", true);
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
}

/**********************************************************************************************************
* @Objective: To Verify Manual Checkbox
* @InputParameters: scenarioName
* @OutputParameters:
* @author:Wajahat Umar S
* @Date : 10-Feb-2019
* @UpdatedByAndWhen:
**********************************************************************************************************/
public static void MaualCheckBoxNotExistAESIAccessRelationship() {
	try {
		if(!agIsVisible(FDE_CausalityPageObjects.AESIManualNoCheckBox)==true) {
			Reports.ExtentReportLog("", Status.PASS,
					"AESI Manual CheckBox is Not Present", true);
			if(agIsVisible(FDE_CausalityPageObjects.AESICheckboxChecked)==true) {
				Reports.ExtentReportLog("", Status.FAIL,
						"AESI Checkbox is Checked and Verified as Editable", true);
			}else {
				
				Reports.ExtentReportLog("", Status.PASS,
						"AESI Checkbox is Non-Editable", true);
			}
			
		}else {
			Reports.ExtentReportLog("", Status.FAIL,
					"AESI Manual CheckBox is not Present", true);
		}
		
			
			
		if(agIsVisible(FDE_CausalityPageObjects.UnSelectedARDropDown)==true) {
			Reports.ExtentReportLog("", Status.PASS,
					"Access Relationship Manual CheckBox is Not Present", true);
			Reports.ExtentReportLog("", Status.PASS,
					"Access Relationship DropDown is Non_Editable", true);
		}else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Access Relationship DropDown is Editable", true);
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}		
	/**********************************************************************************************************
	 * @Objective: To simply add Casuality information
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:	Abhisek Ghosh
	 * @Date : 03-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_CausalityInformation(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Susar")) {
			agIsVisible(FDE_LabellingPageObjects.blindedButton);
			agClick(FDE_LabellingPageObjects.blindedButton);
		} else if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Susar1")) {
			agIsVisible(FDE_LabellingPageObjects.unblindedButton);
			agClick(FDE_LabellingPageObjects.unblindedButton);
		}

		if (getTestDataCellValue(scenarioName, "SelectCausalityProduct").equalsIgnoreCase("YES")) {
			agClick(FDE_LabellingPageObjects.labelingProductClick);
			agClick(FDE_LabellingPageObjects.labelingProduct(getTestDataCellValue(scenarioName, "CausalityProduct")));
		}

		agSetStepExecutionDelay("3000");
		CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.Reporter_Dropdown,
				getTestDataCellValue(scenarioName, "Reporter_Casuality"));
		CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.Company_Dropdown,
				getTestDataCellValue(scenarioName, "Company_Casuality"));
		CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.Dechallenge_Dropdown,
				getTestDataCellValue(scenarioName, "Causality_Dechallenge"));
		CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.Rechallenge_Dropdown,
				getTestDataCellValue(scenarioName, "ReChallenge"));
		if (getTestDataCellValue(scenarioName, "Causality_StartLatency_Manual").equalsIgnoreCase("check")) {
			agClick(FDE_CausalityPageObjects.startLatency_CheckBoxUnder);
			agSetValue(FDE_CausalityPageObjects.Causality_StartLatency,
					getTestDataCellValue(scenarioName, "Causality_StartLatency"));
			CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.startLatencyUnit_Dropdown,
					getTestDataCellValue(scenarioName, "Causality_StartLatency_Unit"));
		}
		if (getTestDataCellValue(scenarioName, "Causality_EndLatency_Manual").equalsIgnoreCase("check")) {
			agClick(FDE_CausalityPageObjects.endLatency_CheckBoxUnder);
			agSetValue(FDE_CausalityPageObjects.Causality_EndLatency,
					getTestDataCellValue(scenarioName, "Causality_EndLatency"));
			CommonOperations.setFDEDropDownValue(FDE_CausalityPageObjects.EndLatencyUnit_Dropdown,
					getTestDataCellValue(scenarioName, "Causality_EndLatency_Unit"));
		}
		if(getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			agSetStepExecutionDelay("5000");
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, " : Casuality Information", false);

	}		
}




