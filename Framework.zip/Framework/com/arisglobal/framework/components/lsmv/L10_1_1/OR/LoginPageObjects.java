package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

import org.openqa.selenium.WebDriver;

import com.arisglobal.framework.lib.main.Constants;

public class LoginPageObjects {

	WebDriver driver = Constants.driver;

	public LoginPageObjects(WebDriver driver) {

	}
	public static String userName = "xpath#//input[@id='loginForm:username']";
	public static String passWord = "xpath#//input[@id='loginForm:password']";
	public static String loginButton = "xpath#//button[@id='loginForm:signInButtonvisible']";
	public static String LSMVDisplaySettings = "xpath#//img[@alt='User Preferences']";
	public static String LSMVLogout = "xpath#//div[@id='headerForm:settingsBlock']/div[@class='headIconRight compheadIconRight']/div[@class='AdvanceSe-tooltip inqColorWidth']/div[@class='tooltipAct tooltipInqList navigationFixed usertolltipsty agSavePrefrance']/div[@class='NewLogout']/a[@id='headerForm:logout']";
	public static String LSMVLogoutConfirmationYes = "xpath#//button[@id='logoutForm:confirmation_yes']/span[@class='ui-button-text ui-c']";
	public static String logoutClose = "xpath#//a[@id='relogin:j_id_g']";
	public static String confirmationWindow = "xpath#//span[@id='loginForm:sessionUserid_title']";
	public static String okButton = "xpath#//span[contains(text(),'Ok')]";
	public static String logOutConfirmationText = "xpath#//label[contains(@id,'relogin') and contains(text(),'You have successfully logged out.')]";
	//a[text()='Close']

	public static String about = "xpath#//a[@title='About']";
	public static String aboutSpan = "xpath#//span[contains(@id,'aboutPage')]";
	public static String closeAbout = "xpath#//span[contains(@id,'aboutPage')]/parent::div/a";
	public static String buildNo = "Build No";
	public static String licseFor = "License For";
	
	public static String getFldVal(String field) {
		return "xpath#//label[contains(text(),'"+field+"')]/ancestor::tr[1]/td[2]/label";
	}

	/////////////////////////////// Reset Password Screen /////////////////////////////////////////
	public static String oldPassword_TextBox = "xpath#//input[@id='changePassword:oldPassword']";
	public static String newPassword_TextBox = "xpath#//input[@id='changePassword:password']";
	public static String confirmNewPassword_TextBox = "xpath#//input[@id='changePassword:confirmPassword']";
	
	public static String submit_button = "xpath#//button[@id='changePassword:save']";
}
