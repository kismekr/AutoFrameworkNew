package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class AppParameters_CallLogPageObjects {

	////////////////////////// Administration >> System Administration >>
	////////////////////////// Application Parameters >> Call Log
	////////////////////////// ////////////////////////////////////////////////
	/////////////////////////////////////////// Call Log >> Call Log
	////////////////////////// ///////////////////////////////////////////////////////

	public static String callLogNumberingFormat_TextBox = "xpath#//input[@id ='applicationParameterForm:callLogNumberingFormatId']";
	public static String callLogNumberingFormat1_DropDown = "xpath#//div[@id='applicationParameterForm:I3-5009']";
	public static String callLogNumberingFormat2_DropDown = "xpath#//div[@id='applicationParameterForm:dateSep3']";
	public static String resetSequenceBy_DropDown = "xpath#//div[@id='applicationParameterForm:resetSequenceByMenu2']";

	public static String displaySupportDocument_CheckBox = "Display Support Document";
	public static String considerProtectConfidentialitySummarySheet_CheckBox = "Consider Protect Confidentiality in Summary Sheet";
	public static String reAuthenticationforCallLogSubmission_CheckBox = "ReAuthentication for Call Log Submission";

	/////////////////////////////////////////// Call Log >> Dispatcher
	/////////////////////////////////////////// ///////////////////////////////////////////////////////

	public static String enableAutoSave_Radio = "Enable Auto Save";
	public static String dispatcherAutoSaveTime_TextBox = "xpath#//input[@id ='applicationParameterForm:dispacherAutoSaveComplaint']";
	public static String EnableAutoSaveRadioBtn = "xpath#//label[text()='Enable Auto Save']/ancestor::div//div//label[text()='Yes']/preceding::div[contains(@class,'ui-radiobutton ui-widget')]";
}
