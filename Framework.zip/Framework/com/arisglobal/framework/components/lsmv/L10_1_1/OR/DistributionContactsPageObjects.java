package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class DistributionContactsPageObjects {

	public static String distributionHover = "xpath#//a[@class='ui-menuitem-link ui-submenu-link ui-corner-all']/span[contains(text(),'Distribution')]";
	// public static String distributionNew =
	// "xpath#//a[@id='headerForm:distributionUnit']//span[@class='ui-menuitem-text'][contains(text(),'Distribution')]";
	public static String distributionNew = "xpath#//a[@id='headerForm:distributeionSetup']//span[@class='ui-menuitem-text'][contains(text(),'Distribution')]";
	public static String new_Button = "xpath#//span[@class='ui-button-text ui-clickable'][contains(text(),'New')]";
	public static String save_Button = "xpath#//span[@class='ui-button-text ui-clickable'][contains(text(),'Save')]";
	public static String delete_Button = "xpath#//span[@class='ui-button-text ui-clickable'][contains(text(),'Delete')]";
	public static String distributionContactName_Textbox = "xpath#//input[@id='name']";
	public static String receiverType_Dropdown = "Receiver Type";
	public static String receiverOrganization_LookupAccount = "xpath#//label[@for='accountId'][text()='Receiver Organization']//parent::span//div//button//span[contains(@class,'fa fa-search')]";
	public static String accountName_Textbox = "xpath#//label[contains(text(),'Account Name')]/ancestor::div/input[@type='text']";
	public static String checkFirstAccountName = "xpath#//p-table[@class='agcommonTblStyle']//tbody/tr[1]/td/p-tableradiobutton";
	public static String receiverOrganization_LookupCompanyunit = "xpath#//label[@for='partnerId'][text()='Receiver Organization']//parent::span//div//button//span[contains(@class,'fa fa-search')]";
	public static String pivot_Lookup = "xpath#//label[@for='pivotRuleId'][text()='Pivot']//parent::span//div//button//span[contains(@class,'fa fa-search')]";
	public static String ruleName_Textbox = "xpath#//label[contains(text(),'Attribute Name')]/ancestor::div/input[@type='text']";
	public static String checkFirstRuleID = "xpath#//p-table[@class='agcommonTblStyle']//tbody/tr[1]/td/p-tableradiobutton";
	public static String language_Dropdown = "Language";
	public static String description_Textarea = "xpath#//textarea[@id='description']";
	public static String correspondenceMedium_Dropdown = "Correspondence Medium";
	public static String correspondenceMediumDetails_Textbox = "xpath#//input[@id='correspondenceMediumDetails']";
	public static String replytoEmailAddress_Textbox = "xpath#//input[@id='replyToEmailAddr']";
	public static String correspondenceCCEmailAddress_Textbox = "xpath#//input[@id='ccEmailIds']";
	public static String submissionDueDateCalculationBasedOn_Dropdown = "Submission Due Date Calculation Based On";
	public static String affiliateSubmissionDueDateCalculationBasedOn_Dropdown = "Affiliate Submission Due Date Calculation Based On";
	public static String mailServer_Dropdown = "Mail Server";
	public static String allowSingleEmailSubmission_label = "Allow Single Email Submission?";
	public static String allowBackReporting_label = "Allow Back Reporting?";
	public static String senderComments_label = "Sender Comments(B.5.4) Access / H4?";
	public static String eventDescription_label = "Event Description(B.5.1) Access / H1?";
	public static String storeLocalDatainLSMV_label = "Store Local Data in LSMV?";
	public static String spainStateAccess_label = "Spain State Access?";
	public static String localLabelingAccess_label = "Local Labeling Access?";
	public static String allowICSRattachments_label = "Allow ICSR attachments?";
	public static String LocalApprovalAccess_label = "LocalApprovalAcessCheckBox";
	public static String summaryandReporterCommentsAccess_label = "H.5.r Summary and Reporter Comments Access?";
	public static String submittingUnitsAdd_Button = "xpath#//a[@class='agDistAddBtn']";
	public static String submittingUnitsDelete_Button = "xpath#//a[@class='agDistDeleteBtn']";
	public static String companyUnitCode_Textbox = "xpath#//label[contains(text(),'Company Unit Code')]/ancestor::div/input[@type='text']";
	public static String companyUnitName_Textbox = "xpath#//label[contains(text(),'Company Unit Name')]/ancestor::div/input[@type='text']";
	public static String search_Button = "xpath#//span[contains(text(),'Search')]/ancestor::button";
	public static String clear_Button = "xpath#//span[contains(text(),'Clear')]/ancestor::button";
	public static String checkFirstCompanyUnit = "xpath#//p-table[@class='agcommonTblStyle']//tbody/tr[1]/td/p-tablecheckbox";
	public static String checkFirstCompanyUnit1 = "xpath#//p-table[@class='agcommonTblStyle']//tbody/tr[1]/td/p-tableradiobutton";
	public static String ok_Button = "xpath#//p-dialog//div/button/span[text()='OK']";
	public static String validaionOk_Button = "xpath#//button[contains(@class,'dialogBtnOk ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only')][@type='button']";
	public static String validationMessage = "xpath#//span[@class='ui-confirmdialog-message']";

	// Format

	public static String distributionFormatNew = "xpath#//button[contains(@class,'agDistAddBtn')]/child::span[@class='ui-button-text ui-clickable']";
	public static String distributionFormatAdd_Button = "xpath#//p-header/label[text()='Distribution Formats']/parent::p-header/span/a[text()='Add']";
	public static String distributionFormatDelete_Button = "xpath#//p-header/label[text()='Distribution Formats']/parent::p-header/span/a[text()='Delete']";
	public static String formatDisplayName_Textbox = "xpath#//input[@id='format']";
	public static String pivotFormat_Lookup = "xpath#//label[text()='Pivot']//parent::span//div//button//span[contains(@class,'fa fa-search')]";
	public static String format_Dropdown = "Format";
	public static String reportMedium_Dropdown = "Report Medium";
	public static String mediumDetails_Textbox = "xpath#//input[@id='mediumDetails']";
	public static String OLTConfiguration_Dropdown = "OLT Configuration";
	public static String XMLDocType_Dropdown = "XML Doc Type";
	public static String MessageType_Dropdown = "Message Type";
	public static String submissionWorkflow_Dropdown = "Submission Workflow";
	public static String dataPrivacy_Dropdown = "Data Privacy";
	public static String includeLiteraturedocumentinsubmission_label = "Include Literature document in submission?";
	public static String blindedReport_label = "Blinded Report?";
	public static String autoRedistributeonMinorChange_label = "Auto Redistribute on Minor Change";
	public static String touchlessSubmission_label = "Touchless Submission?";
	public static String considerSimilarProducts_label = "Consider Similar Products?";
	public static String IncludeR2R3 = "Include R3 in R2?";
	public static String SimilarDevices = "Similar Devices";
	public static String SendFinalReport = "Send Final Report";
	public static String senderContact_Lookup = "xpath#//label[text()='Sender Contact']//parent::span//div//button//span[contains(@class,'fa fa-search')]";
	public static String receiverContact_Lookup = "xpath#//label[text()='Receiver Contact']//parent::span//div//button//span[contains(@class,'fa fa-search')]";
	public static String emailTemplate_Lookup = "xpath#//label[text()='Email Template']//parent::span//div//button//span[contains(@class,'fa-search')]";
	public static String faxTemplate_Lookup = "xpath#//label[text()='Fax Template']//parent::span//div//button//span[contains(@class,'fa-search')]";
	public static String coverPageTemplate_Lookup = "xpath#//label[text()='Cover Page Template']//parent::span//div//button//span[contains(@class,'fa-search')]";
	public static String contactFirstNameTextbox = "xpath#//input[@name='firstName']";
	public static String contactLastNameTextbox = "xpath#//input[@name='lastName']";
	public static String contactSearchButton = "xpath#//button/span[text()='Search']";
	public static String contactCheckBox = "xpath#//span[@class='ui-radiobutton-icon ui-clickable']";
	public static String contactOkButton = "xpath#//div[@class='searchOkbtn']/button/span[text()='OK']";
	public static String templateNameTextbox = "xpath#//input[@name='name']";
	public static String templateselectRadio = "xpath#//td[@class='tblEditRow']//div[@class='ui-radiobutton-box ui-widget ui-state-default']";

	// Anchor

	public static String distributionAnchorAdd_Button = "xpath#//p-header/label[text()='Distribution Anchors']/parent::p-header/span/a[text()='Add']";
	public static String distributionAnchordelete_Button = "xpath#//p-header/label[text()='Distribution Anchors']/parent::p-header/span/a[text()='Delete']";
	public static String anchorName_Textbox = "xpath#//input[@id='displayName']";
	public static String pivotAnchor_Lookup = "xpath#//label[text()='Pivot']//parent::span//div//button//span[contains(@class,'fa fa-search')]";
	public static String effectiveStartDateTextbox = "xpath#//p-calendar[@id='startDate']";
	public static String effectiveEndDateTextbox = "xpath#//p-calendar[@id='endDate']";
	public static String reportType_Dropdown = "Submission Report Type";
	public static String ruleInclusionLogic_Dropdown = "Rule Inclusion Logic";
	public static String timeline_Textbox = "xpath#//input[@id='timeLineDay']";
	public static String affiliateSubmissionDueDateTimeline_Textbox = "xpath#//input[@id='affliateSubmissionTimeLineDays']";

	// Distribution filter

	public static String distributionFilterExpand = "xpath#//span[@class='pi pi-plus']";
	public static String distributionFilterMinimize = "xpath#//span[@class='pi pi-minus']";
	public static String distributionFilterContactName_Textbox = "xpath#//input[@name='unitName']";
	public static String distributionFilterFormatDisplayName_Textbox = "xpath#//input[@name='formatName']";
	public static String distributionFilterAnchorName_Textbox = "xpath#//input[@name='anchorName']";
	public static String distributionFilterFormatClick = "xpath#//tr[contains(@class,'treeLevel0 ng-star-inserted')]";
	public static String distributionFilterSearch = "xpath#//td[@class='treeNodeData treeNodeTooltip agDistTreeTableColName']";

	public static String click_dropdown = "xpath#//div[@id='rightDistParentLayout']//label[text()='%s']/parent::span//p-dropdown/div/label";
	public static String select_value = "xpath#//ul[contains(@class,'ui-dropdown-list')]/child::li/span[text()='%s']";

	public static String SubmittingUnitName = "xpath#//label[text()='Submitting Units']/ancestor::p-panel//tr[@class='ui-selectable-row ng-star-inserted']//td[1]/following-sibling::td[1]";
	public static String SubmittingUnitCode = "xpath#//label[text()='Submitting Units']/ancestor::p-panel//tr[@class='ui-selectable-row ng-star-inserted']//td[1]/following-sibling::td[2]";

	public static String DistributionContact = "xpath#//td[contains(text(),'%s')]";
	public static String NextPage = "xpath#//p-paginator[@styleclass='ui-paginator-top']//a[@class='ui-paginator-next ui-paginator-element ui-state-default ui-corner-all']";
	public static String VerifyDistributionContact = "xpath#//p-header[@class='agDistPanelHeader']/label/following-sibling::label";

	public static String ReciverTypeDDValue = "xpath#//p-dropdown[@id='unitType']/div";
	public static String ReciverOrgTextBox = "xpath#//input[@id='accountId']";
	public static String CountryTextbox = "xpath#//input[@id='country']";
	public static String LanguageDD = "xpath#//label[@class='ng-tns-c3-22 ui-dropdown-label ui-inputtext ui-corner-all ng-star-inserted']";
	public static String CorrespondenceMailDD = "xpath#//label[@class='ng-tns-c3-23 ui-dropdown-label ui-inputtext ui-corner-all ng-star-inserted']";
	public static String SubmissionDueDateDD = "xpath#//label[@class='ng-tns-c3-24 ui-dropdown-label ui-inputtext ui-corner-all ng-star-inserted']";
	public static String AffSubmissionDueDateDD = "xpath#//label[@class='ng-tns-c3-25 ui-dropdown-label ui-inputtext ui-corner-all ng-star-inserted']";
	public static String MailServerDD = "xpath#//label[@class='ng-tns-c3-26 ui-dropdown-label ui-inputtext ui-corner-all ng-star-inserted']";

	public static String CheckedCheckBox = "xpath#//label[starts-with(normalize-space(text()),'{0}')]/../descendant::div[contains(@class,'ui-state-active')]";
	public static String Active = "Active";
	public static String VariableContact = "Variable Contact";

	public static String MaximizeContact = "xpath#//td[contains(text(), '%s')]//i";
	public static String Format = "xpath#//tr[contains(@class,'treeLevel0 ng-star-inserted')]//td//p-treetabletoggler";
	public static String ExpediteTimeline = "xpath#//input[@id='expeditedTimeLine']";
	public static String FormatDD = "xpath#//label[@class='ng-tns-c3-33 ui-dropdown-label ui-inputtext ui-corner-all ng-star-inserted']";
	public static String ReportMediumDD = "xpath#//label[@class='ng-tns-c3-34 ui-dropdown-label ui-inputtext ui-corner-all ng-star-inserted']";
	public static String OLTConfigDD = "xpath#//label[@class='ng-tns-c3-35 ui-dropdown-label ui-inputtext ui-corner-all ng-star-inserted']";
	public static String XMLDocDD = "xpath#//label[@class='ng-tns-c3-40 ui-dropdown-label ui-inputtext ui-corner-all ng-star-inserted']";
	public static String MsgTypeDD = "xpath#//label[@class='ng-tns-c3-41 ui-dropdown-label ui-inputtext ui-corner-all ng-star-inserted']";
	public static String SenderContact_TextBox = "xpath#//input[@id='senderContactId']";
	public static String receiverContactId_TextBox = "xpath#//input[@id='receiverContactId']";
	public static String SubmissionWfDD = "xpath#//label[@class='ng-tns-c3-36 ui-dropdown-label ui-inputtext ui-corner-all ng-star-inserted']";
	public static String DataPrivacyDD = "xpath#//label[@class='ng-tns-c3-37 ui-dropdown-label ui-inputtext ui-corner-all ng-star-inserted']";
	public static String AnchorTab = "xpath#(//td[contains(text(),'%s')])[1]/parent::tr/following-sibling::tr[2]";
	public static String SubmissionReportTypeDD = "xpath#//label[@class='ng-tns-c3-75 ui-dropdown-label ui-inputtext ui-corner-all ng-star-inserted']";
	public static String IncusionLogicDD = "xpath#//label[@class='ng-tns-c3-76 ui-dropdown-label ui-inputtext ui-corner-all ui-placeholder ng-star-inserted']";
	public static String AnchorMaximize = "xpath#//td[contains(text(),'%s')]/parent::tr/following-sibling::tr[1]//td//a";

	public static String ConfirmPopUp = "xpath#//span[text()='Confirmation']";
	public static String ConfirmYesBTn = "xpath#//button//span[text()='Yes']";
	public static String ConfirmNoBTn = "xpath#//button//span[text()='No']";
	/**********************************************************************************************************
	 * @Objective:The below method is created to click drop down in distribution
	 *                format.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Mythri Jain Date : 11-feb-2020 Updated by and when
	 **********************************************************************************************************/
	public static String resultLocator = null;

	public static String clickdropdown(String runTimeLabel) {
		String value = click_dropdown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select dropdown value by passing
	 *                value at runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Mythri Jain Date : 11-feb-2020 Updated by and when
	 **********************************************************************************************************/

	public static String selectDropdownvalue(String runTimeLabel) {
		String value = select_value;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String DistributionContact(String label) {
		String value = DistributionContact.replace("%s", label);
		return value;
	}

	public static String MaximizeContact(String label) {
		String value = MaximizeContact.replace("%s", label);
		return value;
	}

	public static String MaximizeAnchor(String label) {
		String value = AnchorMaximize.replace("%s", label);
		return value;
	}

	public static String AnchorTab(String label) {
		String value = AnchorTab.replace("%s", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox left of
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:WajahatUmar S
	 * @Date : 05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String CheckedCheckBox(String checkBoxLabel) {
		String actualLocator = CheckedCheckBox;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}

}
