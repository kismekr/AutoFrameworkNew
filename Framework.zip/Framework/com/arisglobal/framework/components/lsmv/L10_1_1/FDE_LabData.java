package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_LabDataPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_MedraLookUpPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_LabData extends ToolManager {
	public static WebElement webElement;
	static String className = FDE_LabData.class.getSimpleName();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown in meddra lookup
	 * @InputParameters: scenarioName, columnName, label
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 25-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDownValue_MedDRAlookup(String label, String scenarioName, String columnName) {
		agClick(FDE_MedraLookUpPageObjects.clickDropDown(label));
		agClick(FDE_MedraLookUpPageObjects.SetdropDownValue(getTestDataCellValue(scenarioName, columnName)));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set meddra lookup details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 26-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_TestNameMedDRALLTCode(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Labdata_Tests_TestNameMedDRALLTCodeLookup").equalsIgnoreCase("Yes")) {
			agClick(FDE_LabDataPageObjects.testNameMedDRALLTCode_Lookup);
			agIsVisible(FDE_MedraLookUpPageObjects.searchTerm_Textfields);
			agSetValue(FDE_MedraLookUpPageObjects.searchTerm_Textfields,
					getTestDataCellValue(scenarioName, "Labdata_Tests_TestNameSearchTerm"));
			// agSetValue(FDE_MedraLookUpPageObjects.dictionaryCode_Textfields,
			// getTestDataCellValue(scenarioName, "Labdata_Tests_TestNameDictionaryCode"));
			// setDropDownValue_MedDRAlookup(FDE_MedraLookUpPageObjects.level_DropDown,
			// scenarioName, "Labdata_Tests_TestNameLevel");
			agClick(FDE_MedraLookUpPageObjects.search_Button);
			agSetStepExecutionDelay("2000");
			CommonOperations.takeScreenShot();
			agClick(FDE_MedraLookUpPageObjects.ok_Button);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to get the length of data in row
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 02-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void getLength(String scenarioName, String columnName, String className) {

		String excelData = getTestDataCellValue(scenarioName, columnName);
		String[] data = excelData.split("::");
		Constants.testDataParentLength = data.length;
		System.out.print("Length::" + data.length);
		// return data.length;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is set Test tab details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 26-Nov-2019
	 * @UpdatedByAndWhen:Avinash k 26-Aug-2020
	 **********************************************************************************************************/
	public static void set_TestsData(String scenarioName) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,
		// "ConfigurationSettings");
		// if (getTestDataCellValue(scenarioName,
		// "FDE_LabData").equalsIgnoreCase("Yes")) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Multimaplibraries.getTestDataCellLength(scenarioName, "Labdata_Tests_TestName");

		for (int j = 1; j <= Constants.testDataParentLength; j++) {
			Constants.testDataChildLoopCount = j;

			if (j > 1) {
				agClick(FDE_LabDataPageObjects.testAdd_Button);
				agSetStepExecutionDelay("5000");
				agIsVisible(FDE_LabDataPageObjects.testName_Textbox);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			}

			if (agIsVisible(FDE_LabDataPageObjects.formView_Btn)) {
				agClick(FDE_LabDataPageObjects.formView_Btn);
			}
			agSetValue(FDE_LabDataPageObjects.testName_Textbox,
					getTestDataCellValue(scenarioName, "Labdata_Tests_TestName"));
			agSendKeyStroke(Keys.TAB);
			if(getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
				CommonOperations.captureScreenShot(true);
			}
			set_TestNameMedDRALLTCode(scenarioName);
			agSetValue(FDE_LabDataPageObjects.testDate_Datesfield,
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Labdata_Tests_TestDate")));
			agSetValue(FDE_LabDataPageObjects.testResultValue_Textbox,
					getTestDataCellValue(scenarioName, "Labdata_Tests_TestResultValue"));
			CommonOperations.setFDEDropDownValue(FDE_LabDataPageObjects.testResultValueUnit_DropDown,
					getTestDataCellValue(scenarioName, "Labdata_Tests_TestResultValueUnit"));
			agSetValue(FDE_LabDataPageObjects.normalValueLow_Textbox,
					getTestDataCellValue(scenarioName, "Labdata_Tests_NormalValueLow"));
			agSetValue(FDE_LabDataPageObjects.normalValueHigh_Textbox,
					getTestDataCellValue(scenarioName, "Labdata_Tests_NormalValueHigh"));
			CommonOperations.setFDEDropDownValue(FDE_LabDataPageObjects.testResultCode_DropDown,
					getTestDataCellValue(scenarioName, "Labdata_Tests_TestResultCode"));
			if (getTestDataCellValue(scenarioName, "Labdata_Tests_RelevantForEventDescription")
					.equalsIgnoreCase("true")) {
				agClick(FDE_LabDataPageObjects.relevantForEventDescription_Checkbox);
			}
			agClick(FDE_LabDataPageObjects.clickmoreInformationAvailable_Radiobtn(
					getTestDataCellValue(scenarioName, "Labdata_Tests_MoreInformationAvailable")));
			// CommonOperations.setFDEDropDownValue(FDE_LabDataPageObjects.codingType_DropDown,
			// getTestDataCellValue(scenarioName, "Labdata_Tests_CodingType"));
			agSetValue(FDE_LabDataPageObjects.resultUnstructuredData_Textarea,
					getTestDataCellValue(scenarioName, "Labdata_Tests_ResultUnstructuredDataFreeText"));
			agSetValue(FDE_LabDataPageObjects.labComments_Textarea,
					getTestDataCellValue(scenarioName, "Labdata_ResultofTests_LabComments"));
			agSetValue(FDE_LabDataPageObjects.relevantLaboratoryTestsOrData_Textarea,
					getTestDataCellValue(scenarioName, "Labdata_ResultofTests_RelevantLaboratoryTestsOrData"));

			Reports.ExtentReportLog("", Status.INFO,
					"~~~~~~~~~~~~~~~~~~~Data entered in Lab Data_00" + j + "~~~~~~~~~~~~~~~~~~", true);
		}
		// }
	}

	/**********************************************************************************************************
	 * @Objective: The below method is Verify Test tab details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 26-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void testsData_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		Multimaplibraries.getTestDataCellLength(scenarioName, "Labdata_Tests_TestName");

		for (int j = 1; j <= Constants.testDataParentLength; j++) {
			Constants.testDataChildLoopCount = j;

			if (j >= 1) {
				if (!agIsVisible(FDE_LabDataPageObjects.clickMultipleLabdata(Integer.toString(j)))) {
					agJavaScriptExecuctorClick(FDE_LabDataPageObjects.forwardNavigaterClick);
				}
				if(scenarioName.contains("MultipleLabData")) {
				agJavaScriptExecuctorClick(FDE_LabDataPageObjects.NextIcon);
				}
				agJavaScriptExecuctorClick(FDE_LabDataPageObjects.clickMultipleLabdata(Integer.toString(j)));

				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

			if (agIsVisible(FDE_LabDataPageObjects.formView_Btn)) {
				agClick(FDE_LabDataPageObjects.formView_Btn);
			}
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Labdata_Tests_TestName"),
					FDE_LabDataPageObjects.testName_Textbox);
			agClick(FDE_LabDataPageObjects.getData_testNameMedDRALLTCode);
			agCheckPropertyValue("title", getTestDataCellValue(scenarioName, "Labdata_Tests_TestNameDictionaryCode"),
					FDE_LabDataPageObjects.getData_testNameMedDRALLTCode);
			agClick(FDE_LabDataPageObjects.getData_TestNameMedDRAPTCode);
			agCheckPropertyValue("title", getTestDataCellValue(scenarioName, "Labdata_Tests_TestNameMedDRAPTCode"),
					FDE_LabDataPageObjects.getData_TestNameMedDRAPTCode);
			agClick(FDE_LabDataPageObjects.testDate_Datesfield);
			agCheckPropertyValue("title",
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Labdata_Tests_TestDate")),
					FDE_LabDataPageObjects.testDate_Datesfield);
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Labdata_Tests_TestResultValue"),
					FDE_LabDataPageObjects.testResultValue_Textbox);
			/*
			 * agCheckPropertyText(getTestDataCellValue(scenarioName,
			 * "Labdata_Tests_TestResultValueUnit"),
			 * FDE_LabDataPageObjects.testResultValueUnit_Getvalue);
			 */
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Labdata_Tests_NormalValueLow"),
					FDE_LabDataPageObjects.normalValueLow_Textbox);
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Labdata_Tests_NormalValueHigh"),
					FDE_LabDataPageObjects.normalValueHigh_Textbox);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Labdata_Tests_TestResultCode"),
					FDE_LabDataPageObjects.testResultCode_Getvalue);
			CommonOperations.verifyCheckBoxUnder("Relevant for Event Description ",
					getTestDataCellValue(scenarioName, "Labdata_Tests_RelevantForEventDescription"));
			CommonOperations.verifyRadioButton("More Information Available? ",
					getTestDataCellValue(scenarioName, "Labdata_Tests_MoreInformationAvailable"));
			// agCheckPropertyText(getTestDataCellValue(scenarioName,
			// "Labdata_Tests_CodingType"),
			// FDE_LabDataPageObjects.codingType_Getvalue);
			agCheckPropertyValue("value",
					getTestDataCellValue(scenarioName, "Labdata_Tests_ResultUnstructuredDataFreeText"),
					FDE_LabDataPageObjects.resultUnstructuredData_Textarea);
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Labdata_ResultofTests_LabComments"),
					FDE_LabDataPageObjects.labComments_Textarea);
			agCheckPropertyValue("value",
					getTestDataCellValue(scenarioName, "Labdata_ResultofTests_RelevantLaboratoryTestsOrData"),
					FDE_LabDataPageObjects.relevantLaboratoryTestsOrData_Textarea);

			Reports.ExtentReportLog("", Status.INFO,
					"~~~~~~~~~~~~~~~~~~~Data verified in Lab Data_00" + j + "~~~~~~~~~~~~~~~~~~", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to select Null Flavour value from dropdown
	 *             based on excel data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 23-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setLabdataNFDropDownValue(String label, String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_LabDataPageObjects.NFLabdataDropdownSelect(label));
			agClick(FDE_GeneralPageObjects.clickDropDownValue(getTestDataCellValue(scenarioName, columnName)));
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to check Null Flavour and selected
	 *             dropdown value based on excel data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 23-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_TestsNullFlavours(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (agIsVisible(FDE_LabDataPageObjects.formView_Btn)) {
			agClick(FDE_LabDataPageObjects.formView_Btn);
		}
		agClick(FDE_LabDataPageObjects.click_NFBtn(FDE_LabDataPageObjects.testdata_dropdown));
		setLabdataNFDropDownValue(FDE_LabDataPageObjects.testdata, scenarioName, "Labdata_Tests_TestDate");

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to set EmbededDropdown value
	 * @InputParameters: label, scenarioName, columnName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 26-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setLabEmbedDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_LabDataPageObjects.labEmdedDropdownSelect(label));
			agClick(FDE_LabDataPageObjects.clickDropDownValue(getTestDataCellValue(scenarioName, columnName)));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Click and set TestResultValue value
	 * @InputParameters: TestName, scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 26-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clcikLabTab(String TestName, String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		if (agIsVisible(FDE_LabDataPageObjects.formView_Btn)) {
			agClick(FDE_LabDataPageObjects.formView_Btn);
		}
		agClick(FDE_LabDataPageObjects.clickLabTab(TestName));
		agSetValue(FDE_LabDataPageObjects.testResultValue_Textbox,
				getTestDataCellValue(scenarioName, "Labdata_Tests_TestResultValue"));
		setLabEmbedDropDownValue(FDE_LabDataPageObjects.testResultValueU_DropDown, scenarioName,
				"Labdata_Tests_TestResultValueUnit");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: Verify R2 tags in LabData tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 20-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyLabDataR2Tags() {
		Reports.ExtentReportLog("", Status.INFO, "********Pregnancy R2 tag verification Started*******", true);
		agAssertVisible(FDE_LabDataPageObjects.R2TestName);
		agAssertVisible(FDE_LabDataPageObjects.R2TestDate);
		agAssertVisible(FDE_LabDataPageObjects.R2TestResultValue);
		agAssertVisible(FDE_LabDataPageObjects.R2TestResultUnit);
		agAssertVisible(FDE_LabDataPageObjects.R2NormalValueLow);
		agAssertVisible(FDE_LabDataPageObjects.R2NormalValueHigh);
		agAssertVisible(FDE_LabDataPageObjects.R2MoreInformationAvailable);
		agAssertVisible(FDE_LabDataPageObjects.R2ResultsOfTests);
		Reports.ExtentReportLog("", Status.INFO, "********Pregnancy R2 tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify R3 tags in LabData tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 20-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyLabDataR3Tags() {
		Reports.ExtentReportLog("", Status.INFO, "********Pregnancy R3 tag verification Started*******", true);
		agAssertVisible(FDE_LabDataPageObjects.R3TestName);
		agAssertVisible(FDE_LabDataPageObjects.R3TestNameMedDRALLTCode);
		agAssertVisible(FDE_LabDataPageObjects.R3Testdata);
		agAssertVisible(FDE_LabDataPageObjects.R3TestResultValue);
		agAssertVisible(FDE_LabDataPageObjects.R3TestResultUnit);
		agAssertVisible(FDE_LabDataPageObjects.R3NormalValueLow);
		agAssertVisible(FDE_LabDataPageObjects.R3NormalValueHigh);
		agAssertVisible(FDE_LabDataPageObjects.R3TestResultCode);
		agAssertVisible(FDE_LabDataPageObjects.R3MoreInformationAvailable);
		agAssertVisible(FDE_LabDataPageObjects.R3ResultUnstructuredDataFreeText);
		agAssertVisible(FDE_LabDataPageObjects.R3LabComments);
		Reports.ExtentReportLog("", Status.INFO, "********Pregnancy R3 tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify Codelist tags in LabData tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 20-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyLabDataCodeList() {
		Reports.ExtentReportLog("", Status.INFO, "********Pregnancy R3 tag verification Started*******", true);
		agAssertVisible(FDE_LabDataPageObjects.CLTestResultUnit);
		agAssertVisible(FDE_LabDataPageObjects.CLTestResultCode);
		agAssertVisible(FDE_LabDataPageObjects.CLRelevantforEventDescription);
		agAssertVisible(FDE_LabDataPageObjects.CLMoreInformationAvailable);
		agAssertVisible(FDE_LabDataPageObjects.CLCodingType);
	}

	/**********************************************************************************************************
	 * @Objective: Verify Codelist tags in LabData tab
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 28-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_LabTestData(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FDE_LabDataPageObjects.testName_Textbox,
				getTestDataCellValue(scenarioName, "Labdata_Tests_TestName"));
		set_TestNameMedDRALLTCode(scenarioName);
		agSetValue(FDE_LabDataPageObjects.testResultValue_Textbox,
				getTestDataCellValue(scenarioName, "Labdata_Tests_TestResultValue"));
		CommonOperations.setFDEDropDownValue(FDE_LabDataPageObjects.testResultValueUnit_DropDown,
				getTestDataCellValue(scenarioName, "Labdata_Tests_TestResultValueUnit"));
		CommonOperations.setFDEDropDownValue(FDE_LabDataPageObjects.testResultCode_DropDown,
				getTestDataCellValue(scenarioName, "Labdata_Tests_TestResultCode"));
		agSetValue(FDE_LabDataPageObjects.resultUnstructuredData_Textarea,
				getTestDataCellValue(scenarioName, "Labdata_Tests_ResultUnstructuredDataFreeText"));
	}

}
