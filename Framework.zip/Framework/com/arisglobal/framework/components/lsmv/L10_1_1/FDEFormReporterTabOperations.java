package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ReporterPageObjects;
import com.arisglobal.framework.lib.main.ToolManager;

public class FDEFormReporterTabOperations {
	
	public static WebElement webElement;
	
	/**********************************************************************************************************
     * Objective:The Below method is created to set data in Reporter tab
     * Input Parameters:
     * Output Parameters:
     * @author:Avinash K
     * Date :12-Jul-2019
     * Updated by and when:
     **********************************************************************************************************/
	
	public static void LSMVSetReporterBasicDetails() {
		
			 ToolManager.agClick(ReporterPageObjects.PrimaryReporterCheckBox);
			 primarySourceRegulatoryPurposesRadiobtn("Yes");
		}
	
	
	
	public static void primarySourceRegulatoryPurposesRadiobtn(String data) {
		switch(data)
		{
		case "Yes":
			ToolManager.agClick(ReporterPageObjects.PrimarySourceRegulatoryRadioButton_Yes);
			break;
		case "No":
			ToolManager.agClick(ReporterPageObjects.PrimarySourceRegulatoryRadioButton_No);
			break;
			
		default:
			System.out.println("Invalid Radio Button");
		
		}
			 
		}
	
	
	
	

}
