package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FDE_StudyPageObjects {

	public static String protocolNo_Lookup = "xpath#//a[@class='agLookupLink']//img";
	public static String click_DropDown = "xpath#//label[@style='visibility: visible;'][contains(text(),'{0}')]/ancestor::span/p-dropdown/div";
	public static String setdropDownValue = "xpath#//ul[contains(@class,'ui-dropdown-items')]/child::li/div/span[contains(text(),'%s')]";
	public static String setData_Textfields = "xpath#//label[@style='visibility: visible;'][contains(text(),'%s')]/ancestor::span/input";
	public static String setData_TextAreafields = "xpath#//label[@style='visibility: visible;'][contains(text(),'%s')]/ancestor::span/textarea";
	public static String setData_Datesfields = "xpath#//label[@style='visibility: visible;'][contains(text(),'%s')]/following-sibling::span/input";
	public static String crossReferencedNo_Textfield = "xpath#//label[contains(text(),'Cross Referenced IND')]/following::span/input";
	public static String add_Delete_Buttons = "xpath#//label[contains(text(),'%s')]/following::span[contains(@class,'agAddDeleteBlock')]/a[contains(text(),'%r')]";
	public static String primaryIND_Textfield = "xpath#//label[contains(text(),'Primary IND')]/following-sibling::input";
	public static String get_DropDownValue = "xpath#//label[@style='visibility: visible;'][contains(text(),'{0}')]/ancestor::span/p-dropdown/div/label/span";
	public static String study_Navigation = "xpath#//div[contains(@class,'agTopBreadCrumbsHeader')]/ul/li/a[contains(text(),'%s')]";
	public static String productradioBtn = "xpath#//label[text()='%s']/ancestor::tr/td/p-tableradiobutton/div/child::div/span";
	public static String copyProduct_Buttons = "xpath#//a[text()='Copy Product(s)']";
	public static String verify_Product = "xpath#//label[text()='%label']/ancestor::table/tbody/tr[%r]/td[%c]";
	public static String confirmationPopup = "xpath#//p-confirmdialog//div//i/following-sibling::span";
	public static String yesButton_PopupWindow = "xpath#//button/span/following-sibling::span[text()='Yes']";
	public static String noButton_PopupWindow = "xpath#//button/span/following-sibling::span[text()='No']";
	public static String studyProduct_Label = "xpath#//p-header/label[contains(text(),'Study Product(s)')]";
	public static String registrationNo_TextField = "xpath#//input[@id='adverseEventNew:studyPanelTable:studyRegistrationList:0:registrationNumner:0']";
	public static String get_Product = "xpath#//label[text()='PRODUCT NAME']/following::tbody/tr[%s]/td/label";
	public static String get_ProtocolNo = "xpath#//label[@style='visibility: visible;'][contains(text(),'Sponsor Study No')]/ancestor::span/input";
	public static String get_RegistrationCountry = "xpath#//input[@id='adverseEventNew:studyPanelTable:studyRegistrationList:0:registrationcountry-1_focus:0']/ancestor::div[@class='ui-helper-hidden-accessible']/following-sibling::label/span";
	public static String click_RegCountryDropDown = "xpath#//input[@id='adverseEventNew:studyPanelTable:studyRegistrationList:0:registrationcountry-1_focus:0']/ancestor::div[@class='ui-helper-hidden-accessible']/following-sibling::label";
	public static String caseCodeBrokenOn_Datefield = "xpath#//input[@id='adverseEventNew:studyPanelTable:studyInfoTable:dateCodeBroken-125016_input']";
	public static String popUp_Message = "xpath#//span[@class='ui-confirmdialog-message']";

	// public static String studyConfirmationPopUp_Message =
	// "xpath#//div[@class='ui-dialog-content
	// ui-widget-content']/span[@class='ui-confirmdialog-message']";
	public static String studyConfirmationPopUp_Message = "xpath#//div[@class='ui-dialog-content ui-widget-content']//span[@class='ui-confirmdialog-message']";

	public static String studyConfirmationPopUpYes_Btn = "xpath#//span[contains(@class,'ui-button-text ui-clickable') and text()= 'Yes']";
	// public static String studyConfirmationPopUpYes_Btn =
	// "xpath#//span[contains(@class,'ui-button-text ui-clickable') and text()=
	// 'OK']";

	public static String productcopyPopupWindow = "xpath#//div[@class='ui-dialog-content ui-widget-content']/label[text()='Study Product Copied Successfully']";
	public static String productcopyPopupWindow_Okbutton = "xpath#//label[text()='Study Product Copied Successfully']/following-sibling::div/button/span";

	// labels Names
	public static String studyType_DropDown = "Study Type";
	public static String studyPhase_DropDown = "Study Phase";
	public static String studyDesign_DropDown = "Study Design";
	public static String caseCodeBroken_DropDown = "Case Code Broken";
	public static String studyCodeBroken_DropDown = "Study Code Broken";
	public static String registrationCountry_DropDown = "Registration Country";
	public static String queryContact_DropDown = "Query Contact";
	public static String studyCompletionStatus_DropDown = "Study completion status";
	public static String studyDiscontinueReason_DropDown = "Study discontinue reason";

	public static String protocolNo_Lookupfield = "Protocol No";

	public static String protocolNo_Textbox = "Protocol No";
	public static String studyName_Textbox = "xpath#//label[text()='Study Name']/following-sibling::input[contains(@id,'adverseEventNew:studyPanelTable:studyInfoTable:idN10DAB125001')]";
	public static String projectNo_Textbox = "Project No";
	public static String enrollmentStatus_Textbox = "Enrollment Status";
	public static String eudraCTNumber_Textbox = "EudraCT Number";
	public static String randomizationNumber_Textbox = "Randomization Number";
	public static String centerNumber_Textbox = "Center Number";
	public static String subjectID_Textbox = "Subject ID";
	public static String investigatorNumber_Textbox = "Investigator Number";
	public static String primaryIND_Textbox = "Primary IND";
	public static String studyAcronym_Textbox = "Study Acronym";
	public static String enrollmentDate_Datefield = "Enrollment Date";
	public static String withdrawnDate_Datefield = "Withdrawn Date";
	public static String protocolDetails_TextArea = "Protocol Details";	
	public static String PANDA_TxtField = "PANDA#";

	public static String IIS_CheckBox = "IIS";
	public static String EUCTRegulation_CheckBox = "EU CT Regulation 2019";

	public static String addButton = "Add";
	public static String crossRef_Label = "Cross Referenced IND(s)";
	public static String studyReg_label = "Study Registration";

	public static String studyProduct_tab = "Study Product(s)";
	public static String productName_Column = "Product Name";
	public static String tradeName_Column = "Trade/Brand Name";
	public static String studyProuctType_Column = "STUDY PRODUCT TYPE";
	public static String approvalNo_column = "APPROVAL/AUTHORIZATION NO";
	public static String approvalType_Column = "APPROVAL TYPE";
	public static String authorizationcountry_column = "Authorization Country";

	// Study Registration
	public static String registrationNumber_Textbox = "xpath#//input[contains(@id, 'registrationNumner:%rowNo%')]";
	public static String registrationCountry_Dropdown = "xpath#//select[contains(@name, 'registrationcountry-1_focus:%rowNo%')]";

	// Cross Referenced IND(s)
	public static String crossReferencedIND_Textbox = "xpath#//input[contains(@id, 'A1-125614_focus:%rowNo%')]";
	public static String studyConfirmationPopUpOK_Btn = "xpath#//div[@class='searchOkbtn']/button/span[text()='OK']";

	//R2 tags
	public static String R2SponsorStudyNo = "xpath#//label[text()='[A.2.3.2]']";
	public static String R2StudyType = "xpath#//label[text()='[A.2.3.3]']";
	public static String R2StudyName = "xpath#//label[text()='Study Name']//parent::span/label[text()='[A.2.3.1]']";
	public static String R2CrossRefStudyName = "xpath#//label[text()='Study Name']//parent::th/label[text()='[A.2.3.1]']";
	public static String R2Title = "xpath#//label[text()='[A.2.1.1a]']";
	public static String R2FirstName = "xpath#//label[text()='[A.2.1.1b]']";
	public static String R2MiddleName = "xpath#//label[text()='[A.2.1.1c]']";
	public static String R2LastName  = "xpath#//label[text()='[A.2.1.1d]']";
	public static String R2Hospital_OrganizationName = "xpath#//label[text()='[A.2.1.2a]']";
	public static String R2Department = "xpath#//label[text()='[A.2.1.2b]']";
	public static String R2Street = "xpath#//label[text()='[A.2.1.2c]']";
	public static String R2City = "xpath#//label[text()='[A.2.1.2d]']";
	public static String R2State = "xpath#//label[text()='State']//parent::span/label[text()='[A.2.1.2e]']";
	public static String R2PostalCode = "xpath#//label[text()='[A.2.1.2f]']";
	public static String R2Country = "xpath#//label[text()='[A.2.1.3]']";
	public static String R2EmailId = "xpath#//label[text()='[A.2.1.3.FDA.4]']";
	public static String R2SpanishState = "xpath#//label[text()='Spanish State']//parent::span/label[text()='[A.2.1.2e]']";
	public static String R2Qualification = "xpath#//label[text()='[A.2.1.4]']";

	//R3 Tags
	public static String R3SponsorStudyNo = "xpath#//label[text()='[C.5.3]']";
	public static String R3StudyType = "xpath#//label[text()='[C.5.4]']";
	public static String R3StudyPhase = "xpath#//label[text()='[J.12.i.2/J2.13.r.3]']";
	public static String R3StudyName = "xpath#//label[text()='[C.5.2]']";
	public static String R3PrimaryIND = "xpath#//label[text()='[FDA.C.5.5a]']";
	public static String R3Panda = "xpath#//label[text()='[FDA.C.5.5b]']";
	public static String R3RegistrationNumber = "xpath#//label[text()='[C.5.1.r.1]']";
	public static String R3RegistrationCountry = "xpath#//label[text()='[C.5.1.r.2]']";
	public static String R3CrossReferencedIND = "xpath#//label[text()='[FDA.C.5.r.6]']";
	public static String R3Title ="xpath#//label[text()='[C.2.r.1.1]']";
	public static String R3FirstName = "xpath#//label[text()='[C.2.r.1.2]']";
	public static String R3MiddleName = "xpath#//label[text()='[C.2.r.1.3]']";
	public static String R3LastName = "xpath#//label[text()='[C.2.r.1.4]']";
	public static String R3Hospital_OrganizationName = "xpath#//label[text()='[C.2.r.2.1]']";
	public static String R3Department = "xpath#//label[text()='[C.2.r.2.2]']";
	public static String R3Street = "xpath#//label[text()='[C.2.r.2.3]']";
	public static String R3City = "xpath#//label[text()='[C.2.r.2.4]']";
	public static String R3State = "xpath#//label[text()='State']//parent::span/label[text()='[C.2.r.2.5]']";
	public static String R3PostalCode = "xpath#//label[text()='[C.2.r.2.6]']";
	public static String R3Country = "xpath#//label[text()='[C.2.r.3]']";
	public static String R3Telephone = "xpath#//label[text()='[C.2.r.2.7]']";
	public static String R3EmailID = "xpath#//label[text()='[FDA.C.2.r.2.8]']";
	public static String R3SpanishState = "xpath#//label[text()='Spanish State']//parent::span/label[text()='[C.2.r.2.5]']";
	public static String R3Qualification = "xpath#//label[text()='[C.2.r.4]']";

	//codelist
	public static String CLStudyType = "xpath#//label[text()='[1004]']";
	public static String CLStudyPhase = "xpath#//label[text()='[133]']";
	public static String CLStudyDesign = "xpath#//label[text()='[132]']";
	public static String CLBlindingTechnique = "xpath#//label[text()='[134]']";
	public static String CLCaseCodeBroken = "xpath#//label[text()='Case Code Broken']//parent::span/label[text()='[54]']";
	public static String CLStudyCodeBroken = "xpath#//label[text()='Study Code Broken']//parent::span/label[text()='[54]']";
	public static String CLStudyCompletionStatus = "xpath#//label[text()='[53]']";
	public static String CLStudyDiscontinueReason = "xpath#//label[text()='[112]']";
	public static String CLEUCTRegulation2019 = "xpath#//label[text()='EU CT Regulation 2019']//parent::span/label[text()='[4]']";
	public static String CLRegistrationCountry = "xpath#//label[text()='Registration Country']//parent::th/label[text()='[1015]']";
	public static String CLTitle = "xpath#//label[text()='[5014]']";
	public static String CLCountry = "xpath#//label[text()='Country']//parent::span/label[text()='[1015]']";
	public static String CLSpanishState = "xpath#//label[text()='Spanish State']//parent::span/label[text()='[8147]']";
	public static String CLSpecialization = "xpath#//label[text()='[345]']";
	public static String CLQualification = "xpath#//label[text()='[1003]']";
	public static String CLHealthProfessional = "xpath#//label[text()='[1002]']";
	public static String CLOccupation = "xpath#//label[text()='[1028]']";
	public static String CLReporterInformedAuthorityDirectly = "xpath#//label[text()='[1008]']";


	/**********************************************************************************************************
	 * Objective:The below method is created to set data in text field by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String study_Navigation(String runTimeLabel) {
		String value = study_Navigation;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to navigation in study tab by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String setData_Textfields(String runTimeLabel) {
		String value = setData_Textfields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to navigation in study tab by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Sanchit Date :22-Nov-2019 Updated by and when
	 **********************************************************************************************************/
	public static String setData_TextAreafields(String runTimeLabel) {
		String value = setData_TextAreafields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to set data in date field by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String setData_Datesfields(String runTimeLabel) {
		String value = setData_Datesfields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click drop down by passing label
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String get_DropDownValue(String label) {
		String value = get_DropDownValue.replace("{0}", label);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to get drop down by passing label name
	 * at runtime. Input Parameters: ColumnName Scenario Name Output Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String clickDroprdown(String label) {
		String value = click_DropDown.replace("{0}", label);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to verify study product by passing row
	 * number at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String verify_ProductData(String runTimeLabel, String Rownum, String ColNum) {
		String value = verify_Product.replace("%label", runTimeLabel);
		value = value.replace("%r", Rownum);
		value = value.replace("%c", ColNum);
		return value;
	}

	// Click Drop down value
	public static String setdropDownValue(String data) {
		String value = setdropDownValue.replace("%s", data);
		return value;
	}

	// Set Cross Referenced IND#
	public static String crossReferencedNo(String data) {
		String value = crossReferencedNo_Textfield.replace("%s", data);
		return value;
	}
	// Add and delete button

	public static String add_Delete_Buttons(String runTimeLabel, String valueRuntime) {
		String value = add_Delete_Buttons.replace("%s", runTimeLabel);
		value = value.replace("%r", valueRuntime);
		return value;
	}

	// Click check box
	public static String selectProduct(String data) {
		String value = productradioBtn.replace("%s", data);
		return value;
	}

	// Get product data
	public static String get_Product(String runTimeLabel) {
		String value = get_Product.replace("%r", runTimeLabel);
		return value;
	}

	public static String productsList = "xpath#//label[text()='Study Product(s)']/parent::p-header/parent::div/following-sibling::div//table//tbody/tr";
	public static String productRecord = "xpath#//label[text()='Study Product(s)']/parent::p-header/parent::div/following-sibling::div//table//tbody/tr[%num]/td/p-tableradiobutton/div";
	// Get product data
	public static String selectProductRecord(String prodNum) {
		String value = productRecord.replace("%num", prodNum);
		return value;
	}

}
