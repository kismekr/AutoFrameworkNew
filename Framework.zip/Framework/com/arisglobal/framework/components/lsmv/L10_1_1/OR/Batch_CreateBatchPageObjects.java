package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class Batch_CreateBatchPageObjects {
	
	public static String batchPrintingNewBreadScrum = "xpath#//div/label[text()='New']";
	
	//Header Components
	public static String pageTitle = "xpath#//div[@class='panel-title']/label[text()='Batch Print']";
	public static String saveButton = "xpath#//button[@id='batchPrintDetails:visibleSave']/span[text()='Save']";
	public static String cancelButton = "xpath#//button[@id='batchPrintDetails:cancelId']/span[text()='Cancel']";
	
	//Form Fields components
	public static String batchName_TextField = "xpath#//div/input[@id='batchPrintDetails:batchNameId']";
	public static String batchConfigurationName_DropDown = "xpath#//div/label[@id='batchPrintDetails:batchprinterId_label']";
	
	//Config Value selection
	public static String batchConfigurationName_DropDownValue = "xpath#//div[@class='ui-selectonemenu-items-wrapper']/ul/li[text()='{%s}']";
	
	public static String printerName = "xpath#//div/label[@id='batchPrintDetails:batchprinterId2_label']";
	public static String printType_PDF_RadioBtn = "xpath#//label[text()='PDF']";
	public static String printType_PaperF_RadioBtn = "xpath#//label[text()='Paper']";
	public static String noOfCopies_TextField = "xpath#//div/input[@id='batchPrintDetails:noOfCopiesId']";
	public static String moduleType_DropDown = "xpath#//div[@id='batchPrintDetails:moduleTypeId']";
	
	//PrintBY selection
	public static String printBy_RadioBtn = 	"xpath#//div[contains(@class,'ui-radiobutton')]/following::label[text()='{%s}']";
	public static String printBy_DateRange_RadioBtn = 	"Date Range";
	public static String DateRange_RadioBtn_circle = 	"xpath#//div/input[@value='date']";
	
	public static String printBy_AERRange_RadioBtn = 	"AER No. range";
	public static String AERRange_RadioBtn_circle = 	"xpath#//div/input[@value='rcpt_no_range']";
	
	public static String printBy_UploadFile_RadioBtn = 	"Upload File";
	public static String UploadFile_RadioBtn_circle = 	"xpath#//div/input[@value='uploadedFile']";
	
	public static String printBy_CSV_AERs_RadioBtn = 	"Comma separated AER No.s";
	public static String CSV_AERs_RadioBtn_circle = 	"xpath#//div/input[@value='aer_nos']";
	
	public static String printBy_SavedSearch_RadioBtn = "Saved Searches ";
	public static String SavedSearch_RadioBtn_circle = 	"xpath#//div/input[@value='savedsearchcriteria']";
	
	public static String description_TextArea = 		"xpath#//div/textarea[@id='batchPrintDetails:description']";
	
	public static String keyAERRangeFrom_TextField = 	"xpath#//div/label[text()='AER No.(From)']/following::input[@id='batchPrintDetails:caseRecordIdFrom']";
	public static String keyAERRangeTo_TextField = 		"xpath#//div/label[text()='AER No.(From)']/following::input[@id='batchPrintDetails:caseRecordIdTo']";
	
	public static String dateRange_FromDate = "xpath#//span/input[@id='batchPrintDetails:batchPrintStartDate_input']";
	
	//Time sliders
	public static String dateRange_Hour 	= "xpath#//div/dl/dd[@class='ui_tpicker_hour']/div/span";
	public static String dateRange_Minute 	= "xpath#//div/dl/dd[@class='ui_tpicker_minute']/div/span";
	public static String dateRange_Second 	= "xpath#//div/dl/dd[@class='ui_tpicker_second']/div/span";
	
	public static String dateRange_ToDate = "xpath#//span/input[@id='batchPrintDetails:batchPrintEndDate_input']";
		
	public static String AER_nos_TextField = "xpath#//div/textarea[@id='batchPrintDetails:caseRecordIds']";
	public static String upload_Btn = "xpath#//span/input[@id='batchPrintDetails:j_id_px_input']";
	public static String upload_TextArea = "xpath#//div/textarea[@id='batchPrintDetails:caseRecordIdsFromFile']";
	public static String savedSearchCriteria_DropDown = "xpath#//div/label[@id='batchPrintDetails:searchCriteriaId_label']";
	public static String savedSearchCriteria_SearchBox = "xpath#//div[@class='ui-selectonemenu-filter-container']/input[@id='batchPrintDetails:searchCriteriaId_filter']";
	public static String savedSearchCriteria_Value = "xpath#//li[contains(@id,'batchPrintDetails:searchCriteriaId')][text()='{%s}']";
	
	public static String reportType_Draft_RadioBtn = "xpath#//div[@class='ui-radiobutton ui-widget']/following::label[text()='Draft']";
	public static String reportType_Final_RadioBtn = "xpath#//div[@class='ui-radiobutton ui-widget']/following::label[text()='Final']";	
	public static String dataPrivacy_UnMasked_RadioBtn = "xpath#//div[@class='ui-radiobutton ui-widget']/following::label[text()='UnMasked']";
	public static String dataPrivacy_Masked_RadioBtn = "xpath#//div[@class='ui-radiobutton ui-widget']/following::label[text()='Masked']";	
	public static String bindingType_Blinded_RadioBtn = "xpath#//div[@class='ui-radiobutton ui-widget']/following::label[text()='Blinded']";
	public static String bindingType_UnBlinded_RadioBtn = "xpath#//div[@class='ui-radiobutton ui-widget']/following::label[text()='Unblinded']";
	
	public static String report_CIOMS_CheckBox = "xpath#//div[@class='ui-radiobutton ui-widget']/following::label[text()='CIOMS']";
	public static String report_MedWatch_CheckBox = "xpath#//div[@class='ui-radiobutton ui-widget']/following::label[text()='MedWatch']";
	public static String report_SourceE2BXMLs_CheckBox = "xpath#//div[@class='ui-radiobutton ui-widget']/following::label[text()='Source E2B Xmls']";
	public static String report_IncludeAllVers_CheckBox = "xpath#//div[@class='ui-radiobutton ui-widget']/following::label[text()='Include All Versions']";
	public static String report_IncludeAttachments_CheckBox = "xpath#//div[@class='ui-radiobutton ui-widget']/following::label[text()='Include Attachments']";
	public static String report_FOIA_CheckBox = "xpath#//div[@class='ui-radiobutton ui-widget']/following::label[text()='FOIA-Compliant']";
	public static String report_IncludeCoverPage_CheckBox = "xpath#//div[@class='ui-radiobutton ui-widget']/following::label[text()='Include Cover Page']";
	
	public static String schedule_CheckBox = "Schedule";
	public static String scheduleType_dropdown = "xpath#//div/label[@id='batchPrintDetails:schedularDropDown_label']";
	public static String scheduleType_dropDown_Search = "xpath#//div/input[@name='batchPrintDetails:schedularDropDown_filter']";
	
	public static String scheduleType_option = "xpath#//div/ul/li[text()='{%s}']";
	
	public static String schedule_OneTime_dateFiled = "xpath#//div/span[@id='batchPrintDetails:dateTimeId']/input[@id='batchPrintDetails:dateTimeId_input']";
	public static String schedule_HourBar = "xpath#//div[contains(@class,'hour_slider')]/span[contains(@class,'slider-handle')]";
	public static String schedule_MinuteBar = "xpath#//div[contains(@class,'minute_slider')]/span[contains(@class,'slider-handle')]";
	
	public static String hourSliderTarget = "xpath#//div[contains(@class,'hour_slider')]/span[contains(@class,'slider-handle')][@style='left: {%s}%;']";
	public static String minuteSliderTarget = "xpath#//div[contains(@class,'minute_slider')]/span[contains(@class,'slider-handle')][@style='left: {%s}%;']";
	//0% - 0th hour/minute, 4.34783%-1Hr, 8.69565%-2Hrs, 39.1304-9Hrs, 52.1739-12Hrs, 60.8696-14Hrs
	
	public static String months_DropDown = "xpath#//div[@class='ui-selectcheckboxmenu-trigger ui-state-default ui-corner-right']";
	public static String monthsValueSelector = "xpath#//div[@class='ui-chkbox ui-widget']/following::label[text()='{%s}']";
	
	public static String quarterCheckBoxes = "xpath#//input[contains(@id,'quarterId')]/following::label[contains(text(),'{%s}')]";
	
	public static String daysLabel = "xpath#//div/label[contains(text(),'Days')]";
	public static String daysCheckBoxes = "xpath#//input[contains(@id,'batchPrintDetails')]/following::label[contains(text(),'{%s}')]";
	
	//Save Confirmation pop-up
	public static String saveConfirmWinTitle = "xpath#//div/span[text()='Batch Print Save Confirmation']";
	public static String saveConfirmWin_Text = "xpath#//table[@class='confirmMsgSty']//td[2]/label";
	public static String saveConfirmWin_Yes = "xpath#//div/button[@id='batchPrintDetails:listiID']";
	public static String saveConfirmWin_No = "xpath#////div/button[@id='batchPrintDetails:j_id_sn']";
	
	//On Submission, acknowledgement pop-up window components
	public static String ackwindowTitle = "xpath#//div/span[@id='mandatoryDialogform:mandatoryID_title']";
	public static String ackwindowErrorTitleText = "xpath#//div/span[text()='Action Completed with Validation Error(s)']";
	
	
	
	
	/**********************************************************************************************************
	 * @Objective: To Select the Config Value
	 * @InputParameters: To be set by referring to Test Data sheet
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 15-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectConfigValue(String configVal) {	
		String value1 = batchConfigurationName_DropDownValue;
		String value2 = value1.replace("{%s}", configVal);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: To Select the Print By Radio button
	 * @InputParameters: To be set by referring to Test Data sheet
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 15-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectPrintByRadioBtn(String printByVal) {	
		String value1 = printBy_RadioBtn;
		String value2 = value1.replace("{%s}", printByVal);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: To drag the Hour slider to desired position
	 * @InputParameters: 0% - 0th hour/minute, 4.34783%-1Hr, 8.69565%-2Hrs, 39.1304-9Hrs, 52.1739-12Hrs, 60.8696-14Hrs
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 02-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String slideToSelectHour(String positionInPercent) {	
		String value1 = hourSliderTarget;
		String value2 = value1.replace("{%s}", positionInPercent);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: To drag the Hour slider to desired position
	 * @InputParameters: 0% - 0th minute, 1.69492%-1min, 3.38983%-2mins, 5.08475%-3mins, 8.47458%-5mins, 16.9492%-10mins
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 02-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String slideToSelectMinute(String positionInPercent) {		
		String value1 = minuteSliderTarget;
		String value2 = value1.replace("{%s}", positionInPercent);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: To select the month value
	 * @InputParameters: January, February, March, April, May, June, July, August, September, October, November, December
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 02-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String checkMonth (String monthVal) {		
		String value1 = monthsValueSelector;
		String value2 = value1.replace("{%s}", monthVal);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: To select a desired quarter check box
	 * @InputParameters: Q1, Q2, Q3 and Q4
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 02-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String checkQuarter (String quarterVal) {
		//permissible values = Q1, Q2, Q3 and Q4
		String value1 = quarterCheckBoxes;
		String value2 = value1.replace("{%s}", quarterVal);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: To select a desired days check box
	 * @InputParameters: Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 02-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String checkDays (String daysVal) {
		String value1 = daysCheckBoxes;
		String value2 = value1.replace("{%s}", daysVal);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: To select a desired option from schdule dropdown
	 * @InputParameters: One Time, Daily, Weekly, Monthly, Quarterly
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 18-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectScheduleOption(String daysVal) {
		String value1 = scheduleType_option;
		String value2 = value1.replace("{%s}", daysVal);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: To select a desired option from Saved Search dropdown
	 * @InputParameters: One Time, Daily, Weekly, Monthly, Quarterly
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 14-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectSavedSearchOption(String savedName) {
		String value1 = savedSearchCriteria_Value;
		String value2 = value1.replace("{%s}", savedName);
		return value2;
	}
}
