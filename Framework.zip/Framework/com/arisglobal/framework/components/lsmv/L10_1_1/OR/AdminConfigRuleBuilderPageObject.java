package com.arisglobal.framework.components.lsmv.L10_1_1.OR;
import java.lang.reflect.Field;

/**********************************************************************************************************
	 * @Objective:The below method is created to verify activity log data by passing data at runtime.
	 * @author: MP Ramkumar 
	 * Date :05-Mar-2020 
	 * Updated by:
	 * When and Reason:   	 
	**********************************************************************************************************/
  
public class AdminConfigRuleBuilderPageObject {

	public static String ruleBuilderListformRuleType  = "xpath#//div[@id='ruleBuilderListform:rulesDataTable']//span[@id='ruleBuilderListform:rulesDataTable:0:ruleType']";
	public static String ruleBuilderListformEditIcon = "xpath#//a[@id='ruleBuilderListform:rulesDataTable:0:editDeptId']//img[@id='ruleBuilderListform:rulesDataTable:0:editImgId']";
	public static String ruleBuilderListformCancelbtn = "xpath#//a[@id='ruleBuilderListform:cancelList' and @title='Cancel']";
	public static String keywordSearchTextbox = "xpath#//input[contains(@id,':keyword')]"; ////input[@id='partnerForm:keyword']";
	public static String searckeywordSearchIcon = "xpath#//div[@class='searchBlack']/a[@id='ruleBuilderListform:searchId']";
//	public static String searckeywordSearchIcon = "xpath#//img[@id='ruleBuilderListform:j_id_od']";
	public static String alertRulesSearchEdit = "xpath#//a[@id='ruleBuilderListform:rulesDataTable:0:editDeptId']";
		
	//Rule Objects
	public static String ruleDetailsruleName = "xpath#//input[@id='ruleDetailsForm:ruleName']";
	public static String ruleDetailsCancelbtn = "xpath#//button[@id='ruleDetailsForm:cancelId']";
	public static String ruleDetailsSavebtn = "xpath#//button[@id='ruleDetailsForm:visibleSave']";
	
	//	public static String 
	

	//Objects for rule Builder edition
	public static String ruleTableSpan(int row) {
		return "xpath#//div[@id='ruleBuilderListform:rulesDataTable']//table//tbody/tr[" + Integer.toString(row) + "]//span[contains(@id,'ruleType')]";
	}
	public static String ruleTableNameSpan(int row) {
		return "xpath#//div[@id='ruleBuilderListform:rulesDataTable']//table//tbody/tr[" + Integer.toString(row) + "]//span[contains(@id,'rulenameId')]";
	}
	public static String ruleTableLink(int row) {
		return "xpath#//div[@id='ruleBuilderListform:rulesDataTable']//table//tbody/tr[" + Integer.toString(row) + "]//a";
	}
	public static String ruleTableRows = "xpath#//div[@id='ruleBuilderListform:rulesDataTable']//table//tbody/tr";
	
	
	public static String eMailIDs_custom = "xpath#//input[@id='ruleDetailsForm:emailIds']";
//	public static String desc_textarea = "xpath#//textarea[@id='ruleDetailsForm:ruleDescription']";
	public static String subject_textarea = "xpath#//textarea[@id='templateNewForm:templateheadertab:subjectId']";
	public static String emailBody = "xpath#//body";
	
	//Generalization of objects
	public static String CommonInput = "xpath#//label[text()='{0}']/following-sibling::input";
	public static String CommonTextArea = "xpath#//label[text()='{0}']/following-sibling::textarea";
	public static String CommonDropdown = "xpath#//label[text()='{0}']/ancestor::div/div[contains(@class,'selectonemenu')]//label";
//	public static String CommonRadio = "xpath#//label[text()='{0}']/ancestor::div/div[contains(@class,'selectonemenu')]//label";
	
	//String of objects
	public static String module = "Module";
	public static String fdeForm = "FULL DATA ENTRY FORM";
	public static String formName = "Form Name";
	public static String templateType = "Template Type";
	public static String templateFormat = "Template Format";
	public static String ruleName = "Rule Name";
	public static String desc = "Description";
	public static String dispE2BR2Tag = "Display E2B R2 Tag";
	public static String dispE2BR3Tag = "Display E2B R3 Tag";
	public static String bizAlrtTemplates = "Business Alert Templates";
	public static String mailServer = "Mail Server";
	public static String doNotRegenRuleScrpt = "Do Not Regenerate Rule Script";
	public static String alwaysExecute = "Always Execute";
	public static String stdRule = "Standard Rule";
	public static String active = "Active";
	public static String contact = "Contact";
	public static String dept = "Department";
	public static String reporter = "Reporter";
	public static String mailDistList = "Mail Distribution List";
	public static String sendAlertOnCopyOrSplit = "Send alert on Copy or Split";
	public static String caseSummSheet = "Case Summary Sheet";
	public static String medWatchReport = "MedWatch Report";
	public static String supportingDoc = "Supporting Document";
	public static String sourceDoc = "Source Document";
	public static String e2BXml = "E2B XML";
	public static String invAssgnTo = "Investigation assigned to";
	public static String irtDispFailAlert = "IRT dispose failure alert";
	
	public static String formLibrary = "Form Library";
	public static String fldLibrary = "Field Library";
	public static String methodLibrary = "Method Library";
	
	
	public static String templateID = "Template ID";
	public static String templateName = "Template Name";
	public static String templateExpiryDate = "Template Expiry Date";
	public static String tempType = "Template Type";
	public static String tempFormat = "Template Format";
	public static String globalTemp = "Global Template";
	public static String asgnAllProds = "Assign All Products";
	public static String asgnAllCompUnits = "Assign All Company Units";
	
	public static String selectDroprdown(String label) {
        String value = CommonDropdown.replace("{0}", label);
        return value;
    }
 
	 public static String setInput(String label) {
	        String value = CommonInput.replace("{0}", label);
	        return value;
	    }
	 public static String setTextArea(String label) {
	        String value = CommonTextArea.replace("{0}", label);
	        return value;
	    }
	
	 
	 public String getFields(Object obj, String locatorName) throws Exception {
			String name = null;
			String xpathValue = null;
			Object value = null;
	
			Class<?> objClass = obj.getClass();
			Field[] fields = objClass.getFields();
			for (Field field : fields) {
				name = field.getName();
				if (name.equals(locatorName)) {
					value = field.get(obj);
					xpathValue = value.toString();
					break;
				}
	
			}
			return xpathValue;
		}

}
