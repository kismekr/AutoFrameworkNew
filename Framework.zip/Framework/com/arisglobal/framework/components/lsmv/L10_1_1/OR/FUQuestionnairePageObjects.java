package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class FUQuestionnairePageObjects {
	public static String correspondence = "xpath#//span[@class='lsmv-communication-info']";
	public static String followupRCTlink = "xpath#(//tbody//tr/td[1]/span[@class='lsmv-ques-split'])[%s]";
	public static String followupQuestionnarie_Label = "xpath//span[@id='aeQuestionaryForm:DialogId_title']";
	public static String addQuestiondropdown = "xpath#//label[@id='aeQuestionaryForm:questionnaireContexts_label']";
	public static String addbtn = "xpath#//a[@id='aeQuestionaryForm:contextAdd']";
	public static String questionslookup = "xpath#//a[contains(@id,'questionaryLookup')]/img[contains(@src,'Lookup_Selection')]";
	public static String questionnarieslookup_label = "xpath#//span[text()='Questi	onnaires Lookup']";
	public static String questionselectfilter = "xpath#(//thead[@id='QuestionaryLookupForm:questionTableSingle_head']//th[@aria-label='%s']/span/following::input)[1]";
	public static String questionId = "Question Id";
	public static String questionName = "Question Name";
	public static String field = "Field";
	public static String context = "Context";
	public static String formName = "Form Name";

	public static String questionOkbtn = "xpath#//button[contains(@id,'QuestionaryLookupForm:okBtn')]/span[text()='OK']";
	public static String questionSubmitbtn = "xpath#//button[@id='aeQuestionaryForm:questionSubmitDialog']/span[text()='Submit']";
	public static String status = "xpath#//table[contains(@id,'aeQuestionaryForm')]//label[text()='Not Sent To Reporter']";
	public static String followupsubmittedicon = "xpath#//img[contains(@src,'quesSubmitIcon')]";
	public static String subject = "xpath#//div[@fieldid='subject']/following::span[contains(@onclick,'viewCorrespondence')]/strong";
	public static String subjectVerification = "xpath#(//div[@fieldid='subject']/following::span[contains(@onclick,'viewCorrespondence')]/strong)[2]";
	public static String followupQuestionnarieIcon = "xpath#//span[@title='Followup Questionnaire']";
	public static String loading = "xpath#//div[@class='mask-message-div'][text()='Loading...']";
	public static String followupqueries_hdr = "xpath#//span[@id='questionnariesWindowHeader']";
	public static String selectMode = "xpath#//Select[@id='quesModeCombo']";
	public static String correspondenceTo = "xpath#//textarea[@id='correspondenceToTextArea']";
	public static String selectpriority = "xpath#//select[@id='correspondencePrioritySelect']";
	public static String selectstatus = "xpath#//select[@id='correspondenceStatusSelect']";
	public static String selectCategory = "xpath#//select[@id='correspondenceCategorySelect']";
	public static String selectQueryStatus = "xpath#//select[@id='queryStatus']";
	public static String remindertemplate = "xpath#//span[@id='addReminderTemplate']";
	public static String selecttemplate = "xpath#//span[@id='selectTempQues']";
	public static String templatelookUP = "xpath#//span[text()='Template Lookup']";
	public static String searchtemplate = "xpath#//input[contains(@title,'TEMPLATE NAME')]";

	public static String selectReminderIntervalUnit = "xpath#//select[@id='reminderIntervalUnitSelect']";
	public static String noOfReminders = "xpath#//input[@id='noOfReminders']";
	public static String reminderInterval = "xpath#//input[@id='reminderInterval']";
	public static String question_Radiobtn = "xpath#(//tbody[contains(@id,'QuestionaryLookupForm:questionTableSingle_data')]/tr/td/div/following::div/span)[1]";
	public static String clickRadiobtn_checkbox = "xpath#//input[@id='%label%']";
	public static String overRideReminder = "overrideReimnder";
	public static String turnOffReminder = "xpath#turnOffReminder";
	public static String sendBtn = "xpath#//button[@labelcode='correspondence_send']";
	public static String sendEmailPopUp = "xpath#//div[@class='lsmv-info-popup']";

	public static String getQuestion = "xpath#//label[contains(@id,'aeQuestionaryForm:uiRepeatId')][contains(text(),'%question%')]";
	public static String querieslabel = "xpath#//label[text()='%s']";
	public static String pdfdocument_Radiobtn = "queryFmt1";
	public static String webLink_Radiobtn = "queryFmt0";
	public static String queryformatPopUPOkBtn = "xpath#//button[contains(@onclick,'okConfirmFU')][text()='Ok']";
	public static String queryformatPopUP = "xpath#//span[text()='Email Data updated Successfully']";
	public static String followUPWebLink = "xpath#//body[@style='margin:4px; font:10pt Arial,Verdana; cursor:text']/a[text()='FollowUpWebLink']";
	public static String getListofbr = "xpath#//body[@style='margin:4px; font:10pt Arial,Verdana; cursor:text']/br";
	public static String columnHeader = "xpath#(//body[@style='margin:4px; font:10pt Arial,Verdana; cursor:text']/br)[{%count}]";
	// public static String getListofbrText = "xpath#//body[@style='margin:4px;
	// font:10pt Arial,Verdana; cursor:text']/text()[preceding-sibling::br and
	// following-sibling::br]";
	// public static String getListofbrText = "(//body[@style='margin:4px; font:10pt
	// Arial,Verdana; cursor:text']/br/following-sibling::text())[4]";
	// public static String columnHeader = "//body[@style='margin:4px; font:10pt
	// Arial,Verdana; cursor:text']/br[preceding-sibling::br and
	// following-sibling::br][{%count}]";

	public static String messagelabel = "xpath#//span[text()='Message']";
	public static String iFrame = "xpath#//iframe[@frameborder='0']";
	public static String closeIcon = "xpath#(//div[contains(@id,'aeQuestionaryForm:DialogId')]//a[@aria-label='Close'])[1]";

	public static String followupSubmitted_Icon = "xpath#(//span[@title='Followup has been Submited'])[1]";
	public static String getQuestionNames = "xpath#//tbody[contains(@id,'aeQuestionaryForm:uiRepeatId')]/tr/td[@class='OutcomeQuesFirTd']";
	public static String getListofQuestionNames = "xpath#(//tbody[contains(@id,'aeQuestionaryForm:uiRepeatId')]/tr/td[@class='OutcomeQuesFirTd'])[%count%]";

	// Login to Passcode
	public static String passcodeTextbox = "xpath#//input[@id='qPasscode']";
	public static String submitPasscodeBtn = "xpath#//button[@id='submitPassCode']";
	public static String lifeSphereLogo = "xpath#//div[@class='queLogo']";
	public static String followUPRCTNoLabel = "xpath#//span[@id='aeQuestionaryForm:DialogId_title']";

	// FUQWL
	public static String FUQWLPasscode = "xpath#//input[@id='qPasscode']";
	public static String FUQWLSubmittbutton = "xpath#//button[text()='Submit']";
	public static String FUQWLUserComments = "xpath#//textarea[@id='defaultCommentsDataContent']";
	public static String FUQWLFileUpload = "xpath#//span[@id='fileUploadBtn']";
	public static String FUQWLFileName = "xpath#//span[text()='%fileName']";
	public static String FUQWLSubmittButton = "xpath#//button[@id='qtnAccept']";
	public static String FUQWLSubmissionConfirmation = "xpath#//span[contains(text(),'Your form has been submitted successfully.')]";

	/**********************************************************************************************************
	 * Objective:The below method is created to select Followup Questionnarie
	 * generated Input Parameters: index Scenario Name Output Parameters:
	 * 
	 * @author:Pooja S Date :07-May-2020 Updated by and when
	 **********************************************************************************************************/

	public static String selectFollowpRctlink(String index) {
		String value = followupRCTlink;
		String value2;
		value2 = value.replace("%s", index);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select Followup Questions by context
	 * Input Parameters: text Scenario Name Output Parameters:
	 * 
	 * @author:Pooja S Date :07-May-2020 Updated by and when
	 **********************************************************************************************************/

	public static String selectQuestionsContext(String text) {
		String value = addQuestiondropdown;
		String value2;
		value2 = value.replace("%s", text);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to filter the questions Input
	 * Parameters: id Scenario Name Output Parameters:
	 * 
	 * @author:Pooja S Date :07-May-2020 Updated by and when
	 **********************************************************************************************************/

	public static String setquesbyfilter(String id) {
		String value = questionselectfilter;
		String value2;
		value2 = value.replace("%label%", id);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to check the checkbox for Override
	 * Reminder and Turn Off Reminder Input Parameters: text Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Pooja S Date :14-May-2020 Updated by and when
	 **********************************************************************************************************/

	public static String clickRadiobtn_Checkbox(String text) {
		String value = clickRadiobtn_checkbox;
		String value2;
		value2 = value.replace("%s", text);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to get the question names based on div
	 * count and index Input Parameters: text Scenario Name Output Parameters:
	 * 
	 * @author:Pooja S Date :14-May-2020 Updated by and when
	 **********************************************************************************************************/

	public static String getQuestion(String ques) {
		String value = getQuestion;
		String value2;
		value2 = value.replace("%question%", ques);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:get Passcode by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:Pooja S Date :08-May-2020 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderList(String num) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:get Passcode by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:Pooja S Date :08-May-2020 Updated by and when
	 **********************************************************************************************************/
	public static String subjectList(String num) {
		String value = subject;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:get Question name by passing input Parameters:rowNum Output
	 * @Parameters:
	 * @author:Pooja S Date :26-June-2020 Updated by and when
	 **********************************************************************************************************/
	public static String questionCountList(String num) {
		String value = getListofQuestionNames;
		String value2;
		value2 = value.replace("%count%", num);
		return value2;
	}

}
