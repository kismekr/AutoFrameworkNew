package com.arisglobal.framework.components.lsmv.L10_1_1;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.LibrariesAEkeywordsPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.lsmvConfig.lsmvConstants;

public class Libraries_AEkeywords extends ToolManager {
	static String className = Libraries_AEkeywords.class.getSimpleName();
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to set AE Keywords Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 5-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setAEkeywordsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(LibrariesAEkeywordsPageObjects.aeKeywordsTextArea);
		agSetValue(LibrariesAEkeywordsPageObjects.aeKeywordsTextArea, getTestDataCellValue(scenarioName, "AE Keywords"));
		CommonOperations.clickCheckBoxRightOf(LibrariesAEkeywordsPageObjects.activeCheckBoxLabel, getTestDataCellValue(scenarioName, "Active"));
		
		CommonOperations.takeScreenShot();
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify AE Keywords Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 5-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyAEkeywordsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "AE Keywords"), LibrariesAEkeywordsPageObjects.aeKeywordsTextArea);
		CommonOperations.verifyCheckBoxRightOf(LibrariesAEkeywordsPageObjects.activeCheckBoxLabel,  getTestDataCellValue(scenarioName, "Active"));
		
		CommonOperations.takeScreenShot();
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to add or update AE Keywords Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 5-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addAEkeywords(String scenarioName) {
		setAEkeywordsDetails(scenarioName);
		agClick(LibrariesAEkeywordsPageObjects.saveButton);
	}
}
