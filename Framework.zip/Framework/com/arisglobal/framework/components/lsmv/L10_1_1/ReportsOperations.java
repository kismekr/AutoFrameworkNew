package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDELookupsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ReportsPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class ReportsOperations extends ToolManager {
	public static WebElement webElement;
	static String className = ReportsOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	static String[] skipData={"#skip#"};

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in Reports
	 *             Module
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void menuNavigation(String menu) {

		switch (menu) {

		case "batchPrintListing":
			agMouseHover(ReportsPageObjects.reportsHover);
			agMouseHover(ReportsPageObjects.batchPrintHover);
			agClick(ReportsPageObjects.batchPrintListing);
			break;

		case "batchPrintConfigurations":
			agMouseHover(ReportsPageObjects.reportsHover);
			agMouseHover(ReportsPageObjects.batchPrintHover);
			agClick(ReportsPageObjects.batchPrintConfigurations);
			break;

		case "CIOMSLLReport":
			agMouseHover(ReportsPageObjects.reportsHover);
			agClick(ReportsPageObjects.cIOMSLLREPORT);
			break;

		case "dataExport":
			agMouseHover(ReportsPageObjects.reportsHover);
			agClick(ReportsPageObjects.dataExport);
			break;

		case "charts":
			agMouseHover(ReportsPageObjects.reportsHover);
			agClick(ReportsPageObjects.charts);
			break;

		case "standardReports":
			agMouseHover(ReportsPageObjects.reportsHover);
			agClick(ReportsPageObjects.standardReports);
			break;

		case "standard":
			agMouseHover(ReportsPageObjects.reportsHover);
			agMouseHover(ReportsPageObjects.StandardHover);
			agClick(ReportsPageObjects.StandardAuditTrail);
			break;

		case "standardAdmin":
			agMouseHover(ReportsPageObjects.reportsHover);
			agMouseHover(ReportsPageObjects.StandardHover);
			agJavaScriptExecuctorClick(ReportsPageObjects.StandardAdminAuditTrail);

			break;

		case "caseManagement":
			agMouseHover(ReportsPageObjects.reportsHover);
			agClick(ReportsPageObjects.caseManagement);
			break;

		case "addressLabels":
			agMouseHover(ReportsPageObjects.reportsHover);
			agClick(ReportsPageObjects.addresslables);
			break;

		case "productSalvageReports":
			agMouseHover(ReportsPageObjects.reportsHover);
			agClick(ReportsPageObjects.productSalvageReports);
			break;

		case "workflowMetricsReports":
			agMouseHover(ReportsPageObjects.reportsHover);
			agMouseHover(ReportsPageObjects.operationalReports);
			agClick(ReportsPageObjects.workflowMetricsReport);
			break;

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in reports
	 *             Module and verify the label name.
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void reportsNavigations(String menu) {
		switch (menu) {
		case "batchPrintListing":
			menuNavigation("batchPrintListing");
			status = agIsVisible(ReportsPageObjects.batchPrintKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to batch Print Listing is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to batch Print Listing is Unsuccessfull", true);
			}
			break;
		case "batchPrintConfigurations":
			menuNavigation("batchPrintConfigurations");
			status = agIsVisible(ReportsPageObjects.batchPrintConfigKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to batch Print Configurations is successfull",
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to batch Print Configurations is Unsuccessfull",
						true);
			}
			break;
		case "CIOMSLLReport":
			menuNavigation("CIOMSLLReport");
			status = agIsVisible(ReportsPageObjects.ciomsLLReportsKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to CIOMS LL Report is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to CIOMS LL Report is Unsuccessfull", true);
			}
			break;
		case "dataExport":
			menuNavigation("dataExport");
			status = agIsVisible(ReportsPageObjects.dataExportKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to data Export is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to data Export is Unsuccessfull", true);
			}
			break;
		case "charts":
			menuNavigation("charts");
			status = agIsVisible(ReportsPageObjects.chartsKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to charts is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to charts is Unsuccessfull", true);
			}
			break;
		case "standardReports":
			menuNavigation("standardReports");
			status = agIsVisible(ReportsPageObjects.standardReportsKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to standard Reports is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to standard Reports is Unsuccessfull", true);
			}
			break;
		case "standard":
			menuNavigation("standard");
			status = agIsVisible(ReportsPageObjects.AuditTrailVerification);
			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "Navigation to Standard Audit Trail is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to batch Print Listing is Unsuccessfull", true);
			}
			break;

		case "standardAdmin":
			menuNavigation("standardAdmin");
			status = agIsVisible(ReportsPageObjects.SectionType);
			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "Navigation to Standard Audit Trail is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to batch Print Listing is Unsuccessfull", true);
			}
			break;
		case "caseManagement":
			menuNavigation("caseManagement");
			status = agIsVisible(ReportsPageObjects.caseManagementRecptNo);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to case Management is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to case Management is Unsuccessfull", true);
			}
			break;
		case "addressLabels":
			menuNavigation("addressLabels");
			status = agIsVisible(ReportsPageObjects.addressLabelsReceviDate);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to address Labels is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to address Labels is Unsuccessfull", true);
			}
			break;
		case "productSalvageReports":
			menuNavigation("productSalvageReports");
			status = agIsVisible(ReportsPageObjects.productSalvageCompLatesDate);

			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to product Salvage Reports is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to product Salvage Reports is Unsuccessfull",
						true);
			}
			break;
		case "workflowMetricsReports":
			menuNavigation("workflowMetricsReports");
			status = agIsVisible(ReportsPageObjects.workflowMetricsReportLable);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to workflow Metrics Reports is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to workflow Metrics Reports is Unsuccessfull",
						true);
			}
			break;
		default:
			System.out.println("Invalid Menu Link!");
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to set the audit trial and generate
	 *             the report
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 04-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setAuditTrial(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		CommonOperations.setListDropDownValue(ReportsPageObjects.msgTypeDropdown,
				getTestDataCellValue(scenarioName, "MessageTypeDropDown"));
		agSetValue(ReportsPageObjects.auditTrialBetweenFrom,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "AuditTrialBetweenFrom")));
		agSetValue(ReportsPageObjects.auditTrialBetweenTo,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "AuditTrialBetweenTo")));
		agSetValue(ReportsPageObjects.userName, getTestDataCellValue(scenarioName, "UserName"));
		CommonOperations.takeScreenShot();
		agClick(ReportsPageObjects.auditTrialGenerateReportButton);
		agIsVisible(ReportsPageObjects.downloadAsExcelBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to downlaod the excel
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 04-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downloadAsExcel(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String filename = Multimaplibraries.getTestDataCellValue(scenarioName, "ExcelFileName");
		agClick(ReportsPageObjects.downloadAsExcelBtn);
		if (agIsVisible(ReportsPageObjects.norecords) == true) {
			Reports.ExtentReportLog("", Status.INFO, "No Data to export", true);
			agJavaScriptExecuctorClick(ReportsPageObjects.okBtn);
		} else {
			CommonOperations.takeScreenShot();
			agSetStepExecutionDelay("15000");
			CommonOperations.move_Downloadedexcel(filename);
			Reports.ExtentReportLog("", Status.INFO, "Excel downloaded successfully", true);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set save and update audit info in
	 *             LSMV application.
	 * @InputParameters: testData
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 04-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void handelAuditInfo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "CommonOperations");
		agSetStepExecutionDelay("3000");
		boolean returnAudit = agIsVisible(ReportsPageObjects.auditInfo_Label);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (returnAudit == true) {
			agClick(ReportsPageObjects.clickAuditReason_dropdwn);
			agJavaScriptExecuctorClick(ReportsPageObjects.clickAuditReason_dropdwn);
			agJavaScriptExecuctorClick(
					CommonPageObjects.setAuditreasonDropdrown(getTestDataCellValue(scenarioName, "ReasonCode")));
			agSetValue(ReportsPageObjects.auditreason_Textarea, getTestDataCellValue(scenarioName, "Reason"));
			CommonOperations.takeScreenShot();
			agClick(CommonPageObjects.submit_Btn);
			agSetStepExecutionDelay("3000");
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Audit reason popup is not displayed", false);
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below Method is created to generate report to get
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Padmapriya
	 * @Date : 12-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void reconciliation_GenerateReport(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "Reconciliation_GenerateReport");
		agSetStepExecutionDelay("3000");
		agClick(ReportsPageObjects.reconciliation);
		// if (!getTestDataCellValue(scenarioName,
		// "SourceMedium").equalsIgnoreCase("#skip#")) {
		agClick(ReportsPageObjects.sourceMediumDropdown);
		agClick(ReportsPageObjects.selectSource(getTestDataCellValue(scenarioName, "SourceMedium")));
//		}
		agClick(ReportsPageObjects.processingDateFrom);
	    agSelectByVisibleText(ReportsPageObjects.selectMonth, getTestDataCellValue(scenarioName, "Month"));
		agClick(ReportsPageObjects.selectDay(getTestDataCellValue(scenarioName, "ProcessingDateFrom")));
		agClick(ReportsPageObjects.selectDay(getTestDataCellValue(scenarioName, "ProcessingDateTo")));
		String[] ColumnName = {"SourceMedium", "ProcessingDateFrom", "ProcessingDateTo"};
		String[] ColumnTitles = {"Source","Processing_DateFrom", "Processing_DateTo"};
		CommonOperations.ALMlogWriter(className, scenarioName, ColumnName, ColumnTitles, skipData);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(ReportsPageObjects.generateReportBtn);
	}
	
	
	/**********************************************************************************************************
	 * @Objective: The below Method will get the Receipt No from Generate report
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Padmapriya
	 * @Date : 27-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getRCTNumber(String scenarioName) {
		
		String Data=getTestDataCellValue(scenarioName, "EmailSubject");
		String rctText=agGetText(ReportsPageObjects.getReceiptNo(Data));
		while(!agIsVisible(ReportsPageObjects.getReceiptNo(Data))){
		 rctText = agGetText(ReportsPageObjects.getReceiptNo(Data));
		 
		 agClick(ReportsPageObjects.BackButton);
		 agClick(ReportsPageObjects.generateReportBtn);
		}
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "Reconciliation_GenerateReport", scenarioName ,"ReceiptNo",
				rctText);
		
		System.out.println(rctText);
		return rctText;
	}

	public static void selectProcessingFrom(String date) {
		agClick(ReportsPageObjects.processingDateFrom);
		agClick(ReportsPageObjects.selectDay(date));
	}

	public static void selectProcessingTo(String date) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "Reconciliation_GenerateReport");
		// agClick(ReportsPageObjects.processingDateTo);
		agClick(ReportsPageObjects.selectDay(date));
	}

}