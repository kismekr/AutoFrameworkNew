package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_ParentPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_ProductsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.Product_LookupPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_Parent extends ToolManager {
	public static WebElement webElement;
	static String className = FDE_Parent.class.getSimpleName();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 25-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_ParentPageObjects.click_DropDown(label));
			agClick(FDE_ParentPageObjects.clickdropDownValue(getTestDataCellValue(scenarioName, columnName)));

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 25-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setEmbededDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_ParentPageObjects.click_EmbededDropDown(label));
			agClick(FDE_ParentPageObjects.clickdropDownValue(getTestDataCellValue(scenarioName, columnName)));

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set embedDropdown value
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setParentEmbedDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_ParentPageObjects.productEmdedDropdownSelect(label));
			agClick(FDE_ParentPageObjects.clickDropDownValue(getTestDataCellValue(scenarioName, columnName)));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Parent Information in FDE
	 *             Parent Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 25-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setParentInformation(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FDE_ParentPageObjects.parentID_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentInformation_ParentID"));
		
		if(getTestDataCellValue(scenarioName, "CustomDateFlag").equalsIgnoreCase("YES")) {
			agSetValue(FDE_ParentPageObjects.parentDOB_Datefield, 
					getTestDataCellValue(scenarioName, "Parent_ParentInformation_ParentDOB"));
		}else {
			agSetValue(FDE_ParentPageObjects.parentDOB_Datefield, CommonOperations
					.returnDateTime(getTestDataCellValue(scenarioName, "Parent_ParentInformation_ParentDOB")));
		}
		if(getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}
		agSetValue(FDE_ParentPageObjects.parentAge_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentInformation_ParentAge"));
		setDropDownValue(FDE_ParentPageObjects.parentAge_DropDown, scenarioName,
				"Parent_ParentInformation_ParentAgeUnit");
		setDropDownValue(FDE_ParentPageObjects.parentGender_DropDown, scenarioName,
				"Parent_ParentInformation_ParentGender");
		agSetValue(FDE_ParentPageObjects.lmpofParent_Datefield, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Parent_ParentInformation_LMPOfParent")));
		agSetValue(FDE_ParentPageObjects.parentWeight_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentInformation_ParentWeight"));
		setDropDownValue(FDE_ParentPageObjects.parentWeight_DropDown, scenarioName,
				"Parent_ParentInformation_ParentWeightUnit");
		agSetValue(FDE_ParentPageObjects.parentHeight_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentInformation_ParentHeight"));
		setDropDownValue(FDE_ParentPageObjects.parentHeight_DropDown, scenarioName,
				"Parent_ParentInformation_ParentHeightUnit");
		setDropDownValue(FDE_ParentPageObjects.ethnicOrigin_DropDown, scenarioName,
				"Parent_ParentInformation_EthnicOrigin");
		agSetValue(FDE_ParentPageObjects.parentMedicalHistorytext_Textarea,
				getTestDataCellValue(scenarioName, "Parent_ParentInformation_ParentMedicalHistoryText"));
		Reports.ExtentReportLog("", Status.INFO,
				"Data entered in Parent Information section: Scenario Name::" + scenarioName, true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in text field value
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyData(String object, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(object);
			agCheckPropertyValue("title", getTestDataCellValue(scenarioName, columnName), object);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Parent Information in FDE
	 *             Parent Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 25-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyParentInformation(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		verifyData(FDE_ParentPageObjects.parentID_Textfield, scenarioName, "Parent_ParentInformation_ParentID");
		agClick(FDE_ParentPageObjects.parentDOB_Datefield);
		agCheckPropertyValue("title",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Parent_ParentInformation_ParentDOB")),
				FDE_ParentPageObjects.parentDOB_Datefield);
		verifyData(FDE_ParentPageObjects.parentAge_Textfield, scenarioName, "Parent_ParentInformation_ParentAge");
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Parent_ParentInformation_ParentAgeUnit"),
				FDE_ParentPageObjects.parentAgeUnit_Getvalue);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Parent_ParentInformation_ParentGender"),
				FDE_ParentPageObjects.parentGender_Getvalue);
		agClick(FDE_ParentPageObjects.lmpofParent_Datefield);
		agCheckPropertyValue("title",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Parent_ParentInformation_LMPOfParent")),
				FDE_ParentPageObjects.lmpofParent_Datefield);
		verifyData(FDE_ParentPageObjects.parentWeight_Textfield, scenarioName, "Parent_ParentInformation_ParentWeight");
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Parent_ParentInformation_ParentWeightUnit"),
				FDE_ParentPageObjects.parentWeightUnit_Getvalue);
		verifyData(FDE_ParentPageObjects.parentHeight_Textfield, scenarioName, "Parent_ParentInformation_ParentHeight");
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Parent_ParentInformation_ParentHeightUnit"),
				FDE_ParentPageObjects.parentHeightUnit_Getvalue);
		// verifyData(FDE_ParentPageObjects.ethnicOrigin_Textfield,scenarioName,
		// "Parent_ParentInformation_EthnicOrigin");
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Parent_ParentInformation_EthnicOrigin"),
				FDE_ParentPageObjects.ethnicOrigin_Getvalue);
		agClick(FDE_ParentPageObjects.parentMedicalHistorytext_Textarea);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Parent_ParentInformation_ParentMedicalHistoryText"),
				FDE_ParentPageObjects.parentMedicalHistorytext_Textarea);

		Reports.ExtentReportLog("", Status.INFO,
				"Data verification in Parent Information section: Scenario Name::" + scenarioName, true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Parent Medical History in FDE
	 *             Parent Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 25-Nov-2019
	 * @UpdatedByAndWhen:Mithun M P
	 **********************************************************************************************************/
	public static void setParentMedicalHistory(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (agIsVisible(FDE_ParentPageObjects.pmh_FormView)) {
			agClick(FDE_ParentPageObjects.pmh_FormView);
		}
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorScrollToElement(FDE_ParentPageObjects.parentMedicalHistory_Label);
		agSetValue(FDE_ParentPageObjects.reportedDiseaseTerm_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentMedicalHistory_ReportedDiseaseTermParent"));
		agSendKeyStroke(Keys.TAB);
		if(getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (getTestDataCellValue(scenarioName, "Parent_ParentMedicalHistory_MedDRADisTermParent_Lookup")
				.equalsIgnoreCase("Yes")) {
			agClick(FDE_ParentPageObjects.medDRALLTCODEDiseaseTerm_lookup);
			agSetValue(FDE_ParentPageObjects.dictionaryCodingBrowser_SearchTxtfield,
					getTestDataCellValue(scenarioName, "Parent_ParentMedicalHistory_MedCODErDisTerm_SearchTerm"));
			agClick(FDE_ParentPageObjects.dictionaryCodingBrowser_SearchBtn);
			agSetStepExecutionDelay("2000");
			agClick(FDE_ParentPageObjects.dictionaryCodingBrowser_OkBtn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}

		agSetValue(FDE_ParentPageObjects.startDate_Datefield, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Parent_ParentMedicalHistory_StartDate")));
		agSetValue(FDE_ParentPageObjects.endDate_Datefield, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Parent_ParentMedicalHistory_EndDate")));
		agClick(FDE_ParentPageObjects.clickContinuing_RadioBtn(
				getTestDataCellValue(scenarioName, "Parent_ParentMedicalHistory_Continuing")));
		agSetValue(FDE_ParentPageObjects.comments_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentMedicalHistory_Comments"));
		agSetValue(FDE_ParentPageObjects.duration_Txtfield,
				getTestDataCellValue(scenarioName, "Parent_ParentMedicalHistory_Duration"));
		setEmbededDropDownValue(FDE_ParentPageObjects.duration_DropDown, scenarioName,
				"Parent_ParentMedicalHistory_DurationUnit");
		// setEmbededDropDownValue(FDE_ParentPageObjects.codingType_DropDown,
		// scenarioName, "Parent_ParentMedicalHistory_CodingType");
		Reports.ExtentReportLog("", Status.INFO,
				"Data entered in Parent Medical History section: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Parent Medical History in
	 *             FDE Parent Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 25-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyParentMedicalHistory(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (agIsVisible(FDE_ParentPageObjects.pmh_FormView)) {
			agClick(FDE_ParentPageObjects.pmh_FormView);
		}
		verifyData(FDE_ParentPageObjects.reportedDiseaseTerm_Textfield, scenarioName,
				"Parent_ParentMedicalHistory_ReportedDiseaseTermParent");
		verifyData(FDE_ParentPageObjects.medDRALLTCODEForDiseaseTerm, scenarioName,
				"Parent_ParentMedicalHistory_MedDRADisTermParent");
		agCheckPropertyText(
				getTestDataCellValue(scenarioName, "Parent_ParentMedicalHistory_MedCODErDisTerm_SearchTerm"),
				FDE_ParentPageObjects.get_medDRALLTCODEDiseaseTerm);
		verifyData(FDE_ParentPageObjects.medDRAPTCODEDiseaseTerm_Txtfield, scenarioName,
				"Parent_ParentMedicalHistory_MedDRAPTCODEForDiseaseTermParent");
		agClick(FDE_ParentPageObjects.startDate_Datefield);
		agCheckPropertyValue("title",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Parent_ParentMedicalHistory_StartDate")),
				FDE_ParentPageObjects.startDate_Datefield);
		agClick(FDE_ParentPageObjects.endDate_Datefield);
		agCheckPropertyValue("title",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Parent_ParentMedicalHistory_EndDate")),
				FDE_ParentPageObjects.endDate_Datefield);
		agClick(FDE_ParentPageObjects.comments_Textfield);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Parent_ParentMedicalHistory_Comments"),
				FDE_ParentPageObjects.comments_Textfield);
		verifyData(FDE_ParentPageObjects.duration_Txtfield, scenarioName, "Parent_ParentMedicalHistory_Duration");
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Parent_ParentMedicalHistory_DurationUnit"),
				FDE_ParentPageObjects.durationUnit_Getvalue);
		// agCheckPropertyText(getTestDataCellValue(scenarioName,
		// "Parent_ParentMedicalHistory_CodingType"),
		// FDE_ParentPageObjects.codingTypeUnit_Getvalue);
		Reports.ExtentReportLog("", Status.INFO,
				"Data verification in Parent Medical History section: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Parent Past Therapy in FDE
	 *             Parent Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 25-Nov-2019
	 * @UpdatedByAndWhen: Mithun M P
	 **********************************************************************************************************/
	public static void setParentPastTherapy(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (agIsVisible(FDE_ParentPageObjects.ppt_FormView)) {
			agClick(FDE_ParentPageObjects.ppt_FormView);
		}

		agSetStepExecutionDelay("2000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		if (getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_ProductDescriptionAsReported_Lookup")
				.equalsIgnoreCase("Yes")) {
			agClick(FDE_ParentPageObjects.productDescriptionAsReported_Lookup);
			agIsVisible(FDE_ParentPageObjects.productNameTextbox);
			if(! scenarioName.contains("FDA")) {
			agSetValue(FDE_ParentPageObjects.productNameTextbox,
					getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_ProdDescAsReported_ProdName"));
			}
			else
				agSetValue(Product_LookupPageObjects.FDAProdName, getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_ProdDescAsReported_ProdName"));
			agClick(FDE_ParentPageObjects.searchButton);
			// agClick(FDE_ParentPageObjects.select_Product(getTestDataCellValue(scenarioName,
			// "Parent_ParentPastTherapy_ProdDescAsReported_ProdName")));
			agClick(FDE_ProductsPageObjects.checkFirstProdInProdLib);
			agClick(FDE_ParentPageObjects.okButton);
		}
		agSetValue(FDE_ParentPageObjects.medicinalProductIdentifierMPID_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_MedicinalProductIdentifierMPID"));
		agSetValue(FDE_ParentPageObjects.mPIDVersionDateNumber_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_MPIDVersionDateNumber"));
		agSetValue(FDE_ParentPageObjects.phPID_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_PhPID"));
		agSetValue(FDE_ParentPageObjects.phPIDVersionDateNumber_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_PhPIDVersionDateNumber"));
		agSetValue(FDE_ParentPageObjects.therapyStartDate_datefield, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_StartDate")));
		agSetValue(FDE_ParentPageObjects.therapyEndDate_datefield, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_EndDate")));
		agClick(FDE_ParentPageObjects.indicationTerm_Textfield);
		agSetValue(FDE_ParentPageObjects.indicationTerm_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_IndicationTerm"));
		agSendKeyStroke(Keys.TAB);
		if (getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_MedDForIndiTermParent_Lookup")
				.equalsIgnoreCase("Yes")) {
			agClick(FDE_ParentPageObjects.medDRALLTCODEIndicationTerm_Lookup);
			agIsVisible(FDE_ParentPageObjects.dictionaryCodingBrowser_SearchTxtfield);
			agSetValue(FDE_ParentPageObjects.dictionaryCodingBrowser_SearchTxtfield,
					getTestDataCellValue(scenarioName, "Parent_PastTherapy_MedDRALLTCODEIndiTerm_SearchTerm"));
			agClick(FDE_ParentPageObjects.dictionaryCodingBrowser_SearchBtn);
			agSetStepExecutionDelay("2000");
			agClick(FDE_ParentPageObjects.dictionaryCodingBrowser_OkBtn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		agSetValue(FDE_ParentPageObjects.reactionTerm_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_ReactionTerm"));
		agSendKeyStroke(Keys.TAB);
		if(getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}
		if (getTestDataCellValue(scenarioName, "Parent_PastTherapy_MedDRALLTCODEForReactionTerm_Lookup")
				.equalsIgnoreCase("Yes")) {
			agClick(FDE_ParentPageObjects.medDRALLTCODEReactionTerm_Lookup);
			agIsVisible(FDE_ParentPageObjects.dictionaryCodingBrowser_SearchTxtfield);
			agSetValue(FDE_ParentPageObjects.dictionaryCodingBrowser_SearchTxtfield,
					getTestDataCellValue(scenarioName, "Parent_PastTherapy_MedDRALLTCODEForReactionTerm_SearchTerm"));
			agClick(FDE_ParentPageObjects.dictionaryCodingBrowser_SearchBtn);
			agSetStepExecutionDelay("2000");
			agClick(FDE_ParentPageObjects.dictionaryCodingBrowser_OkBtn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		agSetValue(FDE_ParentPageObjects.inventedName_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_InventedName"));
		agSetValue(FDE_ParentPageObjects.scientificName_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_ScientificName"));
		agSetValue(FDE_ParentPageObjects.trademarkName_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_TrademarkName"));
		agSetValue(FDE_ParentPageObjects.strengthName_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_StrengthName"));
		agSetValue(FDE_ParentPageObjects.formName_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_FormName"));
		agSetValue(FDE_ParentPageObjects.containerName_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_ContainerName"));
		agSetValue(FDE_ParentPageObjects.deviceName_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_DeviceName"));
		agSetValue(FDE_ParentPageObjects.intendedUseName_Textfield,
				getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_IntendedUseName"));
		Reports.ExtentReportLog("", Status.INFO,
				"Data entered in Parent Past Therapy details section: Scenario Name::" + scenarioName, true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Parent Past Therapy details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 26-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyParentPastTherapy(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (agIsVisible(FDE_ParentPageObjects.ppt_FormView)) {
			agClick(FDE_ParentPageObjects.ppt_FormView);
		}

		if (getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_ProductDescriptionAsReported_Lookup")
				.equalsIgnoreCase("Yes")) {

			verifyData(FDE_ParentPageObjects.productDescriptionAsReported_Getvalue, scenarioName,
					"Parent_ParentPastTherapy_ProdDescAsReported_ProdName");
		}
		verifyData(FDE_ParentPageObjects.medicinalProductIdentifierMPID_Textfield, scenarioName,
				"Parent_ParentPastTherapy_MedicinalProductIdentifierMPID");
		verifyData(FDE_ParentPageObjects.mPIDVersionDateNumber_Textfield, scenarioName,
				"Parent_ParentPastTherapy_MPIDVersionDateNumber");
		verifyData(FDE_ParentPageObjects.phPID_Textfield, scenarioName, "Parent_ParentPastTherapy_PhPID");
		verifyData(FDE_ParentPageObjects.phPIDVersionDateNumber_Textfield, scenarioName,
				"Parent_ParentPastTherapy_PhPIDVersionDateNumber");
		agClick(FDE_ParentPageObjects.therapyStartDate_datefield);
		agCheckPropertyValue("title",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_StartDate")),
				FDE_ParentPageObjects.therapyStartDate_datefield);
		agClick(FDE_ParentPageObjects.therapyEndDate_datefield);
		agCheckPropertyValue("title",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Parent_ParentPastTherapy_EndDate")),
				FDE_ParentPageObjects.therapyEndDate_datefield);
		agJavaScriptExecuctorScrollToElement(FDE_ParentPageObjects.therapyStartDate_datefield);
		verifyData(FDE_ParentPageObjects.indicationTerm_Textfield, scenarioName,
				"Parent_ParentPastTherapy_IndicationTerm");
		agCheckPropertyText(
				getTestDataCellValue(scenarioName, "Parent_ParentMedicalHistory_MedCODErDisTerm_SearchTerm"),
				FDE_ParentPageObjects.get_MedDRALLTCODEIndicationTerm);
		verifyData(FDE_ParentPageObjects.medDRALLTCODEIndicationTerm_Textfield, scenarioName,
				"Parent_ParentPastTherapy_MedDForIndiTermParent");
		verifyData(FDE_ParentPageObjects.medDRAPTCODEIndicationTerm_Textfield, scenarioName,
				"Parent_ParentPastTherapy_MedDRAPTCODEForIndicationTermParent");
		verifyData(FDE_ParentPageObjects.reactionTerm_Textfield, scenarioName, "Parent_ParentPastTherapy_ReactionTerm");
		agCheckPropertyText(
				getTestDataCellValue(scenarioName, "Parent_PastTherapy_MedDRALLTCODEForReactionTerm_SearchTerm"),
				FDE_ParentPageObjects.get_MedDRALLTCODEReactionTerm);
		verifyData(FDE_ParentPageObjects.medDRAPTCODEForReactionTerm_Textfield, scenarioName,
				"Parent_ParentPastTherapy_MedDRAPTCODEForReactionTermParent");
		verifyData(FDE_ParentPageObjects.medDRALLTCODEForReactionTerm_Textfield, scenarioName,
				"Parent_ParentPastTherapy_MedDRALLTCODEForReactionTermParent");
		verifyData(FDE_ParentPageObjects.inventedName_Textfield, scenarioName, "Parent_ParentPastTherapy_InventedName");
		verifyData(FDE_ParentPageObjects.scientificName_Textfield, scenarioName,
				"Parent_ParentPastTherapy_ScientificName");
		verifyData(FDE_ParentPageObjects.trademarkName_Textfield, scenarioName,
				"Parent_ParentPastTherapy_TrademarkName");
		verifyData(FDE_ParentPageObjects.strengthName_Textfield, scenarioName, "Parent_ParentPastTherapy_StrengthName");
		verifyData(FDE_ParentPageObjects.formName_Textfield, scenarioName, "Parent_ParentPastTherapy_FormName");
		verifyData(FDE_ParentPageObjects.containerName_Textfield, scenarioName,
				"Parent_ParentPastTherapy_ContainerName");
		verifyData(FDE_ParentPageObjects.deviceName_Textfield, scenarioName, "Parent_ParentPastTherapy_DeviceName");
		verifyData(FDE_ParentPageObjects.intendedUseName_Textfield, scenarioName,
				"Parent_ParentPastTherapy_IntendedUseName");
		Reports.ExtentReportLog("", Status.INFO,
				"Data verification in Parent Past Therapy details section: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Past Therapy Substances
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 26-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setPastTherapySubstances(String scenarioName) {
		agSetValue(FDE_ParentPageObjects.substanceSpecifiedSubstanceName_Textfield,
				getTestDataCellValue(scenarioName, "Parent_PastTherapySubstances1_SubstanceSpecifiedSubName"));
		agSetValue(FDE_ParentPageObjects.substanceTermIDVerDateNum_Textfield,
				getTestDataCellValue(scenarioName, "Parent_PastTherapySubstances1_SubstanceTermIDVerDateNum"));
		agSetValue(FDE_ParentPageObjects.substanceSpecifiedSubstanceTermID_Textfield,
				getTestDataCellValue(scenarioName, "Parent_PastTherapySubstances1_SubstanceSpecifiedSubTermID"));
		agSetValue(FDE_ParentPageObjects.strength_Textfield,
				getTestDataCellValue(scenarioName, "Parent_PastTherapySubstancesParent1_StrengthNumber"));
		setParentEmbedDropDownValue(FDE_ParentPageObjects.strength_DropDown, scenarioName,
				"Parent_PastTherapySubstancesParent1_StrengthNumberUnit");
		Reports.ExtentReportLog("", Status.INFO,
				"Data entered in Past Therapy Substances: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify past therapy substance
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 26-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyPastTherapySubstances(String scenarioName) {

		verifyData(FDE_ParentPageObjects.substanceSpecifiedSubstanceName_Textfield, scenarioName,
				"Parent_PastTherapySubstances1_SubstanceSpecifiedSubName");
		verifyData(FDE_ParentPageObjects.substanceTermIDVerDateNum_Textfield, scenarioName,
				"Parent_PastTherapySubstances1_SubstanceTermIDVerDateNum");
		verifyData(FDE_ParentPageObjects.substanceSpecifiedSubstanceTermID_Textfield, scenarioName,
				"Parent_PastTherapySubstances1_SubstanceSpecifiedSubTermID");
		verifyData(FDE_ParentPageObjects.strength_Textfield, scenarioName,
				"Parent_PastTherapySubstancesParent1_StrengthNumber");
		agCheckPropertyText(
				getTestDataCellValue(scenarioName, "Parent_PastTherapySubstancesParent1_StrengthNumberUnit"),
				FDE_ParentPageObjects.strengthUnit_Getvalue);
		Reports.ExtentReportLog("", Status.INFO,
				"Data verification in Past Therapy Substances: Scenario Name::" + scenarioName, true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Parent details in FDE form
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 26-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void LSMVSetParentDetails(String scenarioName) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,
		// "ConfigurationSettings");
		// if (getTestDataCellValue(scenarioName,
		// "FDE_LabData").equalsIgnoreCase("Yes")) {
		setParentInformation(scenarioName);
		setParentMedicalHistory(scenarioName);
		setParentPastTherapy(scenarioName);
		setPastTherapySubstances(scenarioName);
		// }

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify General Basic Details in
	 *             FDE form
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void parent_Verification(String scenarioName) {
		verifyParentInformation(scenarioName);
		verifyParentMedicalHistory(scenarioName);
		verifyParentPastTherapy(scenarioName);
		verifyPastTherapySubstances(scenarioName);
	}
	
	/**********************************************************************************************************
	 * @Objective: Verify R2 tags in Parent tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyParentR2Tags() {
		Reports.ExtentReportLog("", Status.INFO,"********Parent R2 tag verification Started*******", true);
		agAssertVisible(FDE_ParentPageObjects.R2ParentId);
		agAssertVisible(FDE_ParentPageObjects.R2ParentDOB);
		agAssertVisible(FDE_ParentPageObjects.R2PArentAge);
		agAssertVisible(FDE_ParentPageObjects.R2ParentGender);
		agAssertVisible(FDE_ParentPageObjects.R2LMPOfParent);
		agAssertVisible(FDE_ParentPageObjects.R2ParentWeight);
		agAssertVisible(FDE_ParentPageObjects.R2ParentHeight);
		agAssertVisible(FDE_ParentPageObjects.R2ParentMedicalHistoryText);
		agAssertVisible(FDE_ParentPageObjects.R2ReportedDiseaseTerm_Parent);
		agAssertVisible(FDE_ParentPageObjects.R2StartDate);
		agAssertVisible(FDE_ParentPageObjects.R2EndDate);
		agAssertVisible(FDE_ParentPageObjects.R2Continuing);
		agAssertVisible(FDE_ParentPageObjects.R2Comments);
		agAssertVisible(FDE_ParentPageObjects.R2ProductNameAsReported);
		agAssertVisible(FDE_ParentPageObjects.R2PPTStartDate);
		agAssertVisible(FDE_ParentPageObjects.R2PPTEndDate);
		agAssertVisible(FDE_ParentPageObjects.R2IndicationTerm);
		agAssertVisible(FDE_ParentPageObjects.R2ReactionTerm);
		Reports.ExtentReportLog("", Status.INFO,"********Parent R2 tag verification Completed*******", true);
	}
	
	/**********************************************************************************************************
	 * @Objective: Verify R3 tags in Parent tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyParentR3Tags() {
		Reports.ExtentReportLog("", Status.INFO,"********Parent R3 tag verification Started*******", true);
		agAssertVisible(FDE_ParentPageObjects.R3ParentId);
		agAssertVisible(FDE_ParentPageObjects.R3ParentDOB);
		agAssertVisible(FDE_ParentPageObjects.R3PArentAge);
		agAssertVisible(FDE_ParentPageObjects.R3ParentGender);
		agAssertVisible(FDE_ParentPageObjects.R3LMPOfParent);
		agAssertVisible(FDE_ParentPageObjects.R3ParentWeight);
		agAssertVisible(FDE_ParentPageObjects.R3ParentHeight);
		agAssertVisible(FDE_ParentPageObjects.R3ParentMedicalHistoryText);
		agAssertVisible(FDE_ParentPageObjects.R3MedDRALLTCODEForDiseaseTerm_Parent);
		agAssertVisible(FDE_ParentPageObjects.R3StartDate);
		agAssertVisible(FDE_ParentPageObjects.R3EndDate);
		agAssertVisible(FDE_ParentPageObjects.R3Continuing);
		agAssertVisible(FDE_ParentPageObjects.R3Comments);
		agAssertVisible(FDE_ParentPageObjects.R3ProductNameAsReported);
		agAssertVisible(FDE_ParentPageObjects.R3MedicinalProductIdentifier_MPID);
		agAssertVisible(FDE_ParentPageObjects.R3MPIDVersionDate_Number);
		agAssertVisible(FDE_ParentPageObjects.R3PhPIDVersionDate_Number);
		agAssertVisible(FDE_ParentPageObjects.R3PhPID);
		agAssertVisible(FDE_ParentPageObjects.R3PPTStartDate);
		agAssertVisible(FDE_ParentPageObjects.R3PPTEndDate);
		agAssertVisible(FDE_ParentPageObjects.R3MedDRALLTCODEForIndicationTerm_Parent);
		agAssertVisible(FDE_ParentPageObjects.R3MedDRALLTCODEForReactionTerm_Parent);
		agAssertVisible(FDE_ParentPageObjects.R3InventedName);
		agAssertVisible(FDE_ParentPageObjects.R3ScientificName);
		agAssertVisible(FDE_ParentPageObjects.R3TrademarkName);
		agAssertVisible(FDE_ParentPageObjects.R3StrengthName);
		agAssertVisible(FDE_ParentPageObjects.R3FormName);
		agAssertVisible(FDE_ParentPageObjects.R3ContainerName);
		agAssertVisible(FDE_ParentPageObjects.R3DeviceName);
		agAssertVisible(FDE_ParentPageObjects.R3IntendedUseName);
		agAssertVisible(FDE_ParentPageObjects.R3Substance_SpecifiedSubstanceName);
		agAssertVisible(FDE_ParentPageObjects.R3SubstanceTermIDVer_Date_Num);
		agAssertVisible(FDE_ParentPageObjects.R3Substance_Specified_Substance_TermID);
		agAssertVisible(FDE_ParentPageObjects.R3Strength_Number);
		Reports.ExtentReportLog("", Status.INFO,"********Parent R3 tag verification Completed*******", true);
	}
	
	/**********************************************************************************************************
	 * @Objective: Verify Codelist tags in Parent tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyParentCodeList() {
		Reports.ExtentReportLog("", Status.INFO,"********Parent Codelist tag verification Started*******", true);
		agAssertVisible(FDE_ParentPageObjects.CLParentAge);
		agAssertVisible(FDE_ParentPageObjects.CLParentGender);
		agAssertVisible(FDE_ParentPageObjects.CLparentWeight);
		agAssertVisible(FDE_ParentPageObjects.CLParentHeight);
		agAssertVisible(FDE_ParentPageObjects.ClEthnicOrigin);
		agAssertVisible(FDE_ParentPageObjects.CLConsentToContactParent);
		agAssertVisible(FDE_ParentPageObjects.CLDiseaseTerm);
		agAssertVisible(FDE_ParentPageObjects.CLContinuing);
		agAssertVisible(FDE_ParentPageObjects.CLDuration);
		agAssertVisible(FDE_ParentPageObjects.CLCodingType);
		agAssertVisible(FDE_ParentPageObjects.CLStrength_Number);
		Reports.ExtentReportLog("", Status.INFO,"********Parent Codelist tag verification Completed*******", true);
	}
}
