package com.arisglobal.framework.components.lsmv.L10_1_1;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.ReconciliationPageObjects;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.XlsReader;

public class Reconciliation extends ToolManager {
	static String className = CaseComparison.class.getSimpleName();
	public static String sheetName = "UI_Data";

	/**********************************************************************************************************
	 * @Objective: Get case data comparison
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 09-October-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void getCaseDataAttributes(String filePath)  {
		try {
			XlsReader.createSheet(filePath, sheetName);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<WebElement> caseDataAttributes = agGetElementList(ReconciliationPageObjects.caseDataAttributesList);
		List<WebElement> colHeaderList = agGetElementList(ReconciliationPageObjects.columnHeaderList);
		String columnHeader = null;
		XlsReader.writeToExcel(filePath, sheetName, 0, 0, "Case Data Attributes");
		for (int j = 1; j <= colHeaderList.size(); j++) {
			columnHeader = agGetText(ReconciliationPageObjects.columnHeader(Integer.toString(j)));
			XlsReader.writeToExcel(filePath, sheetName, 0, j, columnHeader);
		}

		for (int i = 1; i <= caseDataAttributes.size(); i++) {
			String caseDataAttributesValue = agGetText(
					ReconciliationPageObjects.caseDataAttributes(Integer.toString(i)));
			String followupCaseDataAttributes = agGetText(
					ReconciliationPageObjects.followupCaseDataAttributes(Integer.toString(i)));
			String masterCaseDataAttributes = agGetText(
					ReconciliationPageObjects.masterCaseDataAttributes(Integer.toString(i)));
			String mergedCaseDataAttributes = agGetText(
					ReconciliationPageObjects.mergedCaseDataAttributes(Integer.toString(i)));
			XlsReader.writeToExcel(filePath, sheetName, i, 0, caseDataAttributesValue);

			System.out.println("caseDataAttributesValue:" + caseDataAttributesValue);
			if (!followupCaseDataAttributes.isEmpty() || !masterCaseDataAttributes.isEmpty()
					|| !mergedCaseDataAttributes.isEmpty()) {
				XlsReader.writeToExcel(filePath, sheetName, i, 1, followupCaseDataAttributes);
				XlsReader.writeToExcel(filePath, sheetName, i, 2, masterCaseDataAttributes);
				XlsReader.writeToExcel(filePath, sheetName, i, 3, mergedCaseDataAttributes);
			}
		}
		System.out.println("Get data completed");
/*		agSetStepExecutionDelay("2000");
		agClick(ReconciliationPageObjects.closeButton);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));*/
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: Verify case data attributes
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 10-October-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyReconciliationCaseDataAttributes(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		String followUpCase, masterCase, mergedCase = null;
		int rowCount;
		rowCount = xls.activeRowcount(filePath, sheetName);
		System.out.println("rowCount: " + rowCount);
		for (int i = 2; i <= rowCount + 1; i++) {
			followUpCase = xls.getCellData(sheetName, 1, i);
			masterCase = xls.getCellData(sheetName, 2, i);
			mergedCase = xls.getCellData(sheetName, 3, i);

			if (followUpCase.trim().isEmpty() && masterCase.trim().isEmpty() && mergedCase.trim().isEmpty()) {
				XlsReader.writeToExcel(filePath, sheetName, i - 1, 4, "PASS");
			}

			if (followUpCase.trim().isEmpty() && !masterCase.trim().isEmpty()) {
				if (masterCase.equals(mergedCase)) {
					XlsReader.writeToExcel(filePath, sheetName, i - 1, 4, "PASS");
				} else {
					XlsReader.writeToExcel(filePath, sheetName, i - 1, 4, "FAIL");
				}
			}

			if (!followUpCase.trim().isEmpty() && masterCase.trim().isEmpty()) {
				if (followUpCase.equals(mergedCase)) {
					XlsReader.writeToExcel(filePath, sheetName, i - 1, 4, "PASS");
				} else {
					XlsReader.writeToExcel(filePath, sheetName, i - 1, 4, "FAIL");
				}
			}

			if (!followUpCase.trim().isEmpty() && !masterCase.trim().isEmpty()) {
				if (followUpCase.equals(mergedCase)) {
					XlsReader.writeToExcel(filePath, sheetName, i - 1, 4, "PASS");
				} else {
					XlsReader.writeToExcel(filePath, sheetName, i - 1, 4, "FAIL");
				}
			}
		}
		System.out.println("Verification completed");
	}
}
