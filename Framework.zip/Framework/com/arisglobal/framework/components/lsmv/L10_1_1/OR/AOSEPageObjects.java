package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class AOSEPageObjects {
	
	public static String AOSEIcon = "xpath#//a[text()='AOSE']";
	public static String validationPopUp = "xpath#//span[text()='Action Completed with Validation Error(s)']";
	public static String okBtn = "xpath#//button[@id='mandatoryDialogform:okButton']";
	public static String AOSEHeader = "xpath#//span[text()='AOSE SEARCH']";
	
	public static String companyUnit = "xpath#//div[text()='Arisglobal']";
	public static String compareBtn = "xpath#//span[@id='compareDialgBtn']";
	
	public static String generateReport = "xpath#//span[text()='Generate Report']";
	public static String openBtn = "xpath#//a/button[@id='open-button']";
	public static String closeBtn = "xpath#//div[@id='targetPanelForReport']/button[text()='Close']";
	public static String embedid = "xpath#//div[@class='embedDiv']/embed[@id='ifr']";
	public static String closeAOSEPopUp = "xpath#//span[@id='closeNotesBtn']";
	
}
