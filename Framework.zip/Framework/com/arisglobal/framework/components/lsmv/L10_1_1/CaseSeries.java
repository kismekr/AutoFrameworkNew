package com.arisglobal.framework.components.lsmv.L10_1_1;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.AdvanceSearchPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CaseSeriesPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.DataExportPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FDE_LabellingPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.FileSystemOperations;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class CaseSeries extends ToolManager {
	
	public static WebElement webElement;
	static String sheetName = CaseSeries.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;	
	
	/**********************************************************************************************************
	 * @Objective:The below method is created to search using advance search and save search result in case series
	 * @InputParameters: void
	 * @author:Yashwanth Naidu
	 * @Date : 24/03/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void searchCriteriaByAdvanceSearch(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		CaseManagementOperations.menuNavigation("Case listing");		
		agSetStepExecutionDelay("8000");		
		AdvanceSearchOperations.navigateToAdvanceSearch();		
		AdvanceSearchOperations.receiptNumberSearch(scenarioName);
		CaseSeries.saveCaseSeries(scenarioName, sheetName, columnName);		
	}	
	
	/**********************************************************************************************************
	 * @Objective:The below method is created to fill the case series details and Save series
	 * @InputParameters: void
	 * @author:Yashwanth Naidu
	 * @Date : 25/03/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void saveCaseSeries(String scenarioName ,String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetStepExecutionDelay("2000");		
		agIsVisible(CaseSeriesPageObjects.receiptSearch);
		agClick(CaseSeriesPageObjects.saveSeriesBtn);
		//agSetValue(CaseSeriesPageObjects.caseSeriesName, getTestDataCellValue(scenarioName,"Case_Series_Name"));
		agWaitTillVisibilityOfElement(CaseSeriesPageObjects.yes_RadioBtn);
		
		/*agClick(CaseSeriesPageObjects.yes_RadioBtn);	
		agSetStepExecutionDelay("1000");		
		agClick(CaseSeriesPageObjects.no_RadioBtn);*/
		
		agJavaScriptExecuctorSendKeys(CaseSeriesPageObjects.caseSeriesVal,getTestDataCellValue(scenarioName,"Case_Series_Name"));	
		agClick(CaseSeriesPageObjects.saveCaseSeries);
		agWaitTillVisibilityOfElement(CaseSeriesPageObjects.saveMessage);
		status = agIsVisible(CaseSeriesPageObjects.saveMessage);
		
		if (status) {	
			Reports.ExtentReportLog("", Status.PASS,"LSMV case series created successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,"LSMV case series not created successfull", true);
		}
		CommonOperations.takeScreenShot();
		agClick(CaseSeriesPageObjects.saveOkButon);	
	}
	
	/**********************************************************************************************************
	 * @Objective:The below method will fill the case series details with same name
	 * @InputParameters: void
	 * @author:Yashwanth Naidu
	 * @Date : 27/03/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void saveSeriesWithSameName(String scenarioName) {
		CaseManagementOperations.menuNavigation("Case listing");
		
		agSetStepExecutionDelay("8000");		
		AdvanceSearchOperations.navigateToAdvanceSearch();		
		AdvanceSearchOperations.receiptNumberSearch(scenarioName);
		agIsVisible(CaseSeriesPageObjects.receiptSearch);
		agClick(CaseSeriesPageObjects.saveSeriesBtn);	
		agClick(CaseSeriesPageObjects.saveCaseSeries);
		agWaitTillVisibilityOfElement(CaseSeriesPageObjects.validatiomMessage);
		status = agIsVisible(CaseSeriesPageObjects.validatiomMessage);
		
		if (status) {
			Reports.ExtentReportLog("", Status.PASS,"Case Series name already exist", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,"Case series name not exist", true);
		}
		CommonOperations.takeScreenShot();
		agClick(CaseSeriesPageObjects.validationOkButton);			
		agClick(CaseSeriesPageObjects.closeSaveSeriesPopUp);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	

	/**********************************************************************************************************
	 * @Objective:The below method will delete created case series.
	 * @InputParameters: void
	 * @author:Yashwanth Naidu
	 * @Date : 30/03/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteCreatedCaseSerie(String scenarioName, String sheetName, String columnName) {	
		agSetStepExecutionDelay("5000");
		CaseManagementOperations.menuNavigation("Case series");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetValue(CaseSeriesPageObjects.caseSeriesSearch, getTestDataCellValue(scenarioName, "Case_Series_Name"));
		agClick(CaseSeriesPageObjects.searchIcon);		
		agClick(CaseSeriesPageObjects.checkRecord);
		agClick(CaseSeriesPageObjects.deleteSearchedSeries);
//		agWaitTillVisibilityOfElement(CaseSeriesPageObjects.deleteSeriesYesBtn);
//		agClick(CaseSeriesPageObjects.deleteSeriesYesBtn);		
		agWaitTillVisibilityOfElement(CaseSeriesPageObjects.completedValidationMessage);
		status = agIsVisible(CaseSeriesPageObjects.completedValidationMessage);
		
		if (status) {
			Reports.ExtentReportLog("", Status.PASS,"Searched case series deleted successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,"Searched case series not deleted successfully", true);
		}
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agJavaScriptExecuctorClick(CaseSeriesPageObjects.actionCompletedOkButton);				
	}
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created search particular Case Series record
	 * @InputParameters: ScenarioName
	 * @author: Shamanth S
	 * @Date : 06/10/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean searchCreatedCaseSeries(String scenarioName) {	
		boolean isAvailable = false;
		
		agSetStepExecutionDelay("2000");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		
		if(agIsVisible(CaseSeriesPageObjects.caseSeriesbreadScrumb)==false) {
			CaseManagementOperations.menuNavigation("Case series");
		}
		
		agWaitTillVisibilityOfElement(CaseSeriesPageObjects.caseSeriesSearchBox);
		agSetValue(CaseSeriesPageObjects.caseSeriesSearchBox, getTestDataCellValue(scenarioName, "ReceiptNo"));
		agClick(CaseSeriesPageObjects.searchButton_icon);
		
		agWaitTillVisibilityOfElement(CaseSeriesPageObjects.paginator);
		if (agGetText(CaseSeriesPageObjects.paginator).startsWith("1") && agGetText(CaseSeriesPageObjects.paginator).endsWith("1")) {
			isAvailable = true;
			Reports.ExtentReportLog("", Status.PASS, "Record with the same Name available", true);
		}
		
		return isAvailable;
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to perform search by saved criteria in advance search listing.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void createAndSearchBySavedCriteria(String scenarioName){
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		
		CaseManagementOperations.menuNavigation("Case listing");
		agSetStepExecutionDelay("8000");		
		AdvanceSearchOperations.navigateToAdvanceSearch();
		agWaitTillVisibilityOfElement(AdvanceSearchPageObjects.clickOnDropDown("Saved Criteria"));
		
		agClick(AdvanceSearchPageObjects.clickOnDropDown("Saved Criteria"));
		agSetValue(AdvanceSearchPageObjects.searchDD_TextArea, getTestDataCellValue(scenarioName, "ReceiptNo"));
		agSetStepExecutionDelay("2000");
		
		if (agIsVisible(AdvanceSearchPageObjects.dropdownSelect(getTestDataCellValue(scenarioName, "ReceiptNo")))) {
			agClick(AdvanceSearchPageObjects.dropdownSelect(getTestDataCellValue(scenarioName, "ReceiptNo")));
			agSetStepExecutionDelay("2000");
			agClick(AdvanceSearchPageObjects.search_Btn);
			
		    agSetStepExecutionDelay("5000");
		    CommonOperations.agwaitTillVisible(CaseListingPageObjects.waitForRCT(getTestDataCellValue(scenarioName, "ReceiptNo")),2, 1000);
		    Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);
		}
		else {					
			agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.administrativeFields_link));
			CommonOperations.agwaitTillVisible(AdvanceSearchPageObjects.receiptNumber_Txtfield);
			agSetStepExecutionDelay("3000");
	        agSetValue(AdvanceSearchPageObjects.receiptNumber_Txtfield, getTestDataCellValue(scenarioName, "ReceiptNo"));
	        
	        agClick(AdvanceSearchPageObjects.saveAndSearch_Btn);
	        agWaitTillVisibilityOfElement(AdvanceSearchPageObjects.saveAndSearch_WinTitle);
	        agSetValue(AdvanceSearchPageObjects.searchCriteriaName, getTestDataCellValue(scenarioName, "ReceiptNo"));
	        agClick(AdvanceSearchPageObjects.saveCriteria_Btn);
	        
	        agIsVisible(AdvanceSearchPageObjects.saveCriteria_ConfirmTitle);
	        agClick(AdvanceSearchPageObjects.saveCriteria_OK);
	        agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	        CommonOperations.agwaitTillVisible(CaseListingPageObjects.waitForRCT(getTestDataCellValue(scenarioName, "ReceiptNo")),2, 1000);
			Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);
		}
		
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is to create a particular Case Series record
	 * @InputParameters: ScenarioName
	 * @author: Shamanth S
	 * @Date : 06/10/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean createCaseSeries(String scenarioName) {	
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		boolean isSeriesCreated = false;	
		if (searchCreatedCaseSeries(scenarioName)) {
			isSeriesCreated = true;
			System.out.println("Record with the same Name available already");
			Reports.ExtentReportLog("", Status.PASS, "Record with the same Name available already", true);
		}
		else {
			createAndSearchBySavedCriteria(scenarioName);
			CaseSeries.saveCaseSeries(scenarioName, sheetName, "ReceiptNo");
		}
		
		return isSeriesCreated;
	}
	
	
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is to delete a particular Case is FOIA Ready
	 * @InputParameters: ScenarioName
	 * @author: Shamanth S
	 * @Date : 08/10/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteCaseSeries(String scenarioName) {		
		CaseManagementOperations.menuNavigation("Case series");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		
		agSetValue(CaseSeriesPageObjects.caseSeriesSearchBox, getTestDataCellValue(scenarioName, "ReceiptNo"));
		agClick(CaseSeriesPageObjects.searchButton_icon);		
		agClick(CaseSeriesPageObjects.searchRecord_chkBx);
		agClick(CaseSeriesPageObjects.Delete_Button);
		/*agWaitTillVisibilityOfElement(CaseSeriesPageObjects.deleteSeriesYesBtn);
		agClick(CaseSeriesPageObjects.deleteSeriesYesBtn);	*/	
		
		agWaitTillVisibilityOfElement(CaseSeriesPageObjects.confirmationOK_Btn);		
		Reports.ExtentReportLog("", Status.INFO, agGetText(CaseSeriesPageObjects.confirmation_Info), true);
		agClick(CaseSeriesPageObjects.confirmationOK_Btn);	
	
		if (searchCreatedCaseSeries(scenarioName)) {
			Reports.ExtentReportLog("", Status.FAIL,"Searched case series not deleted successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS,"Searched case series deleted successfully", true);
		}
		
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is to verify a particular Case is FOIA Ready
	 * @InputParameters: ScenarioName
	 * @author: Shamanth S
	 * @Date : 08/10/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean checkCaseFOIAReady(String scenarioName) {
		boolean isCaseFOIAReady = false;
		
		searchCreatedCaseSeries(scenarioName);
				
		if (agIsVisible(CaseSeriesPageObjects.buildCaseLocators(CaseSeriesPageObjects.completedFOIA_icon, 
				getTestDataCellValue(scenarioName, "ReceiptNo")))) {
			isCaseFOIAReady = true;
			Reports.ExtentReportLog("", Status.INFO,"Searched case series is FOIA ready", false);
		}
		
		return isCaseFOIAReady;
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is to verify a particular Case is FOIA Ready
	 * @InputParameters: ScenarioName
	 * @author: Shamanth S
	 * @Date : 08/10/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void makeCaseFOIAReady(String scenarioName) {
		if(checkCaseFOIAReady(scenarioName)) {
			Reports.ExtentReportLog("", Status.PASS,"The case series is FOIA ready", true);
		}
		
		else {
			agClick(CaseSeriesPageObjects.buildCaseLocators(CaseSeriesPageObjects.caseSeriesName_Hyperlink, 
					getTestDataCellValue(scenarioName, "ReceiptNo")));
			agWaitTillVisibilityOfElement(CaseSeriesPageObjects.refresh_label);
			agClick(CaseSeriesPageObjects.buildCaseLocators(CaseSeriesPageObjects.caseReceiptNumber_Hyperlink, 
					getTestDataCellValue(scenarioName, "ReceiptNo")));
			
			agWaitTillVisibilityOfElement(CaseSeriesPageObjects.moreActions_HoverBtn);
			agMouseHover(CaseSeriesPageObjects.moreActions_HoverBtn);
			agClick(CaseSeriesPageObjects.redactedNarrative_Link);
			
			agWaitTillVisibilityOfElement(CaseSeriesPageObjects.eventDescription_Link);
			agClick(CaseSeriesPageObjects.eventDescription_Link);
			agWaitTillVisibilityOfElement(CaseSeriesPageObjects.redactedNarrative_TxtArea);
			agSetValue(CaseSeriesPageObjects.redactedNarrative_TxtArea, getTestDataCellValue(scenarioName, "RedactedNarrative"));
			agClick(CaseSeriesPageObjects.submit_Btn);
			
			agWaitTillVisibilityOfElement(CaseSeriesPageObjects.info_label);
			agClick(CaseSeriesPageObjects.infoClose_icon);
			Reports.ExtentReportLog("", Status.PASS, agGetText(CaseSeriesPageObjects.info_para), true);
			agWaitTillVisibilityOfElement(CaseSeriesPageObjects.narrativeClose_icon);
			agClick(CaseSeriesPageObjects.narrativeClose_icon);
		}
		
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data is visible in downloaded report.
	 * @InputParameters: scenarioName, sheetName, columnName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 29-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyDataVisible_DownloadedReport(String filePath, String scenarioName, String sheetName,
			String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		PDFOperations.pdfverificationForVisible(filePath,
				getTestDataCellValue(scenarioName, columnName));
	}
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is to verify a particular Case is FOIA Ready
	 * @InputParameters: ScenarioName
	 * @author: Shamanth S
	 * @Date : 13/10/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downloadAndMoveReport(String scenarioName) {
		
		String path = lsmvConstants.LSMV_testDataOutput + "\\" + Reports.currenttime();
		lsmvConstants.path = path;
		
		makeCaseFOIAReady(scenarioName);
		agClick(CaseSeriesPageObjects.buildCaseLocators(CaseSeriesPageObjects.caseSeriesName_Hyperlink, 
				getTestDataCellValue(scenarioName, "ReceiptNo")));
		agWaitTillVisibilityOfElement(CaseSeriesPageObjects.refresh_label);
		agClick(CaseSeriesPageObjects.buildCaseLocators(CaseSeriesPageObjects.reportFOIA_icon, 
				getTestDataCellValue(scenarioName, "ReceiptNo")));
		
		FileSystemOperations.createFolder(path);
					
		FileSystemOperations.moveFile(getTestDataCellValue(scenarioName, "ReceiptNo") + ".pdf", lsmvConstants.LSMV_testDataOutput, path);
		
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is to verify DSUR labelling through case series 
	 * @InputParameters: ScenarioName
	 * @author: Yashwanth Naid
	 * @Date : 30/11/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void applyDSURLabelling(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agIsVisible(CaseSeriesPageObjects.caseSeriesSearch);
		agSetValue(CaseSeriesPageObjects.caseSeriesSearch, getTestDataCellValue(scenarioName, "Case_Series_Name"));
		agClick(CaseSeriesPageObjects.searchIcon);
		status =  agIsVisible(CaseSeriesPageObjects.caseSeries(getTestDataCellValue(scenarioName, "Case_Series_Name")));
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Record listed Successfully", true);
		}
		else {
			Reports.ExtentReportLog("", Status.FAIL, "Record not listed Successfully", true);
		}
		status =  agIsVisible(CaseSeriesPageObjects.pendingDSURLabellingStatus);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Pedning DSUR labelling status verified Successfully", true);
		}
		else {
			Reports.ExtentReportLog("", Status.FAIL, "Pedning DSUR labelling status is not verified Successfully", true);
		}
		agJavaScriptExecuctorClick(CaseSeriesPageObjects.checkRecord);
		agClick(CaseSeriesPageObjects.exportpanelGroup);
		agJavaScriptExecuctorClick(CaseSeriesPageObjects.DSURLabelling);
		agIsVisible(CaseSeriesPageObjects.DSURLDataSheetHeader);
		
		if(scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_1")) {
			
			for(int i = 1; i<=2; i++) {
			agClick(CaseSeriesPageObjects.productLookup);
			agIsVisible(CaseSeriesPageObjects.productlookUpHeader);
			agSetValue(CaseSeriesPageObjects.productName, getTestDataCellValue("DSUREnhancementCaseSeries_" + i, "Product_Name"));
			agClick(CaseSeriesPageObjects.searchBtn);
			agJavaScriptExecuctorClick(CaseSeriesPageObjects.checkProduct);
			agClick(CaseSeriesPageObjects.productOkBtn);
			agIsVisible(CaseSeriesPageObjects.dataSheetName(ProductsOperations.getTestDataCellValue("DSUREnhancementCaseSeries_" + i, "labelingDataSheetName")));		
			agJavaScriptExecuctorClick(CaseSeriesPageObjects.dataSheetName(ProductsOperations.getTestDataCellValue("DSUREnhancementCaseSeries_" + i, "labelingDataSheetName")));
			}
		}else if(scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Repeat_1")) {
			
			for(int i = 1; i<=2; i++) {
			agClick(CaseSeriesPageObjects.productLookup);
			agIsVisible(CaseSeriesPageObjects.productlookUpHeader);
			agSetValue(CaseSeriesPageObjects.productName, getTestDataCellValue("DSUREnhancementCaseSeries_Repeat_" + i, "Product_Name"));
			agClick(CaseSeriesPageObjects.searchBtn);
			agJavaScriptExecuctorClick(CaseSeriesPageObjects.checkProduct);
			agClick(CaseSeriesPageObjects.productOkBtn);
			agIsVisible(CaseSeriesPageObjects.dataSheetName(ProductsOperations.getTestDataCellValue("DSUREnhancementCaseSeries_Repeat_" + i, "labelingDataSheetName")));		
			agJavaScriptExecuctorClick(CaseSeriesPageObjects.dataSheetName(ProductsOperations.getTestDataCellValue("DSUREnhancementCaseSeries_Repeat_" + i, "labelingDataSheetName")));
			}
		}else{
			agClick(CaseSeriesPageObjects.productLookup);
			agIsVisible(CaseSeriesPageObjects.productlookUpHeader);
			agSetValue(CaseSeriesPageObjects.productName, getTestDataCellValue(scenarioName, "Product_Name"));
			agClick(CaseSeriesPageObjects.searchBtn);
			agJavaScriptExecuctorClick(CaseSeriesPageObjects.checkProduct);
			agClick(CaseSeriesPageObjects.productOkBtn);
			agIsVisible(CaseSeriesPageObjects.dataSheetName(getTestDataCellValue(scenarioName, "labelingDataSheetName")));		
			agJavaScriptExecuctorClick(CaseSeriesPageObjects.dataSheetName(ProductsOperations.getTestDataCellValue(scenarioName, "labelingDataSheetName")));
		}		
		agClick(CaseSeriesPageObjects.selectBtn);
		agIsVisible(CaseSeriesPageObjects.dsurLabellingMessage);
		agJavaScriptExecuctorClick(CaseSeriesPageObjects.notificationPopUpclose);
		verifyReadyStatus();
		agClick(CaseSeriesPageObjects.clickSeries);
		DSURStatusVerification();
		if(scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_1") ||scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Repeat_1"))  {
			
			CaseListingOperations.searchCaseAndEdit("DSUREnhancementCaseSeries", "FDE_General", "ReceiptNo");
			FDE_Operations.tabNavigation("Labeling");
			FDE_Labelling.SelectProductLabeling("DSUREnhancementCaseSeries");
			FDE_Labelling.verifylabellingData("DSUREnhancementCaseSeries");
			
			CaseListingOperations.searchCaseAndEdit("DSUREnhancementCaseSeriesV1", "FDE_General", "ReceiptNo");
			FDE_Operations.tabNavigation("Labeling");
			FDE_Labelling.SelectProductLabeling("DSUREnhancementCaseSeriesV1");
			FDE_Labelling.verifylabellingData("DSUREnhancementCaseSeriesV1");
			
			CaseListingOperations.searchCaseAndEdit("DSUREnhancementCaseSeries_Susar", "FDE_General", "ReceiptNo");
			FDE_Operations.tabNavigation("Labeling");
			FDE_Labelling.SelectProductLabeling("DSUREnhancementCaseSeries_Susar");
			FDE_Labelling.verifylabellingData("DSUREnhancementCaseSeries_Susar");
			
			CaseListingOperations.searchCaseAndEdit("DSUREnhancementCaseSeries_Susar_1", "FDE_General", "ReceiptNo");
			FDE_Operations.tabNavigation("Labeling");
			FDE_Labelling.SelectProductLabeling("DSUREnhancementCaseSeries_Susar_1");
			FDE_Labelling.verifylabellingData("DSUREnhancementCaseSeries_Susar_1");
			
		}else if(scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Susar_3")){
				CaseListingOperations.searchCaseAndEdit("DSUREnhancementCaseSeries_Susar_3", "FDE_General", "ReceiptNo");
				FDE_Operations.tabNavigation("Labeling");
				FDE_Labelling.SelectProductLabeling("DSUREnhancementCaseSeries_Susar_3");
				FDE_Labelling.verifylabellingData("DSUREnhancementCaseSeries_Susar_3");
		}else {
			verifyDSURLabelling(scenarioName);
		}
		
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is to verify DSUR labelling status
	 * @InputParameters: ScenarioName
	 * @author: Yashwanth Naid
	 * @Date : 30/11/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyReadyStatus () {
		for (int i=0 ; i<10 ; i++) {
			
			status = agIsVisible(CaseSeriesPageObjects.DSURLebellingReadyStatus);
			if(status) {
				Reports.ExtentReportLog("", Status.PASS, "DSUR labelling completed", true);
				break;		
			}else {
				agClick(CaseSeriesPageObjects.searchIcon);
				agSetStepExecutionDelay("2000");
				
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify DSUR status once completed 
	 * @InputParameters: ScenarioName
	 * @author: Yashwanth Naid
	 * @Date : 30/11/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void DSURStatusVerification() {
		agIsVisible(CaseSeriesPageObjects.workflowHeader);
		agIsVisible(CaseSeriesPageObjects.columnSelectionClick);
		agClick(CaseSeriesPageObjects.columnSelectionClick);
		agJavaScriptExecuctorClick(CaseSeriesPageObjects.selectAll);
		status = agIsVisible(CaseSeriesPageObjects.DSURStatus);
		if(status) {
			Reports.ExtentReportLog("", Status.PASS, "DSUR status verified successfully ", true);
		}else {
			Reports.ExtentReportLog("", Status.PASS, "DSUR status not verified successfully ", true);			
		}	
	}
	

	/**********************************************************************************************************
	 * @Objective: The below method is to verify DSUR labelling in case level
	 * @InputParameters: ScenarioName
	 * @author: Yashwanth Naidu
	 * @Date : 30/11/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDSURLabelling(String scenarioName) {
		String ReceiptNO = getTestDataCellValue(scenarioName, "ReceiptNo");
		agClick(CaseSeriesPageObjects.selectCase(ReceiptNO));
		agWaitTillInvisibilityOfElement(CaseSeriesPageObjects.caseloader);
		agIsVisible(CaseSeriesPageObjects.caseWorkFLowHeader);
		FDE_Operations.tabNavigation("Labeling");
		agIsVisible(FDE_LabellingPageObjects.labelingHeader);
		if(scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Susar_4")) {
			FDE_Labelling.SelectProductLabeling("DSUREnhancementCaseSeries_Susar_4");
		}
		status = agIsVisible(FDE_LabellingPageObjects.DSURCountry);
		if(status) {
			Reports.ExtentReportLog("", Status.PASS, "DSUR country verified successfully ", true);
		}else {
			Reports.ExtentReportLog("", Status.PASS, "DSUR country not verified successfully ", true);			
		}
		status = agIsVisible(FDE_LabellingPageObjects.DSURLabeling);
		if(status) {
			Reports.ExtentReportLog("", Status.PASS, "DSUR labeling verified successfully ", true);
		}else {
			Reports.ExtentReportLog("", Status.PASS, "DSUR labeling not verified successfully ", true);			
		}
	}	
}