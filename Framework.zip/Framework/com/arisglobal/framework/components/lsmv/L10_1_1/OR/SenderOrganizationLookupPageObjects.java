package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public abstract class SenderOrganizationLookupPageObjects {
	
	
	public static String searchButton = "xpath#//span[@class='ui-button-text ui-clickable'][contains(text(),'Search')]";
	public static String cancelButton = "xpath#//span[@class='ui-button-text ui-clickable'][contains(text(),'Cancel')]";
	public static String data = "xpath#//p-table[@datakey='partnerId']//tbody[@class='ui-table-tbody']/tr";
}
