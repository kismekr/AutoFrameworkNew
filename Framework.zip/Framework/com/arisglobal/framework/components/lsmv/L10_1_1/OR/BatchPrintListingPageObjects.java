package com.arisglobal.framework.components.lsmv.L10_1_1.OR;

public class BatchPrintListingPageObjects {
	
	
	
	public static String batchPrintListingSearchTextbox = "xpath#//input[@id='listingForm:searchCriteria']";
	public static String searchIcon = "xpath#//a[@id='listingForm:searchbutton']/img";
	public static String paginator = "xpath#//div[@id='listingForm:batchPrintDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String editIcon = "xpath#//a[@id='listingForm:batchPrintDataTable:0:editLink']";
	public static String batchname_label = "xpath#//label[@id='batchPrintDetails:batchNameLabel']";
	
	public static String refresh_icon = "xpath#//a[@id='listingForm:refreshImage']";
	public static String get_ListofBatchName= "xpath#//tbody[@id='listingForm:batchPrintDataTable_data']/tr/child::td[3]";
	public static String columnHeader = "xpath#(//tbody[@id='listingForm:batchPrintDataTable_data']/tr/child::td[3])[{%count}]";
	
	public static String new_Btn = "xpath#//a[@id='listingForm:newId']";
	public static String delete_Btn = "xpath#//a[@id='listingForm:deleteId']";
	public static String noOfcopies_TxtField = "xpath#//input[@id='batchPrintDetails:noOfCopiesId']";
	
	public static String batchName_Txtfield = "xpath#//input[@id='batchPrintDetails:batchNameId']";
	public static String click_BatchConfigurationName = "xpath#//div[@id='batchPrintDetails:batchprinterId']/div/span";
	public static String set_BatchConfigName = "xpath#//ul[@id='batchPrintDetails:batchprinterId_items']/li[2]";
	public static String printBy_Radiobtns = "xpath#//label[contains(@for,'batchPrintDetails:selectOptionBatchPrinting') and text()='%s']/ancestor::td/div//span";
	public static String dateRange_RadioBtn = "Date Range";
	public static String commaseparatedAERNo_RadioBtn = "Comma separated AER No.s";
	public static String uploadFile_RadioBtn = "Upload File";
	public static String savedSearches_RadioBtn = "Saved Searches ";
	public static String description_Txtarea = "xpath#//textarea[@id='batchPrintDetails:description']";
	
	
	public static String reportType_RadioBtn = "xpath#//label[contains(@for,'batchPrintDetails:versionLabel') and text()='%s']/ancestor::td/div//span";
	public static String draft_RadioBtn = "Draft";
	public static String final_RadioBtn = "Final";
	
	
	public static String dataPrivacyTypeRadiobtns = "xpath#//label[contains(@for,'batchPrintDetails:dataPrivcyID') and text()='%s']/ancestor::td/div//span";
	public static String masked_RadioBtn = "Masked";
	public static String unmasked_RadioBtn = "UnMasked";
	
	
	
	public static String blindingTypeRadiobtns = "xpath#//label[contains(@for,'batchPrintDetails:blindingID') and text()='%s']/ancestor::td/div//span";
	public static String blinded_RadioBtn = "Blinded";
	public static String unblinded_RadioBtn = "Unblinded";
	
	public static String printTypeRadiobtns = "xpath#//label[contains(@for,'batchPrintDetails:printTypeId') and text()='%s']/ancestor::td/div//span";
	public static String pdf_RadioBtn = "PDF";
	public static String paper_RadioBtn = "Paper";
	public static String checkboxs = "xpath#//label[text()='%s']/parent::div/child::div//span";
	public static String cIOMS_checkbox = "CIOMS";
	public static String schedule_checkbox = "Schedule";
	public static String medWatch_checkbox = "MedWatch";
	public static String includeCoverPage_checkbox = "Include Cover Page";
	
	public static String click_ScheduleType = "xpath#//div[@id='batchPrintDetails:schedularDropDown']/div/span";
	public static String set_ScheduleType = "xpath#//ul[@id='batchPrintDetails:schedularDropDown_items']/li[text()='%s']";
	
	public static String save_Btn = "xpath#//button[@id='batchPrintDetails:visibleSave']";
	public static String SaveOkBtn="xpath#//button[@id='mandatoryDialogform:okButton']/span";
	public static String cancel_Btn = "xpath#//button[@id='batchPrintDetails:cancelId']";
	
	public static String fromDate = "xpath#//input[@id='batchPrintDetails:batchPrintStartDate_input']";
	public static String aerNo_Txtarea = "xpath#//textarea[@id='batchPrintDetails:caseRecordIds']";
	public static String toDate = "xpath#//input[@id='batchPrintDetails:batchPrintEndDate_input']";
	public static String getBatchConfigName = "xpath#//label[@id='batchPrintDetails:batchprinterId_label']";
	public static String getSchedularName = "xpath#//label[@id='batchPrintDetails:schedularDropDown_label']";
	
	public static String listingScreen_CheckBoxs = "xpath#//td/a[text()='%s']/ancestor::tbody[@id='listingForm:batchPrintDataTable_data']/tr/td/div/child::div/span";
	
	public static String downloadIcon = "xpath#//a[@id='listingForm:actionId']";
	public static String exporttoExcel_link = "xpath#//button[contains(@id,'listingForm:j_id')]/span[text()='Export To Excel']";
	public static String exporttoExcel_popup = "xpath#//span[@id='listingForm:columnSelectionDialogId_title']";
	public static String export_Btn= "xpath#//button[@id='listingForm:submitId']";
	public static String exportexcelcancel_Btn= "xpath#//button[@id='listingForm:cancelDialogId']";
	
	
	   public static String click_blindingTypeRadiobtns(String runTimeLabel) {
	        String value = blindingTypeRadiobtns;
	        String value2;
	        value2 = value.replace("%s", runTimeLabel);
	        return value2;
	    }
	
	
	
	   public static String set_ScheduleTypeDropdown(String runTimeLabel) {
	        String value = set_ScheduleType;
	        String value2;
	        value2 = value.replace("%s", runTimeLabel);
	        return value2;
	    }
	
	
	   public static String clickcheckboxs(String runTimeLabel) {
	        String value = checkboxs;
	        String value2;
	        value2 = value.replace("%s", runTimeLabel);
	        return value2;
	    }
	
	
	   public static String set_BatchConfigurationName(String runTimeLabel) {
	        String value = set_BatchConfigName;
	        String value2;
	        value2 = value.replace("%s", runTimeLabel);
	        return value2;
	    }
	
	
	   public static String click_printByRadiobtns(String runTimeLabel) {
	        String value = printBy_Radiobtns;
	        String value2;
	        value2 = value.replace("%s", runTimeLabel);
	        return value2;
	    }
	   
	   public static String click_reportTypeRadioBtn(String runTimeLabel) {
	        String value = reportType_RadioBtn;
	        String value2;
	        value2 = value.replace("%s", runTimeLabel);
	        return value2;
	    }
	   public static String click_dataPrivacyTypeRadiobtns(String runTimeLabel) {
	        String value = dataPrivacyTypeRadiobtns;
	        String value2;
	        value2 = value.replace("%s", runTimeLabel);
	        return value2;
	    }
	   
	   public static String click_printTypeRadiobtns(String runTimeLabel) {
	        String value = printTypeRadiobtns;
	        String value2;
	        value2 = value.replace("%s", runTimeLabel);
	        return value2;
	    }
		/**********************************************************************************************************
		 * @Objective:The below method is created to select checkbox by passing value at runtime.
		 * @Input Parameters: runTimeLabel
		 * @Scenario Name Output
		 * @Parameters:
		 * @author:Avinash K Date :18-Oct-2019 Updated by and when   	 
		**********************************************************************************************************/		
	    		
	    public static String selectListingCheckbox(String runTimeLabel) {
	        String value = listingScreen_CheckBoxs;
	        String value2;
	        value2 = value.replace("%s", runTimeLabel);
	        return value2;
	    }
	    
	    
	    
		/**********************************************************************************************************
		 * @Objective:get substance name by passing input Parameters:rowNum Output
		 * @Parameters: Case data attribute value
		 * @author:DushyanthMahesh Date :16-September-2019 Updated by and when
		 **********************************************************************************************************/
		public static String columnHeaderList(String num) {
			String value = columnHeader;
			String value2;
			value2 = value.replace("{%count}", num);
			return value2;
		}
		
	    
	    
	    
}