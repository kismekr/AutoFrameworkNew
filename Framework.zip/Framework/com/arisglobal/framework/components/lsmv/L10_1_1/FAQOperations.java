package com.arisglobal.framework.components.lsmv.L10_1_1;

import com.arisglobal.framework.components.lsmv.L10_1_1.OR.CaseManagementPageObjects;
import com.arisglobal.framework.components.lsmv.L10_1_1.OR.FAQPageObjects;
import com.arisglobal.framework.lib.main.ToolManager;

public class FAQOperations extends ToolManager{

	/**********************************************************************************************************
	 * @Objective: Navigate to sub menu
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 09-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	 public static void FAQ_SubMenuNavigation(String object) {
		agMouseHover(FAQPageObjects.FAQ);
		agClick(object);
	}
	
}
