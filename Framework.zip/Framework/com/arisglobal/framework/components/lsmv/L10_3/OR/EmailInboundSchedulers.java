package com.arisglobal.framework.components.lsmv.L10_3.OR;

import com.arisglobal.framework.lib.main.ToolManager;

public class EmailInboundSchedulers {

	public static String activityLogTab = "xpath#//a[@id='schDetailsForm:activityLogTab1']";
	public static String logTableRowCount = "xpath#//div[@id='schDetailsForm:actLogDataTable']/div[2]/table//tr[@class='ui-widget-content ui-datatable-even']";
	public static String actionTaken = "xpath#//div[@id='schDetailsForm:actLogDataTable']/div[2]/table//tr[%s]/td[2]";
	public static String rctTxt = "xpath#//div[@id='schDetailsForm:actLogDataTable']/div[2]/table//tr[%s]/td[3]";
	
	public static String getActionTaken(String row) {

		String value = actionTaken;
		String value2;
		value2 = value.replace("%s", row);
		return value2;		
	}
	
	public static String getRCTTxt(String row) {

		String value = rctTxt;
		String value2;
		value2 = value.replace("%s", row);
		return value2;		
	}	
}
