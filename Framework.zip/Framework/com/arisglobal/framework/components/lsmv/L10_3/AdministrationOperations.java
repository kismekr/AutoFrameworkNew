package com.arisglobal.framework.components.lsmv.L10_3;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AdministrationPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.SchedulersPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;

public class AdministrationOperations extends Multimaplibraries {

	static String className = E2BMessageQueueOperations.class.getSimpleName();
	public static WebElement webElement;

	/**********************************************************************************************************
	 * @Objective: The below method is created to start and stop the E2BImportScheduler.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void importSchedulerRestart() {

		ToolManager.agMouseHover(AdministrationPageObjects.administrationHover);
		ServerAdministrationOperations.menuNavigation("schedulers");
		ToolManager.agClick(SchedulersPageObjects.stopE2BImportScheduler);
		ToolManager.agClick(SchedulersPageObjects.okButton);
		ToolManager.agClick(SchedulersPageObjects.startE2BImportScheduler);
		ToolManager.agClick(SchedulersPageObjects.okButton);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Scheduler option from the menu
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Sagar S
	 * @Date : 04-02-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void selectSchedulers(String schedulerName) {

		ServerAdministrationOperations.menuNavigation("schedulers");
		

	}
	
	/**********************************************************************************************************
	 * @Objective: Select sub menu Search policies from Administrators
	 * @InputParameters:Sub menu
	 * @OutputParameters:
	 * @author:Chithuraj
	 * @Date : 24-01-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void selectSearchPolicies(String subMenu) {
		ToolManager.agMouseHover(AdministrationPageObjects.administrationHover);
		ApplicationConfigSearchPolices.menuNavigation(subMenu);
	}


}
