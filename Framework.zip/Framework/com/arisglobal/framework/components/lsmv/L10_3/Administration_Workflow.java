package com.arisglobal.framework.components.lsmv.L10_3;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.Administration_Workflow;
import com.arisglobal.framework.components.lsmv.L10_3.ApplicationConfigOperations;
import com.arisglobal.framework.components.lsmv.L10_3.OR.ApplicationConfig_WorkFlowPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.AdministrationPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.AdministrationWorkflowPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.WorkFlowPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Administration_Workflow extends ToolManager {
	public static WebElement webElement;
	static String className = Administration_Workflow.class.getSimpleName();
	static boolean status;
	
	/**********************************************************************************************************
	 * @Objective: The below method is created configure ISP case processing
	 *             workflow
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 20-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void configureISPCaseProcessingWorkflow(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		agIsVisible("wrkflowList:adminformId");
		agClick(AdministrationWorkflowPageObjects.editISPWorkflow);
		agWaitTillVisibilityOfElement(AdministrationWorkflowPageObjects.ISPCaseProcessingBreadcrumb);
		agClick(AdministrationWorkflowPageObjects.clickConfiguration);
		agWaitTillVisibilityOfElement(AdministrationWorkflowPageObjects.activityAndTransactions);
		agClick(AdministrationWorkflowPageObjects
				.setSectionName(getTestDataCellValue(scenarioName, "ActivityAndTransaction")));
		agIsVisible(AdministrationWorkflowPageObjects.intakeAndAssessmentBreadcrumb);
		agClick(AdministrationWorkflowPageObjects.SetActivity(getTestDataCellValue(scenarioName, "WorkflowActivity")));
		agClick(AdministrationWorkflowPageObjects
				.SelectAssessmentType(getTestDataCellValue(scenarioName, "AssessmentType")));
		agClick(AdministrationWorkflowPageObjects.saveConfiguration);
		agWaitTillInvisibilityOfElement(AdministrationWorkflowPageObjects.processingLoader);
		agIsVisible(AdministrationWorkflowPageObjects.popUpHeader);
		agAssertVisible(AdministrationWorkflowPageObjects.saveMessage);

		status = agIsVisible(AdministrationWorkflowPageObjects.saveMessage);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Workflow ISP Case Processing Workflow updated successfully",
					true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Workflow ISP Case Processing Workflow not updated successfully",
					true);
		}

		CommonOperations.takeScreenShot();
		agClick(AdministrationWorkflowPageObjects.okButton);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created Edit ISP case processing workflow
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date :05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void EditISPCaseProcessingWorkflow() {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Workflow ISP Case Processing Started", true);
			for (int i = 0; i < 5; i++) {
				if (agIsVisible(AdministrationWorkflowPageObjects.ISPCaseProcessingWorkflow) == true) {
					agClick(AdministrationWorkflowPageObjects.editISPWorkflow);
					agWaitTillVisibilityOfElement(AdministrationWorkflowPageObjects.ISPCaseProcessingBreadcrumb);
					agClick(AdministrationWorkflowPageObjects.clickConfiguration);
					agWaitTillVisibilityOfElement(AdministrationWorkflowPageObjects.activityAndTransactions);
					break;
				} else {
					agClick(AdministrationWorkflowPageObjects.NextPage);
				}
				Reports.ExtentReportLog("", Status.INFO, "Workflow ISP Case Processing Ended", true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Navigate till Workflow Fails", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is Read Workflow Activity Configuration
	 * @InputParameters: Scenario Name,ActivityName
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date :05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void ReadWorkflowActivityMainandConfigurations(String scenarioName, String ActivityName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Read Workflow Main & Configuration Started", true);
			String className = "WorkflowConfigurations";
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			Administration_Workflow.NavigateActivityTabs(ActivityName);
			Reports.ExtentReportLog("", Status.INFO, "Navigate to " + ActivityName, true);
			agClick(WorkFlowPageObjects.activityName_TextBox);		
			String ActivityNameTextBox = agGetAttribute("value", WorkFlowPageObjects.activityName_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ActivityName",
					ActivityNameTextBox);
			// agClick(WorkFlowPageObjects.ActivityType_Label);
			String ActivityType = agGetText(WorkFlowPageObjects.ActivityType_Label);
			if (ActivityType.equalsIgnoreCase("--Select--")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ActivityType", "");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ActivityType",
						ActivityType);
			}
			// agClick(WorkFlowPageObjects.ActivityID_TextBox);
			agGetAttribute("value", WorkFlowPageObjects.ActivityID_TextBox);
			String ActivityID = agGetAttribute("value", WorkFlowPageObjects.ActivityID_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ActivityID", ActivityID);

			agClick(WorkFlowPageObjects.sequence_TextBox);
			String Sequence = agGetAttribute("value", WorkFlowPageObjects.sequence_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Sequence", Sequence);

			if(!scenarioName.equalsIgnoreCase("Check_Case_Nullified")) {
				String CompletionRule = agGetText(WorkFlowPageObjects.completionRule_Label);
				if (CompletionRule.equalsIgnoreCase("--Select--")) {
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CompletionRule", "");
				} else {
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CompletionRule",
							CompletionRule);
				}
			}else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CompletionRule",
						"Disable");
			}
//			String TransitionRule = agGetText(WorkFlowPageObjects.transitionRule_Label);
//
//			if (TransitionRule.equalsIgnoreCase("--Select--")) {
//				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "TransitionRule", "");
//			} else {
//				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "TransitionRule",
//						TransitionRule);
//			}
			String AutoCompletionRule;
			if (ActivityName.equalsIgnoreCase("Initial")) {
				AutoCompletionRule = agGetText(WorkFlowPageObjects.autoCompletionRule_Label);
			} else {

				AutoCompletionRule = agGetText(WorkFlowPageObjects.autocompletionRule_div);
			}
			if (AutoCompletionRule.equalsIgnoreCase("--Select--")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AutoCompletionRule",
						"");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AutoCompletionRule",
						AutoCompletionRule);
			}

			String OnSucessTransition = agGetText(WorkFlowPageObjects.onSuccessTransition_Dropdown);

			if (OnSucessTransition.equalsIgnoreCase("--Select--")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "OnSucessTransition",
						"");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "OnSucessTransition",
						AutoCompletionRule);
			}
			String OnFailureTransition = agGetText(WorkFlowPageObjects.onFailureTransition_Dropdown);
			if (OnFailureTransition.equalsIgnoreCase("--Select--")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "OnFailureTransition",
						"");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "OnFailureTransition",
						AutoCompletionRule);
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.allowManualLock_Label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualLockCheckBox", "Yes");

			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowManualLockCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.autoComplete_Label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AutoCompleteCheckBox",
						"Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AutoCompleteCheckBox",
						"No");
			}
			if (agIsVisible(
					WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.generateCaseQualityScore_Label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"GenerateCaseQualityScoreCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"GenerateCaseQualityScoreCheckBox", "No");
			}
			if (agIsVisible(
					WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.enableSumissionTracking_Label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"GenerateDistributionListCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"GenerateDistributionListCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.isInCriticalPath)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IsinCriticalPathCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IsinCriticalPathCheckBox", "No");
			}
			if (agIsVisible(
					WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.generateCaseSummary_Label)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"GenerateCaseSummaryCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"GenerateCaseSummaryCheckBox", "No");
			}

			/////////// Configurations/////////////////
			agClick(WorkFlowPageObjects.ConfigurationsTab);
			agSetStepExecutionDelay("3000");
			Reports.ExtentReportLog("", Status.INFO, "Read Values in Configuration Tab", true);
			////////////////////////////////////////
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.investigationActivity)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"InvestigationActivityCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"InvestigationActivityCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.restrictLocalDocView)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"RestrictLocalDocumentViewCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"RestrictLocalDocumentViewCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.onSave)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "OnSaveCheckBox",
						"Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "OnSaveCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.onCompleteActivity)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"OnCompleteActivityCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"OnCompleteActivityCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(WorkFlowPageObjects.preliminaryInvestigationActivity)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"PreliminaryInvestigationActivityCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"PreliminaryInvestigationActivityCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.updateVTASynonyms)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"UpdateVTASynonymsCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"UpdateVTASynonymsCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.allowApprovedCaseEdit)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowApprovedCaseEditCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowApprovedCaseEditCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.stopForSampling)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"StopforsamplingCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"StopforsamplingCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.followUpCaseAutoMerge)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"FollowUpCaseAutoMergeCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"FollowUpCaseAutoMergeCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.followUpCaseAutoMerge)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"FollowUpCaseAutoMergeCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"FollowUpCaseAutoMergeCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.initialDataAssessment)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"InitialDataAssessmentCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"InitialDataAssessmentCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.fullDataAssessment)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"FullDataAssessmentCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"FullDataAssessmentCheckBox", "No");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.autoDataAssessment)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AutoDataAssessmentCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AutoDataAssessmentCheckBox", "No");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.allowDeletion)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AllowDeletionCheckBox",
						"Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AllowDeletionCheckBox",
						"No");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.deletionActivity)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DeletionActivityCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DeletionActivityCheckBox", "No");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.GenerateNarrative)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"GenerateNarrativeCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"GenerateNarrativeCheckBox", "No");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.submitUncodedTerms)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"SubmitUncodedTermsCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"SubmitUncodedTermsCheckBox", "No");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.restrictDataPrivacy)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"RestrictPrivacyDataAccessCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"RestrictPrivacyDataAccessCheckBox", "No");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.localCorrespondenceView)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"LocalCorrespondenceViewCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"LocalCorrespondenceViewCheckBox", "No");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.allowCompareReconcileFU)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowCompareReconcileFollowUpCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowCompareReconcileFollowUpCheckBox", "No");
			}
			
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.paralleWorkflowStarts)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ParallelWorkflowStartsCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ParallelWorkflowStartsCheckBox", "No");
			}
			
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.waitForChildWorkflow)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"WaitforChildWorkflowCheckbox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"WaitforChildWorkflowCheckbox", "No");
			}
			
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.japanNonCase)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"JapanNonCaseCheckbox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"JapanNonCaseCheckbox", "No");
			}
			
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.japanNonCase)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"JapanNonCaseCheckbox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"JapanNonCaseCheckbox", "No");
			}
			
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.nonCaseActivity)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"NonCaseActivityCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"NonCaseActivityCheckBox", "No");
			}
			
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.notifyfollowupcaseonCompleteActivity)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"NotifyfollowupcaseCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"NotifyfollowupcaseCheckBox", "No");
			}
					
			
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.rejectXMLReceipt)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"RejectXMLReceiptCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"RejectXMLReceiptCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.EventDescription)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"GenerateNarativeCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"GenerateNarativeCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.Medicalhisory)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"MedicalHistoryCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"MedicalHistoryCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.CompanyRemarks)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"CompanyRemarksCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"CompanyRemarksCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.PharmacologicalComments)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"PharmacologicalCommentsCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"PharmacologicalCommentsCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.AdditionalComments)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AdditionalCommentsCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AdditionalCommentsCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.sendForReprocessing)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"SendforReprocessingCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"SendforReprocessingCheckBox", "No");
			}
			if (agIsVisible(
					WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.allowAddingDistributionContacts)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowAddingDistributionContactsCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowAddingDistributionContactsCheckBox", "No");
			}
			if (agIsVisible(
					WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.distributionInTransitActivity)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IsDistributionInTransitActivityCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"IsDistributionInTransitActivityCheckBox", "No");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.allowDistribution)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowRedistributionCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowRedistributionCheckBox", "No");
			}
			Reports.ExtentReportLog("", Status.INFO, "Read Values in Transition", true);
			if (ActivityName.equalsIgnoreCase("Initial")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.Initial_SendToIA);

				Administration_Workflow.TransitionActivityWrite("Initial_IntakeAndAssessment");

				agClick(WorkFlowPageObjects.Initial_SendToNonCase);

				Administration_Workflow.TransitionActivityWrite("Initial_NonCase");

			} else if (ActivityName.equalsIgnoreCase("Non Case")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.NonCase_SendToIA);

				Administration_Workflow.TransitionActivityWrite("Non_Case_IntakeAndAssessment");

				agClick(WorkFlowPageObjects.NonCase_SendToExit);

				Administration_Workflow.TransitionActivityWrite("Non_Case_Exit");

			} else if (ActivityName.equalsIgnoreCase("Intake and Assessment")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.IA_SendToReview);

				Administration_Workflow.TransitionActivityWrite("Intake_Assessment_Review");

				agClick(WorkFlowPageObjects.IA_SendToTranslation);

				Administration_Workflow.TransitionActivityWrite("Intake_Assessment_Translation");

				agClick(WorkFlowPageObjects.IA_SendToNonCase);

				Administration_Workflow.TransitionActivityWrite("Intake_Assessment_NonCase");

			} else if (ActivityName.equalsIgnoreCase("Translation")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.Translation_SendToIA);

				Administration_Workflow.TransitionActivityWrite("Translation_IntakeAndAssessment");

				agClick(WorkFlowPageObjects.Translation_SendToReview);

				Administration_Workflow.TransitionActivityWrite("Translation_Review");

			} else if (ActivityName.equalsIgnoreCase("Review")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.Review_SendToFDE);

				Administration_Workflow.TransitionActivityWrite("Review_FullDataEntry");

				agClick(WorkFlowPageObjects.Review_SendToNonCase);

				Administration_Workflow.TransitionActivityWrite("Review_NonCase");

				agClick(WorkFlowPageObjects.Review_SendToIA);

				Administration_Workflow.TransitionActivityWrite("Review_IntakeAndAssessment");

			} else if (ActivityName.equalsIgnoreCase("Full Data Entry")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.FDE_SendToQltyReview);

				Administration_Workflow.TransitionActivityWrite("Full_Data_Entry_QualityReview");

			} else if (ActivityName.equalsIgnoreCase("Quality Review")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
			
				agClick(WorkFlowPageObjects.QR_SendToMedicalReview);
				
				Administration_Workflow.TransitionActivityWrite("Quality_Review_MedicalReview");

				agClick(WorkFlowPageObjects.QR_SendToFDE);

				Administration_Workflow.TransitionActivityWrite("Quality_Review_FullDataEntry");
				
			} else if (ActivityName.equalsIgnoreCase("Medical Review")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.MR_SendToFinalReview);

				Administration_Workflow.TransitionActivityWrite("Medical_Review_FinalReview");

				agClick(WorkFlowPageObjects.MR_SendToSuppReview);

				Administration_Workflow.TransitionActivityWrite("Medical_Review_SupplementalReview");

				agClick(WorkFlowPageObjects.MR_SendToFDE);

				Administration_Workflow.TransitionActivityWrite("Medical_Review_FullDataEntry");

			} else if (ActivityName.equalsIgnoreCase("Supplemental Review")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.SR_SendToMedicalReview);

				Administration_Workflow.TransitionActivityWrite("Supplemental_Review_MedicalReview");

				agClick(WorkFlowPageObjects.SR_SendToFullDataEntry);

				Administration_Workflow.TransitionActivityWrite("Supplemental_Review_FullDataEntry");
				
				agClick(WorkFlowPageObjects.SR_SendToFinalReview);
				
				Administration_Workflow.TransitionActivityWrite("Supplemental_Review_FinalReview");

			} else if (ActivityName.equalsIgnoreCase("Final Review")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.FR_SendToCaseApproval);

				Administration_Workflow.TransitionActivityWrite("Final_Review_CaseApproval");

				agClick(WorkFlowPageObjects.FR_SendToFullDataEntry);

				Administration_Workflow.TransitionActivityWrite("Final_Review_FullDataEntry");

				agClick(WorkFlowPageObjects.FR_SendToMedicalReview);

				Administration_Workflow.TransitionActivityWrite("Final_Review_MedicalReview");

			} else if (ActivityName.equalsIgnoreCase("Case Approval (Auto)")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.CA_SendToDistriute);

				Administration_Workflow.TransitionActivityWrite("Case_Approval_Distribute");

				agClick(WorkFlowPageObjects.CA_JapanCaseReportableToPDA);

				Administration_Workflow.TransitionActivityWrite("Case_Approval_PMDA");

			} else if (ActivityName.equalsIgnoreCase("Distribute")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.Distribute_SendToDistribute);

				Administration_Workflow.TransitionActivityWrite("Distribute_DistributeTransit");

			} else if (ActivityName.equalsIgnoreCase("Distribute Transit")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.DT_SendToExit);

				Administration_Workflow.TransitionActivityWrite("Distribute_Transit_Exit");

				agClick(WorkFlowPageObjects.DT_SendToMinorChange);

				Administration_Workflow.TransitionActivityWrite("Distribute_Transit_MinorChange");

			} else if (ActivityName.equalsIgnoreCase("Minor Change")) {
				
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				
				agClick(WorkFlowPageObjects.MC_SendToDistribute);

				Administration_Workflow.TransitionActivityWrite("Minor_Change_DistributeTransit");

			} else if (ActivityName.equalsIgnoreCase("Case Deletion")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.CaseDeletion_DeleteConfirmed);

				Administration_Workflow.TransitionActivityWrite("Case_Deletion_DeleteConfirmed");

				agClick(WorkFlowPageObjects.CaseDeletion_RejectDeletion);

				Administration_Workflow.TransitionActivityWrite("Case_Deletion_RejectDeletion");

			} else if (ActivityName.equalsIgnoreCase("Check Case Nullified")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);

				agClick(WorkFlowPageObjects.CCNullified_SendToDistribute);

				Administration_Workflow.TransitionActivityWrite("Check_Case_Nullified_Distribute");

				agClick(WorkFlowPageObjects.CCNullified_SendToDeletion);

				Administration_Workflow.TransitionActivityWrite("Check_Case_Nullified_Deletion");

			} else if (ActivityName.equalsIgnoreCase("JPN Non Case Data Entry")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.JPNNonCaseDE_SendToNonCase);

				Administration_Workflow.TransitionActivityWrite("JPN_Non_Case_Data_Entry_NonCase");

				agClick(WorkFlowPageObjects.JPNNonCaseDE_NonJPNCaseReportablePMDA);

				Administration_Workflow.TransitionActivityWrite("JPN_Non_Case_Data_Entry_PMDA");
			}
			Reports.ExtentReportLog("", Status.INFO, "Read Workflow Main & Configuration Ends", true);
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Read Configuration Fails", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is Write Workflow Activity Configuration
	 * @InputParameters: Scenario Name,ActivityName
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date :08-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void WriteWorkflowActivityMainandConfigurations(String scenarioName, String ActivityName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Write To Workflow Main & Configuration Started", true);
			String className = "WorkflowConfigurations";
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			Administration_Workflow.NavigateActivityTabs(ActivityName);
			Reports.ExtentReportLog("", Status.INFO, "Navigate to " + ActivityName, true);
			agSetValue(WorkFlowPageObjects.sequence_TextBox, getTestDataCellValue(scenarioName, "Sequence"));

			if (getTestDataCellValue(scenarioName, "CompletionRule").equalsIgnoreCase("")) {

			} else {
				CommonOperations.setListDropDownValue(WorkFlowPageObjects.completionRule_Label,
						getTestDataCellValue(scenarioName, "CompletionRule"));
			}
			if (getTestDataCellValue(scenarioName, "TransitionRule").equalsIgnoreCase("")) {

			} else {
				CommonOperations.setListDropDownValue(WorkFlowPageObjects.transitionRule_Label,
						getTestDataCellValue(scenarioName, "TransitionRule"));
			}

			if (getTestDataCellValue(scenarioName, "AutoCompletionRule").equalsIgnoreCase("")) {

			} else {
				CommonOperations.setListDropDownValue(WorkFlowPageObjects.autoComplete_Label,
						getTestDataCellValue(scenarioName, "AutoCompletionRule"));
			}
			if (getTestDataCellValue(scenarioName, "OnSucessTransition").equalsIgnoreCase("")) {

			} else {
				CommonOperations.setListDropDownValue(WorkFlowPageObjects.onSuccessTransition_Dropdown,
						getTestDataCellValue(scenarioName, "OnSucessTransition"));
			}
			if (getTestDataCellValue(scenarioName, "OnFailureTransition").equalsIgnoreCase("")) {

			} else {
				CommonOperations.setListDropDownValue(WorkFlowPageObjects.onFailureTransition_Dropdown,
						getTestDataCellValue(scenarioName, "OnFailureTransition"));
			}
			//Allow Manual Lock			
			if (getTestDataCellValue(scenarioName, "AllowManualLockCheckBox").equalsIgnoreCase("Yes")) {			
				if (agIsVisible(CommonPageObjects.checkBoxChecked(WorkFlowPageObjects.allowManualLock_Label)) == true) {			
				
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.allowManualLock_Label));	
				}
			}	
			//Auto complete
			if (getTestDataCellValue(scenarioName, "AutoCompleteCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(CommonPageObjects.checkBoxChecked(WorkFlowPageObjects.autoComplete_Label)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.autoComplete_Label));
				}
			}
			//Generate case Qualty Score
			if (getTestDataCellValue(scenarioName, "GenerateCaseQualityScoreCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(CommonPageObjects.checkBoxChecked(WorkFlowPageObjects.generateCaseQualityScore_Label)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.generateCaseQualityScore_Label));
				}
			}
			//Enable Submission Tracking
			if (getTestDataCellValue(scenarioName, "EnableSubmissionTrackingCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(CommonPageObjects.checkBoxChecked(WorkFlowPageObjects.enableSumissionTracking_Label)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.enableSumissionTracking_Label));
				}
			}
			//Is Critical Path
			if (getTestDataCellValue(scenarioName, "IsinCriticalPathCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(CommonPageObjects.checkBoxChecked(WorkFlowPageObjects.isInCriticalPath)) == true) {
				
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.isInCriticalPath));
				}
			}
			//Generate Case Summarry
			if (getTestDataCellValue(scenarioName, "GenerateCaseSummaryCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(CommonPageObjects.checkBoxChecked(WorkFlowPageObjects.generateCaseSummary_Label)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.generateCaseSummary_Label));
				}
			}
			agClick(WorkFlowPageObjects.ConfigurationsTab);
			agSetStepExecutionDelay("3000");
			Reports.ExtentReportLog("", Status.INFO, "Write Values in Configuration Tab", true);
			if (getTestDataCellValue(scenarioName, "RestrictLocalDocumentViewCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.restrictLocalDocView)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.restrictLocalDocView));
				}
			}
			if (getTestDataCellValue(scenarioName, "OnSaveCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.onSave)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.onSave));
				}
			}
			if (getTestDataCellValue(scenarioName, "OnCompleteActivityCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.onCompleteActivity)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.onCompleteActivity));
				}
			}
			
			if (getTestDataCellValue(scenarioName, "InvestigationActivityCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.investigationActivity)) == true) {
				
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.investigationActivity));
				}
			}
			if (getTestDataCellValue(scenarioName, "PreliminaryInvestigationActivityCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.preliminaryInvestigationActivity)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.preliminaryInvestigationActivity));
				}
			}
			if (getTestDataCellValue(scenarioName, "UpdateVTASynonymsCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.updateVTASynonyms)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.updateVTASynonyms));
				}
			}
			if (getTestDataCellValue(scenarioName, "AllowApprovedCaseEditCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.allowApprovedCaseEdit)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.allowApprovedCaseEdit));
				}
			}
			if (getTestDataCellValue(scenarioName, "StopforsamplingCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.stopForSampling)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.stopForSampling));
				}
			}
			if (getTestDataCellValue(scenarioName, "FollowUpCaseAutoMergeCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.followUpCaseAutoMerge)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.followUpCaseAutoMerge));
				}
			}
			if (getTestDataCellValue(scenarioName, "InitialDataAssessmentCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.initialDataAssessment)) == true) {
					
				}else {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.initialDataAssessment));
				}
			}
			if (getTestDataCellValue(scenarioName, "FullDataAssessmentCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.fullDataAssessment)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.fullDataAssessment));
				}
			}
			if (getTestDataCellValue(scenarioName, "AutoDataAssessmentCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.followUpCaseAutoMerge)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.autoDataAssessment));
				}
			}
			if (getTestDataCellValue(scenarioName, "AllowDeletionCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.allowDeletion)) == true) {
					
				}else {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.allowDeletion));
				}
			}
			if (getTestDataCellValue(scenarioName, "DeletionActivityCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.deletionActivity)) == true) {
					
				}else {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.deletionActivity));
				}
			}
			if (getTestDataCellValue(scenarioName, "SubmitUncodedTermsCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.submitUncodedTerms)) == true) {
					
				}else {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.submitUncodedTerms));
				}
			}
			if (getTestDataCellValue(scenarioName, "LocalCorrespondenceViewCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.localCorrespondenceView)) == true) {
					
				}else {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.localCorrespondenceView));
				}
			}

			if (getTestDataCellValue(scenarioName, "GenerateNarrativeCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.GenerateNarrative)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.GenerateNarrative));
				}		
			}
			
			if (getTestDataCellValue(scenarioName, "RestrictPrivacyDataAccessCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.restrictDataPrivacy)) == true) {
					
				}else {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.restrictDataPrivacy));
				}
			}
			if (getTestDataCellValue(scenarioName, "AllowCompareReconcileFollowUpCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.allowCompareReconcileFU)) == true) {
					
				}else {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.allowCompareReconcileFU));
				}
			}
			if (getTestDataCellValue(scenarioName, "LocalCorrespondenceViewCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.localCorrespondenceView)) == true) {
					
				}else {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.localCorrespondenceView));
				}
			}

			if (getTestDataCellValue(scenarioName, "ParallelWorkflowStartsCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.paralleWorkflowStarts)) == true) {
					
				}else {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.paralleWorkflowStarts));
				}
			}
			if (getTestDataCellValue(scenarioName, "WaitforChildWorkflowCheckbox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.waitForChildWorkflow)) == true) {
					
				}else {	
				agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.waitForChildWorkflow));
				}
			}
			if (getTestDataCellValue(scenarioName, "JapanNonCaseCheckbox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.japanNonCase)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.japanNonCase));
				}
			}
			if (getTestDataCellValue(scenarioName, "NotifyfollowupcaseCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.notifyFUcaseonComplete)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.notifyFUcaseonComplete));
				}
			}
			if (getTestDataCellValue(scenarioName, "NonCaseActivityCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.nonCase_Label)) == true) {
				
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.nonCase_Label));
				}
			}
			if (getTestDataCellValue(scenarioName, "RejectXMLReceiptCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.rejectXMLReceipt)) == true) {
					
			}else {	
				agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.rejectXMLReceipt));
				}
			}
			if (getTestDataCellValue(scenarioName, "GenerateNarativeCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.EventDescription)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.EventDescription));
				}
			}
			if (getTestDataCellValue(scenarioName, "MedicalHistoryCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.Medicalhisory)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.Medicalhisory));
				}
			}
			if (getTestDataCellValue(scenarioName, "CompanyRemarksCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.CompanyRemarks)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.CompanyRemarks));
				}
			}
			if (getTestDataCellValue(scenarioName, "PharmacologicalCommentsCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.PharmacologicalComments)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.PharmacologicalComments));
				}
			}
			if (getTestDataCellValue(scenarioName, "AdditionalCommentsCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.AdditionalComments)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.AdditionalComments));
				}
			}
			if (getTestDataCellValue(scenarioName, "SendforReprocessingCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.sendForReprocessing)) == true) {
				
				}else {	
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.sendForReprocessing));
				}
			}
			if (getTestDataCellValue(scenarioName, "AllowAddingDistributionContactsCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.allowAddingDistributionContacts)) == true) {
				
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.allowAddingDistributionContacts));
				}
			}
			if (getTestDataCellValue(scenarioName, "IsDistributionInTransitActivityCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.distributionInTransitActivity)) == true) {
				
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.distributionInTransitActivity));
				}
			}
			if (getTestDataCellValue(scenarioName, "AllowRedistributionCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.allowDistribution)) == true) {
				
				}else {		
				agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.allowDistribution));
				}
			}
			if (getTestDataCellValue(scenarioName, "CreateNewVersionCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.createNewVersionActivity)) == true) {
					
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.createNewVersionActivity));
				}
			}
			if (getTestDataCellValue(scenarioName, "CreateNewVersionCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.createNewVersionActivity)) == true) {
				
				}else {
					agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.createNewVersionActivity));
				}
			}
			Reports.ExtentReportLog("", Status.INFO, "Write Values in Transition", true);
			if (ActivityName.equalsIgnoreCase("Initial")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.Initial_SendToIA);

				Administration_Workflow.TransitionActivityRead("Initial_IntakeAndAssessment");

				agClick(WorkFlowPageObjects.Initial_SendToNonCase);

				Administration_Workflow.TransitionActivityRead("Initial_NonCase");

			} else if (ActivityName.equalsIgnoreCase("Non Case")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.NonCase_SendToIA);

				Administration_Workflow.TransitionActivityRead("Non_Case_IntakeAndAssessment");

				agClick(WorkFlowPageObjects.NonCase_SendToExit);

				Administration_Workflow.TransitionActivityRead("Non_Case_Exit");

			} else if (ActivityName.equalsIgnoreCase("Intake and Assessment")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.IA_SendToReview);

				Administration_Workflow.TransitionActivityRead("Intake_Assessment_Review");

				agClick(WorkFlowPageObjects.IA_SendToTranslation);
				Administration_Workflow.TransitionActivityRead("Intake_Assessment_Translation");

				agClick(WorkFlowPageObjects.IA_SendToNonCase);

				Administration_Workflow.TransitionActivityRead("Intake_Assessment_NonCase");

			} else if (ActivityName.equalsIgnoreCase("Translation")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.Translation_SendToIA);
				
				Administration_Workflow.TransitionActivityRead("Translation_IntakeAndAssessment");
				
				agClick(WorkFlowPageObjects.Translation_SendToReview);
				
				Administration_Workflow.TransitionActivityRead("Translation_Review");

			} else if (ActivityName.equalsIgnoreCase("Review")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.Review_SendToFDE);

				Administration_Workflow.TransitionActivityRead("Review_FullDataEntry");

				agClick(WorkFlowPageObjects.Review_SendToNonCase);

				Administration_Workflow.TransitionActivityRead("Review_NonCase");
				
				agClick(WorkFlowPageObjects.Review_SendToIA);

				Administration_Workflow.TransitionActivityRead("Review_IntakeAndAssessment");

			} else if (ActivityName.equalsIgnoreCase("Full Data Entry")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.FDE_SendToQltyReview);

				Administration_Workflow.TransitionActivityRead("Full_Data_Entry_QualityReview");

			} else if (ActivityName.equalsIgnoreCase("Quality Review")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				
				agClick(WorkFlowPageObjects.QR_SendToMedicalReview);

				Administration_Workflow.TransitionActivityRead("Quality_Review_MedicalReview");
				
				agClick(WorkFlowPageObjects.QR_SendToFDE);

				Administration_Workflow.TransitionActivityRead("Quality_Review_FullDataEntry");

			} else if (ActivityName.equalsIgnoreCase("Medical Review")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.MR_SendToFinalReview);

				Administration_Workflow.TransitionActivityRead("Medical_Review_FinalReview");

				agClick(WorkFlowPageObjects.MR_SendToSuppReview);

				Administration_Workflow.TransitionActivityRead("Medical_Review_SupplementalReview");

				agClick(WorkFlowPageObjects.MR_SendToFDE);

				Administration_Workflow.TransitionActivityRead("Medical_Review_FullDataEntry");

			} else if (ActivityName.equalsIgnoreCase("Supplemental Review")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.SR_SendToMedicalReview);

				Administration_Workflow.TransitionActivityRead("Supplemental_Review_MedicalReview");

				agClick(WorkFlowPageObjects.SR_SendToFullDataEntry);

				Administration_Workflow.TransitionActivityRead("Supplemental_Review_FullDataEntry");
				
				agClick(WorkFlowPageObjects.SR_SendToFinalReview);

				Administration_Workflow.TransitionActivityRead("Supplemental_Review_FinalReview");

			} else if (ActivityName.equalsIgnoreCase("Final Review")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.FR_SendToCaseApproval);

				Administration_Workflow.TransitionActivityRead("Final_Review_CaseApproval");

				agClick(WorkFlowPageObjects.FR_SendToFullDataEntry);

				Administration_Workflow.TransitionActivityRead("Final_Review_FullDataEntry");

				agClick(WorkFlowPageObjects.FR_SendToMedicalReview);

				Administration_Workflow.TransitionActivityRead("Final_Review_MedicalReview");

			} else if (ActivityName.equalsIgnoreCase("Case Approval (Auto)")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.CA_SendToDistriute);

				Administration_Workflow.TransitionActivityRead("Case_Approval_Distribute");

				agClick(WorkFlowPageObjects.CA_JapanCaseReportableToPDA);

				Administration_Workflow.TransitionActivityRead("Case_Approval_PMDA");

			} else if (ActivityName.equalsIgnoreCase("Distribute")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.Distribute_SendToDistribute);

				Administration_Workflow.TransitionActivityRead("Distribute_DistributeTransit");

			} else if (ActivityName.equalsIgnoreCase("Distribute Transit")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);

				agClick(WorkFlowPageObjects.DT_SendToExit);

				Administration_Workflow.TransitionActivityRead("Distribute_Transit_Exit");

				agClick(WorkFlowPageObjects.DT_SendToMinorChange);

				Administration_Workflow.TransitionActivityRead("Distribute_Transit_MinorChange");

			} else if (ActivityName.equalsIgnoreCase("Minor Change")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.MC_SendToDistribute);

				Administration_Workflow.TransitionActivityRead("Minor_Change_DistributeTransit");

			} else if (ActivityName.equalsIgnoreCase("Case Deletion")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.CaseDeletion_DeleteConfirmed);

				Administration_Workflow.TransitionActivityRead("Case_Deletion_DeleteConfirmed");

				agClick(WorkFlowPageObjects.CaseDeletion_RejectDeletion);

				Administration_Workflow.TransitionActivityRead("Case_Deletion_RejectDeletion");

			} else if (ActivityName.equalsIgnoreCase("Check Case Nullified")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);

				agClick(WorkFlowPageObjects.CCNullified_SendToDistribute);

				Administration_Workflow.TransitionActivityRead("Check _Case_Nullified_Distribute");

				agClick(WorkFlowPageObjects.CCNullified_SendToDeletion);

				Administration_Workflow.TransitionActivityRead("Check _Case_Nullified_Deletion");

			} else if (ActivityName.equalsIgnoreCase("JPN Non Case Data Entry")) {
				Administration_Workflow.NavigateActivityTabs(ActivityName);
				agClick(WorkFlowPageObjects.JPNNonCaseDE_SendToNonCase);

				Administration_Workflow.TransitionActivityRead("JPN_Non_Case_Data_Entry_NonCase");

				agClick(WorkFlowPageObjects.JPNNonCaseDE_NonJPNCaseReportablePMDA);

				Administration_Workflow.TransitionActivityRead("JPN_Non_Case_Data_Entry_PMDA");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "write  Configuration Fails", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is Write Workflow Activity Configuration
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date :08-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void TransitionActivityRead(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Write Transition Activity Started", true);
			String className = "WorkflowConfigurations";
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetStepExecutionDelay("4000");
			// agSetValue(WorkFlowPageObjects.transitionName_Textbox,
			// getTestDataCellValue(scenarioName, "TransitionName"));
			agSetValue(WorkFlowPageObjects.SequenceTrans_Textbox, getTestDataCellValue(scenarioName, "TransitionSequence"));

			if (getTestDataCellValue(scenarioName, "dataAssessmentReqCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifySubActCheckBoxClicked(WorkFlowPageObjects.dataAssessmentReq)) == true) {
				
				}else {
					agClick(WorkFlowPageObjects.checkBox(WorkFlowPageObjects.dataAssessmentReq));
				}
			}
			if (getTestDataCellValue(scenarioName, "GenerateDistributeReportsCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifySubActCheckBoxClicked(WorkFlowPageObjects.generateDistributionReports)) == true) {
				
				}else {
				agClick(WorkFlowPageObjects.checkBox(WorkFlowPageObjects.generateDistributionReports));
				}
			}
			if (getTestDataCellValue(scenarioName, "approvedCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifySubActCheckBoxClicked(WorkFlowPageObjects.approved)) == true) {

				}else {
					agClick(WorkFlowPageObjects.checkBox(WorkFlowPageObjects.approved));
				}
			}
			if (getTestDataCellValue(scenarioName, "autoLockCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifySubActCheckBoxClicked(WorkFlowPageObjects.autoLock)) == true) {

				}else {	
					agClick(WorkFlowPageObjects.checkBox(WorkFlowPageObjects.autoLock));
				}
			}
			// if (getTestDataCellValue(scenarioName,
			// "ProposeSubmissionTrackingDepostionCheckBox")
			// .equalsIgnoreCase("Yes")) {
			// agClick(WorkFlowPageObjects.checkBox(WorkFlowPageObjects.ProposeSubmissionTrackingDepostion));
			// }

			if (getTestDataCellValue(scenarioName, "generateDistributionContactsCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifySubActCheckBoxClicked(WorkFlowPageObjects.generateDistributionContacts)) == true) {
				
				}else {
					agClick(WorkFlowPageObjects.checkBox(WorkFlowPageObjects.generateDistributionContacts));
				}
			}
			if (getTestDataCellValue(scenarioName, "generateVariableContactsCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifySubActCheckBoxClicked(WorkFlowPageObjects.generateVariableContacts)) == true) {
					
				}else {	
					agClick(WorkFlowPageObjects.checkBox(WorkFlowPageObjects.generateVariableContacts));
				}
			}
			if (getTestDataCellValue(scenarioName, "generateDistributionReportsCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifySubActCheckBoxClicked(WorkFlowPageObjects.generateDistributionReports)) == true) {
					
				}else {	
					agClick(WorkFlowPageObjects.checkBox(WorkFlowPageObjects.generateDistributionReports));
				}
			}
			if (getTestDataCellValue(scenarioName, "finalEvaluationVariableContactCheckBox").equalsIgnoreCase("Yes")) {
				if (agIsVisible(WorkFlowPageObjects.verifySubActCheckBoxClicked(WorkFlowPageObjects.finalEvaluationVariableContact)) == true) {
					
				}else {	
					agClick(WorkFlowPageObjects.checkBox(WorkFlowPageObjects.finalEvaluationVariableContact));
				}
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.INFO, "Write Transition Activity Ends", true);
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Write Transition Activity fails", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is Write Workflow Activity Configuration
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date :08-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void TransitionActivityWrite(String scenarioName) {
		try {

			Reports.ExtentReportLog("", Status.INFO, "Read Transition Activity Started", true);
			String className = "WorkflowConfigurations";
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetStepExecutionDelay("4000");
			///////////// ------------Transition------------////////////////////////
			agGetAttribute("value", WorkFlowPageObjects.transitionName_Textbox);
			agClick(WorkFlowPageObjects.transitionName_Textbox);
			String transitionName_Textbox = agGetAttribute("value", WorkFlowPageObjects.transitionName_Textbox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "TransitionName",
					transitionName_Textbox);
			
//			String transitionTo = agGetText(WorkFlowPageObjects.transitionTo);
//			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "TransitionTo",
//					transitionTo);
			
			agClick(WorkFlowPageObjects.SequenceTrans_Textbox);
			//String SequenceT = agGetAttribute("value", WorkFlowPageObjects.SequenceTrans_Textbox);
			String SequenceT = agGetText(WorkFlowPageObjects.SequenceTrans_Textbox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "TransitionSequence", SequenceT);

			if (agIsVisible(
					WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.generateDistributionReports)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"GenerateDistributeReportsCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"GenerateDistributeReportsCheckBox", "No");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.dataAssessmentReq)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"dataAssessmentReqCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"dataAssessmentReqCheckBox", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.approved)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "approvedCheckBox",
						"Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "approvedCheckBox",
						"No");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.autoLock)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "autoLockCheckBox",
						"Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "autoLockCheckBox",
						"No");
			}
			if (agIsVisible(WorkFlowPageObjects.checkBoxTick(WorkFlowPageObjects.generateDistributionContacts)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"generateDistributionContactsCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"generateDistributionContactsCheckBox", "No");
			}
			if (agIsVisible(WorkFlowPageObjects.checkBoxTick(WorkFlowPageObjects.generateVariableContacts)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"generateVariableContactsCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"generateVariableContactsCheckBox", "No");
			}
			if (agIsVisible(WorkFlowPageObjects.checkBoxTick(WorkFlowPageObjects.generateDistributionReports)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"generateDistributionReportsCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"generateDistributionReportsCheckBox", "No");
			}		
			if (agIsVisible(WorkFlowPageObjects.checkBoxTick(WorkFlowPageObjects.finalEvaluationVariableContact)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"finalEvaluationVariableContactCheckBox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"finalEvaluationVariableContactCheckBox", "No");
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.INFO, "Read Transition Activity Ends", true);
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Read Transition Activity Fails", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is Write Workflow Activity Configuration
	 * @InputParameters: ActivityName
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date :08-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void NavigateActivityTabs(String ActivityName) {
		if (agIsVisible(WorkFlowPageObjects.MaximizeActivityTabs(ActivityName)) == true) {
			agJavaScriptExecuctorClick(WorkFlowPageObjects.MaximizeActivityTabs(ActivityName));
		}
		agJavaScriptExecuctorClick(WorkFlowPageObjects.ActivityTabs(ActivityName));
		agWaitTillVisibilityOfElement(WorkFlowPageObjects.WfActivityVerify(ActivityName));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is Perform Validations for Rules(Read)
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date :21-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ValidationsRead(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Workflow Validation Read Started", true);
			String className = "WFConfiguration_Validations";
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			String RuleName = Multimaplibraries.getTestDataCellValue(scenarioName, "RuleName");
			String ActivityName = Multimaplibraries.getTestDataCellValue(scenarioName, "WFActivityName");
			Administration_Workflow.NavigateActivityTabs(ActivityName);
			agClick(WorkFlowPageObjects.ValidationBtn);
			agSetStepExecutionDelay("4000");
			Reports.ExtentReportLog("", Status.INFO, "Navigated to Validations Tab", true);

			if (agIsVisible(WorkFlowPageObjects.RuleName(RuleName)) == true) {
				Reports.ExtentReportLog("", Status.INFO, "Rule Name " + RuleName + "Exist", true);
			}

			if (getTestDataCellValue(scenarioName, "OnSaveRadioBtn").equalsIgnoreCase("Warning")) {
				if (agIsVisible(WorkFlowPageObjects.OnSaveWarningRadioBtn(RuleName)) == true) {
					agClick(WorkFlowPageObjects.OnSaveWarningRadioBtn(RuleName));
					Reports.ExtentReportLog("", Status.INFO, "On Save-Warning Radio button Selected", true);
				} else {
					Reports.ExtentReportLog("", Status.INFO, "On Save-Warning Radio button Already Selected", true);
				}

			} else if (getTestDataCellValue(scenarioName, "OnSaveRadioBtn").equalsIgnoreCase("Error")) {
				if (agIsVisible(WorkFlowPageObjects.OnSaveErrorRadioBtn(RuleName)) == true) {
					agClick(WorkFlowPageObjects.OnSaveErrorRadioBtn(RuleName));
					Reports.ExtentReportLog("", Status.INFO, "On Save-Error Radio button Selected", true);
				} else {
					Reports.ExtentReportLog("", Status.INFO, "On Save-Error Radio button Already Selected", true);
				}

			} else if (getTestDataCellValue(scenarioName, "OnSaveRadioBtn").equalsIgnoreCase("#skip#")
					|| getTestDataCellValue(scenarioName, "OnSaveRadioBtn").equalsIgnoreCase("")) {
				Reports.ExtentReportLog("", Status.INFO, "No Option is Selected", true);
			}
			if (getTestDataCellValue(scenarioName, "OnCompleteRadioBtn").equalsIgnoreCase("Warning")) {
				if (agIsVisible(WorkFlowPageObjects.OnCompleteWarningRadioBtn(RuleName)) == true) {
					agClick(WorkFlowPageObjects.OnCompleteWarningRadioBtn(RuleName));
					Reports.ExtentReportLog("", Status.INFO, "On Complete-Warning Radio button Selected", true);
				} else {
					Reports.ExtentReportLog("", Status.INFO, "On Complete-Warning button Already Selected", true);
				}

			} else if (getTestDataCellValue(scenarioName, "OnCompleteRadioBtn").equalsIgnoreCase("Error")) {
				if (agIsVisible(WorkFlowPageObjects.OnCompleteErrorRadioBtn(RuleName)) == true) {
					agClick(WorkFlowPageObjects.OnCompleteErrorRadioBtn(RuleName));
					Reports.ExtentReportLog("", Status.INFO, "On Complete-Error Radio button Selected", true);
				} else {
					Reports.ExtentReportLog("", Status.INFO, "On Complete-Error button Already Selected", true);
				}

			} else if (getTestDataCellValue(scenarioName, "OnCompleteRadioBtn").equalsIgnoreCase("#skip#")
					|| getTestDataCellValue(scenarioName, "OnCompleteRadioBtn").equalsIgnoreCase("")) {
				Reports.ExtentReportLog("", Status.INFO, "No Option is Selected", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.INFO, "Workflow Validation Read ENDS", true);

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Workflow Validation Read Failed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is Perform Validations for Rules(Write)
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date :22-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ValidationsWrite(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Workflow Validation Write Started", true);
			String className = "WFConfiguration_Validations";
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			String RuleName = Multimaplibraries.getTestDataCellValue(scenarioName, "RuleName");
			String ActivityName = Multimaplibraries.getTestDataCellValue(scenarioName, "WFActivityName");
			Administration_Workflow.NavigateActivityTabs(ActivityName);
			agClick(WorkFlowPageObjects.ValidationBtn);
			agSetStepExecutionDelay("4000");
			Reports.ExtentReportLog("", Status.INFO, "Navigated to Validations Tab", true);

			if (agIsVisible(WorkFlowPageObjects.RuleName(RuleName)) == true) {
				Reports.ExtentReportLog("", Status.INFO, "Rule Name " + RuleName + "Exist", true);
			}

			if (agIsVisible(WorkFlowPageObjects.OnSaveWarningRadioBtn(RuleName)) == true) {
				Reports.ExtentReportLog("", Status.INFO, "On Save-Warning Radio button Selected", true);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "OnSaveRadioBtn",
						"Warning");
			}

			else if (agIsVisible(WorkFlowPageObjects.OnSaveErrorRadioBtn(RuleName)) == true) {
				Reports.ExtentReportLog("", Status.INFO, "On Save-Error Radio button Selected", true);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "OnCompleteRadioBtn",
						"Error");
			}

			if (agIsVisible(WorkFlowPageObjects.OnCompleteWarningRadioBtn(RuleName)) == true) {
				Reports.ExtentReportLog("", Status.INFO, "On Complete-Warning Radio button Selected", true);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "OnCompleteRadioBtn",
						"Warning");
			}

			else if (agIsVisible(WorkFlowPageObjects.OnCompleteErrorRadioBtn(RuleName)) == true) {

				Reports.ExtentReportLog("", Status.INFO, "On Complete-Error Radio button Selected", true);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "OnCompleteRadioBtn",
						"Error");
			}

			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.INFO, "Workflow Validation Write ENDS", true);

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Workflow Validation Write Failed", true);
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is Perform to save configuration
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date :17-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void saveConfiguration() {
		agClick(WorkFlowPageObjects.saveButton);
		agSetStepExecutionDelay("5000");
		agIsVisible(WorkFlowPageObjects.ConfirmationPopUp);
		agClick(WorkFlowPageObjects.ConfirmationPopUpOk);
	}
	
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is search Workflow and edit Configuration
	 * @InputParameters: scenarioName,WorkflowName
	 * @OutputParameters:
	 * @author: Rashmi
	 * @Date :19-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void NavigateToCongfigurationMenu()
	{
		agClick(ApplicationConfig_WorkFlowPageObjects.configurationMenuItem_Label);
	}
	
	
	public static void searchAndEditWorkFlow(String ActivityName,String CheckUncheck)
	{
		
		agClick(ApplicationConfig_WorkFlowPageObjects.workflowName(ActivityName)); 
		agClick(ApplicationConfig_WorkFlowPageObjects.configurationLabel); 
		System.out.println(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.restrictLocalDocView)+"--------");
		System.out.println(agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.restrictLocalDocView))+"--------checkbox "); 
		if (CheckUncheck.equalsIgnoreCase("Yes")) {
			if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.restrictLocalDocView)) == true) {
				
			}
			else
			agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.restrictLocalDocView));
		
		}
		if (CheckUncheck.equalsIgnoreCase("No")) {
			if (agIsVisible(WorkFlowPageObjects.verifyCheckBoxClicked(WorkFlowPageObjects.restrictLocalDocView)) == true) {
				agClick(WorkFlowPageObjects.checkBoxLeftOf(WorkFlowPageObjects.restrictLocalDocView));
			}
			else
			{
				
			}
			
		
		}
		saveConfiguration();	
			
		
	}
	
	public static void ConfigureRestrictLocalDoc(String scenarioName,String IsCheck) {
	ApplicationConfigOperations.applicationConfigurationsNavigations("workFlow");
	ApplicationConfigOperations.navigateWorkflowEditScreen(scenarioName);
	Administration_Workflow.NavigateToCongfigurationMenu();
	Administration_Workflow.searchAndEditWorkFlow("Initial",IsCheck);
	Administration_Workflow.searchAndEditWorkFlow("Intake and Assessment",IsCheck);
	Administration_Workflow.searchAndEditWorkFlow("Translation",IsCheck);
	Administration_Workflow.searchAndEditWorkFlow("Review",IsCheck);
	Administration_Workflow.searchAndEditWorkFlow("Full Data Entry",IsCheck);
	Administration_Workflow.searchAndEditWorkFlow("Quality Review",IsCheck);
	Administration_Workflow.searchAndEditWorkFlow("Medical Review",IsCheck); 
	Administration_Workflow.searchAndEditWorkFlow("Supplemental Review",IsCheck);
	Administration_Workflow.searchAndEditWorkFlow("Final Review",IsCheck);
	Administration_Workflow.searchAndEditWorkFlow("Case Approval  Auto ",IsCheck);
	Administration_Workflow.searchAndEditWorkFlow("Distribute",IsCheck);
	Administration_Workflow.searchAndEditWorkFlow("Distribute Transit",IsCheck);
	
	}

	
	
	/**********************************************************************************************************
	 * @Objective: The below method is used to verify ANG AutoGeneration at different workflows
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Chithuraj
	 * @Date :24-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setEventDescANG(String scenarioName,String activityAndTransaction) {
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(AdministrationPageObjects.administrationHover);
		agClick(AdministrationWorkflowPageObjects.workFlow);
		agSetStepExecutionDelay("20000");
		agIsVisible("wrkflowList:adminformId");
		agClick(AdministrationWorkflowPageObjects.editISPWorkflow);
		agWaitTillVisibilityOfElement(AdministrationWorkflowPageObjects.ISPCaseProcessingBreadcrumb);
		agClick(AdministrationWorkflowPageObjects.clickConfiguration);
		
		agWaitTillVisibilityOfElement(AdministrationWorkflowPageObjects.activityAndTransactions);
		eventDescription(scenarioName,activityAndTransaction);
	}	

	public static void eventDescription(String scenarioName,String activityAndTransaction) {
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(AdministrationWorkflowPageObjects
				.setSectionName(activityAndTransaction));
		agClick(WorkFlowPageObjects.ConfigurationsTab);
		String status=Multimaplibraries.getTestDataCellValue(scenarioName, activityAndTransaction);
		if(status.equalsIgnoreCase("check")) {
			if (agIsVisible(WorkFlowPageObjects.checkBoxUnder(WorkFlowPageObjects.EventDescription)) == false) {
				agClick(WorkFlowPageObjects.checkBoxUnder(WorkFlowPageObjects.EventDescription));
				agSetStepExecutionDelay("5000");
				agSelectByVisibleText(WorkFlowPageObjects.edDropdown, "Auto ANG Generation Check");
				agSetStepExecutionDelay("3000");
				Reports.ExtentReportLog("", Status.INFO, "Checked on Event Descriprtion", true);
				saveConfiguration();
				agWaitTillInvisibilityOfElement(AdministrationWorkflowPageObjects.processingLoader);
				agIsVisible(AdministrationWorkflowPageObjects.popUpHeader);
				agAssertVisible(AdministrationWorkflowPageObjects.saveMessage);
			}
		}else {
			
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.EventDescription)) == true) {
				agClick(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.EventDescription));
				Reports.ExtentReportLog("", Status.INFO, "Clicked on Event Descriprtion", true);
				saveConfiguration();
				agWaitTillInvisibilityOfElement(AdministrationWorkflowPageObjects.processingLoader);
				agIsVisible(AdministrationWorkflowPageObjects.popUpHeader);
				agAssertVisible(AdministrationWorkflowPageObjects.saveMessage);
			}	
		}		
		
		
	}
	
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created navigate to Workflow Configuration Tab
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Praveen Patil
	 * @Date :05-March-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void navigateWorkflow_SubTab(String subMenu) {
		switch (subMenu) {
		case "Configuration":
				agWaitTillVisibilityOfElement(AdministrationWorkflowPageObjects.clickConfiguration);
				agClick(AdministrationWorkflowPageObjects.clickConfiguration);
				agWaitTillVisibilityOfElement(AdministrationWorkflowPageObjects.activityAndTransactions);
				Reports.ExtentReportLog("", Status.INFO, "", true);
				break;
				
		case "CaseDueDates":
			
				break;
			
		case "LanguageLabels":
			
				break;
			
		case "Designer":
			
				break;
			
		}

	}
	
	

	/**********************************************************************************************************
	 * @Objective: The below method is to Configure AutoComplete
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Praveen Patil
	 * @Date :05-March-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void congiure_AutoComplete(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String ActiAndTrans = getTestDataCellValue(scenarioName, "ActivityAndTransaction");
		String activities[] = ActiAndTrans.split(",");
		for(int i=0;i<activities.length;i++) {
			agClick(AdministrationWorkflowPageObjects.setSectionName(activities[i]));
			agSetStepExecutionDelay("10000");
			agWaitTillVisibilityOfElement(AdministrationWorkflowPageObjects.clickConfiguration);
			if(getTestDataCellValue(scenarioName, "AutoCompleteCheckBox").equalsIgnoreCase("check")) {
				if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.autoComplete_Label)) == false) {
					agClick(WorkFlowPageObjects.CheckedCheckBox2("Auto Complete"));
					Reports.ExtentReportLog("", Status.INFO, "", true);
				}
			}
			if(getTestDataCellValue(scenarioName, "AutoCompleteCheckBox").equalsIgnoreCase("uncheck")) {
				if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(WorkFlowPageObjects.autoComplete_Label)) == true) {
					agClick(WorkFlowPageObjects.CheckedCheckBox2("Auto Complete"));
					Reports.ExtentReportLog("", Status.INFO, "", true);
				}
			}
		} // End of loop
		
		
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the activity label
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Praveen Patil
	 * @Date :09-March-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyActivityOfCase(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String expectedActivity = getTestDataCellValue(scenarioName, "WorkflowActivity");
			if (agIsVisible(CommonPageObjects.getActivityLabel(expectedActivity)) == true) {
				Reports.ExtentReportLog("", Status.PASS, "Case is in expected Activity :"+expectedActivity, true);
			}else {
				Reports.ExtentReportLog("", Status.FAIL, "Case is not in expected Activity : "+expectedActivity, true);
			}
		}
	
	
}
