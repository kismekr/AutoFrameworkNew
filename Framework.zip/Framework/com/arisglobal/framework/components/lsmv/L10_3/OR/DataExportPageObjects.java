package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class DataExportPageObjects {

	public static String new_Button = "xpath#//a[@id='listingForm:newId']";
	public static String delete_Button = "xpath#//a[@id='listingForm:deleteId']";
	public static String dataExportListingSearch_Textbox = "xpath#//input[@id='listingForm:searchCriteria']";
	public static String search_Icon = "xpath#//a[@id='listingForm:searchbutton']/img";
	public static String paginator = "xpath#//div[@id='listingForm:dataExtractionDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String save_Button = "xpath#//button[@id='qdExtractionDetails:visibleSave']";
	public static String cancel_Button = "xpath#//button[@id='qdExtractionDetails:cancelId']";
	public static String refresh_Icon = "xpath#//a[@id='listingForm:refreshImage']";
	public static String download_Icon = "xpath#//a[@id='listingForm:actionId']/img";
	public static String exporttoExcel_link = "xpath#//button[contains(@id,'listingForm')]/span[text()='Export To Excel']";
	public static String exporttoExcel_popup = "xpath#//span[@id='listingForm:columnSelectionDialogId_title']";
	public static String export_Button = "xpath#//button[@id='listingForm:submitId']";
	public static String exportexcelcancel_Button = "xpath#//button[@id='listingForm:cancelDialogId']";
	public static String dataExtractionLable = "xpath#//span[@class='ui-panel-title']//label[text()='Data Extraction']";
	public static String dataExtractionName_Textbox = "xpath#//input[@id='qdExtractionDetails:deName']";
	public static String dataExtractionStart_Date = "xpath#//span/input[@id='qdExtractionDetails:qdeStartDate_input']";
	public static String dataExtractionEnd_Date = "xpath#//span/input[@id='qdExtractionDetails:qdeEndDate_input']";
	public static String dataExtractionPreviousRun_Date = "xpath#//span/input[@id='qdExtractionDetails:prevRunDate_input']";
	public static String accountsNameLookup_icon = "xpath#//a[@id='qdExtractionDetails:accountNameId:accountLookup']/img";
	public static String accountLookup_label = "xpath#//span[text()='Sender']";
	public static String accountsName_Txtfield = "xpath#//input[@id='accountLookup:accountName']";
	public static String dtdType_Txtfield = "xpath#//input[@id='accountLookup:accountdtdTypeId']";
	public static String lookupSearch_Btn = "xpath#//button[@id='accountLookup:findButton']";
	public static String accountLookup_RadioBtn = "xpath#//td/span[contains(text(),'%s')]/ancestor::tbody/tr/td/div/child::div/span";
	public static String lookupOK_Btn = "xpath#//button[@id='accountLookup:okButton1']";
	public static String description_Textbox = "xpath#//textarea[@id='qdExtractionDetails:description']";
	public static String postMarketRadioBtn = "xpath#//table[@id='qdExtractionDetails:idPostMarket']/tbody/tr/td/div/following-sibling::label[text()='%s']";
	public static String includeCaseVersionRadioBtn = "xpath#//table[@id='qdExtractionDetails:idIncludeCaseVersion']/tbody/tr/td/div/following-sibling::label[text()='%s']";
	public static String reportsHover = "xpath#//a[@class='ui-menuitem-link ui-submenu-link ui-corner-all']//span[@class='ui-menuitem-text'][contains(text(),'Reports')]";
	public static String dataExport = "xpath#//a[@id='headerForm:qdeHistoryId']//span[@class='ui-menuitem-text'][contains(text(),'Data export')]";
	public static String moduleType_dropdown = "Module Type";
	public static String additionalSearchCriteria_dropdown = "Additional Search Criteria";
	public static String publicUse_checkbox = "Public Use";
	public static String exportTypeR2_checkbox = "R2";
	public static String exportTypeR3_checkbox = "R3";
	public static String exportTypeASCII_checkbox = "ASCII";
	public static String click_dropdown = "xpath#//label[contains(@id,'qdExtractionDetails')][contains(text(),'%s')]/following-sibling::div/div[contains(@class,'ui-selectonemenu-trigger')]";
	public static String select_value = "xpath#//ul[contains(@class,'ui-selectonemenu-items')]/child::li[text()='%s']";

	public static String selectRecord_CheckBox = "xpath#//tbody[@id='listingForm:dataExtractionDataTable_data']/tr/child::td/div/div[2]/span";
	public static String recordEdit_icon = "xpath#//tr/td/a[@id='listingForm:dataExtractionDataTable:0:editLink']/img";

	//Delete Prompt Window
	public static String deletePromptMessage = "xpath#//div[@id='listingForm:deleteconfirm']/div/following-sibling::div/div[@class='confmDlgLblBtm']/label";
	public static String deleteConfirm_Button = "xpath#//div[@id='listingForm:removeConfirmdialogPanelGroup']/div/button[@id='listingForm:confirmation_yes']";
	public static String deleteCancel_Button = "xpath#//div[@id='listingForm:removeConfirmdialogPanelGroup']/div/button[@id='listingForm:confirmation_no']";

	//On Submission, acknowledgement pop-up window components
	public static String ackwindowTitle = "xpath#//div/span[@id='mandatoryDialogform:mandatoryID_title']";
	public static String ackwindowErrorTitleText = "xpath#//div/span[text()='Action Completed with Validation Error(s)']";
	public static String ackWindowHeaderText = "xpath#//div/div/span[@id='mandatoryDialogform:mandatoryID_title']";
	public static String ackWindowInfoText = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String ackWindowInfoTextCheck ="xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo'][contains(text(),'ed successfully')]";
	public static String ackWindowInfoOK_button = "xpath#//div[@class='buttonBg']/button[@id='mandatoryDialogform:okButton']";
	
	//Download Reports
	public static String reportR2download_icon = "xpath#//a[@id='listingForm:dataExtractionDataTable:0:downloadLinkForR2']/img";
	public static String reportR3download_icon = "xpath#//a[@id='listingForm:dataExtractionDataTable:0:downloadLinkForR3']/img";
	public static String reportASCIIdownload_icon = "xpath#//a[@id='listingForm:dataExtractionDataTable:0:downloadLinkforAscii']/img";
	
	//Schedule Type
	public static String schedule_CheckBox = "Schedule";
	public static String scheduleType_dropdown = "xpath#//div/label[contains(@id,'schedularDropDown_label')]";
	public static String scheduleType_dropDown_Search = "xpath#//div/input[contains(@name,'schedularDropDown_filter')]";
	
	public static String scheduleType_OneTimeOption = "xpath#//div/ul/li[text()='One Time']";
	public static String scheduleType_DailyOption = "xpath#//div/ul/li[text()='Daily']";
	public static String scheduleType_WeeklyOption = "xpath#//div/ul/li[text()='weekly']";
	
	public static String schedule_OneTime_dateField = "xpath#//div/span[@class='ui-calendar']/input[@id='qdExtractionDetails:j_id_ue_input']";
	public static String schedule_timeField = "xpath#//div/span[@class='ui-calendar']/input[@id='qdExtractionDetails:j_id_ud_input']";
	
	public static String daysLabel = "xpath#//div/label[contains(text(),'Days')]";
	public static String daysCheckBoxes = "xpath#//input/following::label[contains(text(),'{%s}')]";
	
	
	/**********************************************************************************************************
	 * @Objective:The below method is created to set Synonyms text area by passing
	 *                index at runtime.
	 * @Input Parameters: index
	 * @author:Mythri Jain
	 * @Date :15-Sep-2020
	 * @Updated by and when
	 **********************************************************************************************************/

	public static String selectAccountLookupRadioBtn(String runTimeLabel) {
		String value = accountLookup_RadioBtn;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to set include CaseVersion Radio
	 *                Button by passing index at runtime.
	 * @Input Parameters: index
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Mythri Jain
	 * @Date :15-Sep-2020
	 * @Updated by and when
	 **********************************************************************************************************/

	public static String setIncludeCaseVersion(String runTimeLabel) {
		String value = includeCaseVersionRadioBtn;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to set Post Market Radio Button by
	 *                passing index at runtime.
	 * @Input Parameters: index
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Mythri Jain
	 * @Date :15-Sep-2020
	 * @Updated by and when
	 **********************************************************************************************************/

	public static String setPostMarket(String runTimeLabel) {
		String value = postMarketRadioBtn;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to click drop down in Data Extraction
	 *                section by passing label name at runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Mythri Jain
	 * @Date :15-Sep-2020
	 * @Updated by and when
	 **********************************************************************************************************/

	public static String clickdropdown(String runTimeLabel) {
		String value = click_dropdown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select dropdown value by passing
	 *                value at runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name:
	 * @Output Parameters:
	 * @author:Mythri Jain
	 * @Date :15-Sep-2020
	 * @Updated by and when
	 **********************************************************************************************************/

	public static String selectDropdownvalue(String runTimeLabel) {
		String value = select_value;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: To select a desired Days check box
	 * @InputParameters: Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 02-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String checkDays (String daysVal) {
		String value1 = daysCheckBoxes;
		String value2 = value1.replace("{%s}", daysVal);
		return value2;
	}

}
