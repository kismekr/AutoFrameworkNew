package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AccountsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.AdministrationCompanyUnitPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AdministrationCompanyUnit extends ToolManager {

	static String className = AdministrationCompanyUnit.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Company Unit.
	 * @InputParameters: Scenario Name
	 * @OutputParameters: Boolean
	 * @author:Naresh
	 * @Date : 06-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean searchCompanyUnit(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(AdministrationCompanyUnitPageObjects.keywordSearchTextbox,
				getTestDataCellValue(scenarioName, "SearchText"));
		agClick(AdministrationCompanyUnitPageObjects.keywordSearchIcon);
		agSetStepExecutionDelay("2000");
		CommonOperations.takeScreenShot();
		agWaitTillVisibilityOfElement(AdministrationCompanyUnitPageObjects.paginator);
		String paginator = agGetText(AdministrationCompanyUnitPageObjects.paginator);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.PASS,
					"Search Result with '" + getTestDataCellValue(scenarioName, "SearchText") + "' exists!", true);
			return true;
		} else
			return false;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Edit Searched Company Unit.
	 * @InputParameters: NA
	 * @OutputParameters: NA
	 * @author:Naresh
	 * @Date : 06-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void editCompanyUnit() {
		agClick(AdministrationCompanyUnitPageObjects.editIcon);
		agAssertVisible(AdministrationCompanyUnitPageObjects.unitCodeTextBox);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create Company Unit.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 06-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createCompanyUnit(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(AdministrationCompanyUnitPageObjects.newButton);
		setCompanyUnitGeneral(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Company Unit General data.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 24-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCompanyUnitGeneral(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(AdministrationCompanyUnitPageObjects.unitCodeTextBox,
				getTestDataCellValue(scenarioName, "UnitCode"));
		agSetValue(AdministrationCompanyUnitPageObjects.unitNameTextbox,
				getTestDataCellValue(scenarioName, "UnitName"));
		agSetStepExecutionDelay("3000");
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.typeDropdown,
				getTestDataCellValue(scenarioName, "Type"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.companyUnitTypeDropdown,
				getTestDataCellValue(scenarioName, "CompanyUnitType"));
		agSetValue(AdministrationCompanyUnitPageObjects.buildingNoTextbox,
				getTestDataCellValue(scenarioName, "BuildingNumber"));
		agSetValue(AdministrationCompanyUnitPageObjects.streetAddressTextbox,
				getTestDataCellValue(scenarioName, "StreetAddress"));
		agSetValue(AdministrationCompanyUnitPageObjects.cityTextbox, getTestDataCellValue(scenarioName, "City"));
		agSetValue(AdministrationCompanyUnitPageObjects.stateTextbox, getTestDataCellValue(scenarioName, "State"));
		agSetValue(AdministrationCompanyUnitPageObjects.postCodeTextbox,
				getTestDataCellValue(scenarioName, "Postcode"));
		agSetValue(AdministrationCompanyUnitPageObjects.extnTextbox, getTestDataCellValue(scenarioName, "Extn"));
		agSetStepExecutionDelay("3000");
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.countryDropdown,
				getTestDataCellValue(scenarioName, "Country"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.takeScreenShot();
		agSetValue(AdministrationCompanyUnitPageObjects.regionTextbox, getTestDataCellValue(scenarioName, "Region"));
		agSetValue(AdministrationCompanyUnitPageObjects.faxCountryCodeTextbox,
				getTestDataCellValue(scenarioName, "FaxCountryCode"));
		agSetValue(AdministrationCompanyUnitPageObjects.faxAreaCodeTextbox,
				getTestDataCellValue(scenarioName, "FaxAreaCode"));
		agSetValue(AdministrationCompanyUnitPageObjects.faxNumberTextbox,
				getTestDataCellValue(scenarioName, "FaxNumber"));
		agSetValue(AdministrationCompanyUnitPageObjects.phoneCountryCodeTextbox,
				getTestDataCellValue(scenarioName, "PhoneCountryCode"));
		agSetValue(AdministrationCompanyUnitPageObjects.phoneAreaCodeTextbox,
				getTestDataCellValue(scenarioName, "PhoneAreaCode"));
		agSetValue(AdministrationCompanyUnitPageObjects.phoneNumberTextbox,
				getTestDataCellValue(scenarioName, "PhoneNumber"));
		agSetValue(AdministrationCompanyUnitPageObjects.emailIDTextbox, getTestDataCellValue(scenarioName, "EmailID"));

		CommonOperations.clickRadioButton("Is Distribution Contact?",
				getTestDataCellValue(scenarioName, "IsDistributionContact"));
		CommonOperations.clickRadioButton("ICSR Exchange Partner?",
				getTestDataCellValue(scenarioName, "ICSRExchangePartner"));

		/*
		 * agSetValue(AdministrationCompanyUnitPageObjects.interChangeIDTextbox,
		 * getTestDataCellValue(scenarioName, "InterchangeID"));
		 */
		agJavaScriptExecuctorSendKeys(AdministrationCompanyUnitPageObjects.interChangeIDTextbox,
				getTestDataCellValue(scenarioName, "InterchangeID"));
		agSetStepExecutionDelay("3000");
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.dtdCorresDropdown,
				getTestDataCellValue(scenarioName, "DTDforCorrespondence"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(AdministrationCompanyUnitPageObjects.senderOrgTextbox,
				getTestDataCellValue(scenarioName, "SenderOrganization"));
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.senderOrgTypeDropdown,
				getTestDataCellValue(scenarioName, "SenderOrganizationType"));
		switch (getTestDataCellValue(scenarioName, "SenderOrganizationType")) {
		case "Interchange ID":
			agSetValue(AdministrationCompanyUnitPageObjects.interChangeIDTextbox,
					getTestDataCellValue(scenarioName, "InterchangeID"));
			break;
		case "Sender Organization":
			agSetValue(AdministrationCompanyUnitPageObjects.senderOrgTextbox,
					getTestDataCellValue(scenarioName, "SenderOrganization"));
			break;
		}
		CommonOperations.clickCheckBoxLeftOf("Compounding Outsourcing Facility 503B",
				getTestDataCellValue(scenarioName, "CompoundingOutsourcingFacility503B"));
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify Company Unit General data.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 24-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCompanyUnitGeneral(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(AdministrationCompanyUnitPageObjects.unitCodeTextBox);
		CommonOperations.takeScreenShot();
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "UnitCode"),
				AdministrationCompanyUnitPageObjects.unitCodeTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "UnitName"),
				AdministrationCompanyUnitPageObjects.unitNameTextbox);
		// agCheckPropertyText(getTestDataCellValue(scenarioName, "Type"),
		// AdministrationCompanyUnitPageObjects.typeDropdown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "CompanyUnitType"),
				AdministrationCompanyUnitPageObjects.companyUnitTypeDropdown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "BuildingNumber"),
				AdministrationCompanyUnitPageObjects.buildingNoTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "StreetAddress"),
				AdministrationCompanyUnitPageObjects.streetAddressTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "City"),
				AdministrationCompanyUnitPageObjects.cityTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "State"),
				AdministrationCompanyUnitPageObjects.stateTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Postcode"),
				AdministrationCompanyUnitPageObjects.postCodeTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Extn"),
				AdministrationCompanyUnitPageObjects.extnTextbox);
		// agCheckPropertyText(getTestDataCellValue(scenarioName, "Country"),
		// AdministrationCompanyUnitPageObjects.countryDropdown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Region"),
				AdministrationCompanyUnitPageObjects.regionTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FaxCountryCode"),
				AdministrationCompanyUnitPageObjects.faxCountryCodeTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FaxAreaCode"),
				AdministrationCompanyUnitPageObjects.faxAreaCodeTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FaxNumber"),
				AdministrationCompanyUnitPageObjects.faxNumberTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PhoneCountryCode"),
				AdministrationCompanyUnitPageObjects.phoneCountryCodeTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PhoneAreaCode"),
				AdministrationCompanyUnitPageObjects.phoneAreaCodeTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PhoneNumber"),
				AdministrationCompanyUnitPageObjects.phoneNumberTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "EmailID"),
				AdministrationCompanyUnitPageObjects.emailIDTextbox);
		agJavaScriptExecuctorScrollToElement(AdministrationCompanyUnitPageObjects.interChangeIDTextbox);
		CommonOperations.takeScreenShot();
		CommonOperations.verifyRadioButton("Is Distribution Contact?",
				getTestDataCellValue(scenarioName, "IsDistributionContact"));
		CommonOperations.verifyRadioButton("ICSR Exchange Partner?",
				getTestDataCellValue(scenarioName, "ICSRExchangePartner"));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "InterchangeID"),
				AdministrationCompanyUnitPageObjects.interChangeIDTextbox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "DTDforCorrespondence"),
				AdministrationCompanyUnitPageObjects.dtdCorresDropdown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "SenderOrganization"),
				AdministrationCompanyUnitPageObjects.senderOrgTextbox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "SenderOrganizationType"),
				AdministrationCompanyUnitPageObjects.senderOrgTypeDropdown);
		switch (getTestDataCellValue(scenarioName, "SenderOrganizationType")) {
		case "Interchange ID":
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "InterchangeID"),
					AdministrationCompanyUnitPageObjects.interChangeIDTextbox);
			break;
		case "Sender Organization":
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "SenderOrganization"),
					AdministrationCompanyUnitPageObjects.senderOrgTextbox);
			break;
		}
		CommonOperations.verifyCheckBoxLeftOf("Compounding Outsourcing Facility 503B",
				getTestDataCellValue(scenarioName, "CompoundingOutsourcingFacility503B"));
		agJavaScriptExecuctorScrollToElement(AdministrationCompanyUnitPageObjects.senderOrgTextbox);
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Department data.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 13-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDepartmentGrid(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, "BoolAllDepartments").trim().contains("#skip#")
				&& !getTestDataCellValue(scenarioName, "BoolAllDepartments").equalsIgnoreCase("false")) {
			CommonOperations.clickCheckBoxLeftOf("All Departments",
					getTestDataCellValue(scenarioName, "BoolAllDepartments"));
		} else if (!getTestDataCellValue(scenarioName, "BoolAddDepartment").trim().contains("#skip#")
				&& !getTestDataCellValue(scenarioName, "BoolAddDepartment").equalsIgnoreCase("false")) {
			agSetStepExecutionDelay("3000");
			CommonOperations.clickAddDivOf("Department");
			agAssertVisible(AdministrationCompanyUnitPageObjects.departmentNameTextbox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CommonOperations.agwaitTillVisible(AdministrationCompanyUnitPageObjects.departmentNameTextbox, 1, 1000);
			agSetValue(AdministrationCompanyUnitPageObjects.departmentNameTextbox,
					getTestDataCellValue(scenarioName, "Department"));
			agSetValue(AdministrationCompanyUnitPageObjects.deptEmailTextbox,
					getTestDataCellValue(scenarioName, "DepartmentEmailAddress"));
			agClick(AdministrationCompanyUnitPageObjects.deptSearchButton);
			agSetStepExecutionDelay("5000");
			agClick(AdministrationCompanyUnitPageObjects.deptSearchResultsChkbox);
			// CommonOperations.clickCheckBoxLeftOf(getTestDataCellValue(scenarioName,
			// "Department"), "true");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CommonOperations.takeScreenShot();
			agClick(AdministrationCompanyUnitPageObjects.deptOkButton);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify Department data.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 15-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDepartment(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, "BoolAllDepartments").trim().contains("#skip#")
				&& !getTestDataCellValue(scenarioName, "BoolAllDepartments").equalsIgnoreCase("false")) {
			CommonOperations.verifyCheckBoxLeftOf("All Departments",
					getTestDataCellValue(scenarioName, "BoolAllDepartments"));
		}

		else if (!getTestDataCellValue(scenarioName, "BoolAddDepartment").trim().contains("#skip#")
				&& !getTestDataCellValue(scenarioName, "BoolAddDepartment").equalsIgnoreCase("false")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Department"),
					(AdministrationCompanyUnitPageObjects.deptartmentNameLabel).replace("%rowNo%",
							getTestDataCellValue(scenarioName, "DepartmentRowNo")));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Company Unit.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 15-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCompanyUnitGrid(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, "BoolAddCompanyUnit").trim().contains("#skip#")
				&& !getTestDataCellValue(scenarioName, "BoolAddCompanyUnit").equalsIgnoreCase("false")) {
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorScrollDown();
			CommonOperations.clickAddDivOf("Company Unit");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agSetValue(
					(AdministrationCompanyUnitPageObjects.domainNameTextbox).replace("%rowNo%",
							getTestDataCellValue(scenarioName, "DomainNameRowNo")),
					getTestDataCellValue(scenarioName, "DomainName"));
			CommonOperations.setListDropDownValue(
					(AdministrationCompanyUnitPageObjects.companyUnitDropdown).replace("%rowNo%",
							getTestDataCellValue(scenarioName, "CompanyUnitRowNo")),
					getTestDataCellValue(scenarioName, "CompanyUnit"));
		}
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify Company Unit.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 15-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCompanyUnitGrid(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, "BoolAddCompanyUnit").trim().contains("#skip#")
				&& !getTestDataCellValue(scenarioName, "BoolAddCompanyUnit").equalsIgnoreCase("false")) {
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "DomainName"),
					(AdministrationCompanyUnitPageObjects.domainNameTextbox).replace("%rowNo%",
							getTestDataCellValue(scenarioName, "DomainNameRowNo")));
			agCheckPropertyText(getTestDataCellValue(scenarioName, "CompanyUnit"),
					(AdministrationCompanyUnitPageObjects.companyUnitDropdown).replace("%rowNo%",
							getTestDataCellValue(scenarioName, "CompanyUnitRowNo")));
		}
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Submission workflow.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 13-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSubmissionWorkflow(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.submissionWorkflowDropdown,
				getTestDataCellValue(scenarioName, "SubmissionWorkflow"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify Submission workflow.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 15-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySubmissionWorkflow(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "SubmissionWorkflow"),
				AdministrationCompanyUnitPageObjects.submissionWorkflowDropdown);
		agJavaScriptExecuctorScrollToElement(AdministrationCompanyUnitPageObjects.submissionWorkflowDropdown);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Complaint workflow.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 13-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setComplaintWorkflow(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.complaintWorkflowDropdown,
				getTestDataCellValue(scenarioName, "ComplaintWorkflow"));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Tracker Settings.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 13-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setTrackerSettings(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(AdministrationCompanyUnitPageObjects.receiptNoFormatTextbox,
				getTestDataCellValue(scenarioName, "ReceiptNumberingFormat"));
		agSetStepExecutionDelay("3000");
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.receiptNoDateFomateDropdown,
				getTestDataCellValue(scenarioName, "ReceiptNoDateFormat"));
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.receiptNoDateSepDropdown,
				getTestDataCellValue(scenarioName, "ReceiptNoDateSeperator"));
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.receiptNoResetSeqDropdown,
				getTestDataCellValue(scenarioName, "ReceiptResetSequenceBy"));
		agSetValue(AdministrationCompanyUnitPageObjects.lrnNoFormatTextbox,
				getTestDataCellValue(scenarioName, "LRNNumberingFormat"));
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.lrnNoDateFormatDropdown,
				getTestDataCellValue(scenarioName, "LRNNoDateFormat"));
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.lrnNoDateSepDropdown,
				getTestDataCellValue(scenarioName, "LRNNoDateSeperator"));
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.lrnNoResetSeqDropdown,
				getTestDataCellValue(scenarioName, "LRNResetSequenceBy"));
		agSetValue(AdministrationCompanyUnitPageObjects.callLogNoFormatTextbox,
				getTestDataCellValue(scenarioName, "CallLogNumberingFormat"));
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.callLogDateFormatDropdown,
				getTestDataCellValue(scenarioName, "CallLogDateFormat"));
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.callLogDateSepDropdown,
				getTestDataCellValue(scenarioName, "CallLogDateSeperator"));
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.callLogResetSeqDropdown,
				getTestDataCellValue(scenarioName, "CallLogResetSequenceBy"));
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.aeWorkflowDropdown,
				getTestDataCellValue(scenarioName, "AEWorkflow"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.clickCheckBoxLeftOf("Default Company Unit for Portal AEs",
				getTestDataCellValue(scenarioName, "DefaultCompanyUnitforPortalAEs"));
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify Tracker Settings.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 15-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyTrackerSettings(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ReceiptNumberingFormat"),
				AdministrationCompanyUnitPageObjects.receiptNoFormatTextbox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ReceiptNoDateFormat"),
				AdministrationCompanyUnitPageObjects.receiptNoDateFomateDropdown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ReceiptNoDateSeperator"),
				AdministrationCompanyUnitPageObjects.receiptNoDateSepDropdown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ReceiptResetSequenceBy"),
				AdministrationCompanyUnitPageObjects.receiptNoResetSeqDropdown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "LRNNumberingFormat"),
				AdministrationCompanyUnitPageObjects.lrnNoFormatTextbox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "LRNNoDateFormat"),
				AdministrationCompanyUnitPageObjects.lrnNoDateFormatDropdown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "LRNNoDateSeperator"),
				AdministrationCompanyUnitPageObjects.lrnNoDateSepDropdown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "LRNResetSequenceBy"),
				AdministrationCompanyUnitPageObjects.lrnNoResetSeqDropdown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "CallLogNumberingFormat"),
				AdministrationCompanyUnitPageObjects.callLogNoFormatTextbox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "CallLogDateFormat"),
				AdministrationCompanyUnitPageObjects.callLogDateFormatDropdown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "CallLogDateSeperator"),
				AdministrationCompanyUnitPageObjects.callLogDateSepDropdown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "CallLogResetSequenceBy"),
				AdministrationCompanyUnitPageObjects.callLogResetSeqDropdown);
		CommonOperations.setListDropDownValue(AdministrationCompanyUnitPageObjects.aeWorkflowDropdown,
				getTestDataCellValue(scenarioName, "AEWorkflow"));
		CommonOperations.verifyCheckBoxLeftOf("Default Company Unit for Portal AEs",
				getTestDataCellValue(scenarioName, "DefaultCompanyUnitforPortalAEs"));
		agJavaScriptExecuctorScrollToElement(AdministrationCompanyUnitPageObjects.receiptNoFormatTextbox);
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify Case Due Date Calculation
	 *             Configuration For Case Triage.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 13-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCaseDueDateForTriage(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "RuleName"),
				(AdministrationCompanyUnitPageObjects.ruleNameDropdown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "RuleNameRowNo")));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Date"),
				(AdministrationCompanyUnitPageObjects.dateDropdown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "DateRowNo")));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "DueInDays"),
				(AdministrationCompanyUnitPageObjects.dueInDaysTextbox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "DueInDaysRowNo")));
		agJavaScriptExecuctorScrollToElement(
				(AdministrationCompanyUnitPageObjects.ruleNameDropdown).replace("%rowNo%", "0"));
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Add Case Due Date Calculation
	 *             Configuration For Case Triage.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 13-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCaseDueDateForTriage(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.clickAddDivOf("Case Due Date Calculation Configuration For Case Triage");
		CommonOperations.setListDropDownValue(
				(AdministrationCompanyUnitPageObjects.ruleNameDropdown).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "RuleNameRowNo")),
				getTestDataCellValue(scenarioName, "RuleName"));
		CommonOperations.setListDropDownValue((AdministrationCompanyUnitPageObjects.dateDropdown).replace("%rowNo%",
				getTestDataCellValue(scenarioName, "DateRowNo")), getTestDataCellValue(scenarioName, "Date"));
		agSetValue(
				(AdministrationCompanyUnitPageObjects.dueInDaysTextbox).replace("%rowNo%",
						getTestDataCellValue(scenarioName, "DueInDaysRowNo")),
				getTestDataCellValue(scenarioName, "DueInDays"));
		agJavaScriptExecuctorScrollToElement(
				(AdministrationCompanyUnitPageObjects.ruleNameDropdown).replace("%rowNo%", "0"));
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add contacts details.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 16-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addContact(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "boolAdd_Contacts").equalsIgnoreCase("true")) {
			agSetStepExecutionDelay("3000");
			CommonOperations.clickAddDivOf(AdministrationCompanyUnitPageObjects.contacts_Label);

			agSetValue(AccountsPageObjects.contactIdTextbox, getTestDataCellValue(scenarioName, "Contacts_ContactId"));
			CommonOperations.setListDropDownValue(AccountsPageObjects.countryDropdown,
					getTestDataCellValue(scenarioName, "Contacts_Country"));
			agSetValue(AccountsPageObjects.firstNameTextbox, getTestDataCellValue(scenarioName, "Contacts_FirstName"));
			agSetValue(AccountsPageObjects.middleNameTextbox,
					getTestDataCellValue(scenarioName, "Contacts_MiddleName"));
			agSetValue(AccountsPageObjects.lastNameTextbox, getTestDataCellValue(scenarioName, "Contacts_LastName"));
			agSetValue(AccountsPageObjects.emailAddressTextbox,
					getTestDataCellValue(scenarioName, "Contacts_EmailAddress"));
			CommonOperations.setListDropDownValue(AccountsPageObjects.specializationDropdown,
					getTestDataCellValue(scenarioName, "Contacts_Specialization"));
			CommonOperations.setListDropDownValue(AccountsPageObjects.departmentDropdown,
					getTestDataCellValue(scenarioName, "Contacts_Department"));
			agSetValue(AccountsPageObjects.interchangeIdTextbox,
					getTestDataCellValue(scenarioName, "Contacts_InterchangeId"));
			CommonOperations.clickCheckBoxRightOf(AccountsPageObjects.isAlsoAnE2BContact,
					getTestDataCellValue(scenarioName, "Contacts_IsAlsoAnE2BContact"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.PASS, "Contact Lookup Details Entered", true);

			agClick(AccountsPageObjects.searchContactButton);
			agSetStepExecutionDelay("5000");
			agClick(CommonPageObjects.selectListingCheckbox(getTestDataCellValue(scenarioName, "Contacts_FirstName")));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agClick(AccountsPageObjects.okContactButton);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add contacts details in Contact
	 *             grid.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 16-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addContactsGridDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Contact_Primary").equalsIgnoreCase("true")) {
			agClick((AdministrationCompanyUnitPageObjects.checkPrimary).replace("%s",
					getTestDataCellValue(scenarioName, "Contacts_FirstName")));
		}
		if (getTestDataCellValue(scenarioName, "Contact_E2BContacts").equalsIgnoreCase("true")) {
			agClick((AdministrationCompanyUnitPageObjects.checkE2BContacts).replace("%s",
					getTestDataCellValue(scenarioName, "Contacts_FirstName")));
			agSetStepExecutionDelay("3000");
			agSetValue(
					(AdministrationCompanyUnitPageObjects.interchangeIDTextbox).replace("%rowNo%",
							getTestDataCellValue(scenarioName, "RowNo_Contact")),
					getTestDataCellValue(scenarioName, "Contact_InterchangeID"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		if (getTestDataCellValue(scenarioName, "Contact_Distribute").equalsIgnoreCase("true")) {
			agClick((AdministrationCompanyUnitPageObjects.checkDistribute).replace("%s",
					getTestDataCellValue(scenarioName, "Contacts_FirstName")));
		}

		agJavaScriptExecuctorScrollToElement(AdministrationCompanyUnitPageObjects.contacts_Div);
		Reports.ExtentReportLog("", Status.PASS, "Contacts Grid Section Details Entered", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete Case Due Date Calculation
	 *             Configuration For Case Triage.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 13-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteCaseDueDateForTriage(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.clickCheckBoxLeftOf(getTestDataCellValue(scenarioName, "RuleNameRowNo"), "true");
		CommonOperations.clickDeleteDivOf("Case Due Date Calculation Configuration For Case Triage");
		CommonOperations.setDeleteAuditInfo("Delete_CompanyUnit");
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Upload product corpus file.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 13-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void uploadCompProdCorpusFile(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(AdministrationCompanyUnitPageObjects.uploadCompProdCorpusFileButton, lsmvConstants.LSMV_testDataInput
				+ "//" + getTestDataCellValue(scenarioName, "UploadCompanyProductCorpusFile"));
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Search and Create company unit.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 13-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreateCompanyUnit(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		boolean searchResults = searchCompanyUnit(scenarioName);
		if (searchResults == false) {
			createCompanyUnit(scenarioName);
			setDepartmentGrid(scenarioName);
			setCompanyUnitGrid(scenarioName);
			setSubmissionWorkflow(scenarioName);
			setTrackerSettings(scenarioName);
			setCaseDueDateForTriage(scenarioName);
			addContact(scenarioName);
			addContactsGridDetails(scenarioName);
			agClick(AdministrationCompanyUnitPageObjects.saveButton);
			CommonOperations.setAuditInfo("Create_CompanyUnit");
			searchAndVerifyCompanyUnit(scenarioName);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Search and Updated Administration
	 *             >> Company Unit.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 15-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndUpdateCompanyUnit(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		boolean searchResults = searchCompanyUnit(scenarioName);
		if (searchResults == true) {
			editCompanyUnit();
			setCompanyUnitGeneral(scenarioName);
			agClick(AdministrationCompanyUnitPageObjects.saveButton);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Search and Verify company unit.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh
	 * @Date : 13-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndVerifyCompanyUnit(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		boolean searchResults = searchCompanyUnit(scenarioName);
		if (searchResults == false) {
		} else {
			editCompanyUnit();
			verifyCompanyUnitGeneral(scenarioName);
			verifyDepartment(scenarioName);
			verifyCompanyUnitGrid(scenarioName);
			verifySubmissionWorkflow(scenarioName);
			verifyTrackerSettings(scenarioName);
			verifyCaseDueDateForTriage(scenarioName);
			agClick(AdministrationCompanyUnitPageObjects.cancelButton);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit and delete Company unit.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Naresh S
	 * @Date : 15-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndDeleteCompanyUnit(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		boolean searchResults = searchCompanyUnit(scenarioName);
		if (searchResults) {
			agWaitTillVisibilityOfElement(CommonPageObjects.checkCompanyUnitList(getTestDataCellValue(scenarioName, "SearchText")));
			agClick(CommonPageObjects.checkCompanyUnitList(getTestDataCellValue(scenarioName, "SearchText")));
			agSetStepExecutionDelay("5000");
			agClick(AdministrationCompanyUnitPageObjects.deleteButton);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CommonOperations.setDeleteCompanyUnitAuditInfo("Delete_CompanyUnit");
		}
		boolean deleteSearchResults = searchCompanyUnit(scenarioName);
		if (deleteSearchResults) {
			Reports.ExtentReportLog("", Status.FAIL,
					"Company Unit with name " + getTestDataCellValue(scenarioName, "SearchText") + " is not deleted",
					true);
		} else {
			Reports.ExtentReportLog("", Status.PASS,
					"Company Unit with name " + getTestDataCellValue(scenarioName, "SearchText") + " is deleted", true);
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method will verify the email ID present in transport setting screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Padmapriya
	 * @Date : 25-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyEmailID_TransportSettings() {
		agClick(AdministrationCompanyUnitPageObjects.transportSettingsLink);
		agClick(AdministrationCompanyUnitPageObjects.edittransposesettingscu);
		String emailID = agGetText(AdministrationCompanyUnitPageObjects.transportemailid);
		Reports.ExtentReportLog("", Status.PASS,
				"Email Address found " + emailID, true);
		
	}
}
