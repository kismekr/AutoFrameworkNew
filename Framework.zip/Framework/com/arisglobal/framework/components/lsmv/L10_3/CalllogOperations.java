package com.arisglobal.framework.components.lsmv.L10_3;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.CalllogPageObjects;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.aventstack.extentreports.Status;

public class CalllogOperations extends ToolManager{
	public static WebElement webElement;
	static String className = CalllogOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to perform menu navigation in Calllog module
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void menuNavigation(String subMenu) {
		agMouseHover(CalllogPageObjects.calllogHover);
		agClick(CalllogPageObjects.calllogMenuNavigations(subMenu));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to perform menu navigation in Calllog module and verify each menu based on label name
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void calllog_MenuNavigations(String menu){

			switch (menu) {
			case "calllogNew":
				menuNavigation("Calllog new");
				 status = agIsVisible(CalllogPageObjects.calllogNewLable);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to calllog New is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to calllog New is Unsuccessfull", true);
				}
				break;
			case "calllogListing":
				menuNavigation("Calllog listing");
				 status = agIsVisible(CalllogPageObjects.calllogNewButton);
				if (status) {
					Reports.ExtentReportLog("", Status.PASS, "Navigation to calllog Listing is successfull", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Navigation to calllog Listing is Unsuccessfull", true);
				}
				break;
				
			default:
				System.out.println("Invalid Menu Link!");

	}
}}