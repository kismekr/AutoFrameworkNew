package com.arisglobal.framework.components.lsmv.L10_3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.arisglobal.framework.components.lsmv.L10_3.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.DocumentsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDEFormCopyWindowPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDEMoreOptionsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_CaseDocumentsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_SplitCasePageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_SplitCase extends ToolManager {
	static boolean status;
	static String className = FDE_SplitCase.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();

	/**********************************************************************************************************
	 * @Objective: The below method will write copied receipt number to datasheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 24-jun-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void writeSplitReceiptNo(String scenarioName) {
		status = agIsVisible(FDE_SplitCasePageObjects.SplitCaseReceiptNumber);
		if (status) {
			String SplitReceiptNumber = agGetText(FDE_SplitCasePageObjects.SplitCaseReceiptNumber);
			String[] arrOfStr = SplitReceiptNumber.split("Successfully created '");
			arrOfStr = arrOfStr[1].split("' receipt item");
			SplitReceiptNumber = arrOfStr[0].toString().trim();
			String[] SplitStr = SplitReceiptNumber.split(", ");
			System.out.println(SplitStr[0]);
			System.out.println(SplitStr[1]);
			
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
			String RecieptNumberPrefix =getTestDataCellValue("LSMV_ISP_Config", "ReceiptPrefix");
			
			if(SplitStr[0].contains(RecieptNumberPrefix)) {
				Reports.ExtentReportLog("", Status.PASS, "Receipt Numbering Format - Prefix is getting Mapped in Created Split 1 Reciept Number", true);
				
			}else {
				Reports.ExtentReportLog("", Status.FAIL, "Receipt Numbering Format - Prefix is getting Mapped in Created Split 1 Reciept Number", true);
			}
			
			if(SplitStr[1].contains(RecieptNumberPrefix)) {
				Reports.ExtentReportLog("", Status.PASS, "Receipt Numbering Format - Prefix is getting Mapped in Created Split 2 Reciept Number", true);
				
			}else {
				Reports.ExtentReportLog("", Status.FAIL, "Receipt Numbering Format - Prefix is getting Mapped in Created Split 2 Reciept Number", true);
			}
			
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SplitReceiptNumber1",
					SplitStr[0]);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SplitReceiptNumber2",
					SplitStr[1]);
			Reports.ExtentReportLog("Copy case", Status.PASS,
					"Split case creation successfull :: receiptNumber-" + SplitReceiptNumber, true);

		} else {
			Reports.ExtentReportLog("Split case", Status.FAIL, "Split Case  creation unsuccessfull", true);
		}

		agJavaScriptExecuctorClick(FDE_SplitCasePageObjects.okButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method Upload Source Document(one files)
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :05-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void UploadSourceDocument(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(DocumentsPageObjects.CaseDocumentBtn);
		agClick(DocumentsPageObjects.AddDocBtn);
		agSetStepExecutionDelay("3000");
		agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile("1"), lsmvConstants.LSMV_testDataInput + "\\"
				+ getTestDataCellValue(scenarioName, "SourceDocs_DocDescription"));
		agSetStepExecutionDelay("5000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully) == true) {
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.actComp_Sucessfully);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.ActionOkBtn);
			agClick(FullDataEntryFormPageObjects.ActionOkBtn);
		}
		// agClick(FDE_CaseDocumentsPageObjects.clickDocumentCategory);
		// agClick(FDE_CaseDocumentsPageObjects.setDocumentCategory(getTestDataCellValue(scenarioName,
		// "SourceDocs_DocCategory")));

		Reports.ExtentReportLog("Document one Upload", Status.PASS, "Document one Uploaded successfull ::", true);

		agClick(DocumentsPageObjects.AddDocBtn);
		agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile("2"), lsmvConstants.LSMV_testDataInput + "\\"
				+ getTestDataCellValue(scenarioName, "SourceDocs_DocDescription1"));

		agSetStepExecutionDelay("5000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully) == true) {
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.actComp_Sucessfully);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.ActionOkBtn);
			agClick(FullDataEntryFormPageObjects.ActionOkBtn);
		}

		// agClick(FDE_CaseDocumentsPageObjects.clickDocumentCategoryFile2);
		// agClick(FDE_CaseDocumentsPageObjects.setDocumentCategoryFile2(getTestDataCellValue(scenarioName,
		// "SourceDocs_DocCategory")));

		Reports.ExtentReportLog("Document two Upload", Status.PASS, "Document two Uploaded successfull ::", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to verify added Source Document in
	 *             Case Documents Section after Split.
	 * @InputParameters: scenarioName, index
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @Date : 19-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifySourceUploadDocumentSplit(String scenarioName) {
		agClick(DocumentsPageObjects.CaseDocumentBtn);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (agGetText(FDE_CaseDocumentsPageObjects.filenameLink)
				.equalsIgnoreCase(getTestDataCellValue(scenarioName, "SourceDocs_DocDescription")) == true) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "SourceDocs_DocDescription"),
					FDE_CaseDocumentsPageObjects.filenameLink);
			Reports.ExtentReportLog("", Status.PASS, "Source document one is displayed", true);

		} else if (agGetText(FDE_CaseDocumentsPageObjects.filenameLink)
				.equalsIgnoreCase(getTestDataCellValue(scenarioName, "SourceDocs_DocDescription1")) == true) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "SourceDocs_DocDescription1"),
					FDE_CaseDocumentsPageObjects.filenameLink);
			Reports.ExtentReportLog("", Status.PASS, "Source document two is displayed", true);

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Source document doesnt Exist", true);

		}

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is verify Source Documents in FDE form
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar
	 * @Date : 05-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void sourceDocumentsVerification() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		status = agIsExists(FDE_CaseDocumentsPageObjects.filenameLink);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Source document is displayed", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Source document is not displayed", true);
		}
		if (agIsVisible(FDE_CaseDocumentsPageObjects.filenameLink1) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Source document of Child Case is displayed", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// agCheckPropertyText(getTestDataCellValue(scenarioName, "Filename"),
		// FDE_CaseDocumentsPageObjects.fileName_SourceDoc(index));

	}

	/**********************************************************************************************************
	 * @Objective: The below method will search the case based on Receipt ID and
	 *             edit the case to perform Split case.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 24-jun-2019
	 * @UpdatedByAndWhen:WajahatUmar S
	 **********************************************************************************************************/
	public static void SplitCase(String scenarioName) {
		String RecieptNumber = agGetText(FullDataEntryFormPageObjects.RecptNumber);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		FDE_Operations.MoreOptionsLinksNavigation(FDEMoreOptionsPageObjects.moreOptions("Split"));
		agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.moreOptions("Split"));
		agWaitTillVisibilityOfElement(FDE_SplitCasePageObjects.VerifyReciptNumber);
		agIsVisible(FDE_SplitCasePageObjects.VerifyReciptNumber);
		String VerifyReciptNum = agGetText(FDE_SplitCasePageObjects.VerifyReciptNumber);
		String VerifyReptNo[] = VerifyReciptNum.split("Split Document > ");
		System.out.println(VerifyReptNo[1]);
		agSetStepExecutionDelay("2000");
		// To Verify if Receipt Number in Full Data Entry page Matches with Receipt
		// Number in Copy Case Pop Up
		// agCheckPropertyText(FDE_CopyCase.getData(scenarioName,
		// "ReceiptNo"),FDE_CopyCase.getData(scenarioName, "CopiedReceiptNo"));
		if (RecieptNumber.equalsIgnoreCase(VerifyReptNo[1])) {
			Reports.ExtentReportLog("Receipt No", Status.PASS,
					"Receipt Number " + RecieptNumber + " Matches successfull with ::" + VerifyReptNo[1], true);

		} else {
			Reports.ExtentReportLog("Receipt No", Status.FAIL,
					"Receipt Number " + RecieptNumber + " Doesn't Matches with -" + VerifyReptNo[1], false);
		}
		agClick(FDE_SplitCasePageObjects.SplitBySourceDocument);

		// CommonOperations.clickCheckBoxLeftOf(FDE_SplitCasePageObjects.receiptDetails_CheckBox,
		// getTestDataCellValue(scenarioName, "Receipt Details"));
		// CommonOperations.clickCheckBoxLeftOf(FDE_SplitCasePageObjects.Retain_Classfication_Checkbox,
		// getTestDataCellValue(scenarioName, "Retain Classification"));
		// CommonOperations.clickCheckBoxLeftOf(FDE_SplitCasePageObjects.Correspondence_CheckBox,
		// getTestDataCellValue(scenarioName, "Correspondence"));
		CommonPageObjects.ManualCheckBoxSplit(FDE_SplitCasePageObjects.Supporting_DocumentsCheckbox);

		CommonPageObjects.ManualCheckBoxSplit(FDE_SplitCasePageObjects.Notes_CheckBox);
		if (getTestDataCellValue(scenarioName, "Linked Cases").equalsIgnoreCase("true")) {
			agClick(FDE_SplitCasePageObjects.LinkedCases_CheckBox);
		}
		CommonPageObjects.ManualCheckBoxSplit(FDE_SplitCasePageObjects.OutofWorkflow_Checkbox);
		// CommonOperations.ManualCheckBoxSplit(FDE_SplitCasePageObjects.General_CheckBox,
		// getTestDataCellValue(scenarioName, "General"));
		// CommonOperations.ManualCheckBoxSplit(FDE_SplitCasePageObjects.Source_CheckBox,
		// getTestDataCellValue(scenarioName, "Source"));
		// CommonOperations.ManualCheckBoxSplit(FDE_SplitCasePageObjects.Reporter_CheckBox,
		// getTestDataCellValue(scenarioName, "Reporter"));
		// CommonOperations.ManualCheckBoxSplit(FDE_SplitCasePageObjects.Study_CheckBox,
		// getTestDataCellValue(scenarioName, "Study"));
		// CommonOperations.ManualCheckBoxSplit(FDE_SplitCasePageObjects.Patient_CheckBox,
		// getTestDataCellValue(scenarioName, "Patient"));
		// CommonOperations.ManualCheckBoxSplit(FDE_SplitCasePageObjects.Parent_CheckBox,
		// getTestDataCellValue(scenarioName, "Parent"));
		// CommonOperations.ManualCheckBoxSplit(FDE_SplitCasePageObjects.Product_CheckBox,
		// getTestDataCellValue(scenarioName, "Product(s)"));
		// CommonOperations.ManualCheckBoxSplit(FDE_SplitCasePageObjects.Event_CheckBox,
		// getTestDataCellValue(scenarioName, "Event(s)"));
		// CommonOperations.ManualCheckBoxSplit(FDE_SplitCasePageObjects.Narrative_CheckBox,
		// getTestDataCellValue(scenarioName, "Narrative"));
		// CommonOperations.ManualCheckBoxSplit(FDE_SplitCasePageObjects.Pregnancy_CheckBox,
		// getTestDataCellValue(scenarioName, "Pregnancy"));
		// CommonOperations.ManualCheckBoxSplit(FDE_SplitCasePageObjects.LabData_CheckBox,
		// getTestDataCellValue(scenarioName, "Lab Data"));
		// CommonOperations.ManualCheckBoxSplit(FDE_SplitCasePageObjects.Literature_CheckBox,
		// getTestDataCellValue(scenarioName, "Literature"));

		agSetValue(FDE_SplitCasePageObjects.CommentTextBox, getTestDataCellValue(scenarioName, "CommentTextBox"));
		agWaitTillVisibilityOfElement(FDE_SplitCasePageObjects.SubmitBtn);
		agClick(FDE_SplitCasePageObjects.SubmitBtn);
		agWaitTillVisibilityOfElement(FDEFormCopyWindowPageObjects.okButton);
		writeSplitReceiptNo(scenarioName);

	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Write data into excel sheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 06-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search the created case in case
	 *             listing and edit
	 * @InputParameters: Scenario Name, sheetName, columnName
	 * @OutputParameters:
	 * @author:WajahatUmar
	 * @Date : 09-03-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchCaseAndverify(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		CaseManagementOperations.menuNavigation("Case listing");
		/*
		 * if(agIsVisible(FullDataEntryFormPageObjects.withOutSaveValidation)==true) {
		 * agClick(FullDataEntryFormPageObjects.yesBtn_withOutSaveValidation); }
		 */
		agSetStepExecutionDelay("8000");
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, columnName));
		agClick(CaseListingPageObjects.searchButton);
		// CommonOperations.waitTillCaseVisible();
		agWaitTillVisibilityOfElement(CaseListingPageObjects.receiptNumberlink);

		Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);
		agSetStepExecutionDelay("8000");
		agClick(CaseListingPageObjects.receiptNumberlink);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
	}

	/**********************************************************************************************************
	 * @Objective: The below method Upload Source Document(one files)
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void UploadSingleSourceDocument(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(DocumentsPageObjects.CaseDocumentBtn);
		agClick(DocumentsPageObjects.AddDocBtn);
		agSetStepExecutionDelay("3000");
		agSetValue(FDE_CaseDocumentsPageObjects.sourceDocuments_UploadFile("1"), lsmvConstants.LSMV_testDataInput + "\\"
				+ getTestDataCellValue(scenarioName, "SourceDocs_DocDescription"));
		agSetStepExecutionDelay("5000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully) == true) {
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.actComp_Sucessfully);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.ActionOkBtn);
			agClick(FullDataEntryFormPageObjects.ActionOkBtn);
		}

		Reports.ExtentReportLog("Document one Upload", Status.PASS, "Document Uploaded successfull ::", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to verify added Source Document in
	 *             Case Documents Section after Split.
	 * @InputParameters: scenarioName, index
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @Date : 19-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifySourceUploadDocumentSplitByPageNo(String scenarioName) {
		agClick(DocumentsPageObjects.CaseDocumentBtn);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (agGetText(FDE_CaseDocumentsPageObjects.filenameLink)
				.equalsIgnoreCase(getTestDataCellValue(scenarioName, "SourceDocs_DocDescription")) == true) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "SourceDocs_DocDescription"),
					FDE_CaseDocumentsPageObjects.filenameLink);
			agClick(FDE_CaseDocumentsPageObjects.filenameLink);

			int PgNoRange1 = 0;
			int PgNoRange2 = 0;
			int PgNoRange3 = 0;
			int PgNoRange4 = 0;
			String str_Sampl = getTestDataCellValue(scenarioName, "PageNo");
			String str = str_Sampl.replaceAll("[^\\d]", " ");
			str = str.trim();

			str = str.replaceAll(" +", " ");

			String[] arrOfStr = str.split(" ", str.length());
			// Check if String contains a sequence
			List<String> al = new ArrayList<String>();
			al = Arrays.asList(arrOfStr);

			PgNoRange1 = Integer.parseInt(al.get(0));
			PgNoRange2 = Integer.parseInt(al.get(1));
			PgNoRange3 = Integer.parseInt(al.get(2));
			PgNoRange4 = Integer.parseInt(al.get(3));

			int PgNoRangentered = (PgNoRange2 - PgNoRange1) + 1;
			int PgNoRangentered1 = (PgNoRange4 - PgNoRange3) + 1;
			System.out.println(PgNoRangentered);
			System.out.println(PgNoRangentered1);
			agSetStepExecutionDelay("3000");
			agGetCurrentWindow();

			agClick(FDE_CaseDocumentsPageObjects.PageNoPdf1);
			String PageNoRange1 = agGetAttribute("value", FDE_CaseDocumentsPageObjects.PageNoPdf1);
			String PageNoRange2 = agGetText(FDE_CaseDocumentsPageObjects.PageNoPdf2).replace("of ", "");
			if (PageNoRange1.equalsIgnoreCase("1") && (PageNoRange2.equalsIgnoreCase(String.valueOf(PgNoRangentered))
					|| PageNoRange2.equalsIgnoreCase(String.valueOf(PgNoRangentered1)))) {
				Reports.ExtentReportLog("", Status.PASS, "Split By Page Number Matches", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Split By Page Number not Match", true);
			}
			agCloseCurrentWindow();
			agGetWindowControlByInstance(1);
			agGetCurrentWindow();

			Reports.ExtentReportLog("", Status.PASS, "Source document one is displayed", true);

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Source document doesnt Exist", true);

		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method will search the case based on Receipt ID and
	 *             edit the case to perform Split case by Page.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SplitCaseByPageNo(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			// Create a case
			CaseManagementOperations.caseManagement_MenuNavigations("fullDataEntryForm");

			FDE_General.setCaseUnitsDetails(scenarioName);
			FDE_General.setCaseDates(scenarioName);
			FDE_General.setCaseReportDetails(scenarioName);
			FDE_General.addContact_FDEForm(scenarioName);
			UploadSingleSourceDocument(scenarioName);
			sourceDocumentsVerification();
			FDE_Operations.LSMVSave(scenarioName, "FDE_General");

			String data = FDE_General.getData(scenarioName, "ReceiptNo");
			FDE_SplitCase.setData(scenarioName, "ReceiptNo", data);
			String RecieptNumber = agGetText(FullDataEntryFormPageObjects.RecptNumber);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			FDE_Operations.MoreOptionsLinksNavigation(FDEMoreOptionsPageObjects.moreOptions("Split"));
			agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.moreOptions("Split"));
			Reports.ExtentReportLog("", Status.INFO, "Split Case By Page Number", true);
			agWaitTillVisibilityOfElement(FDE_SplitCasePageObjects.VerifyReciptNumber);
			agIsVisible(FDE_SplitCasePageObjects.VerifyReciptNumber);
			String VerifyReciptNum = agGetText(FDE_SplitCasePageObjects.VerifyReciptNumber);
			String VerifyReptNo[] = VerifyReciptNum.split("Split Document > ");
			agSetStepExecutionDelay("2000");
			// To Verify if Receipt Number in Full Data Entry page Matches with Receipt

			if (RecieptNumber.equalsIgnoreCase(VerifyReptNo[1])) {
				Reports.ExtentReportLog("Receipt No", Status.PASS,
						"Receipt Number " + RecieptNumber + " Matches successfull with ::" + VerifyReptNo[1], true);

			} else {
				Reports.ExtentReportLog("Receipt No", Status.FAIL,
						"Receipt Number " + RecieptNumber + " Doesn't Matches with -" + VerifyReptNo[1], false);
			}
			agSetValue(FDE_SplitCasePageObjects.PageNoTextBox, getTestDataCellValue(scenarioName, "PageNo"));
			agSetValue(FDE_SplitCasePageObjects.CommentTextBox, getTestDataCellValue(scenarioName, "CommentTextBox"));
			agWaitTillVisibilityOfElement(FDE_SplitCasePageObjects.SubmitBtn);
			agClick(FDE_SplitCasePageObjects.SubmitBtn);
			agWaitTillVisibilityOfElement(FDEFormCopyWindowPageObjects.okButton);
			writeSplitReceiptNo(scenarioName);
			Reports.ExtentReportLog("", Status.INFO, "Case has been Splitted by Page Number", true);
			searchCaseAndverify("SplitCase", "FDE_SplitCase", "SplitReceiptNumber1");
			FDE_Operations.tabNavigation("General");
			FDE_General.caseUnits_Verification("SplitCase");
			FDE_General.caseDates_Verification("SplitCase");
			FDE_General.setCaseReportDetails("SplitCase");
			FDE_General.caseReport_Verification("SplitCase");
			FDE_General.contact_Verification("SplitCase");
			verifySourceUploadDocumentSplitByPageNo("SplitCase");

			searchCaseAndverify("SplitCase", "FDE_SplitCase", "SplitReceiptNumber2");
			FDE_Operations.tabNavigation("General");
			FDE_General.caseUnits_Verification("SplitCase");
			FDE_General.caseDates_Verification("SplitCase");
			FDE_General.setCaseReportDetails("SplitCase");
			FDE_General.caseReport_Verification("SplitCase");
			FDE_General.contact_Verification("SplitCase");
			verifySourceUploadDocumentSplitByPageNo("SplitCase");

		} catch (Exception e) {
			Reports.ExtentReportLog("", Status.FAIL, "Split Case By PageNo Failed", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method will search the case based on Receipt ID and
	 *             edit the case to perform Split case by Page.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void CaseCreationthroughSplitFunctionality(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Case Creation throug hSplit Functionality Started", true);
		SplitCaseByPageNo(scenarioName);
		Reports.ExtentReportLog("", Status.INFO, "Case Creation throug hSplit Functionality Ended", true);
	}

}
