package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class CaseSeriesPageObjects {

	public static String saveSeriesBtn = "xpath#//a[@class='critSaveSeries']";
	public static String caseSeriesName = "xpath#//div[@id='htmlSaveCaseSeriesDailog']//input[@id='caseSeriesName']//parent::div";
	public static String caseSeriesVal = "xpath#//div/input[@id='caseSeriesName']";
	public static String saveCaseSeries = "xpath#//div[@id='htmlSaveCaseSeriesDailog']//button[1][@class='btn btn-secondary']";
	public static String saveMessage = "xpath#//div[@id='htmlValidationDailog']//ul[@class='htmlInfoList']";
	public static String saveOkButon = "xpath#//div[@style='text-align: center;']//a[@class='btn btn-secondary']"; 
	public static String validatiomMessage = "xpath#//div[@id='htmlValidationDailog']//ul[@class='htmlValidationList']";
	public static String validationOkButton = "xpath#//div[@id='htmlValidationDailog']//a[@class='btn btn-secondary']";
	public static String closeSaveSeriesPopUp = "xpath#//div[@id='htmlSaveCaseSeriesDailog']//button[2][@class='btn btn-secondary']";
	public static String keywordSearchTextbox = "xpath#//input[@id='CSDL:keyword']";
	public static String searchButton = "xpath#//a[@id='CSDL:searchId']";
	public static String seriesCheckBox = "xpath#//div[@id='CSDL:listPanel']//div[@class='ui-chkbox ui-widget']";		
	public static String deleteSearchedSeries = "xpath#//button[@id='deleteCaseSeries']";
	public static String deleteSeriesYesBtn = "xpath#//button[@id='CSDL:confirmation_yes']";
	public static String completedValidationMessage = "xpath#//span[text()='Action Completed Successfully']";
	public static String actionCompletedOkButton = "xpath#//div[@id='htmlValidationDailog']//a[@class='btn btn-secondary']";
	public static String receiptSearch = "xpath#//div[@id='listingAdvCriteria']//li";
	
	public static String caseSeriesbreadScrumb = "xpath#//label[@class='breadTxt'][text()='Case Series']";
	public static String caseSeriesSearchBox = "xpath#//input[@id='htmlKeywordSearch']";
	public static String searchButton_icon = "xpath#//div[@class='htmlTopSearchBar']/span/a/img";
	public static String searchRecord_chkBx = "xpath#//td/input[@class='tableSelectRow']";
	public static String caseSeriesRecordName_link = "xpath#//tr/td/a[text()='%s']";
	public static String caseRecieptNumber_link = "xpath#//td/a[text()='%s']";
	public static String paginator = "xpath#//div/span[@class='htmlPaginationInfo']";
	public static String Delete_Button = "xpath#//button[@id='deleteCaseSeries']"; 
	
	public static String yes_RadioBtn = "xpath#//span/label[@class='htmlRadioContainer'][contains(text(),'Yes')]";
	public static String no_RadioBtn = "xpath#//span/label[@class='htmlRadioContainer'][contains(text(),'No')]";
	
	public static String confirmation_Info = "xpath#//ul[@class='htmlInfoList']/li";
	public static String confirmationOK_Btn = "xpath#//div/a[@class='btn btn-secondary'][contains(text(),'OK')]";
	
	public static String completedFOIA_icon = "xpath#//td/a[text()='%s']/following::img[@alt='foia_submitted']";
	public static String caseSeriesName_Hyperlink = "xpath#//tr/td/a[text()='%s']";
	public static String caseReceiptNumber_Hyperlink = "xpath#//a[@class='receiptNoSty'][text()='%s']";
	public static String caseAERNumber_Hyperlink = "xpath#//td[@class=' ADL_table_aerNo']/a[text()='%s']";
	public static String refresh_label = "xpath#//div/a/span[text()='Refresh']";
	public static String reportFOIA_icon = "xpath#//td/a[text()='%s']/following::img[@alt='foia_generation_not_done']";
	
	public static String moreActions_HoverBtn = "xpath#//a[text()='More Actions']/parent::span";
	public static String redactedNarrative_Link = "xpath#//span/a[text()='Redacted Narrative']";
	public static String eventDescription_Link = "xpath#//li/a/span[text()='Event Description']";	
	public static String noFROIReady_label = "xpath#//span[@class='agRedactedNarrative']//label[text()='No']";
	public static String redactedNarrative_TxtArea = "xpath#//div/textarea[@id='agTextAreaCounter1']";
	public static String submit_Btn = "xpath#//p-dialog[contains(@class,'agRedacted')]//div/button/span[text()='Submit']";
	public static String info_label = "xpath#//div/span[text()='Info']";
	public static String info_para = "xpath#//div[@class='ui-growl-message']/p";
	public static String infoClose_icon = "xpath#//div[contains(@class,'ui-growl-icon-close')]";
	public static String narrativeClose_icon = "xpath#//div/span[text()='Redacted Narrative']/following-sibling::a";
	public static String backToListing_link = "xpath#//div/a/span[text()='Back to Listing']";
	
	public static String caseSeriesSearch = "xpath#//input[@id='htmlKeywordSearch']";
	public static String searchIcon = "xpath#//a[@onclick='keyWordSearch()']/img";
	public static String searchResult = "xpath#//a[text()='%s']";
	public static String pendingDSURLabellingStatus = "xpath#//label[text()='Pending DSUR Labeling']";
	public static String checkRecord = "xpath#(//td[@class=' htmlSelectChkBox']/input)[1]";
	public static String exportpanelGroup = "xpath#//span[@id='exportPanelGroup']/img";
	public static String DSURLabelling = "xpath#//a[text()=' DSUR Labelling ']";
	public static String DSURLDataSheetHeader  = "xpath#//span[text()='DSUR Labeling Data Sheet(s)']";
	public static String productLookup = "xpath#//div[@class='productSelectDSUR']/a[@class='htmlAdvLookupIcon']";
	public static String productlookUpHeader = "xpath#//span[text()='List of Product']";
	public static String productName = "xpath#//input[@fieldid='PRODUCT_NAME']";
	public static String searchBtn = "xpath#//span[text()='Search']";
	public static String checkProduct = "xpath#//div[@class='lsmv-grid-row']/span[@class='lsmv-grid-chk-sticky lsmv-grid-row-sel-chk lsmv-grid-sel-unchk']";
	public static String productOkBtn = "xpath#//div[@id='targetPanelForPrdLookupGrid']//span[@id='selecctBtnId']";
	public static String dataSheetName = "xpath#//span[text()='%s']";
	public static String selectBtn = "xpath#//span[text()='Select']";
	public static String dsurLabellingMessage = "xpath#//span[text()='DSUR Labeling is in progress. Please refresh the listing to view the updated status']";
	public static String notificationPopUpclose = "xpath#//div[@class='lsmv-info-popup']/div[@id='lsmv-comments-close']";
	
	public static String DSURLebellingReadyStatus = "xpath#//label[text()='DSUR Ready']";
	public static String clickSeries = "xpath#//td[@class=' CSL_table_caseSeriesName']/a";
	public static String columnSelectionClick = "xpath#//img[@title='Column Selection']";
	public static String workflowHeader = "xpath#//label[@id='workflowCurrentText']";
	public static String selectAll = "xpath#//span[@id='lbl_selectAll']//parent::a/span[1]";
	public static String DSURStatus = "xpath#//label[text()='Success']";
	public static String selectDSURCase = "xpath#//a[text()='%s']";
	public static String caseloader = "xpath#//img[@id='adverseEventNew:j_id_pk']";
	public static String caseWorkFLowHeader  = "xpath#//div[@id='adverseEventNew:panelGroupTop']";
	
	public static String dataSheetName(String DataSheet) {
		String value = dataSheetName;
		String value2;
		value2 = value.replace("%s", DataSheet);
		return value2;
	}
	
	public static String caseSeries(String SeriesName) {
		String value = searchResult;
		String value2;
		value2 = value.replace("%s", SeriesName);
		return value2;
	}
	public static String selectCase(String ReceiptNO) {
		String value = selectDSURCase;
		String value2;
		value2 = value.replace("%s", ReceiptNO);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective:The below method is created to set caseSeriesRecordName_link locator at runtime.
	 * @Input Parameters: Record Name from the Data sheet
	 * @author: Shamanth S
	 * @Date : 05-Oct-2020
	 * @Updated by and when: 
	 **********************************************************************************************************/

	public static String setCaseSeriesRecordNameLocator(String recordName) {
		String value = caseSeriesRecordName_link;
		String value2;
		value2 = value.replace("%s", recordName);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective:The below method is written to build locators a dynamically
	 * @Input Parameters: Partial Locator and record value from test sheet 
	 * @author: Shamanth S
	 * @Date : 13-Oct-2020
	 * @Updated by and when: 
	 **********************************************************************************************************/

	public static String buildCaseLocators(String Locator, String receiptName) {
		String value = Locator;
		String value2;
		value2 = value.replace("%s", receiptName);
		return value2;
	}
	
}
