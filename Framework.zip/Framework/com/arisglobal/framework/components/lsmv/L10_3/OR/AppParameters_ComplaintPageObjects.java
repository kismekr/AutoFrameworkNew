package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class AppParameters_ComplaintPageObjects {

	/////////////////////////////// Administration >> System Administration >>
	/////////////////////////////// Application Parameters >> Complaint
	/////////////////////////////// //////////////////////////////
	/////////////////////////////////////////////////// Complaint
	/////////////////////////////// ////////////////////////////////////////////////////////////////

	public static String complaintNumberingFormat_TextBox = "xpath#//input[@id ='applicationParameterForm:receiptNumberingFormatIdCmp']";
	public static String complaintNumberingFormat1_DropDown = "xpath#//div[@id='applicationParameterForm:maskByComplaints']//label";
	public static String complaintNumberingFormat2_DropDown = "xpath#//div[@id='applicationParameterForm:Icmp-5009']//label";
	public static String complaintNumberingFormat3_DropDown = "xpath#//div[@id='applicationParameterForm:dateSepCmp']//label";
	public static String complaintResetSequenceBy_DropDown = "xpath#//div[@id='applicationParameterForm:resetSequenceByMenuCmp']//label";
	public static String recallsNumberingFormat_TextBox = "xpath#//input[@id ='applicationParameterForm:receiptNumberingFormatIdRecalls']";
	public static String recallsNumberingFormat1_DropDown = "xpath#//div[@id='applicationParameterForm:maskByRecalls']//label";
	public static String recallsNumberingFormat2_DropDown = "xpath#//div[@id='applicationParameterForm:RE-5009']//label";
	public static String recallsNumberingFormat3_DropDown = "xpath#//div[@id='applicationParameterForm:dateSepRecalls']//label";
	public static String recallResetSequenceBy_DropDown = "xpath#//div[@id='applicationParameterForm:resetSequenceByMenuRecalls']//label";
	public static String archiveComplaintsOlderThan_TextBox = "xpath#//input[@id ='applicationParameterForm:archiveCmpinput']";
	public static String archiveComplaintsOlderThanUnit_DropDown = "xpath#//div[@id='applicationParameterForm:cmp-5064']//label";
	public static String setEndDateforPreliminaryInvestigationByDays_TextBox = "xpath#//input[@id ='applicationParameterForm:complaintEnddateForPreliminaryInvestigation']";
	public static String setEndDateforInvestigationByDays_TextBox = "xpath#//input[@id ='applicationParameterForm:complaintEnddateForPreliminaryInvestigation']";
	public static String standardAEValidation_CheckBox = "Standard AE Validation";
	public static String enableAutoSave_Radio = "Enable Auto Save";
	public static String autoSaveComplaintinSec_TextBox = "xpath#//input[@id ='applicationParameterForm:autoSaveComplaint']";
	public static String productMandatoryforComplaint_CheckBox = "Product Mandatory for Complaint";
	public static String enableEditChecks_CheckBox = "Enable Edit Checks";
	public static String dueDateCalculation_Radio = "Due Date Calculation";
	public static String Yes = "Yes";
	public static String No = "No";

	/////////////////////////////////////////////////// Complaint >> Response Due
	/////////////////////////////////////////////////// Days
	/////////////////////////////////////////////////// ////////////////////////////////////////////////////////////////

	public static String responseDueDays_Label = "Response Due Days";
	public static String responseDueDays_Div = "xpath#//label[contains(@id, 'applicationParameterForm') and contains(text(), 'Response Due Days')]";
	public static String responseDueDays_DropDown = "xpath#//label[@id='applicationParameterForm:complaintHolidays_label']";
	public static String priority_DropDown = "xpath#//div[@id='applicationParameterForm:complaintpriorityDatatable:%rowNo%:A1-145']";
	public static String priority_TextBox = "xpath#//input[@id ='applicationParameterForm:complaintpriorityDatatable:%rowNo%:complaintpriorityvalue']";
	public static String priorityUnit_DropDown = "xpath#//div[@id='applicationParameterForm:complaintpriorityDatatable:%rowNo%:complainthoursordate']";

}
