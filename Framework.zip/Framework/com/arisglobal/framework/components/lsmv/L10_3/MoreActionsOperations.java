package com.arisglobal.framework.components.lsmv.L10_3;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1.OR.AdministrationPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.AdministrationWorkflowPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.ApplicationConfigSearchPolices_PageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.ApplicationConfig_WorkFlowPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDEFormCopyWindowPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDEMoreOptionsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_SplitCasePageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.SubmissionPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.WorkFlowPageObjects;
import com.arisglobal.framework.components.lsrims.R10_3.OR.WorkflowConfiguration;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.outlookwebmail.OutlookWebMail;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class MoreActionsOperations extends ToolManager {

	static String className = MoreActionsOperations.class.getSimpleName();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below Method is create new Correspondance.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 20-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void CorrespondanceOperation(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Correspondence"));
		agSetStepExecutionDelay("2000");
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CorrespondanceReptNumber);
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.CorrespondanceBtnnew);
		agSetStepExecutionDelay("2000");
		agClearText(FDEMoreOptionsPageObjects.CorrespondanceTo);
		agSetValue(FDEMoreOptionsPageObjects.CorrespondanceTo, getTestDataCellValue(scenarioName, "ToAddress"));
		agClick(FDEMoreOptionsPageObjects.CatergoryDRopdownEmailReport);
		agSetStepExecutionDelay("2000");
		agClick(FDEMoreOptionsPageObjects
				.CategoryDropdwonValue(getTestDataCellValue(scenarioName, "EmailSummaryDropDown")));
		// agSelectByVisibleText(FDEMoreOptionsPageObjects.selectpriority,
		// getTestDataCellValue(scenarioName, "Priority"));
		// agSelectByVisibleText(FDEMoreOptionsPageObjects.selectstatus,
		// getTestDataCellValue(scenarioName, "Status"));
		// agSetValue(FDEMoreOptionsPageObjects.noOfReminders,
		// getTestDataCellValue(scenarioName, "NoofReminders"));
		// agSetValue(FDEMoreOptionsPageObjects.reminderInterval,
		// getTestDataCellValue(scenarioName, "ReminderInterval"));
		// agSelectByVisibleText(FDEMoreOptionsPageObjects.selectReminderIntervalUnit,
		// getTestDataCellValue(scenarioName, "ReminderIntervalUnit"));

		agClick(FDEMoreOptionsPageObjects.Send_Correspondence);
		agSetStepExecutionDelay("3000");
		agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.sendEmailPopUp);
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CorrespondanceBtnnew);
		Reports.ExtentReportLog("Send Correspondence", Status.PASS, "", true);

		agSetStepExecutionDelay("3000");
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CorrespondanceBtnnew);
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.Cancel_correspondence);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create Verify Activity Log.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 20-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void ActivityLog(String scenarioName) {
		String RecieptNumber = agGetText(FullDataEntryFormPageObjects.RecptNumber);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Activity Log"));
		agSetStepExecutionDelay("5000");
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.VerifyRecptNumber);
		String VerifyReciptNum = agGetText(FDEMoreOptionsPageObjects.VerifyRecptNumber);
		// String ColReptNumber=agGetText(FDEMoreOptionsPageObjects.ReptNumber);
		String ActivityStatus = agGetText(FDEMoreOptionsPageObjects.WorkflowActivity);
		// String VerifyReptNo[]=VerifyReciptNum.split("Activity Log | ");
		// System.out.println(VerifyReptNo[1]);
		agSetStepExecutionDelay("2000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// To Verify if Receipt Number in Full Data Entry page Matches with Receipt
		// Number in Activity Log Pop Up

		// if(RecieptNumber.equalsIgnoreCase(VerifyReptNo[1])) {
		// Reports.ExtentReportLog("Receipt No", Status.PASS,
		// "Receipt Number "+RecieptNumber+" Matches successfull with ::"
		// +VerifyReptNo[1] , true);
		//
		// }else {
		// Reports.ExtentReportLog("Receipt No", Status.FAIL,
		// "Receipt Number "+getTestDataCellValue(scenarioName, "ReceiptNo")+" Doesn't
		// Matches with -" +VerifyReptNo[1] , false);
		// }
		if (getTestDataCellValue(scenarioName, "ActivityName").equalsIgnoreCase(ActivityStatus)) {
			Reports.ExtentReportLog("Activity Name Matches", Status.PASS,
					"Activity Name " + getTestDataCellValue(scenarioName, "ActivityName")
							+ " Matches successfull with ::" + ActivityStatus,
					true);

		} else {
			Reports.ExtentReportLog("Receipt No in the Column", Status.FAIL, "Activity Name "
					+ getTestDataCellValue(scenarioName, "ActivityName") + " Doesn't Matches with -" + ActivityStatus,
					false);
		}

		agClick(FDEMoreOptionsPageObjects.ActivityLogCloseBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create Verify Workflow LifeCycle.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 20-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void WorkflowTracking(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Workflow Tracking"));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.WorkFlowName);
		String WorkflowName = agGetText(FDEMoreOptionsPageObjects.WorkFlowName);
		// if(getTestDataCellValue(scenarioName,
		// "WorkflowName").equalsIgnoreCase(WorkflowName)) {
		// Reports.ExtentReportLog("Workflow Name Matches", Status.PASS,
		// "Activity Name "+getTestDataCellValue(scenarioName, "WorkflowName")+" Matches
		// successfull with ::" +WorkflowName , true);
		//
		// }else {
		// Reports.ExtentReportLog("Workflow name doesnt match", Status.FAIL,
		// "Activity Name "+getTestDataCellValue(scenarioName, "WorkflowName")+" Doesn't
		// Matches with -" +WorkflowName , false);
		// }
		Reports.ExtentReportLog("", Status.PASS, "WorkFlow Tracking", true);
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.WorkflowCLose);

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to Send Email Case Summary Report.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 20-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void EmailCaseSummaryReport(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Email Case Summary Report"));

		agSetValue(FDEMoreOptionsPageObjects.EMailReportTo, getTestDataCellValue(scenarioName, "ToAddress"));
		agSetStepExecutionDelay("2000");
		agClick(FDEMoreOptionsPageObjects.CatergoryDRopdownEmailReport);
		agSetStepExecutionDelay("2000");
		agClick(FDEMoreOptionsPageObjects
				.CategoryDropdwonValue(getTestDataCellValue(scenarioName, "EmailSummaryDropDown")));
		agClick(FDEMoreOptionsPageObjects.SendEmailReportBtn);
		agSetStepExecutionDelay("2000");
		if (agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Action completed without Validation Errors", true);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.ActionOkBtn);
			agClick(FullDataEntryFormPageObjects.ActionOkBtn);
		}

		if (agIsVisible(FDEMoreOptionsPageObjects.EMailReportPopUp) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Correspondance Adverse Effect", true);
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.CloseiconBtn);

		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.PASS, "Email Case Summary Report", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to Audit Trail Verification.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 20-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void AuditTrail(String scenarioName) {
		String RecieptNumber = agGetText(FullDataEntryFormPageObjects.RecptNumber);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Audit Trail"));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.AuditReptNumber);
		agSetStepExecutionDelay("2000");
		String VerifyReciptNum = agGetText(FDEMoreOptionsPageObjects.AuditReptNumber);

		String VerifyReptNo[] = VerifyReciptNum.split("Audit Trail Report > ");
		System.out.println(VerifyReptNo[1]);

		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (RecieptNumber.equalsIgnoreCase(VerifyReptNo[1])) {
			Reports.ExtentReportLog("Audit Receipt No", Status.PASS,
					"Audit Receipt Number " + RecieptNumber + " Matches successfull with ::" + VerifyReptNo[1], true);

		} else {
			Reports.ExtentReportLog("Audit Receipt No", Status.FAIL,
					"Audit Receipt Number " + RecieptNumber + " Doesn't Matches with -" + VerifyReptNo[1], false);
		}

		if (agIsVisible(FDEMoreOptionsPageObjects.TableNameValidtaion)) {
			Reports.ExtentReportLog("Table Name", Status.PASS, "Table Name Exist", true);
		}

		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.AuditCLoseBtn);

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to Perform Task .
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 20-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void Task(String scenarioName) {
		String RecieptNumber = agGetText(FullDataEntryFormPageObjects.RecptNumber);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Tasks"));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.TaskReptNumber);
		String VerifyReciptNum = agGetText(FDEMoreOptionsPageObjects.TaskReptNumber);

		String VerifyReptNo[] = VerifyReciptNum.split("Task Listing > ");
		System.out.println(VerifyReptNo[1]);
		agSetStepExecutionDelay("5000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// if(RecieptNumber.equalsIgnoreCase(VerifyReptNo[1])) {
		// Reports.ExtentReportLog("Task Receipt No", Status.PASS,
		// "Task Receipt Number "+RecieptNumber+" Matches successfull with ::"
		// +VerifyReptNo[1] , true);
		//
		// }else {
		// Reports.ExtentReportLog("Task Receipt No", Status.FAIL,
		// "Task Receipt Number "+RecieptNumber+" Doesn't Matches with -"
		// +VerifyReptNo[1] , false);
		// }
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.TaskNewBtn);
		agClick(FDEMoreOptionsPageObjects.TaskNewBtn);
		agSetStepExecutionDelay("2000");
		agSelectByValue(FDEMoreOptionsPageObjects.SelectCaseType, getTestDataCellValue(scenarioName, "TaskDropDown"));
		agSetStepExecutionDelay("2000");
		agClick(FDEMoreOptionsPageObjects.RemainderDetailsIcon);
		agSetStepExecutionDelay("2000");
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.InputDueDate);
		agSetValue(FDEMoreOptionsPageObjects.InputDueDate,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "InputDueDate")));
		agSetStepExecutionDelay("2000");
		agClick(FDEMoreOptionsPageObjects.TaskSaveBtn);
		agSetStepExecutionDelay("4000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CLoseTask);
		agClick(FDEMoreOptionsPageObjects.CLoseTask);

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to Veriify Proposed Distributed
	 *             Contacts .
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 20-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void VerifyProposedDistributionContact() {
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("View Proposed Distribution Contacts "));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.VerifyListofDistributionContacts);
		String VerifyDistributionContactList = agGetText(FDEMoreOptionsPageObjects.VerifyListofDistributionContacts);
		agSetStepExecutionDelay("2000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("Distribution Contact List", Status.PASS,
				"List of Proposed Distributed Contacts found ", true);
		agClick(FDEMoreOptionsPageObjects.DistributionContactClose);
		agSetStepExecutionDelay("4000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to Note .
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 20-March-2020
	 * @UpdatedByAndWhen:WajahatUmar on 08-June-2020
	 **********************************************************************************************************/

	public static void CreateNotes(String scenarioName) {
		String RecieptNumber = agGetText(FullDataEntryFormPageObjects.RecptNumber);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Case Notes"));
		if (agIsVisible(FDEMoreOptionsPageObjects.NotesReptNum) == true) {
			agSetStepExecutionDelay("2000");
			agClick(FDEMoreOptionsPageObjects.NotesCheckBox);
			agClick(FDEMoreOptionsPageObjects.DeleteBtn);
			agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.DeletePopUp);
			agSetStepExecutionDelay("2000");
			Reports.ExtentReportLog("", Status.INFO, "Notes Deleted", true);
		}
		agSetStepExecutionDelay("2000");
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.NoteNewBtn);
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.NoteNewBtn);
		agSetValue(FDEMoreOptionsPageObjects.Description, getTestDataCellValue(scenarioName, "Description"));
		agSetStepExecutionDelay("2000");
		agSetValue(FDEMoreOptionsPageObjects.FileUpload,
				lsmvConstants.LSMV_testDataInput + "\\" + getTestDataCellValue(scenarioName, "FileName"));
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.NoteSave);
		agSetStepExecutionDelay("2000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.PASS, "Note Added", true);
		agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.NotePopup);
		// String NotesReciptNo = agGetText(FDEMoreOptionsPageObjects.NotesReptNum);
		String NotesDescription = agGetText(FDEMoreOptionsPageObjects.NotesDescription);
		if (agIsVisible(FDEMoreOptionsPageObjects.NotesRctNum(RecieptNumber))
				&& NotesDescription.equalsIgnoreCase(getTestDataCellValue(scenarioName, "Description"))) {
			Reports.ExtentReportLog("", Status.PASS, "Notes Created ", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Notes not Created ", true);
		}
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.CLoseNote);
		ToolManager.agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.NotePopup);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to Veriify Proposed Distributed
	 *             Contacts .
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 20-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void VerifyCaseQualityScoreHistory(String scenarioName) {
		String RecieptNumber = agGetText(FullDataEntryFormPageObjects.RecptNumber);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorMouseHover(FDEMoreOptionsPageObjects.CaseScoreNavigationUnderMoreoptions);
		agClick(FDEMoreOptionsPageObjects.CaseScoreNavigationUnderMoreoptions);
		agSetStepExecutionDelay("2000");
		agClick(FDEMoreOptionsPageObjects.CaseScoreOptions("Case Quality Score History"));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CAseQualityVerification);
		String VerifyReciptNum = agGetText(FDEMoreOptionsPageObjects.CAseQualityVerification);

		String VerifyReptNo[] = VerifyReciptNum.split("Case Quality Score History > ");
		System.out.println(VerifyReptNo[1]);
		agSetStepExecutionDelay("2000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (RecieptNumber.equalsIgnoreCase(VerifyReptNo[1])) {
			Reports.ExtentReportLog("Receipt No in Case Quality Score", Status.PASS, "Receipt No in Case Quality Score"
					+ RecieptNumber + " Matches successfull with ::" + VerifyReptNo[1], true);

		} else {
			Reports.ExtentReportLog("Task Receipt No", Status.FAIL,
					"Receipt No in Case Quality Score " + RecieptNumber + " Doesn't Matches with -" + VerifyReptNo[1],
					false);
		}

		agClick(FDEMoreOptionsPageObjects.CloseCaseQualityPopUp);

	}

	/**********************************************************************************************************
	 * @Objective: The below method will verify Reciept Number.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 23-March-2020
	 * @UpdatedByAndWhen:WajahatUmar S
	 **********************************************************************************************************/
	public static void SplitCase(String scenarioName) {
		String RecieptNumber = agGetText(FullDataEntryFormPageObjects.RecptNumber);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		FDE_Operations.MoreOptionsLinksNavigation(FDEMoreOptionsPageObjects.moreOptions("Split"));
		agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.moreOptions("Split"));
		agWaitTillVisibilityOfElement(FDE_SplitCasePageObjects.VerifyReciptNumber);
		agIsVisible(FDE_SplitCasePageObjects.VerifyReciptNumber);
		String VerifyReciptNum = agGetText(FDE_SplitCasePageObjects.VerifyReciptNumber);
		String VerifyReptNo[] = VerifyReciptNum.split("Split Document > ");
		System.out.println(VerifyReptNo[1]);
		agSetStepExecutionDelay("2000");
		// To Verify if Receipt Number in Full Data Entry page Matches with Receipt
		// Number in Copy Case Pop Up
		// agCheckPropertyText(FDE_CopyCase.getData(scenarioName,
		// "ReceiptNo"),FDE_CopyCase.getData(scenarioName, "CopiedReceiptNo"));
		if (RecieptNumber.equalsIgnoreCase(VerifyReptNo[1])) {
			Reports.ExtentReportLog("Receipt No", Status.PASS,
					"Receipt Number " + RecieptNumber + " Matches successfull with ::" + VerifyReptNo[1], true);

		} else {
			Reports.ExtentReportLog("Receipt No", Status.FAIL,
					"Receipt Number " + RecieptNumber + " Doesn't Matches with -" + VerifyReptNo[1], false);
		}
		agWaitTillVisibilityOfElement(FDE_SplitCasePageObjects.CancelBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(FDE_SplitCasePageObjects.CancelBtn);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify Receipt ID and
	 * 
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @Date : 23-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void copyCase(String scenarioName) {
		String RecieptNumber = agGetText(FullDataEntryFormPageObjects.RecptNumber);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		FDE_Operations.MoreOptionsLinksNavigation(FDEMoreOptionsPageObjects.moreOptions("Copy"));
		agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.moreOptions("Copy"));
		agIsVisible(FDEFormCopyWindowPageObjects.VerifyReciptNumber);
		String VerifyReciptNum = agGetText(FDEFormCopyWindowPageObjects.VerifyReciptNumber);
		String VerifyReptNo[] = VerifyReciptNum.split("Copy > ");
		System.out.println(VerifyReptNo[1]);
		agSetStepExecutionDelay("2000");
		// To Verify if Receipt Number in Full Data Entry page Matches with Receipt
		// Number in Copy Case Pop Up
		// agCheckPropertyText(FDE_CopyCase.getData(scenarioName,
		// "ReceiptNo"),FDE_CopyCase.getData(scenarioName, "CopiedReceiptNo"));
		if (RecieptNumber.equalsIgnoreCase(VerifyReptNo[1])) {
			Reports.ExtentReportLog("Receipt No", Status.PASS,
					"Receipt Number " + RecieptNumber + " Matches successfull with ::" + VerifyReptNo[1], true);

		} else {
			Reports.ExtentReportLog("Receipt No", Status.FAIL,
					"Receipt Number " + RecieptNumber + " Doesn't Matches with -" + VerifyReptNo[1], false);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		agClick(FDEMoreOptionsPageObjects.CopyCancel);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to verify Receipt ID and
	 * 
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @Date : 23-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void CheckE2BTags() {
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agSetStepExecutionDelay("2000");
		agMouseHover(FDEMoreOptionsPageObjects.E2BTagsNavigationUnderMoreoptions);

		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.E2BTagsNavigationUnderMoreoptions);
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.E2BTagsMoreOptions("E2B R2 Tag"));
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.E2BTagsMoreOptions("E2B R3 Tag"));
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.E2BTagsMoreOptions("Code List IDs"));
		agSetStepExecutionDelay("2000");

		Reports.ExtentReportLog("Check Boxed Checked", Status.PASS, " ", true);

		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	public static void verifyE2BtagData() {
		agAssertExists(FDEMoreOptionsPageObjects.intialReceiveDataTag);
		agAssertExists(FDEMoreOptionsPageObjects.latestReceiveDataTag);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Delete the Case.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @Date : 08-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void DeleteCase() {
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agSetStepExecutionDelay("2000");
		FDE_Operations.MoreOptionsLinksNavigation(FDEMoreOptionsPageObjects.moreOptions("Delete"));
		agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.moreOptions("Delete"));
		agClick(FDEMoreOptionsPageObjects.deleteAuditReasonCode_Dropdwn);
		agClick(FDEMoreOptionsPageObjects.deleteReasonCode_Dropdwn_value);
		agClick(FDEMoreOptionsPageObjects.deleteAuditReasonSubmit_Btn);
		if (agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully)) {

			System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
			System.out.println(agGetText(FullDataEntryFormPageObjects.case_MovedToNxtAct));
			Reports.ExtentReportLog("", Status.PASS, "Action completed without Validation Errors", true);
			agClick(FullDataEntryFormPageObjects.ActionOkBtn);

		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to save the FDE case
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void LSMVSave(String scenarioName, String sheetName) {
		agSetStepExecutionDelay("2000");
		agClick(FullDataEntryFormPageObjects.SaveButton);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.writeRecptNo_FDESave(scenarioName, sheetName);
		agAssertContainsText(FullDataEntryFormPageObjects.receiptNumber,
				FDE_General.getData(scenarioName, "SaveMessage"));
		String receiptNumber = agGetText(FullDataEntryFormPageObjects.receiptNumber);
		status = agIsVisible(FullDataEntryFormPageObjects.receiptNumber);
		if (status) {
			Reports.ExtentReportLog("LSMV create new case receipt", Status.PASS,
					"New case creation successfull :: Validation-" + receiptNumber, true);
		} else {
			Reports.ExtentReportLog("LSMV create new case receipt", Status.FAIL,
					"New case creation unsuccessfull :: Validation-" + receiptNumber, true);
		}
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
		agClick(FullDataEntryFormPageObjects.saveOkButton);

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create Verify Activity Log.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 04-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerificationofActivityLog(String WorflowActivity) {
		String RecieptNumber = agGetText(FullDataEntryFormPageObjects.RecptNumber);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Activity Log"));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.DownloadActivityLog);
		int counter = 0;
		while (!agIsVisible(FDEMoreOptionsPageObjects.receiptNo) && counter < 5) {
			agClick(FDEMoreOptionsPageObjects.RefreshBtn);
			counter++;
		}
		System.out.print(agGetText(FDEMoreOptionsPageObjects.receiptNo));
		if (RecieptNumber.equalsIgnoreCase(agGetText(FDEMoreOptionsPageObjects.receiptNo))) {
			Reports.ExtentReportLog("", Status.PASS, "Reciept Number Exist", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Reciept Number Not Exist", true);
		}
		agSetStepExecutionDelay("3000");
		if (agGetText(FDEMoreOptionsPageObjects.WfActivity).equalsIgnoreCase(WorflowActivity)) {
			Reports.ExtentReportLog("", Status.PASS, "WorkFlowActivityName Matches", true);

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "WorkFlowActivityName not Matches", true);
		}

		if (agIsVisible(FDEMoreOptionsPageObjects.ActionDetails) == true) {
			Reports.ExtentReportLog("", Status.INFO, "Action Detail Comments Exist", true);
		}
		agSetStepExecutionDelay("2000");
		agClick(FDEMoreOptionsPageObjects.DownloadActivityLog);
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.ExportToExcelBtn);
		agClick(FDEMoreOptionsPageObjects.ExportToExcelBtn);
		agSetStepExecutionDelay("2000");
		agClick(FDEMoreOptionsPageObjects.ExportToPdfBtn);
		agSetStepExecutionDelay("2000");
		Reports.ExtentReportLog("", Status.INFO, "Data Export Configuration", true);
		agClick(FDEMoreOptionsPageObjects.DataExportCancelBtn);
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.DownloadActivityLog);
		agClick(FDEMoreOptionsPageObjects.ActivityLogCloseBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create Verify Activity Log.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 08-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerificationofWorkFlowTracking(String wfFromActivityName, String wfToActivityName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Verification of WorkFlow Tracking Started", true);
			String workFlow = agGetText(CaseListingPageObjects.caseActHeader);
			agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
			agClick(FDEMoreOptionsPageObjects.moreOptions("Workflow Tracking"));
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.WorkFlowName);

			String WorkflowName = agGetText(FDEMoreOptionsPageObjects.WorkFlowName);
			;
			String TransitionName;
			String FromActivityName;
			String ToActivityName;

			String isAutoComplete = agGetText(FDEMoreOptionsPageObjects.IsAutoCompleted);
			// String isAutoCompleteFailed =
			// agGetText(FDEMoreOptionsPageObjects.IsAutoCompleteFailed);
			if (isAutoComplete.equalsIgnoreCase("YES")) {
				WorkflowName = agGetText(FDEMoreOptionsPageObjects.WorkFlowName);
				TransitionName = agGetText(FDEMoreOptionsPageObjects.TransitionNameNextRow);
				FromActivityName = agGetText(FDEMoreOptionsPageObjects.FromActivityNameNextRow);
				ToActivityName = agGetText(FDEMoreOptionsPageObjects.ToActivityNameNextRow);
			} else {
				WorkflowName = agGetText(FDEMoreOptionsPageObjects.WorkFlowName);
				TransitionName = agGetText(FDEMoreOptionsPageObjects.TransitionName);
				FromActivityName = agGetText(FDEMoreOptionsPageObjects.FromActivityName);
				ToActivityName = agGetText(FDEMoreOptionsPageObjects.ToActivityName);
			}
			if (WorkflowName.equalsIgnoreCase("ISP Case Processing Workflow")) {
				Reports.ExtentReportLog("", Status.PASS,
						"WorkFlowName as " + WorkflowName + " Matches in WorkFlowTracking Section", true);

			} else {
				Reports.ExtentReportLog("", Status.FAIL, "WorkFlowName as " + WorkflowName + " not Matches", true);
			}

			if (FromActivityName.equalsIgnoreCase(wfFromActivityName)) {
				Reports.ExtentReportLog("", Status.PASS,
						"FromActivityName as " + wfFromActivityName + " Matches in WorkFlowTracking Section", true);

			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"FromActivityName as " + wfFromActivityName + " not Matches in WorkFlowTracking Section", true);
			}
			if (ToActivityName.equalsIgnoreCase(wfToActivityName)) {
				Reports.ExtentReportLog("", Status.PASS,
						"TOActivityName as " + wfToActivityName + " Matches in WorkFlowTracking Section", true);

			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"ToActivityName as " + wfToActivityName + " not Matches in WorkFlowTracking Section", true);
			}

			if (TransitionName.equalsIgnoreCase("Send to" + ' ' + ToActivityName)) {
				Reports.ExtentReportLog("", Status.PASS,
						"TRANSITION NAME as " + TransitionName + " Matches in WorkFlowTracking Section", true);

			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"TRANSITION NAME as " + TransitionName + " not Matches in WorkFlowTracking Section", true);
			}
			if (agIsVisible(FDEMoreOptionsPageObjects.IsAutoCompleted) == true) {
				Reports.ExtentReportLog("", Status.INFO, "AUto Completed is Set as True in WorkFlowTracking Section",
						true);
			}

			if (agIsVisible(FDEMoreOptionsPageObjects.wfDescription) == true) {
				Reports.ExtentReportLog("", Status.INFO, "Workflow Description Displayed in WorkFlowTracking Section",
						true);
			}
			agSetStepExecutionDelay("2000");
			agClick(FDEMoreOptionsPageObjects.DownloadWorkflowLog);
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.ExportToExcelBtn);
			agClick(FDEMoreOptionsPageObjects.ExportToExcelBtn);
			agSetStepExecutionDelay("2000");
			agClick(FDEMoreOptionsPageObjects.ExportToPdfBtn);
			agSetStepExecutionDelay("2000");
			Reports.ExtentReportLog("", Status.INFO, "Data Export Configuration Window", true);
			agClick(FDEMoreOptionsPageObjects.DataExportCancelBtn);
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.DownloadWorkflowLog);
			agClick(FDEMoreOptionsPageObjects.WorkflowCLose);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.INFO, "Verification of WorkFlow Tracking Completed", true);
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Verification of WorkFlow Tracking Fails", true);
			if (agIsVisible(FDEMoreOptionsPageObjects.DataExportCancelBtn) == true) {
				agClick(FDEMoreOptionsPageObjects.DataExportCancelBtn);
				agSetStepExecutionDelay("2000");
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				agClick(FDEMoreOptionsPageObjects.WorkflowCLose);
			} else if (agIsVisible(FDEMoreOptionsPageObjects.WorkflowCLose) == true) {
				agClick(FDEMoreOptionsPageObjects.WorkflowCLose);

			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to Perform Task .
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 10-Jun-2020
	 * @UpdatedByAndWhen: Karthikeyan Natarajan 02-07-2020
	 **********************************************************************************************************/

	public static void CreationofTask(String scenarioName) {
		String RecieptNumber = agGetText(FullDataEntryFormPageObjects.RecptNumber);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Tasks"));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.TaskReptNumber);
		String VerifyReciptNum = agGetText(FDEMoreOptionsPageObjects.TaskReptNumber);
		if (agIsVisible(FDEMoreOptionsPageObjects.ReferenceId) == true) {
			agClick(FDEMoreOptionsPageObjects.PreviousTaskchkbox);
			agClick(FDEMoreOptionsPageObjects.TaskDeleteBtn);
			agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.DeleteValidation);
		}
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.TaskNewBtn);
		agClick(FDEMoreOptionsPageObjects.TaskNewBtn);
		agSetStepExecutionDelay("2000");
		agSelectByValue(FDEMoreOptionsPageObjects.SelectCaseType, getTestDataCellValue(scenarioName, "TaskDropDown"));
		agSetStepExecutionDelay("2000");
		agSetValue(FDEMoreOptionsPageObjects.CommentTask, getTestDataCellValue(scenarioName, "Description"));
		agSelectByValue(FDEMoreOptionsPageObjects.ReplyStatusDD, "1");
		agSetValue(FDEMoreOptionsPageObjects.ReplyDate,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "InputDueDate")));
		agSetValue(FDEMoreOptionsPageObjects.SceduledDate,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "InputDueDate")));
		agSetValue(FDEMoreOptionsPageObjects.ActualCompletionDate,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "InputDueDate")));
		agClick(FDEMoreOptionsPageObjects.DistributionContactInformation);
		agSelectByValue(FDEMoreOptionsPageObjects.AuthorityDD, getTestDataCellValue(scenarioName, "AuthorityDropDown"));
		agSelectByValue(FDEMoreOptionsPageObjects.ContactDD, getTestDataCellValue(scenarioName, "ContactDropDown"));
		agClick(FDEMoreOptionsPageObjects.RemainderDetailsIcon);
		agSetStepExecutionDelay("2000");
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.InputDueDate);
		agSetValue(FDEMoreOptionsPageObjects.InputDueDate,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "InputDueDate")));
		agSetValue(FDEMoreOptionsPageObjects.ReminderOnDate,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "InputDueDate")));
		agClick(FDEMoreOptionsPageObjects.DocumnentIcon);
		agSetStepExecutionDelay("3000");
		agSetValue(FDEMoreOptionsPageObjects.DocumentUploadTask,
				lsmvConstants.LSMV_testDataInput + "\\" + getTestDataCellValue(scenarioName, "FileName"));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.DocumentUploadVerification);
		agSetStepExecutionDelay("3000");
		Reports.ExtentReportLog("", Status.INFO, "Document Upload", true);
		agSetValue(FDEMoreOptionsPageObjects.FileDescription, "Document for Task");
		agClick(FDEMoreOptionsPageObjects.UsergroupAssignmentDetails);
		agSetValue(FDEMoreOptionsPageObjects.SearchTask, getTestDataCellValue(scenarioName, "SearchUser"));
		agJavaScriptExecuctorClick(
				FDEMoreOptionsPageObjects.clickUserChkBox(getTestDataCellValue(scenarioName, "SearchUser")));
		agClick(FDEMoreOptionsPageObjects.UserArrowBtn);
		if (agIsVisible(FDEMoreOptionsPageObjects.SelectedUser) == true) {
			Reports.ExtentReportLog("", Status.PASS, "User is Selected", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "User is not Selected", true);

		}
		agSetStepExecutionDelay("2000");
		agClick(FDEMoreOptionsPageObjects.TaskSaveBtn);
		Reports.ExtentReportLog("", Status.INFO, "Task is Created", true);
		if (agGetText(FDEMoreOptionsPageObjects.ReferenceId).equalsIgnoreCase(RecieptNumber)) {
			Reports.ExtentReportLog("", Status.PASS, "Reciept Number Matches with Reference ID", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Reciept Number not Matches with Reference ID", true);
		}
		agSetStepExecutionDelay("4000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CLoseTask);
		agClick(FDEMoreOptionsPageObjects.CLoseTask);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to validate more actions operations
	 *             (Activity Log, Workflow Tracking, Notes and Tasks) in E2E
	 *             Scenarios
	 * @InputParameters: Scenario Name, From Activity, To Activity
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 02-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void validateMoreActionsOperations(String scenarioName, String fromActivty, String toActivity,
			String creationType) {
		String tempName = "";

		if (creationType.contains("XML") || creationType.equalsIgnoreCase("BIE")) {
			tempName = fromActivty;
		} else if (fromActivty.equalsIgnoreCase("Intake and Assessment")) {
			tempName = fromActivty;
		} else
			tempName = toActivity;
		if (scenarioName.contains("NonCase")) {
			tempName = "Non Case";
			toActivity = "Non Case";
		}
		if (creationType.contains("DataExtraction")) {
			tempName = toActivity;
		}
		MoreActionsOperations.VerificationofActivityLog(tempName);
		MoreActionsOperations.VerificationofWorkFlowTracking(fromActivty, toActivity);
		MoreActionsOperations.verifyicationofAuditTrial(scenarioName, toActivity);
		if (toActivity.equalsIgnoreCase("Intake and Assessment")) {
			MoreActionsOperations.CreateNotes(scenarioName);
			MoreActionsOperations.CreationofTask(scenarioName);
		}
	}

	public static void verifyicationofAuditTrial(String scenarioName, String activityName) {
		Reports.ExtentReportLog("", Status.INFO, "Verification of Audit Trial by work flow activity is started", true);
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "dataassessmentoperations");
			String AERNo = getTestDataCellValue(scenarioName, "AERNo");
			// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			String WorkFlowheader = agGetText(CaseListingPageObjects.caseActHeader);
			String RecieptNumber = agGetText(FullDataEntryFormPageObjects.RecptNumber);
			CommonOperations.takeScreenShot();
			agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
			agClick(FDEMoreOptionsPageObjects.moreOptions("Audit Trail"));
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.auditTrilReport);
			boolean activityPresent = agIsVisible(FDEMoreOptionsPageObjects.auditTrialValidationElements(activityName));
			boolean rctNumPresent = agIsVisible(FDEMoreOptionsPageObjects.auditTrialValidationElements(RecieptNumber));
			boolean aerNumPresent = agIsVisible(FDEMoreOptionsPageObjects.auditTrialValidationElements(AERNo));
			if ((activityPresent) && (rctNumPresent || aerNumPresent)) {
				Reports.ExtentReportLog("", Status.PASS, "WorkFlowActivityName Matches", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "WorkFlowActivityName not Matches", true);
			}
			if (WorkFlowheader.equalsIgnoreCase(activityName)) {
				if (scenarioName.equalsIgnoreCase("LSMV_VerifyAuditTrial")) {
					verifyActivityName(activityName);
					AuditTrailVerification(scenarioName);
				} else {
					verificationOfAuditTrail(scenarioName);
				}
				Reports.ExtentReportLog("", Status.PASS,
						"Verification of Audit Trial is completed for " + WorkFlowheader + "activity", true);
			} else {
				Reports.ExtentReportLog("", Status.INFO,
						"Verification of Audit Trial is not completed for " + WorkFlowheader + "activity", true);
				// agClick(FDEMoreOptionsPageObjects.closeBtn);
				agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.closeAuditTrial);
				agSetStepExecutionDelay("3000");
			}
		} catch (Exception e) {
			e.printStackTrace();
			if (agIsVisible(FDEMoreOptionsPageObjects.closeBtn) == true) {
				agClick(FDEMoreOptionsPageObjects.closeBtn);
				agSetStepExecutionDelay("2000");
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			}
		}
		Reports.ExtentReportLog("", Status.INFO, "Verification of Audit Trial by work flow activity is ended ", true);
	}

	public static void verificationOfAuditTrail(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		if (getTestDataCellValue(scenarioName, "FileDropdown").equalsIgnoreCase("EXCEL")) {
			verifyDownloadExcel(scenarioName);
			// agClick(FDEMoreOptionsPageObjects.closeBtn);
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.closeAuditTrial);
			agSetStepExecutionDelay("3000");
		}
		if (getTestDataCellValue(scenarioName, "FileDropdown").equalsIgnoreCase("PDF")) {
			verifyDownloadPDF(scenarioName);
			// agClick(FDEMoreOptionsPageObjects.closeBtn);
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.closeAuditTrial);
			agSetStepExecutionDelay("3000");
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	public static void verifyDownloadExcel(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String filename = Multimaplibraries.getTestDataCellValue(scenarioName, "File");
		try {
			// CommonOperations.setListDropDownValue(FDEMoreOptionsPageObjects.excelDownload_Dropdown,
			// getTestDataCellValue(scenarioName, "FileDropdown"));
			CommonOperations.takeScreenShot();
			agClick(FDEMoreOptionsPageObjects.downloadAsExcel);
			agSetStepExecutionDelay("15000");
			agGetCurrentWindow();
			agSetStepExecutionDelay("10000");
			CommonOperations.move_Downloadedexcel(filename);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.INFO, "Excel downloaded successfully", true);
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			// agCloseCurrentWindow();
			// agGetWindowControlByInstance(1);
		} catch (Exception ex) {
			Reports.ExtentReportLog("", Status.FAIL, filename + " :Download Failed", true);
		}
	}

	public static void verifyDownloadPDF(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String filename = "Audit_Trail_Report.pdf";
		try {
			// CommonOperations.setListDropDownValue(FDEMoreOptionsPageObjects.excelDownload_Dropdown,
			// getTestDataCellValue(scenarioName, "FileDropdown"));
			CommonOperations.takeScreenShot();
			// agSetStepExecutionDelay("5000");
			agClick(FDEMoreOptionsPageObjects.downloadAsPDF);
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// FDE_Operations.downloadReports();
			FDE_Operations.downloadPDFinListing();
			CommonOperations.move_DownloadedPDF(filename);
			Reports.ExtentReportLog("", Status.INFO, "PDF downloaded successfully", true);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} catch (Exception ex) {
			Reports.ExtentReportLog("", Status.FAIL, filename + " :Download Failed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click dropdown and select value of
	 *             DTDXSDType dropdown.
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 14-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDTDXSDTypeDropDownValue(String locator, String valueToSelect) {
		if (!valueToSelect.equalsIgnoreCase("#skip#")) {
			agSetStepExecutionDelay("2000");
			agClick(locator);
			agClick(FDEMoreOptionsPageObjects.clickDTDXSDDropDownValue(valueToSelect));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click dropdown and select value of
	 *             MHLWRType dropdown.
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 14-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setMHLWReportTypeDropDownValue(String locator, String valueToSelect) {
		if (!valueToSelect.equalsIgnoreCase("#skip#")) {
			agSetStepExecutionDelay("2000");
			agClick(locator);
			agClick(FDEMoreOptionsPageObjects.clickMHLWDropDownValue(valueToSelect));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to generate E2b xml report (R2 and R3
	 *             Reports)
	 * @InputParameters: Scenario Name, reportType
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 14-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void GenerateE2BXmlReport(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.e2BGenerateReport);
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.validateE2BReporPopUp);
		String reportType = getTestDataCellValue(scenarioName, "E2BxmlReportType");

		if (reportType.equalsIgnoreCase("R3")) {
			agSetStepExecutionDelay("2000");
			setDTDXSDTypeDropDownValue(FDEMoreOptionsPageObjects.clickDTDXSDTypeDD,
					getTestDataCellValue(scenarioName, "E2bDTDXSDType"));
			/*
			 * setMHLWReportTypeDropDownValue(FDEMoreOptionsPageObjects.clickMHLWReportType,
			 * getTestDataCellValue(scenarioName, "MHLWReportType"));
			 */
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agClick(FDEMoreOptionsPageObjects.exportE2Bxml);
		} else {
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.radioR2);
			agSetStepExecutionDelay("2000");
			setDTDXSDTypeDropDownValue(FDEMoreOptionsPageObjects.clickDTDXSDTypeDD,
					getTestDataCellValue(scenarioName, "E2bDTDXSDType"));
			agClick(FDEMoreOptionsPageObjects.exportE2Bxml);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to verify the send correspondence
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 24-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void sendCorrespondenceVerification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Correspondence"));
		agSetStepExecutionDelay("8000");
		String mailSuccess = null;
		String mailQueued = null;
		if (agIsVisible(FDEMoreOptionsPageObjects.successIcon)) {
			mailSuccess = agGetAttribute("title", FDEMoreOptionsPageObjects.successIcon);
			if (mailSuccess.equalsIgnoreCase("Success"))
				Reports.ExtentReportLog("", Status.PASS, "Outgoing Mail verification : " + mailSuccess, true);
		} else if (agIsVisible(FDEMoreOptionsPageObjects.queuedIcon)) {
			mailQueued = agGetAttribute("title", FDEMoreOptionsPageObjects.queuedIcon);
			if (mailQueued.equalsIgnoreCase("Queued"))
				Reports.ExtentReportLog("", Status.PASS, "Outgoing Mail verification : " + mailQueued, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Outgoing Mail verification : ", true);
		}

		agClick(FDEMoreOptionsPageObjects.viewCorrespondence);
		agSetStepExecutionDelay("3000");
		agClick(FDEMoreOptionsPageObjects.CorrespondanceTo);
		String mail = agGetText(
				FDEMoreOptionsPageObjects.toAddress.replace("%s", getTestDataCellValue(scenarioName, "ToAddress")));
		if (mail.equalsIgnoreCase(getTestDataCellValue(scenarioName, "ToAddress"))) {
			Reports.ExtentReportLog("", Status.PASS, "To address verfication passed : ", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "To address verfication failed : ", true);
		}
		// agAssertContainsText(FDEMoreOptionsPageObjects.CorrespondanceTo,
		// getTestDataCellValue(scenarioName, "ToAddress"));
		agAssertContainsText(FDEMoreOptionsPageObjects.CatergoryDRopdownEmailReport,
				getTestDataCellValue(scenarioName, "EmailSummaryDropDown"));
		agAssertContainsText(FDEMoreOptionsPageObjects.selectstatus, getTestDataCellValue(scenarioName, "Status"));
		agClick(FDEMoreOptionsPageObjects.cancelBtn);
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.Cancel_correspondence);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to Veriify OLT status in Proposed
	 *             Distributed Contacts .
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 11-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyOLTDistributionContact(String contactName, String OltContactStatus) {
		agSetStepExecutionDelay("15000");
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.moreOptionsHover);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agSetStepExecutionDelay("2000");
		agClick(FDEMoreOptionsPageObjects.moreOptions("View Proposed Distribution Contacts "));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.VerifyListofDistributionContacts);
		agSetValue(FDEMoreOptionsPageObjects.distributeContactSearch, contactName);
		agClick(FDEMoreOptionsPageObjects.distributeSearch);
		String OltStatus = agGetText(FDEMoreOptionsPageObjects.verifyOltContact);
		if (OltStatus.equalsIgnoreCase(OltContactStatus)) {
			Reports.ExtentReportLog("", Status.PASS, "OLT contact status is verified successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "OLT contact status is not verified successfully", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("Distribution Contact List", Status.PASS,
				"List of Proposed Distributed Contacts found ", true);
		agClick(FDEMoreOptionsPageObjects.DistributionContactClose);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to Veriify Auto Complete of Activity
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 08-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static boolean verifyAutoComplete(String activityName) {
		Reports.ExtentReportLog("", Status.INFO, "Auto Complete Verification Starts", false);
		boolean autoComplete = false;
		try {
			agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
			agClick(FDEMoreOptionsPageObjects.moreOptions("Workflow Tracking"));

			String toActivityName = agGetText(FDEMoreOptionsPageObjects.ToActivityName);
			String isAutoComplete = agGetText(FDEMoreOptionsPageObjects.IsAutoCompleted);
			String isAutoCompleteFailed = agGetText(FDEMoreOptionsPageObjects.IsAutoCompleteFailed);

			if (toActivityName.equalsIgnoreCase(activityName) && isAutoComplete.equalsIgnoreCase("YES")
					&& isAutoCompleteFailed.isEmpty()) {
				autoComplete = true;
				Reports.ExtentReportLog("", Status.PASS, "Casee is Auto Completed to " + activityName, true);
			} else {
				autoComplete = false;
				if (isAutoCompleteFailed.equalsIgnoreCase("true")) {
					toActivityName = agGetText(FDEMoreOptionsPageObjects.ToActivityNameNextRow);
					isAutoComplete = agGetText(FDEMoreOptionsPageObjects.IsAutoCompleted);
					isAutoCompleteFailed = agGetText(FDEMoreOptionsPageObjects.IsAutoCompleteFailed);
					if (toActivityName.equalsIgnoreCase(activityName) && isAutoComplete.equalsIgnoreCase("YES")) {
						autoComplete = true;
						Reports.ExtentReportLog("", Status.PASS, "Casee is Auto Completed to " + activityName, true);
					}
				} else
					Reports.ExtentReportLog("", Status.FAIL, "Casee is not Auto Completed to " + activityName, true);
			}
			agClick(FDEMoreOptionsPageObjects.WorkflowCLose);
			Reports.ExtentReportLog("", Status.INFO, "Auto Complete Verification Ends", false);
		} catch (Exception ex) {
			ex.printStackTrace();
			agClick(FDEMoreOptionsPageObjects.WorkflowCLose);
			Reports.ExtentReportLog("", Status.FAIL, "Auto Complete Verification Ends Abruptly", false);
		}
		return autoComplete;

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to Verify the blinded/Unblinded
	 *             products in audit trail report in PDF
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 21-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void auditTrial(String scenarioName) {
		agSetStepExecutionDelay("3000");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Audit Trail"));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.auditTrilReport);
		verificationOfAuditTrail(scenarioName);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to download excel and pdf from audit
	 *             trial window and verify
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 03-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AuditTrailVerification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		if (getTestDataCellValue(scenarioName, "FileDropdownExcel").equalsIgnoreCase("EXCEL")) {
			verifyDownloadExcelandPDF(scenarioName, "EXCEL");
			agSetStepExecutionDelay("3000");
		}
		if (getTestDataCellValue(scenarioName, "FileDropdown").equalsIgnoreCase("PDF")) {
			verifyDownloadExcelandPDF(scenarioName, "PDF");
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.closeAuditTrial);
			agSetStepExecutionDelay("3000");
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to verify current activity in Audit
	 *             trial
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 04-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyActivityName(String ActivityName) {
		agIsVisible(FDEMoreOptionsPageObjects.WfActivityName);
		String CurrentActivityName = agGetText(FDEMoreOptionsPageObjects.WfActivityName);
		if (ActivityName.equalsIgnoreCase(CurrentActivityName)) {
			Reports.ExtentReportLog("", Status.PASS, "Activity Name matched successfully " + ActivityName, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Activity Name not matched successfully" + ActivityName, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to verify download excel and pdf
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 03-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDownloadExcelandPDF(String scenarioName, String DownloadType) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (DownloadType.equalsIgnoreCase("EXCEL")) {
			agClick(FDEMoreOptionsPageObjects.downloadAuditTrialAsExcel);
//			CommonOperations.setListDropDownValue(FDEMoreOptionsPageObjects.excelDownload_Dropdown,
//					getTestDataCellValue(scenarioName, "FileDropdownExcel"));
		}
		if (DownloadType.equalsIgnoreCase("PDF")) {
			agClick(FDEMoreOptionsPageObjects.downloadAuditTrialAsPDF);
//			CommonOperations.setListDropDownValue(FDEMoreOptionsPageObjects.excelDownload_Dropdown,
//					getTestDataCellValue(scenarioName, "FileDropdown"));
		
		CommonOperations.takeScreenShot();
		agClick(FDEMoreOptionsPageObjects.downloadBtn);
		agSetStepExecutionDelay("15000");
		agGetCurrentWindow();
		agSetStepExecutionDelay("10000");
		}
		if (DownloadType.equalsIgnoreCase("EXCEL")) {
			String filename = Multimaplibraries.getTestDataCellValue(scenarioName, "ExcelFileName");
			CommonOperations.move_Downloadedexcel(filename);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.INFO, "Excel downloaded successfully", true);
//			agCloseCurrentWindow();
		}
		if (DownloadType.equalsIgnoreCase("PDF")) {
			String filename = Multimaplibraries.getTestDataCellValue(scenarioName, "File");
			FDE_Operations.downloadReports();
			CommonOperations.move_DownloadedPDF(filename);
			Reports.ExtentReportLog("", Status.INFO, "PDF downloaded successfully", true);
//			agCloseCurrentWindow();
//			agGetWindowControlByInstance(1);
		}
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.AuditCLoseBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		
//		agGetWindowControlByInstance(1);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to Send Correspondance
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void E2ECorrespondace(String scenarioName, String login) {
		CaseListingOperations.searchCaseAndEdit(scenarioName, "lsmv_wpa_controller", "Receipt_Number");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String CorrespondanceMode = getTestDataCellValue(scenarioName, "CorrespondanceDropDown").toUpperCase();
		switch (CorrespondanceMode) {
		case "EMAIL":
			E2EEmailCorrespondance(scenarioName);
			LSMVLogin.Logout();
			CorrespondanceReply();
			LSMVLogin.Login(login);
			break;
		case "PHONE":
			E2EPhoneCorrespondance(scenarioName);
			break;
		case "LETTER":
			E2ELetterCorrespondance(scenarioName);
			break;
		case "FAX":
			E2EFaxCorrespondance(scenarioName);
			break;
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to Send Email Correspondance
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void E2EEmailCorrespondance(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Email Correspondance Starts", false);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
			agClick(FDEMoreOptionsPageObjects.moreOptions("Correspondence"));
			agSetStepExecutionDelay("2000");
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CorrespondanceReptNumber);
			String RCTNumber = agGetText(FDEMoreOptionsPageObjects.CorrespondanceReptNumber).split(">")[1];
			agSelectByVisibleText(FDEMoreOptionsPageObjects.CorrespondanceMode, "Email");
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.CorrespondanceBtnnew);
			agSetStepExecutionDelay("2000");
			agClearText(FDEMoreOptionsPageObjects.CorrespondanceTo);
			agSetValue(FDEMoreOptionsPageObjects.CorrespondanceTo, getTestDataCellValue(scenarioName, "ToAddress"));
			agClick(FDEMoreOptionsPageObjects.CatergoryDRopdownEmailReport);
			agSetStepExecutionDelay("2000");
			agClick(FDEMoreOptionsPageObjects
					.CategoryDropdwonValue(getTestDataCellValue(scenarioName, "EmailSummaryDropDown")));
			agSelectByVisibleText(FDEMoreOptionsPageObjects.selectpriority,
					getTestDataCellValue(scenarioName, "Priority"));
			agSelectByVisibleText(FDEMoreOptionsPageObjects.selectstatus, getTestDataCellValue(scenarioName, "Status"));
			agSetValue(FDEMoreOptionsPageObjects.noOfReminders, getTestDataCellValue(scenarioName, "NoofReminders"));
			agSetValue(FDEMoreOptionsPageObjects.reminderInterval,
					getTestDataCellValue(scenarioName, "ReminderInterval"));
			agSelectByVisibleText(FDEMoreOptionsPageObjects.selectReminderIntervalUnit,
					getTestDataCellValue(scenarioName, "ReminderIntervalUnit"));

			// Email Template
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.EmailTemplate);
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.EmailTemplateOkBtn);
			agClick(FDEMoreOptionsPageObjects.EmailTemplateChkBox);
			agClick(FDEMoreOptionsPageObjects.EmailTemplateOkBtn);
			agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.EmailTemplateOkBtn);

			uploadDocuments(scenarioName);

			agClick(FDEMoreOptionsPageObjects.EmailSave);
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.LetterCorrespondanceSavedSuccessfully);
			agClick(FDEMoreOptionsPageObjects.EmailCancel);
			agWaitTillVisibilityOfElement(
					FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.Subject, 2));
			agClick(FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.Subject, 2));
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.Send_Correspondence);
			agClick(FDEMoreOptionsPageObjects.Send_Correspondence);
			agSetStepExecutionDelay("3000");
			agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.sendEmailPopUp);
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CorrespondanceBtnnew);
			Reports.ExtentReportLog("Send Correspondence", Status.PASS, "", true);

			agSetStepExecutionDelay("3000");
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CorrespondanceBtnnew);

			// Wait for Reminder
			validateCorrespondanceScreen(scenarioName, RCTNumber, "EMAIL");
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.Cancel_correspondence);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.INFO, "Email Correspondance Ends", false);

		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, "Email Correspondance Failed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to Send Phone Correspondance
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void E2EPhoneCorrespondance(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Phone Correspondance Starts", false);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
			agClick(FDEMoreOptionsPageObjects.moreOptions("Correspondence"));
			agSetStepExecutionDelay("2000");
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CorrespondanceReptNumber);
			String RCTNumber = agGetText(FDEMoreOptionsPageObjects.CorrespondanceReptNumber).split(">")[1];
			agSelectByVisibleText(FDEMoreOptionsPageObjects.CorrespondanceMode, "Phone");
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.CorrespondanceBtnnew);
			agSetStepExecutionDelay("2000");
			// Phone Template
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.EmailTemplate);
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.EmailTemplateOkBtn);
			agClick(FDEMoreOptionsPageObjects.EmailTemplateChkBox);
			agClick(FDEMoreOptionsPageObjects.EmailTemplateOkBtn);
			agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.EmailTemplateOkBtn);
			agSetValue(FDEMoreOptionsPageObjects.PhoneNumber, getTestDataCellValue(scenarioName, "PhoneNo"));
			agClick(FDEMoreOptionsPageObjects
					.PhoneCategoryDropdwonValue(getTestDataCellValue(scenarioName, "EmailSummaryDropDown")));
			agSetValue(FDEMoreOptionsPageObjects.PhoneCorrespandanceSubject, RCTNumber);

			agClick(FDEMoreOptionsPageObjects.PhoneCorrespandanceSave);
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.LetterCorrespondanceSavedSuccessfully);
			agClick(FDEMoreOptionsPageObjects.PhoneCorrespondanceCancel);
			agSetStepExecutionDelay("3000");
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CorrespondanceBtnnew);
			agAssertContainsText(
					FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.Subject, 2),
					RCTNumber);
			agAssertContainsText(
					FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.ReceiptNo, 2),
					RCTNumber);
			agAssertContainsText(
					FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.Category, 2),
					getTestDataCellValue(scenarioName, "EmailSummaryDropDown"));
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.Cancel_correspondence);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.PASS, "Phone Correspondance is Sucessfull", false);
			Reports.ExtentReportLog("", Status.INFO, "Phone Correspondance Ends", false);

		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, "Phone Correspondance Failed", false);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to Send Letter Correspondance
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void E2ELetterCorrespondance(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Letter Correspondance Starts", false);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
			agClick(FDEMoreOptionsPageObjects.moreOptions("Correspondence"));
			agSetStepExecutionDelay("2000");
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CorrespondanceReptNumber);
			String RCTNumber = agGetText(FDEMoreOptionsPageObjects.CorrespondanceReptNumber).split(">")[1];
			agSelectByVisibleText(FDEMoreOptionsPageObjects.CorrespondanceMode, "Letter");
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.CorrespondanceBtnnew);
			agSetStepExecutionDelay("2000");
			// Letter Template
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.EmailTemplate);
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.EmailTemplateOkBtn);
			agClick(FDEMoreOptionsPageObjects.EmailTemplateChkBox);
			agClick(FDEMoreOptionsPageObjects.EmailTemplateOkBtn);
			agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.EmailTemplateOkBtn);
			agSetValue(FDEMoreOptionsPageObjects.LetterTo, getTestDataCellValue(scenarioName, "LetterTo"));
			agSetValue(FDEMoreOptionsPageObjects.LetterSubject, RCTNumber);
			agClick(FDEMoreOptionsPageObjects.LetterSave);
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.LetterCorrespondanceSavedSuccessfully);
			agClick(FDEMoreOptionsPageObjects.LetterCancel);
			agSetStepExecutionDelay("3000");
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CorrespondanceBtnnew);
			agAssertContainsText(
					FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.Subject, 2),
					RCTNumber);
			agAssertContainsText(
					FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.ReceiptNo, 2),
					RCTNumber);
			agAssertContainsText(FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.To, 2),
					getTestDataCellValue(scenarioName, "LetterTo"));
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.Cancel_correspondence);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.PASS, "Letter Correspondance is Sucesssfull", false);
			Reports.ExtentReportLog("", Status.INFO, "Letter Correspondance Ends", false);

		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, "Letter Correspondance Failed", false);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to Send Fax Correspondance
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void E2EFaxCorrespondance(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Fax Correspondance Starts", false);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
			agClick(FDEMoreOptionsPageObjects.moreOptions("Correspondence"));
			agSetStepExecutionDelay("2000");
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CorrespondanceReptNumber);
			String RCTNumber = agGetText(FDEMoreOptionsPageObjects.CorrespondanceReptNumber).split(">")[1];
			agSelectByVisibleText(FDEMoreOptionsPageObjects.CorrespondanceMode, "Fax");
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.CorrespondanceBtnnew);
			agSetStepExecutionDelay("2000");
			agSetValue(FDEMoreOptionsPageObjects.FaxTo, getTestDataCellValue(scenarioName, "FaxTo"));
			agClick(FDEMoreOptionsPageObjects
					.CategoryDropdwonValue(getTestDataCellValue(scenarioName, "EmailSummaryDropDown")));
			agSelectByVisibleText(FDEMoreOptionsPageObjects.selectpriority,
					getTestDataCellValue(scenarioName, "Priority"));
			agSelectByVisibleText(FDEMoreOptionsPageObjects.selectstatus, getTestDataCellValue(scenarioName, "Status"));
			agSetValue(FDEMoreOptionsPageObjects.noOfReminders, getTestDataCellValue(scenarioName, "NoofReminders"));
			agSetValue(FDEMoreOptionsPageObjects.reminderInterval,
					getTestDataCellValue(scenarioName, "ReminderInterval"));
			agSelectByVisibleText(FDEMoreOptionsPageObjects.selectReminderIntervalUnit,
					getTestDataCellValue(scenarioName, "ReminderIntervalUnit"));

			// Email Template
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.EmailTemplate);
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.EmailTemplateOkBtn);
			agClick(FDEMoreOptionsPageObjects.EmailTemplateChkBox);
			agClick(FDEMoreOptionsPageObjects.EmailTemplateOkBtn);
			agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.EmailTemplateOkBtn);
			uploadDocuments(scenarioName);
			agClick(FDEMoreOptionsPageObjects.FaxSave);
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.LetterCorrespondanceSavedSuccessfully);
			agClick(FDEMoreOptionsPageObjects.FaxCancel);
			agWaitTillVisibilityOfElement(
					FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.Subject, 2));
			agClick(FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.Subject, 2));
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.Send_Correspondence);
			agClick(FDEMoreOptionsPageObjects.FaxSend);
			agSetStepExecutionDelay("3000");
			agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.sendEmailPopUp);
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CorrespondanceBtnnew);
			Reports.ExtentReportLog("Send Correspondence", Status.PASS, "", true);

			agSetStepExecutionDelay("3000");
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CorrespondanceBtnnew);

			validateCorrespondanceScreen(scenarioName, RCTNumber, "FAX");

			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.Cancel_correspondence);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.INFO, "Fax Correspondance Ends", false);

		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, "Fax Correspondance Failed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to Send Reply to Correspondance Email
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void CorrespondanceReply() {
		OutlookWebMail.ReplyCorrespondanceEmail();
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to validate reminder records in
	 *             corresspondance screen
	 * @InputParameters: Scenario Name, RCT number, CorrespondanceType
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void validateCorrespondanceScreen(String scenarioName, String RCTNumber, String type) {

		int actualRecords = agGetElementList(FDEMoreOptionsPageObjects.correspondanceRemainderCount).size();
		int totalRecords = Integer.parseInt(getTestDataCellValue(scenarioName, "NoofReminders")) + 1;
		int counter = 0;
		int remainderCount = 0;
		while ((totalRecords != actualRecords - 1) && counter <= 40) {
			agClick(FDEMoreOptionsPageObjects.correspondanceRefresh);
			counter++;
			actualRecords = agGetElementList(FDEMoreOptionsPageObjects.correspondanceRemainderCount).size();
		}
		for (int index = 0; index < totalRecords; index++) {
			agAssertContainsText(
					FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.Subject, index + 2),
					RCTNumber);
			agAssertContainsText(
					FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.ReceiptNo, index + 2),
					RCTNumber);
			if (type.equalsIgnoreCase("EMAIL"))
				agAssertContainsText(
						FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.To, index + 2),
						getTestDataCellValue(scenarioName, "ToAddress"));
			else if (type.equalsIgnoreCase("FAX"))
				agAssertContainsText(
						FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.To, index + 2),
						getTestDataCellValue(scenarioName, "FaxTo"));
			String category = agGetText(
					FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.Category, index + 2));
			if (category.equalsIgnoreCase(getTestDataCellValue(scenarioName, "EmailSummaryDropDown"))) {
				agAssertContainsText(FDEMoreOptionsPageObjects
						.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.Status, index + 2), "Open");
				agAssertContainsText(FDEMoreOptionsPageObjects
						.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.ReminderCount, index + 2),
						getTestDataCellValue(scenarioName, "NoofReminders"));
			} else if (category.equalsIgnoreCase("Reminder")) {
				remainderCount++;
				agAssertContainsText(FDEMoreOptionsPageObjects
						.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.Status, index + 2), "Close");
			}
		}
		if (remainderCount == Integer.parseInt(getTestDataCellValue(scenarioName, "NoofReminders"))) {
			Reports.ExtentReportLog("", Status.PASS, "Reminders Sent Correctly", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Reminders Sent InCorrectly", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to upload document to correspondance
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void uploadDocuments(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.FAIL, "Document Uplaod Starts", false);
			agClick(FDEMoreOptionsPageObjects.LocalDocument);
			agUploadDocuments(lsmvConstants.lsmvXmlPath + getTestDataCellValue(scenarioName, "File"));
			agWaitTillVisibilityOfElement(
					FDEMoreOptionsPageObjects.docName.replace("%file", getTestDataCellValue(scenarioName, "File")));
			agClick(FDEMoreOptionsPageObjects.caseDocument);
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.caseDocumentAdd);
			if (agIsVisible(FDEMoreOptionsPageObjects.caseDocumentCheckBox)) {
				agClick(FDEMoreOptionsPageObjects.caseDocumentCheckBox);
				agClick(FDEMoreOptionsPageObjects.caseDocumentAdd);
				agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.caseDocumentAdd);
			} else {
				agClick(FDEMoreOptionsPageObjects.caseDocumentClose);
				agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.caseDocumentClose);
			}
			Reports.ExtentReportLog("", Status.PASS, "Document Uplaod is Sucessfull", true);
			Reports.ExtentReportLog("", Status.FAIL, "Document Uplaod Ends", false);

		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, "Document Uplaod Failed", true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to validate Product Event Type
	 *             validation report
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ProductEventTypeValdationInAuditTrial() {

		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Audit Trail"));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.auditTrilReport);
		CommonOperations.setListDropDownValue(FDEMoreOptionsPageObjects.excelDownload_Dropdown, "EXCEL");
		downloadAuditTrial();
		agCloseCurrentWindow();
		agGetWindowControlByInstance(1);
		CommonOperations.setListDropDownValue(FDEMoreOptionsPageObjects.excelDownload_Dropdown, "PDF");
		downloadAuditTrial();
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.ATReportTxt);
		agClick(FDEMoreOptionsPageObjects.ATDownloadBtn);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		agCloseCurrentWindow();
		agGetWindowControlByInstance(1);

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to validate Product Event Type Audit
	 *             Trial Download
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downloadAuditTrial() {
		agClick(FDEMoreOptionsPageObjects.downloadBtn);
		agSetStepExecutionDelay("15000");
		agGetCurrentWindow();
		agSetStepExecutionDelay("10000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "AuidtTrial downloaded successfully", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to Verify case notes created.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 01-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCaseNotes(String scenarioName) {
		String RecieptNumber = agGetText(FullDataEntryFormPageObjects.RecptNumber);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Case Notes"));
		if (agIsVisible(FDEMoreOptionsPageObjects.NotesReptNum) == true) {
			agSetStepExecutionDelay("2000");
			agClick(FDEMoreOptionsPageObjects.NotesRctNum(RecieptNumber));
			Reports.ExtentReportLog("", Status.INFO, "Case Notes Listed", true);

			/*
			 * boolean validDescription = false; validDescription =
			 * agGetText(FDEMoreOptionsPageObjects.Description).equalsIgnoreCase(
			 * getTestDataCellValue(scenarioName, "Description"));
			 * System.out.println("Actual Text from Web: "+agGetText(
			 * FDEMoreOptionsPageObjects.Description));
			 * System.out.println("Actual Text from TestSheet: "+getTestDataCellValue(
			 * scenarioName, "Description")); if (validDescription) {
			 * Reports.ExtentReportLog("", Status.PASS,
			 * "Case Notes has valid Description displayed", true); }else {
			 * Reports.ExtentReportLog("", Status.FAIL,
			 * "Case Notes has INVALID Description displayed", true); }
			 */

			downloadAndReadPDFAttachment(scenarioName);

			agClick(FDEMoreOptionsPageObjects.NoteCancel);
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.CLoseNote);
			ToolManager.agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.NotePopup);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Case Notes NOT Listed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to Verify case notes created.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 01-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downloadAndReadPDFAttachment(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String fileName = getTestDataCellValue(scenarioName, "FileName");
		String filePath = null;

		try {
			agClick(FDEMoreOptionsPageObjects.caseNoteDocName(fileName));
			CommonOperations.save_GeneratedReport(fileName);

			filePath = lsmvConstants.path;
			System.out.println("filePath: " + filePath);
			PDFOperations.pdfverificationForVisible(filePath + "\\" + fileName,
					getTestDataCellValue(scenarioName, "Description"));

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to create new version of case
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 08-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createNewVersion(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Create New Version"));
		agIsVisible(FDEMoreOptionsPageObjects.createNewVersionHeader);
		agClick(FDEMoreOptionsPageObjects.reasonDropdown);
		agSetStepExecutionDelay("2000");
		agClick(FDEMoreOptionsPageObjects.otherOptions);
		agClick(FDEMoreOptionsPageObjects.submitNewVersion);
		CommonOperations.writeCreatedVersionRecptNo_FDESave(scenarioName, "FDE_General");
		CommonOperations.captureScreenShot(true);
		agClick(FullDataEntryFormPageObjects.createVersionOkBtn);

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to send Followup Questionre
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 10-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void FollowUpQuestenire(String scenarioName, String userName) {
		CaseListingOperations.searchCaseAndEdit(scenarioName, "lsmv_wpa_controller", "Receipt_Number");
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			Reports.ExtentReportLog("", Status.INFO, "FollowUp Questionire Starts", false);
			agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
			agClick(FDEMoreOptionsPageObjects.moreOptions("Correspondence"));
			agSetStepExecutionDelay("2000");
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CorrespondanceReptNumber);
			String RCTNumber = agGetText(FDEMoreOptionsPageObjects.CorrespondanceReptNumber).split(">")[1];
			System.out.println(RCTNumber);
			agWaitTillVisibilityOfElement(
					FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.Subject, 2));
			agClick(FDEMoreOptionsPageObjects.CorrespondanceScreenValue(FDEMoreOptionsPageObjects.Subject, 2));
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.FollowUpModeDropDown);
			agSelectByVisibleText(FDEMoreOptionsPageObjects.FollowUpModeDropDown,
					getTestDataCellValue(scenarioName, "FollowUpMode"));
			String queryMode = getTestDataCellValue(scenarioName, "FollowUpFormat");
			if (queryMode.equalsIgnoreCase("PDF Document")) {
				agClick(FDEMoreOptionsPageObjects.PDFDocRadioButton);
				if (agIsVisible(FDEMoreOptionsPageObjects.confirmationOKButton))
					agClick(FDEMoreOptionsPageObjects.confirmationOKButton);
				// Code To be added for PDF Document
			} else {
				FollowUpWebLinkQuestinere(scenarioName);
			}
			if (getTestDataCellValue(scenarioName, "FollowUpMode").equalsIgnoreCase("Email")) {
				LSMVLogin.Logout();
				OutlookWebMail.FollowUpWeblink(scenarioName);
				FUQuestionnarieOperations.FollowupQuestionreWeblink(scenarioName);
				LSMVLogin.Login(userName);
			}
			Reports.ExtentReportLog("", Status.INFO, "FollowUp Questionire Ends", false);
		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, "FollowUp Questionire Failed", false);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to send Followup Weblink Questionre
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 10-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void FollowUpWebLinkQuestinere(String scenarioName) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "FollowUp Weblink Questionire Starts", false);
			agSetValue(FDEMoreOptionsPageObjects.WeblinkReceiverTextBox,
					getTestDataCellValue(scenarioName, "ToAddress"));
			uploadDocuments(scenarioName);
			Reports.ExtentReportLog("", Status.INFO, "FollowUp Weblink Questionire ", true);
			agClick(FDEMoreOptionsPageObjects.FollowUpSendButton);
			Reports.ExtentReportLog("", Status.INFO, "FollowUp Weblink Questionire Ends", false);
			agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.CorrespondanceBtnnew);
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.Cancel_correspondence);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, "FollowUp Weblink Questionire Failed", false);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to Verify the audit trail report in
	 *             PDF
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 15-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void auditTrialReportDownload(String scenarioName, int downloadStepNumber) {
		agSetStepExecutionDelay("3000");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String filename = getTestDataCellValue(scenarioName, "FileName");
		System.out.println("filename: " + filename);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Audit Trail"));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.auditTrilReport);
		Reports.ExtentReportLog("", Status.PASS, "As Expected", true);

		CommonOperations.almStepNumber(String.valueOf(downloadStepNumber));
		agClick(FDEMoreOptionsPageObjects.downloadAsPDF_Btn);
		try {
			agSetStepExecutionDelay("15000");
			agGetCurrentWindow();
			Thread.sleep(12000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// FDE_Operations.downloadReports();
		CommonOperations.move_DownloadedPDF(filename);
		Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
		Reports.ExtentReportLog("", Status.PASS, "<br />" + "Export Type: PDF", false);

		agCloseCurrentWindow();
		agGetWindowControlByInstance(1);
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.closeBtn);
		agClick(FDEMoreOptionsPageObjects.closeBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to Verify the audit trail report
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 07-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyLabellingDatainauditTrial(String Value) {

		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Audit Trail"));

		if (Value.equalsIgnoreCase("0")) {
			agSetStepExecutionDelay("2000");
			// agClick(FDEMoreOptionsPageObjects.LastIcon);
			// agSetStepExecutionDelay("2000");
			// agClick(FDEMoreOptionsPageObjects.Page34);
			//
			// String Labelling = agGetText(FDEMoreOptionsPageObjects.LabellingCheck);
			// String Country = agGetText(FDEMoreOptionsPageObjects.CountryCheck);
			//
			// if (agIsVisible(FDEMoreOptionsPageObjects.LabellingCheck) == true
			// && agIsVisible(FDEMoreOptionsPageObjects.CountryCheck) == true) {
			// Reports.ExtentReportLog("", Status.INFO, "Labeling data is captured in audit
			// trial report.", true);
			//
			// }

			for (int i = 2; i < 40; i++) {
				ArrayList<String> Editable = MoreActionsOperations.GetTableContextCase();
				agSetStepExecutionDelay("5000");

				// if (Editable.contains("CUBA (CU)")) {

				if (agIsVisible(FDEMoreOptionsPageObjects.LabellingCheck) == true) {

					Reports.ExtentReportLog("", Status.PASS, "As Expected <br />", true);
					break;

					// } else
					// if(agIsVisible(FDEMoreOptionsPageObjects.PageNoIcon(String.valueOf(i))) ==
					// true) {
					// i--;
					// agClick(FDEMoreOptionsPageObjects.PageNoIcon(String.valueOf(i)));
					// if (agIsVisible(FDEMoreOptionsPageObjects.LabellingCheck) == true) {
					//
					// Reports.ExtentReportLog("", Status.PASS, "Labeling data is captured in audit
					// trial report.<br />",
					// true);
					// i++;
					// agClick(FDEMoreOptionsPageObjects.PageNoIcon(String.valueOf(i)));
					// CommonOperations.captureScreenShot(true);
					// break;
					// }
					// }else {

					// agClick(FDEMoreOptionsPageObjects.PageNoIcon(String.valueOf(i)));
					// }
					// } else {
				} else {

					agClick(FDEMoreOptionsPageObjects.PageNoIcon(String.valueOf(i)));
				}
			}

		} else {
			agSetStepExecutionDelay("2000");

			for (int i = 2; i < 10; i++) {
				ArrayList<String> Editable = MoreActionsOperations.GetTableContext();

				if (Editable.contains("IB (2)")) {

					if (agIsVisible(FDEMoreOptionsPageObjects.LabellingUnlabelledCheck) == true) {
						agJavaScriptExecuctorScrollToElement(FDEMoreOptionsPageObjects.LabellingUnlabelledCheck);
						CommonOperations.captureScreenShot(true);
						agJavaScriptExecuctorScrollToElement(FDEMoreOptionsPageObjects.CountryIBCheck);
						CommonOperations.captureScreenShot(true);

					}
				} else if (Editable.contains("CUBA (CU)")) {

					if (agIsVisible(FDEMoreOptionsPageObjects.LabellingUnlabelledCheck) == true) {
						agJavaScriptExecuctorScrollToElement(FDEMoreOptionsPageObjects.LabellingUnlabelledCheck);
						CommonOperations.captureScreenShot(true);

					}

				} else {
					agClick(FDEMoreOptionsPageObjects.PageNoIcon(String.valueOf(i)));
				}
				agClick(FDEMoreOptionsPageObjects.PageNoIcon(String.valueOf(i)));

			}
			agSetStepExecutionDelay("2000");
			Reports.ExtentReportLog("", Status.PASS, "As Expected <br />", true);
		}

		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.AuditCLoseBtn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Get list of editable values
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 17-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> GetTableContext() {
		ArrayList Al = new ArrayList<>();

		List<WebElement> EditableText = agGetElementList(FDEMoreOptionsPageObjects.Tablevalues);

		for (int i = 0; i < EditableText.size(); i++) {

			// loading text of each element in to array all_elements_text
			Al.add(EditableText.get(i).getText());

			// to print directly

		}
		return Al;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Get list of editable values
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 17-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> GetTableContextCase() {
		ArrayList Al = new ArrayList<>();

		List<WebElement> EditableText = agGetElementList(FDEMoreOptionsPageObjects.Tablevalues);

		for (int i = 0; i < EditableText.size(); i++) {

			// loading text of each element in to array all_elements_text
			Al.add(EditableText.get(i).getText());

		}
		return Al;

	}

	public static void DSURCountryVerificationInAuditTrial() {
		agSetStepExecutionDelay("3000");
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Audit Trail"));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.auditTrilReport);
		agIsVisible(FDEMoreOptionsPageObjects.dsurCountryVerification);
		CommonOperations.captureScreenShot(true);
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.closeAuditTrial);
		agSetStepExecutionDelay("3000");
	}
	
	
	public static void moreOptionsSwitchFormNavigation() {
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
	if(agIsVisible(FDEMoreOptionsPageObjects.moreOptionSwitchNavigation)) {
			agJavaScriptExecuctorMouseHover(FDEMoreOptionsPageObjects.moreOptionSwitchNavigation);
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.moreOptionsFDENavigation);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.receiptNumber);
			if(agIsVisible(FullDataEntryFormPageObjects.receiptNumber)) {
				agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
				agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);
			}
		}	
	}
	
	
	public static boolean verifymoreOptions(String scenarioName,String option,String status) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);		
		boolean mReturn=false;
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agSetStepExecutionDelay("1000");
		if ((agIsVisible(FDEMoreOptionsPageObjects.moreOptions(option))==true) && (status=="check")) {
			mReturn=true;
			agClick(FDEMoreOptionsPageObjects.moreOptions(option));
			
			CaseDeleteOperations.setDeleteReason(scenarioName);
			agSetStepExecutionDelay("3000");
			agClick(FullDataEntryFormPageObjects.ActionOkBtn);
			agSetStepExecutionDelay("3000");
	         
		}
		else if ((agIsVisible(FDEMoreOptionsPageObjects.moreOptions(option))==false) && (status=="uncheck")) {
			Reports.ExtentReportLog("", Status.PASS, option+" option is not displayed in more actions", true);
		}
		else
		{
			Reports.ExtentReportLog("", Status.FAIL, option+" option is not displayed in more actions", true);
		}
		
		return mReturn;
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method created to open audit trial report tab
	 * @InputParameters: 
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 25-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void openAuditTrialReport() {
		agSetStepExecutionDelay("8000");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agSetStepExecutionDelay("8000");
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.moreOptions("Audit Trail"));
		agClick(FDEMoreOptionsPageObjects.moreOptions("Audit Trail"));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.auditTrilReport);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	
	/**********************************************************************************************************
	 * @Objective: The below method created to close audit trial report tab
	 * @InputParameters: 
	 * @OutputParameters:
	 * @author:Abhisek Ghosh
	 * @Date : 12-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void closeAuditTrialReport() {
		agSetStepExecutionDelay("3000");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDEMoreOptionsPageObjects.closeBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below Method is created to Verify the Health Canada ID Number and Class Of Device 
	 *              in audit trail report screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 12-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void auditTrial_HCID_COD(String scenarioName) {
		agSetStepExecutionDelay("3000");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions("Audit Trail"));
		agWaitTillVisibilityOfElement(FDEMoreOptionsPageObjects.auditTrilReport);
		
		if(agIsVisible(FDEMoreOptionsPageObjects.auditTrilReport)) {
			
			Reports.ExtentReportLog("", Status.INFO, "Audit trail report is generated", false);	
			
			if((scenarioName).contains("LSMV_OQ_HCD_Product_Library_Product_Coding")) {
				
				if(agIsVisible(FDEMoreOptionsPageObjects.auditTrail_HCID) && agIsVisible(FDEMoreOptionsPageObjects.auditTrail_COD)) {
					
					agJavaScriptExecuctorScrollToElement(FDEMoreOptionsPageObjects.auditTrail_COD);
					Reports.ExtentReportLog("", Status.PASS, "As Expected"+
							"<br />"+ "Health Canada ID number and class of device is captured in audit trial report", true);
				}
				
				else {
					Reports.ExtentReportLog("", Status.FAIL, "Not As Expected"+
							"<br />"+ "Health Canada ID number and class of device is not captured in audit trial report", true);
				}
			}
		}
		else {
			Reports.ExtentReportLog("", Status.FAIL, "Not As Expected"+
					"<br />"+ "Audit trail report is not generated", true);
		}
		
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}	

	
}
