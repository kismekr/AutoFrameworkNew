package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class ContactLookUpPageObjects {
	
	public static String contactID_TextBox = "xpath#//input[@id ='contactsLookupForm:contactId']";
	public static String Country_DropDown = "xpath#//div[@id='contactsLookupForm:C-1015']";
	public static String firstName_TextBox = "xpath#//input[@id ='contactsLookupForm:firstName']";
	public static String middleName_TextBox = "xpath#//input[contains(@id,  'contactsLookupForm:') and @title='Middle Name']";
	public static String lastName_TextBox = "xpath#//input[@id ='contactsLookupForm:lastName']";
	public static String countryCode_TextBox = "xpath#//input[contains(@id,  'contactsLookupForm:') and @title='Country Code']";
	public static String areaCode_TextBox = "xpath#///input[contains(@id,  'contactsLookupForm:') and @title='Area Code']";
	public static String number_TextBox = "xpath#//input[@id ='contactsLookupForm:phoneNumber']";
	public static String extnNo_TextBox = "xpath#//input[contains(@id,  'contactsLookupForm:') and @title='Extn No']";
	public static String emailAddress_TextBox = "xpath#//input[@id ='contactsLookupForm:email']";
	public static String degree_TextBox = "xpath#//input[contains(@id,  'contactsLookupForm:') and @title='Degree']";
	public static String otherPhoneNo_TextBox = "xpath#//input[@id ='contactsLookupForm:otherPhones']";
	public static String specialization_DropDown = "xpath#//div[@id='contactsLookupForm:CL-345']";
	public static String ifOtherSpecify_TextBox = "xpath#//input[@id ='contactsLookupForm:otherVal']";
	public static String department_DropDown = "xpath#//div[@id='contactsLookupForm:department']";
	public static String primaryAccount_TextBox = "xpath#//input[contains(@id,  'contactsLookupForm:') and @title='Organization']";
	public static String postalCode_TextBox = "xpath#//input[@id ='contactsLookupForm:postalCode']";
	public static String customerMasterID_TextBox = "xpath#//input[@id ='contactsLookupForm:CustIdField']";
	public static String isAlsoAnE2BContact_CheckBox = "Is also an E2B Contact";
	public static String interchangeID_TextBox = "xpath#//input[@id ='contactsLookupForm:interChangeId']";
	
	public static String search_Button = "xpath#//button[@id= 'contactsLookupForm:cntSearch']";
	public static String clear_Button = "xpath#//button[@id= 'contactsLookupForm:cntClear']";
	public static String cancel_Button = "xpath#//button[@id= 'contactsLookupForm:topCancelButton']";

	
}
