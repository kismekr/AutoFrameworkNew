package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class ActiveMoietyPageObjects {
	

	
	public static String new_Btn = "xpath#//a[@id='listingForm:newId']";
	public static String activeMoiety_Lable = "xpath#//div[@class='panel-title']/label[text()='Active Moiety']";
	public static String activeMoiety_TxtField = "xpath#//input[@id='activeMoietyDetails:activeMoiety']";
	public static String pharmacologicalClass_Lookupicon = "xpath#//img[contains(@id,'activeMoietyDetails:pharmacologicalLookup')]";
	public static String description_TextArea = "xpath#//textarea[@id='activeMoietyDetails:activeMoietyDesc']";
	public static String save_Btn = "xpath#//button[@id='activeMoietyDetails:visibleSave']";
	public static String pharmacologicalClass_label = "xpath#//span[@id='pharmacologicalClassLookupForm:pharmacologicalClassLookupDialog_title'][text()='Pharmacological Class Lookup']";
	public static String keywordSearchLookup_TxtField = "xpath#//input[@id='pharmacologicalClassLookupForm:keywordId']";
    public static String lookupsearch_Btn = "xpath#//button[@id='pharmacologicalClassLookupForm:subSearchButton']";
	public static String checkbox_lookup = "xpath#//td/span[text()='%s']/ancestor::td/preceding::td[@class='ui-selection-column']/div/child::div/span";
	public static String lookupOk_Btn = "xpath#//button[@id='pharmacologicalClassLookupForm:okButtonBottom']";
	public static String validation_Popup = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	//public static String deletevalidation_Popup = "xpath#//div[@id='listingForm:deleteconfirm']";
	public static String deletevalidation_Popup = "xpath#//div[@class='ui-dialog-content ui-widget-content']/span[@class='ui-confirm-dialog-message']";
	public static String downloadIcon = "xpath#//a[@id='listingForm:actionId']";
	public static String exporttoExcel_link = "xpath#//button[contains(@id,'listingForm')]/span[text()='Export To Excel']";
	public static String exporttoExcel_popup = "xpath#//span[@id='listingForm:columnSelectionDialogId_title']";
	public static String export_Btn= "xpath#//button[@id='listingForm:submitId']";
	public static String exportexcelcancel_Btn= "xpath#//button[@id='listingForm:cancelDialogId']";
	public static String edit_Icon= "xpath#//img[@id='listingForm:moietyDataTable:0:editImgId']";
	public static String get_PHARMACOLOGICALCLASS= "xpath#//label[@id='activeMoietyDetails:pharmacologicalClassDataTable:%s:tName']";
	public static String cancel_Btn= "xpath#//button[@id='activeMoietyDetails:cancelId']";
	public static String get_ListofActiveMoiety= "xpath#//tbody[@id='listingForm:moietyDataTable_data']/ancestor::table/tbody/tr/td[3]";
 	public static String columnHeader = "xpath#(//tbody[@id='listingForm:moietyDataTable_data']/ancestor::table/tbody/tr/td[3])[{%count}]";
	
	public static String validationOk_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']";
	public static String keywordSearch_TxtField = "xpath#//input[@id='listingForm:searchCriteria']";
	public static String search_Icon = "xpath#//a[@id='listingForm:searchbutton']";
	public static String paginator = "xpath#//div[@id='listingForm:moietyDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String get_activtemoiety = "xpath#//tbody[@id='listingForm:moietyDataTable_data']/tr/td[@class='EditIcon']/following-sibling::td[1]";
	public static String refresh_Icon = "xpath#//a[@id='listingForm:refreshImage']";
	public static String listingScreen_CheckBoxs = "xpath#//td[text()='%s']/ancestor::tbody[@id='listingForm:moietyDataTable_data']/tr/td/div/child::div/span";
	public static String delete_Btn = "xpath#//a[@id='listingForm:deleteId']";
	public static String deletePopupYes_Btn = "xpath#//button[@id='listingForm:confirmation_yes']";
	public static String noRecordsFound = "xpath#//tbody[@id='listingForm:moietyDataTable_data']/tr/td[text()='No records found.']";
	
	/**********************************************************************************************************
	 * Objective:The below method is created to send index at runtime.
	 * Input Parameters: runTimeLabel
	 * Scenario Name Output
	 * Parameters:
	 * @author:Avinash K Date :21-Oct-2019 Updated by and when   	 
	**********************************************************************************************************/		
    		
    public static String getPHARMACOLOGICALCLASS(String runTimeLabel) {
        String value = get_PHARMACOLOGICALCLASS;
        String value2;
        value2 = value.replace("%s", runTimeLabel);
        return value2;
    }
	/**********************************************************************************************************
	 * @Objective:get substance name by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:DushyanthMahesh Date :16-September-2019 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderList(String num) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}
	
	/**********************************************************************************************************
	 * Objective:The below method is created to send value by passing value at runtime.
	 * Input Parameters: runTimeLabel
	 * Scenario Name Output
	 * Parameters:
	 * @author:Avinash K Date :17-Oct-2019 Updated by and when   	 
	**********************************************************************************************************/		
    		
    public static String selectCheckbox(String runTimeLabel) {
        String value = checkbox_lookup;
        String value2;
        value2 = value.replace("%s", runTimeLabel);
        return value2;
    }
	
	
	/**********************************************************************************************************
	 * @Objective:The below method is created to select checkbox by passing value at runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name Output
	 * @Parameters:
	 * @author:Avinash K Date :18-Oct-2019 Updated by and when   	 
	**********************************************************************************************************/		
    		
    public static String selectListingCheckbox(String runTimeLabel) {
        String value = listingScreen_CheckBoxs;
        String value2;
        value2 = value.replace("%s", runTimeLabel);
        return value2;
    }
	
	
	
}
