package com.arisglobal.framework.components.lsmv.L10_3.OR;

public abstract class CaseManagementPageObjects {

	public static String fullDataEntryForm = "xpath#//a[@class='ui-menuitem-link ui-corner-all']/span[contains(text(),'Full data entry form')]";
	public static String caseListing = "xpath#//a[@id='headerForm:adverseList2LayoutId']";
	public static String caseSeries = "xpath#//span[contains(text(),'Case series')]";
	public static String caseSeriesLable = "xpath#//label[@id='CSDL:assignmentLabel']";
	public static String correspondenceListing = "xpath#//span[contains(text(),'Correspondence listing')]";
	public static String correspondenceListingLable = "xpath#//div[@id='corrListForm:header']/label[text()='Unread Correspondence']";
	public static String bulkImports = "xpath#//span[contains(text(),'Bulk imports')]";
	public static String bulkImportsLable = "xpath#//span[@id='importDataListForm:header']/label[contains(text(),'Case Triage > Bulk Imports')]";
	public static String FollowupQueryTracker = "xpath#//span[contains(text(),'Follow up query tracker')]";
	public static String FollowupQueryTrackerLable = "xpath#//div[@id='questionaryListform:header']/label[contains(text(),'Follow Up Query Tracker')]";
	public static String e2bMessageQueueListingLable = "xpath#//span[@id='safetyE2BMessageQueueListform:header']/label[text()='E2B Message Queue']";
	public static String FDElable = "xpath#//label[contains(text(),'Case Units')]";
	public static String senderOrganizationTextField = "xpath#//input[@id='adverseEventNew:basicDetailsDataTable:reportedSenderId']";

	public static String saveButton = "xpath#//a[@id='adverseEventNew:visibleSave1']";

	public static String saveCaseOnEditButton = "xpath#//a[@id='duplicateVisibleSave']";
	public static String TabNavigtion = "xpath#//li[@role='presentation']/a[@role='tab']/span[text()='%s']";
	public static String classificationTypeFollowUp = "xpath#//a[@id='adverseEventNew:followUp']";
	// -----------------
	public static String classificationTypeDuplicate = "xpath#//a[@id='adverseEventNew:duplicate']";
	// -----------------

	public static String gridView = "xpath#//div[contains(@id,'ui-panel')]/div/p-header/label[text()='%s%']/following-sibling::span/a[text()='Grid View']";
	public static String FormView = "xpath#//div[contains(@id,'ui-panel')]/div/p-header/label[text()='%s%']/following-sibling::span/a[text()='Form View']";
	public static String sourceDocumentsTab = "xpath#//span[@class='ui-panel-title']/label[text()='Source Documents']";
	public static String sourceDocFileName = "xpath#//td[@class='uploadTabLblName']/a";
	public static String documentCheck = "xpath#//canvas[@id='page1']";

	public static String cancelButton = "xpath#//a[@id='adverseEventNew:cancelId']";
	public static String saveandExitButton = "xpath#//a[@id='adverseEventNew:saveAndExitId']";
	public static String validationPopup_OkButton = "xpath#//button[@id='mandatoryDialogform:okButton']//span[text()='OK']";
	public static String Popup_onSave_GetRecptNo = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";

	// Case Management Menu Navigations validation point
	public static String caseManagementMenu = "xpath#//div[@id='headerForm:menuMainId']//ul[@class='ui-menu-list ui-helper-reset']/child::li/a/span[contains(text(),'Case Management')]/following::ul/li/a/span[contains(text(),'%s')]";
	public static String caseManagementMenuSubMenu = "xpath#//div[@id='headerForm:menuMainId']//ul[@class='ui-menu-list ui-helper-reset controloverflow']/child::li/a/span[contains(text(),'Case Management')]//following::ul/li/a/span[contains(text(),'%s')]";
	public static String caseManagementSubMenu = "xpath#//div[@id='headerForm:menuMainId']//ul[@class='ui-menu-list ui-helper-reset']/child::li/a/span[contains(text(),'Case Management')]//following::ul/li/a/following::ul/li/a/span[contains(text(),'%s')]";
	public static String unstructuredFormSubMenu = "xpath#//div[@id='headerForm:menuMainId']//ul[@class='ui-menu-list ui-helper-reset']/child::li/a/span[contains(text(),'Case Management')]//following::ul/li/a/following::ul/li[2]/a/span[contains(text(),'Unstructured form')]";
	public static String caseManagementHover = "xpath#//li[@id='headerForm:adverseMenu']";
	public static String newCaseHover = "xpath#//div[@id='headerForm:menuMainId']//ul[@class='ui-menu-list ui-helper-reset']/child::li/a/span[contains(text(),'Case Management')]//following::ul/li/a/span[contains(text(),'New Case')]";
	public static String caseListingkeywordSearchTextbox = "xpath#//input[@id='ADL:newBasicId']";
	public static String FDEinitialReceiveDate = "xpath#//input[@id='adverseEventNew:basicDetailsDataTable:RecievedDate-102121_input']";
	public static String E2BMsgQkeywordSearchTextbox = "xpath#//input[@type='text'][@placeholder='Search...']";
	public static String caseSerieskeywordSearchTextbox = "xpath#//input[@id='CSDL:keyword']";
	public static String unreadCorreskeywordSearchTextbox = "xpath#//input[@id='corrListForm:keywordSearch']";
	public static String bulkImportskeywordSearchTextbox = "xpath#//input[@id='importDataListForm:searchText']";
	public static String followUpkeywordSearchTextbox = "xpath#//input[@id='questionaryListform:keywordSearch']";
	public static String e2bMessageQueueListing = "xpath#//a[contains(@id,'headerForm:aeE2BMessageQueueListingId')]";
	public static String emailIntakeMessageQueue = "xpath#//a[contains(@id,'EmailIntakeMessageQueueListingId')]";
	public static String senderEmailTitle = "xpath#//div[@title='SENDER EMAIL']//span[1]";

	// More Options FDE form

	public static String moreOptionsHover = "xpath#//a[@id='adverseEventNew:actionsLinkID']";
	public static String moreReporteroptionsHover = "xpath#//span[contains(text(),'More Report Actions')]";
	public static String caseSummaryLink = "xpath#//span[@class='ui-menuitem-text'][contains(text(),'Case Summary')]";
	public static String caseSummaryGenerate = "xpath#//a[@id='adverseEventNew:caseSummaryReportGenerate']";
	public static String dowloadIcon = "xpath#//*[@id='download']";
	public static String ReportGenerationacess = "xpath#//span[@id='dataPrivacyAccess_title']";
	public static String PublicRadiobutton = "xpath#//*[text()='Public']";
	public static String GenerateButton = "xpath#//button[@id='generateReport']";
	public static String pdfFrameid = "openCaseSummaryDiolog:test_adv";
	public static String cancelIcon = "xpath#//span[@id='openCaseSummaryDiolog:CaseSummaryDialog_title']/following-sibling::a[1]";
	public static String okButton = "xpath#//button[@id='mandatoryDialogform:okButton']//span[@class='ui-button-text ui-c'][contains(text(),'OK')]";
	public static String downLoadReports = "xpath#//ul[contains(@class,'ui-widget-content')]/li/a/span[@class='ui-menuitem-text'][contains(text(),'%s')]";
	public static String moreOptionsNavigation = "xpath#//div[@id='adverseEventNew:moreButtonsDiv']/child::table/tbody/tr/td/a[contains(text(),'%s')]";

	public static String homeButton = "xpath#//a/img[contains(@id,'headerForm:j_id')][contains(@src,'/LSMV101/images/Home_off')]";
	public static String dashboard = "xpath#//a[@id='headerForm:home'][text()='Dashboard']";

	// Manual Lock
	public static String manualLock_Btn = "xpath#//a[@id='adverseEventNew:manualCaseLockId']";
	public static String manualLockValidation_Msg = "xpath#//label[@class='validationDialogSpanSty newDesign_INFO_label']";
	public static String manualLock_OkBtn = "xpath#//label[@class='validationDialogSpanSty newDesign_INFO_label']//following::button[text()='OK']";
	public static String manualUnlock_Btn = "xpath#//a[@id='adverseEventNew:manualCaseUnLockId']";
	//RCT NO
		public static String getRCTNo = "xpath#//label[@id='adverseEventNew:recieptId']";
	/**********************************************************************************************************
	 * Objective:The below method is created to downLoad Reports by passing reports
	 * name at runtime. Input Parameters: ColumnName Output Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String downLoadReports(String runTimeLabel) {
		String value = downLoadReports;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to moreOptions menu navigation passing
	 * link name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String moreOptions(String runTimeLabel) {
		String value = moreOptionsNavigation;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to perform menu navigation by passing
	 * menu name at runtime. Input Parameters: menu Scenario Name Output Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/

	public static String CaseManagmentMenuNavigations(String menu) {
		String value = caseManagementMenu;
		String value2;
		value2 = value.replace("%s", menu);
		return value2;
	}

	public static String CaseManagmentMenuSubMenuNavigations(String menu) {
		String value = caseManagementMenuSubMenu;
		String value2;
		value2 = value.replace("%s", menu);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to perform SubMenu navigation by
	 * passing menu name at runtime. Input Parameters: menu Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String CaseManagmentSubMenuNavigations(String menu) {
		String value = caseManagementSubMenu;
		String value2;
		value2 = value.replace("%s", menu);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:Tab navigation in case management Input Parameters: menu Scenario
	 * Name Output Parameters:
	 * 
	 * @author:DushyanthMahesh Date :20-Feb-2020 Updated by and when
	 **********************************************************************************************************/
	public static String TabNavigtion(String menu) {
		String value = TabNavigtion;
		String value2;
		value2 = value.replace("%s", menu);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:Tab navigation in case management Input Parameters: menu Scenario
	 * Name Output Parameters:
	 * 
	 * @author:DushyanthMahesh Date :20-Feb-2020 Updated by and when
	 **********************************************************************************************************/
	public static String GridViewCheck(String menu) {
		String value = gridView;
		String value2;
		value2 = value.replace("%s%", menu);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:Tab navigation in case management Input Parameters: menu Scenario
	 * Name Output Parameters:
	 * 
	 * @author:WajahatUmar S Date :28-Aug-2020 Updated by and when
	 **********************************************************************************************************/
	public static String FormViewCheck(String menu) {
		String value = FormView;
		String value2;
		value2 = value.replace("%s%", menu);
		return value2;
	}
}
