package com.arisglobal.framework.components.lsmv.L10_3;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_CaseValidationsObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_EventsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_PatientPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_ReporterPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_SourcePageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.ResolveValidationsPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_CaseValidations extends ToolManager {
	static String className = FDE_CaseValidations.class.getSimpleName();
	static boolean status;

	public static ArrayList<String> arr = new ArrayList();
	public static List<WebElement> validationElements;

	/**********************************************************************************************************
	 * @Objective:This method checks whether validation window exists are not
	 * @InputParameters:NA
	 * @OutputParameters:NA
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean validationExists() {
		return agIsVisible(FDE_CaseValidationsObjects.validationlist);
	}

	/**********************************************************************************************************
	 * @Objective:This method checks whether warning window exists are not
	 * @InputParameters:NA
	 * @OutputParameters:NA
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean warningExists() {
		return agIsVisible(FDE_CaseValidationsObjects.warnings);
	}

	/**********************************************************************************************************
	 * @Objective:This method will fetch validation or warning from application
	 * @InputParameters:operation
	 * @OutputParameters:validation or warning list
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static List<WebElement> fetchValidationFromApplication(String operation) {
		List<WebElement> validationORWarningData = null;

		switch (operation) {
		case "Validation":
			if (validationExists()) {
				validationORWarningData = agGetElementList(FDE_CaseValidationsObjects.validationlist);
			} else {
				System.out.println("validations are not Present");
			}
			break;
		case "Warning":
			if (warningExists()) {
				validationORWarningData = agGetElementList(FDE_CaseValidationsObjects.Warninglist);
			} else {
				System.out.println("Warning are not Present");
			}
			break;

		}
		DuplicateCheck(validationORWarningData);
		validationElements = validationORWarningData;
		return validationORWarningData;
	}

	/**********************************************************************************************************
	 * @Objective:This method will drives the validation and warning handlings
	 * @InputParameters:operation, Scenario,client,Expectedrow
	 * @OutputParameters:Expectedrow
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static int VerfyCaseForEorrs(String operation, String Scenario, int Expectedrow,
			List<WebElement> validationData) {
		switch (operation) {
		case "Validation":
			Expectedrow = GenericVerfiying_Validation("Validation", Scenario,  validationData);

			break;
		case "Warning":
			Expectedrow = GenericVerfiying_Validation("Warning", Scenario, 
					/* agGetElementList(FDE_CaseValidationsObjects.Warninglist) */validationData);
			break;

		case "HandlingValidation":
			if (validationExists()) {
				GenericHandling_Validation("Validation", Scenario, FDE_CaseValidationsObjects.validationlist,
						Expectedrow);
			} else {
				System.out.println("validations are not Present");
			}
			break;
		case "HandlingWarning":
			if (warningExists()) {
				GenericHandling_Validation("Warning", Scenario, FDE_CaseValidationsObjects.warnings,
						Expectedrow);
			} else {
				System.out.println("Warning are not Present");
			}
			break;

		}
		return Expectedrow;
	}

	/**********************************************************************************************************
	 * @Objective:This method will fetch validations from the application
	 * @InputParameters: type,Scenario,client, OR
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static int GenericVerfiying_Validation(String type, String Scenario,
			List<WebElement> validationData) {
		int expectedrow = VerfiyValidationFired(Scenario, validationData);
		return expectedrow;
	}

	/**********************************************************************************************************
	 * @Objective:This will handle the validation and warnings
	 * @InputParameters:type,Scenario,client,OR,rownum
	 * @OutputParameters:Screen
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String GenericHandling_Validation(String type, String Scenario,  String OR,
			int rownum) {
		String validationId, validationMessage, ScreenName = null;
		List<WebElement> validationData = agGetElementList(OR);
		System.out.println(validationData.size());
		for (WebElement validation : validationData) {
			if (validationExists() || warningExists()) {
				if (rownum == 0) {
					validationMessage = agGetText(OR + "[1]");
					System.out.println("Validation message" + validationMessage);
					validationId = fetchValidationId(validationMessage, ":", "ValidationID");
					System.out.println(validationId);
					searchValidationWarning(type, Scenario, validationId, validationMessage);
					System.out.println(validationId);

				} else {
					validationMessage = agGetText(OR + "[" + rownum + "]");
					System.out.println("validation message" + validationMessage);
					validationId = fetchValidationId(validationMessage, ":", "ValidationID");
					System.out.println(validationId);
					searchValidationWarning(type, Scenario, validationId, validationMessage);
					System.out.println(validationId);
					break;
				}

				agSetStepExecutionDelay("10000");
			}
		}
		return ScreenName;
	}

	/**********************************************************************************************************
	 * @Objective:This method will verfy if there are duplicate validations fired
	 * @InputParameters:validationData
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void DuplicateCheck(List<WebElement> validationData) {
		boolean checkpoint = true;
		Set dubval = new HashSet<String>();
		for (WebElement val : validationData) {
			if (dubval.add(val) == false) {
				checkpoint = true;
				Reports.ExtentReportLog(val + "  is repeated multiple time", Status.FAIL,
						"Duplicate check :: " + val.getTagName() + " is repeated multiple time UnSuccesfull", true);
				break;
			}
		}

		if (checkpoint) {
			Reports.ExtentReportLog("All Validations which are fired are unquie", Status.PASS,
					"Duplicate check ::" + "All Validations which are fired are unquie", true);
		}
	}

	/*********************************************************************************************************
	 * @Objective:This method will search validation id and validation message in
	 *                 the validation lib sheet(ie excel sheet)
	 * @InputParameters:type,Scenario,client,actualvalidationID,actualValidationMessage
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchValidationWarning(String type, String Scenario, String actualvalidationID,
			String actualValidationMessage) {
		XlsReader xlsv = new XlsReader(lsmvConstants.LSMV_testData);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String DataSheetName, Validation_ID = "", Validation_Message = "", FDE_ScreenName = "";
		for (int row = 1; row < xlsv.getRowCount(className); row++) {
			DataSheetName = "client" + "_" + type + row;

			System.out.println(DataSheetName);
			try {
				Validation_ID = Multimaplibraries.getTestDataCellValue(DataSheetName, "Validation_ID");
				Validation_Message = Multimaplibraries.getTestDataCellValue(DataSheetName, "Validation_Message");

				if (Validation_ID.equalsIgnoreCase(actualvalidationID)
						|| Validation_Message.equalsIgnoreCase(actualValidationMessage)) {
					FDE_ScreenName = Multimaplibraries.getTestDataCellValue(DataSheetName, "FDE_ScreenName");
					System.out.println("ScreenName  " + FDE_ScreenName);
					// SetDataForCaseProcess(Scenario, FDE_ScreenName);
					break;
				}

			} catch (Exception e) {
				System.out.println("Validation is not found in " + className + "Sheet");
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective:This method will verify whether said validation is raised
	 * @InputParameters:scenarioName,validationData
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static int VerfiyValidationFired(String scenarioName, List<WebElement> validationData) {
		int Specificrow = 0;
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		} catch (Exception e) {

		}
		String expectedvalidationMessage = Multimaplibraries.getTestDataCellValue(scenarioName, "Validation_Message");
		String expectedvalidationId = Multimaplibraries.getTestDataCellValue(scenarioName, "Validation_ID");

		arr.add(expectedvalidationId);
		String validationMessage = "";
		int row = 1;
		int validationsize = validationData.size();
		System.out.println(" Total Rows " + validationsize);

		boolean checkpoint = false;
		for (row = 0; row < validationsize; row++) {
			validationMessage = validationData.get(row).getText();
			// validationMessage = agGetText(FDE_CaseValidationsObjects.validatationOr(row +
			// 1));
			// System.out.println(validationMessage);
			String validationId = fetchValidationId(validationMessage, ":", "ValidationID");
			if (expectedvalidationMessage.equalsIgnoreCase(validationMessage)) {
				Specificrow = row + 1;
				checkpoint = true;
				break;
			} else if (expectedvalidationId.equalsIgnoreCase(validationId)) {
				Specificrow = row + 1;
				checkpoint = true;
				break;
			}
		}

		if (checkpoint) {
			Reports.ExtentReportLog("Verifiying ExpectedValidation", Status.PASS, "ExpectedvalidationMessage ::"
					+ expectedvalidationMessage + " && Actual validation :: " + validationMessage + " :: Succesfull",
					true);
		} else {
			Reports.ExtentReportLog("Verifiying Validation Message", Status.FAIL,
					"ExpectedvalidationMessage :: " + expectedvalidationMessage + " But Actual validation :: "
							+ validationMessage + " ::  UnSuccesfull",
					true);
		}
		return Specificrow;
	}
	// ===========================================================================================================================================================================================================================================================

	/**********************************************************************************************************
	 * @Objective:this method will separate the validation id validation message
	 * @InputParameters:validationMessage,rex,operation
	 * @OutputParameters:validation id
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String fetchValidationId(String validationMessage, String rex, String operation) {
		String value = null;
		switch (operation) {
		case "ValidationID":
			value = splitData(validationMessage, rex);
			break;
		case "Associated_field":
			value = splitData(validationMessage, rex);
			break;
		}
		return value;
	}

	/**********************************************************************************************************
	 * @Objective:this method will peform user defined split operation
	 * @InputParameters:validationMessage,rex
	 * @OutputParameters:validation id
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String splitData(String validationMessage, String rex) {
		String value = null;
		if (CharcterOccurence(validationMessage, ':') > 2) {

			if (validationMessage.contains("CUST-")) {
				value = (validationMessage.split(rex))[2].trim();
			} else {
				value = (validationMessage.split(rex))[1].trim();
			}

		} else if (CharcterOccurence(validationMessage, ':') > 1) {
			value = (validationMessage.split(rex))[1].trim();
		} else {

			if (validationMessage.contains(rex)) {
				value = (validationMessage.split(rex))[0].trim();
			} else {
				value = (validationMessage.split(" "))[0] + " " + (validationMessage.split(" "))[1];
			}
		}

		return value;
	}

	/**********************************************************************************************************
	 * @Objective:This method is used for clicking on validation message
	 * @InputParameters:object
	 * @OutputParameters:status
	 * @author:
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean clickOnValidation(String object) {
		boolean status = false;
		agClick(object);
		return status;
	}

	/**********************************************************************************************************
	 * @Objective:This method will search how many times character is repeated
	 * @InputParameters:String and charcter to be searched
	 * @OutputParameters:int
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static int CharcterOccurence(String value, char ch) {
		int count = 0;
		for (int j = 0; j < value.length(); j++) {
			if (ch == value.charAt(j)) {
				count++;
			}
		}
		// System.out.println(ch + "--" + count);
		return count;
	}

	/**********************************************************************************************************
	 * @Objective:This method will drive the validations fired
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static List<WebElement> verifyValidations(String scenarioName, String Sheetname) {
		List<WebElement> validationData = null;
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, Sheetname);
		String Operation = Multimaplibraries.getTestDataCellValue(scenarioName, "ValidationOperation");
		switch (Operation) {
		case "Errors":
			validationData = verfiyListofvalidation(scenarioName);
			break;
		case "Warnings":
			verfiyListofWarning(scenarioName);
			break;
		case "Both":
			validationData = verfiyListofvalidation(scenarioName);
			verfiyListofWarning(scenarioName);
			break;
		}
		return validationData;
	}

	/**********************************************************************************************************
	 * @Objective:This method will fetch the expected Validation names from testdata
	 * @InputParameters:scenarioName
	 * @OutputParameters:object
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Object[] FetchingValidationFromTestData(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "WorkflowControl");
		String Valid = Multimaplibraries.getTestDataCellValue(scenarioName, "VerfiyValidations");
		Object[] validations = Valid.split(",");
		return validations;
	}
	
	
	/**********************************************************************************************************
	 * @Objective:This method will fetch the expected Validation names from testdata
	 * @InputParameters:scenarioName
	 * @OutputParameters:object
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Object[] FetchingSupressionValidationFromTestData(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "WorkflowControl");
		String Valid = Multimaplibraries.getTestDataCellValue(scenarioName, "ClearValidations");
		Object[] validations = Valid.split(",");
		return validations;
	}

	/**********************************************************************************************************
	 * @Objective:This method will verify expected with actual validations
	 * @InputParameters:scenarioName
	 * @OutputParameters:int
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static List<WebElement> verfiyListofvalidation(String scenarioName) {
		List<WebElement> validationData;
		validationData = FDE_CaseValidations.fetchValidationFromApplication("Validation");
		for (Object Name : FetchingValidationFromTestData(scenarioName)) {
			FDE_CaseValidations.VerfyCaseForEorrs("Validation", Name.toString(),0, validationData);
		}
		return validationData;
	}

	/**********************************************************************************************************
	 * @Objective:This method Generates current time
	 * @InputParameters:
	 * @OutputParameters:time
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String SysTime() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		System.out.println(dtf.format(now));
		return dtf.format(now);
	}

	/**********************************************************************************************************
	 * @Objective:This method will fetch the expected warnings names from testdata
	 * @InputParameters:scenarioName
	 * @OutputParameters:object
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Object[] FetchingWarningFromTestData(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "WorkflowControl");
		String Valid = Multimaplibraries.getTestDataCellValue(scenarioName, "VerfiyWarnings");
		System.out.println("validations   " + Valid);
		Object[] validations = Valid.split(",");
		System.out.println("validations   " + validations);
		return validations;
	}

	/**********************************************************************************************************
	 * @Objective:This method will verfity expected with actual warnings
	 * @InputParameters:scenarioName
	 * @OutputParameters:int
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static List<WebElement> verfiyListofWarning(String scenarioName) {
		List<WebElement> WarningData;
		WarningData = FDE_CaseValidations.fetchValidationFromApplication("Warning");
		for (Object Name : FetchingWarningFromTestData(scenarioName)) {
			FDE_CaseValidations.VerfyCaseForEorrs("Warning", Name.toString(), 0, WarningData);
		}
		return WarningData;
	}

	/**********************************************************************************************************
	 * @Objective:This method will verfiy errors and warning raised in the popup
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyvalidationInpop(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "WorkflowControl");
		String Operation = Multimaplibraries.getTestDataCellValue(scenarioName, "ValidationOperation");
		switch (Operation) {
		case "Errors":
			VerifyErrorInactivityProcess(scenarioName);
			break;
		case "Warnings":
			VerifyWarningInactivityProcess(scenarioName);
			break;
		case "Both":
			VerifyWarningInactivityProcess(scenarioName);
			VerifyErrorInactivityProcess(scenarioName);
			break;
		}

	}

	/**********************************************************************************************************
	 * @Objective:This will fetch and varify the warnings which are raised in the
	 *                 pop down while processing in workflow
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyWarningInactivityProcess(String scenarioName) {
		if (agIsVisible(CommonPageObjects.warnings)) {
			List<WebElement> datalist = agGetElementList(CommonPageObjects.warningsCount);
			for (Object validation : FetchingWarningFromTestData(scenarioName)) {
				FDE_CaseValidations.VerfyCaseForEorrs("Warning", validation.toString(), 0, datalist);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective:This will fetch and varify the Errors which are raised in the pop
	 *                 down while processing in workflow
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyErrorInactivityProcess(String scenarioName) {
		if (agIsVisible(CommonPageObjects.Errors)) {
			List<WebElement> datalist = agGetElementList(CommonPageObjects.ErrorCount);
			for (Object validation : FetchingValidationFromTestData(scenarioName)) {
				FDE_CaseValidations.VerfyCaseForEorrs("Validation", validation.toString(), 0, datalist);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective:This method will fetch the Screen names from testdata
	 * @InputParameters:scenarioName
	 * @OutputParameters:object
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Object[] FetchingScreenFromTestData(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "WorkflowControl");
		String Valid = Multimaplibraries.getTestDataCellValue(scenarioName, "WorkSheetName");
		System.out.println("validations   " + Valid);
		Object[] validations = Valid.split(",");
		System.out.println("validations   " + validations);
		return validations;
	}

	/**********************************************************************************************************
	 * @Objective:This method will perform click operation on given validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void validationClick() {
		for (String option : arr) {
			for (WebElement elemts : validationElements) {
				if (elemts.getText().contains(option)) {
					elemts.click();
					arr.remove(option);
					break;
				}
			}
		}

	}

	// ------------------------------------------------------------------------------##############----------

	/**********************************************************************************************************
	 * @Objective:This method will drives the Resolving/supression of validations
	 *                 and reverifies the validations are still present
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void validationsSupressionDriver(String scenarioName) {
		boolean operation =false;
		String[] Scenario = null;
		String value = "";
		String Activity = "";
		if (scenarioName.contains("##")) {
			Scenario = scenarioName.split("##");
			value = Scenario[0];
			Activity = Scenario[1];
		} else {
			value = scenarioName;
			Activity = scenarioName;
		}
		Object[] validations = FDE_CaseValidations.FetchingSupressionValidationFromTestData(value);
		for (Object Name : validations) {
			ValidationSupressionProcessor(Name.toString());
		}
		// FDE_Operations.Save();
		Validations.completeActivityFlow(Activity);

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseValidations");
		if (FDE_CaseValidations.validationExists()) {
			for (Object Name : validations) {
				reverifyValidationPresent(Name.toString());
			}
		}}

	

	/**********************************************************************************************************
	 * @Objective:This method process the validations clearing
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ValidationSupressionProcessor(String scenarioName) {
		System.out.println("Vamsi good morning "+scenarioName);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_CaseValidations");
		
		System.out.println("Vamsi good morning "+getTestDataCellValue(scenarioName, "No_of_Fields"));
		int No_of_Fields = Integer.parseInt(getTestDataCellValue(scenarioName, "No_of_Fields"));

		String Validation_ID = getTestDataCellValue(scenarioName, "Validation_ID");
		String Validation_Message = getTestDataCellValue(scenarioName, "Validation_Message");

		for (int iterator = 1; iterator <= No_of_Fields; iterator++) {
			String[] Data = getTestDataCellValue(scenarioName, "ScreenName" + iterator).split(",");
			String ScreenName = Data[0];
			String Operation = Data[1];

			String FieldName = getTestDataCellValue(scenarioName, "FieldLabel" + iterator);
			String FieldValue = getTestDataCellValue(scenarioName, "FieldValue" + iterator);

			switch (ScreenName) {
			case "FDE_General":
				ClickType(Operation, Validation_ID);
				FDE_GeneralValidations(FieldName, FieldValue);

				break;

			case "FDE_Source":
				ClickType(Operation, Validation_ID);
				FDE_SourceValidations(FieldName, FieldValue);
				break;

			case "FDE_Study":
				ClickType(Operation, Validation_ID);
				FDE_StudyValidations(FieldName, FieldValue);
				break;

			case "FDE_Reporter":
				ClickType(Operation, Validation_ID);
				FDE_ReporterValidations(FieldName, FieldValue);
				break;

			case "FDE_Patient":
				ClickType(Operation, Validation_ID);
				FDE_PatientValidations(FieldName, FieldValue);
				break;

			case "FDE_Parent":
				ClickType(Operation, Validation_ID);
				FDE_ParentValidations(FieldName, FieldValue);
				break;

			case "FDE_Products":
				ClickType(Operation, Validation_ID);
				FDE_ProductsValidations(FieldName, FieldValue);
				break;
			case "FDE_Events":
				ClickType(Operation, Validation_ID);
				FDE_EventsValidations(FieldName, FieldValue);
				break;

			case "FDE_Narrative":
				ClickType(Operation, Validation_ID);
				FDE_NarrativeValidations(FieldName, FieldValue);
				break;

			case "FDE_Labelling":
				ClickType(Operation, Validation_ID);
				FDE_LabellingValidations(FieldName, FieldValue);
				break;

			case "FDE_Pregnancy":
				ClickType(Operation, Validation_ID);
				FDE_PregnancyValidations(FieldName, FieldValue);
				break;

			case "FDE_Causality":
				ClickType(Operation, Validation_ID);
				FDE_CausalityValidations(FieldName, FieldValue);
				break;

			case "FDE_Literature":
				ClickType(Operation, Validation_ID);
				FDE_LiteratureValidations(FieldName, FieldValue);
				break;

			case "FDE_LabData":
				ClickType(Operation, Validation_ID);
				FDE_LabDataValidations(FieldName, FieldValue);
				break;
			}

		}
	}

	/**********************************************************************************************************
	 * @Objective:This method will clear General Screen validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void FDE_GeneralValidations(String FieldName, String value) {
		String ScreenName = "General";
		VerifyFieldAssociatedTab(ScreenName);
		switch (FieldName) {
		case "Gen_CaseSpecificInformation_CaseSignificance":
			// CommonOperations.clickManualCheckBox(FDE_GeneralPageObjects.Case_Significance,
			// "Check");
			CommonOperations.setFDEDropDownValue(
					FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.caseSignificance), value);
			break;
		}

	}

	/**********************************************************************************************************
	 * @Objective:This method will clear Source Screen validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	private static void FDE_SourceValidations(String FieldName, String value) {
		String ScreenName = "Source";
		VerifyFieldAssociatedTab(ScreenName);
		switch (FieldName) {
		case "Source_Source":
			CommonOperations.setFDEDropDownValue(FDE_SourcePageObjects.sourceDropdown, value);
			break;
		}

	}

	/**********************************************************************************************************
	 * @Objective:This method will clear Patient Screen validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	private static void FDE_PatientValidations(String FieldName, String value) {

		String ScreenName = "Patient";
		VerifyFieldAssociatedTab(ScreenName);
		switch (FieldName) {
		case "Patient_PatientIdentifiers_PatientID":
			agSetValue(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.patientID_Textbox), value);
			break;
		case "Patient_DeathDetails_AutopsyDone":
			// CommonOperations.clickManualCheckBox(FDE_PatientPageObjects.Autopsy_Done,
			// "Check");
			agClick(FDE_PatientPageObjects.select_RadioButtons(FDE_PatientPageObjects.autopsyDone_Radio, value));
			break;
		}

	}

	/**********************************************************************************************************
	 * @Objective:This method will clear Events Screen validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	private static void FDE_EventsValidations(String FieldName, String value) {

		String ScreenName = "Event(s)";
		VerifyFieldAssociatedTab(ScreenName);
		switch (FieldName) {
		case "Events_EventInformation_ReportedTerm":
			agSetValue(FDE_EventsPageObjects.reportedTerm_Textfield, value);
			agSendKeyStroke(Keys.TAB);
			/*
			 * if (agIsVisible(FDE_EventsPageObjects.confirmationpop) == true) {
			 * agClick(FDE_EventsPageObjects.popUp_YesBtn); }
			 */

			break;
		case "Events_EventInformation_Outcome":
			CommonOperations.setFDEDropDownValue(
					FDE_EventsPageObjects.click_DropDown(FDE_EventsPageObjects.outCome_DropDown), value);
			break;
		}

	}

	/**********************************************************************************************************
	 * @Objective:This method will clear Lab Screen validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	private static void FDE_LabDataValidations(String FieldName, String value) {

		String ScreenName = "Lab Data";
		VerifyFieldAssociatedTab(ScreenName);
		switch (FieldName) {
		case "Gen_CaseSpecificInformation_Nullification":
			break;
		}

	}

	/**********************************************************************************************************
	 * @Objective:This method will clear Literature Screen validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	private static void FDE_LiteratureValidations(String FieldName, String value) {

		String ScreenName = "Literature";
		VerifyFieldAssociatedTab(ScreenName);
		switch (FieldName) {
		case "Gen_CaseSpecificInformation_Nullification":
			break;
		}

	}

	/**********************************************************************************************************
	 * @Objective:This method will clear Causality Screen validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	private static void FDE_CausalityValidations(String FieldName, String value) {
		String ScreenName = "Causality";
		VerifyFieldAssociatedTab(ScreenName);
		switch (FieldName) {
		case "Gen_CaseSpecificInformation_Nullification":
			break;
		}

	}

	/**********************************************************************************************************
	 * @Objective:This method will clear Pregnancy Screen validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	private static void FDE_PregnancyValidations(String FieldName, String value) {
		String ScreenName = "Pregnancy";

		VerifyFieldAssociatedTab(ScreenName);
		switch (FieldName) {
		case "Gen_CaseSpecificInformation_Nullification":
			break;
		}

	}

	/**********************************************************************************************************
	 * @Objective:This method will clear LabellingV Screen validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	private static void FDE_LabellingValidations(String FieldName, String value) {

		String ScreenName = "Labelling";
		VerifyFieldAssociatedTab(ScreenName);
		switch (FieldName) {
		case "Gen_CaseSpecificInformation_Nullification":
			break;
		}

	}

	/**********************************************************************************************************
	 * @Objective:This method will clear Narrative Screen validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	private static void FDE_NarrativeValidations(String FieldName, String value) {

		String ScreenName = "Narrative";
		VerifyFieldAssociatedTab(ScreenName);
		switch (FieldName) {
		case "Gen_CaseSpecificInformation_Nullification":
			break;
		}

	}

	/**********************************************************************************************************
	 * @Objective:This method will clear Products Screen validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	private static void FDE_ProductsValidations(String FieldName, String value) {

		String ScreenName = "Product(s)";
		VerifyFieldAssociatedTab(ScreenName);
		switch (FieldName) {
		case "Gen_CaseSpecificInformation_Nullification":
			break;
		}

	}

	/**********************************************************************************************************
	 * @Objective:This method will clear Parent Screen validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	private static void FDE_ParentValidations(String FieldName, String value) {

		String ScreenName = "Parent";
		VerifyFieldAssociatedTab(ScreenName);
		switch (FieldName) {
		case "Gen_CaseSpecificInformation_Nullification":
			break;
		}

	}

	/**********************************************************************************************************
	 * @Objective:This method will clear Reporter Screen validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	private static void FDE_ReporterValidations(String FieldName, String value) {
		String ScreenName = "Reporter";
		VerifyFieldAssociatedTab(ScreenName);
		switch (FieldName) {
		case "Reporter_PrimaryReporter":
			agClick(FDE_ReporterPageObjects.click_Checkboxs(FDE_ReporterPageObjects.primaryReporter_Checkbox));
			break;

		case "Reporter_PrimarySourceForRegulatoryPurposes":
			agClick(FDE_ReporterPageObjects
					.select_RadioButtons(FDE_ReporterPageObjects.primarySourceRegulatory_Radiobtn, value));
			break;
		}

	}

	/**********************************************************************************************************
	 * @Objective:This method will clear Study Screen validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	private static void FDE_StudyValidations(String FieldName, String value) {
		String ScreenName = "Study";
		VerifyFieldAssociatedTab(ScreenName);
		switch (FieldName) {
		case "Gen_CaseSpecificInformation_Nullification":
			break;
		}

	}

	/**********************************************************************************************************
	 * @Objective:This method will perform click operation on given validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ClickType(String Operation, String validationId) {
		if (!Operation.equalsIgnoreCase("#skip#")) {
			if (Operation.equalsIgnoreCase("Link")) {
				validationClick(validationId);
			} else {
				FDE_Operations.tabNavigation(Operation);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective:This method will perform click operation on given validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void validationClick(String value) {
		List<WebElement> validationElements = FDE_CaseValidations.fetchValidationFromApplication("Validation");
		for (WebElement elemts : validationElements) {
			String val = elemts.getText();
			if (val.contains(value)) {
				agJavaScriptExecuctorClick(FDE_CaseValidationsObjects.validationSpecfic(value));
				break;
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective:This method will reverfies whether validation still present
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void reverifyValidationPresent(String scenarioName) {
		List<WebElement> validationData = FDE_CaseValidations.fetchValidationFromApplication("Validation");
		String expectedvalidationMessage = Multimaplibraries.getTestDataCellValue(scenarioName, "Validation_Message");
		String expectedvalidationId = Multimaplibraries.getTestDataCellValue(scenarioName, "Validation_ID");
		String validationMessage = "";
		int row = 1;
		int validationsize = validationData.size();
		System.out.println(" Total Rows " + validationsize);

		boolean checkpoint = false;
		for (row = 0; row < validationsize; row++) {
			validationMessage = validationData.get(row).getText();
			String validationId = FDE_CaseValidations.fetchValidationId(validationMessage, ":", "ValidationID");
			if (expectedvalidationMessage.equalsIgnoreCase(validationMessage)) {
				checkpoint = true;
				break;
			} else if (expectedvalidationId.equalsIgnoreCase(validationId)) {
				checkpoint = true;
				break;
			}
		}

		if (checkpoint) {
			Reports.ExtentReportLog("Verifiying Validation Message", Status.FAIL,
					"Post setting data validation still exits ::  UnSuccesfull", true);
		}

	}

	public static void VerifyFieldAssociatedTab(String ScreenName) {
		agClick(ResolveValidationsPageObjects.openValidationDialog);
		String activeTab = agGetText(ResolveValidationsPageObjects.activeTab);
		if (activeTab.equalsIgnoreCase(ScreenName)) {
			Reports.ExtentReportLog("Verifiying Tab", Status.PASS,
					"ExpectedTab ::" + ScreenName + " && Actual Tab :: " + activeTab + " :: Succesfull", true);
		} else {
			Reports.ExtentReportLog("Verifiying Tab", Status.FAIL,
					"ExpectedTab :: " + ScreenName + " But Actual Tab :: " + activeTab + " ::  UnSuccesfull", true);
		}
		if (agIsVisible(ResolveValidationsPageObjects.closeValidationDialog)) {
			agClick(ResolveValidationsPageObjects.closeValidationDialog);
		}
	}

	public static Boolean ClickOnValidations(String string, String string2) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void validation(String string, String scenarioName) {
		// TODO Auto-generated method stub
		
	}

}
