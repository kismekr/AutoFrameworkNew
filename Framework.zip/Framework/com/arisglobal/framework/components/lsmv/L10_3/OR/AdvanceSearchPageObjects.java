package com.arisglobal.framework.components.lsmv.L10_3.OR;

public abstract class AdvanceSearchPageObjects {
	public static String receiptNumber_Txtfield = "xpath#//input[@name='receiptNumber']";
	public static String search_Btn = "xpath#//button[@id='advSearchButton'][not(contains(@class,'btn btn-secondary'))]";
	public static String searchLinks = "xpath#//div[@class='advPanelContainer']//div/ul/li/a[text()='%s']";
	public static String displayCases_Label = "xpath#//label[text()='Display Cases']";
	public static String displayCases_radioBtn = "xpath#//div[@id='INBOUND_SEARCH_DISPLAY_CASES']/child::label[text()='%s']";
	public static String selectDropdown = "xpath#//ul[contains(@class,'select2-results__options')]/child::li[text()='%s']";
	public static String clickDropDown = "xpath#//div[@class='advPanelContainer']/child::div//label[text()='%s']/parent::div/span";
	public static String saveAndSearch_Btn = "xpath#//button[text()='Save and Search']";

	public static String saveAndSearch_WinTitle = "xpath#//div/span[text()='Save and Search']";
	public static String searchCriteriaName = "xpath#//div/input[@id='criterianame']";
	public static String saveCriteria_Btn = "xpath#//div/button[contains(text(),'	Save')]";

	public static String saveCriteria_ConfirmTitle = "xpath#//div/span[contains(text(),'Action Completed Successfully')]";
	public static String saveCriteria_OK = "xpath#//div/a[contains(text(),'OK')]";

	// -----
	public static String initialReceivedDateFrom = "xpath#//input[@name='initialFromDate']";
	public static String initialReceivedDateTo = "xpath#//input[@name='intialToDate']";
	public static String reset = "xpath#//div[@class='adv-rigth-btns']/span/button[text()='Reset']";
	public static String protocolNumLookupImg = "xpath#//div[@id='INBOUND_SEARCH_PROTOCOL_NO']/a/img";
	public static String studyLookupStudyNoInput = "xpath#//label[text()='Study No ']/following::input[@name='study']";
	public static String studyLookupSearchButton = "xpath#//button/span[text()='Search']";
	public static String selectSearchedFirstItem = "xpath#(//tbody/tr/td[@class='tblEditRow']/p-tableradiobutton)[1]";
	public static String studyLookupOKButton = "xpath#//button[@type='button']/span[text()='OK']";
	public static String aerNoInput = "xpath#//input[@name='aerNo']";
	public static String eventReporterTermInput = "xpath#//div[@id='INBOUND_SEARCH_REPORTED_TERM']/input";
	public static String companyUnitTxtbox = "xapth#//div[@id='INBOUND_SEARCH_COMPANY_UNIT']//span[@role='combobox']";
	public static String dropdownSelect = "xpath#//ul[@role='listbox'][@aria-expanded='true']/li[contains(text(),'{%s}')]";
	public static String patientDOBFrom = "xpath#//input[@name='patientDOBFrom']";
	public static String patientDOBTo = "xpath#//input[@name='patientDOBTO']";
	public static String patientGenderTxtbox = "xpath#//div[@id='INBOUND_SEARCH_PATSEX']//span[@role='combobox']";
	public static String reporterTypeTxtbox = "xpath#//div[@id='INBOUND_SEARCH_REPORTTYPE']//span[@role='combobox']";
	public static String classificationType = "xpath#//div[@id='INBOUND_SEARCH_CLASSIFICATION_TYPE_CODE']//span[@role='combobox']";
	public static String reportReceivingMedium = "xpath#//div[@id='INBOUND_SEARCH_MEDIUM_CODE']//span[@role='combobox']";
	public static String primarySourceCountryTxtbox = "xpath#//div[@id='INBOUND_SEARCH_OCCURCOUNTRY']//span[@role='combobox']";

	public static String messageNumber_Textfield = "xpath#//input[@name='messageNumber']";
	public static String productLookup = "xpath#//label[contains(text(),'Product')]/ancestor::div/a/img";
	public static String level1ProductTextbox = "xpath#//label[(text()='{0}')]/ancestor::div/input[@type='text']";
	public static String searchButton = "xpath#//span[contains(text(),'Search')]/ancestor::button";
	public static String checkFirstProdInProdLib = "xpath#//div[@aria-hidden='false']/div/p-table[@class='agcommonTblStyle proLibTblDialog ng-star-inserted']//table/tbody/tr[1]/td/p-tablecheckbox";
	public static String prodLibOkButton = "xpath#//div[contains(@class,'agSearchprodcutTable')]//div/button/span[text()='Ok']";
	public static String searchLoader = "xpath#//img[@id = 'headerForm:j_id_y']";
	public static String addedProductVerify = "xpath#//span[@id='prodSpan0']";
	public static String eventsHeader = "xpath#//span[@class='adv_title_Event']";
	public static String productHeader = "xpath#//span[@class='adv_title_product']";
	public static String seriousDropdown = "Serious";
	public static String seriousnessCriteriaDropdown = "Seriousness Criteria";
	public static String prodLibproductNameTextbox = "Product Name";
	public static String dropdownClick = "xpath#//label[text()='%s']/parent::span/parent::div/span/span";
	public static String savedCriteriaDropdown = "Saved Criteria";
	public static String reportTerm_Txtfield = "xpath#//input[@name='event']";

	public static String productSearchButton = "xpath#//span[@class='lsmv-button' and text()='Search']";
	public static String frstProdInLib = "xpath#//div[@id='targetPanelForPrdLookupGrid']//following::span[@class='lsmv-grid-chk-sticky lsmv-grid-row-sel-chk lsmv-grid-sel-unchk']";
	public static String productOkButton = "xpath#(//span[@id='selecctBtnId'])[1]";
	public static String txtProdName = "xpath#//input[@fieldid='PRODUCT_NAME']";
	// -----

	// Search Links
	public static String caseDetails_link = "Case Details";
	public static String administrativeFields_link = "Administrative Fields";
	public static String productFields_link = "Product";
	public static String eventsFields_link = "Event(s)";
	public static String caseUnitAndDates_link = "Case Unit and Dates";
	public static String caseReportAndSeriousness_link = "Case Report and Seriousness";
	public static String studyInformation_Link = "Study Information";

	// Display cases Radio button label
	public static String outofworkflow_RadioBtn = "Out of workflow";
	public static String Both_RadioBtn = "Both";

	// Product
	public static String product_TextField = "xpath#//input[@id='productAutocomplete']";

	// Dropdown Label names
	public static String dropDownListItem = "xpath#//li[text()='{0}'][contains(@id,'{1}')]";
	public static String companyUnit_Dropdown = "xpath#//select[@name='companyUnit']";
	public static String reportType_Dropdown = "xpath#//select[@name='reportType']";
	public static String reportClassification_Dropdown = "xpath#//select[@name='reportClassificationType']";
	public static String reportCategory_Dropdown = "xpath#//select[@name='reportClassification']";
	public static String reportPriority_Dropdown = "xpath#//select[@name='apriority']";
	public static String reportRecvMedium_Dropdown = "xpath#//select[@name='medium']";

	// Study information
	public static String protocolNo_TextBox = "xpath#//input[@id='protocolNumber']";
	public static String studyName_TextBox = "xpath#//input[@name='studyName']";
	public static String eudraCTNumber_TextBox = "xpath#//input[@name='eudractNum']";
	public static String studyPhase_Dropdown = "xpath#//select[@name='studyPhase']";
	public static String studyDesign_Dropdown = "xpath#//select[@name='studyDesign']";
	public static String studyType_Dropdown = "xpath#//select[@name='studyType']";
	public static String caseCodeBroken_Dropdown = "xpath#//select[@name='caseCodeBroken']";
	public static String registratioNum_TextBox = "xpath#//input[@name='studyRegNum']";

	public static String outofworkflowStatus_Dropdown = "Out of workflow Status";

	// Added to adjust change in locators
	public static String searchDD_TextArea = "xpath#//span/input[@class='select2-search__field']";
	public static String searchDropDown_value = "xpath#//ul/li[text()='%s']";

	// Added Prod Locators
	public static String firstRecord_ChkBx = "xpath#//div[@id='targetPanelForPrdLookupGrid']//div[@class='lsmv-grid-row']/span";
	public static String productChar_Dropdown = "xpath#//select[@name='selectedDrugCharacterization']";
	public static String eventSeriousness_Dropdown = "xpath#//div/select[@name='serious']";
	public static String seeMore_Hyperlink = "xpath#//div[@class='criteriaSeeMore']/a";

	/**********************************************************************************************************
	 * @Objective:The below method is created to click search links by passing link
	 *                name at runtime.
	 * @Input Parameters: ColumnName
	 * @Scenario Name Output
	 * @Parameters:
	 * @author:Avinash K Date :06-Feb-2019 Updated by and when
	 **********************************************************************************************************/
	public static String searchLinks(String runTimeLabel) {
		String value = searchLinks;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to click radio button in display cases
	 *                case detailssection by passing link name at runtime.
	 * @Input Parameters: ColumnName
	 * @Scenario Name Output
	 * @Parameters:
	 * @author:Avinash K Date :06-Feb-2019 Updated by and when
	 **********************************************************************************************************/
	public static String displayCases_radioBtn(String runTimeLabel) {
		String value = displayCases_radioBtn;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created click DropDown by passing label name at
	 * runtime. Input Parameters: ColumnName Scenario Name Output Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/

	public static String clickDropDown(String runTimeLabel) {
		String value = clickDropDown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select Dropdown by passing label
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/
	public static String selectDropdown(String runTimeLabel) {
		String value = selectDropdown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective: To select company unit drop down Input Parameters: company unit
	 * name Parameters:
	 * 
	 * @author:DushyanthMahesh Date :04-Mar-2020 Updated by and when
	 **********************************************************************************************************/
	public static String dropdownSelect(String runTimeLabel) {
		String value = dropdownSelect;
		String value2;
		value2 = value.replace("{%s}", runTimeLabel);
		return value2;
	}

	public static String level1ProductTextbox(String label) {
		String value = level1ProductTextbox.replace("{0}", label);
		return value;

	}

	public static String clickOnDropDown(String runTimeLabel) {
		String value = dropdownClick;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to generate xpath based on locator
	 *             and value to select from dropdown.
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Pooja S
	 * @Date : 29-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectListDropDown(String locator, String valueToSelect) {
		String xpath[] = locator.split("'");
		String resLocator = xpath[1].replace("_container", "");
		String actualLocator = dropDownListItem;
		String tempLocator = actualLocator.replace("{0}", valueToSelect);
		String resultLocator = tempLocator.replace("{1}", resLocator);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to locate a Search criteria dorp down
	 *             record.
	 * @InputParameters: Drop down record value
	 * @OutputParameters: Returns dynamic Xpath
	 * @author: Shamanth S
	 * @Date : 13-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String searchCriteriaDDRecord(String recValue) {
		String value = searchDropDown_value;
		String value2;
		value2 = value.replace("%s", recValue);
		return value2;
	}

	public static String productCharacterizationDD = "xpath#//div[@id='INBOUND_SEARCH_PRODUCT_CHARACTERIZATION']/span/span/span";
	public static String productCharacterizationDDRecord = "xpath#//ul[contains(@id,'selectedDrugCharacterization')]/li[text()='%s']";
	/**********************************************************************************************************
	 * @Objective: The below method is created to locate a Product Characterization DD value.
	 * @InputParameters: Drop down record value
	 * @OutputParameters: Returns dynamic Xpath
	 * @author: Shamanth S
	 * @Date : 13-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String productCharacterizationDDRecord(String recValue) {
		String value = productCharacterizationDDRecord;
		String value2;
		value2 = value.replace("%s", recValue);
		return value2;
	}

}
