package com.arisglobal.framework.components.lsmv.L10_3;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.ContactsPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class ContactsOperations extends ToolManager {
	public static WebElement webElement;
	static String className = ContactsOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in Contact
	 *             Module.
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void menuNavigation(String menu) {
		switch (menu) {
		case "contactsNew":
			agMouseHover(ContactsPageObjects.contactsHover);
			agClick(ContactsPageObjects.contactsNew);
			break;

		case "contactsListing":
			agMouseHover(ContactsPageObjects.contactsHover);
			agClick(ContactsPageObjects.contactsListing);
			agSetStepExecutionDelay("9000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			break;

		case "unresolvedCorrespondence":
			agMouseHover(ContactsPageObjects.contactsHover);
			agClick(ContactsPageObjects.unresolvedCorrespondence);
			break;
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in Contact
	 *             Module and verify the label name.
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void contactsNavigations(String menu) {
		switch (menu) {
		case "contactsNew":
			menuNavigation("contactsNew");
			status = agIsVisible(ContactsPageObjects.contactsFirstName);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to contacts New is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to contacts New is Unsuccessfull", true);
			}
			break;
		case "contactsListing":
			menuNavigation("contactsListing");
			agWaitTillVisibilityOfElement(ContactsPageObjects.contactsListingKeywordsearch);
			status = agIsVisible(ContactsPageObjects.contactsListingKeywordsearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to contacts Listing is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to contacts Listing is Unsuccessfull", true);
			}
			break;
		case "unresolvedCorrespondence":
			menuNavigation("unresolvedCorrespondence");
			status = agIsVisible(ContactsPageObjects.ContactunresolvedCorresKeywordsearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to unresolved Correspondence is successfull",
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to unresolved Correspondence is Unsuccessfull",
						true);
			}
			break;
		default:
			System.out.println("Invalid Menu Link!");
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is search Contacts in ContactsListing Screen.
	 * @InputParameters: scenarioName,field
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 08-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void contactSearch(String scenarioName, String field) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		switch (field) {
		case "contactId":
			agSetValue(ContactsPageObjects.contactsListingKeywordsearch,
					getTestDataCellValue(scenarioName, "ContactId"));
			agClick(ContactsPageObjects.contactsListingKeywordsearchIcon);
			agSetStepExecutionDelay("3000");
			String id = agGetText(ContactsPageObjects.searchedContactRecordId);

			if (id.equalsIgnoreCase(getTestDataCellValue(scenarioName, "ContactId"))) {
				Reports.ExtentReportLog("", Status.PASS, "Search based on Contact Id successful", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Search based on Contact Id Unsuccessful", true);
			}
			break;

		case "firstName":
			agSetValue(ContactsPageObjects.contactsListingKeywordsearch,
					getTestDataCellValue(scenarioName, "FirstName"));
			agClick(ContactsPageObjects.contactsListingKeywordsearchIcon);
			agSetStepExecutionDelay("3000");
			String fName = agGetText(ContactsPageObjects.searchedContactRecordfName);

			if (fName.equalsIgnoreCase(getTestDataCellValue(scenarioName, "FirstName"))) {
				Reports.ExtentReportLog("", Status.PASS, "Search based on FirstName successful", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Search based on FirstName Unsuccessful", true);
			}
			break;

		case "middleName":
			agSetValue(ContactsPageObjects.contactsListingKeywordsearch,
					getTestDataCellValue(scenarioName, "MiddleName"));
			agClick(ContactsPageObjects.contactsListingKeywordsearchIcon);
			agSetStepExecutionDelay("3000");
			String mName = agGetText(ContactsPageObjects.searchedContactRecordmName);

			if (mName.equalsIgnoreCase(getTestDataCellValue(scenarioName, "MiddleName"))) {
				Reports.ExtentReportLog("", Status.PASS, "Search based on MiddleName successful", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Search based on MiddleName Unsuccessful", true);
			}
			break;

		case "lastName":
			agSetValue(ContactsPageObjects.contactsListingKeywordsearch,
					getTestDataCellValue(scenarioName, "LastName"));
			agClick(ContactsPageObjects.contactsListingKeywordsearchIcon);
			agSetStepExecutionDelay("3000");
			String lName = agGetText(ContactsPageObjects.searchedContactRecordlName);

			if (lName.equalsIgnoreCase(getTestDataCellValue(scenarioName, "LastName"))) {
				Reports.ExtentReportLog("", Status.PASS, "Search based on LastName successful", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Search based on LastName Unsuccessful", true);
			}
			break;

		case "emailId":
			agSetValue(ContactsPageObjects.contactsListingKeywordsearch, getTestDataCellValue(scenarioName, "EmailId"));
			agClick(ContactsPageObjects.contactsListingKeywordsearchIcon);
			agSetStepExecutionDelay("3000");
			String mailId = agGetText(ContactsPageObjects.searchedContactRecordemailId);

			if (mailId.equalsIgnoreCase(getTestDataCellValue(scenarioName, "EmailId"))) {
				Reports.ExtentReportLog("", Status.PASS, "Search based on EmailId successful", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Search based on EmailId Unsuccessful", true);
			}
			break;
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to create a new Contact.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 15-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void enterContactGeneralDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		CommonOperations.setListDropDownValue(ContactsPageObjects.titleDropdownLabel,
				getTestDataCellValue(scenarioName, "Title"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(ContactsPageObjects.contactsFirstName, getTestDataCellValue(scenarioName, "FirstName"));
		agSetValue(ContactsPageObjects.contactsLastName, getTestDataCellValue(scenarioName, "LastName"));
		agSetValue(ContactsPageObjects.contactsMiddleName, getTestDataCellValue(scenarioName, "MiddleName"));
		agSetStepExecutionDelay("3000");
		CommonOperations.setListDropDownValue(ContactsPageObjects.suffixLabel,
				getTestDataCellValue(scenarioName, "Suffix"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (!getTestDataCellValue(scenarioName, "DoNotContact").equalsIgnoreCase("Yes")) {
			agSetStepExecutionDelay("3000");
			CommonOperations.setListDropDownValue(ContactsPageObjects.preferredContactMedium,
					getTestDataCellValue(scenarioName, "PreferredContactMedium"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} else {
			CommonOperations.clickCheckBoxLeftOf("Do Not Contact", getTestDataCellValue(scenarioName, "DoNotContact"));
		}
		agSetStepExecutionDelay("3000");
		CommonOperations.setListDropDownValue(ContactsPageObjects.companyUnitLabel,
				getTestDataCellValue(scenarioName, "CompanyUnit"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (getTestDataCellValue(scenarioName, "boolSenderLookup").equalsIgnoreCase("true")) {
			agClick(ContactsPageObjects.senderLookupIcon);
			agSetStepExecutionDelay("8000");
			if (agIsVisible(ContactsPageObjects.searchByAccountLabel)) {
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				if (getTestDataCellValue(scenarioName, "boolSearchByAccount").equalsIgnoreCase("true")) {
					agSetStepExecutionDelay("5000");
					agSetValue(ContactsPageObjects.accountNameTextbox,
							getTestDataCellValue(scenarioName, "Sender_AccountName"));
					agClick(ContactsPageObjects.searchSenderButton);
					agClick(ContactsPageObjects.selectRadioRecord);
					agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
					CommonOperations.takeScreenShot();
					agClick(ContactsPageObjects.okSenderbyAccountButton);
				} else {
					agSetValue(ContactsPageObjects.unitCodeTextbox, getTestDataCellValue(scenarioName, "UnitCode"));
					agSetValue(ContactsPageObjects.unitNameTextbox, getTestDataCellValue(scenarioName, "UnitName"));
					CommonOperations.setListDropDownValue(ContactsPageObjects.typeLabel,
							getTestDataCellValue(scenarioName, "Type"));
					CommonOperations.setListDropDownValue(ContactsPageObjects.countryLabel,
							getTestDataCellValue(scenarioName, "Country"));
					agClick(ContactsPageObjects.searchBycompanyUnitButton);
					agClick(ContactsPageObjects.selectRadioRecord);
					agSetStepExecutionDelay("3000");
					CommonOperations.takeScreenShot();
					agClick(ContactsPageObjects.okSenderbyCUnitButton);
					agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				}
			}
		} else {
			agSetValue(ContactsPageObjects.senderTextbox, getTestDataCellValue(scenarioName, "Sender"));
			if (!getTestDataCellValue(scenarioName, "Sender").equalsIgnoreCase("#skip#")) {
				agClick(ContactsPageObjects.senderSuggestionListItem);
			}
		}
		agSetStepExecutionDelay("3000");
		agSetValue(ContactsPageObjects.phCountryCodeTextbox, getTestDataCellValue(scenarioName, "PhCountryCode"));
		agSetValue(ContactsPageObjects.phAreaCode, getTestDataCellValue(scenarioName, "PhAreaCode"));// TBA

		agSetValue(ContactsPageObjects.phNumberTextbox, getTestDataCellValue(scenarioName, "PhoneNumber"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(ContactsPageObjects.extensionNumber, getTestDataCellValue(scenarioName, "ExtensionNumber"));// TBA
		agSetValue(ContactsPageObjects.faxCountryCodeTextbox, getTestDataCellValue(scenarioName, "FaxCountryCode"));
		agSetValue(ContactsPageObjects.faxAreaCode, getTestDataCellValue(scenarioName, "FaxAreaCode"));// TBA
		agSetValue(ContactsPageObjects.faxNumberTextbox, getTestDataCellValue(scenarioName, "FaxNumber"));
		agSetValue(ContactsPageObjects.faxExtNumberTextbox, getTestDataCellValue(scenarioName, "FAXExtensionNumber"));
		agSetValue(ContactsPageObjects.emailAddressTextarea, getTestDataCellValue(scenarioName, "EmailAddress"));
		agSetValue(ContactsPageObjects.otherPhoneNumberTextbox, getTestDataCellValue(scenarioName, "OtherPhoneNumber"));
		agSetValue(ContactsPageObjects.degreeTextbox, getTestDataCellValue(scenarioName, "Degree"));
		agSetStepExecutionDelay("3000");
		agClick(ContactsPageObjects.clickGenderDrpdown);
		agClick(ContactsPageObjects.setGender(getTestDataCellValue(scenarioName, "Gender")));
		// CommonOperations.setListDropDownValue(ContactsPageObjects.genderLabel,
		// getTestDataCellValue(scenarioName, "Gender"));
		CommonOperations.setListDropDownValue(ContactsPageObjects.contactCategoryLabel,
				getTestDataCellValue(scenarioName, "ContactCategory"));
		CommonOperations.setListDropDownValue(ContactsPageObjects.contactSubCategoryLabel,
				getTestDataCellValue(scenarioName, "ContactSubCategory"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Contact >> Contact Details Section 1", true);
		agJavaScriptExecuctorScrollToElement(ContactsPageObjects.Specialization_Label);
		CommonOperations.setListDropDownValue(ContactsPageObjects.SpecializationLabel,
				getTestDataCellValue(scenarioName, "Specialization"));
		agSetValue(ContactsPageObjects.otherSpecializationTextbox,
				getTestDataCellValue(scenarioName, "OtherSpecialization"));// TBA
		agSetStepExecutionDelay("3000");
		agSetValue(ContactsPageObjects.primaryAccountTextbox, getTestDataCellValue(scenarioName, "PrimaryAccount"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		// agClick(ContactsPageObjects.departmentLabel);
		// agClick(ContactsPageObjects.setDepartmentValue(getTestDataCellValue(scenarioName,
		// "Department")));
		CommonOperations.setListDropDownValue(ContactsPageObjects.departmentLabel,
				getTestDataCellValue(scenarioName, "Department"));
		if (getTestDataCellValue(scenarioName, "ConsentToCaptureDetails").equalsIgnoreCase("Yes")) {
			CommonOperations.clickCheckBoxLeftOf("Consent to Capture Details", "true");
		}
		if (getTestDataCellValue(scenarioName, "ConsentToShare").equalsIgnoreCase("Yes")) {
			CommonOperations.clickCheckBoxLeftOf("Consent to Share", "true");
		}

		
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Contact >> Contact Details Section 2", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to create verify a Contact general deetails.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 02-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyContactGeneralDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Title"), ContactsPageObjects.titleDropdownLabel);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FirstName"),
				ContactsPageObjects.contactsFirstName);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "LastName"),
				ContactsPageObjects.contactsLastName);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MiddleName"),
				ContactsPageObjects.contactsMiddleName);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Suffix"), ContactsPageObjects.suffixLabel);
		if (!getTestDataCellValue(scenarioName, "DoNotContact").equalsIgnoreCase("Yes")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "PreferredContactMedium"),
					ContactsPageObjects.preferredContactMedium);
		} else {
			CommonOperations.verifyCheckBoxLeftOf("Do Not Contact", getTestDataCellValue(scenarioName, "DoNotContact"));
		}
		agCheckPropertyText(getTestDataCellValue(scenarioName, "CompanyUnit"), ContactsPageObjects.companyUnitLabel);
		if (getTestDataCellValue(scenarioName, "boolSenderLookup").equalsIgnoreCase("true")) {
			if (getTestDataCellValue(scenarioName, "boolSearchByAccount").equalsIgnoreCase("true")) {
				agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Sender_AccountName"),
						ContactsPageObjects.senderTextbox);
			} else {
				agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "UnitName"),
						ContactsPageObjects.senderTextbox);
			}
		} else {
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Sender"),
					ContactsPageObjects.senderTextbox);
		}
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PhCountryCode"),
				ContactsPageObjects.phCountryCodeTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PhAreaCode"), ContactsPageObjects.phAreaCode);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PhoneNumber"),
				ContactsPageObjects.phNumberTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ExtensionNumber"),
				ContactsPageObjects.extensionNumber);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FaxCountryCode"),
				ContactsPageObjects.faxCountryCodeTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FaxAreaCode"),
				ContactsPageObjects.faxAreaCode);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FaxNumber"),
				ContactsPageObjects.faxNumberTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "EmailAddress"),
				ContactsPageObjects.emailAddressTextarea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "OtherPhoneNumber"),
				ContactsPageObjects.otherPhoneNumberTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Degree"), ContactsPageObjects.degreeTextbox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Gender"), ContactsPageObjects.genderLabel);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ContactCategory"),
				ContactsPageObjects.contactCategoryLabel);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ContactSubCategory"),
				ContactsPageObjects.contactSubCategoryLabel);

		Reports.ExtentReportLog("", Status.INFO, "Data Verification in Contact >> Contact Details Section 1", true);

		agCheckPropertyText(getTestDataCellValue(scenarioName, "Specialization"),
				ContactsPageObjects.SpecializationLabel);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "OtherSpecialization"),
				ContactsPageObjects.otherSpecializationTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PrimaryAccount"),
				ContactsPageObjects.primaryAccountTextbox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Department"), ContactsPageObjects.departmentLabel);
		if (getTestDataCellValue(scenarioName, "ConsentToCaptureDetails").equalsIgnoreCase("Yes")) {
			CommonOperations.verifyCheckBoxLeftOf("Consent to Capture Details",
					getTestDataCellValue(scenarioName, "ConsentToCaptureDetails"));
		}
		if (getTestDataCellValue(scenarioName, "ConsentToShare").equalsIgnoreCase("Yes")) {
			CommonOperations.verifyCheckBoxLeftOf("Consent to Share",
					getTestDataCellValue(scenarioName, "ConsentToShare"));
		}

		agJavaScriptExecuctorScrollToElement(ContactsPageObjects.Specialization_Label);
		Reports.ExtentReportLog("", Status.INFO, "Data Verification in Contact >> Contact Details Section 2", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to enter E2B details for a new/existing
	 *             contact.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 19-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void enterContactE2BDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.setListDropDownValue(ContactsPageObjects.dateInformedLabel,
				getTestDataCellValue(scenarioName, "DateInformedBasedOnReceiver"));
		CommonOperations.clickCheckBoxLeftOf(ContactsPageObjects.archiveBasedOnDateInformed_Label,
				getTestDataCellValue(scenarioName, "ArchiveBasedOnDateInformed"));
		CommonOperations.clickCheckBoxLeftOf(ContactsPageObjects.icsrACKRequired_Label,
				getTestDataCellValue(scenarioName, "ICSRACKRequired"));

		agJavaScriptExecuctorScrollToElement(ContactsPageObjects.e2bDetails_Div);
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Contact >> E2B Details Section", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to verify E2B details for a new/existing
	 *             contact.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 02-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyContactE2BDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "DateInformedBasedOnReceiver"),
				ContactsPageObjects.dateInformedLabel);
		CommonOperations.verifyCheckBoxLeftOf(ContactsPageObjects.archiveBasedOnDateInformed_Label,
				getTestDataCellValue(scenarioName, "ArchiveBasedOnDateInformed"));
		CommonOperations.verifyCheckBoxLeftOf(ContactsPageObjects.icsrACKRequired_Label,
				getTestDataCellValue(scenarioName, "ICSRACKRequired"));

		agJavaScriptExecuctorScrollToElement(ContactsPageObjects.e2bDetails_Div);
		Reports.ExtentReportLog("", Status.INFO, "Data Verification in Contact >> E2B Details Section", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to enter Address details for a new/existing
	 *             contact.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 19-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void enterContactAddressDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		CommonOperations.setListDropDownValue(ContactsPageObjects.addressCountryLabel,
				getTestDataCellValue(scenarioName, "AddressCountry"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(ContactsPageObjects.postalCodeBrickTextbox, getTestDataCellValue(scenarioName, "PostalCodeBrick"));
		agSetValue(ContactsPageObjects.postalCodeZipcodeTextbox,
				getTestDataCellValue(scenarioName, "PostalCodeZipcode"));// TBA
		agSetStepExecutionDelay("3000");
		agSetValue(ContactsPageObjects.houseOrAptNumberTextbox, getTestDataCellValue(scenarioName, "HouseAptNumber"));
		agSetValue(ContactsPageObjects.streetAddressTextbox, getTestDataCellValue(scenarioName, "StreetAddress"));
		agSetValue(ContactsPageObjects.addressTextbox, getTestDataCellValue(scenarioName, "Address"));
		agSetValue(ContactsPageObjects.address2Textbox, getTestDataCellValue(scenarioName, "Address2"));
		agSetValue(ContactsPageObjects.cityTextbox, getTestDataCellValue(scenarioName, "City"));
		agSetValue(ContactsPageObjects.stateTextbox, getTestDataCellValue(scenarioName, "State"));
		agSetStepExecutionDelay("3000");
		CommonOperations.setListDropDownValue(ContactsPageObjects.typelabel,
				getTestDataCellValue(scenarioName, "Type"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (!getTestDataCellValue(scenarioName, "PrimaryAddress").equalsIgnoreCase("#skip#")) {
			if (!getTestDataCellValue(scenarioName, "PrimaryAddress").equalsIgnoreCase("Yes")) {
				CommonOperations.clickCheckBoxLeftOf("Primary Address", "false");
			}
		}

		agJavaScriptExecuctorScrollToElement(ContactsPageObjects.addresses_Div);
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Contact >> Addresses Section", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to verify Address details for a new/existing
	 *             contact.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 02-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyContactAddressDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(ContactsPageObjects.addressCountryLabel);
		// Address
		agCheckPropertyText(getTestDataCellValue(scenarioName, "AddressCountry"),
				ContactsPageObjects.addressCountryLabel);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PostalCodeBrick"),
				ContactsPageObjects.postalCodeBrickTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PostalCodeZipcode"),
				ContactsPageObjects.postalCodeZipcodeTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "HouseAptNumber"),
				ContactsPageObjects.houseOrAptNumberTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "StreetAddress"),
				ContactsPageObjects.streetAddressTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Address"),
				ContactsPageObjects.addressTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Address2"),
				ContactsPageObjects.address2Textbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "City"), ContactsPageObjects.cityTextbox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "State"), ContactsPageObjects.stateTextbox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Type"), ContactsPageObjects.typelabel);

		if (!getTestDataCellValue(scenarioName, "PrimaryAddress").equalsIgnoreCase("Yes")) {
			CommonOperations.verifyCheckBoxLeftOf("Primary Address",
					getTestDataCellValue(scenarioName, "PrimaryAddress"));

		}

		agJavaScriptExecuctorScrollToElement(ContactsPageObjects.addresses_Div);
		Reports.ExtentReportLog("", Status.INFO, "Data Verification in Contact >> Addresses Section", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to enter Company Unit Details in Company Unit
	 *             Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 5-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void enterCompanyUnitDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(ContactsPageObjects.companyUnit_Link);
		CommonOperations.clickCheckBoxLeftOf(ContactsPageObjects.allCompanyUnit_CheckBox,
				getTestDataCellValue(scenarioName, "AllCompanyUnit"));

		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Contact >> Company Unit Section", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to enter Account Details in Account Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 14-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void enterAccountDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(ContactsPageObjects.account_Link);
		agSetStepExecutionDelay("5000");
		CommonOperations.clickCheckBoxLeftOf(ContactsPageObjects.allAccount_CheckBox,
				getTestDataCellValue(scenarioName, "AllAccount"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Contact >> Account Section", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to create new contact.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 19-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createContact(String scenarioName) {
		enterContactGeneralDetails(scenarioName);
		enterContactE2BDetails(scenarioName);
		enterContactAddressDetails(scenarioName);
		enterCompanyUnitDetails(scenarioName);
		enterAccountDetails(scenarioName);
		agSetStepExecutionDelay("5000");
		agClick(ContactsPageObjects.saveExitButton);
		String savedMsg = CommonOperations.setAuditInfo("Save_Contact");

		String[] arrOfStr = savedMsg.split("Contact ID '");
		arrOfStr = arrOfStr[1].split("' Saved Successfully");
		savedMsg = arrOfStr[0].trim();
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "ContactsOperations", scenarioName, "CreatedContactId",
				savedMsg);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to verify new contact.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 02-Jan-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyContact(String scenarioName) {
		verifyContactGeneralDetails(scenarioName);
		verifyContactE2BDetails(scenarioName);
		verifyContactAddressDetails(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created write Contact Id To Datasheet
	 * @InputParameters: scenarioName, sheetName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 2-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void writeContactId(String scenarioName, String sheetName) {
		agSetStepExecutionDelay("10000");
		String contactId = agGetText(ContactsPageObjects.contactCreatedMsg);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		String[] orginalText = contactId.split("'");
		String result = orginalText[1];

		/*
		 * String[] arrOfStr = contactId.split("Contact ID"); arrOfStr =
		 * arrOfStr[1].split("Saved successfully"); contactId = arrOfStr[0].trim();
		 * XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName,
		 * scenarioName, "CreatedContactId", contactId);
		 */

		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "CreatedContactId", result);

		if (agIsVisible(ContactsPageObjects.contactCreatedMsg) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Contact Successfully created", true);
			agClick(ContactsPageObjects.okButton);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Contact not created", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search User.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 06-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean searchContact(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("6000");
		agAssertVisible(ContactsPageObjects.contactsListingKeywordsearch);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(ContactsPageObjects.contactsListingKeywordsearch, getTestDataCellValue(scenarioName, "SearchText"));
		agClick(ContactsPageObjects.contactsListingKeywordsearchIcon);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay("7000");
		String paginator = agGetText(ContactsPageObjects.paginator);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.PASS,
					"Search Result with '" + getTestDataCellValue(scenarioName, "SearchText") + "' exists!", true);
			return true;
		} else {
			return false;
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete Contact.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 5-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndDeleteContact(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		boolean searchResults = searchContact(scenarioName);
		System.out.println(searchResults);
		if (searchResults) {
			agClick(CommonPageObjects.selectListingCheckbox(getTestDataCellValue(scenarioName, "SearchText")));
			agClick(ContactsPageObjects.deleteButton);
			CommonOperations.setDeleteAuditInfo("Delete_Contact");
		}
		boolean deleteSearchResults = searchContact(scenarioName);
		if (deleteSearchResults) {
			Reports.ExtentReportLog("", Status.FAIL,
					"Contact : " + getTestDataCellValue(scenarioName, "SearchText") + " is not deleted", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS,
					"Contact : " + getTestDataCellValue(scenarioName, "SearchText") + " is deleted", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is to search and edit Contact in Listing screen
	 * @InputParameters: scenarioName , edit
	 * @OutputParameters:NA
	 * @author:Mithun M P
	 * @Date : 14-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndEditTask(String scenarioName, boolean edit) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agSetValue(ContactsPageObjects.contactsListingKeywordsearch,
				getTestDataCellValue(scenarioName, "CreatedContactId"));
		agClick(ContactsPageObjects.contactsListingKeywordsearchIcon);
		agSetStepExecutionDelay("10000");

		if (agIsVisible(ContactsPageObjects.searchRecEdit(getTestDataCellValue(scenarioName, "CreatedContactId")))) {
			Reports.ExtentReportLog("", Status.INFO, "Contact Search successful", true);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Contact Search Unsuccessful", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		if (edit == true) {
			agClick(ContactsPageObjects.searchRecEdit(getTestDataCellValue(scenarioName, "CreatedContactId")));
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is to search data in advance search screen and edit
	 *             Contact in Listing screen
	 * @InputParameters: scenarioName
	 * @OutputParameters:NA
	 * @author: Avinash k
	 * @Date : 16-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void advanceSearchAndEditTask(String scenarioName, boolean edit) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(ContactsPageObjects.advanceSearchBtn);
		agSetStepExecutionDelay("5000");
		agSetValue(ContactsPageObjects.advaSrchContactIDTxtFeild,
				getTestDataCellValue(scenarioName, "CreatedContactId"));
		agClick(ContactsPageObjects.advSearchBtn);
		agSetStepExecutionDelay("10000");
		if (agIsVisible(ContactsPageObjects.searchRecEdit(getTestDataCellValue(scenarioName, "CreatedContactId")))) {
			Reports.ExtentReportLog("", Status.INFO, "Contact Search successful", true);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Contact Search Unsuccessful", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		if (edit == true) {
			agClick(ContactsPageObjects.searchRecEdit(getTestDataCellValue(scenarioName, "CreatedContactId")));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download Contact and export to
	 *             excel.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 16-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportToexcel(String FileName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(ContactsPageObjects.downloadIcon);
		agClick(ContactsPageObjects.exporttoExcel_link);
		if (agIsVisible(ContactsPageObjects.export_Btn) == true) {
			agClick(ContactsPageObjects.export_Btn);
			try {
				Thread.sleep(8000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			CommonOperations.move_Downloadedexcel(FileName);
			if(agIsVisible(ContactsPageObjects.exportexcelcancel_Btn)) {
				agClick(ContactsPageObjects.exportexcelcancel_Btn);
			}
			
		} else {
			Reports.ExtentReportLog("Export to excel pop is not displayed", Status.INFO, "", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to compare record count with download
	 *             excel
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:Avinash K
	 * @Date : 16-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void recordCountVerification(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		String count = xls.getCellData("Contact", 2, 4);
		String[] Totalcount = count.split(":");
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in exported excel::" + Totalcount[1].trim(),
				false);
		String applrecordcount = agGetText(ContactsPageObjects.paginator);
		String[] data = applrecordcount.split(" ");
		String recordCount = data[4];
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in application::" + recordCount, false);
		if (recordCount.equalsIgnoreCase(Totalcount[1].trim())) {
			Reports.ExtentReportLog("", Status.PASS, "Record count verification is successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Record count verification is Unsuccessfull", true);
		}
	}
}
