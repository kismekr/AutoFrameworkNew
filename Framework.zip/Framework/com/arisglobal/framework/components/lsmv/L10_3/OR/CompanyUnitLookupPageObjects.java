package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class CompanyUnitLookupPageObjects {
	public static String unitCode_TextBox = "xpath#//label[text()= 'Unit Code']/following-sibling::input[contains(@id , 'companyUnitlookupSearchForm:')]";
	public static String unitName_TextBox = "xpath#//label[text()= 'Unit Name']/following-sibling::input[contains(@id , 'companyUnitlookupSearchForm:')]";
	public static String type_DropDown = "xpath#//label[@id='companyUnitlookupSearchForm:CompanyUnitLookup-9_label']";
	public static String country_DropDown = "xpath#//label[@id='companyUnitlookupSearchForm:CompanyLookup-1_label']";
	
	public static String search_Button = "xpath#//button[@id='companyUnitlookupSearchForm:companySearchId']";
	public static String clear_Button = "xpath#//button[@id='companyUnitlookupSearchForm:companyClearId']";
	public static String ok_Button = "xpath#//button[contains(@id, 'companyUnitlookupSearchForm:bottomOkButton')]";
	
	public static String searchResultSelectRadio = "xpath#//tbody[@id = 'companyUnitlookupSearchForm:companyUnitTable:companyUnitLookUpDataTable_data']/descendant::div/span[contains(@class, 'ui-radiobutton-icon')]";
}
