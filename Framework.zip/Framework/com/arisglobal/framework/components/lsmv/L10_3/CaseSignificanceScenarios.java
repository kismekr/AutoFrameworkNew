package com.arisglobal.framework.components.lsmv.L10_3;

import org.openqa.selenium.WebElement;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;

public class CaseSignificanceScenarios extends ToolManager {
	
	public static WebElement webElement;
	static String className = CaseSignificanceScenarios.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	
	/**********************************************************************************************************
	 * @Objective: This method is created load data from excel sheet
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 09-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void loadDataToMultimap() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
	}
	
	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 09-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
	
	
}