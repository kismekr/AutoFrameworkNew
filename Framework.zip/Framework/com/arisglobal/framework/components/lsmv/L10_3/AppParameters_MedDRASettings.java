package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AppParameters_MedDRASettingsPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AppParameters_MedDRASettings extends ToolManager {
	static String className = AppParameters_MedDRASettings.class.getSimpleName();

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set MedDRA Settings Details in
	 *             MedDRA Settings Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 17-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setMedDRASettingsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_MedDRASettingsPageObjects.hostName_TextBox,
					getTestDataCellValue(scenarioName, "HostName"));
			agSetValue(AppParameters_MedDRASettingsPageObjects.portNumber_TextBox,
					getTestDataCellValue(scenarioName, "PortNumber"));
			agSetValue(AppParameters_MedDRASettingsPageObjects.sourceID_TextBox,
					getTestDataCellValue(scenarioName, "SourceID"));
			agSetValue(AppParameters_MedDRASettingsPageObjects.username_TextBox,
					getTestDataCellValue(scenarioName, "Username"));
			agSetValue(AppParameters_MedDRASettingsPageObjects.password_TextBox,
					getTestDataCellValue(scenarioName, "Password"));

			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> MedDRA Settings >> MedDRA Settings Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> MedDRA Settings >> MedDRA Settings Section fails", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read MedDRA Settings Details in
	 *             MedDRA Settings Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadMedDRASettingsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			agClick(AppParameters_MedDRASettingsPageObjects.hostName_TextBox);
			String HostName = agGetAttribute("value", AppParameters_MedDRASettingsPageObjects.hostName_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "HostName", HostName);

			agClick(AppParameters_MedDRASettingsPageObjects.sourceID_TextBox);
			String SourceID = agGetAttribute("value", AppParameters_MedDRASettingsPageObjects.sourceID_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SourceID", SourceID);

			agClick(AppParameters_MedDRASettingsPageObjects.portNumber_TextBox);
			String PortNumber = agGetAttribute("value", AppParameters_MedDRASettingsPageObjects.portNumber_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "PortNumber", PortNumber);

			agClick(AppParameters_MedDRASettingsPageObjects.username_TextBox);
			String Username = agGetAttribute("value", AppParameters_MedDRASettingsPageObjects.username_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Username", Username);

			agClick(AppParameters_MedDRASettingsPageObjects.password_TextBox);
			String Password = agGetAttribute("value", AppParameters_MedDRASettingsPageObjects.password_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Password", Password);

			Reports.ExtentReportLog("", Status.INFO,
					"Read Data Entered in Application Parameters >> MedDRA Settings >> MedDRA Settings Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data Entered in Application Parameters >> MedDRA Settings >> MedDRA Settings Section fails",
					true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set data in MedDRA Settings Tab
	 *             under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 17-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setAppParameters_MedDRASettingsTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >>MedraSetting Tab Started",
				true);
		setMedDRASettingsDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >>MedraSetting Tab Completed",
				true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read data in MedDRA Settings Tab
	 *             under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date :25-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadAppParameters_MedDRASettingsTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO,
				"Read Data Entered in Application Parameters >>MedraSetting Tab Started", true);
		ReadMedDRASettingsDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO,
				"Read Data Entered in Application Parameters >>MedraSetting Tab Completed", true);
	}
}
