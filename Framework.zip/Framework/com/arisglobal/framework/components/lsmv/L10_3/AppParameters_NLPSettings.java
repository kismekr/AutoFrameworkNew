package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AppParameters_NLPSettingsPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AppParameters_NLPSettings extends ToolManager{
	static String className = AppParameters_NLPSettings.class.getSimpleName();

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set NLP Settings Details in NLP Settings Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 17-April-2020
	 * @UpdatedByAndWhen: 
	 ************************************************************************************************************************/
	public static void setNLPSettingsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(AppParameters_NLPSettingsPageObjects.nlpConfigurationPath_TextBox, getTestDataCellValue(scenarioName, "NLPConfigurationPath"));
		CommonOperations.setListDropDownValue(AppParameters_NLPSettingsPageObjects.defaultCompanyProduct_DropDown, getTestDataCellValue(scenarioName, "DefaultCompanyProduct"));

		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >> NLP Settings >> NLP Settings Section", true);
	}
	
	/***********************************************************************************************************************
	 * @Objective: The below method is created to set data in NLP Settings Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 17-April-2020
	 * @UpdatedByAndWhen: 
	 ************************************************************************************************************************/
	public static void setAppParameters_NLPSettingsTabDetails(String scenarioName) {
		setNLPSettingsDetails(scenarioName);
	}

}
