package com.arisglobal.framework.components.lsmv.L10_3;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.MedicalReviewFormPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class MedicalReviewFormOperations extends ToolManager{
	static String className = FDE_General.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: The below method is created to switch to desired form view
	 * @InputParameters: Form Type
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 28-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void switchToDesiredFormType(String formType) {
		formType = formType.toUpperCase();
		agWaitTillVisibilityOfElement(MedicalReviewFormPageObjects.moreOptionsHover);
		agMouseHover(MedicalReviewFormPageObjects.moreOptionsHover);
		agMouseHover(MedicalReviewFormPageObjects.switchToForm);
		agClick(MedicalReviewFormPageObjects.formTypeLocator(formType));
		
		//Read Acknowledgement
		if (agIsExists(MedicalReviewFormPageObjects.ackTitle)) {
			agClick(MedicalReviewFormPageObjects.ackMessage1);
			Reports.ExtentReportLog("", Status.PASS, "Acknowledgement: "+agGetText(MedicalReviewFormPageObjects.ackMessage1), true);
			Reports.ExtentReportLog("", Status.PASS, "Acknowledgement: "+agGetText(MedicalReviewFormPageObjects.ackMessage2), false);
			agClick(MedicalReviewFormPageObjects.ackOK_Btn);
			Reports.ExtentReportLog("", Status.PASS, "Case opened in desired form type successfully", true);
		}
		
	}

	
	/**********************************************************************************************************
	 * @Objective: To traverse to particular section
	 * @InputParameters: Tab Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 04-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void traverseToDesiredTab(String tabName) {
		agSetStepExecutionDelay("2000");
		agClick(MedicalReviewFormPageObjects.sectionTitleBar(tabName));
		Reports.ExtentReportLog("", Status.PASS, "User Directed to "+tabName+" successfully", true);
	}

	
	/**********************************************************************************************************
	 * @Objective: To Expand particular Product record listed under Products/Events tab 
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 04-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void expandProductRecord(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		String classAtr = agGetAttribute("class", MedicalReviewFormPageObjects.productsEvents_ExpandIcon(
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName")));
		if (classAtr.contains("circle-right")) {
			agClick(MedicalReviewFormPageObjects.productsEvents_ExpandIcon(
					getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName")));
			Reports.ExtentReportLog("", Status.PASS, "Product Record expanded to view details", true);
		}
		
	}
	
	/**********************************************************************************************************
	 * @Objective: To verify and edit Labeling details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 04-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyLabellingDetailsEditable(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		
		if(agIsExists(MedicalReviewFormPageObjects.labellingCountry_CheckBox)) {
			if(!(agGetAttribute("class", MedicalReviewFormPageObjects.labellingCountry_CBState).contains("ui-state-active"))) {
			agClick(MedicalReviewFormPageObjects.labellingCountry_CheckBox);
			}
			agSetStepExecutionDelay("1000");
			agClick(MedicalReviewFormPageObjects.labelling_SelectParent);
			agClick(MedicalReviewFormPageObjects.labelling_Select);			
		}
		
		Reports.ExtentReportLog("", Status.PASS, "Product Record expanded to view details", true);
	}
	
	/**********************************************************************************************************
	 * @Objective: To verify and edit Causality details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 04-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCompanyCausalityEditable(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		String prodName = getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName");
		String colName = "company causality";
		boolean isAvailable = false; 
		int columnNum = 0;

		List<WebElement> tbHeaders = agGetElementList(MedicalReviewFormPageObjects.tBodyHeaders(prodName));
		int size = tbHeaders.size();

		if (size>0) {
			for (int i = 1; i <= size; i++) {
				String tempName = agGetText(MedicalReviewFormPageObjects.tBodyHeadersByNumber(prodName, i)).trim().toLowerCase();
				if (tempName.equalsIgnoreCase(colName)) {
					columnNum = i;
					isAvailable = true;
					agClick(MedicalReviewFormPageObjects.causalityDropDown(prodName, columnNum));
					agSetStepExecutionDelay("1000");
					agClick(MedicalReviewFormPageObjects.causalityDropDown_value);
					Reports.ExtentReportLog("", Status.PASS, "Causality Dropdown value selected", true);
					break;
				}
			}
			if (isAvailable==false) {
				Reports.ExtentReportLog("", Status.FAIL, "Causality Dropdown field is not available", true);				
			}
		}
		else {
			Reports.ExtentReportLog("", Status.FAIL, "No record with the expected Product Name not available", true);
		}
	}
	
	
	/**********************************************************************************************************
	 * @Objective: To verify Labeling Version and Assess Relationship field availability
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 04-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyFieldsAvailability(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		if (agIsExists(MedicalReviewFormPageObjects.labellingVersion_THeader)) {
			agClick(MedicalReviewFormPageObjects.labellingVersion_THeader);
		}
		if (agIsExists(MedicalReviewFormPageObjects.assessRelaionship_THeader)) {
			agIsExists(MedicalReviewFormPageObjects.assessRelaionship_THeader);
		}
		Reports.ExtentReportLog("", Status.PASS, "Product Record expanded to view details", true);
	}
	
	
}
