package com.arisglobal.framework.components.lsmv.L10_3.OR;

public abstract class CaseListingReassignPageObjects {

	public static String reAssignLabel = "xpath#//div/span[text()='Re-assign Adverse Event']";
	public static String companyunitDropDown = "xpath#//*[@id='select2-cuDropDown-container']";
	public static String companyunitDropDownValueSelect = "xpath#//ul[@id='select2-cuDropDown-results']/child::li[contains(text(),";
	public static String reAssignedToRadioButton = "xpath#(//div[@class='col-md-2']/child::label/label[text()='%s']/following::span)[1]";
	public static String clickUserGroupDropDown = "xpath#//*[@id='select2-usrGrpDropDown-container']";
	public static String setUserGroupDropDown = "xpath#//ul[@id='select2-usrGrpDropDown-results']/child::li[contains(text(),";
	public static String userGroupDropDownValueSelect = "xpath#//ul[contains(@id,'reAssignForm:j_id')]/child::li[contains(text(),";
	public static String commentsTextArea = "xpath#//textarea[@id='textareaId']";
	public static String reAssign_Button = "xpath#//div[@id='reassignDialog']//a[@id='reAssign']";
	public static String selectDropdrown = "xpath#//ul[contains(@id,'select2')]/li[contains(text(),'%s')]";
	public static String CompUnit_DD_Textbox = "xpath#//input[@class='select2-search__field']";

	public static String Searchload_icon = "xpath#//img[@id='headerForm:j_id_x']";

	public static String CompanyUnit = "Company Unit";
	public static String Manager = "Manager";

	/**********************************************************************************************************
	 * Objective:The below method is created to select Reassign Dropdown value by
	 * passing value at runtime. Input Parameters: runTimeLabel Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/

	public static String selectDropdrown(String runTimeLabel) {
		String value = selectDropdrown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select the radio button by passing
	 * the label at runtime. Input Parameters: runTimeLabel Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when
	 **********************************************************************************************************/

	public static String clickRadioButton(String runTimeLabel) {
		String value = reAssignedToRadioButton;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

}
