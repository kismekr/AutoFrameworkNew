package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class AppParameters_DMSPageObjects {

	//////// Administration >> Application Parameters >> DMS ////////

	public static String dmsType_DropDown = "xpath#//div[@id='applicationParameterForm:A1-342']";
	public static String documentTransferType_DropDown = "xpath#//div[@id='applicationParameterForm:A1-9133']";

	//////// Administration >> DMS >> General ////////

	public static String IAMRole_TextBox = "IAM Role";
	public static String accessKey_TextBox = "xpath#//input[@id='applicationParameterForm:accessKeyId']";
	public static String secretKey_TextBox = "xpath#//input[@id='applicationParameterForm:secretKeyId']";
	public static String s3Region_TextBox = "xpath#//input[@id='applicationParameterForm:s3RegionId']";
	public static String s3Bucket_TextBox = "xpath#//input[@id='applicationParameterForm:s3BucketId']";
	public static String s3DirectoryPath_Textox = "xpath#//input[@id='applicationParameterForm:s3FolderId']";

	//////// Administration >> DMS >> Master Data ////////

	public static String masterAccessKey_TextBox = "xpath#//input[@id='applicationParameterForm:accessKeyId1']";
	public static String masterSecretKey_TextBox = "xpath#//input[@id='applicationParameterForm:secretKeyId1']";
	public static String masterS3Region_TextBox = "xpath#//input[@id='applicationParameterForm:s3RegionId1']";
	public static String masterS3Bucket_TextBox = "xpath#//input[@id='applicationParameterForm:s3BucketId1']";
	public static String masterS3DirectoryPath_Textox = "xpath#//input[@id='applicationParameterForm:s3FolderId1']";

}
