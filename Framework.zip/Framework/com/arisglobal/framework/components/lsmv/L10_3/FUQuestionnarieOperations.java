package com.arisglobal.framework.components.lsmv.L10_3;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.FUQuestionnairePageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FollowUpRulesPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DataBaseOperations;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FUQuestionnarieOperations extends ToolManager {

	static String className = FUQuestionnarieOperations.class.getSimpleName();
	// public static String questionSheetName =
	// Libraries_Questions.class.getSimpleName();
	public static String testDataPath = lsmvConstants.LSMV_testData;
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: To Verify and select Followup Questionnarie generated for the
	 *             case
	 * @InputParameters: object
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 07-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void ClickFUQuestionnarieLink(String index) {
		agMouseHover(FUQuestionnairePageObjects.correspondence);
		if (agIsVisible(FUQuestionnairePageObjects.selectFollowpRctlink(index))) {
			agClick(FUQuestionnairePageObjects.selectFollowpRctlink(index));
			Reports.ExtentReportLog("", Status.INFO, "Follow Up Questinaire Present for Created Case", true);
			agWaitTillVisibilityOfElement(FUQuestionnairePageObjects.followUPRCTNoLabel);
			verifyQuestionData();
		} else
			Reports.ExtentReportLog("", Status.INFO, "Follow Up Questinaire Is not Present for created case", true);

	}

	/**********************************************************************************************************
	 * @Objective: To add questions to Followup Questionnarie generated for the case
	 * @InputParameters: object
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 07-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addQuestionsByContext(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agIsVisible(FUQuestionnairePageObjects.followupQuestionnarie_Label);
		agIsVisible(FUQuestionnairePageObjects.status);
		CommonOperations.setListDropDownValue(FUQuestionnairePageObjects.addQuestiondropdown,
				Libraries_Questions.getTestDataCellValue(scenarioName, "Context"));
		agClick(FUQuestionnairePageObjects.addbtn);
		addQuestions(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: To select the Followup Questionnarie in FDE screen
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 07-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void addQuestions(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FUQuestionnairePageObjects.questionslookup);
		agIsVisible(FUQuestionnairePageObjects.questionnarieslookup_label);
		agSetValue(FollowUpRulesPageObjects.questionName_filter,
				Libraries_Questions.getTestDataCellValue(scenarioName, "QuestionName"));
		agClick(FUQuestionnairePageObjects.question_Radiobtn);
		agClick(FUQuestionnairePageObjects.questionOkbtn);
		agClick(FUQuestionnairePageObjects.questionSubmitbtn);
	}

	/**********************************************************************************************************
	 * @Objective: To Verify the Followup submitted icon present in FDE screen
	 * @InputParameters: object
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 07-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyFollowUpsubmitIcon() {
		agMouseHover(FUQuestionnairePageObjects.correspondence);
		agIsVisible(FUQuestionnairePageObjects.followupsubmittedicon);
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: To Open the Follow up Questionnarie through Email by clicking on
	 *             correspondence
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 07-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void openFollowupQuestionnarie() {
		agSetStepExecutionDelay("2000");
		agClick(FUQuestionnairePageObjects.correspondence);
		agIsVisible(FUQuestionnairePageObjects.followupQuestionnarieIcon);
		agIsVisible(FUQuestionnairePageObjects.subject);
		agClick(FUQuestionnairePageObjects.subject);
		agWaitTillInvisibilityOfElement(FUQuestionnairePageObjects.loading);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: To Open the subject email which contains the answers of the
	 *             Follow up Questionnaire sent by the reporter
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 18-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void openFUQuestionnarieSubject() {
		agSetStepExecutionDelay("2000");
		agClick(FUQuestionnairePageObjects.correspondence);
		agIsVisible(FUQuestionnairePageObjects.followupQuestionnarieIcon);
		status = agIsVisible(FUQuestionnairePageObjects.followupSubmitted_Icon);
		agIsVisible(FUQuestionnairePageObjects.subjectVerification);
		agClick(FUQuestionnairePageObjects.subjectVerification);
		agWaitTillInvisibilityOfElement(FUQuestionnairePageObjects.loading);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: To verify the answers of the Follow up Questionnaire sent by the
	 *             reporter
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 18-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyAnswersFUQuestionnarie() {
		agSetStepExecutionDelay("2000");
		agClick(FUQuestionnairePageObjects.correspondence);
		agIsVisible(FUQuestionnairePageObjects.followupQuestionnarieIcon);
		status = agIsVisible(FUQuestionnairePageObjects.followupSubmitted_Icon);
		agIsVisible(FUQuestionnairePageObjects.subjectVerification);
		agClick(FUQuestionnairePageObjects.subjectVerification);
		agWaitTillInvisibilityOfElement(FUQuestionnairePageObjects.loading);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: To set all the datas to send the followup questionnarie through
	 *             Email
	 * @InputParameters: object
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 07-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SetEmailParameters(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		agIsVisible(FUQuestionnairePageObjects.followupqueries_hdr);
		agSelectByVisibleText(FUQuestionnairePageObjects.selectMode,
				getTestDataCellValue(scenarioName, "FollowUp_Mode"));
		if (getTestDataCellValue(scenarioName, "FollowUp_QueryFormat").equalsIgnoreCase("true")) {
			agClick(FUQuestionnairePageObjects.clickRadiobtn_Checkbox(FUQuestionnairePageObjects.webLink_Radiobtn));
			agClick(FUQuestionnairePageObjects.queryformatPopUP);
			agWaitTillInvisibilityOfElement(FUQuestionnairePageObjects.queryformatPopUP);
		}
		agSetValue(FUQuestionnairePageObjects.correspondenceTo,
				getTestDataCellValue(scenarioName, "FollowUp_CorrespondenceTo"));
		agSelectByVisibleText(FUQuestionnairePageObjects.selectpriority,
				getTestDataCellValue(scenarioName, "FollowUp_Priority"));
		agSelectByVisibleText(FUQuestionnairePageObjects.selectstatus,
				getTestDataCellValue(scenarioName, "FollowUp_Status"));
		agSelectByVisibleText(FUQuestionnairePageObjects.selectCategory,
				getTestDataCellValue(scenarioName, "FollowUp_Category"));
		agSelectByVisibleText(FUQuestionnairePageObjects.selectQueryStatus,
				getTestDataCellValue(scenarioName, "FollowUp_QueryStatus"));

		agSetValue(FUQuestionnairePageObjects.noOfReminders,
				getTestDataCellValue(scenarioName, "FollowUp_NoofReminders"));
		agSetValue(FUQuestionnairePageObjects.reminderInterval,
				getTestDataCellValue(scenarioName, "FollowUp_ReminderInterval"));
		agSelectByVisibleText(FUQuestionnairePageObjects.selectReminderIntervalUnit,
				getTestDataCellValue(scenarioName, "FollowUp_ReminderIntervalUnit"));

		if (getTestDataCellValue(scenarioName, "FollowUp_OverrideReminder").equalsIgnoreCase("true")) {
			agClick(FUQuestionnairePageObjects.clickRadiobtn_Checkbox(FUQuestionnairePageObjects.overRideReminder));
			agClick(FUQuestionnairePageObjects.clickRadiobtn_Checkbox(FUQuestionnairePageObjects.turnOffReminder));
		}

		/*
		 * agClick(FollowUpQuestionnairePageObjects.remindertemplate);
		 * agWaitTillVisibilityOfElement(FollowUpQuestionnairePageObjects.templatelookUP
		 * ); agSetValue(FollowUpQuestionnairePageObjects.searchtemplate,
		 * getTestDataCellValue(scenarioName, "FollowUp_TemplateName"));
		 */
		agClick(FUQuestionnairePageObjects.sendBtn);
		agWaitTillInvisibilityOfElement(FUQuestionnairePageObjects.sendEmailPopUp);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Get list of question Names from the Excel
	 *             Sheet and verify in FU Questionnaire
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 15-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> GetQuestionListFromExcel() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		ArrayList<String> scenario = Multimaplibraries.getScenarioList(testDataPath, className);

		for (int i = 1; i < scenario.size(); i++) {
			// int j = i+1;

			status = agIsVisible(FUQuestionnairePageObjects
					.getQuestion(getTestDataCellValue("VerifyQuestion_" + i, "FollowUp_QuestionName")));
			if (status) {
				Reports.ExtentReportLog(
						"", Status.PASS, " Question Name : '"
								+ getTestDataCellValue("VerifyQuestion_" + i, "FollowUp_QuestionName") + "' exists!",
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, " Question Name : '"
						+ getTestDataCellValue("VerifyQuestion_" + i, "FollowUp_QuestionName") + "' doesnt exists!",
						false);
			}

		}
		agClick(FUQuestionnairePageObjects.closeIcon);
		return scenario;

	}

	/**********************************************************************************************************
	 * @Objective: To Click the followup Questions weblink and provide the
	 *             Passcode(in Progress)
	 * @InputParameters: object
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 14-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Boolean clickFollowUpWeblink() {
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorScrollToElement(FUQuestionnairePageObjects.messagelabel);
		Boolean flag = false;
		agSwitchFrameByIndex(0);
		/*
		 * String text=agGetText(FollowUpQuestionnairePageObjects.getListofbr);
		 * System.out.println(text);
		 */

		List<WebElement> list = agGetElementList(FUQuestionnairePageObjects.getListofbr);
		String columnHeader = null;
		String passcode = "";
		for (int j = 1; j <= list.size(); j++) {
			columnHeader = agGetText(FUQuestionnairePageObjects.columnHeaderList(Integer.toString(j)));
			if (!passcode.equalsIgnoreCase(columnHeader)) {
				flag = true;
				break;
			}

		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		return flag;

	}

	/**********************************************************************************************************
	 * @Objective: To open the email and navigate to followup Questions weblink and
	 *             provide the Passcode(in Progress)
	 * @InputParameters: object
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 14-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void OpenMail(String scenarioName) {
		// agClick(OutlookWebmailPageObjects.openEmail(FDE_General.getTestDataCellValue(scenarioName,
		// "ReceiptNo")));
		String hyperlink = agGetAttribute("href", FUQuestionnairePageObjects.followUPWebLink);
		System.out.println(hyperlink);
		agNavigate(hyperlink);
		agGetCurrentWindow();

	}

	/**********************************************************************************************************
	 * @Objective: To Login by providing the passcode(in Progress)
	 * @InputParameters: object
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 14-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void loginPasscode(String columnHeader) {
		agSetValue(FUQuestionnairePageObjects.passcodeTextbox, columnHeader);
		agClick(FUQuestionnairePageObjects.submitPasscodeBtn);
		agWaitTillVisibilityOfElement(FUQuestionnairePageObjects.lifeSphereLogo);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Follow up Questionnaire
	 *             generated or not
	 * @InputParameters: object
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 26-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyFollowUPQuestionnaire(String index) {
		Reports.ExtentReportLog("", Status.INFO, " Followup Questionnarie generation started ", true);
		try {
			ClickFUQuestionnarieLink(index);
		} catch (Exception e) {
			e.printStackTrace();
			if (agIsVisible(FUQuestionnairePageObjects.closeIcon) == true) {
				agClick(FUQuestionnairePageObjects.closeIcon);
				Reports.ExtentReportLog("", Status.FAIL, " Followup Questionnarie generation failed " + e, true);
			}
		}
		Reports.ExtentReportLog("", Status.INFO, " Followup Questionnarie generation ended ", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Follow up Questionnaire
	 *             generated or not
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 26-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Boolean verifyQuestionData() {
		Boolean falg = false;
		List<WebElement> list = agGetElementList(FUQuestionnairePageObjects.getQuestionNames);
		for (int j = 1; j <= list.size(); j++) {
			Boolean rowCount = agIsVisible(FUQuestionnairePageObjects.questionCountList(Integer.toString(j)));
			String question = agGetText(FUQuestionnairePageObjects.questionCountList(Integer.toString(j)));
			if (rowCount) {
				falg = true;
				// break;
				Reports.ExtentReportLog("", Status.INFO, " Followup Questionnarie generated ", true);
				Reports.ExtentReportLog("", Status.INFO, " Question Name : " + question + " exists! ", true);
			}
		}
		agClick(FUQuestionnairePageObjects.closeIcon);
		return falg;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Follow up Questionnaire
	 *             Weblink
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 11-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void FollowupQuestionreWeblink(String scenarioName) {
		Connection dbCon = null;
		try {
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);
			ResultSet rs = DataBaseOperations.performRead(dbCon,
					"SELECT * FROM moreactionsoperations WHERE Scenario = '" + scenarioName + "' ");
			rs.beforeFirst();
			rs.last();
			String Passcode = rs.getString("Passcode");
			String Weblink = rs.getString("Weblink");
			Reports.ExtentReportLog("", Status.INFO, " Followup Questionnarie Weblink verification starts ", false);
			agNavigate(Weblink);
			agWaitTillVisibilityOfElement(FUQuestionnairePageObjects.FUQWLPasscode);
			agSetValue(FUQuestionnairePageObjects.FUQWLPasscode, Passcode);
			Reports.ExtentReportLog("", Status.INFO, " Followup Questionnarie Weblink Login starts ", true);
			agClick(FUQuestionnairePageObjects.FUQWLSubmittbutton);
			agWaitTillVisibilityOfElement(FUQuestionnairePageObjects.FUQWLUserComments);
			Reports.ExtentReportLog("", Status.INFO, " Followup Questionnarie Weblink Login is sucessfull", true);
			agSetValue(FUQuestionnairePageObjects.FUQWLUserComments,
					getTestDataCellValue(scenarioName, "FUQUserComments"));
			agClick(FUQuestionnairePageObjects.FUQWLFileUpload);
			agUploadDocuments(lsmvConstants.lsmvXmlPath + getTestDataCellValue(scenarioName, "FileName"));
			agWaitTillVisibilityOfElement(FUQuestionnairePageObjects.FUQWLFileName.replace("%fileName",
					getTestDataCellValue(scenarioName, "FileName")));
			Reports.ExtentReportLog("", Status.INFO, " Followup Questionnarie Weblink Reply Response ", true);
			agClick(FUQuestionnairePageObjects.FUQWLSubmittButton);
			Reports.ExtentReportLog("", Status.INFO, " Followup Questionnarie Weblink verification ends ", false);
		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, " Followup Questionnarie Weblink verification failed ", false);
		}

	}

}
