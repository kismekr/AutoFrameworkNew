package com.arisglobal.framework.components.lsmv.L10_3;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.CommonOperations;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CaseManagementPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDEMoreOptionsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_MedraLookUpPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_ParentPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_ProductsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_StudyPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.Product_LookupPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.ProductsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.SenderLookupPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

import bsh.ParseException;

public class FDE_Products extends ToolManager {
	static String className = FDE_Products.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	public static void setProductDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.productDropdownSelect(label));
			agJavaScriptExecuctorClick(
					FDE_GeneralPageObjects.clickDropDownValue(getTestDataCellValue(scenarioName, columnName)));
		}
	}

	public static void setProductEmbedDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_ProductsPageObjects.productEmdedDropdownSelect(label));
			agJavaScriptExecuctorClick(
					FDE_GeneralPageObjects.clickDropDownValue(getTestDataCellValue(scenarioName, columnName)));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in text field value
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyData(String object, String scenarioName, String columnName) {

		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(object);
			agCheckPropertyValue("title", getTestDataCellValue(scenarioName, columnName), object);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click product lookup
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickProductLookup() {
		agClick(FDE_ProductsPageObjects.productDescriptionLookup);
		agSetStepExecutionDelay("5000");
		if (agIsVisible(Product_LookupPageObjects.ProductName_TxtfieldLookup) == true)
			;
		{
			Reports.ExtentReportLog("", Status.PASS, "Product lookup is displayed", true);
		}

		{
			Reports.ExtentReportLog("", Status.FAIL, "Product lookup is displayed", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: Set Product Information test data in general page of FDE
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setProductInformation(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (scenarioName.equalsIgnoreCase("ConfigureDSURCodelist_2")) {
			agClick(FDE_ProductsPageObjects.AddBtnProduct);
			agSetStepExecutionDelay("5000");
		}

		agJavaScriptExecuctorClick(FDE_ProductsPageObjects.productinfo_label);

		setProductDropDownValue(FDE_ProductsPageObjects.productCharacterizationDrpdwn, scenarioName,
				"Products_ProductInformation_ProductCharacterization");
		agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.prductNameAsReportedTxtbox),
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductNameAsReported"));
		agClick(FDE_ProductsPageObjects.productNameAsReported_Label);
		agSetStepExecutionDelay("9000");
		
		CommonOperations.captureScreenShot(true);
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_Lookup")
				.equalsIgnoreCase("Yes")) {
			agClick(FDE_ProductsPageObjects.productDescriptionLookup);
			agClick(FDE_ProductsPageObjects.productLibray_RadioBtn);
			// Added for japanese workflow
			if (!scenarioName.equalsIgnoreCase("JapanTest") || !scenarioName.equalsIgnoreCase("JapanDomFDE")) {
				if (scenarioName.contains("FDA")) {
					// FDAProdName
					agSetValue(Product_LookupPageObjects.FDAProdName, getTestDataCellValue(scenarioName,
							"Products_ProductInformation_ProductDescription_ProductName"));
				} else
					agSetStepExecutionDelay("5000");
				agSetValue(
						FDE_ProductsPageObjects
								.level1ProductTextbox(Product_LookupPageObjects.prodLibproductNameTextbox),
						getTestDataCellValue(scenarioName,
								"Products_ProductInformation_ProductDescription_ProductName"));
			}
			agClick(FDE_ProductsPageObjects.searchButton);
			if (getTestDataCellValue(scenarioName, "Products_ProductInformation_LocalTradeName")
					.equalsIgnoreCase("Yes")) {
				agClick(Product_LookupPageObjects.localTradeName);
			}
			agClick(FDE_ProductsPageObjects.checkFirstProdInProdLib);

			agClick(FDE_ProductsPageObjects.prodLibOkButton);

			agSetStepExecutionDelay("5000");
			if (agIsVisible(FDE_ProductsPageObjects.indication_Popup) == true) {
				agClick(FDE_ProductsPageObjects.indicationPopup_CloseIcon);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			/*
			 * if (agIsVisible(FDE_ProductsPageObjects.listedness_Popup) == true) {
			 * agClick(FDE_ProductsPageObjects.listedness_PopupYesBtn); }
			 */
			if (agIsVisible(FDE_ProductsPageObjects.confirmationYes)) {
				agClick(FDE_ProductsPageObjects.confirmationYes);
			}

		}
		/*
		 * agSetStepExecutionDelay("3000");
		 * setProductDropDownValue(FDE_ProductsPageObjects.countryObtainedDrpdwn,
		 * scenarioName, "Products_ProductInformation_CountryObtained");
		 * agSetStepExecutionDelay(String.valueOf(Constants.
		 * defaultGlobalStepExecutionDelay));
		 * 
		 * agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * medicinalProductIdentifierTxtbox), getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_MedicinalProductIdentifierMPID"));
		 * agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * MPIDverNumTxtbox), getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_MPIDVersionDateNumber"));
		 * agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * PhPIDTxtbox), getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_PhPID"));
		 * agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * PhPIDverDateNumberTxtbox), getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_PhPIDVersionDateNumber"));
		 * agSetValue(FDE_ProductsPageObjects.productEmbedTxtbox(FDE_ProductsPageObjects
		 * .cumulativeDose), getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_CumulativeDoseToFirstReaction"));
		 * setProductEmbedDropDownValue(FDE_ProductsPageObjects.cumulativeDose,
		 * scenarioName,
		 * "Products_ProductInformation_CumulativeDoseToFirstReaction_Unit");
		 * agSetValue(FDE_ProductsPageObjects.productEmbedTxtbox(FDE_ProductsPageObjects
		 * .gestationPeriod), getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_GestationPeriodAtTimeOfExposure"));
		 * setProductEmbedDropDownValue(FDE_ProductsPageObjects.gestationPeriod,
		 * scenarioName,
		 * "Products_ProductInformation_GestationPeriodAtTimeOfExposure_Unit");
		 */
		agSetStepExecutionDelay("5000");
		CommonOperations.captureScreenShot(true);
		setProductDropDownValue(FDE_ProductsPageObjects.actionTakenWithDrug, scenarioName,
				"Products_ProductInformation_ActionTakenWithDrug");

		setProductDropDownValue(FDE_ProductsPageObjects.codingClassDrpdwn, scenarioName,
				"Products_ProductInformation_CodingClass");

		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductBlinded").equalsIgnoreCase("Yes")) {
			agClick(FDE_ProductsPageObjects.checkRadioButton_Value(FDE_ProductsPageObjects.productBlindedRadio,
					getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductBlinded")));
		}

		setProductDropDownValue(FDE_ProductsPageObjects.productFlag, scenarioName,
				"Products_ProductInformation_ProductFlag");

		/*
		 * agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * NDCNumber), getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_NDCNumber"));
		 */
		if (scenarioName.equalsIgnoreCase("ConfigureDSURCodelist_1")) {
			setStudyProductTypeDropDownValue(FDE_ProductsPageObjects.studyProductType, scenarioName,
					"Products_ProductInformation_StudyProductType");
			agSetStepExecutionDelay("10000");
			CommonOperations.captureScreenShot(true);
		} else {
			setProductDropDownValue(FDE_ProductsPageObjects.studyProductType, scenarioName,
					"Products_ProductInformation_StudyProductType");
		}

		/*
		 * if (getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_ProductType").equalsIgnoreCase("OCT")) {
		 * agClick(FDE_ProductsPageObjects.productChkbox(FDE_ProductsPageObjects.
		 * productType, FDE_ProductsPageObjects.productTypeOTC)); } if
		 * (getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_ProductType") .equalsIgnoreCase("Compounded")) {
		 * agClick(FDE_ProductsPageObjects.productChkbox(FDE_ProductsPageObjects.
		 * productType, FDE_ProductsPageObjects.productTypeCOMPOUNDED)); } if
		 * (getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_ProductType").equalsIgnoreCase("Generic")) {
		 * agClick(FDE_ProductsPageObjects.productChkbox(FDE_ProductsPageObjects.
		 * productType, FDE_ProductsPageObjects.productTypeGeneric)); } if
		 * (getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_ProductType") .equalsIgnoreCase("Biosimilar")) {
		 * agClick(FDE_ProductsPageObjects.productChkbox(FDE_ProductsPageObjects.
		 * productType, FDE_ProductsPageObjects.productTypeBiosimilar)); }
		 * 
		 * agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * inventedNameTxtbox), getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_InventedName"));
		 * agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * scientificNameTxtbox), getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_ScientificName"));
		 * agSetValue(FDE_ProductsPageObjects.additionalDrugInfo_Textarea,
		 * getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_AdditionalDrugInformation"));
		 * agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * trademarkNameTxtbox), getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_TrademarkName"));
		 * agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * strengthNameTxtbox), getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_StrengthName"));
		 * agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * formNameTxtbox), getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_FormName"));
		 * agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * containerNameTxtbox), getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_ContainerName"));
		 * agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * deviceNameTxtbox), getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_DeviceName"));
		 * agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * intendedUseNameTxtbox), getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_IntendedUseName"));
		 * 
		 * // setProductDropDownValue(FDE_ProductsPageObjects.codingClassDrpdwn, //
		 * scenarioName, "Products_ProductInformation_CodingClass"); //
		 * agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.productFlag);
		 * 
		 * agClick(FDE_ProductsPageObjects.checkRadioButton_Value(
		 * FDE_ProductsPageObjects.lackOfEffectRadioBtn,
		 * getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_LackOfEffect")));
		 * agClick(FDE_ProductsPageObjects.checkRadioButton_Value(
		 * FDE_ProductsPageObjects.priorUseRadioBtn, getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_PriorUse")));
		 * agClick(FDE_ProductsPageObjects.checkRadioButton_Value(
		 * FDE_ProductsPageObjects.toleratedRadioBtn, getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_Tolerated")));
		 * 
		 * agSetValue(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * preferredWHODDdecode_Txtfield), getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_PreferredWHODDDecode"));
		 */
		Reports.ExtentReportLog("", Status.INFO,
				"Data entered in Product Information section: Scenario Name::" + scenarioName, false);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Product Information in
	 *             Product tab displayed in Product Tab
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void productInformation_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductCharacterization"),
				FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.productCharacterizationDrpdwn));
		// verify_CompanyProduct(scenarioName);
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_Lookup")
				.equalsIgnoreCase("Yes")) {
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.productDescription_Lookupfield);
			agCheckPropertyValue("title",
					getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"),
					FDE_ProductsPageObjects.productDescription_Lookupfield);
		}
		agJavaScriptExecuctorClick(FDE_ProductsPageObjects.productinfo_label);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.prductNameAsReportedTxtbox),
				scenarioName, "Products_ProductInformation_ProductNameAsReported");
		verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.prefferedProductDescriptionTxtbox),
				scenarioName, "Products_ProductInformation_PreferredProductDescription");
		/*
		 * verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * WHODDcodeTxtbox), scenarioName, "Products_ProductInformation_WHODDCode");
		 * agCheckPropertyText(getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_CountryObtained"),
		 * FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.
		 * countryObtainedDrpdwn));
		 * verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * medicinalProductIdentifierTxtbox), scenarioName,
		 * "Products_ProductInformation_MedicinalProductIdentifierMPID");
		 * verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * MPIDverNumTxtbox), scenarioName,
		 * "Products_ProductInformation_MPIDVersionDateNumber");
		 * verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * PhPIDTxtbox), scenarioName, "Products_ProductInformation_PhPID");
		 * verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * PhPIDverDateNumberTxtbox), scenarioName,
		 * "Products_ProductInformation_PhPIDVersionDateNumber");
		 * verifyData(FDE_ProductsPageObjects.productEmbedTxtbox(FDE_ProductsPageObjects
		 * .cumulativeDose), scenarioName,
		 * "Products_ProductInformation_CumulativeDoseToFirstReaction");
		 * agCheckPropertyText( getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_CumulativeDoseToFirstReaction_Unit"),
		 * FDE_ProductsPageObjects.productEmdedDropdownSelect(FDE_ProductsPageObjects.
		 * cumulativeDose));
		 * verifyData(FDE_ProductsPageObjects.productEmbedTxtbox(FDE_ProductsPageObjects
		 * .gestationPeriod), scenarioName,
		 * "Products_ProductInformation_GestationPeriodAtTimeOfExposure");
		 * agCheckPropertyText( getTestDataCellValue(scenarioName,
		 * "Products_ProductInformation_GestationPeriodAtTimeOfExposure_Unit"),
		 * FDE_ProductsPageObjects.productEmdedDropdownSelect(FDE_ProductsPageObjects.
		 * gestationPeriod));
		 * 
		 * verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.
		 * preferredWHODDdecode_Txtfield), scenarioName,
		 * "Products_ProductInformation_PreferredWHODDDecode");
		 */
		Reports.ExtentReportLog("", Status.INFO,
				"Data verification in Product Information section: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Product Information in
	 *             Product tab displayed in Product Tab
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void productInfoOtherDetails_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_ProductInformation_ActionTakenWithDrug"),
				FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.actionTakenWithDrug));
		verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.inventedNameTxtbox), scenarioName,
				"Products_ProductInformation_InventedName");
		verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.scientificNameTxtbox), scenarioName,
				"Products_ProductInformation_ScientificName");
		verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.trademarkNameTxtbox), scenarioName,
				"Products_ProductInformation_TrademarkName");
		verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.strengthNameTxtbox), scenarioName,
				"Products_ProductInformation_StrengthName");
		verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.formNameTxtbox), scenarioName,
				"Products_ProductInformation_FormName");
		verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.containerNameTxtbox), scenarioName,
				"Products_ProductInformation_ContainerName");
		verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.deviceNameTxtbox), scenarioName,
				"Products_ProductInformation_DeviceName");
		verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.intendedUseNameTxtbox), scenarioName,
				"Products_ProductInformation_IntendedUseName");
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_ProductInformation_CodingClass"),
				FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.codingClassDrpdwn));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductFlag"),
				FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.productFlag));
		verifyData(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.NDCNumber), scenarioName,
				"Products_ProductInformation_NDCNumber");
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_ProductInformation_StudyProductType"),
				FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.studyProductType));
		Reports.ExtentReportLog("", Status.INFO,
				"Data verification in Product Information section: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Product Is company product
	 *             in Product Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_CompanyProduct(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String value = agGetAttribute("class", FDE_ProductsPageObjects.checkRadioButton_Value(
				FDE_ProductsPageObjects.companyProductRadio, getTestDataCellValue(scenarioName, "CompanyProduct")));
		if (value.contains("pi-circle-on")) {
			Reports.ExtentReportLog("Product is Company Product", Status.PASS, "", true);
		} else {
			Reports.ExtentReportLog("Product is not Company Product", Status.FAIL, "", true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Product Is Blinded in
	 *             Product Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_ProductIsBlinded(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		String Data = agGetAttribute("class",
				FDE_ProductsPageObjects.checkRadioButton_Value(FDE_ProductsPageObjects.productBlindedRadio,
						getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductBlinded")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (Data.contains("pi-circle-on")) {
			Reports.ExtentReportLog("Product is Blinded Product", Status.PASS, "", true);
		} else {
			Reports.ExtentReportLog("Product is not Blinded", Status.FAIL, "", true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Product Is Not Blinded in
	 *             Product Tab
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_ProductIsNotBlinded(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		String Data = agGetAttribute("class",
				FDE_ProductsPageObjects.checkRadioButton_Value(FDE_ProductsPageObjects.productBlindedRadio,
						getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductBlinded")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (Data.contains("pi-circle-on")) {
			Reports.ExtentReportLog("Product is Blinded Product", Status.FAIL, "", true);
		} else {
			Reports.ExtentReportLog("Product is not Blinded", Status.PASS, "", true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Blinded link in Product
	 *             Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_Blindedlabel(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (FDE_Study.getData(scenarioName, "StudyProductType").equalsIgnoreCase("Blinded")) {
			agAssertVisible(FDE_ProductsPageObjects.blinded_link);
		} else {
			agAssertNotVisible(FDE_ProductsPageObjects.blinded_link);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Unblinded Button in Product
	 *             Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_UnblindedButton(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (FDE_Study.getData(scenarioName, "CaseCodeBroken").equalsIgnoreCase("Code Broken")) {
			agAssertVisible(FDE_ProductsPageObjects.addUnblindedProduct_Btn);
		} else if (FDE_Study.getData(scenarioName, "CaseCodeBroken").equalsIgnoreCase("Code Not Broken")) {
			agAssertNotVisible(FDE_ProductsPageObjects.addUnblindedProduct_Btn);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify linked blinded product in
	 *             Product Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_BlindedProductLink(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(
				FDE_ProductsPageObjects.product_Link(FDE_Study.getData(scenarioName, "UnblindedProduct")));
		agSetStepExecutionDelay("5000");
		agAssertVisible(FDE_ProductsPageObjects.unBlinded_link);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agAssertVisible(FDE_ProductsPageObjects.blindedProductLink);
		CommonOperations.takeScreenShot();
		agAssertVisible(FDE_ProductsPageObjects.product_Link(FDE_Study.getData(scenarioName, "BlindedProduct_1")));
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to Add Unblinded Button in Product
	 *                Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void add_UnblindedProduct(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_ProductsPageObjects.addUnblindedProduct_Btn);
		if (agIsVisible(FDE_ProductsPageObjects.confirmationPopup) == true) {
			agCheckPropertyText(Product_LookupOperations.getData(scenarioName, "PopupMessage"),
					FDE_ProductsPageObjects.popUp_Message);
			CommonOperations.takeScreenShot();
			agClick(FDE_ProductsPageObjects.popUp_YesBtn);
		}
		agSetStepExecutionDelay("2000");
		agClick(FDE_ProductsPageObjects.productDescriptionLookup);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Product_LookupOperations.searchProductInProductLibrary(scenarioName);
		CommonOperations.takeScreenShot();
	}

	public static void add_UnblindedProduct(String scenarioName, String ALMStepNo) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.almStepNumber(ALMStepNo);
		agClick(FDE_ProductsPageObjects.addUnblindedProduct_Btn);
		agIsVisible(FDE_ProductsPageObjects.confirmationPopup);
		agSetStepExecutionDelay("2000");
		Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
		Reports.ExtentReportLog("", Status.INFO,
				"The Confirmation window is displayed with the message Do you want to add the Unblinded product?.",
				false);

		int ALMStepNoCount = Integer.parseInt(ALMStepNo);
		int ALMStepsAddition = ALMStepNoCount + 1;
		String ALMCount = Integer.toString(ALMStepsAddition);
		CommonOperations.almStepNumber(ALMCount);
		if (agIsVisible(FDE_ProductsPageObjects.confirmationPopup) == true) {
			agCheckPropertyText(Product_LookupOperations.getData(scenarioName, "PopupMessage"),
					FDE_ProductsPageObjects.popUp_Message);
			agClick(FDE_ProductsPageObjects.popUp_YesBtn);
			// Reports.ExtentReportLog("", Status.INFO, "The case is saved. ", true);
		}
		// int ALMStepNoCounts = Integer.parseInt(ALMCount);
		// int ALMStepsAdditions = ALMStepNoCounts + 1;W
		// String ALMCounts = Integer.toString(ALMStepsAdditions);
		// CommonOperations.almStepNumber(ALMCounts);
		agSetStepExecutionDelay("2000");
		// agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.productinfo_label);
		agClick(FDE_ProductsPageObjects.productDescriptionLookup);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Product_LookupOperations.searchProductInProductLibrary(scenarioName);
		agSetStepExecutionDelay("5000");
		CommonOperations.captureScreenShot(true);
		agJavaScriptExecuctorClick(FDE_ProductsPageObjects.indication_Label);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FDE_ProductsPageObjects.indicationTerm_TextField,
				getTestDataCellValue(scenarioName, "Products_Indications_IndicationTerm"));
		agSendKeyStroke(Keys.TAB);
		agSetStepExecutionDelay("3000");
		CommonOperations.captureScreenShot(true);
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to verify basic product data in
	 *                Product Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void studyProductsVerifiaction(String scenarioName) {
		agClick(FDE_ProductsPageObjects.productDescription_Lookupfield);
		agCheckPropertyValue("title", FDE_Study.getData(scenarioName, "BlindedProduct_1"),
				FDE_ProductsPageObjects.productDescription_Lookupfield);
		agCheckPropertyText(FDE_Study.getData(scenarioName, "StudyProductType_1"),
				FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.studyProductType));
		CommonOperations.takeScreenShot();
		FDE_Products.productNavigations("BlindingUnBlinding", "StudyProduct_2");
		agClick(FDE_ProductsPageObjects.productDescription_Lookupfield);
		agCheckPropertyValue("title", FDE_Study.getData(scenarioName, "StudyProduct_2"),
				FDE_ProductsPageObjects.productDescription_Lookupfield);
		agCheckPropertyText(FDE_Study.getData(scenarioName, "StudyProductType_2"),
				FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.studyProductType));
		Reports.ExtentReportLog("", Status.INFO, "Study product verification", true);

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to perform product navigations in
	 *                Product Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void productNavigations(String scenarioName, String colName) {
		agClick(FDE_ProductsPageObjects.product_Navigations(FDE_Study.getData(scenarioName, colName)));
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to verify Product Description in
	 *                Product Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyProductDescription(String scenarioName) {
		agClick(FDE_ProductsPageObjects.productDescription_Lookupfield);
		agCheckPropertyValue("title", Product_LookupOperations.getData(scenarioName, "ProductName"),
				FDE_ProductsPageObjects.productDescription_Lookupfield);
	}

	/**********************************************************************************************************
	 * @Objective:This method is created get data from excel sheet
	 * @InputParameters: Scenario Name, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	/**********************************************************************************************************
	 * @Objective: Set Product Approval information in Products page
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:WajahatUmar S on 28-Aug-2020
	 **********************************************************************************************************/
	public static void setProductApproval(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Multimaplibraries.getTestDataCellLength(scenarioName, "Products_Approval_TradeBrandName");

		for (int j = 1; j <= Constants.testDataChildLength; j++) {
			Constants.testDataChildLoopCount = j;

			if (j > 1) {
			
				agJavaScriptExecuctorClick(FDE_ProductsPageObjects.approvalAddBtn);
				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.approval_Label);

			/*
			 * if (agIsVisible(CaseManagementPageObjects.GridViewCheck("Approval"))) {
			 * agClick(CaseManagementPageObjects.GridViewCheck("Approval"));
			 * agSetValue(FDE_ProductsPageObjects.tradeBrandName_TextField,
			 * getTestDataCellValue(scenarioName, "Products_Approval_TradeBrandName"));
			 * 
			 * if (getTestDataCellValue(scenarioName,
			 * "Products_Approval_MAHAsCoded_Lookup").equalsIgnoreCase("Yes")) {
			 * agClick(FDE_ProductsPageObjects.mAHAscoded_lookUpGridView);
			 * agSetValue(FDE_ProductsPageObjects.accountLookup_AccountNameTxtfield,
			 * getTestDataCellValue(scenarioName,
			 * "Products_Approval_MAHAsCoded_AccountName"));
			 * agClick(FDE_ProductsPageObjects.accountLookup_SearchBtn);
			 * agSetStepExecutionDelay("2000");
			 * agClick(FDE_ProductsPageObjects.accountLookup_selectRadioBtn(
			 * getTestDataCellValue(scenarioName,
			 * "Products_Approval_MAHAsCoded_AccountName")));
			 * agClick(FDE_ProductsPageObjects.accountLookup_OkBtn);
			 * agSetStepExecutionDelay(String.valueOf(Constants.
			 * defaultGlobalStepExecutionDelay)); } if (getTestDataCellValue(scenarioName,
			 * "Products_Approval_MAHAsCoded_Lookup").equalsIgnoreCase("No")) {
			 * agSetValue(FDE_ProductsPageObjects.mAHAsReported_TextField,
			 * getTestDataCellValue(scenarioName, "Products_Approval_MAHAsReported")); } if
			 * (!getTestDataCellValue(scenarioName,
			 * "Products_Approval_ProductType").equalsIgnoreCase("#skip#")) {
			 * agClick(FDE_ProductsPageObjects.Click_ProductFlag_DropDown);
			 * agClick(FDE_ProductsPageObjects
			 * .clickDropDownValue(getTestDataCellValue(scenarioName,
			 * "Products_Approval_ProductType"))); }
			 * 
			 * Reports.ExtentReportLog("", Status.INFO,
			 * "Grid View:Data entered in Product Approval information section: Scenario Name::"
			 * + scenarioName, true);
			 * 
			 * }else
			 */
			
			if (getTestDataCellValue(scenarioName, "Products_Approval_TradeBrandName_Lookup")
					.equalsIgnoreCase("Yes")) {
				
				if(agIsVisible(FDE_ProductsPageObjects.productTradeBarandNameLookup)) {
					
					agClick(FDE_ProductsPageObjects.productTradeBarandNameLookup);
					
					agSetStepExecutionDelay("5000");
					agSetValue(FDE_ProductsPageObjects
									.level1ProductTextbox(Product_LookupPageObjects.prodTradeBrandNameTextbox),
							getTestDataCellValue(scenarioName,
									"Products_Approval_TradeBrandName"));
					
					agClick(FDE_ProductsPageObjects.searchButton);
					agSetStepExecutionDelay("5000");
										
					agClick(FDE_ProductsPageObjects.checkFirstTradeBrandNameLib);
					Reports.ExtentReportLog("", Status.PASS, "As Expected"+
							"<br />"+ "LTN record of "+getTestDataCellValue(scenarioName,
									"Products_ProductInformation_ProductDescription_ProductName")+" is fetched in search results", true);
					agClick(FDE_ProductsPageObjects.prod_TradeBrandNameLibOkButton);
	
				}				
			}
			
			
			else {
			agSetValue(FDE_ProductsPageObjects.tradeBrandName_TextField,
					getTestDataCellValue(scenarioName, "Products_Approval_TradeBrandName"));
			}
			if (!getTestDataCellValue(scenarioName, "Products_Approval_ProductType").equalsIgnoreCase("#skip#")) {
				agClick(FDE_ProductsPageObjects.Click_ProductFlag_DropDown);
				agClick(FDE_ProductsPageObjects
						.clickDropDownValue(getTestDataCellValue(scenarioName, "Products_Approval_ProductType")));
			}

			if (getTestDataCellValue(scenarioName, "Products_Approval_MAHAsCoded_Lookup").equalsIgnoreCase("Yes")) {
				agClick(FDE_ProductsPageObjects.mAHAsCoded_Lookup);
				agSetValue(FDE_ProductsPageObjects.accountLookup_AccountNameTxtfield,
						getTestDataCellValue(scenarioName, "Products_Approval_MAHAsCoded_AccountName"));
				agClick(FDE_ProductsPageObjects.accountLookup_SearchBtn);
				agSetStepExecutionDelay("2000");
				agClick(FDE_ProductsPageObjects.accountLookup_selectRadioBtn(
						getTestDataCellValue(scenarioName, "Products_Approval_MAHAsCoded_AccountName")));
				agClick(FDE_ProductsPageObjects.accountLookup_OkBtn);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			}
			if (getTestDataCellValue(scenarioName, "Products_Approval_MAHAsCoded_Lookup").equalsIgnoreCase("No")) {
				agSetValue(FDE_ProductsPageObjects.mAHAsReported_TextField,
						getTestDataCellValue(scenarioName, "Products_Approval_MAHAsReported"));
			}
			if (!getTestDataCellValue(scenarioName, "Products_Approval_AuthorizationCountry")
					.equalsIgnoreCase("#skip#")) {
				agClick(FDE_ProductsPageObjects.clickAuthorizationCountry_Dropdown);
				agClick(FDE_ProductsPageObjects.clickDropDownValue(
						getTestDataCellValue(scenarioName, "Products_Approval_AuthorizationCountry")));
			}
			if (!getTestDataCellValue(scenarioName, "Products_Approval_ApprovalType").equalsIgnoreCase("#skip#")) {
				agClick(FDE_ProductsPageObjects.clickApprovalType_Dropdown);
				agClick(FDE_ProductsPageObjects
						.clickDropDownValue(getTestDataCellValue(scenarioName, "Products_Approval_ApprovalType")));
			}
			agSetValue(FDE_ProductsPageObjects.AuthorizationNumber,
					getTestDataCellValue(scenarioName, "Products_Approval_AuthorizationNumber"));
			agSetValue(FDE_ProductsPageObjects.IdentificationNo,
					getTestDataCellValue(scenarioName, "Products_Approval_IdentificationNo"));

			 if (!getTestDataCellValue(scenarioName,
			 "Products_Approval_ClassOfDevice").equalsIgnoreCase("#skip#")) {
			 agSetStepExecutionDelay("2000");
			// CommonOperations.setListDropDownValue(FDE_ProductsPageObjects.ClickClassofDevice_dropDown,
			// getTestDataCellValue(scenarioName, "Products_Approval_ClassOfDevice"));
			 agJavaScriptExecuctorClick(FDE_ProductsPageObjects.ClickClassofDevice_dropDown);
			 agSetStepExecutionDelay("2000");
			 agJavaScriptExecuctorClick(FDE_ProductsPageObjects
			 .clickDropDownValue(getTestDataCellValue(scenarioName,
			 "Products_Approval_ClassOfDevice")));
			 }
			 
			 if (!getTestDataCellValue(scenarioName,
					 "Products_Approval_HealthCanadaIDNumber").equalsIgnoreCase("#skip#")) {
			 agSetValue(FDE_ProductsPageObjects.HCID_TextBox,
						getTestDataCellValue(scenarioName, "Products_Approval_HealthCanadaIDNumber"));
			 }
			agSetStepExecutionDelay("3000");
			/*
			 * agClick(CommonPageObjects.checkBoxUnder(FDE_ProductsPageObjects.Implantable))
			 * ;
			 * agClick(CommonPageObjects.checkBoxLeftOf(FDE_ProductsPageObjects.ActiveDevice
			 * )); agClick(CommonPageObjects.checkBoxLeftOf(FDE_ProductsPageObjects.
			 * Intendedtomedicinalproduct));
			 * agClick(CommonPageObjects.checkBoxLeftOf(FDE_ProductsPageObjects.
			 * Sterileconditions));
			 * agClick(CommonPageObjects.checkBoxLeftOf(FDE_ProductsPageObjects.
			 * Measuringfunction));
			 * agClick(CommonPageObjects.checkBoxLeftOf(FDE_ProductsPageObjects.
			 * Reusablesurgicalinstruments));
			 * 
			 * agClick(FDE_ProductsPageObjects.MDRSoftwareChkbox);
			 * agClick(CommonPageObjects.checkBoxLeftOf(FDE_ProductsPageObjects.
			 * Procedurepacks));
			 * agClick(CommonPageObjects.checkBoxLeftOf(FDE_ProductsPageObjects.Custommade))
			 * ; agClick(CommonPageObjects.checkBoxLeftOf(FDE_ProductsPageObjects.
			 * Nonmedicalpurpose));
			 * agClick(CommonPageObjects.checkBoxLeftOf(FDE_ProductsPageObjects.Systems));
			 * agClick(CommonPageObjects.checkBoxLeftOf(FDE_ProductsPageObjects.Selftesting)
			 * ); agClick(CommonPageObjects.checkBoxLeftOf(FDE_ProductsPageObjects.
			 * NearPatienttesting));
			 * agClick(CommonPageObjects.checkBoxLeftOf(FDE_ProductsPageObjects.
			 * Professionaltesting));
			 * agClick(CommonPageObjects.checkBoxLeftOf(FDE_ProductsPageObjects.
			 * CompanionDiagnostic));
			 * agClick(CommonPageObjects.checkBoxLeftOf(FDE_ProductsPageObjects.Reagent));
			 * agClick(FDE_ProductsPageObjects.IVDRSoftwareChkbox);			 * agClick(CommonPageObjects.checkBoxLeftOf(FDE_ProductsPageObjects.Instrument))
			 * ; agClick(CommonPageObjects.checkBoxUnder(FDE_ProductsPageObjects.
			 * Devicemarketedbefore));
			 */
			agSetValue(FDE_ProductsPageObjects.NotifiedBodyNo,
					getTestDataCellValue(scenarioName, "Products_Approval_NotifiedBodyCertificateNo"));
			// if (!getTestDataCellValue(scenarioName,
			// "Products_Approval_DeviceCommercialDate")
			// .equalsIgnoreCase("#skip#")) {
			// agClick(FDE_ProductsPageObjects.Click_DeviceCommericalDate_dropdown);
			// agClick(FDE_ProductsPageObjects.clickDropDownValue(
			// getTestDataCellValue(scenarioName,
			// "Products_Approval_DeviceCommercialDate")));
			// }
			agSetValue(FDE_ProductsPageObjects.Years, getTestDataCellValue(scenarioName, "Products_Approval_Years"));
			agSetValue(FDE_ProductsPageObjects.Months, getTestDataCellValue(scenarioName, "Products_Approval_Months"));
			Reports.ExtentReportLog("", Status.INFO,
					"Form View:Data entered in Product Approval information section: Scenario Name::" + scenarioName,
					false);

		}
	}

	/**********************************************************************************************************
	 * @Objective:To Verify Product Approval information in Products page
	 * @InputParameters: Scenario Name, columnName
	 * @OutputParameters:
	 * @author: Avinash k
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:WajahatUmar S on 28-Aug-2020
	 **********************************************************************************************************/
	public static void verifyProductApproval(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Multimaplibraries.getTestDataCellLength(scenarioName, "Products_Approval_TradeBrandName");

		for (int j = 1; j <= Constants.testDataChildLength; j++) {
			Constants.testDataChildLoopCount = j;

			if (j >= 1) {

				agJavaScriptExecuctorClick(
						FDE_ProductsPageObjects.click_MultipleApproval.replace("#1", "#" + String.valueOf(j)));

				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.approval_Label);

			/*
			 * if (agIsVisible(CaseManagementPageObjects.FormViewCheck("Approval"))) {
			 * verifyData(FDE_ProductsPageObjects.tradeBrandName_TextField, scenarioName,
			 * "Products_Approval_TradeBrandName");
			 * agCheckPropertyText(getTestDataCellValue(scenarioName,
			 * "Products_Approval_ProductType"),
			 * FDE_ProductsPageObjects.Click_ProductFlag_DropDown); if
			 * (getTestDataCellValue(scenarioName,
			 * "Products_Approval_MAHAsCoded_Lookup").equalsIgnoreCase("Yes")) {
			 * agCheckPropertyValue("title", getTestDataCellValue(scenarioName,
			 * "Products_Approval_MAHAsCoded_AccountName"),
			 * FDE_ProductsPageObjects.mAHAsCoded_Getvalue); }
			 * verifyData(FDE_ProductsPageObjects.mAHAsReported_TextField, scenarioName,
			 * "Products_Approval_MAHAsReported");
			 * 
			 * Reports.ExtentReportLog("", Status.INFO,
			 * "Grid View:Data verification in Product Approval information section: Scenario Name::"
			 * + scenarioName, true); } else if
			 * (agIsVisible(CaseManagementPageObjects.GridViewCheck("Approval"))) {
			 */
			verifyData(FDE_ProductsPageObjects.tradeBrandName_TextField, scenarioName,
					"Products_Approval_TradeBrandName");
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Approval_ProductType"),
					FDE_ProductsPageObjects.Click_ProductFlag_DropDown);
			if (!getTestDataCellValue(scenarioName, "Products_Approval_MAHAsCoded_Lookup").equalsIgnoreCase("#skip#")) {
				agClick(FDE_ProductsPageObjects.mAHAsCoded_Getvalue);
				agCheckPropertyValue("title",
						getTestDataCellValue(scenarioName, "Products_Approval_MAHAsCoded_AccountName"),
						FDE_ProductsPageObjects.mAHAsCoded_Getvalue);
			}
			verifyData(FDE_ProductsPageObjects.mAHAsReported_TextField, scenarioName,
					"Products_Approval_MAHAsReported");
			verifyData(FDE_ProductsPageObjects.approvalNo_TextField, scenarioName, "Products_Approval_ApprovalNo");
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Approval_ApprovalType"),
					FDE_ProductsPageObjects.clickApprovalType_Dropdown);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Approval_AuthorizationCountry"),
					FDE_ProductsPageObjects.clickAuthorizationCountry_Dropdown);
			verifyData(FDE_ProductsPageObjects.AuthorizationNumber, scenarioName,
					"Products_Approval_AuthorizationNumber");
			verifyData(FDE_ProductsPageObjects.IdentificationNo, scenarioName, "Products_Approval_IdentificationNo");
			if (!getTestDataCellValue(scenarioName, "Products_Approval_ClassOfDevice").equalsIgnoreCase("#skip#")) {
				agCheckPropertyValue("title", getTestDataCellValue(scenarioName, "Products_Approval_ClassOfDevice"),
						FDE_ProductsPageObjects.ClickClassofDevice_dropDown);
			}
			verifyData(FDE_ProductsPageObjects.NotifiedBodyNo, scenarioName,
					"Products_Approval_NotifiedBodyCertificateNo");
			if (!getTestDataCellValue(scenarioName, "Products_Approval_DeviceCommercialDate")
					.equalsIgnoreCase("#skip#")) {
				agCheckPropertyValue("title",
						getTestDataCellValue(scenarioName, "Products_Approval_DeviceCommercialDate"),
						FDE_ProductsPageObjects.Click_DeviceCommericalDate_dropdown);
			}
			verifyData(FDE_ProductsPageObjects.Years, scenarioName, "Products_Approval_Years");
			verifyData(FDE_ProductsPageObjects.Months, scenarioName, "Products_Approval_Months");
			CommonOperations.verifyCheckBoxUnder(FDE_ProductsPageObjects.Implantable, "Yes");
			CommonOperations.verifyCheckBoxLeftOf(FDE_ProductsPageObjects.ActiveDevice, "Yes");
			CommonOperations.verifyCheckBoxLeftOf(FDE_ProductsPageObjects.Intendedtomedicinalproduct, "Yes");
			CommonOperations.verifyCheckBoxLeftOf(FDE_ProductsPageObjects.Sterileconditions, "Yes");
			CommonOperations.verifyCheckBoxLeftOf(FDE_ProductsPageObjects.Measuringfunction, "Yes");
			CommonOperations.verifyCheckBoxLeftOf(FDE_ProductsPageObjects.Reusablesurgicalinstruments, "Yes");
			CommonOperations.verifyCheckBoxLeftOf(FDE_ProductsPageObjects.Procedurepacks, "Yes");
			CommonOperations.verifyCheckBoxLeftOf(FDE_ProductsPageObjects.Custommade, "Yes");

			CommonOperations.verifyCheckBoxLeftOf(FDE_ProductsPageObjects.Nonmedicalpurpose, "Yes");
			CommonOperations.verifyCheckBoxLeftOf(FDE_ProductsPageObjects.Systems, "Yes");

			CommonOperations.verifyCheckBoxLeftOf(FDE_ProductsPageObjects.Selftesting, "Yes");
			CommonOperations.verifyCheckBoxLeftOf(FDE_ProductsPageObjects.NearPatienttesting, "Yes");

			CommonOperations.verifyCheckBoxLeftOf(FDE_ProductsPageObjects.Professionaltesting, "Yes");
			CommonOperations.verifyCheckBoxLeftOf(FDE_ProductsPageObjects.CompanionDiagnostic, "Yes");
			CommonOperations.verifyCheckBoxLeftOf(FDE_ProductsPageObjects.Reagent, "Yes");
			CommonOperations.verifyCheckBoxLeftOf(FDE_ProductsPageObjects.Instrument, "Yes");
			CommonOperations.verifyCheckBoxUnder(FDE_ProductsPageObjects.Devicemarketedbefore, "Yes");
			Reports.ExtentReportLog("", Status.INFO,
					"Form View:Data verification in Product Approval information section: Scenario Name::"
							+ scenarioName,
					true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: Set Product Ingredients in Products page
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setIngredients(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Multimaplibraries.getTestDataCellLength(scenarioName, "Products_Ingredients_ActiveSubstance");

		for (int j = 1; j <= Constants.testDataChildLength; j++) {
			Constants.testDataChildLoopCount = j;

			if (j > 1) {
				
				agJavaScriptExecuctorClick(FDE_ProductsPageObjects.ingredientsAddBtn);
				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.ingrideints_Label);
			agSetValue(FDE_ProductsPageObjects.activeSubstance_TextField,
					getTestDataCellValue(scenarioName, "Products_Ingredients_ActiveSubstance"));
			if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
				CommonOperations.captureScreenShot(true);
			}
			agSetValue(FDE_ProductsPageObjects.substanceTermIDVerDateNum_TextField,
					getTestDataCellValue(scenarioName, "Products_Ingredients_SubstanceTermIDVerDateNum"));
			agSetValue(FDE_ProductsPageObjects.substanceSpecifiedSubstanceTermID_TextField,
					getTestDataCellValue(scenarioName, "Products_Ingredients_SubstanceSpecifiedSubstanceTermID"));
			agSetValue(FDE_ProductsPageObjects.strengthNumber_TextField,
					getTestDataCellValue(scenarioName, "Products_Ingredients_StrengthNumber"));
			if (!getTestDataCellValue(scenarioName, "Products_Ingredients_StrengthNumber_Unit")
					.equalsIgnoreCase("#skip#")) {
				agClick(FDE_ProductsPageObjects.clickStrengthNumberunit_Dropdown);
				agClick(FDE_ProductsPageObjects.clickDropDownValue(
						getTestDataCellValue(scenarioName, "Products_Ingredients_StrengthNumber_Unit")));
				CommonOperations.captureScreenShot(true);
			}
			Reports.ExtentReportLog("", Status.INFO,
					"Data entered in Product Ingredients section: Scenario Name::" + scenarioName, false);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verify Product Ingredients in Products page
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyIngredients(String scenarioName) {
		Multimaplibraries.getTestDataCellLength(scenarioName, "Products_Ingredients_ActiveSubstance");

		for (int j = 1; j <= Constants.testDataChildLength; j++) {
			Constants.testDataChildLoopCount = j;

			if (j >= 1) {

				agJavaScriptExecuctorClick(
						FDE_ProductsPageObjects.click_Multipleingredients.replace("#1", "#" + String.valueOf(j)));

				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.ingrideints_Label);
			verifyData(FDE_ProductsPageObjects.activeSubstance_TextField, scenarioName,
					"Products_Ingredients_ActiveSubstance");
			verifyData(FDE_ProductsPageObjects.substanceTermIDVerDateNum_TextField, scenarioName,
					"Products_Ingredients_SubstanceTermIDVerDateNum");
			verifyData(FDE_ProductsPageObjects.substanceSpecifiedSubstanceTermID_TextField, scenarioName,
					"Products_Ingredients_SubstanceSpecifiedSubstanceTermID");
			verifyData(FDE_ProductsPageObjects.strengthNumber_TextField, scenarioName,
					"Products_Ingredients_StrengthNumber");
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Ingredients_StrengthNumber_Unit"),
					FDE_ProductsPageObjects.clickStrengthNumberunit_Dropdown);
			Reports.ExtentReportLog("", Status.INFO,
					"Data verification in Product Ingredients section: Scenario Name::" + scenarioName, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Set Product Indication(s) in Products page
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setIndication(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Multimaplibraries.getTestDataCellLength(scenarioName, "Products_Indications_IndicationTerm");

		for (int j = 1; j <= Constants.testDataChildLength; j++) {
			Constants.testDataChildLoopCount = j;

			if (j > 1) {
				agClick(FDE_ProductsPageObjects.indicationAddBtn);
				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.indication_Label);
			agSetValue(FDE_ProductsPageObjects.indicationTerm_TextField.replace(":0", ":" + String.valueOf(j - 1)),
					getTestDataCellValue(scenarioName, "Products_Indications_IndicationTerm"));
			agSendKeyStroke(Keys.TAB);
			if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
				CommonOperations.captureScreenShot(true);
			}
			if (getTestDataCellValue(scenarioName, "Products_Indications_IndicationMedDRALLTCode_Lookup")
					.equalsIgnoreCase("Yes")) {
				agClick(FDE_ProductsPageObjects.indicationMedDRALLTCode_Lookup);
				if (agIsVisible(FDE_MedraLookUpPageObjects.MedraLanguagePopUpClick) == true) {
					agClick(FDE_MedraLookUpPageObjects.MedraLanguagePopUpClick);
					agClick(FDE_MedraLookUpPageObjects.MeraLanguageDropdownValue);
				}

				agSetValue(FDE_ParentPageObjects.dictionaryCodingBrowser_SearchTxtfield,
						getTestDataCellValue(scenarioName, "Products_Indications_IndicationMedDRALLTCode_SearchTerm"));
				agClick(FDE_ParentPageObjects.dictionaryCodingBrowser_SearchBtn);
				agSetStepExecutionDelay("2000");
				agClick(FDE_ParentPageObjects.dictionaryCodingBrowser_OkBtn);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			}
			agSetStepExecutionDelay("5000");
			CommonOperations.captureScreenShot(true);
			Reports.ExtentReportLog("", Status.INFO,
					"Data entered in Product Indication section: Scenario Name::" + scenarioName, false);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verify Product Indication(s) in Products page
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyIndication(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Multimaplibraries.getTestDataCellLength(scenarioName, "Products_Indications_IndicationTerm");

		for (int j = 1; j <= Constants.testDataChildLength; j++) {
			Constants.testDataChildLoopCount = j;
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.indication_Label);
			agClick(FDE_ProductsPageObjects.indicationMedDRALLTCode_Getvalue.replace(":0",
					":" + String.valueOf(j - 1)));
			verifyData(FDE_ProductsPageObjects.indicationTerm_TextField.replace(":0", ":" + String.valueOf(j - 1)),
					scenarioName, "Products_Indications_IndicationTerm");
			verifyData(
					FDE_ProductsPageObjects.indicationMedDRALLTCode_Getvalue.replace(":0", ":" + String.valueOf(j - 1)),
					scenarioName, "Products_Indications_IndicationMedDRALLTCode");
			verifyData(FDE_ProductsPageObjects.indicationsMedDRAPTCode_TextField.replace(":0",
					":" + String.valueOf(j - 1)), scenarioName, "Products_Indications_IndicationsMedDRAPTCode");

			Reports.ExtentReportLog("", Status.INFO,
					"Data verification in Product Indication section: Scenario Name::" + scenarioName, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Set Additional Info Code in Products page
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setAdditionalInfoCode(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Multimaplibraries.getTestDataCellLength(scenarioName, "Products_AdditionalInfoCode_AdditionalInfoCode");

		for (int j = 1; j <= Constants.testDataChildLength; j++) {
			Constants.testDataChildLoopCount = j;

			if (j > 1) {
				agClick(FDE_ProductsPageObjects.additionalInfoAddBtn);
				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			if (!getTestDataCellValue(scenarioName, "Products_AdditionalInfoCode_AdditionalInfoCode")
					.equalsIgnoreCase("#skip#")) {
				agJavaScriptExecuctorClick(FDE_ProductsPageObjects.additionalInfoCode_Label);
				agClick(FDE_ProductsPageObjects.clickAdditionalInfoCodeDrpdwn.replace("_focus:0",
						"_focus:" + String.valueOf(j - 1)));
				agClick(FDE_ProductsPageObjects.clickDropDownValue(
						getTestDataCellValue(scenarioName, "Products_AdditionalInfoCode_AdditionalInfoCode")));
				Reports.ExtentReportLog("", Status.INFO,
						"Data entered in Product Additional Info Code section: Scenario Name::" + scenarioName, true);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verify Additional Info Code in Products page
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyAdditionalInfoCode(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		Multimaplibraries.getTestDataCellLength(scenarioName, "Products_AdditionalInfoCode_AdditionalInfoCode");

		for (int j = 1; j <= Constants.testDataChildLength; j++) {
			Constants.testDataChildLoopCount = j;
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.additionalInfoCode_Label);
//			agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_AdditionalInfoCode_AdditionalInfoCode"),
//					FDE_ProductsPageObjects.clickAdditionalInfoCodeDrpdwn.replace("_focus:0",
//							"_focus:" + String.valueOf(j - 1)));
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_AdditionalInfoCode_AdditionalInfoCode"),
					FDE_ProductsPageObjects.clickAdditionalInfoCodeDrpdwn);
			Reports.ExtentReportLog("", Status.INFO,
					"Data verification in Product Additional Info Code section: Scenario Name::" + scenarioName, true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: Set Product Therapies data in product page of FDE
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Avinash K
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setTherapies(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Multimaplibraries.getTestDataCellLength(scenarioName, "Products_Therapies_TherapyStartDate");

		for (int j = 1; j <= Constants.testDataChildLength; j++) {
			Constants.testDataChildLoopCount = j;

			if (j > 1) {
				agJavaScriptExecuctorClick(FDE_ProductsPageObjects.therapyAddBtn);
				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.therapis_Label);
			agSetStepExecutionDelay("3000");
			agSetValue(FDE_ProductsPageObjects.unitDose_TextField,
					getTestDataCellValue(scenarioName, "Products_Therapies_UnitDose"));
			setProductEmbedDropDownValue(FDE_ProductsPageObjects.unitDose_dropdown, scenarioName,
					"Products_Therapies_UnitDoseUnit");
			agSetValue(FDE_ProductsPageObjects.formStrength_TextField,
					getTestDataCellValue(scenarioName, "Products_Therapies_FormStrength"));
			setProductEmbedDropDownValue(FDE_ProductsPageObjects.formStrength_dropdown, scenarioName,
					"Products_Therapies_FormStrengthUnit");
			agSetValue(FDE_ProductsPageObjects.frequency_TextField,
					getTestDataCellValue(scenarioName, "Products_Therapies_Frequency"));
			agSetValue(FDE_ProductsPageObjects.frequencyTime_TextField,
					getTestDataCellValue(scenarioName, "Products_Therapies_FrequencyTime"));
			setProductEmbedDropDownValue(FDE_ProductsPageObjects.frequencyTime_dropdown, scenarioName,
					"Products_Therapies_FrequencyTimeUnit");
			if (getTestDataCellValue(scenarioName, "Products_Therapies_DailyDose_Manual").equalsIgnoreCase("Check")) {
				agSetStepExecutionDelay("3000");
				CommonOperations.clickManualCheckBox(FDE_ProductsPageObjects.dailyDose_dropdown,
						getTestDataCellValue(scenarioName, "Products_Therapies_DailyDose_Manual"));
				agSetValue(FDE_ProductsPageObjects.dailyDose_TextField,
						getTestDataCellValue(scenarioName, "Products_Therapies_DailyDose"));
				setProductEmbedDropDownValue(FDE_ProductsPageObjects.dailyDose_dropdown, scenarioName,
						"Products_Therapies_DailyDoseUnit");
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			}
			// if (getTestDataCellValue(scenarioName,
			// "Products_Therapies_TotalDose_Manual").equalsIgnoreCase("Check")) {
			// CommonOperations.clickManualCheckBox(FDE_ProductsPageObjects.totaldose_Dropdown,
			// getTestDataCellValue(scenarioName, "Products_Therapies_TotalDose_Manual"));
			// agSetValue(FDE_ProductsPageObjects.totaldose_TextField,
			// getTestDataCellValue(scenarioName, "Products_Therapies_TotalDose"));
			// setProductEmbedDropDownValue(FDE_ProductsPageObjects.totaldose_Dropdown,
			// scenarioName, "Products_Therapies_TotalDoseUnit");
			// code commented because both are disable in application
			// }

			if (getTestDataCellValue(scenarioName, "CustomDateFlag").equalsIgnoreCase("YES")) {
				agSetValue(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate),
						getTestDataCellValue(scenarioName, "Products_Therapies_TherapyStartDate"));
				agSetValue(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyEndDate),
						getTestDataCellValue(scenarioName, "Products_Therapies_TherapyEndDate"));
				CommonOperations.captureScreenShot(true);
			} else {
				agSetValue(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate),
						CommonOperations.returnDateTime(
								getTestDataCellValue(scenarioName, "Products_Therapies_TherapyStartDate")));
				agSetValue(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyEndDate),
						CommonOperations.returnDateTime(
								getTestDataCellValue(scenarioName, "Products_Therapies_TherapyEndDate")));
			}
			if (getTestDataCellValue(scenarioName, "Products_Therapies_DurationOfDrugAdministration_Manual")
					.equalsIgnoreCase("Check")) {
				CommonOperations.clickManualCheckBox(FDE_ProductsPageObjects.durationOfDrugAdministration_Dropdown,
						getTestDataCellValue(scenarioName, "Products_Therapies_DurationOfDrugAdministration_Manual"));
				agSetValue(FDE_ProductsPageObjects.durationOfDrugAdministration_TextField,
						getTestDataCellValue(scenarioName, "Products_Therapies_DurationOfDrugAdministration"));
				setProductEmbedDropDownValue(FDE_ProductsPageObjects.durationOfDrugAdministration_Dropdown,
						scenarioName, "Products_Therapies_DurationOfDrugAdministrationUnit");
			}
			agSetStepExecutionDelay("5000");
			agSetValue(FDE_ProductsPageObjects.lotNumber_TextField,
					getTestDataCellValue(scenarioName, "Products_Therapies_LotNumber"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			agSetValue(FDE_ProductsPageObjects.lotExpirationDate_DateField, CommonOperations
					.returnDateTime(getTestDataCellValue(scenarioName, "Products_Therapies_LotExpirationDate")));

			setProductDropDownValue(FDE_ProductsPageObjects.formOfAdmin_Dropdown, scenarioName,
					"Products_Therapies_FormOfAdmin");
			if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
				CommonOperations.captureScreenShot(true);
			}
			agSetValue(FDE_ProductsPageObjects.PharmaceuticalTermID_TxtField,
					getTestDataCellValue(scenarioName, "Products_Therapies_PharmaceuticalDoseFormTermID"));
			setProductDropDownValue(FDE_ProductsPageObjects.routeOfAdmin_Dropdown, scenarioName,
					"Products_Therapies_RouteOfAdmin");

			status = agIsVisible(FDE_ProductsPageObjects.routeOfAdminValue);
			if (status) {
				CommonOperations.captureScreenShot(true);
			}

			if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
				agSetStepExecutionDelay("10000");
				CommonOperations.captureScreenShot(true);
			}
			agSetValue(FDE_ProductsPageObjects.routeOfAdministrationTermIDVerDateNum_TextField,
					getTestDataCellValue(scenarioName, "Products_Therapies_RouteOfAdministrationTermIDVerDateNum"));
			agSetValue(FDE_ProductsPageObjects.pharmaceuticalDoseFormTermIDVerDateNum_TextField,
					getTestDataCellValue(scenarioName, "Products_Therapies_PharmaceuticalDoseFormTermIDVerDateNum"));
			// setProductDropDownValue(FDE_ProductsPageObjects.routeofAdministrationTermID_Dropdown,
			// scenarioName, "Products_Therapies_RouteOfAdministrationTermID");

			// if (!getTestDataCellValue(scenarioName,
			// "Products_Therapies_ParentsRouteOfAdmin").equalsIgnoreCase("#skip#")) {
			// agClick(FDE_ProductsPageObjects.clickparentsRouteOfAdmin);
			// agClick(FDE_ProductsPageObjects.clickDropDownValue(getTestDataCellValue(scenarioName,
			// "Products_Therapies_ParentsRouteOfAdmin")));
			// }
			agSetValue(FDE_ProductsPageObjects.parentRouteOfAdministrationTermIDVerDateNum_TextField,
					getTestDataCellValue(scenarioName,
							"Products_Therapies_ParentRouteOfAdministrationTermIDVerDateNum"));
			setProductDropDownValue(FDE_ProductsPageObjects.parentRouteOfAdministrationTermID_Dropdown, scenarioName,
					"Products_Therapies_ParentRouteOfAdministrationTermID");
			agSetValue(FDE_ProductsPageObjects.dosageText_TextField,
					getTestDataCellValue(scenarioName, "Products_Therapies_DosageText"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.INFO,
					"Data entered in Product Therapies section: Scenario Name::" + scenarioName, false);
		}
	}

	/**********************************************************************************************************
	 * @Objective:To Verify therapy details
	 * @InputParameters: Scenario Name, columnName
	 * @OutputParameters:
	 * @author: Avinash k
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyTherapies(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		Multimaplibraries.getTestDataCellLength(scenarioName, "Products_Therapies_TherapyStartDate");

		for (int j = 1; j <= Constants.testDataChildLength; j++) {
			Constants.testDataChildLoopCount = j;

			if (j >= 1) {

				agJavaScriptExecuctorClick(
						FDE_ProductsPageObjects.click_MultipleTherapies.replace("#1", "#" + String.valueOf(j)));

				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.therapis_Label);
			verifyData(FDE_ProductsPageObjects.unitDose_TextField, scenarioName, "Products_Therapies_UnitDose");
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Therapies_UnitDoseUnit"),
					FDE_ProductsPageObjects.productEmdedDropdownSelect((FDE_ProductsPageObjects.unitDose_dropdown)));
			verifyData(FDE_ProductsPageObjects.formStrength_TextField, scenarioName, "Products_Therapies_FormStrength");
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Therapies_FormStrengthUnit"),
					FDE_ProductsPageObjects
							.productEmdedDropdownSelect((FDE_ProductsPageObjects.formStrength_dropdown)));
			verifyData(FDE_ProductsPageObjects.frequency_TextField, scenarioName, "Products_Therapies_Frequency");
			verifyData(FDE_ProductsPageObjects.frequencyTime_TextField, scenarioName,
					"Products_Therapies_FrequencyTime");
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Therapies_FrequencyTimeUnit"),
					FDE_ProductsPageObjects
							.productEmdedDropdownSelect((FDE_ProductsPageObjects.frequencyTime_dropdown)));
			if (getTestDataCellValue(scenarioName, "Products_Therapies_DailyDose_Manual").equalsIgnoreCase("Check")) {
				verifyData(FDE_ProductsPageObjects.dailyDose_TextField, scenarioName, "Products_Therapies_DailyDose");
				agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Therapies_DailyDoseUnit"),
						FDE_ProductsPageObjects
								.productEmdedDropdownSelect((FDE_ProductsPageObjects.dailyDose_dropdown)));
			}

			agClick(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate));
			agCheckPropertyValue("title",
					CommonOperations
							.returnDateTime(getTestDataCellValue(scenarioName, "Products_Therapies_TherapyStartDate")),
					FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate));
			agClick(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyEndDate));
			agCheckPropertyValue("title",
					CommonOperations
							.returnDateTime(getTestDataCellValue(scenarioName, "Products_Therapies_TherapyEndDate")),
					FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyEndDate));
			if (getTestDataCellValue(scenarioName, "Products_Therapies_DurationOfDrugAdministration_Manual")
					.equalsIgnoreCase("Check")) {
				verifyData(FDE_ProductsPageObjects.durationOfDrugAdministration_TextField, scenarioName,
						"Products_Therapies_DurationOfDrugAdministration");
				agCheckPropertyText(
						getTestDataCellValue(scenarioName, "Products_Therapies_DurationOfDrugAdministrationUnit"),
						FDE_ProductsPageObjects.productEmdedDropdownSelect(
								(FDE_ProductsPageObjects.durationOfDrugAdministration_Dropdown)));

			}
			verifyData(FDE_ProductsPageObjects.lotNumber_TextField, scenarioName, "Products_Therapies_LotNumber");

			agClick(FDE_ProductsPageObjects.lotExpirationDate_DateField);
			agCheckPropertyValue("title",
					CommonOperations
							.returnDateTime(getTestDataCellValue(scenarioName, "Products_Therapies_LotExpirationDate")),
					FDE_ProductsPageObjects.lotExpirationDate_DateField);

			agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Therapies_FormOfAdmin"),
					FDE_ProductsPageObjects.productDropdownSelect((FDE_ProductsPageObjects.formOfAdmin_Dropdown)));
			verifyData(FDE_ProductsPageObjects.PharmaceuticalTermID_TxtField, scenarioName,
					"Products_Therapies_PharmaceuticalDoseFormTermID");
			agCheckPropertyText((getTestDataCellValue(scenarioName, "Products_Therapies_RouteOfAdmin")).trim(),
					FDE_ProductsPageObjects.productDropdownSelect((FDE_ProductsPageObjects.routeOfAdmin_Dropdown)));

			verifyData(FDE_ProductsPageObjects.routeOfAdministrationTermIDVerDateNum_TextField, scenarioName,
					"Products_Therapies_RouteOfAdministrationTermIDVerDateNum");
			verifyData(FDE_ProductsPageObjects.pharmaceuticalDoseFormTermIDVerDateNum_TextField, scenarioName,
					"Products_Therapies_PharmaceuticalDoseFormTermIDVerDateNum");
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Therapies_RouteOfAdministrationTermID"),
					FDE_ProductsPageObjects
							.productDropdownSelect((FDE_ProductsPageObjects.routeofAdministrationTermID_Dropdown)));
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Therapies_ParentsRouteOfAdmin"),
					FDE_ProductsPageObjects.clickparentsRouteOfAdmin);
			verifyData(FDE_ProductsPageObjects.parentRouteOfAdministrationTermIDVerDateNum_TextField, scenarioName,
					"Products_Therapies_ParentRouteOfAdministrationTermIDVerDateNum");
			agCheckPropertyText(
					(getTestDataCellValue(scenarioName, "Products_Therapies_ParentRouteOfAdministrationTermID")).trim(),
					FDE_ProductsPageObjects.productDropdownSelect(
							(FDE_ProductsPageObjects.parentRouteOfAdministrationTermID_Dropdown)));
			if (getTestDataCellValue(scenarioName, "Products_Therapies_TotalDose_Manual").equalsIgnoreCase("Check")) {
				verifyData(FDE_ProductsPageObjects.totaldose_TextField, scenarioName, "Products_Therapies_TotalDose");
				agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Therapies_TotalDoseUnit"),
						FDE_ProductsPageObjects
								.productEmdedDropdownSelect((FDE_ProductsPageObjects.totaldose_Dropdown)));
			}

			Reports.ExtentReportLog("", Status.INFO,
					"Data verification in Product Therapies section: Scenario Name::" + scenarioName, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: To set Product Device Details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 2-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDeviceDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_ProductsPageObjects.device_FullForm);
		agSetStepExecutionDelay("2000");
		agSetValue(FDE_ProductsPageObjects.deviceComponentNameFreeText_TextField,
				getTestDataCellValue(scenarioName, "Products_Device_DeviceComponentNameFreeText"));
		agSetValue(FDE_ProductsPageObjects.deviceComponentTermIDVersionDateNumber_TextField,
				getTestDataCellValue(scenarioName, "Products_Device_DeviceComponentTermIDVersionDateNumber"));
		agSetValue(FDE_ProductsPageObjects.deviceComponentTermID_TextField,
				getTestDataCellValue(scenarioName, "Products_Device_DeviceComponentTermID"));
		agSetValue(FDE_ProductsPageObjects.commonDeviceName_TextField,
				getTestDataCellValue(scenarioName, "Products_Device_CommonDeviceName"));
		agSetValue(FDE_ProductsPageObjects.brandName_TextField,
				getTestDataCellValue(scenarioName, "Products_Device_BrandName"));
		agSetValue(FDE_ProductsPageObjects.productCode_TextField,
				getTestDataCellValue(scenarioName, "Products_Device_ProductCode"));
		agSetValue(FDE_ProductsPageObjects.UDI_TextField, getTestDataCellValue(scenarioName, "Products_Device_UDI"));
		agSetValue(FDE_ProductsPageObjects.expirationDate_TextField,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Products_Device_ExpirationDate")));
		agSetValue(FDE_ProductsPageObjects.modelNumber_TextField,
				getTestDataCellValue(scenarioName, "Products_Device_ModelNumber"));
		agSetValue(FDE_ProductsPageObjects.catalogNumber_TextField,
				getTestDataCellValue(scenarioName, "Products_Device_CatalogNumber"));
		agSetValue(FDE_ProductsPageObjects.serialNumber_TextField,
				getTestDataCellValue(scenarioName, "Products_Device_SerialNumber"));
		agSetValue(FDE_ProductsPageObjects.dateImplanted_TextField,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Products_Device_DateImplanted")));
		agSetValue(FDE_ProductsPageObjects.DurationOfTheImplantation,
				(getTestDataCellValue(scenarioName, "Products_Device_DurationOfTheImplantation")));
		setDurationOfTheImplantation(scenarioName,className);
		agSetValue(FDE_ProductsPageObjects.dateExplanted_TextField,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Products_Device_DateExplanted")));
		agSetValue(FDE_ProductsPageObjects.deviceAge_TextField,
				getTestDataCellValue(scenarioName, "Products_Device_DeviceAge"));
		CommonOperations.setFDEDropDownValue(FDE_ProductsPageObjects.deviceAgeUnit_DropDown,
				getTestDataCellValue(scenarioName, "Products_Device_DeviceAgeUnit"));
		CommonOperations.clickRadioButton(FDE_ProductsPageObjects.labeledSingleUseDevice_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_LabeledSingleUseDevice"));
		agSetStepExecutionDelay("2000");
		agSetValue(FDE_ProductsPageObjects.deviceManufactureDate_TextField, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Products_Device_DeviceManufactureDate")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.clickRadioButton(
				FDE_ProductsPageObjects.isThisaSingleUserDevicethatwasReprocessedandReused_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_ISingleUserDeviceReproceAndReused"));
		if (getTestDataCellValue(scenarioName, "Products_Device_ReprocessorUnit_Lookup").equalsIgnoreCase("Yes")) {
			agClick(FDE_ProductsPageObjects.reprocessorUnit_LookUp);
			if (getTestDataCellValue(scenarioName, "Products_Device_SenderPartnerLookup_Sender")
					.equalsIgnoreCase("Yes")) {
				CommonOperations.setSenderPartnerLookupDetails("Sender",
						getTestDataCellValue(scenarioName, "Products_Device_SenderAccountName"));
			} else if (getTestDataCellValue(scenarioName, "Products_Device_SenderPartnerLookup_CompanyUnit")
					.equalsIgnoreCase("Yes")) {
				CommonOperations.setSenderPartnerLookupDetails("Company Unit",
						getTestDataCellValue(scenarioName, "Products_Device_SenderCompanyUnitName"));
			}
		}
		String remedialActionInit_ChkBox = getTestDataCellValue(scenarioName,
				"Products_Device_IfRemedialActionInitiated");
		if (!remedialActionInit_ChkBox.equalsIgnoreCase("#skip#")) {
			String[] totalRecordsRemAct = remedialActionInit_ChkBox.split(",");
			for (int i = 0; i < totalRecordsRemAct.length; i++) {
				CommonOperations.clickCheckBoxLeftOf(totalRecordsRemAct[i], "true");
			}
		}
		
		if(scenarioName.contains("LSMV_OQ_HCD_Related_FDE_fields_")){
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.closeDevicePopUp);
			agSetStepExecutionDelay("2000");
		}
		// agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.device_Label);
		Reports.ExtentReportLog("", Status.INFO,
				"Data entered in Product Device section: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: To verify Product Device Details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 2-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDeviceDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_DeviceComponentNameFreeText"),
				FDE_ProductsPageObjects.deviceComponentNameFreeText_TextField);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Products_Device_DeviceComponentTermIDVersionDateNumber"),
				FDE_ProductsPageObjects.deviceComponentTermIDVersionDateNumber_TextField);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_DeviceComponentTermID"),
				FDE_ProductsPageObjects.deviceComponentTermID_TextField);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_CommonDeviceName"),
				FDE_ProductsPageObjects.commonDeviceName_TextField);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_BrandName"),
				FDE_ProductsPageObjects.brandName_TextField);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_ProductCode"),
				FDE_ProductsPageObjects.productCode_TextField);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_UDI"),
				FDE_ProductsPageObjects.UDI_TextField);
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Products_Device_ExpirationDate")),
				FDE_ProductsPageObjects.expirationDate_TextField);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_ModelNumber"),
				FDE_ProductsPageObjects.modelNumber_TextField);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_CatalogNumber"),
				FDE_ProductsPageObjects.catalogNumber_TextField);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_SerialNumber"),
				FDE_ProductsPageObjects.serialNumber_TextField);
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Products_Device_DateImplanted")),
				FDE_ProductsPageObjects.dateImplanted_TextField);
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Products_Device_DateExplanted")),
				FDE_ProductsPageObjects.dateExplanted_TextField);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_DeviceAge"),
				FDE_ProductsPageObjects.deviceAge_TextField);
		CommonOperations.verifyFDEDropDownValue(FDE_ProductsPageObjects.deviceAgeUnit_DropDown,
				getTestDataCellValue(scenarioName, "Products_Device_DeviceAgeUnit"));
		CommonOperations.verifyRadioButton(FDE_ProductsPageObjects.labeledSingleUseDevice_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_LabeledSingleUseDevice"));
		agCheckPropertyValue("value",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Products_Device_DeviceManufactureDate")),
				FDE_ProductsPageObjects.deviceManufactureDate_TextField);
		CommonOperations.verifyRadioButton(
				FDE_ProductsPageObjects.isThisaSingleUserDevicethatwasReprocessedandReused_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_ISingleUserDeviceReproceAndReused"));
		if (getTestDataCellValue(scenarioName, "Products_Device_ReprocessorUnit_Lookup").equalsIgnoreCase("Yes")) {
			if (getTestDataCellValue(scenarioName, "Products_Device_SenderPartnerLookup_Sender")
					.equalsIgnoreCase("Yes")) {
				agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_SenderAccountName"),
						FDE_ProductsPageObjects.reprocessorUnit_TextField);
			} else if (getTestDataCellValue(scenarioName, "Products_Device_SenderPartnerLookup_CompanyUnit")
					.equalsIgnoreCase("Yes")) {
				agCheckPropertyValue("value",
						getTestDataCellValue(scenarioName, "Products_Device_SenderCompanyUnitName"),
						FDE_ProductsPageObjects.reprocessorUnit_TextField);
			}
		}
		String remedialActionInit_ChkBox = getTestDataCellValue(scenarioName,
				"Products_Device_IfRemedialActionInitiated");
		if (!remedialActionInit_ChkBox.equalsIgnoreCase("#skip#")) {
			String[] totalRecordsRemAct = remedialActionInit_ChkBox.split(",");
			for (int i = 0; i < totalRecordsRemAct.length; i++) {
				CommonOperations.verifyCheckBoxLeftOf(totalRecordsRemAct[i], "true");
			}
		}
		agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.device_Label);
		Reports.ExtentReportLog("", Status.INFO,
				"Data verification in Product Device section: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: To set Product Device Other Details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 2-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDeviceOtherDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// Disabled fields
		// agSetValue(FDE_ProductsPageObjects.describeOther_TextField,
		// getTestDataCellValue(scenarioName, "Products_Device_DescribeOther"));
		agSetValue(FDE_ProductsPageObjects.correctionRemovalReportingNumber_TextField,
				getTestDataCellValue(scenarioName, "Products_Device_CorrectionRemovalReportingNumber"));
		CommonOperations.setFDEDropDownValue(FDE_ProductsPageObjects.locationWhereEventNotOccured_DropDown,
				getTestDataCellValue(scenarioName, "Products_Device_LocationWhereEventOccured"));
		CommonOperations.clickRadioButton(FDE_ProductsPageObjects.deviceUsedFor_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_DeviceUsedFor"));
		// Disabled fields
		// agSetValue(FDE_ProductsPageObjects.eventLocationOther_TextArea,
		// getTestDataCellValue(scenarioName, "Products_Device_EventLocationOther"));
		agSetValue(FDE_ProductsPageObjects.deviceBatchLotNumber_TextField,
				getTestDataCellValue(scenarioName, "Products_Device_DeviceBatchLotNumber"));

		CommonOperations.clickRadioButton(FDE_ProductsPageObjects.usageOfDevice_InitialUse_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_UsageOfDevice_InitialUse"));
		CommonOperations.clickRadioButton(FDE_ProductsPageObjects.usageOfDevice_Other_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_UsageOfDevice_Other"));
		CommonOperations.clickRadioButton(FDE_ProductsPageObjects.usageOfDevice_Problemnotedprioruse_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_UsageOfDevice_Problemnotedprioruse"));
		CommonOperations.clickRadioButton(FDE_ProductsPageObjects.usageOfDevice_Reserviced_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_UsageOfDevice_Reserviced"));
		CommonOperations.clickRadioButton(FDE_ProductsPageObjects.usageOfDevice_ReusableMedicaldevice_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_UsageOfDevice_ReusableMedicaldevice"));
		CommonOperations.clickRadioButton(FDE_ProductsPageObjects.usageOfDevice_SingleUseMedicaldevice_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_UsageOfDevice_SingleUseMedicaldevice"));
		agClick(FDE_ProductsPageObjects.unknownRadio);
		// CommonOperations.clickRadioButton(FDE_ProductsPageObjects.usageOfDevice_Unknown_Radio,
		// getTestDataCellValue(scenarioName, "Products_Device_UsageOfDevice_Unknown"));
		if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}
		CommonOperations.clickRadioButton(FDE_ProductsPageObjects.malfunction_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_Malfunction"));
		String followUpType_ChkBox = getTestDataCellValue(scenarioName, "Products_Device_FollowUpType");
		if (!followUpType_ChkBox.equalsIgnoreCase("#skip#")) {
			String[] totalRecordsFollowUp = followUpType_ChkBox.split(",");
			for (int i = 0; i < totalRecordsFollowUp.length; i++) {
				CommonOperations.clickCheckBoxLeftOf(totalRecordsFollowUp[i], "true");
			}
		}
		CommonOperations.setFDEDropDownValue(FDE_ProductsPageObjects.operatorOfDevice_DropDown,
				getTestDataCellValue(scenarioName, "Products_Device_OperatorOfDevice"));
		agSetValue(FDE_ProductsPageObjects.productReturnDate_TextField, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Products_Device_ProductReturnDate")));
		CommonOperations.clickRadioButton(FDE_ProductsPageObjects.wasThisDeviceServicedbyThirdParty_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_WasThisDeviceServicedByAThirdParty"));
		CommonOperations.clickRadioButton(FDE_ProductsPageObjects.productAvailableForEvaluation_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_ProductAvailableForEvaluation"));
		CommonOperations.clickRadioButton(FDE_ProductsPageObjects.deviceEvaluatedByManufacturer_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_DeviceEvaluatedByManufacturer"));
		CommonOperations.setFDEDropDownValue(FDE_ProductsPageObjects.reasonWhyDeviceWasNotEvaluated_DropDown,
				getTestDataCellValue(scenarioName, "Products_Device_ReasonWhyDeviceWasNotEvaluated"));
		agSetStepExecutionDelay("5000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// object change
		/*
		 * CommonOperations.clickRadioButton(FDE_ProductsPageObjects.
		 * reportSenttoManufacturer_Radio, getTestDataCellValue(scenarioName,
		 * "Products_Device_ReportSentToManufacturerIfYesEnterDate"));
		 * if(getTestDataCellValue(scenarioName,
		 * "Products_Device_ReportSentToManufacturerIfYesEnterDate").equalsIgnoreCase(
		 * "Yes")) { agSetStepExecutionDelay("2000");
		 * agSetValue(FDE_ProductsPageObjects.reportSenttoManufacturerDate_TextField,
		 * CommonOperations.returnDateTime(getTestDataCellValue(scenarioName,
		 * "Products_Device_ReportSentToManufacturerDate")));
		 * agSetStepExecutionDelay(String.valueOf(Constants.
		 * defaultGlobalStepExecutionDelay)); }
		 */
		if (getTestDataCellValue(scenarioName, "Products_Device_UserFacility_Lookup").equalsIgnoreCase("Yes")) {
			agClick(FDE_ProductsPageObjects.userFacility_LookUpIcon);
			if (getTestDataCellValue(scenarioName, "Products_Device_UserFacility_SenderPartnerLookup_Sender")
					.equalsIgnoreCase("Yes")) {
				CommonOperations.setSenderPartnerLookupDetails("Sender",
						getTestDataCellValue(scenarioName, "Products_Device_UserFacility_SenderAccountName"));
			} else if (getTestDataCellValue(scenarioName,
					"Products_Device_UserFacility_SenderPartnerLookup_CompanyUnit").equalsIgnoreCase("Yes")) {
				CommonOperations.setSenderPartnerLookupDetails("Company Unit",
						getTestDataCellValue(scenarioName, "Products_Device_UserFacility_SenderCompanyUnitName"));
			}
		}
		if (getTestDataCellValue(scenarioName, "Products_Device_Importer_Lookup").equalsIgnoreCase("Yes")) {
			agClick(FDE_ProductsPageObjects.importer_LookUpIcon);
			if (getTestDataCellValue(scenarioName, "Products_Device_Importer_SenderPartnerLookup_Sender")
					.equalsIgnoreCase("Yes")) {
				CommonOperations.setSenderPartnerLookupDetails("Sender",
						getTestDataCellValue(scenarioName, "Products_Device_Importer_SenderAccountName"));
			} else if (getTestDataCellValue(scenarioName, "Products_Device_Importer_SenderPartnerLookup_CompanyUnit")
					.equalsIgnoreCase("Yes")) {
				CommonOperations.setSenderPartnerLookupDetails("Company Unit",
						getTestDataCellValue(scenarioName, "Products_Device_Importer_SenderCompanyUnitName"));
			}
		}
		CommonOperations.agwaitTillVisible(FDE_ProductsPageObjects.reportSenttoFda_Radio, 10, 1000);
		CommonOperations.clickRadioButton(FDE_ProductsPageObjects.reportSenttoFda_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_ReportSentToFdaIfYesEnterDate"));
		if (getTestDataCellValue(scenarioName, "Products_Device_ReportSentToFdaIfYesEnterDate")
				.equalsIgnoreCase("Yes")) {
			agSetStepExecutionDelay("2000");
			agSetValue(FDE_ProductsPageObjects.reportSenttoFdaDate_TextField, CommonOperations
					.returnDateTime(getTestDataCellValue(scenarioName, "Products_Device_ReportSentToFdaDate")));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		agSetStepExecutionDelay("1000");
		agSetValue(FDE_ProductsPageObjects.userFacilityImportReportNumber_TextField,
				getTestDataCellValue(scenarioName, "Products_Device_UserFacilityImportReportNumber"));
		agSetValue(FDE_ProductsPageObjects.mfr_TextField, getTestDataCellValue(scenarioName, "Products_Device_MFR"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.reprocessorUnit_TextField);
		agClick(FDE_ProductsPageObjects.deviceClose);
		Reports.ExtentReportLog("", Status.INFO,
				"Data entered in Product Device section: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: To verify Product Device Other Details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 2-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDeviceOtherDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_DescribeOther"),
				FDE_ProductsPageObjects.describeOther_TextField);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Products_Device_CorrectionRemovalReportingNumber"),
				FDE_ProductsPageObjects.correctionRemovalReportingNumber_TextField);
		CommonOperations.verifyFDEDropDownValue(FDE_ProductsPageObjects.locationWhereEventNotOccured_DropDown,
				getTestDataCellValue(scenarioName, "Products_Device_LocationWhereEventOccured"));
		CommonOperations.verifyRadioButton(FDE_ProductsPageObjects.deviceUsedFor_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_DeviceUsedFor"));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_EventLocationOther"),
				FDE_ProductsPageObjects.eventLocationOther_TextArea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_DeviceBatchLotNumber"),
				FDE_ProductsPageObjects.deviceBatchLotNumber_TextField);
		CommonOperations.verifyRadioButton(FDE_ProductsPageObjects.malfunction_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_Malfunction"));
		String followUpType_ChkBox = getTestDataCellValue(scenarioName, "Products_Device_FollowUpType");
		if (!followUpType_ChkBox.equalsIgnoreCase("#skip#")) {
			String[] totalRecordsFollowUp = followUpType_ChkBox.split(",");
			for (int i = 0; i < totalRecordsFollowUp.length; i++) {
				CommonOperations.verifyCheckBoxLeftOf(totalRecordsFollowUp[i], "true");
			}
		}
		CommonOperations.verifyFDEDropDownValue(FDE_ProductsPageObjects.operatorOfDevice_DropDown,
				getTestDataCellValue(scenarioName, "Products_Device_OperatorOfDevice"));
		agCheckPropertyValue("value",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Products_Device_ProductReturnDate")),
				FDE_ProductsPageObjects.productReturnDate_TextField);
		CommonOperations.verifyRadioButton(FDE_ProductsPageObjects.wasThisDeviceServicedbyThirdParty_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_WasThisDeviceServicedByAThirdParty"));
		CommonOperations.verifyRadioButton(FDE_ProductsPageObjects.productAvailableForEvaluation_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_ProductAvailableForEvaluation"));
		CommonOperations.verifyRadioButton(FDE_ProductsPageObjects.deviceEvaluatedByManufacturer_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_DeviceEvaluatedByManufacturer"));
		CommonOperations.verifyFDEDropDownValue(FDE_ProductsPageObjects.reasonWhyDeviceWasNotEvaluated_DropDown,
				getTestDataCellValue(scenarioName, "Products_Device_ReasonWhyDeviceWasNotEvaluated"));
		CommonOperations.verifyRadioButton(FDE_ProductsPageObjects.reportSenttoManufacturer_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_ReportSentToManufacturerIfYesEnterDate"));
		if (getTestDataCellValue(scenarioName, "Products_Device_ReportSentToManufacturerIfYesEnterDate")
				.equalsIgnoreCase("Yes")) {
			agCheckPropertyValue("value",
					CommonOperations.returnDateTime(
							getTestDataCellValue(scenarioName, "Products_Device_ReportSentToManufacturerDate")),
					FDE_ProductsPageObjects.reportSenttoManufacturerDate_TextField);
		}
		if (getTestDataCellValue(scenarioName, "Products_Device_UserFacility_Lookup").equalsIgnoreCase("Yes")) {
			if (getTestDataCellValue(scenarioName, "Products_Device_UserFacility_SenderPartnerLookup_Sender")
					.equalsIgnoreCase("Yes")) {
				agCheckPropertyValue("value",
						getTestDataCellValue(scenarioName, "Products_Device_UserFacility_SenderAccountName"),
						FDE_ProductsPageObjects.userFacility_TextField);
			} else if (getTestDataCellValue(scenarioName,
					"Products_Device_UserFacility_SenderPartnerLookup_CompanyUnit").equalsIgnoreCase("Yes")) {
				agCheckPropertyValue("value",
						getTestDataCellValue(scenarioName, "Products_Device_UserFacility_SenderCompanyUnitName"),
						FDE_ProductsPageObjects.userFacility_TextField);
			}
		}
		if (getTestDataCellValue(scenarioName, "Products_Device_Importer_Lookup").equalsIgnoreCase("Yes")) {
			if (getTestDataCellValue(scenarioName, "Products_Device_Importer_SenderPartnerLookup_Sender")
					.equalsIgnoreCase("Yes")) {
				agCheckPropertyValue("value",
						getTestDataCellValue(scenarioName, "Products_Device_Importer_SenderAccountName"),
						FDE_ProductsPageObjects.importer_TextField);
			} else if (getTestDataCellValue(scenarioName, "Products_Device_Importer_SenderPartnerLookup_CompanyUnit")
					.equalsIgnoreCase("Yes")) {
				agCheckPropertyValue("value",
						getTestDataCellValue(scenarioName, "Products_Device_Importer_SenderCompanyUnitName"),
						FDE_ProductsPageObjects.importer_TextField);
			}
		}
		CommonOperations.verifyRadioButton(FDE_ProductsPageObjects.reportSenttoFda_Radio,
				getTestDataCellValue(scenarioName, "Products_Device_ReportSentToFdaIfYesEnterDate"));
		if (getTestDataCellValue(scenarioName, "Products_Device_ReportSentToFdaIfYesEnterDate")
				.equalsIgnoreCase("Yes")) {
			agCheckPropertyValue("value",
					CommonOperations
							.returnDateTime(getTestDataCellValue(scenarioName, "Products_Device_ReportSentToFdaDate")),
					FDE_ProductsPageObjects.reportSenttoFdaDate_TextField);
		}
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Products_Device_UserFacilityImportReportNumber"),
				FDE_ProductsPageObjects.userFacilityImportReportNumber_TextField);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_MFR"),
				FDE_ProductsPageObjects.mfr_TextField);

		agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.reprocessorUnit_TextField);
		Reports.ExtentReportLog("", Status.INFO,
				"Data verification in Product Device section: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: To set Product Device Manufacturer Details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 2-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	// Below Hard Coded Value done for Data Modeling executions.
	static String rowNo_DeviceManufacturer = "0"; // getTestDataCellValue(scenarioName, "RowNo_DeviceManufacturer");
	static String boolAdd_DeviceManufacturer = "false"; // getTestDataCellValue(scenarioName,
														// "boolAdd_DeviceManufacturer");

	public static void setDeviceManufacturerDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (agIsVisible(CaseManagementPageObjects.GridViewCheck("Device manufacturer"))) {
			agClick(CaseManagementPageObjects.GridViewCheck("Device manufacturer"));
		}
		if (boolAdd_DeviceManufacturer.equalsIgnoreCase("true")) {
			agClick(CommonPageObjects.clickAddButton(FDE_ProductsPageObjects.deviceManufacturer_Label));
		}
		agSetValue(
				(FDE_ProductsPageObjects.manufacturerAsReported_TextField).replace("%rowNo%", rowNo_DeviceManufacturer),
				getTestDataCellValue(scenarioName, "Products_Device_DeviceManufacturer_ManufacturerAsReported"));
		if (getTestDataCellValue(scenarioName, "Products_Device_DeviceManufacturer_ManufacturerAsCoded_Lookup")
				.equalsIgnoreCase("Yes")) {
			agClick((FDE_ProductsPageObjects.manufacturerAsCoded_Lookup).replace("%rowNo%", rowNo_DeviceManufacturer));
			agSetValue(SenderLookupPageObjects.accountName_TextBox,
					getTestDataCellValue(scenarioName, "Products_Device_DeviceManufacturer_SenderAccountName"));
			agClick(SenderLookupPageObjects.search_Button);
			CommonOperations.agwaitTillVisible(
					CommonPageObjects.searchResultSelectRadio(
							getTestDataCellValue(scenarioName, "Products_Device_DeviceManufacturer_SenderAccountName")),
					10, 1000);
			agClick(CommonPageObjects.searchResultSelectRadio(
					getTestDataCellValue(scenarioName, "Products_Device_DeviceManufacturer_SenderAccountName")));
			CommonOperations.takeScreenShot();
			agClick(SenderLookupPageObjects.okSenderPartner_Button);
		}
		agSetValue((FDE_ProductsPageObjects.manufacturerAddress_TextField).replace("%rowNo%", rowNo_DeviceManufacturer),
				getTestDataCellValue(scenarioName, "Products_Device_DeviceManufacturer_ManufacturerAddress"));
		agSetValue((FDE_ProductsPageObjects.city_TextField).replace("%rowNo%", rowNo_DeviceManufacturer),
				getTestDataCellValue(scenarioName, "Products_Device_DeviceManufacturer_City"));
		agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.deviceManufacturer_Div);
		CommonOperations.takeScreenShot();

		agSetValue((FDE_ProductsPageObjects.state_TextField).replace("%rowNo%", rowNo_DeviceManufacturer),
				getTestDataCellValue(scenarioName, "Products_Device_DeviceManufacturer_State"));
		CommonOperations.setFDEDropDownValue(
				(FDE_ProductsPageObjects.country_DropDown).replace("%rowNo%", rowNo_DeviceManufacturer),
				getTestDataCellValue(scenarioName, "Products_Device_DeviceManufacturer_Country"));
		agSetStepExecutionDelay("3000");
		agJavaScriptExecuctorClick(FDE_ProductsPageObjects.closeDevicePopUp);
		agSetStepExecutionDelay("2000");
		Reports.ExtentReportLog("", Status.INFO,
				"Data entered in Product Device Manufacturer section: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: To verify Product Device Manufacturer Details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 2-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDeviceManufacturerDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Products_Device_DeviceManufacturer_ManufacturerAsReported"),
				(FDE_ProductsPageObjects.manufacturerAsReported_TextField).replace("%rowNo%",
						rowNo_DeviceManufacturer));
		if (getTestDataCellValue(scenarioName, "Products_Device_DeviceManufacturer_ManufacturerAsCoded_Lookup")
				.equalsIgnoreCase("Yes")) {
			agCheckPropertyValue("value",
					getTestDataCellValue(scenarioName, "Products_Device_DeviceManufacturer_SenderAccountName"),
					(FDE_ProductsPageObjects.manufacturerAsCoded_TextField).replace("%rowNo%",
							rowNo_DeviceManufacturer));
		}

		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Products_Device_DeviceManufacturer_ManufacturerAddress"),
				(FDE_ProductsPageObjects.manufacturerAddress_TextField).replace("%rowNo%", rowNo_DeviceManufacturer));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_DeviceManufacturer_City"),
				(FDE_ProductsPageObjects.city_TextField).replace("%rowNo%", rowNo_DeviceManufacturer));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Products_Device_DeviceManufacturer_State"),
				(FDE_ProductsPageObjects.state_TextField).replace("%rowNo%", rowNo_DeviceManufacturer));
		CommonOperations.verifyFDEDropDownValue(
				(FDE_ProductsPageObjects.country_DropDown).replace("%rowNo%", rowNo_DeviceManufacturer),
				getTestDataCellValue(scenarioName, "Products_Device_DeviceManufacturer_Country"));

		agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.deviceManufacturer_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data verification in Product Device Manufacturer section: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: To set Product Device Problem Evaluation Details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 2-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	// Below Hard Coded Value done for Data Modeling executions.
	static String rowNo_DeviceProblemEvaluation = "0"; // getTestDataCellValue(scenarioName,
														// "RowNo_DeviceProblemEvaluation");
	static String boolAdd_DeviceProblemEvaluation = "false"; // getTestDataCellValue(scenarioName,
																// "boolAdd_DeviceProblemEvaluation");

	public static void setDeviceProblemEvaluationDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (boolAdd_DeviceProblemEvaluation.equalsIgnoreCase("true")) {
			agClick(CommonPageObjects.clickAddButton(FDE_ProductsPageObjects.deviceProblemEvaluation_Label));
		}
		CommonOperations.setFDEDropDownValue(
				(FDE_ProductsPageObjects.evaluationType_DropDown).replace("%rowNo%", rowNo_DeviceProblemEvaluation),
				getTestDataCellValue(scenarioName, "Products_Device_DeviceProblemEvaluation_EvaluationType"));
		CommonOperations.setFDEDropDownValue(
				(FDE_ProductsPageObjects.evaluationValue_DropDown).replace("%rowNo%", rowNo_DeviceProblemEvaluation),
				getTestDataCellValue(scenarioName, "Products_Device_DeviceProblemEvaluation_EvaluationValue"));

		agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.deviceProblemEvaluation_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data entered in Product Device Problem Evaluation section: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: To verify Product Device Problem Evaluation Details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 2-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDeviceProblemEvaluationDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.verifyFDEDropDownValue(
				(FDE_ProductsPageObjects.evaluationType_DropDown).replace("%rowNo%", rowNo_DeviceProblemEvaluation),
				getTestDataCellValue(scenarioName, "Products_Device_DeviceProblemEvaluation_EvaluationType"));
		CommonOperations.verifyFDEDropDownValue(
				(FDE_ProductsPageObjects.evaluationValue_DropDown).replace("%rowNo%", rowNo_DeviceProblemEvaluation),
				getTestDataCellValue(scenarioName, "Products_Device_DeviceProblemEvaluation_EvaluationValue"));

		agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.deviceProblemEvaluation_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data verification in Product Device Problem Evaluation section: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective:To set product details
	 * @InputParameters: Scenario Name, columnName
	 * @OutputParameters:
	 * @author: Avinash k
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setProductData(String scenarioName) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,
		// "ConfigurationSettings");
		// if (getTestDataCellValue(scenarioName,
		// "FDE_Products").equalsIgnoreCase("Yes")) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Multimaplibraries.getTestDataCellLength(scenarioName, "Products_ProductInformation_ProductCharacterization");

		for (int j = 1; j <= Constants.testDataParentLength; j++) {
			Constants.testDataParentLoopCount = j;

			if (j > 1) {
				agClick(FDE_ProductsPageObjects.AddBtnProduct);
				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			setProductInformation(scenarioName);
			setIngredients(scenarioName);
			setProductApproval(scenarioName);
			setIndication(scenarioName);
			setTherapies(scenarioName);
			// setAdditionalInfoCode(scenarioName);
			/*
			 * if (!scenarioName.equalsIgnoreCase("LSMV_CIOMS_Report_Multiple") &&
			 * !scenarioName.equalsIgnoreCase("JapanDomWF") &&
			 * !scenarioName.equalsIgnoreCase("JapanTest") &&
			 * !scenarioName.equalsIgnoreCase("CopyCase")) {
			 * setAdditionalInfoCode(scenarioName); setDeviceDetails(scenarioName);
			 * setDeviceOtherDetails(scenarioName);
			 * setDeviceManufacturerDetails(scenarioName); }
			 * setDeviceProblemEvaluationDetails(scenarioName);
			 */
			Reports.ExtentReportLog("", Status.INFO,
					"~~~~~~~~~~~~~~Data Entered in Product Creation_00" + j + "~~~~~~~~~~~~", false);
		}
	}
	// }

	/**********************************************************************************************************
	 * @Objective: To navigate to 1st record
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Avinash K
	 * @Date : 29-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void navigateToParentProduct() {
		if (agIsVisible(FDE_ProductsPageObjects.forwardNavigaterClick) == true) {
			List<WebElement> list = agGetElementList(FDE_ProductsPageObjects.getListOfProducts);
			System.out.println("Products Length::" + list.size());
			for (int i = 1; i <= list.size(); i++) {
				agJavaScriptExecuctorClick(FDE_ProductsPageObjects.prevNavigaterClick);
				try {
					Thread.sleep(3000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to verify Product Information in
	 *                Product tab displayed in Product Tab
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void productData_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Multimaplibraries.getTestDataCellLength(scenarioName,
				"Products_ProductInformation_ProductDescription_ProductName");

		navigateToParentProduct();

		for (int j = 1; j <= Constants.testDataParentLength; j++) {
			Constants.testDataParentLoopCount = j;

			if (j >= 1) {

				if (!agIsVisible(FDE_ProductsPageObjects.clickMultipleProducts(getTestDataCellValue(scenarioName,
						"Products_ProductInformation_ProductDescription_ProductName")))) {
					agJavaScriptExecuctorClick(FDE_ProductsPageObjects.forwardNavigaterClick);
				} else if (!agIsVisible(FDE_ProductsPageObjects.clickMultipleProducts(getTestDataCellValue(scenarioName,
						"Products_ProductInformation_ProductDescription_ProductName")))) {
					agJavaScriptExecuctorClick(FDE_ProductsPageObjects.prevNavigaterClick);
				}
				agJavaScriptExecuctorClick(FDE_ProductsPageObjects.clickMultipleProducts(getTestDataCellValue(
						scenarioName, "Products_ProductInformation_ProductDescription_ProductName")));
				System.out.println("Product Name:"
						+ agGetXpath(FDE_ProductsPageObjects.clickMultipleProducts(getTestDataCellValue(scenarioName,
								"Products_ProductInformation_ProductDescription_ProductName"))));
				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			productInformation_Verification(scenarioName);
			verifyIngredients(scenarioName);
			verifyIndication(scenarioName);
			verifyProductApproval(scenarioName);
			verifyTherapies(scenarioName);
			verifyAdditionalInfoCode(scenarioName);
			/*
			 * verifyDeviceDetails(scenarioName); verifyDeviceOtherDetails(scenarioName);
			 * verifyDeviceManufacturerDetails(scenarioName);
			 * verifyDeviceProblemEvaluationDetails(scenarioName);
			 */
			Reports.ExtentReportLog("", Status.INFO, "Product Verification_00" + j, false);
		}
	}
	// ----------------------------------------

	/**********************************************************************************************************
	 * @Objective: Set Product Therapie data in product page of FDE is enhanced to
	 *             support multiple records
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Avinash K
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen: MP Ramkumar on 9-Mar-2020 (To support Multiple Records
	 *                    Adding)
	 **********************************************************************************************************/
	public static void setTherapyData(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (getTestDataCellValue(scenarioName, "Therapy_NextRec").equalsIgnoreCase("true")) {
			agClick(FDE_ProductsPageObjects.clickTherapyButtons("Add"));
			try {
				Thread.sleep(10000);// Wait Added for new tab.
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		agSetValue(FDE_ProductsPageObjects.unitDose_TextField,
				getTestDataCellValue(scenarioName, "Products_Therapies_UnitDose"));
		setProductEmbedDropDownValue(FDE_ProductsPageObjects.unitDose_dropdown, scenarioName,
				"Products_Therapies_UnitDoseUnit");
		agSetValue(FDE_ProductsPageObjects.formStrength_TextField,
				getTestDataCellValue(scenarioName, "Products_Therapies_FormStrength"));
		setProductEmbedDropDownValue(FDE_ProductsPageObjects.formStrength_dropdown, scenarioName,
				"Products_Therapies_FormStrengthUnit");
		agClick(FDE_ProductsPageObjects.formStrength_TextField);
		if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}
		agSetValue(FDE_ProductsPageObjects.frequency_TextField,
				getTestDataCellValue(scenarioName, "Products_Therapies_Frequency"));
		agSetValue(FDE_ProductsPageObjects.frequencyTime_TextField,
				getTestDataCellValue(scenarioName, "Products_Therapies_FrequencyTime"));
		setProductEmbedDropDownValue(FDE_ProductsPageObjects.frequencyTime_dropdown, scenarioName,
				"Products_Therapies_FrequencyTimeUnit");
		if (getTestDataCellValue(scenarioName, "Products_Therapies_DailyDose_Manual").equalsIgnoreCase("Check")) {
			CommonOperations.clickManualCheckBox(FDE_ProductsPageObjects.dailyDose_dropdown,
					getTestDataCellValue(scenarioName, "Products_Therapies_DailyDose_Manual"));
			agSetValue(FDE_ProductsPageObjects.dailyDose_TextField,
					getTestDataCellValue(scenarioName, "Products_Therapies_DailyDose"));
			setProductEmbedDropDownValue(FDE_ProductsPageObjects.dailyDose_dropdown, scenarioName,
					"Products_Therapies_DailyDoseUnit");
		}
		if (getTestDataCellValue(scenarioName, "Products_Therapies_TotalDose_Manual").equalsIgnoreCase("Check")) {
			CommonOperations.clickManualCheckBox(FDE_ProductsPageObjects.totaldose_Dropdown,
					getTestDataCellValue(scenarioName, "Products_Therapies_TotalDose_Manual"));
			agSetValue(FDE_ProductsPageObjects.totaldose_TextField,
					getTestDataCellValue(scenarioName, "Products_Therapies_TotalDose"));
			setProductEmbedDropDownValue(FDE_ProductsPageObjects.totaldose_Dropdown, scenarioName,
					"Products_Therapies_TotalDoseUnit");
		}
		agSetValue(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate),
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Products_Therapies_TherapyStartDate")));
		agSetValue(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyEndDate), CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Products_Therapies_TherapyEndDate")));
		if (getTestDataCellValue(scenarioName, "Products_Therapies_DurationOfDrugAdministration_Manual")
				.equalsIgnoreCase("Check")) {
			CommonOperations.clickManualCheckBox(FDE_ProductsPageObjects.durationOfDrugAdministration_Dropdown,
					getTestDataCellValue(scenarioName, "Products_Therapies_DurationOfDrugAdministration_Manual"));
			agSetValue(FDE_ProductsPageObjects.durationOfDrugAdministration_TextField,
					getTestDataCellValue(scenarioName, "Products_Therapies_DurationOfDrugAdministration"));
			setProductEmbedDropDownValue(FDE_ProductsPageObjects.durationOfDrugAdministration_Dropdown, scenarioName,
					"Products_Therapies_DurationOfDrugAdministrationUnit");
		}
		agSetValue(FDE_ProductsPageObjects.lotNumber_TextField,
				getTestDataCellValue(scenarioName, "Products_Therapies_LotNumber"));

		agSetValue(FDE_ProductsPageObjects.lotExpirationDate_DateField, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Products_Therapies_LotExpirationDate")));

		setProductDropDownValue(FDE_ProductsPageObjects.formOfAdmin_Dropdown, scenarioName,
				"Products_Therapies_FormOfAdmin");
		agSetValue(FDE_ProductsPageObjects.PharmaceuticalTermID_TxtField,
				getTestDataCellValue(scenarioName, "Products_Therapies_PharmaceuticalDoseFormTermID"));
		setProductDropDownValue(FDE_ProductsPageObjects.routeOfAdmin_Dropdown, scenarioName,
				"Products_Therapies_RouteOfAdmin");
		agSetValue(FDE_ProductsPageObjects.routeOfAdministrationTermIDVerDateNum_TextField,
				getTestDataCellValue(scenarioName, "Products_Therapies_RouteOfAdministrationTermIDVerDateNum"));
		agSetValue(FDE_ProductsPageObjects.pharmaceuticalDoseFormTermIDVerDateNum_TextField,
				getTestDataCellValue(scenarioName, "Products_Therapies_PharmaceuticalDoseFormTermIDVerDateNum"));
		setProductDropDownValue(FDE_ProductsPageObjects.routeofAdministrationTermID_Dropdown, scenarioName,
				"Products_Therapies_RouteOfAdministrationTermID");

		if (!getTestDataCellValue(scenarioName, "Products_Therapies_ParentsRouteOfAdmin").equalsIgnoreCase("#skip#")) {
			agClick(FDE_ProductsPageObjects.clickparentsRouteOfAdmin);
			agClick(FDE_ProductsPageObjects
					.clickDropDownValue(getTestDataCellValue(scenarioName, "Products_Therapies_ParentsRouteOfAdmin")));
		}
		agSetValue(FDE_ProductsPageObjects.parentRouteOfAdministrationTermIDVerDateNum_TextField,
				getTestDataCellValue(scenarioName, "Products_Therapies_ParentRouteOfAdministrationTermIDVerDateNum"));
		setProductDropDownValue(FDE_ProductsPageObjects.parentRouteOfAdministrationTermID_Dropdown, scenarioName,
				"Products_Therapies_ParentRouteOfAdministrationTermID");
		agSetValue(FDE_ProductsPageObjects.dosageText_TextField,
				getTestDataCellValue(scenarioName, "Products_Therapies_DosageText"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data entered in Product Therapies section: Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to select Null Flavour value from dropdown
	 *             based on excel data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 23-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setProductNFDropDownValue(String label, String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_ProductsPageObjects.NFproductDropdownSelect(label));
			agClick(FDE_GeneralPageObjects.clickDropDownValue(getTestDataCellValue(scenarioName, columnName)));
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to check Null Flavour and selected
	 *             dropdown value based on excel data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 23-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setProductNullFlavours(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agClick(FDE_ProductsPageObjects.click_NFBtn(FDE_ProductsPageObjects.therapyStartDate));
		setProductNFDropDownValue(FDE_ProductsPageObjects.therapyStartDate, scenarioName,
				"Products_Therapies_TherapyStartDate");
		agClick(FDE_ProductsPageObjects.click_NFBtn(FDE_ProductsPageObjects.therapyEndDate));
		setProductNFDropDownValue(FDE_ProductsPageObjects.therapyEndDate, scenarioName,
				"Products_Therapies_TherapyEndDate");
		agClick(FDE_ProductsPageObjects.click_NFBtn(FDE_ProductsPageObjects.formOfAdmin_Dropdown));
		setProductNFDropDownValue(FDE_ProductsPageObjects.formOfAdmin_Dropdown, scenarioName,
				"Products_Therapies_FormOfAdmin");
		agClick(FDE_ProductsPageObjects.click_NFBtn(FDE_ProductsPageObjects.routeOfAdmin_Dropdown));
		setProductNFDropDownValue(FDE_ProductsPageObjects.routeOfAdmin_Dropdown, scenarioName,
				"Products_Therapies_RouteOfAdmin");
		agClick(FDE_ProductsPageObjects.click_NFBtn(FDE_ProductsPageObjects.lotnumber_Dropdown));
		setProductNFDropDownValue(FDE_ProductsPageObjects.lotnumber_Dropdown, scenarioName,
				"Products_Therapies_LotNumber");

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to Add Unblinded Button in Product Tab
	 *                without the product description
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 24-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void addUnblindedProduct(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_ProductsPageObjects.addUnblindedProduct_Btn);
		if (agIsVisible(FDE_ProductsPageObjects.confirmationPopup) == true) {
			agCheckPropertyText(Product_LookupOperations.getData(scenarioName, "PopupMessage"),
					FDE_ProductsPageObjects.popUp_Message);
			CommonOperations.takeScreenShot();
			agClick(FDE_ProductsPageObjects.popUp_YesBtn);
			CommonOperations.takeScreenShot();
			FDE_Products.setIngredients(scenarioName);
			FDE_Products.setTherapies(scenarioName);
			CommonOperations.takeScreenShot();
		}
	}

	/**********************************************************************************************************
	 * @Objective: To Clik on Product tab
	 * @InputParameters: position, runTimeLabel
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 27-Apr-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickProduct(String position, String ProductName) {
		agClick(FDE_ProductsPageObjects.clickProduct(position, ProductName));
	}

	/**********************************************************************************************************
	 * @Objective: To ProductNavigation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash
	 * @Date : 06-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ProductNavigation() {
		agClick(FDE_ProductsPageObjects.productNavigation_Icon);
	}

	// a[@class='tabCarouselNext evAttached']
	/**********************************************************************************************************
	 * @Objective: The below method is to Automatic calculation of Therapy Duration
	 *             in Products Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @throws ParseException
	 * @throws java.text.ParseException
	 * @Date : 11-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AutocalculationofTherpyDuration() throws ParseException, java.text.ParseException {
		Reports.ExtentReportLog("", Status.INFO, "Auto calculating of Thearpy Duration Begins", true);
		try {
			FDE_Operations.tabNavigation("Product(s)");

			agClick(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate));
			String ThearpyStartDate = agGetAttribute("title",
					FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate));
			agClick(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyEndDate));
			String ThearpyEndDate = agGetAttribute("title",
					FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyEndDate));
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
			if (ThearpyStartDate.equals("") || ThearpyEndDate.equals("")) {
				Reports.ExtentReportLog("", Status.INFO, "No Data Found to Calculate Theary Duartion", true);
			} else {
				Date firstDate = sdf.parse(ThearpyStartDate);
				Date secondDate = sdf.parse(ThearpyEndDate);
				String DurationofDrugDD = agGetText(FDE_ProductsPageObjects.DurationOfDrugDD);
				agClick(FDE_ProductsPageObjects.durationOfDrugAdministration_TextField);
				String DurationofDrug = agGetAttribute("title",
						FDE_ProductsPageObjects.durationOfDrugAdministration_TextField);

				int diffYear = Math.abs(secondDate.getYear() - firstDate.getYear());
				int diffMonth = diffYear * 12 + secondDate.getMonth() - firstDate.getMonth();
				long diffDay = Math.abs(secondDate.getDay() - firstDate.getDay());
				long diff = secondDate.getTime() - firstDate.getTime();
				long diffSeconds = diff / 1000;
				long diffMinutes = diff / (60 * 1000);
				long diffHours = diff / (60 * 60 * 1000);

				if (DurationofDrugDD.equalsIgnoreCase("Day")) {
					if (DurationofDrug.equalsIgnoreCase(String.valueOf(diffDay))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Therapy Duration  in Days Matches", true);
						return;
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Therapy Duration  in Days Doesnt Matches",
								true);
					}
				} else if (DurationofDrugDD.equalsIgnoreCase("Month")) {
					if (DurationofDrug.equalsIgnoreCase(String.valueOf(diffMonth))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Therapy Duration  in Month Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Therapy Duration  in Month Doesnt Matches",
								true);
					}
				} else if (DurationofDrugDD.equalsIgnoreCase("Year")) {
					if (DurationofDrug.equalsIgnoreCase(String.valueOf(diffYear))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Therapy Duration  in Year Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Therapy Duration  in Year Doesnt Matches",
								true);
					}
				} else if (DurationofDrugDD.equalsIgnoreCase("Week")) {
					if (DurationofDrug.equalsIgnoreCase(String.valueOf(diffDay))) {
						Reports.ExtentReportLog("Calculated Therapy Duration  in Week Matches", Status.PASS, "", true);
					} else {
						Reports.ExtentReportLog("Calculated Therapy Duration  in Week Doesnt Matches", Status.FAIL, "",
								true);
					}
				} else if (DurationofDrugDD.equalsIgnoreCase("Hour")) {
					if (DurationofDrug.equalsIgnoreCase(String.valueOf(diffHours))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Therapy Duration  in Hour Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Therapy Duration  in Hour Doesnt Matches",
								true);
					}
				} else if (DurationofDrugDD.equalsIgnoreCase("Minute")) {
					if (DurationofDrug.equalsIgnoreCase(String.valueOf(diffMinutes))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Therapy Duration  in Minute Matches",
								true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL,
								"Calculated Therapy Duration  in Minute Doesnt Matches", true);
					}
				} else if (DurationofDrugDD.equalsIgnoreCase("Second")) {
					if (DurationofDrug.equalsIgnoreCase(String.valueOf(diffSeconds))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Therapy Duration  in Second Matches",
								true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL,
								"Calculated Therapy Duration  in Second Doesnt Matches", true);
					}
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Therapy Duration is not getting AutoCalculated", true);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Auto calculating of Thearpy Duration Fails", true);

		}
		Reports.ExtentReportLog("", Status.INFO, "Auto calculating of Thearpy Duration Ends", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Automatic calculation of Unit Dose in
	 *             Products Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @throws ParseException
	 * @throws java.text.ParseException
	 * @Date : 15-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AutocalculationofUnitDoseandTotalDose() {
		Reports.ExtentReportLog("", Status.INFO, "Auto calculating of Unit Dose and Total Dose Ends", true);
		try {
			agClick(FDE_ProductsPageObjects.unitDose_TextField);
			String UnitDose = agGetAttribute("title", FDE_ProductsPageObjects.unitDose_TextField);
			agClick(FDE_ProductsPageObjects.frequency_TextField);
			String Frequency = agGetAttribute("title", FDE_ProductsPageObjects.frequency_TextField);
			agClick(FDE_ProductsPageObjects.frequencyTime_TextField);
			String FrequencyTime = agGetAttribute("title", FDE_ProductsPageObjects.frequencyTime_TextField);
			agClick(FDE_ProductsPageObjects.dailyDose_TextField);
			String Dailydosetextfield = agGetAttribute("title", FDE_ProductsPageObjects.dailyDose_TextField);
			agClick(FDE_ProductsPageObjects.totaldose_TextField);
			String TotalDosetextfield = agGetAttribute("title", FDE_ProductsPageObjects.totaldose_TextField);
			agClick(FDE_ProductsPageObjects.durationOfDrugAdministration_TextField);
			String DurationofDrug = agGetAttribute("title",
					FDE_ProductsPageObjects.durationOfDrugAdministration_TextField);
			if (UnitDose.equals("") || Frequency.equals("") || Dailydosetextfield.equals("")
					|| TotalDosetextfield.equals("") || DurationofDrug.equals("")) {
				Reports.ExtentReportLog("", Status.INFO, "No Data Found to Calculate UnitDose and TotalDose", true);
			} else {

				double UnitDoseValue = Double.parseDouble(UnitDose);
				double FrequencyValue = Double.parseDouble(Frequency);
				double FrequencyTimeValue = Double.parseDouble(FrequencyTime);
				double DurationofDrugValue = Double.parseDouble(DurationofDrug);
				// double DailyDoseValue=Double.parseDouble(Dailydosetextfield);
				LocalDate currentdate = LocalDate.now();
				ArrayList<Integer> Al = new ArrayList<>();
				double d = 1;
				double d1 = 0;

				String FrequencyTimeDDValue = agGetText(FDE_ProductsPageObjects.FrequencyTimeDD);

				if (FrequencyTimeDDValue.equalsIgnoreCase("Year ( Y )")) {
					for (int i = 0; i < FrequencyTimeValue; i++) {
						LocalDate yearLater = currentdate.plusYears(i);
						Al.add(i, yearLater.lengthOfYear());
						d1 = d1 + yearLater.lengthOfYear();
					}

				} else if (FrequencyTimeDDValue.equalsIgnoreCase("Month ( M )")) {
					for (int i = 0; i < FrequencyTimeValue; i++) {
						Month M = currentdate.getMonth().plus(i);
						Al.add(i, M.maxLength());

						if (M.maxLength() > 12) {
							if (currentdate.isLeapYear()) {
								d = d + M.maxLength();
								d1 = d;
							} else {
								d1 = d1 + M.maxLength();
							}
						}
					}
				} else if (FrequencyTimeDDValue.equalsIgnoreCase("Day ( D )")) {
					d1 = FrequencyTimeValue;
				} else if (FrequencyTimeDDValue.equalsIgnoreCase("Week ( W )")) {
					d1 = FrequencyTimeValue * 7;
				} else {
					Reports.ExtentReportLog("", Status.INFO, "Daily Dose will calculated only in Days", true);

				}

				double DailyDose = (UnitDoseValue * FrequencyValue) / d1;
				if (!String.valueOf(Dailydosetextfield).isEmpty()) {
					double DailyDoseValue = Double.parseDouble(Dailydosetextfield);
					if (String.valueOf(DailyDose).substring(0, 2)
							.equalsIgnoreCase(String.valueOf(DailyDoseValue).substring(0, 2))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Daily Dose Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Daily Dose Doesnt Matches", true);
					}

				}
				double TotalDose = Double.parseDouble(Dailydosetextfield) * DurationofDrugValue;

				if (!String.valueOf(TotalDosetextfield).isEmpty()) {
					double TotalDoseValue = Double.parseDouble(TotalDosetextfield);
					System.out.print(TotalDoseValue);
					System.out.print(TotalDose);
					if (String.valueOf(TotalDoseValue).equalsIgnoreCase(String.valueOf(TotalDose))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Total Dose Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Total Dose Doesnt Matches", true);
					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Auto calculating of Unit Dose and Total Dose Fails", true);

		}
		Reports.ExtentReportLog("", Status.INFO, "Auto calculating of Unit Dose and Total Dose Ends", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Auto calculating the Product flag based on
	 *             the inputs provided in the product library(Script has to be
	 *             changed based on Excel Values)
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @Date : 22-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AutocalculatingProductflagbasedoninputsprovidedinproductlibrary() {
		Reports.ExtentReportLog("", Status.INFO,
				"Auto calculating Product flag based on inputs provided in product library is started", true);
		try {
			FDE_Operations.tabNavigation("Product(s)");
			agSetStepExecutionDelay("3000");
			Constants.driver.switchTo().activeElement();
			agClick(FDE_ProductsPageObjects.ProductDescriptionTextBox);
			String ProductDescription = agGetAttribute("title", FDE_ProductsPageObjects.ProductDescriptionTextBox);
			System.out.print(ProductDescription);
			agSetStepExecutionDelay("3000");
			String ProductFlag = agGetText(FDE_ProductsPageObjects.ProductFlagDDValue);
			if (ProductDescription.equalsIgnoreCase("Azibact")) {
				if (ProductFlag.equalsIgnoreCase("Medical Device")) {
					Reports.ExtentReportLog("", Status.PASS, "Product Flag Value Matches for Azibact", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Product Flag Value Doesnt Matches", true);
				}
			} else if (ProductDescription.equalsIgnoreCase("Ameel-M")) {
				if (ProductFlag.equalsIgnoreCase("Cosmetics")) {
					Reports.ExtentReportLog("", Status.PASS, "Product Flag Value Matches for Ameel-M", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Product Flag Value Doesnt Matches", true);

				}
			} else if (ProductDescription.equalsIgnoreCase("Auto-DOLO FRESH")) {
				if (ProductFlag.equalsIgnoreCase("Combination") || ProductFlag.equalsIgnoreCase("Drug")) {
					Reports.ExtentReportLog("", Status.PASS, "Product Flag Value Matches for Auto-DOLO FRESH", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Product Flag Value Doesnt Matches", true);
				}

			} else if (ProductDescription.equalsIgnoreCase("Auto-Zetamate Plus")
					|| ProductDescription.equalsIgnoreCase("Mr Calpol")) {
				if (ProductFlag.equalsIgnoreCase("Drug")) {
					Reports.ExtentReportLog("", Status.PASS, "Product Flag Value Matches for Auto-Zetamate Plus", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Product Flag Value Doesnt Matches", true);

				}

			} else if (ProductDescription.equalsIgnoreCase("Sinarest")) {
				if (ProductFlag.equalsIgnoreCase("Vaccine")) {
					Reports.ExtentReportLog("", Status.PASS, "Product Flag Value Matches for Sinarest", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Product Flag Value Doesnt Matches", true);
				}

			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Product Flag Value Has not Set", true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Auto calculating Product flag based on inputs provided in product library Fails", true);

		}
		Reports.ExtentReportLog("", Status.INFO,
				"Auto calculating Product flag based on inputs provided in product library Ends", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Clear PhPID and PhPID Version Date /
	 *             Number fields
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 4-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clearPhPID() {
		agClearText(FDE_ProductsPageObjects.PhPID_Txtbox);
		agClearText(FDE_ProductsPageObjects.PhPIDverDateNumber_Txtbox);
	}

	/**********************************************************************************************************
	 * @Objective: To Clik on Therapie tab
	 * @InputParameters: position, runTimeLabel
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 05-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickTherapie(String position, String TherapieName) {
		agSetStepExecutionDelay("5000");
		agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.indicationScroll);
		agClick(FDE_ProductsPageObjects.clickTherapie(position, TherapieName));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective:Verify rollover from Parent Route of Administration Term ID
	 *                   [G.k.4.r.12b] to Parent's Route Of Admin
	 *                   [G.k.4.r.11/B.4.k.9] upon save, import and export of the
	 *                   case.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 18-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyParentRouteOfAdmin_RollOver() {
		Reports.ExtentReportLog("", Status.INFO,
				"Auto Rollover verification of Parent Route of Administration Term ID in product tab is started", true);
		try {
			FDE_Operations.tabNavigation("Product(s)");
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorScrollToElement(
					(FDE_ProductsPageObjects.labelname).replace("%label%", FDE_ProductsPageObjects.therapyEndDate));
			String parentRouteofAdminTermID = agGetText(FDE_ProductsPageObjects
					.productDropdownSelect(FDE_ProductsPageObjects.parentRouteOfAdministrationTermID_Dropdown));
			CommonOperations.takeScreenShot();
			System.out.println(parentRouteofAdminTermID);
			String parentRouteofAdmin = agGetText(FDE_ProductsPageObjects.clickparentsRouteOfAdmin);
			CommonOperations.takeScreenShot();
			System.out.println(parentRouteofAdmin);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (parentRouteofAdminTermID.equalsIgnoreCase("--Select--")) {
				Reports.ExtentReportLog("", Status.INFO,
						"Auto Rollover verification of Parent Route of Administration Term ID in product is not selected",
						true);
			} else if (parentRouteofAdminTermID.equalsIgnoreCase(parentRouteofAdmin)) {
				Reports.ExtentReportLog("", Status.PASS,
						"Auto Rollover verification of Parent Route of Administration Term ID in product is matched",
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Auto Rollover verification of Parent Route of Administration Term ID in product is not matched",
						true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Auto Rollover verification of Parent Route of Administration Term ID in product tab is not verified"
							+ e,
					true);
		}
		Reports.ExtentReportLog("", Status.INFO,
				"Auto Rollover verification of Parent Route of Administration Term ID in product tab is ended", true);
	}

	/**********************************************************************************************************
	 * @Objective:Verify rollover from Form of Admin [G.k.4.r.9.1/B.4.k.7] to
	 *                   Pharmaceutical Dose Form Term ID [G.k.4.r.9.2b] upon save,
	 *                   import and export of the case.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 18-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyPharmaceuticalDoseFormTermID_RollOver() {
		Reports.ExtentReportLog("", Status.INFO,
				"Auto Rollover verification of Pharmaceutical Dose Form Term ID in product tab is started", true);
		try {
			String DoseFormTermIDFromExcel = null;
			FDE_Operations.tabNavigation("Product(s)");
			String formofAdmin = agGetText(
					FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.formOfAdmin_Dropdown));
			System.out.println(formofAdmin);
			agClick(FDE_ProductsPageObjects.PharmaceuticalTermID_TxtField);
			String doseFormTermIDFromApp = agGetAttribute("title",
					FDE_ProductsPageObjects.PharmaceuticalTermID_TxtField);
			System.out.println(doseFormTermIDFromApp);
			agJavaScriptExecuctorScrollToElement(
					(FDE_ProductsPageObjects.labelname).replace("%label%", FDE_ProductsPageObjects.therapyEndDate));
			agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
			agSetStepExecutionDelay("2000");
			agMouseHover(FDEMoreOptionsPageObjects.E2BTagsNavigationUnderMoreoptions);
			agClick(FDEMoreOptionsPageObjects.E2BTagsNavigationUnderMoreoptions);
			String checkBoxStatus = agGetAttribute("class",
					FDEMoreOptionsPageObjects.E2BTagsMoreOptions("Code List IDs"));
			if (checkBoxStatus.contains("ui-icon-blank")) {
				agClick(FDEMoreOptionsPageObjects.E2BTagsMoreOptions("Code List IDs"));
				agSetStepExecutionDelay("2000");
			} else if (checkBoxStatus.contains("ui-icon-check")) {
				Reports.ExtentReportLog("", Status.INFO, "Code List IDs checkbox checked", true);
			}
			CommonOperations.takeScreenShot();
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			String getcodelist = agGetText(FDE_ProductsPageObjects.getCodelist(
					FDE_ProductsPageObjects.formOfAdmin_Dropdown, FDE_ProductsPageObjects.formofAdminCodelist));
			String data1 = getcodelist.substring(getcodelist.lastIndexOf("["));
			String codelistFormofAdmin = data1.substring(1, data1.indexOf("]")).trim();
			System.out.println(codelistFormofAdmin);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "CodeList_FormOfAdmin");
			if (formofAdmin.equalsIgnoreCase("--Select--") || formofAdmin.equalsIgnoreCase("SELECTTS")) {
				Reports.ExtentReportLog("", Status.INFO,
						"Auto Rollover verification of Form of Admin in product is not selected", true);
				return;
			} else {
				DoseFormTermIDFromExcel = Multimaplibraries.getTestDataCellValue(formofAdmin, "CodeList");
				System.out.println(DoseFormTermIDFromExcel);
			}
			if (doseFormTermIDFromApp.isEmpty()) {
				Reports.ExtentReportLog("", Status.PASS,
						"Auto Rollover verification of Pharmaceutical Dose Form Term ID in product tab is not present",
						true);
			} else if (doseFormTermIDFromApp.equalsIgnoreCase(DoseFormTermIDFromExcel)) {
				Reports.ExtentReportLog("", Status.PASS,
						"Auto Rollover verification of Pharmaceutical Dose Form Term ID in product tab is matched",
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Auto Rollover verification of Pharmaceutical Dose Form Term ID in product tab is not matched",
						true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Auto Rollover verification of Pharmaceutical Dose Form Term ID in product tab is not verified" + e,
					true);
		}
		Reports.ExtentReportLog("", Status.INFO,
				"Auto Rollover verification of Pharmaceutical Dose Form Term ID in product tab is ended", true);
	}

	/**********************************************************************************************************
	 * @Objective:Verify rollover from Route of ADMIN (R2) [B.4.k.8] to Route of
	 *                   Admin Term ID (R3) [G.k.4.r.10.2b] upon save, import and
	 *                   export of the case.
	 * 
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 23-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyRouteofAdminTermID_RollOver() {
		Reports.ExtentReportLog("", Status.INFO,
				"Auto Rollover verification of Route Of Administration TermID in product tab is started", true);
		try {
			String routeofAdminTermIDExcel = null;
			FDE_Operations.tabNavigation("Product(s)");
			String routeofAdmin = agGetText(
					FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.routeOfAdmin_Dropdown));
			System.out.println(routeofAdmin);
			agClick(FDE_ProductsPageObjects.routeofAdministrationTermID);
			String routeofAdminTermIDFromApp = agGetAttribute("title",
					FDE_ProductsPageObjects.routeofAdministrationTermID);
			System.out.println(routeofAdminTermIDFromApp);
			agJavaScriptExecuctorScrollToElement(
					(FDE_ProductsPageObjects.labelname).replace("%label%", FDE_ProductsPageObjects.therapyEndDate));
			agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
			agSetStepExecutionDelay("2000");
			agMouseHover(FDEMoreOptionsPageObjects.E2BTagsNavigationUnderMoreoptions);
			agClick(FDEMoreOptionsPageObjects.E2BTagsNavigationUnderMoreoptions);
			String checkBoxStatus = agGetAttribute("class",
					FDEMoreOptionsPageObjects.E2BTagsMoreOptions("Code List IDs"));
			if (checkBoxStatus.contains("ui-icon-blank")) {
				agClick(FDEMoreOptionsPageObjects.E2BTagsMoreOptions("Code List IDs"));
				agSetStepExecutionDelay("2000");
			} else if (checkBoxStatus.contains("ui-icon-check")) {
				Reports.ExtentReportLog("", Status.INFO, "Code List IDs checkbox checked", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			String getcodelist = agGetText(FDE_ProductsPageObjects.getCodelist(
					FDE_ProductsPageObjects.routeOfAdmin_Dropdown, FDE_ProductsPageObjects.routeofAdminCodelist));
			String data1 = getcodelist.substring(getcodelist.lastIndexOf("["));
			String codelistFormofAdmin = data1.substring(1, data1.indexOf("]")).trim();
			System.out.println(codelistFormofAdmin);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "CodeList_RouteOfAdmin");
			if (routeofAdmin.equalsIgnoreCase("--Select--") || routeofAdmin.equalsIgnoreCase("SELECTTS")) {
				Reports.ExtentReportLog("", Status.INFO,
						"Auto Rollover verification of Route of Admin in product is not selected", true);
				return;
			} else {
				routeofAdminTermIDExcel = Multimaplibraries.getTestDataCellValue(routeofAdmin, "CodeList");
				System.out.println(routeofAdminTermIDExcel);
			}
			if (routeofAdminTermIDFromApp.isEmpty()) {
				Reports.ExtentReportLog("", Status.PASS,
						"Auto Rollover verification of Route Of Administration TermID in product tab is not present",
						true);
			} else if (routeofAdminTermIDFromApp.equalsIgnoreCase(routeofAdminTermIDExcel)) {
				Reports.ExtentReportLog("", Status.PASS,
						"Auto Rollover verification of Route Of Administration TermID in product tab is matched", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Auto Rollover verification of Route Of Administration TermID in product tab is not matched",
						true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Auto Rollover verification of Route Of Administration TermID in product tab is not verified" + e,
					true);
		}
		Reports.ExtentReportLog("", Status.INFO,
				"Auto Rollover verification of Route Of Administration TermID in product tab is ended", true);
	}

	/**********************************************************************************************************
	 * @Objective: This function is created to verify Coding window -- Products,
	 *             Indications Based on User Previleges, blinded or unblinded
	 *             products and product indications are shown along with coding
	 *             status in Coding Status window/split screen.
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 16-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void blindedUnBlindedProdShowninCodeWindowforPreveligedUser(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO,
				"Blinded Unblinded products and indication terms are coded for preveliged user is started", true);
		try {
			// agJavaScriptExecuctorScrollToElement(
			// FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.reportType_Dropdown));
			String reportType = agGetText(
					FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.reportType_Dropdown));
			Reports.ExtentReportLog("", Status.INFO, "Report Type Dropdown :" + reportType, true);
			FDE_Operations.tabNavigation("Study");
			if (agIsVisible(FDE_StudyPageObjects.studyConfirmationPopUp_Message) == true) {
				FDE_Study.handleValidationMessageforNonStudy();
			}
			String clinicalTrial = agGetText(
					FDE_StudyPageObjects.get_DropDownValue(FDE_StudyPageObjects.studyType_DropDown));
			Reports.ExtentReportLog("", Status.INFO, "Study Type Dropdown :" + clinicalTrial, true);
			String caseCodeBroken = agGetText(
					FDE_StudyPageObjects.clickDroprdown(FDE_StudyPageObjects.caseCodeBroken_DropDown));
			if (caseCodeBroken.equalsIgnoreCase("Code not broken")) {
				FDE_Study.setCaseCodeBroken(scenarioName);// BlindingUnblinding
			}
			FDE_Operations.tabNavigation("Product(s)");
			if (clinicalTrial.equalsIgnoreCase("Clinical Trials") && reportType.equalsIgnoreCase("Report from study")) {
				if (!agIsVisible(FDE_ProductsPageObjects.unBlinded_link) == true
						&& !agIsVisible(FDE_ProductsPageObjects.blindedProductLink) == true
						&& agIsVisible(FDE_ProductsPageObjects.addUnblindedProduct_Btn) == true) {
					add_UnblindedProduct("AddUnblindedProduct");
					FDE_Operations.LSMVSaveReconsile();
				}
				agSetStepExecutionDelay("3000");
				compareBlindedUnblindedProductAndIndicationForPrevilegedUser(scenarioName);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			} else {
				Reports.ExtentReportLog("", Status.INFO, "Case is not a Clinical trial and Non study case ", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.INFO,
					"Blinded and unblinded indication terms and products coded not verified" + e, true);
		}
		Reports.ExtentReportLog("", Status.INFO,
				"Blinded Unblinded products and indication terms are coded for preveliged user is ended", true);
	}

	/**********************************************************************************************************
	 * @Objective: This function is created to verify the blinded and unblinded
	 *             products indication terms for preveliged user
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 17-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void compareBlindedUnblindedProductAndIndicationForPrevilegedUser(String scenarioName) {
		ArrayList<String> blindedIndication = new ArrayList<>();
		ArrayList<String> unblindedIndication = new ArrayList<>();
		ArrayList<String> indicationCode = new ArrayList<>();

		ArrayList<String> blindedProduct = new ArrayList<>();
		ArrayList<String> unblindedProduct = new ArrayList<>();
		ArrayList<String> productCode = new ArrayList<>();

		// Verifies only one product
		unBlindedProductCodeVerification(scenarioName);

		ArrayList<String> unBlindedProdList = getUnBlindedProductList();
		ArrayList<String> unBlindedIndList = getIndicationTermsforUnBlindedProductList();
		agSetStepExecutionDelay("3000");
		agAssertVisible(FDE_ProductsPageObjects.product_Link(FDE_Study.getData(scenarioName, "BlindedProduct_1")));
		agJavaScriptExecuctorClick(
				FDE_ProductsPageObjects.product_Link(FDE_Study.getData(scenarioName, "BlindedProduct_1")));

		// Verifies only one product
		blindedProductCodeVerification(scenarioName);

		ArrayList<String> blindedProdList = getBlindedProductList();
		ArrayList<String> blindedIndList = getIndicationTermsforBlindedProductList();

		// Coded Screen
		ArrayList<String> prodCodeList = getProductinCodedList();
		ArrayList<String> indicationCodeList = getIndicationTermsinCodedList();

		blindedIndication.addAll(blindedIndList);// Al-blinded
		unblindedIndication.addAll(unBlindedIndList);// Al1-unblinded
		indicationCode.addAll(indicationCodeList);// Al2-indication code

		blindedProduct.addAll(blindedProdList);// Al-blinded
		unblindedProduct.addAll(unBlindedProdList);// Al1-unblinded
		productCode.addAll(prodCodeList);// Al2-product code

		// Compares unblinded indication term
		try {
			for (int i = 0; i < unblindedIndication.size(); i++) {
				String unblindIndication = unblindedIndication.get(i).toString();
				for (int j = 0; j < indicationCode.size(); j++) {
					String compare = indicationCode.get(j).toString();
					if (unblindIndication.equalsIgnoreCase(compare)) {
						Reports.ExtentReportLog("", Status.PASS,
								" Unblinded indication terms matches in Coded screen " + unblindIndication, true);
						String codedSrc = agGetAttribute("src",
								FDE_ProductsPageObjects.getIndicationStatus(Integer.toString(j + 1)));
						if (codedSrc.contains("greenCheck")) {
							Reports.ExtentReportLog("", Status.PASS,
									" Unblinded indication Status coded " + unblindIndication, true);
						} else if (codedSrc.contains("delete")) {

							Reports.ExtentReportLog("", Status.PASS,
									" Unblinded indication Status not coded " + unblindIndication, true);
						} else {
							Reports.ExtentReportLog("", Status.FAIL,
									" Unblinded indication Coded Status not visible " + unblindIndication, true);
						}
						break;
					}
				}
			}
			// Compares blinded indication term
			for (int i = 0; i < blindedIndication.size(); i++) {
				String blindIndication = blindedIndication.get(i).toString();
				for (int j = 0; j < indicationCode.size(); j++) {
					String compare = indicationCode.get(j).toString();
					if (blindIndication.equalsIgnoreCase(compare)) {
						Reports.ExtentReportLog("", Status.PASS,
								" blinded indication terms matches in Coded screen " + blindIndication, true);
						String codedSrc = agGetAttribute("src",
								FDE_ProductsPageObjects.getIndicationStatus(Integer.toString(j + 1)));

						if (codedSrc.contains("greenCheck")) {
							Reports.ExtentReportLog("", Status.PASS,
									" blinded indication Status coded " + blindIndication, true);
						} else if (codedSrc.contains("delete")) {
							Reports.ExtentReportLog("", Status.PASS,
									" blinded indication Status not coded " + blindIndication, true);
						} else {
							Reports.ExtentReportLog("", Status.FAIL,
									" blinded indication Coded Status not visible " + blindIndication, true);
						}
						break;
					}

				}

			}

			// Compares blinded product list
			for (int i = 0; i < blindedProduct.size(); i++) {
				String blindproduct = blindedProduct.get(i).toString();
				for (int j = 0; j < productCode.size(); j++) {
					String compare = productCode.get(j).toString();
					if (blindproduct.equalsIgnoreCase(compare)) {
						Reports.ExtentReportLog("", Status.PASS,
								" blinded product matches in Coded screen " + blindproduct, true);
						String codedSrc = agGetAttribute("src",
								FDE_ProductsPageObjects.getProductStatus(Integer.toString(j + 1)));

						if (codedSrc.contains("greenCheck")) {
							Reports.ExtentReportLog("", Status.PASS, " blinded product Status coded " + blindproduct,
									true);
						} else if (codedSrc.contains("delete")) {
							Reports.ExtentReportLog("", Status.PASS,
									" blinded product Status not coded " + blindproduct, true);
						} else {
							Reports.ExtentReportLog("", Status.FAIL,
									" blinded product Coded Status not visible " + blindproduct, true);
						}
						break;
					}
				}
			}

			// Compares Unblinded product list
			for (int i = 0; i < unblindedProduct.size(); i++) {
				String unblindproduct = unblindedProduct.get(i).toString();
				for (int j = 0; j < productCode.size(); j++) {
					String compare = productCode.get(j).toString();
					if (unblindproduct.equalsIgnoreCase(compare)) {
						Reports.ExtentReportLog("", Status.PASS,
								" unblinded product matches in Coded screen " + unblindproduct, true);
						String codedSrc = agGetAttribute("src",
								FDE_ProductsPageObjects.getProductStatus(Integer.toString(j + 1)));

						if (codedSrc.contains("greenCheck")) {
							Reports.ExtentReportLog("", Status.PASS,
									" Unblinded product Status coded " + unblindproduct, true);
						} else if (codedSrc.contains("delete")) {
							Reports.ExtentReportLog("", Status.PASS,
									" Unblinded product Status not coded " + unblindproduct, true);
						} else {
							Reports.ExtentReportLog("", Status.FAIL,
									" Unblinded product Status Coded not visible " + unblindproduct, true);
						}
						break;
					}

				}
			}
			agClick(FDE_ProductsPageObjects.arrowIcon);
		} catch (Exception e) {
			e.printStackTrace();
			agClick(FDE_ProductsPageObjects.arrowIcon);
			Reports.ExtentReportLog("", Status.FAIL,
					" Verification of Blinded and Unblinded Indication Terms and Products for PreveligedUser not verified"
							+ e,
					true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify product blinded or not
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 15-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void blindedProductCodeVerification(String scenarioName) {
		List<WebElement> getProdCode = agGetElementList(FDE_ProductsPageObjects.suspectProductCodedlist);
		for (int i = 0; i < getProdCode.size(); i++) {
			String prodCode = agGetAttribute("class", FDE_ProductsPageObjects.getProductCode(Integer.toString(i + 1)));
			if (prodCode.contains("suspectProductCoded")) {
				Reports.ExtentReportLog("", Status.PASS, "Product is coded ", true);
			} else if (prodCode.contains("suspectProductNotCoded")) {
				Reports.ExtentReportLog("", Status.PASS, "Product is not Coded ", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Product is not Coded ", true);
			}

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify product Unblinded or not
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 15-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void unBlindedProductCodeVerification(String scenarioName) {
		List<WebElement> getProdCode = agGetElementList(FDE_ProductsPageObjects.suspectProductCodedlist);
		for (int i = 0; i < getProdCode.size(); i++) {
			String prodCode = agGetAttribute("class", FDE_ProductsPageObjects.getProductCode(Integer.toString(i + 1)));
			if (prodCode.contains("suspectProductCoded")) {
				Reports.ExtentReportLog("", Status.PASS, "Product is coded ", true);
			} else if (prodCode.contains("suspectProductNotCoded")) {
				Reports.ExtentReportLog("", Status.PASS, "Product is not Coded ", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Product is not Coded ", true);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: This function is created to get the unblinded products
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 20-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> getUnBlindedProductList() {
		ArrayList Al = new ArrayList<>();
		agSetStepExecutionDelay("3000");
		agClick(FDE_ProductsPageObjects.productDescription_Lookupfield);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		String unBlindedProduct = agGetAttribute("value", FDE_ProductsPageObjects.productDescription_Lookupfield);
		List<String> list = Arrays.asList(unBlindedProduct.toString());
		Al.addAll(list);

		return Al;
	}

	/**********************************************************************************************************
	 * @Objective: This function is created to get the unblinded products indication
	 *             terms
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 17-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static ArrayList<String> getIndicationTermsforUnBlindedProductList() {
		ArrayList Al = new ArrayList<>();
		// get Unblinded indication Terms
		// agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.indicationLabel);
		agClick(FDE_ProductsPageObjects.indicationtab);
		List<WebElement> unBlindedProdIndicationList = agGetElementList(
				FDE_ProductsPageObjects.getListOfIndicationTerms);
		for (int i = 0; i < unBlindedProdIndicationList.size(); i++) {
			agSetStepExecutionDelay("3000");
			agIsVisible(FDE_ProductsPageObjects.getIndication(Integer.toString(i)));
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.getIndication(Integer.toString(i)));
			agClick(FDE_ProductsPageObjects.therapiestab);
			agClick(FDE_ProductsPageObjects.productEmdedDropdownSelect(FDE_ProductsPageObjects.frequencyTime_dropdown));
			agClick(FDE_ProductsPageObjects.indicationtab);
			agClick(FDE_ProductsPageObjects.getIndication(Integer.toString(i)));
			String getUnblindedIndicationTerm = agGetAttribute("title",
					FDE_ProductsPageObjects.getIndication(Integer.toString(i)));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			List<String> list = Arrays.asList(getUnblindedIndicationTerm.toString());
			Al.addAll(i, list);
			System.out.println(Al);
		}

		return Al;
	}

	/**********************************************************************************************************
	 * @Objective: This function is created to get the blinded products for
	 *             unpreveliged user
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 20-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> getBlindedProductList() {
		ArrayList Al = new ArrayList<>();
		try {
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.productDescription_Lookupfield);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			String blindedProduct = agGetAttribute("value", FDE_ProductsPageObjects.productDescription_Lookupfield);
			List<String> list = Arrays.asList(blindedProduct.toString());
			Al.addAll(list);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return Al;
	}

	/**********************************************************************************************************
	 * @Objective: This function is created to get the blinded products indication
	 *             terms
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 17-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> getIndicationTermsforBlindedProductList() {
		// get blinded indication Terms
		ArrayList Al = new ArrayList<>();
		agSetStepExecutionDelay("5000");
		// agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.indicationLabel);
		agClick(FDE_ProductsPageObjects.indicationtab);
		List<WebElement> blindedProdIndicationList = agGetElementList(FDE_ProductsPageObjects.getListOfIndicationTerms);
		for (int j = 0; j < blindedProdIndicationList.size(); j++) {
			agSetStepExecutionDelay("3000");
			agIsVisible(FDE_ProductsPageObjects.getIndication(Integer.toString(j)));
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.getIndication(Integer.toString(j)));
			agClick(FDE_ProductsPageObjects.therapiestab);
			agClick(FDE_ProductsPageObjects.productEmdedDropdownSelect(FDE_ProductsPageObjects.frequencyTime_dropdown));
			agClick(FDE_ProductsPageObjects.indicationtab);
			agClick(FDE_ProductsPageObjects.getIndication(Integer.toString(j)));
			String getBlindedIndicationTerm = agGetAttribute("title",
					FDE_ProductsPageObjects.getIndication(Integer.toString(j)));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			List<String> list = Arrays.asList(getBlindedIndicationTerm.toString());
			Al.addAll(j, list);
			System.out.println(Al);

		}
		return Al;
	}

	/**********************************************************************************************************
	 * @Objective: This function is created to get the blinded and unblinded
	 *             products in coded window
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 20-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> getProductinCodedList() {
		codeWindow();
		List<WebElement> prodDescriptionList = agGetElementList(FDE_ProductsPageObjects.prodDescriptionList);
		ArrayList Al = new ArrayList<>();
		for (int i = 0; i <= prodDescriptionList.size(); i++) {
			agIsVisible(FDE_ProductsPageObjects.getProductDescription(Integer.toString(i + 1)));
			String getProduct = agGetText(FDE_ProductsPageObjects.getProductDescription(Integer.toString(i + 1)));
			List<String> list = Arrays.asList(getProduct.toString());
			Al.addAll(i, list);
			System.out.println(Al);
		}
		return Al;
	}

	/**********************************************************************************************************
	 * @Objective: This function is created navigate to CodeWindow screen
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 20-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void codeWindow() {
		agSetStepExecutionDelay("2000");
		if (agIsVisible(FDE_ProductsPageObjects.codedIcon) == true) {
			agClick(FDE_ProductsPageObjects.codedIcon);
		} else if (agIsVisible(FDE_ProductsPageObjects.partialCodedIcon) == true) {
			agClick(FDE_ProductsPageObjects.partialCodedIcon);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: This function is created to get the indication terms in coded
	 *             window
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 17-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> getIndicationTermsinCodedList() {
		codeWindow();
		ArrayList Al = new ArrayList<>();
		agSetStepExecutionDelay("3000");
		if (agIsVisible(FDE_ProductsPageObjects.getListOfIndicationinCode) == true) {
			List<WebElement> codeindicationlist = agGetElementList(FDE_ProductsPageObjects.getListOfIndicationinCode);

			for (int i = 0; i < codeindicationlist.size(); i++) {
				agIsVisible(FDE_ProductsPageObjects.getIndicationinCode(Integer.toString(i + 1)));
				String getindidcationTerm = agGetText(
						FDE_ProductsPageObjects.getIndicationinCode(Integer.toString(i + 1)));
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				List<String> list = Arrays.asList(getindidcationTerm.toString());
				if (list.toString().length() > 1) {
					Al.addAll(i, list);
				}
				System.out.println(Al);
			}
		} else {
			Reports.ExtentReportLog("", Status.PASS, " Indication Terms not visible ", true);
		}
		return Al;
	}

	/**********************************************************************************************************
	 * @Objective: This function is created to verify Coding window -- Products,
	 *             Indications Based on User Previleges, blinded or unblinded
	 *             products and product indications are shown along with coding
	 *             status in Coding Status window/split screen. USER should be
	 *             created with all section access except case management - "allow
	 *             access to unblinded information".
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 15-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void blindedUnBlindedProdShowninCodeWindowforUnPreveligedUser(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO,
				"Blinded Unblinded products and indication terms are coded for unpreveliged user is started", true);
		try {
			FDE_Operations.tabNavigation("General");
			// agJavaScriptExecuctorScrollToElement(
			// FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.reportType_Dropdown));
			String reportType = agGetText(
					FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.reportType_Dropdown));
			Reports.ExtentReportLog("", Status.INFO, "Report Type Dropdown :" + reportType, true);
			FDE_Operations.tabNavigation("Study");
			if (agIsVisible(FDE_StudyPageObjects.studyConfirmationPopUp_Message) == true) {
				FDE_Study.handleValidationMessageforNonStudy();
			}
			String clinicalTrial = agGetText(
					FDE_StudyPageObjects.get_DropDownValue(FDE_StudyPageObjects.studyType_DropDown));
			Reports.ExtentReportLog("", Status.INFO, "Study Type Dropdown :" + clinicalTrial, true);
			String caseCodeBroken = agGetText(
					FDE_StudyPageObjects.clickDroprdown(FDE_StudyPageObjects.caseCodeBroken_DropDown));
			if (caseCodeBroken.equalsIgnoreCase("Code not broken")) {
				FDE_Study.setCaseCodeBroken(scenarioName);// BlindingUnblinding
			}
			FDE_Operations.tabNavigation("Product(s)");
			if (clinicalTrial.equalsIgnoreCase("Clinical Trials") && reportType.equalsIgnoreCase("Report from study")) {
				agSetStepExecutionDelay("3000");
				compareBlindedUnblindedProductAndIndicationForUnPrevilegedUser(scenarioName);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			} else {
				Reports.ExtentReportLog("", Status.INFO, "Case is not a Clinical trial and Non study case ", true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Blinded Unblinded products and indication terms are coded for unpreveliged user is not verified"
							+ e,
					true);
		}
		Reports.ExtentReportLog("", Status.INFO,
				"Blinded Unblinded products and indication terms are coded for unpreveliged user is ended", true);
	}

	/**********************************************************************************************************
	 * @Objective: This function is created to verify the blinded and unblinded
	 *             products indication terms for Unpreveliged user USER2 should be
	 *             created with all section access except case management - "allow
	 *             access to unblinded information".
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 17-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void compareBlindedUnblindedProductAndIndicationForUnPrevilegedUser(String scenarioName) {
		ArrayList<String> blindedIndication = new ArrayList<>();// Al-blindedIndication
		ArrayList<String> indicationCode = new ArrayList<>();// Al2.indicationCode

		ArrayList<String> blindedProduct = new ArrayList<>();// Al-blindedProduct
		ArrayList<String> productCode = new ArrayList<>();// Al2-productCode

		// verifies only one product
		blindedProductCodeVerification(scenarioName);

		// get blinded product and indication term
		ArrayList<String> blindedProductList = getBlindedProductList();
		ArrayList<String> blindedIndicationList = getIndicationTermsforBlindedProductList();

		// Coded Screen
		ArrayList<String> prodCodeList = getProductinCodedList();
		ArrayList<String> indicationCodeList = FDE_Products.getIndicationTermsinCodedList();

		blindedProduct.addAll(blindedProductList);
		blindedIndication.addAll(blindedIndicationList);
		productCode.addAll(prodCodeList);
		indicationCode.addAll(indicationCodeList);

		// Compares blinded indication term
		try {
			for (int i = 0; i < blindedIndication.size(); i++) {
				String blindIndication = blindedIndication.get(i).toString();
				for (int j = 0; j < indicationCode.size(); j++) {
					String compare = indicationCode.get(j).toString();
					if (blindIndication.equalsIgnoreCase(compare)) {
						Reports.ExtentReportLog("", Status.PASS,
								" blinded indication terms matches in Coded screen " + blindIndication, true);
						String codedSrc = agGetAttribute("src",
								FDE_ProductsPageObjects.getIndicationStatus(Integer.toString(j + 1)));

						if (codedSrc.contains("greenCheck")) {
							Reports.ExtentReportLog("", Status.PASS,
									" blinded indication Status coded " + blindIndication, true);
						} else if (codedSrc.contains("delete")) {
							Reports.ExtentReportLog("", Status.PASS,
									" blinded indication Status not coded  " + blindIndication, true);
						} else {
							Reports.ExtentReportLog("", Status.FAIL,
									" blinded indication Coded Status not visible " + blindIndication, true);
						}
						break;
					}
				}
			}

			// Compares blinded product
			for (int i = 0; i < blindedProduct.size(); i++) {
				String blindproduct = blindedProduct.get(i).toString();
				for (int j = 0; j < productCode.size(); j++) {
					String compare = productCode.get(j).toString();
					if (blindproduct.equalsIgnoreCase(compare)) {
						Reports.ExtentReportLog("", Status.PASS,
								" unblinded product matches in Coded screen " + blindproduct, true);
						String codedSrc = agGetAttribute("src",
								FDE_ProductsPageObjects.getProductStatus(Integer.toString(j + 1)));

						if (codedSrc.contains("greenCheck")) {
							Reports.ExtentReportLog("", Status.PASS, " blinded product Status coded " + blindproduct,
									true);
						} else if (codedSrc.contains("delete")) {
							Reports.ExtentReportLog("", Status.PASS,
									" blinded product Status not coded  " + blindproduct, true);
						} else {
							Reports.ExtentReportLog("", Status.FAIL,
									" blinded product Coded Status not visible " + blindproduct, true);
						}
						break;
					}
				}
			}

			agClick(FDE_ProductsPageObjects.arrowIcon);
		} catch (Exception e) {
			e.printStackTrace();
			agClick(FDE_ProductsPageObjects.arrowIcon);
			Reports.ExtentReportLog("", Status.FAIL,
					"Verification of Blinded Product and Indication Terms for UnPreveligedUser not verified " + e,
					true);
		}

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to perform product navigations in
	 *                Product Tab for unblinded products
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 29-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void productTabNavigation(String scenarioName, String colName) {
		agClick(FDE_ProductsPageObjects.product_Navigations(Product_LookupOperations.getData(scenarioName, colName)));
	}

	/**********************************************************************************************************
	 * @Objective: This function is created to verify the blinded product link
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 30-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_BlindedProdLink(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (agIsVisible(FDE_ProductsPageObjects.unBlinded_link) == true
				&& agIsVisible(FDE_ProductsPageObjects.blindedProductLink) == true
				&& agIsVisible(FDE_ProductsPageObjects
						.product_Link(FDE_Study.getData(scenarioName, "BlindedProduct_1"))) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Blinded product link visibe for previlige user", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Blinded product link not visibe for previlige user", true);
		}
		agClick(FDE_ProductsPageObjects.product_Link(FDE_Study.getData(scenarioName, "BlindedProduct_1")));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to get all Non Coded Products
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> getNonCodedProducts(String scenarioName) {
		ArrayList Al = new ArrayList<>();
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(FDE_ProductsPageObjects.navigateProduct(
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductNameAsReported")));
		List<WebElement> getProdNonCode = agGetElementList(FDE_ProductsPageObjects.suspectProductNotCodedlist);
		for (int i = 0; i < getProdNonCode.size(); i++) {
			String prodNonCode = agGetAttribute("class",
					FDE_ProductsPageObjects.getProductCode(Integer.toString(i + 1)));
			List<String> list = Arrays.asList(prodNonCode.toString());
			Al.addAll(list);
		}
		return Al;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to get all Coded Products
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> getCodedProducts(String scenarioName) {
		ArrayList Al = new ArrayList<>();
		if (scenarioName.equalsIgnoreCase("AddUnblindedProduct")) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "Product_LookupOperations");
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects
					.navigateProduct(getTestDataCellValue(scenarioName, "ProductLibraryProductName")));
		}

		if (!scenarioName.equalsIgnoreCase("AddUnblindedProduct")) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.navigateProduct(
					getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductNameAsReported")));
		}
		List<WebElement> getProdCode = agGetElementList(FDE_ProductsPageObjects.suspectProductCodedlist);
		for (int i = 0; i < getProdCode.size(); i++) {
			String prodCode = agGetAttribute("class", FDE_ProductsPageObjects.getProductCode(Integer.toString(i + 1)));
			List<String> list = Arrays.asList(prodCode.toString());
			Al.addAll(list);
		}
		return Al;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created verification for non coded products
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void nonCodedProductVerification(String scenarioName) {
		ArrayList<String> prodNonCode = getNonCodedProducts(scenarioName);
		String nonCodeProduct = agGetText(FDE_ProductsPageObjects.navigateProduct(
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductNameAsReported")));
		if (prodNonCode.contains("suspectProductCoded")) {
			Reports.ExtentReportLog("", Status.FAIL, "Product is coded " + nonCodeProduct, true);
		} else {
			Reports.ExtentReportLog("", Status.PASS, "Product is not Coded " + nonCodeProduct, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created verification for coded products
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void codedProductVerification(String scenarioName) {
		if (scenarioName.equalsIgnoreCase("AddUnblindedProduct")) {
			ArrayList<String> product = getCodedProducts(scenarioName);
			String prodCode = product.toString();
			String codeProduct = agGetText(FDE_ProductsPageObjects
					.navigateProduct(getTestDataCellValue(scenarioName, "ProductLibraryProductName")));
			if (prodCode.contains("suspectProductCoded")) {
				Reports.ExtentReportLog("", Status.PASS, "Product is coded " + codeProduct, true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Product is not coded " + codeProduct, true);
			}
		}
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!scenarioName.equalsIgnoreCase("AddUnblindedProduct")) {
			ArrayList<String> product = getCodedProducts(scenarioName);
			String prodCode = product.toString();
			if (prodCode.contains("suspectProductCoded")) {
				Reports.ExtentReportLog("", Status.PASS, "Product is coded ", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Product is not Coded ", true);
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created verification for coded products in
	 *             split window for preveliged user
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void productsVerification_PrevilgedUser(String scenarioName) {
		ArrayList<String> productCode = new ArrayList<>();
		ArrayList<String> ProductList = getProductNameAsReportedCodedList();
		productCode.addAll(ProductList);

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "Product_LookupOperations");
		String unblindProd = getTestDataCellValue(scenarioName, "ProductLibraryProductName");

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Study");
		String blindProd = getTestDataCellValue(scenarioName, "BlindedProduct_1");

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String nonProd = getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductNameAsReported");

		for (int i = 0; i < productCode.size(); i++) {
			String prodCode = productCode.get(i).toString();
			String[] arrStr = prodCode.split("M");
			String Product = arrStr[0].trim();
			System.out.println(Product);
			if (Product.equalsIgnoreCase(unblindProd)
					|| (Product.equalsIgnoreCase(blindProd) || Product.equalsIgnoreCase(nonProd))) {
				String codedSrc = agGetAttribute("src",
						FDE_ProductsPageObjects.getProductStatus(Integer.toString(i + 1)));

				if (codedSrc.contains("greenCheck")) {
					Reports.ExtentReportLog("", Status.PASS,
							" product Status coded verification done for previlged user  " + Product, true);
				} else if (codedSrc.contains("delete")) {
					Reports.ExtentReportLog("", Status.PASS,
							" product Status not coded verification done for previlged user " + Product, true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, " product Coded Status not visible " + Product, true);
				}

			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created verification for coded products in
	 *             split window for unpreveliged user
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void productsVerification_UnPrevilgedUser(String scenarioName) {
		ArrayList<String> productCode = new ArrayList<>();
		ArrayList<String> ProductList = getProductNameAsReportedCodedList();
		productCode.addAll(ProductList);

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Study");
		String blindProd = getTestDataCellValue(scenarioName, "BlindedProduct_1");

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String nonProd = getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductNameAsReported");

		for (int i = 0; i < productCode.size(); i++) {
			String prodCode = productCode.get(i).toString();
			String[] arrStr = prodCode.split("M");
			String Product = arrStr[0].trim();
			System.out.println(Product);

			if (Product.equalsIgnoreCase(blindProd) || Product.equalsIgnoreCase(nonProd)) {
				String codedSrc = agGetAttribute("src",
						FDE_ProductsPageObjects.getProductStatus(Integer.toString(i + 1)));

				if (codedSrc.contains("greenCheck")) {
					Reports.ExtentReportLog("", Status.PASS,
							" product Status coded verification done for unprevilged user " + Product, true);
				} else if (codedSrc.contains("delete")) {
					Reports.ExtentReportLog("", Status.PASS,
							"  product Status not coded verification done for unprevilged user" + Product, true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "  product Coded Status not visible " + Product, true);
				}
				break;
			}

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created verification for products indication
	 *             in split window
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void indicationsVerification(String scenarioName) {
		ArrayList<String> code = new ArrayList<>();
		ArrayList<String> codeList = getIndicationTermsinCodedList();
		code.addAll(codeList);

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Study");
		String studyIndication = getTestDataCellValue(scenarioName, "Study_Indication");

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String nonindication = getTestDataCellValue(scenarioName,
				"Products_Indications_IndicationMedDRALLTCode_SearchTerm");

		for (int i = 0; i < code.size(); i++) {
			String indication = code.get(i).toString();
			if (indication.equalsIgnoreCase(studyIndication) || (indication.equalsIgnoreCase(nonindication))) {
				String codedSrc = agGetAttribute("src",
						FDE_ProductsPageObjects.getIndicationStatus(Integer.toString(i + 1)));

				if (codedSrc.contains("greenCheck")) {
					Reports.ExtentReportLog("", Status.PASS, "Status coded " + indication, true);
				} else if (codedSrc.contains("delete")) {
					Reports.ExtentReportLog("", Status.PASS, " Status not coded  " + indication, true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, " Status not visible " + indication, true);
				}

			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: This function is created to get the blinded and unblinded
	 *             ProductNameAsReported in coded window
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> getProductNameAsReportedCodedList() {
		codeWindow();
		List<WebElement> prodDescriptionList = agGetElementList(FDE_ProductsPageObjects.prodNameAsReportedList);
		ArrayList Al = new ArrayList<>();
		for (int i = 0; i < prodDescriptionList.size(); i++) {
			agIsVisible(FDE_ProductsPageObjects.getProductNameAsReported(Integer.toString(i + 1)));
			String getProduct = agGetText(FDE_ProductsPageObjects.getProductNameAsReported(Integer.toString(i + 1)));
			List<String> list = Arrays.asList(getProduct.toString());
			Al.addAll(i, list);
			System.out.println(Al);
		}
		return Al;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to perform product link navigation
	 *                Product Tab.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 06-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void product_Link(String scenarioName, String colName) {
		agJavaScriptExecuctorClick(FDE_ProductsPageObjects.product_Link(FDE_Study.getData(scenarioName, colName)));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify product is not coded.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 06-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void NonCodedProductVerification() {
		List<WebElement> getProdCode = agGetElementList(FDE_ProductsPageObjects.suspectProductNotCodedlist);
		for (int i = 0; i < getProdCode.size(); i++) {
			String prodCode = agGetAttribute("class",
					FDE_ProductsPageObjects.getProductNotCode(Integer.toString(i + 1)));
			if (prodCode.contains("suspectProductNotCoded")) {
				Reports.ExtentReportLog("", Status.FAIL, "Product is not coded ", true);
			} else {
				Reports.ExtentReportLog("", Status.PASS, "Product is Coded ", true);
			}
			CommonOperations.takeScreenShot();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify product is coded.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void CodedProductVerification() {
		List<WebElement> getProdCode = agGetElementList(FDE_ProductsPageObjects.suspectProductCodedlist);
		for (int i = 0; i < getProdCode.size(); i++) {
			String prodCode = agGetAttribute("class", FDE_ProductsPageObjects.getProductCode(Integer.toString(i + 1)));
			if (prodCode.contains("suspectProductCoded")) {
				Reports.ExtentReportLog("", Status.PASS, "Product is coded ", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Product is not Coded ", true);
			}
			CommonOperations.takeScreenShot();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Clear Marketing Authorization Holder As
	 *             Reported
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 07-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clearMarketingAuthorizationHolder() {
		agClearText(FDE_ProductsPageObjects.marketingAuthorizationHolderAsReported_Txtbox);
	}

	/**********************************************************************************************************
	 * @Objective: Verify R2 tags in Product tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyProductR2Tags() {
		Reports.ExtentReportLog("", Status.INFO, "********Product R2 tag verification Started*******", true);
		agAssertVisible(FDE_ProductsPageObjects.R2ProductCharacterization);
		agAssertVisible(FDE_ProductsPageObjects.R2ProductNameAsReported);
		agAssertVisible(FDE_ProductsPageObjects.R2CountryObtained);
		agAssertVisible(FDE_ProductsPageObjects.R2ActionTakenWithDrug);
		agAssertVisible(FDE_ProductsPageObjects.R2GestationPeriodAtTimeOfExposure);
		agAssertVisible(FDE_ProductsPageObjects.R2CumulativeDoseToFirstReaction);
		agAssertVisible(FDE_ProductsPageObjects.R2AdditionalDrugInformation);
		agAssertVisible(FDE_ProductsPageObjects.R2ActiveSubstance);
		agAssertVisible(FDE_ProductsPageObjects.R2MAHAsReported);
		agAssertVisible(FDE_ProductsPageObjects.R2ApprovalType);
		agAssertVisible(FDE_ProductsPageObjects.R2AuthorizationCountry);
		agAssertVisible(FDE_ProductsPageObjects.R2AuthorizationNumber);
		agAssertVisible(FDE_ProductsPageObjects.R2IndicationTerm);
		agAssertVisible(FDE_ProductsPageObjects.R2UnitDose);
		agAssertVisible(FDE_ProductsPageObjects.R2Frequency);
		agAssertVisible(FDE_ProductsPageObjects.R2FrequencyTime);
		agAssertVisible(FDE_ProductsPageObjects.R2TherapyStartDate);
		agAssertVisible(FDE_ProductsPageObjects.R2TherapyEndDate);
		agAssertVisible(FDE_ProductsPageObjects.R2DurationOfDrugAdministration);
		agAssertVisible(FDE_ProductsPageObjects.R2FormOfAdmin);
		agAssertVisible(FDE_ProductsPageObjects.R2RouteOfAdmin);
		agAssertVisible(FDE_ProductsPageObjects.R2Lot_BatchNo);
		agAssertVisible(FDE_ProductsPageObjects.R2ParentsRouteOfAdmin);
		agAssertVisible(FDE_ProductsPageObjects.R2DosageText);
		Reports.ExtentReportLog("", Status.INFO, "********Product R2 tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify R3 tags in Product tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyProductR3Tags() {
		Reports.ExtentReportLog("", Status.INFO, "********Product R3 tag verification Started*******", true);
		agAssertVisible(FDE_ProductsPageObjects.R3ProductCharacterization);
		agAssertVisible(FDE_ProductsPageObjects.R3ProductNameAsReported);
		agAssertVisible(FDE_ProductsPageObjects.R3CountryObtained);
		agAssertVisible(FDE_ProductsPageObjects.R3ActionTakenWithDrug);
		agAssertVisible(FDE_ProductsPageObjects.R3InvestigationalProductBlinded);
		agAssertVisible(FDE_ProductsPageObjects.R3GestationPeriodAtTimeOfExposure);
		agAssertVisible(FDE_ProductsPageObjects.R3CumulativeDoseToFirstReaction);
		agAssertVisible(FDE_ProductsPageObjects.R3MedicinalProductIdentifier_MPID);
		agAssertVisible(FDE_ProductsPageObjects.R3MPIDVersionDate_Number);
		agAssertVisible(FDE_ProductsPageObjects.R3PhPID);
		agAssertVisible(FDE_ProductsPageObjects.R3PhPIDVersionDate_Number);
		agAssertVisible(FDE_ProductsPageObjects.R3TrademarkName);
		agAssertVisible(FDE_ProductsPageObjects.R3InventedName);
		agAssertVisible(FDE_ProductsPageObjects.R3ScientificName);
		agAssertVisible(FDE_ProductsPageObjects.R3ContainerName);
		agAssertVisible(FDE_ProductsPageObjects.R3StrengthName);
		agAssertVisible(FDE_ProductsPageObjects.R3FormName);
		agAssertVisible(FDE_ProductsPageObjects.R3DeviceName);
		agAssertVisible(FDE_ProductsPageObjects.R3IntendedUseName);
		agAssertVisible(FDE_ProductsPageObjects.R3AdditionalDrugInformation);
		agAssertVisible(FDE_ProductsPageObjects.R3ActiveSubstance);
		agAssertVisible(FDE_ProductsPageObjects.R3SubstanceTermIDVerDate_Num);
		agAssertVisible(FDE_ProductsPageObjects.R3Substance_SpecifiedSubstanceTermID);
		agAssertVisible(FDE_ProductsPageObjects.R3Strength_Number);
		agAssertVisible(FDE_ProductsPageObjects.R3MAHAsReported);
		agAssertVisible(FDE_ProductsPageObjects.R3ApprovalType);
		agAssertVisible(FDE_ProductsPageObjects.R3AuthorizationCountry);
		agAssertVisible(FDE_ProductsPageObjects.R3AuthorizationNumber);
		agAssertVisible(FDE_ProductsPageObjects.R3IndicationTerm);
		agAssertVisible(FDE_ProductsPageObjects.R3Indication_MedDRALLTCode);
		agAssertVisible(FDE_ProductsPageObjects.R3UnitDose);
		agAssertVisible(FDE_ProductsPageObjects.R3FrequencyTime);
		agAssertVisible(FDE_ProductsPageObjects.R3TherapyStartDate);
		agAssertVisible(FDE_ProductsPageObjects.R3TherapyEndDate);
		agAssertVisible(FDE_ProductsPageObjects.R3DurationOfDrugAdministration);
		agAssertVisible(FDE_ProductsPageObjects.R3FormOfAdmin);
		agAssertVisible(FDE_ProductsPageObjects.R3PharmaceuticalDoseFormTermID);
		agAssertVisible(FDE_ProductsPageObjects.R3PharmaceuticalDoseFormTermIDVerDate_Num);
		agAssertVisible(FDE_ProductsPageObjects.R3RouteOfAdmin);
		agAssertVisible(FDE_ProductsPageObjects.R3RouteOfAdministrationTermID);
		agAssertVisible(FDE_ProductsPageObjects.R3RouteOfAdministrationTermIDVerDateNum);
		agAssertVisible(FDE_ProductsPageObjects.R3LotBatchNo);
		agAssertVisible(FDE_ProductsPageObjects.R3ParentRouteOfAdmin);
		agAssertVisible(FDE_ProductsPageObjects.R3ParentRouteOfAdministrationTermID);
		agAssertVisible(FDE_ProductsPageObjects.R3ParentRouteOfAdministrationTermIDVerDateNum);
		agAssertVisible(FDE_ProductsPageObjects.R3DosageText);
		agAssertVisible(FDE_ProductsPageObjects.R3AdditionalInfoCode);
		Reports.ExtentReportLog("", Status.INFO, "********Product R3 tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify Codelist tags in Product tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 20-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyProductCodeList() {
		Reports.ExtentReportLog("", Status.INFO, "********Product Codelist tag verification Started*******", true);
		agAssertVisible(FDE_ProductsPageObjects.CLProductCharacterization);
		agAssertVisible(FDE_ProductsPageObjects.CLCompanyProduct);
		agAssertVisible(FDE_ProductsPageObjects.CLProductFlag);
		agAssertVisible(FDE_ProductsPageObjects.CLCountryObtained);
		agAssertVisible(FDE_ProductsPageObjects.CLActionTakenWithDrug);
		agAssertVisible(FDE_ProductsPageObjects.CLProductType);
		agAssertVisible(FDE_ProductsPageObjects.CLCodingClass);
		agAssertVisible(FDE_ProductsPageObjects.CLStudyProductType);
		agAssertVisible(FDE_ProductsPageObjects.CLInvestigationalProductBlinded);
		agAssertVisible(FDE_ProductsPageObjects.CLGestationPeriodAtTimeOfExposure);
		agAssertVisible(FDE_ProductsPageObjects.CLCumulativeDoseToFirstReaction);
		agAssertVisible(FDE_ProductsPageObjects.CLLackOfEffect);
		agAssertVisible(FDE_ProductsPageObjects.CLPrioruse);
		agAssertVisible(FDE_ProductsPageObjects.CLPriorUseOfEquivalentDrug);
		agAssertVisible(FDE_ProductsPageObjects.CLBiologicalFatherExposedToDrug);
		agAssertVisible(FDE_ProductsPageObjects.CLTolerated);
		agAssertVisible(FDE_ProductsPageObjects.CLStrength_number);
		agAssertVisible(FDE_ProductsPageObjects.CLApprovalProductFlag);
		agAssertVisible(FDE_ProductsPageObjects.CLApprovalType);
		agAssertVisible(FDE_ProductsPageObjects.CLAuthorizationCountry);
		agAssertVisible(FDE_ProductsPageObjects.CLClassOfDevice);
		agAssertVisible(FDE_ProductsPageObjects.CLMDRType);
		agAssertVisible(FDE_ProductsPageObjects.CLIVDRType);
		agAssertVisible(FDE_ProductsPageObjects.CLDeviceCommercialDate);
		agAssertVisible(FDE_ProductsPageObjects.CLUnitDose);
		agAssertVisible(FDE_ProductsPageObjects.CLFrequencyTime);
		agAssertVisible(FDE_ProductsPageObjects.CLDailyDose);
		agAssertVisible(FDE_ProductsPageObjects.CLTotalDoe);
		agAssertVisible(FDE_ProductsPageObjects.CLFormStrength);
		agAssertVisible(FDE_ProductsPageObjects.CLDurationofDrugAdministration);
		agAssertVisible(FDE_ProductsPageObjects.CLFormOfAdmin);
		agAssertVisible(FDE_ProductsPageObjects.CLRouteOfAdmin);
		agAssertVisible(FDE_ProductsPageObjects.CLParentRouteofAdministrationTermID);
		agAssertVisible(FDE_ProductsPageObjects.CLTherapySite);
		agAssertVisible(FDE_ProductsPageObjects.CLAdditionalInfoCode);
		Reports.ExtentReportLog("", Status.INFO, "********Product Codelist tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to Add Unblinded Button by copying the
	 *                blinded product
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 30-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void copyBlindedProduct(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_ProductsPageObjects.addUnblindedProduct_Btn);
		if (agIsVisible(FDE_ProductsPageObjects.confirmationPopup) == true) {
			CommonOperations.takeScreenShot();
			agClick(FDE_ProductsPageObjects.popUp_YesBtn);
		}
		agSetStepExecutionDelay("2000");
		agClick(FDE_ProductsPageObjects.copyBlindedProd_Btn);
		if (agIsVisible(FDE_ProductsPageObjects.blindedinfo_Label) == true
				|| agIsVisible(FDE_ProductsPageObjects.blindedConfigInfo) == true) {
			agClick(FDE_ProductsPageObjects.blindedpopupOkBtn);
		}
		agIsVisible(FDE_ProductsPageObjects.copiedBlindedText);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to verify the copied blinded product
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 30-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void copyBlindedProduct_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Reports.ExtentReportLog("", Status.INFO, "********Copy Blinded Product verification Started*******", true);
		agAssertContainsText(FDE_ProductsPageObjects.productDescription_Lookupfield,
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"));
		agAssertContainsText(FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.actionTakenWithDrug),
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ActionTakenWithDrug"));
		agAssertContainsText(FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.productFlag),
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductFlag"));
		FDE_Products.verify_ProductIsNotBlinded(scenarioName);
		verifyIndication(scenarioName);
		agAssertContainsText(FDE_ProductsPageObjects.activeSubstance_TextField,
				getTestDataCellValue(scenarioName, "Products_Ingredients_ActiveSubstance"));
		agAssertContainsText(FDE_ProductsPageObjects.unitDose_TextField,
				getTestDataCellValue(scenarioName, "Products_Therapies_UnitDose"));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Therapies_UnitDoseUnit"),
				FDE_ProductsPageObjects.productEmdedDropdownSelect((FDE_ProductsPageObjects.unitDose_dropdown)));
		agAssertContainsText(FDE_ProductsPageObjects.frequency_TextField,
				getTestDataCellValue(scenarioName, "Products_Therapies_Frequency"));
		agAssertContainsText(FDE_ProductsPageObjects.frequencyTime_TextField,
				getTestDataCellValue(scenarioName, "Products_Therapies_FrequencyTime"));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Therapies_FrequencyTimeUnit"),
				FDE_ProductsPageObjects.productEmdedDropdownSelect((FDE_ProductsPageObjects.frequencyTime_dropdown)));
		if (getTestDataCellValue(scenarioName, "Products_Therapies_DailyDose_Manual").equalsIgnoreCase("Check")) {
			verifyData(FDE_ProductsPageObjects.dailyDose_TextField, scenarioName, "Products_Therapies_DailyDose");
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Therapies_DailyDoseUnit"),
					FDE_ProductsPageObjects.productEmdedDropdownSelect((FDE_ProductsPageObjects.dailyDose_dropdown)));
		}
		agClick(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate));
		agCheckPropertyValue("title",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Products_Therapies_TherapyStartDate")),
				FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate));
		verifyData(FDE_ProductsPageObjects.lotNumber_TextField, scenarioName, "Products_Therapies_LotNumber");
		agClick(FDE_ProductsPageObjects.lotExpirationDate_DateField);
		agCheckPropertyValue("title",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Products_Therapies_LotExpirationDate")),
				FDE_ProductsPageObjects.lotExpirationDate_DateField);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Therapies_FormOfAdmin"),
				FDE_ProductsPageObjects.productDropdownSelect((FDE_ProductsPageObjects.formOfAdmin_Dropdown)));
		agCheckPropertyText((getTestDataCellValue(scenarioName, "Products_Therapies_RouteOfAdmin")).trim(),
				FDE_ProductsPageObjects.productDropdownSelect((FDE_ProductsPageObjects.routeOfAdmin_Dropdown)));
		agCheckPropertyText(
				(getTestDataCellValue(scenarioName, "Products_Therapies_ParentRouteOfAdministrationTermID")).trim(),
				FDE_ProductsPageObjects
						.productDropdownSelect((FDE_ProductsPageObjects.parentRouteOfAdministrationTermID_Dropdown)));
		verifyData(FDE_ProductsPageObjects.routeOfAdministrationTermIDVerDateNum_TextField, scenarioName,
				"Products_Therapies_RouteOfAdministrationTermIDVerDateNum");
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to Add Unblinded Button by copying the
	 *                blinded product
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 30-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void selectStudyProduct(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Study");
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.copiedBlindedText);
		agIsVisible(FDE_ProductsPageObjects.selectStudyProd_Btn);
		agJavaScriptExecuctorClick(FDE_ProductsPageObjects.selectStudyProd_Btn);
		agClick(FDE_StudyPageObjects.selectProduct(getTestDataCellValue(scenarioName, "StudyProduct_2")));
		agClick(FDE_ProductsPageObjects.studyOKBtn);
		if (agIsVisible(FDE_StudyPageObjects.productcopyPopupWindow) == true) {
			agClick(FDE_StudyPageObjects.productcopyPopupWindow_Okbutton);
		}
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to verify the selected study product
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 30-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void selectStudyProduct_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Reports.ExtentReportLog("", Status.INFO, "********Select Study Product verification Started*******", true);
		agAssertContainsText(FDE_ProductsPageObjects.productDescription_Lookupfield,
				FDE_Study.getData(scenarioName, "StudyProduct_2"));
		agCheckPropertyText(FDE_Study.getData(scenarioName, "StudyProductType_2"),
				FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.studyProductType));
		FDE_Products.verify_ProductIsNotBlinded(scenarioName);
		verifyIndication(scenarioName);
		// agAssertContainsText(FDE_ProductsPageObjects.activeSubstance_TextField,
		// getTestDataCellValue(scenarioName, "Products_Ingredients_ActiveSubstance"));
		agAssertContainsText(FDE_ProductsPageObjects.unitDose_TextField,
				getTestDataCellValue(scenarioName, "Products_Therapies_UnitDose"));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Therapies_UnitDoseUnit"),
				FDE_ProductsPageObjects.productEmdedDropdownSelect((FDE_ProductsPageObjects.unitDose_dropdown)));
		agAssertContainsText(FDE_ProductsPageObjects.frequency_TextField,
				getTestDataCellValue(scenarioName, "Products_Therapies_Frequency"));
		agAssertContainsText(FDE_ProductsPageObjects.frequencyTime_TextField,
				getTestDataCellValue(scenarioName, "Products_Therapies_FrequencyTime"));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Therapies_FrequencyTimeUnit"),
				FDE_ProductsPageObjects.productEmdedDropdownSelect((FDE_ProductsPageObjects.frequencyTime_dropdown)));
		if (getTestDataCellValue(scenarioName, "Products_Therapies_DailyDose_Manual").equalsIgnoreCase("Check")) {
			verifyData(FDE_ProductsPageObjects.dailyDose_TextField, scenarioName, "Products_Therapies_DailyDose");
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Therapies_DailyDoseUnit"),
					FDE_ProductsPageObjects.productEmdedDropdownSelect((FDE_ProductsPageObjects.dailyDose_dropdown)));
		}
		agClick(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate));
		agCheckPropertyValue("title",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Products_Therapies_TherapyStartDate")),
				FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate));
		verifyData(FDE_ProductsPageObjects.lotNumber_TextField, scenarioName, "Products_Therapies_LotNumber");
		agClick(FDE_ProductsPageObjects.lotExpirationDate_DateField);
		agCheckPropertyValue("title",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Products_Therapies_LotExpirationDate")),
				FDE_ProductsPageObjects.lotExpirationDate_DateField);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Products_Therapies_FormOfAdmin"),
				FDE_ProductsPageObjects.productDropdownSelect((FDE_ProductsPageObjects.formOfAdmin_Dropdown)));
		agCheckPropertyText((getTestDataCellValue(scenarioName, "Products_Therapies_RouteOfAdmin")).trim(),
				FDE_ProductsPageObjects.productDropdownSelect((FDE_ProductsPageObjects.routeOfAdmin_Dropdown)));
		agCheckPropertyText(
				(getTestDataCellValue(scenarioName, "Products_Therapies_ParentRouteOfAdministrationTermID")).trim(),
				FDE_ProductsPageObjects
						.productDropdownSelect((FDE_ProductsPageObjects.parentRouteOfAdministrationTermID_Dropdown)));
		verifyData(FDE_ProductsPageObjects.routeOfAdministrationTermIDVerDateNum_TextField, scenarioName,
				"Products_Therapies_RouteOfAdministrationTermIDVerDateNum");
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to set the auto suggest product
	 *                description
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 07-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void autoSuggestProductDesc(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Products_AutoSuggestion_PPD").equalsIgnoreCase("true")) {
			agSetValue(FDE_ProductsPageObjects.productDescriptionTextbox,
					getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"));
			agIsVisible(FDE_ProductsPageObjects.autoSuggestionProductpopup);
			CommonOperations.takeScreenShot();
			agWaitTillVisibilityOfElement(FDE_ProductsPageObjects.autoselectPPD);
			agClick(FDE_ProductsPageObjects.autoselectPPD);
			recalculateProductPopUp();
		}
		if (getTestDataCellValue(scenarioName, "Products_AutoSuggestion_LTN").equalsIgnoreCase("true")) {
			agSetValue(FDE_ProductsPageObjects.productDescriptionTextbox,
					getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"));
			agIsVisible(FDE_ProductsPageObjects.autoSuggestionProductpopup);
			CommonOperations.takeScreenShot();
			agWaitTillVisibilityOfElement(FDE_ProductsPageObjects.autoselectLTN);
			agClick(FDE_ProductsPageObjects.autoselectLTN);
			recalculateProductPopUp();
		}
	}

	/**********************************************************************************************************
	 * @Objective: Set Product Information by setting trade name
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 07-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setProductInformation_TradeName(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_Lookup")
				.equalsIgnoreCase("Yes")) {
			agSetStepExecutionDelay("2000");
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.productDescriptionTextbox);
			agClick(FDE_ProductsPageObjects.productDescriptionLookup);
			agClick(FDE_ProductsPageObjects.productLibray_RadioBtn);
			agSetValue(FDE_ProductsPageObjects.level1ProductTextbox(Product_LookupPageObjects.prodLibTradeNameTextBox),
					getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"));
			agClick(FDE_ProductsPageObjects.searchButton);
			agSetStepExecutionDelay("3000");
			agClick(FDE_ProductsPageObjects.checkFirstProdInProdLib);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agClick(FDE_ProductsPageObjects.prodLibOkButton);
			agSetStepExecutionDelay("2000");
			recalculateProductPopUp();
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: Route of Admin and Form of Admin verification for the product
	 *             selected by Trade name
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 07-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyRouteofAdmin_FormOfAdmin_ByTradeName(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO,
				"Verification Started for Route of Admin and Form of Admin for the product selected by Trade Name "
						+ scenarioName,
				true);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ProductsOperations");
		agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.frequency_TextField);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "labelingAddAttrFormOfAdmin"),
				FDE_ProductsPageObjects.productDropdownSelect((FDE_ProductsPageObjects.formOfAdmin_Dropdown)));
		agCheckPropertyText((getTestDataCellValue(scenarioName, "labelingAddAttrRouteOfAdmin")).trim(),
				FDE_ProductsPageObjects.productDropdownSelect((FDE_ProductsPageObjects.routeOfAdmin_Dropdown)));
		CommonOperations.takeScreenShot();
		Reports.ExtentReportLog("", Status.INFO,
				"Verification completed for Route of Admin and Form of Admin for the product selected by Trade Name "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: Route of Admin and Form of Admin verification for the product
	 *             selected by PPD
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 07-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyRouteofAdmin_FormOfAdmin_ByPPD(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO,
				"Verification Started for Route of Admin and Form of Admin for the product selected from PPD "
						+ scenarioName,
				true);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ProductsOperations");
		agJavaScriptExecuctorScrollToElement(FDE_ProductsPageObjects.frequency_TextField);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "FormOfAdmin"),
				FDE_ProductsPageObjects.productDropdownSelect((FDE_ProductsPageObjects.formOfAdmin_Dropdown)));
		agCheckPropertyText((getTestDataCellValue(scenarioName, "RouteOfAdmin")).trim(),
				FDE_ProductsPageObjects.productDropdownSelect((FDE_ProductsPageObjects.routeOfAdmin_Dropdown)));
		CommonOperations.takeScreenShot();
		Reports.ExtentReportLog("", Status.INFO,
				"Verification completed for Route of Admin and Form of Admin for the product selected from PPD "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: Created to set all the check boxes for the recalculation of
	 *             product look up
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 07-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void recalculateProductPopUp() {
		Reports.ExtentReportLog("", Status.INFO, "Recalculation of Products", true);
		if (agIsVisible(FDE_ProductsPageObjects.productrecalculate_Popup) == true) {
			agClick(FDE_ProductsPageObjects.recalculatecheckbox(FDE_ProductsPageObjects.productNameAsReported));
			agClick(FDE_ProductsPageObjects.recalculatecheckbox(FDE_ProductsPageObjects.drugTherapy));
			agClick(FDE_ProductsPageObjects.recalculatecheckbox(FDE_ProductsPageObjects.device));
			agClick(FDE_ProductsPageObjects.recalculatecheckbox(FDE_ProductsPageObjects.indication));
			agClick(FDE_ProductsPageObjects.recalculateYesBtn);
			agSetStepExecutionDelay("2000");
			agIsVisible(FDE_ProductsPageObjects.productDescriptionTextbox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	public static void navigateToLinkedBlindedProduct(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agIsVisible(FDE_ProductsPageObjects.blindedProductLink);
		agClick(FDE_ProductsPageObjects.product_Link(
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName")));
	}

	public static void AddNewProductBtn() {
		agIsVisible(FDE_ProductsPageObjects.AddBtnProduct);
		agClick(FDE_ProductsPageObjects.AddBtnProduct);
	}

	public static void setStudyProductTypeDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.productDropdownSelect(label));
			agJavaScriptExecuctorClick(FDE_GeneralPageObjects
					.clickStudyProductDropDownValue(getTestDataCellValue(scenarioName, columnName)));
		}
	}

	/**********************************************************************************************************
	 * @Objective: Select a radio button against Company Product field
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 18-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void markCompanyProduct(String selectVal) {
		agWaitTillVisibilityOfElement(
				FDE_ProductsPageObjects.checkRadioButton_Value(FDE_ProductsPageObjects.companyProductRadio, selectVal));

		agClick(FDE_ProductsPageObjects.checkRadioButton_Value(FDE_ProductsPageObjects.companyProductRadio, "Yes"));
		agSetStepExecutionDelay("5000");
	}
		
	/**********************************************************************************************************
	 * @Objective: Verify only therapy and duration dose fields
	 * @OutputParameters:
	 * @author: Kishore
	 * @Date : 3-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void productDurationDoseVerification(String scenarioName) {
		getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(FDE_ProductsPageObjects.clickMultipleProducts(getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName")));
		agJavaScriptExecuctorClick(FDE_ProductsPageObjects.therapis_Label);
		CommonOperations.verifyData(FDE_ProductsPageObjects.unitDose_TextField, scenarioName, "Products_Therapies_UnitDose","title");
		CommonOperations.verifyData(FDE_ProductsPageObjects.productEmdedDropdownSelect((FDE_ProductsPageObjects.unitDose_dropdown)),scenarioName,"Products_Therapies_UnitDoseUnit","text");
		CommonOperations.verifyData(FDE_ProductsPageObjects.formStrength_TextField, scenarioName, "Products_Therapies_FormStrength","title");
		CommonOperations.verifyData(FDE_ProductsPageObjects
				.productEmdedDropdownSelect((FDE_ProductsPageObjects.formStrength_dropdown)),scenarioName, "Products_Therapies_FormStrengthUnit","text");
		CommonOperations.verifyData(FDE_ProductsPageObjects.frequency_TextField, scenarioName, "Products_Therapies_Frequency","title");
		CommonOperations.verifyData(FDE_ProductsPageObjects.frequencyTime_TextField, scenarioName,
				"Products_Therapies_FrequencyTime","title");
		CommonOperations.verifyData(FDE_ProductsPageObjects
				.productEmdedDropdownSelect((FDE_ProductsPageObjects.frequencyTime_dropdown)),scenarioName, "Products_Therapies_FrequencyTimeUnit","text");
		CommonOperations.verifyData(FDE_ProductsPageObjects.dailyDose_TextField, scenarioName, "Products_Therapies_DailyDose","title");
		CommonOperations.verifyData(FDE_ProductsPageObjects
				.productEmdedDropdownSelect((FDE_ProductsPageObjects.dailyDose_dropdown)),scenarioName, "Products_Therapies_DailyDoseUnit","text");
	
		CommonOperations.verifyData(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate), scenarioName,"Products_Therapies_TherapyStartDate","title");
		CommonOperations.verifyData(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyEndDate), scenarioName, "Products_Therapies_TherapyEndDate","title");
		
		CommonOperations.verifyData(FDE_ProductsPageObjects.durationOfDrugAdministration_TextField, scenarioName,"Products_Therapies_DurationOfDrugAdministration","title");
		CommonOperations.verifyData(FDE_ProductsPageObjects.productEmdedDropdownSelect((FDE_ProductsPageObjects.durationOfDrugAdministration_Dropdown)),scenarioName, "Products_Therapies_DurationOfDrugAdministrationUnit","text");
	
	}
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to update Therapy Data
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 12-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void UpdateTherapyDate(String scenarioName , String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		if(getTestDataCellValue(scenarioName, "AddtherapyStartDateNullFlavour").equalsIgnoreCase("YES")) {
				agClick(FDE_ProductsPageObjects.click_NFBtn(FDE_ProductsPageObjects.therapyStartDate));
				agSetStepExecutionDelay("2000");
				agIsVisible(FDE_ProductsPageObjects.nullFlavoupPopUp);
				agJavaScriptExecuctorClick(FDE_ProductsPageObjects.nullFlavoupPopUpYesButton);			
		}
		if(getTestDataCellValue(scenarioName, "RemovetherapyStartDateNullFlavour").equalsIgnoreCase("YES")) {
				agClick(FDE_ProductsPageObjects.click_UndoNFBtn(FDE_ProductsPageObjects.therapyStartDate));
				agSetStepExecutionDelay("2000");
				agIsVisible(FDE_ProductsPageObjects.nullFlavoupPopUp);
				agJavaScriptExecuctorClick(FDE_ProductsPageObjects.nullFlavoupPopUpYesButton);
		}
		if(getTestDataCellValue(scenarioName, "AddtherapyEndDateNullFlavour").equalsIgnoreCase("YES")) {
				agClick(FDE_ProductsPageObjects.click_NFBtn(FDE_ProductsPageObjects.therapyEndDate));
				agSetStepExecutionDelay("2000");
				agIsVisible(FDE_ProductsPageObjects.nullFlavoupPopUp);
				agJavaScriptExecuctorClick(FDE_ProductsPageObjects.nullFlavoupPopUpYesButton);
		}
		if (getTestDataCellValue(scenarioName, "RemovetherapyEndDateNullFlavour").equalsIgnoreCase("YES")) {
				agClick(FDE_ProductsPageObjects.click_UndoNFBtn(FDE_ProductsPageObjects.therapyEndDate));
				agSetStepExecutionDelay("2000");
				agIsVisible(FDE_ProductsPageObjects.nullFlavoupPopUp);
				agJavaScriptExecuctorClick(FDE_ProductsPageObjects.nullFlavoupPopUpYesButton);
		}
		
		if(getTestDataCellValue(scenarioName, "therapyStartDateBlank").equalsIgnoreCase("YES")) {
				agClearText(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate));
				agClearText(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyEndDate));
					
		}else {
				agSetValue(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyStartDate),
						getTestDataCellValue(scenarioName, "Products_Therapies_TherapyStartDate"));
				agSetValue(FDE_ProductsPageObjects.product_DateTextbox(FDE_ProductsPageObjects.therapyEndDate),
						getTestDataCellValue(scenarioName, "Products_Therapies_TherapyEndDate"));
				CommonOperations.captureScreenShot(true);
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to Navigate to product 
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 12-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void productNavagation(String scenarioName , String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agJavaScriptExecuctorClick(getTestDataCellValue(scenarioName, "Products_ProductName"));
		agSetStepExecutionDelay("2000");
	}
	
	public static void setDurationOfTheImplantation(String scenarioName,String sheetName) {
		if (scenarioName.equalsIgnoreCase("#skip#")) {
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.DurationOfTheImplantation_Dropdown);
			agSetStepExecutionDelay("2000");
			agJavaScriptExecuctorClick(getTestDataCellValue(scenarioName, "Products_Device_DurationOfTheImplantationDDvalue"));
		}
	}
	
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to compare the value displayed in the field "Class of Devices" and
	 * 				"Health Canada ID Number" with the actual Test Data
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 12-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_HCID_ClassOfDevices(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
				
//		verifyData(FDE_ProductsPageObjects.HCID_TextBox, scenarioName, "Products_Approval_HealthCanadaIDNumber");
		
		agClick(FDE_ProductsPageObjects.HCID_TextBox);
		boolean checkHCID = agCheckPropertyValue("title", getTestDataCellValue(scenarioName, "Products_Approval_HealthCanadaIDNumber"),
				FDE_ProductsPageObjects.HCID_TextBox);
		System.out.println(checkHCID);
		
		String expectedClassOfDevices= getTestDataCellValue(scenarioName, "Products_Approval_ClassOfDevice");
		System.out.println("Expected : "+expectedClassOfDevices);
		String actualClassOfDevices= agGetText(FDE_ProductsPageObjects.classOfDevice_dropdown);
		System.out.println("Actual : "+actualClassOfDevices);
		
		if((checkHCID) && actualClassOfDevices.equals(expectedClassOfDevices)) {				
				Reports.ExtentReportLog("", Status.INFO, "As Expected"+
						"<br />"+ "The value of class of device and Health Canada ID number which is auto populated in Product(s) > Approval tab is same as given in the test data."
						, false);
			}
			
			else {
				
				Reports.ExtentReportLog("", Status.FAIL, "Not As Expected"+
						"<br />"+ "The value of class of device and Health Canada ID number which is auto populated in Product(s) > Approval tab is not same as given in the test data."
						, false);				
			}
	}
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to navigate to Products -> Approval
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 12-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void navigateToApproval() {
		agJavaScriptExecuctorClick(FDE_ProductsPageObjects.approval_Label);
		agSetStepExecutionDelay("5000");
	}
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to verify the value displayed in the field "Class of Devices" and
	 * 				"Health Canada ID Number" are auto-populated
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 14-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_AutoPopulate_HCID_ClassOfDevices() {
//		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		
		agClick(FDE_ProductsPageObjects.HCID_TextBox);
		String checkHCID = agGetAttribute("title", FDE_ProductsPageObjects.HCID_TextBox);
		System.out.println(checkHCID);		
		
		String actualClassOfDevices= agGetText(FDE_ProductsPageObjects.classOfDevice_dropdown);
		System.out.println("Actual : "+actualClassOfDevices);
		
		if((checkHCID).equals("") && actualClassOfDevices.contains("--Select--")) {				
				Reports.ExtentReportLog("", Status.PASS, "As Expected"+
						"<br />"+ "Class of device and Health Canada ID number is not displayed"
						, true);
			}
			
			else {
				
				Reports.ExtentReportLog("", Status.PASS, "As Expected"+
						"<br />"+ "Class of device and Health Canada ID number is auto populated in Product(s) > Approval tab"
						, true);				
			}
	}
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to delete Product Name As Reported details
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 14-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void delete_ProductNameAsReported(String cnfrm) {
		
		agClearText(FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.prductNameAsReportedTxtbox));
		agClick(FDE_ProductsPageObjects.productInformation_Label);
		
		if(agIsVisible(FDE_ProductsPageObjects.confirmation_window)) {
			
			agJavaScriptExecuctorClick(FDE_ProductsPageObjects.productCodeConfirm(cnfrm));

		}

	}
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to verify the value of Approval Details are deleted
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 14-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_Approved_Deleted() {
		
		agClick(FDE_ProductsPageObjects.tradeBrandName_TextField);
		String checkTradeBrandName = agGetAttribute("title", FDE_ProductsPageObjects.tradeBrandName_TextField);
		System.out.println(checkTradeBrandName);		
		
		String actualClassOfDevices= agGetText(FDE_ProductsPageObjects.classOfDevice_dropdown);
		System.out.println("Actual : "+actualClassOfDevices);
		
		agClick(FDE_ProductsPageObjects.HCID_TextBox);
		String checkHCID = agGetAttribute("title", FDE_ProductsPageObjects.HCID_TextBox);
		System.out.println(checkHCID);	
		
		if((checkTradeBrandName).equals("") && (checkHCID).equals("") && actualClassOfDevices.contains("--Select--")) {				
				Reports.ExtentReportLog("", Status.PASS, "As Expected"+
						"<br />"+ "Product > Approval record is deleted"
						, true);
			}
			
			else {
				
				Reports.ExtentReportLog("", Status.FAIL, "Not As Expected"+
						"<br />"+ "Product > Approval record is not deleted"
						, true);				
			}
	}

	/**********************************************************************************************************
	 * @Objective: Below method is created to delete "Health Canada ID Number" details
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 14-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void delete_HealthCanadaIDNumber() {
		
		agClearText(FDE_ProductsPageObjects.HCID_TextBox);
		agSetStepExecutionDelay("2000");
		
//		Reports.ExtentReportLog("", Status.INFO, "Data deleted in Health Canada ID Number Field", false);
	}
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to delete "Class Of Device" details
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 14-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void update_COD(String value) {	
				 agSetStepExecutionDelay("2000");
				 agJavaScriptExecuctorClick(FDE_ProductsPageObjects.ClickClassofDevice_dropDown);
				 agSetStepExecutionDelay("2000");
				 agJavaScriptExecuctorClick(FDE_ProductsPageObjects
				 .clickDropDownValue(value));	
	}

	/**********************************************************************************************************
	 * @Objective: Below method is created to delete "Health Canada ID Number" details
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 14-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void update_HCID(String value) {	
				 agSetStepExecutionDelay("2000");
				 agSetValue(FDE_ProductsPageObjects.HCID_TextBox,
							value);
	}
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to verify whether the field "Health Canada ID Number" is Blank
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 14-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_Blank_HealthCanadaIDNumber() {
		
		agClick(FDE_ProductsPageObjects.HCID_TextBox);
		String checkHCID = agGetAttribute("title", FDE_ProductsPageObjects.HCID_TextBox);
		System.out.println(checkHCID);		
			
		if((checkHCID).equals("")) {
			
			Reports.ExtentReportLog("", Status.PASS, "As Expected"+
					"<br />"+ "Health Canada ID Number field is blank"
					, true);
			}
			
			else {
				
				Reports.ExtentReportLog("", Status.FAIL, "Not As Expected"+
						"<br />"+ "Health Canada ID Number field is not blank"
						, true);				
			}
	}
	
}
