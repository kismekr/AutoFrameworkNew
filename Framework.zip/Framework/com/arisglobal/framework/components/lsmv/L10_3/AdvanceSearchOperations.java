package com.arisglobal.framework.components.lsmv.L10_3;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_0_1.CommonOperations;
import com.arisglobal.framework.components.lsmv.L10_3.OR.AdvanceSearchPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CaseListingDeletePageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_EventsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_ProductsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AdvanceSearchOperations extends ToolManager {
	public static WebElement webElement;
	static String className = AdvanceSearchOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to select dropdown value in
	 *             outofWorkFlow listing.
	 * @InputParameters: LabelName, value
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDown_outofWorkFlow(String LabelName, String columnName) {
		agClick(AdvanceSearchPageObjects.clickDropDown(LabelName));
		agClick(AdvanceSearchPageObjects.selectDropdown(columnName));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform search in advance search
	 *             listing.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 06-Feb-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void navigateToAdvanceSearch() {
		agJavaScriptExecuctorClick(CaseListingPageObjects.searchLinks(CaseListingPageObjects.advanceSearch_link));
		CommonOperations.agwaitTillVisible(AdvanceSearchPageObjects.receiptNumber_Txtfield, 3, 1000);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform search in advance search
	 *             listing.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 06-Feb-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void receiptNumberSearch(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.administrativeFields_link));
		CommonOperations.agwaitTillVisible(AdvanceSearchPageObjects.receiptNumber_Txtfield, 2, 1000);
		agSetStepExecutionDelay("5000");
		agSetValue(AdvanceSearchPageObjects.receiptNumber_Txtfield, getTestDataCellValue(scenarioName, "ReceiptNo"));
		agClick(AdvanceSearchPageObjects.search_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.agwaitTillVisible(
				CaseListingPageObjects.waitForRCT(getTestDataCellValue(scenarioName, "ReceiptNo")), 2, 1000);
		Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to retrieve the deleted case from
	 *             outofWorkFlow listing.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 06-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void outofWorkflowSearch(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			navigateToAdvanceSearch();
			// agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.caseDetails_link));
			// CommonOperations.agwaitTillVisible(AdvanceSearchPageObjects.displayCases_Label,
			// 2, 1000);
			agSetStepExecutionDelay("3000");
			agClick(AdvanceSearchPageObjects.displayCases_radioBtn(AdvanceSearchPageObjects.outofworkflow_RadioBtn));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			setDropDown_outofWorkFlow(AdvanceSearchPageObjects.outofworkflowStatus_Dropdown,
					getTestDataCellValue(scenarioName, "OutofworkflowStatus"));
			receiptNumberSearch(scenarioName);
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Out of Workflow Search Failed", true);

		}
	}

	public static void searchByReceiptNoInAdvanceSearch(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			navigateToAdvanceSearch();
			agSetStepExecutionDelay("3000");
			receiptNumberSearch(scenarioName);
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Out of Workflow Search Failed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Write data into excel sheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to retrieve the deleted case from
	 *             outofWorkFlow listing.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 06-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void retrieveDeleteCase(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FullDataEntryFormPageObjects.retrieve_Btn);
		agIsVisible(FullDataEntryFormPageObjects.retrieveReasonPopup_Title);
		Reports.ExtentReportLog("", Status.INFO, "Retrieve Window", true);
		agSetValue(FullDataEntryFormPageObjects.retrieveReason_Txtarea,
				getTestDataCellValue(scenarioName, "RetrieveReason"));
		agClick(FullDataEntryFormPageObjects.retrievePopupSubmit_Btn);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
		agSetStepExecutionDelay("5000");
		status = agIsVisible(CaseListingPageObjects.validationPopup);
		if (status) {
			String validation = agGetText(CaseListingPageObjects.validationPopup);
			agAssertContainsText(FullDataEntryFormPageObjects.receiptNumber,
					getTestDataCellValue(scenarioName, "RetrieveMessage"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("Case is retrieved successfully", Status.PASS, "Validation : " + validation, true);
		} else {
			String validation = agGetText(CaseListingPageObjects.validationPopup);
			Reports.ExtentReportLog("Case is not retrieved successfully", Status.FAIL, "Validation" + validation, true);
		}
		agClick(CaseListingDeletePageObjects.validationPopupOkBtn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform search by message no in
	 *             advance search listing.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 28-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void messageNumberSearch(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.administrativeFields_link));
		CommonOperations.agwaitTillVisible(AdvanceSearchPageObjects.messageNumber_Textfield, 2, 1000);
		agSetStepExecutionDelay("5000");
		agSetValue(AdvanceSearchPageObjects.messageNumber_Textfield, getTestDataCellValue(scenarioName, "MessageNo"));
		agClick(AdvanceSearchPageObjects.search_Btn);
		agWaitTillInvisibilityOfElement(AdvanceSearchPageObjects.searchLoader);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.agwaitTillVisible(
				CaseListingPageObjects.waitForRCT(getTestDataCellValue(scenarioName, "MessageNo")), 2, 1000);
		Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform search by product in
	 *             advance search listing.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 28-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchByProduct(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.productFields_link));
		agWaitTillVisibilityOfElement(AdvanceSearchPageObjects.productHeader);

		agClick(AdvanceSearchPageObjects.productLookup);
		agWaitTillInvisibilityOfElement(AdvanceSearchPageObjects.searchLoader);
		agSetValue(AdvanceSearchPageObjects.level1ProductTextbox(AdvanceSearchPageObjects.prodLibproductNameTextbox),
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"));
		agClick(AdvanceSearchPageObjects.searchButton);
		agClick(AdvanceSearchPageObjects.checkFirstProdInProdLib);

		agClick(AdvanceSearchPageObjects.prodLibOkButton);
		// agIsVisible(AdvanceSearchPageObjects.addedProductVerify);
		agWaitTillInvisibilityOfElement(AdvanceSearchPageObjects.searchLoader);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		Reports.ExtentReportLog("", Status.INFO, "Search result is listed", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform search by event in advance
	 *             search listing.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 28-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchByEvent(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.eventsFields_link));
		agWaitTillVisibilityOfElement(AdvanceSearchPageObjects.eventsHeader);

		CommonOperations.agwaitTillVisible(AdvanceSearchPageObjects.reportTerm_Txtfield, 2, 1000);
		agSetStepExecutionDelay("5000");
		agSetValue(AdvanceSearchPageObjects.reportTerm_Txtfield, getTestDataCellValue(scenarioName, "ReportedTerm"));
		agClick(AdvanceSearchPageObjects.search_Btn);
		agWaitTillInvisibilityOfElement(AdvanceSearchPageObjects.searchLoader);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform search by Seriousness in
	 *             advance search listing.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 28-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchBySeriousness(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.eventsFields_link));
		agWaitTillVisibilityOfElement(AdvanceSearchPageObjects.eventsHeader);
		agSetStepExecutionDelay("5000");
		setDropDown_outofWorkFlow(AdvanceSearchPageObjects.seriousDropdown,
				getTestDataCellValue(scenarioName, "AdvanceSearch_Events_Serious"));
		setDropDown_outofWorkFlow(AdvanceSearchPageObjects.seriousDropdown,
				getTestDataCellValue(scenarioName, "AdvanceSearch_Events_SeriousnessCriteria"));
		agClick(AdvanceSearchPageObjects.search_Btn);
		agWaitTillInvisibilityOfElement(AdvanceSearchPageObjects.searchLoader);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select dropdown and its value.
	 * @InputParameters: LabelName, value
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 29-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDown(String LabelName, String columnName) {
		agClick(AdvanceSearchPageObjects.clickOnDropDown(LabelName));
		agClick(AdvanceSearchPageObjects.selectDropdown(columnName));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform search by saved criteria
	 *             in advance search listing.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 29-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchBySavedCriteria(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		setDropDown(AdvanceSearchPageObjects.savedCriteriaDropdown,
				getTestDataCellValue(scenarioName, "AdvanceSearch_SavedSearch"));
		agSetStepExecutionDelay("5000");
		agClick(AdvanceSearchPageObjects.search_Btn);
		agWaitTillInvisibilityOfElement(AdvanceSearchPageObjects.searchLoader);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);
	}

	/**********************************************************************************************************
	 * @Objective: Advance search/flexible search by case units,Study and products
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 29-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void advanceSearchByCase_Study_ProductInfo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.administrativeFields_link));
		CommonOperations.agwaitTillVisible(AdvanceSearchPageObjects.receiptNumber_Txtfield, 2, 1000);
		agSetStepExecutionDelay("5000");
		agSetValue(AdvanceSearchPageObjects.receiptNumber_Txtfield, FDE_General.getData(scenarioName, "ReceiptNo"));

		// Case units and Dates
		agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.caseUnitAndDates_link));
		agSelectByVisibleText(AdvanceSearchPageObjects.companyUnit_Dropdown,
				FDE_General.getData(scenarioName, "Gen_CaseUnits_CompanyUnit"));

		// Case Report and Seriousness
		searchByCaseReportsAndSeriousness(scenarioName);

		// Study Information
		searchByStudyInformation(scenarioName);

		agWaitTillInvisibilityOfElement(AdvanceSearchPageObjects.searchLoader);
		Reports.ExtentReportLog("", Status.INFO, "Case is listed by Advance Search", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Click the saerch buton
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 30-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void clickSearch() {
		agClick(AdvanceSearchPageObjects.search_Btn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created search the study information
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 29-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchByStudyInformation(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Study");
		agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.studyInformation_Link));
		agSetValue(AdvanceSearchPageObjects.protocolNo_TextBox,
				getTestDataCellValue(scenarioName, "Study_StudyLookup_StudyNo"));
		// agSelectByVisibleText(AdvanceSearchPageObjects.studyPhase_Dropdown,
		// getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyPhase"));
		agSelectByVisibleText(AdvanceSearchPageObjects.studyDesign_Dropdown,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyDesign"));
		agSetValue(AdvanceSearchPageObjects.studyName_TextBox,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyName"));
		agSelectByVisibleText(AdvanceSearchPageObjects.studyType_Dropdown,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyType"));
		agSetValue(AdvanceSearchPageObjects.eudraCTNumber_TextBox,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_EudraCTNumber"));
		agSetValue(AdvanceSearchPageObjects.registratioNum_TextBox,
				getTestDataCellValue(scenarioName, "Study_StudyRegistration_RegistrationNumber"));
		agSelectByVisibleText(AdvanceSearchPageObjects.caseCodeBroken_Dropdown,
				getTestDataCellValue("BlindingUnBlinding_BreakTheCode", "Study_StudyInformation_CaseCodeBroken"));
		Reports.ExtentReportLog("", Status.INFO, "Searched by Study information", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created search the study information
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters:NA
	 * @author:Pooja S
	 * @Date : 29-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchByCaseReportsAndSeriousness(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.caseReportAndSeriousness_link));
		agSelectByVisibleText(AdvanceSearchPageObjects.reportType_Dropdown,
				getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportType"));
		agSelectByVisibleText(AdvanceSearchPageObjects.reportCategory_Dropdown,
				getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportCategory"));
		agSelectByVisibleText(AdvanceSearchPageObjects.reportPriority_Dropdown,
				getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportPriority"));
		// agSelectByVisibleText(AdvanceSearchPageObjects.reportClassification_Dropdown,
		// getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportClassification"));
		agSelectByVisibleText(AdvanceSearchPageObjects.reportRecvMedium_Dropdown,
				getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportReceivingMedium"));
		Reports.ExtentReportLog("", Status.INFO, "Searched by Case Reports and Seriousness", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search unblinded product in
	 *             advance search listing based on user privileges in run time
	 * @InputParameters: product name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 15-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchUnBlindedBlindedProductName(String scenarioName) {
		agSetStepExecutionDelay("4000");
		agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.productFields_link));
		agWaitTillVisibilityOfElement(AdvanceSearchPageObjects.productHeader);
		agClick(AdvanceSearchPageObjects.productLookup);
		agWaitTillInvisibilityOfElement(AdvanceSearchPageObjects.searchLoader);
		if (scenarioName.equalsIgnoreCase("AddUnblindedProduct")) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "Product_LookupOperations");
			agSetValue(AdvanceSearchPageObjects.txtProdName,
					getTestDataCellValue(scenarioName, "ProductLibraryProductName"));
		}
		if (scenarioName.equalsIgnoreCase("BlindingUnBlinding")) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Study");
			agSetValue(AdvanceSearchPageObjects.txtProdName, getTestDataCellValue(scenarioName, "BlindedProduct_1"));
		}

		agClick(AdvanceSearchPageObjects.productSearchButton);
		agClick(AdvanceSearchPageObjects.frstProdInLib);
		agClick(AdvanceSearchPageObjects.productOkButton);
		// agIsVisible(AdvanceSearchPageObjects.addedProductVerify);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Case is listed by Product", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to retverify nullified case from
	 *             outofWorkFlow listing .
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 15-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyNullifiedCase(String ReceiptNo) {

		String ReceiptNoText = agGetText(CaseListingPageObjects.receiptNumberlink);
		if (ReceiptNo.equalsIgnoreCase(ReceiptNoText)) {

			Reports.ExtentReportLog("", Status.PASS, "Case is out of workflow successfully", true);
			status = agIsVisible(CaseListingPageObjects.caseDeletedIcon);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Nullified Case deleted successfully", true);
			} else {
				Reports.ExtentReportLog("", Status.PASS, "Nullified Case not deleted successfully", true);
			}

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Case is not out of workflow successfully", true);
		}
		agClick(CaseListingPageObjects.clearall);
		agSetStepExecutionDelay("5000");
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to create case with multiple products.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 17-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createCaseWithMultipleProducts(String scenarioName, int noOfProducts) {

		FDE_Operations.tabNavigation("General");
		FDE_General.setCaseUnitsDetails(scenarioName);
		FDE_General.setCaseDates(scenarioName);
		FDE_General.setCaseReportDetails(scenarioName);
		FDE_General.addContact_FDEForm(scenarioName);
		FDE_General.setAdditionalDocumentsDetails(scenarioName);

		FDE_Operations.tabNavigation("Event(s)");
		FDE_Events.set_EventInformation_Data(scenarioName);
		FDE_Events.set_EventSeriousness(scenarioName);

		FDE_Operations.tabNavigation("Product(s)");
		for (int i = 1; i <= noOfProducts; i++) {
			FDE_Products.setProductInformation(scenarioName + i);
			FDE_Products.setIngredients(scenarioName + i);
			FDE_Products.setProductApproval(scenarioName + i);
			FDE_Products.setIndication(scenarioName + i);
			FDE_Products.setTherapies(scenarioName + i);
			agClick(FDE_ProductsPageObjects.AddBtnProduct);
		}

		FDE_Operations.LSMVSave(scenarioName, "FDE_General");
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to retrieve records by providing
	 *             Product, Event and Case Receipt number.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 17-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchBy_Product_Event_CaseReceiptNo(String scenarioName, int productNumber) {

		// Set Case Details
		agWaitTillVisibilityOfElement(
				AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.administrativeFields_link));
		// agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.administrativeFields_link));
		// agSetStepExecutionDelay("5000");
		agSetValue(AdvanceSearchPageObjects.receiptNumber_Txtfield, FDE_General.getData(scenarioName, "ReceiptNo"));
		Reports.ExtentReportLog("", Status.INFO, "Receipt number of the case is keyed", true);

		// Set Product Details
		agSetStepExecutionDelay("5000");
		agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.productFields_link));
		agMouseHover(AdvanceSearchPageObjects.productHeader);
		// agClick(AdvanceSearchPageObjects.productHeader);
		agSetStepExecutionDelay("2000");

		agClick(AdvanceSearchPageObjects.productLookup);
		agWaitTillInvisibilityOfElement(AdvanceSearchPageObjects.searchLoader);
		agSetValue(AdvanceSearchPageObjects.txtProdName, FDE_Products.getData(scenarioName + productNumber,
				"Products_ProductInformation_ProductDescription_ProductName"));
		agClick(AdvanceSearchPageObjects.productSearchButton);
		agClick(AdvanceSearchPageObjects.firstRecord_ChkBx);
		agClick(AdvanceSearchPageObjects.productOkButton);
		agWaitTillVisibilityOfElement(AdvanceSearchPageObjects.productHeader);

		agWaitTillVisibilityOfElement(AdvanceSearchPageObjects.productCharacterizationDD);
		agClick(AdvanceSearchPageObjects.productCharacterizationDD);
		agSetStepExecutionDelay("3000");
		agClick(AdvanceSearchPageObjects.productCharacterizationDDRecord(FDE_Products
				.getData(scenarioName + productNumber, "Products_ProductInformation_ProductCharacterization")));
		// FDE_Products.getData(scenarioName+productNumber,
		// "Products_ProductInformation_ProductCharacterization"));
		Reports.ExtentReportLog("", Status.INFO, "Necessary Product details keyed", true);

		// Set Event Details //select[@name='selectedDrugCharacterization']
		agWaitTillVisibilityOfElement(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.eventsFields_link));
		agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.eventsFields_link));
		agMouseHover(AdvanceSearchPageObjects.eventsHeader);
		// agWaitTillVisibilityOfElement(AdvanceSearchPageObjects.eventsHeader);
		agWaitTillInvisibilityOfElement(AdvanceSearchPageObjects.searchLoader);
		agSetValue(AdvanceSearchPageObjects.reportTerm_Txtfield,
				FDE_Events.getData(scenarioName, "Events_EventInformation_ReportedTerm"));
		agSelectByVisibleText(AdvanceSearchPageObjects.eventSeriousness_Dropdown,
				FDE_Events.getData(scenarioName, "Events_EventSeriousness_Seriousness"));
		Reports.ExtentReportLog("", Status.INFO, "Necessary Event details keyed", true);

		// Case Search
		agClick(AdvanceSearchPageObjects.search_Btn);
		agWaitTillInvisibilityOfElement(AdvanceSearchPageObjects.searchLoader);
		if (agIsExists(AdvanceSearchPageObjects.seeMore_Hyperlink)) {
			agMouseHover(AdvanceSearchPageObjects.seeMore_Hyperlink);
		}

		if (agIsExists(CaseListingPageObjects.waitForRCT(FDE_General.getData(scenarioName, "ReceiptNo")))) {
			Reports.ExtentReportLog("", Status.PASS, "Search result is listed, Expected Case is retrieved.", true);
			verify_Product_EventData(scenarioName, productNumber);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Search result is listed, Expected Case is NOT retrieved", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to retrieve records by providing
	 *             Product, Event and Case Receipt number.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 17-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_Product_EventData(String scenarioName, int productNumber) {
		if (agIsVisible(CaseListingPageObjects.receiptNumberlink)) {
			agClick(CaseListingPageObjects.receiptNumberlink);

			if (productNumber == 1) {
				// Events Tab
				FDE_Operations.tabNavigation("Event(s)");
				agJavaScriptExecuctorClick(FDE_EventsPageObjects.eventInfo_Label);
				System.out.println("ScenarioName: " + scenarioName);
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
				FDE_Events.verifyData(
						FDE_EventsPageObjects.setData_Textfields(FDE_EventsPageObjects.reportedTerm_Textbox),
						scenarioName, "Events_EventInformation_ReportedTerm");
				CommonOperations.verifyRadioButton(FDE_EventsPageObjects.seriousness_Radiobtn,
						FDE_Events.getTestDataCellValue(scenarioName, "Events_EventSeriousness_Seriousness"));
			}

			// Products Tab
			FDE_Operations.tabNavigation("Product(s)");
			agWaitTillVisibilityOfElement(FDE_ProductsPageObjects.clickMultipleProducts(FDE_Products.getData(
					scenarioName + productNumber, "Products_ProductInformation_ProductDescription_ProductName")));
			agClick(FDE_ProductsPageObjects.clickMultipleProducts(FDE_Products.getData(scenarioName + productNumber,
					"Products_ProductInformation_ProductDescription_ProductName")));

			agWaitTillVisibilityOfElement(FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects
					.productDropdownSelect(FDE_ProductsPageObjects.productCharacterizationDrpdwn)));
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
			FDE_Products.agCheckPropertyText(
					getTestDataCellValue(scenarioName + productNumber,
							"Products_ProductInformation_ProductCharacterization"),
					FDE_ProductsPageObjects
							.productDropdownSelect(FDE_ProductsPageObjects.productCharacterizationDrpdwn));
			FDE_Products.verifyData(
					FDE_ProductsPageObjects.productTextbox(FDE_ProductsPageObjects.prductNameAsReportedTxtbox),
					scenarioName + productNumber, "Products_ProductInformation_ProductNameAsReported");
			FDE_Products.agCheckPropertyText(
					getTestDataCellValue(scenarioName + productNumber, "Products_ProductInformation_ProductFlag"),
					FDE_ProductsPageObjects.productDropdownSelect(FDE_ProductsPageObjects.productFlag));

		}
	}
}