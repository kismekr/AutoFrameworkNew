package com.arisglobal.framework.components.lsmv.L10_3;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CodingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_EventsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_ProductsPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Coding extends ToolManager {

	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in Coding
	 *             Module
	 * @InputParameters: pageObject
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 30-Sept-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void menuNavigation(String pageObject) {

		agMouseHover(CodingPageObjects.codingHover);
		agJavaScriptExecuctorClick(pageObject);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in Coding
	 *             Module
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 30-Sept-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void distributionNavigations(String menu) {
		switch (menu) {
		case "CodingInboxandReviewMedDRA":
			agSetStepExecutionDelay("2000");
			menuNavigation(CodingPageObjects.codingInboxandReviewMedDRA);
			status = agIsVisible(CodingPageObjects.codingInboxMedraHeader);

			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to Coding Inbox and Review MedDRA is successfull",
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Navigation to Coding Inbox and Review MedDRA is Unsuccessfull", true);
			}
			break;
		case "CodingInboxandReviewWhoDD":
			agSetStepExecutionDelay("2000");
			menuNavigation(CodingPageObjects.codingInboxandReviewWhoDD);
			status = agIsVisible(CodingPageObjects.codingInboxWhoDDHeader);

			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to Coding Inbox and Review WhoDD is successfull",
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Coding Inbox and Review WhoDD is Unsuccessfull",
						true);
			}
			break;
		default:
			System.out.println("Invalid Menu Link!");
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform to add all the gird column
	 *             preferences and verify all columns
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 01-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addGridColumnPreferencesAndVerifyColumns(String PageHeader) {
		agIsVisible(CodingPageObjects.gridcolumnPreferenceIcon);
		agSetStepExecutionDelay("2000");
		agClick(CodingPageObjects.gridcolumnPreferenceIcon);
		agJavaScriptExecuctorClick(CodingPageObjects.selectAllColumns);
		agJavaScriptExecuctorClick(CodingPageObjects.closeColumnPreferencePopUp);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agJavaScriptExecuctorClick(CodingPageObjects.saveGridCustom);

		status = agIsVisible(CodingPageObjects.saveConfirmation);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Custom grid saved successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Custom grid saved Unsuccessfull", true);
		}
		CommonOperations.takeScreenShot();

		if (PageHeader.equalsIgnoreCase("Coding Inbox - WHO DD")) {

			agAssertVisible(CodingPageObjects.aerNO);
			agAssertVisible(CodingPageObjects.receiptNO);
			agAssertVisible(CodingPageObjects.productNameAsReporter);
			agAssertVisible(CodingPageObjects.dictionaryVersion);
			agAssertVisible(CodingPageObjects.submissionDueDate);
			agAssertVisible(CodingPageObjects.caseDueDate);
			agAssertVisible(CodingPageObjects.centralCodingReceivedDate);
			agAssertVisible(CodingPageObjects.caseSeriousness);
			agAssertVisible(CodingPageObjects.routeoFAdmin);
			agAssertVisible(CodingPageObjects.indication);
			agAssertVisible(CodingPageObjects.matchFound);
			agAssertVisible(CodingPageObjects.codingComment);
			agAssertVisible(CodingPageObjects.processingUnit);
			agAssertVisible(CodingPageObjects.resolved);
			agAssertVisible(CodingPageObjects.caseOwner);

		} else {
			agAssertVisible(CodingPageObjects.aerNO);
			agAssertVisible(CodingPageObjects.receiptNO);
			agAssertVisible(CodingPageObjects.reportedTerm);
			agAssertVisible(CodingPageObjects.dictionaryVersion);
			agAssertVisible(CodingPageObjects.termType);
			agAssertVisible(CodingPageObjects.caseSeriousness);
			agAssertVisible(CodingPageObjects.caseOwner);
			agAssertVisible(CodingPageObjects.submissionDueDate);
			agAssertVisible(CodingPageObjects.caseDueDate);
			agAssertVisible(CodingPageObjects.productDescription);
			agAssertVisible(CodingPageObjects.receivedDate);
			agAssertVisible(CodingPageObjects.eventSeriousness);
			agAssertVisible(CodingPageObjects.processingUnit);
			agAssertVisible(CodingPageObjects.codingComment);
			agAssertVisible(CodingPageObjects.matchFound);
			agAssertVisible(CodingPageObjects.resolved);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create export data in excel and PDF.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 01-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportCodingInboxWhoDD() {
		agIsVisible(CodingPageObjects.clickExportIcon);
		agClick(CodingPageObjects.clickExportIcon);
		agWaitTillVisibilityOfElement(CodingPageObjects.exportConfigurationHeader);
		agClick(CodingPageObjects.exportAsExcelBtn);
		agSetStepExecutionDelay("15000");
		CommonOperations.move_XLSDownloadedexcel("Unresolved Triage");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Excel downloaded successfully", true);
		CommonOperations.takeScreenShot();
		agClick(CodingPageObjects.exportAsPDFBtn);
		agSetStepExecutionDelay("15000");
		CommonOperations.move_DownloadedPDF("Unresolved Triage");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "PDF downloaded successfully", true);
		CommonOperations.takeScreenShot();
		agClick(CodingPageObjects.cancel);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create for grid column filter anf verify
	 *             searched result
	 * @InputParameters: scenarioName ,sheetName,columnName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 01-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void gridColumnFilter(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agIsVisible(CodingPageObjects.filterIcon);
		agClick(CodingPageObjects.filterIcon);
		agSetValue(CodingPageObjects.receiptNoInput, getTestDataCellValue(scenarioName, columnName));
		agClick(CodingPageObjects.filterAerNo);
		agSetStepExecutionDelay("5000");
		String ReceiptNum = getTestDataCellValue(scenarioName, columnName);

		status = agIsVisible(CodingPageObjects.noRecordFound);
		if (status) {
			Reports.ExtentReportLog("", Status.FAIL, "ReceiptNo not matched successfully" + ReceiptNum, true);
		} else {
			Reports.ExtentReportLog("", Status.PASS, "ReceiptNo matched successfully" + ReceiptNum, true);
		}
		CommonOperations.takeScreenShot();
		agClick(CodingPageObjects.filterIcon);
		agSetStepExecutionDelay("5000");
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to search by filter criteria and
	 *             verify searched result
	 * @InputParameters: scenarioName ,sheetName,columnName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 01-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void filterCriteriaSearch(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agIsVisible(CodingPageObjects.clickFilterCriteria);
		agClick(CodingPageObjects.clickFilterCriteria);
		agSetValue(CodingPageObjects.filterCriteriaReceiptNo, getTestDataCellValue(scenarioName, columnName));
		agClick(CodingPageObjects.searchBtn);
		agSetStepExecutionDelay("5000");
		String ReceiptNum = getTestDataCellValue(scenarioName, columnName);

		status = agIsVisible(CodingPageObjects.noRecordFound);
		if (status) {
			Reports.ExtentReportLog("", Status.FAIL, "ReceiptNo not matched successfully" + ReceiptNum, true);
		} else {
			Reports.ExtentReportLog("", Status.PASS, "ReceiptNo matched successfully" + ReceiptNum, true);
		}
		CommonOperations.takeScreenShot();
		agClick(CodingPageObjects.clearBtn);
		agSetStepExecutionDelay("5000");
		agClick(CodingPageObjects.closeBtn);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to classify Un Resolved Product in
	 *             Coding Inbox WhoDD
	 * @InputParameters: scenarioName ,sheetName,columnName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void classifyUnResolvedProduct(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetValue(CodingPageObjects.inputreceiptNo, getTestDataCellValue(scenarioName, columnName));
		agClick(CodingPageObjects.clickSearch);
		agSetStepExecutionDelay("5000");
		agClick(CodingPageObjects.clickProductName);
		agIsVisible(CodingPageObjects.codingBrowser);
		agJavaScriptExecuctorClick(CodingPageObjects.begensWithCheckBox);
		agClick(CodingPageObjects.btnSearch);
		agWaitTillInvisibilityOfElement(CodingPageObjects.searchLoader);
		agClick(CodingPageObjects.checkSearchProduct);
		agClick(CodingPageObjects.clickClassifyBtn);
		status = agIsVisible(CodingPageObjects.multipleMatchTermPopUp);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Multiple matching terms popUp is displayed successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Multiple matching terms popUp is not displayed successfully",
					true);
		}
		CommonOperations.takeScreenShot();
		agClick(CodingPageObjects.yesBtn);
		agIsVisible(CodingPageObjects.classifyConfirmation);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to change view in Coding Inbox WhoDD
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void changeView(String label) {
		agClick(CodingPageObjects.viewDD);
		agSetStepExecutionDelay("2000");
		agClick(CodingPageObjects.selectViewDroprdown(label));
		agWaitTillInvisibilityOfElement(CodingPageObjects.searchLoader);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to change Vtaview in Coding Inbox
	 *             MedDRA
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void changeVTAView(String label) {
		agClick(CodingPageObjects.vtaViewDD);
		agSetStepExecutionDelay("2000");
		agClick(CodingPageObjects.selectViewDroprdown(label));
		agWaitTillInvisibilityOfElement(CodingPageObjects.searchLoader);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to verify classified product status in
	 *             Resolved View
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyClassifiedProductStatus() {
		agSetStepExecutionDelay("2000");
		status = agIsVisible(CodingPageObjects.verifyYes);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Product classified successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Product classified not successfully", true);
		}
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to classify Un Resolved event in
	 *             Coding Inbox and Review MedDRA
	 * @InputParameters: scenarioName ,sheetName,columnName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void classifyUnResolvedEvent(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetValue(CodingPageObjects.inputreceiptNo, getTestDataCellValue(scenarioName, columnName));
		agClick(CodingPageObjects.clickSearch);
		agSetStepExecutionDelay("5000");
		agClick(CodingPageObjects.clickSearchResult);
		agIsVisible(CodingPageObjects.dictionaryCodingBrowserPopUp);
		// agJavaScriptExecuctorClick(CodingPageObjects.begensWithCheckBox);
		agClick(CodingPageObjects.btnSearch);
		agWaitTillInvisibilityOfElement(CodingPageObjects.searchLoader);
		// agClick(CodingPageObjects.checkSearchProduct);
		agClick(CodingPageObjects.clickClassifyBtn);
		status = agIsVisible(CodingPageObjects.multipleMatchTermPopUp);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Multiple matching terms popUp is displayed successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Multiple matching terms popUp is not displayed successfully",
					true);
		}
		CommonOperations.takeScreenShot();
		agClick(CodingPageObjects.yesBtn);
		agIsVisible(CodingPageObjects.classifyConfirmation);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to approve VTA in VTA Review and
	 *             Approval Tab under
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 05-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void approvalVTA(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agClick(CodingPageObjects.VTAReviewAndApprovalTab);
		changeVTAView("Approved");
		agSetValue(CodingPageObjects.searchInVTAReview, getTestDataCellValue(scenarioName, columnName));
		agClick(CodingPageObjects.searchIcon);
		agSetStepExecutionDelay("5000");
		// agClick(CodingPageObjects.clickSearchResult);
		agJavaScriptExecuctorClick(CodingPageObjects.clickCheckBox);
		agClick(CodingPageObjects.approveVTABtn);
		status = agIsVisible(CodingPageObjects.approveConfirmation);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Term approved successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "MTerm approved not successfully", true);
		}
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created for VTA Approval for WHO DD and
	 *             verify approval status
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 21-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VTAApprovalforWHODD(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agClick(CodingPageObjects.VTAReviewAndApprovalWhoDDTab);
		agSetValue(CodingPageObjects.searchInVTAReviewWhoDD, getTestDataCellValue(scenarioName, columnName));
		agClick(CodingPageObjects.WhoDDsearchIcon);
		agJavaScriptExecuctorClick(CodingPageObjects.WhoDDclickCheckBox);
		agClick(CodingPageObjects.approveVTABtn);
		agIsVisible(CodingPageObjects.multipleMatchTermPopUp);
		CommonOperations.takeScreenShot();
		agClick(CodingPageObjects.yesBtn);

		agJavaScriptExecuctorClick(CodingPageObjects.WhoDDclickCheckBox);
		agClick(CodingPageObjects.approveVTABtn);
		agIsVisible(CodingPageObjects.multipleMatchTermSecondLevelPopUp);
		agClick(CodingPageObjects.VTASecondLevelYesBtn);
		agIsVisible(CodingPageObjects.VTAApprovalMsg);
		changeVTAView("Approved");
		agSetStepExecutionDelay("2000");
		status = agIsVisible(CodingPageObjects.VTAApprovedYes);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Term Approved successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Term Approved not successfully", true);
		}
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created for verification of submit uncoded
	 *             terms based on work flow level
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja/ChithuRaj
	 * @Date : 18-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verificationOfSubmitUncodedTermsBasedOnWorkflow(String WFscenarioName, String scenarioName,
			String columnName, String codingOptions) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "WorkflowConfigurations");
		boolean prodUnCodedStatus = true;
		boolean eventUnCodedStatus = true;
		List<WebElement> getProdCode = null;
		List<WebElement> getEventCode = null;
		String submitUncodedTermsStatus = getTestDataCellValue(WFscenarioName, "SubmitUncodedTermsCheckBox");
		String ReceiptNum = FDE_General.getData(scenarioName, columnName);
		// Searching the case in case listing screen
		if (agIsExists(CaseListingPageObjects.newButton)) {
			agSetValue(CaseListingPageObjects.keywordSearchTextbox, ReceiptNum);
			agClick(CaseListingPageObjects.searchButton);
			agClick(CaseListingPageObjects.receiptNumberlink);
		} else {
			CaseListingOperations.searchCase_Edit(scenarioName, "FDE_General", "ReceiptNo");
		}
		// Verify Product is coded or not
		if (codingOptions.equalsIgnoreCase("CodingInboxandReviewWhoDD")) {
			try {
				FDE_Operations.tabNavigation("Product(s)");
				getProdCode = agGetElementList(FDE_ProductsPageObjects.suspectProductNotCodedlist);
			} catch (Exception e) {
				Reports.ExtentReportLog("", Status.FAIL, " Product noncoded list not available : " + e, true);
			}
			for (int i = 0; i < getProdCode.size(); i++) {
				String prodCode = agGetAttribute("class",
						FDE_ProductsPageObjects.getProductNotCode(Integer.toString(i + 1)));
				if (prodCode.contains("suspectProductNotCoded")) {
					Reports.ExtentReportLog("", Status.INFO, "Product is not coded ", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Product is Coded ", true);
					prodUnCodedStatus = false;
				}
				CommonOperations.takeScreenShot();
			}

		}
		// Verify Event is coded or not
		else {
			try {
				FDE_Operations.tabNavigation("Event(s)");
				getEventCode = agGetElementList(FDE_EventsPageObjects.suspectEventNotCodedlist);
			} catch (Exception e) {
				Reports.ExtentReportLog("", Status.FAIL, " Event noncoded list not available : " + e, true);
			}
			for (int i = 0; i < getEventCode.size(); i++) {
				String eventCode = agGetAttribute("class",
						FDE_EventsPageObjects.getEventNotCode(Integer.toString(i + 1)));
				if (eventCode.contains("reactionTabSDLnotAutoCoded")) {
					Reports.ExtentReportLog("", Status.INFO, "Event is not coded ", true);
					eventUnCodedStatus = true;
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Event is Coded ", true);
					eventUnCodedStatus = false;
				}
				CommonOperations.takeScreenShot();
			}

		}
		Coding.distributionNavigations(codingOptions);
		boolean searchStatus = SearchByReceiptNum(ReceiptNum);
		if (prodUnCodedStatus == false || eventUnCodedStatus == false) {
			Reports.ExtentReportLog("", Status.FAIL,
					" Product OR Event is coded " + " for " + codingOptions + " RCTNum " + ReceiptNum, true);
		} else if (submitUncodedTermsStatus.equalsIgnoreCase("Yes") && searchStatus == true) {
			Reports.ExtentReportLog("", Status.PASS,
					" ReceiptNo matched successfully " + ReceiptNum + " Activity: " + WFscenarioName, true);
		} else if (submitUncodedTermsStatus.equalsIgnoreCase("No") && searchStatus == false) {
			Reports.ExtentReportLog("", Status.PASS,
					" ReceiptNo not matched successfully " + ReceiptNum + " Activity: " + WFscenarioName, true);
		} else if (submitUncodedTermsStatus.equalsIgnoreCase("")
				|| submitUncodedTermsStatus.equalsIgnoreCase("#skip#")) {
			Reports.ExtentReportLog("", Status.INFO, " No Value provided for the workflow " + WFscenarioName, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					" Search is not successfull " + ReceiptNum + " Activity: " + WFscenarioName, true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to search and verify searched result
	 * @InputParameters: ReceiptNum
	 * @OutputParameters:
	 * @author:Pooja/Chithuraj
	 * @Date : 18-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean SearchByReceiptNum(String ReceiptNum) {
		agIsVisible(CodingPageObjects.clickFilterCriteria);
		boolean status = false;
		for (int i = 0; i <= 4; i++) {
			agSetValue(CodingPageObjects.inputreceiptNo, ReceiptNum);
			agClick(CodingPageObjects.clickSearch);
			agSetStepExecutionDelay("5000");
			status = agIsVisible(CodingPageObjects.noRecordFound);
			if (status == true) {
				System.out.println("Waiting for Scheduler to complete the activity");
				agSetStepExecutionDelay("55000");
				agClick(CodingPageObjects.unresolvedTraige);
				continue;
			} else {
				break;
			}
		}

		if (status == false) {
			return true;
		} else {
			return false;
		}

	}

}