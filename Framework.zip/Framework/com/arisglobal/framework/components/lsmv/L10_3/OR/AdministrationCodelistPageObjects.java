package com.arisglobal.framework.components.lsmv.L10_3.OR;

import com.arisglobal.framework.lib.main.ToolManager;

public class AdministrationCodelistPageObjects extends ToolManager {

	public static String keywordSearchTextbox = "xpath#//input[@id='codeListform:searchText']";
	public static String keywordSearchIcon = "xpath#//img[contains(@src,'search_icon')]";
	public static String codelistName = "xpath#//label[text()='COUNTRY_CORE_IB']";
	public static String editCodeList= "xpath#//img[@id='codeListform:codelistDataTable:0:editLink1']";
	public static String codeListNameHeader = "xpath#//div[@id='codelistDetailsform:detailsPanel_header']";
	public static String DSURCodelist = "xpath#//label[text()='DSUR ']";
	public static String cancelBtn = "xpath#//span[text()=' Cancel']";
	
	
}
