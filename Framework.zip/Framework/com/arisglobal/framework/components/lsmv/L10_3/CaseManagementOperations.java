package com.arisglobal.framework.components.lsmv.L10_3;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CaseManagementPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.DataAssessmentPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDEMoreOptionsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FollowupNotificationPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.HomePageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.LoginPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.UnstructuredFormPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class CaseManagementOperations extends ToolManager {
	public static WebElement webElement;
	static String className = CaseManagementOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform menu navigation in case
	 *             management module module
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void menuNavigation_ObjectID(String object) {
		agMouseHover(CaseManagementPageObjects.caseManagementHover);
		agClick(object);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform menu navigation in case
	 *             management module module
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void menuNavigation(String subMenu) {
		agMouseHover(CaseManagementPageObjects.caseManagementHover);
		agClick(CaseManagementPageObjects.CaseManagmentMenuNavigations(subMenu));
	}

	public static void menusubmenuNavigation(String subMenu) {
		agMouseHover(CaseManagementPageObjects.caseManagementHover);
		agClick(CaseManagementPageObjects.CaseManagmentMenuSubMenuNavigations(subMenu));
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to perform Sub menu navigation in case
	 *                management module
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void subMenuNavigations(String subMenu) {
		agMouseHover(CaseManagementPageObjects.caseManagementHover);
		agMouseHover(CaseManagementPageObjects.newCaseHover);
		agClick(CaseManagementPageObjects.CaseManagmentSubMenuNavigations(subMenu));
	}

	/**********************************************************************************************************
	 * @Objective:The below Method is create to perform menu navigations in
	 *                CaseManagement Module and verify the label name.
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void caseManagement_MenuNavigations(String menu) {
		// agSetGlobalTimeOut("120");
		switch (menu) {
		case "fullDataEntryForm":
			agSetStepExecutionDelay("4000");
			subMenuNavigations("Full data entry form");
			// agSetStepExecutionDelay("8000");
			CommonOperations.agwaitTillVisible(CaseManagementPageObjects.senderOrganizationTextField, 2, 1000);
			status = agIsVisible(CaseManagementPageObjects.senderOrganizationTextField);
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "", false);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Full data entry form is Unsuccessfull", true);
			}
			break;
		case "caseListing":
			menuNavigation("Case listing");
			agSetStepExecutionDelay("8000");
			status = agIsVisible(CaseListingPageObjects.keywordSearchTextbox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to case Listing is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to case Listing is Unsuccessfull", true);
			}
			break;
		case "caseSeries":
			menuNavigation("Case series");
			status = agIsVisible(CaseManagementPageObjects.caseSerieskeywordSearchTextbox);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to Case Series is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Case Series is Unsuccessfull", true);
			}
			break;

		case "correspondenceListing":
			menuNavigation("Correspondence listing");
			status = agIsVisible(CaseManagementPageObjects.unreadCorreskeywordSearchTextbox);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to Correspondence Listing is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Correspondence Listing is Unsuccessfull", true);
			}
			break;
		case "bulkImports":
			menuNavigation("Bulk imports");
			status = agIsVisible(CaseManagementPageObjects.bulkImportskeywordSearchTextbox);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to bulk Imports is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to bulk Imports is Unsuccessfull", true);
			}
			break;
		case "followupQueryTracker":
			menuNavigation("Follow up query tracker");
			status = agIsVisible(CaseManagementPageObjects.followUpkeywordSearchTextbox);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS,
						"Navigation to followup Query Tracker is successfull" + "<br />", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to followup Query Tracker is Unsuccessfull", true);
			}
			break;
		case "e2bMessageQueueListing":
			menuNavigation_ObjectID(CaseManagementPageObjects.e2bMessageQueueListing);
			agSetStepExecutionDelay("5000");
			status = agIsVisible(CaseManagementPageObjects.E2BMsgQkeywordSearchTextbox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "", true);
				Reports.ExtentReportLog("", Status.INFO, "Navigation to E2B Message Queue is successfull" + "<br />",
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to E2B Message Queue is Unsuccessfull", true);
			}
			break;
		case "unstructuredForm":
			agSetStepExecutionDelay("4000");
			agMouseHover(CaseManagementPageObjects.caseManagementHover);
			agMouseHover(CaseManagementPageObjects.newCaseHover);
			agClick(CaseManagementPageObjects.unstructuredFormSubMenu);
			// agSetStepExecutionDelay("8000");
			CommonOperations.agwaitTillVisible(UnstructuredFormPageObjects.senderUnit_TextBox, 2, 1000);
			status = agIsVisible(UnstructuredFormPageObjects.senderUnit_TextBox);
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "", false);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Unstructured form is Unsuccessfull", true);
			}
			break;
		case "emailIntakeMessageQueue":
			menuNavigation_ObjectID(CaseManagementPageObjects.emailIntakeMessageQueue);
			agSetStepExecutionDelay("5000");
			status = agIsVisible(CaseManagementPageObjects.senderEmailTitle);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "", false);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Email Intake  Message Queue is Unsuccessfull",
						true);
			}
			break;
		default:
			System.out.println("Invalid Menu Link!");
		}

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to save the FDE case
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 14-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void FDE_Save(String scenarioName, String sheetName) {
		agClick(CaseManagementPageObjects.saveButton);
		writeRecptNo_FDESave(scenarioName, sheetName);
		String receiptNumber = agGetText(CaseManagementPageObjects.Popup_onSave_GetRecptNo);
		status = agIsVisible(CaseManagementPageObjects.Popup_onSave_GetRecptNo);
		if (status) {
			agAssertContainsText(CaseManagementPageObjects.Popup_onSave_GetRecptNo, "saved successfully");
			Reports.ExtentReportLog("LSMV create new case receipt", Status.PASS,
					"New case creation successfull :: Validation-" + receiptNumber, true);
		} else {
			Reports.ExtentReportLog("LSMV create new case receipt", Status.FAIL,
					"New case creation unsuccessfull :: Validation-" + receiptNumber, true);
		}

		agClick(CaseManagementPageObjects.validationPopup_OkButton);

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created write Receipt No To Datasheet.
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 14-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void writeRecptNo_FDESave(String scenarioName, String sheetName) {
		agSetStepExecutionDelay("8000");
		String receiptNumber = agGetText(CaseManagementPageObjects.Popup_onSave_GetRecptNo);
		agSetStepExecutionDelay("1000");
		String[] arrOfStr = receiptNumber.split("Receipt number");
		arrOfStr = arrOfStr[1].split("saved successfully");
		receiptNumber = arrOfStr[0].trim();
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "ReceiptNo", receiptNumber);

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created Cancel the case.
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 14-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void FDE_Cancel() {
		agClick(CaseManagementPageObjects.cancelButton);
		agIsVisible(CaseManagementPageObjects.caseListingkeywordSearchTextbox);
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created Save and Exit the case.
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 14-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void FDE_SaveandExit(String scenarioName, String sheetName) {
		agClick(CaseManagementPageObjects.saveandExitButton);
		CommonOperations.agwaitTillVisible(CaseManagementPageObjects.Popup_onSave_GetRecptNo);
		writeRecptNo_FDESave(scenarioName, sheetName);
		String receiptNumber = agGetText(CaseManagementPageObjects.Popup_onSave_GetRecptNo);
		status = agIsVisible(CaseManagementPageObjects.Popup_onSave_GetRecptNo);
		if (status) {
			agAssertContainsText(CaseManagementPageObjects.Popup_onSave_GetRecptNo, "saved successfully");
			Reports.ExtentReportLog("LSMV create new case receipt", Status.PASS,
					"New case creation successfull :: Validation-" + receiptNumber, true);
		} else {
			Reports.ExtentReportLog("LSMV create new case receipt", Status.FAIL,
					"New case creation unsuccessfull :: Validation-" + receiptNumber, true);
		}

		agClick(CaseManagementPageObjects.validationPopup_OkButton);

	}

	/**********************************************************************************************************
	 * @Objective: The below method will click the more options link
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 24-jun-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void MoreOptionsLinksNavigation(String object) {

		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(object);
	}

	/**********************************************************************************************************
	 * @Objective: The below method will click the more options link
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 17-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void navigateHomeDashboard() {
		agMouseHover(CaseManagementPageObjects.homeButton);
		agClick(CaseManagementPageObjects.dashboard);
		agSetGlobalTimeOut("3");
		if (agIsVisible(LoginPageObjects.confirmationWindow) == true) {
			agClick(LoginPageObjects.okButton);
		}
		agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
		agWaitTillInvisibilityOfElement(CaseListingPageObjects.oWS_SearchLoading);
		status = agIsVisible(HomePageObjects.headerSettingBlock);
		if (status) {
			Reports.ExtentReportLog("Login", Status.PASS, "Navigation to dashboard Successfull", true);
		} else
			Reports.ExtentReportLog("Login", Status.FAIL, "Navigation to dashboard Unsuccessfull", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is used to created to search the created case in
	 *             case listing.
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 28-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void searchCase(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetStepExecutionDelay("10000");
		CaseManagementOperations.menuNavigation("Case listing");
		agWaitTillVisibilityOfElement(CaseListingPageObjects.keywordSearchTextbox);
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, columnName));
		agClick(CaseListingPageObjects.searchButton);

		CommonOperations.agwaitTillVisible(
				CaseListingPageObjects.waitForRCT(FDE_General.getData(scenarioName, columnName)), 4, 1000);

		Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);

		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is used to edit the to search case in case
	 *             listing.
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 28-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void editCase() {
		agWaitTillVisibilityOfElement(CaseListingPageObjects.receiptNumberlink);
		agClick(CaseListingPageObjects.receiptNumberlink);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is used to search based on workflow activity in
	 *             case listing page
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 28-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void FilterByWorkflowActivity(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetStepExecutionDelay("2000");
		agWaitTillVisibilityOfElement(CaseListingPageObjects.listingColumnFilter);
		agClick(CaseListingPageObjects.listingColumnFilter);
		agSetValue(CaseListingPageObjects.workflowActivitySearch, getTestDataCellValue(scenarioName, columnName));
		agSendKeyStroke(Keys.ENTER);
		agWaitTillInvisibilityOfElement(CaseListingPageObjects.searchLoader);

		Reports.ExtentReportLog("", Status.INFO, "workflow search is listed", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is used to identify searched case in case
	 *             listing page
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 28-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void caseIdentification(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetStepExecutionDelay("10000");
		CaseManagementOperations.menuNavigation("Case listing");
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, columnName));
		agClick(CaseListingPageObjects.searchButton);

		CommonOperations.agwaitTillVisible(
				CaseListingPageObjects.waitForRCT(FDE_General.getData(scenarioName, columnName)), 4, 1000);

		agIsVisible(CaseListingPageObjects.receiptNumberlink);
		agAssertContainsText(CaseListingPageObjects.receiptNumberlink, getTestDataCellValue(scenarioName, "ReceiptNo"));
		String validation = agGetText(CaseListingPageObjects.receiptNumberlink);
		status = agIsVisible(CaseListingPageObjects.receiptNumberlink);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Case Identified successfully::" + validation, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Case Identified Unsuccessfully::" + validation, true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to get Top Recpt No from Email Intake
	 *                Msg Q and write To Test Data
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Praveen Patil
	 * @Date : 28-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void getTopRecptNo_fromEmailIntakeMsgQ_writeToTestData(String scenarioName, String sheetName) {

		String receiptNumber = agGetText(CommonPageObjects.emailIntakeMsgTopReceiptNo);
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "ReceiptNo", receiptNumber);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the Submission tracking tab
	 *             in all activities based on the Enable submission tracking
	 *             checkbox [check/uncheck]at workflow level
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :04-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verificationOfSubmissionTrackingTab(String scenarioName, String Activity) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "WorkflowConfigurations");
		String submissionTrackStatus = getTestDataCellValue(scenarioName, "EnableSubmissionTrackingCheckBox");
		if (submissionTrackStatus.equalsIgnoreCase("Yes")) {
			if (agIsVisible(FullDataEntryFormPageObjects.FDE_tabNavigation("Submission Tracking")) == true) {
				agClick(FullDataEntryFormPageObjects.FDE_tabNavigation("Submission Tracking"));
				agSetStepExecutionDelay("2000");
				Reports.ExtentReportLog("", Status.PASS,
						" Submission tracking tab is enabled for the case  >> " + " WorkFlow: " + Activity, true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						" Submission tracking tab is not enabled for the case  >> " + " WorkFlow: " + Activity, true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		} else if (submissionTrackStatus.equalsIgnoreCase("No")) {
			if (agIsVisible(FullDataEntryFormPageObjects.FDE_tabNavigation("Submission Tracking")) == true) {
				agClick(FullDataEntryFormPageObjects.FDE_tabNavigation("Submission Tracking"));
				agSetStepExecutionDelay("2000");
				Reports.ExtentReportLog("", Status.FAIL,
						" Submission tracking tab is enabled for the case  >> " + " WorkFlow: " + Activity, true);
			} else {
				Reports.ExtentReportLog("", Status.PASS,
						" Submission tracking tab is not enabled for the case  >> " + " WorkFlow: " + Activity, true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		if (submissionTrackStatus.equalsIgnoreCase("") || submissionTrackStatus.equalsIgnoreCase("#skip#")) {
			Reports.ExtentReportLog("", Status.INFO, " No Value provided for the workflow " + Activity, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the Allow manual Lock
	 *             functionality in all activities based on the "Allow Manual Lock"
	 *             checkbox [check/uncheck]at workflow level
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :09-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verificationOfAllowManualLock(String WFscenarioName, String Activity, String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "WorkflowConfigurations");
		boolean manualLockStatus;
		String allowManualLockStatus = getTestDataCellValue(WFscenarioName, "AllowManualLockCheckBox");
		if (allowManualLockStatus.equalsIgnoreCase("Yes")) {
			manualLockStatus = agIsVisible(CaseManagementPageObjects.manualLock_Btn);
			if (manualLockStatus) {
				Reports.ExtentReportLog("", Status.PASS,
						" Allow Manual Lock is enabled for the case  >> " + " WorkFlow: " + Activity, true);

				agJavaScriptExecuctorClick(CaseManagementPageObjects.manualLock_Btn);
				agSetStepExecutionDelay("2000");
				agWaitTillVisibilityOfElement(CaseManagementPageObjects.manualLockValidation_Msg);
				String manualLockValidationMsg = agGetText(CaseManagementPageObjects.manualLockValidation_Msg);
				Reports.ExtentReportLog("", Status.INFO, " Case is manually locked " + manualLockValidationMsg, true);
				agJavaScriptExecuctorClick(CaseManagementPageObjects.manualLock_OkBtn);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				CaseListingOperations.searchCase_Edit(scenarioName, "FDE_General", "ReceiptNo");
				if (agIsVisible(CaseManagementPageObjects.manualUnlock_Btn) == true) {
					Reports.ExtentReportLog("", Status.PASS,
							" Case is manually locked; Case is in uneditable form >> " + " WorkFlow: " + Activity,
							true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL,
							" Case is not manually locked; Case is not in uneditable form >> " + " WorkFlow: "
									+ Activity,
							true);
				}

			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						" Allow Manual Lock is not enabled for the case  >> " + " WorkFlow: " + Activity, true);
			}

		} else if (allowManualLockStatus.equalsIgnoreCase("No")) {
			manualLockStatus = agIsVisible(CaseManagementPageObjects.manualLock_Btn);
			if (manualLockStatus) {
				Reports.ExtentReportLog("", Status.FAIL,
						" Allow Manual Lock is enabled for the case  >> " + " WorkFlow: " + Activity, true);
			} else {
				Reports.ExtentReportLog("", Status.PASS,
						" Allow Manual Lock is not enabled for the case  >> " + " WorkFlow: " + Activity, true);
			}
		}
		if (allowManualLockStatus.equalsIgnoreCase("") || allowManualLockStatus.equalsIgnoreCase("#skip#")) {
			Reports.ExtentReportLog("", Status.INFO, " No Value provided for the workflow " + Activity, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify RCT number date format
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDateFormat(String scenarioName) {

		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agWaitTillVisibilityOfElement(CaseManagementPageObjects.getRCTNo);
		String RCT = agGetText(CaseManagementPageObjects.getRCTNo);
		String Prefix = AppParameters_CaseManagement.getData(scenarioName, "ReceiptPrefix");
		String dateFormat = AppParameters_CaseManagement.getData(scenarioName, "ReceiptDateFormat").replace("MON",
				"MMM");
		String separator = AppParameters_CaseManagement.getData(scenarioName, "ReceiptSeparator");
		String[] arrSplit = RCT.split(Prefix);
		String date[] = arrSplit[1].split(separator);
		String date1 = date[0];
		String ActualDate = CommonOperations.GetDateinRequiredFormat(dateFormat);
		if (date1.equals(ActualDate) == true) {
			Reports.ExtentReportLog("", Status.PASS,
					"Date Format In RCT No is::" + date1 + "::Date format in Application Parameter is::" + dateFormat,
					true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Date Format In RCT No is::" + date1 + "::Date format in Application Parameter is::" + dateFormat,
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Write data into excel sheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Mnually unlock the case
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 10-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void manualUnlock() {
		agSetStepExecutionDelay("2000");
		if (agIsVisible(CaseManagementPageObjects.manualUnlock_Btn) == true) {
			agClick(CaseManagementPageObjects.manualUnlock_Btn);
			String ValidationMsg = agGetText(CaseManagementPageObjects.manualLockValidation_Msg);
			Reports.ExtentReportLog("", Status.INFO, " Case is manually Unlocked " + ValidationMsg, true);
			agClick(CaseManagementPageObjects.manualLock_OkBtn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} else {
			Reports.ExtentReportLog("", Status.INFO, " Allow manual unlock button not visible", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Allow Compare and Reconcile
	 *             for Follow Up in different workflows in all activities based on
	 *             the "Allow Compare and Reconcile for Follow Up in different
	 *             workflows" checkbox [check/uncheck]at workflow level
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :18-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verificationOfAllowCompareAndReconcileFollowUp(String WFscenarioName, String Activity,
			String parentCaseScenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "WorkflowConfigurations");
		String allowCmpreReconcileStatus = getTestDataCellValue(WFscenarioName,
				"AllowCompareReconcileFollowUpCheckBox");
		if (allowCmpreReconcileStatus.equalsIgnoreCase("Yes")) {

			// verify if Follow up received case is in Case listing screen
			if (agIsExists(CaseListingPageObjects.newButton)) {
				String RCTnum = FDE_General.getData(parentCaseScenarioName, "ReceiptNo");
				agSetValue(CaseListingPageObjects.keywordSearchTextbox, RCTnum);
				agClick(CaseListingPageObjects.searchButton);
				if (agIsVisible(FollowupNotificationPageObjects.followupReceived_icon) == true) {
					agClick(CaseListingPageObjects.receiptNumberlink);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, " Followup received icon is not visible for the case ",
							true);
				}

				verifyFollowupReconcileAlert(Activity);
			}
			// verify if Follow up received case is Opened
			else if (agIsVisible(DataAssessmentPageObjects.followupNotificationAlert) == true) {
				verifyFollowupReconcileAlert(Activity);
			}
			// verify if Follow up received case to be searched
			else {
				CaseListingOperations.searchCase_Edit(parentCaseScenarioName, "FDE_General", "ReceiptNo");
				verifyFollowupReconcileAlert(Activity);
			}

		} else if (allowCmpreReconcileStatus.equalsIgnoreCase("No")) {
			verificationOfFollowupReconcileAlertBasedOnListing(Activity, parentCaseScenarioName);
		}

		if (allowCmpreReconcileStatus.equalsIgnoreCase("") || allowCmpreReconcileStatus.equalsIgnoreCase("#skip#")) {
			Reports.ExtentReportLog("", Status.INFO, " No Value provided for the workflow " + Activity, true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the follow up reconcilation
	 *             alert pop up visible or not
	 * @InputParameters:
	 * @OutputParameters: Activity
	 * @author:Pooja S
	 * @Date :18-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyFollowupReconcileAlert(String Activity) {
		agSetStepExecutionDelay("2000");
		if (agIsVisible(DataAssessmentPageObjects.followupNotificationAlert) == true) {
			String reconcileNotification = agGetText(DataAssessmentPageObjects.followupNotificationAlert);
			Reports.ExtentReportLog("", Status.PASS, "Reconcile followup Notification Alert is visible :: Alert-"
					+ reconcileNotification + " WorkFlowActivity : " + Activity, true);
			agClick(DataAssessmentPageObjects.followupReconsileNoBtn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.loading);
			if (agIsVisible(DataAssessmentPageObjects.followupReconsileIcon) == true) {
				Reports.ExtentReportLog("", Status.PASS, "Reconcile followup Notification Icon visible", true);
				agClick(DataAssessmentPageObjects.followupReconsileIcon);
				ReconciliationOperations.reconciliationWindowVerification();
				agClick(FullDataEntryFormPageObjects.followupReconcileWindowClose);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Reconcile followup Notification Alert is not visible :: " + " WorkFlowActivity : " + Activity,
						true);
			}

		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Reconcile followup Notification Alert is not visible" + " WorkFlowActivity : " + Activity, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the followup received case
	 *             should be searched or in case listing or opened
	 * @InputParameters:
	 * @OutputParameters:Activity,scenarioName
	 * @author:Pooja S
	 * @Date :18-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verificationOfFollowupReconcileAlertBasedOnListing(String Activity,
			String parentCaseScenarioName) {
		// verify if Follow up received case is in Case listing screen
		if (agIsExists(CaseListingPageObjects.newButton)) {
			String RCTnum = FDE_General.getData(parentCaseScenarioName, "ReceiptNo");
			agSetValue(CaseListingPageObjects.keywordSearchTextbox, RCTnum);
			agClick(CaseListingPageObjects.searchButton);
			if (agIsVisible(FollowupNotificationPageObjects.followupReceived_icon) == true) {
				agClick(CaseListingPageObjects.receiptNumberlink);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, " Followup received icon is not visible for the case ", true);
			}
			if (agIsVisible(DataAssessmentPageObjects.followupNotificationAlert) == true) {
				String reconcileNotification = agGetText(DataAssessmentPageObjects.followupNotificationAlert);
				Reports.ExtentReportLog("", Status.FAIL, "Reconcile followup Notification Alert is visible :: Alert-"
						+ reconcileNotification + " WorkFlowActivity : " + Activity, true);

			} else {
				Reports.ExtentReportLog("", Status.PASS,
						"Reconcile followup Notification Alert is not visible" + " WorkFlowActivity : " + Activity,
						true);
			}
		}
		// verify if Follow up recevived case is Opened
		else if (agIsVisible(DataAssessmentPageObjects.followupNotificationAlert) == true) {
			if (agIsVisible(DataAssessmentPageObjects.followupNotificationAlert) == true) {
				String reconcileNotification = agGetText(DataAssessmentPageObjects.followupNotificationAlert);
				Reports.ExtentReportLog("", Status.FAIL, "Reconcile followup Notification Alert is visible :: Alert-"
						+ reconcileNotification + " WorkFlowActivity : " + Activity, true);

			} else {
				Reports.ExtentReportLog("", Status.PASS,
						"Reconcile followup Notification Alert is not visible" + " WorkFlowActivity : " + Activity,
						true);
			}
		}
		// verify if Follow up received case to be searched
		else {
			CaseListingOperations.searchCase_Edit(parentCaseScenarioName, "FDE_General", "ReceiptNo");
			if (agIsVisible(DataAssessmentPageObjects.followupNotificationAlert) == true) {
				String reconcileNotification = agGetText(DataAssessmentPageObjects.followupNotificationAlert);
				Reports.ExtentReportLog("", Status.FAIL, "Reconcile followup Notification Alert is visible :: Alert-"
						+ reconcileNotification + " WorkFlowActivity : " + Activity, true);

			} else {
				Reports.ExtentReportLog("", Status.PASS,
						"Reconcile followup Notification Alert is not visible" + " WorkFlowActivity : " + Activity,
						true);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the Case validity
	 *             Identifier in application parameters
	 * @InputParameters:
	 * @OutputParameters:scenarioName
	 * @author:Pooja S
	 * @Date :05-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verificationOfCaseValidityIdentifier(String AppParamScenarioName, String PatScenario,
			String RepScenario) {
		String patientStatus = null;
		String atleastOneReporterStatus = null;
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_General");
		patientStatus = getTestDataCellValue(AppParamScenarioName, "PatientAvailable");
		atleastOneReporterStatus = getTestDataCellValue(AppParamScenarioName, "AtLeastOneReporter");
		if (patientStatus.equalsIgnoreCase("true") && atleastOneReporterStatus.equalsIgnoreCase("true")) {
			if (FDE_Patient.isPatDetKeyed(PatScenario) == true || FDE_Reporter.isRepDetKeyed(RepScenario) == true) {
				CaseManagementOperations.verifyReportClassificationAsInValid();
			} else {
				CaseManagementOperations.verifyReportClassificationAsValid();
			}
		} else if (atleastOneReporterStatus.equalsIgnoreCase("true") && patientStatus.equalsIgnoreCase("false")) {
			if (FDE_Reporter.isRepDetKeyed(RepScenario) == true) {
				CaseManagementOperations.verifyReportClassificationAsValid();
			} else if (FDE_Reporter.isRepDetKeyed(RepScenario) == true) {
				CaseManagementOperations.verifyReportClassificationAsInValid();

			}
		} else if (patientStatus.equalsIgnoreCase("true") && atleastOneReporterStatus.equalsIgnoreCase("false")) {
			if (FDE_Patient.isPatDetKeyed(PatScenario) == true) {
				CaseManagementOperations.verifyReportClassificationAsValid();
			} else {
				CaseManagementOperations.verifyReportClassificationAsInValid();
			}
		} else if (patientStatus.equalsIgnoreCase("false") && atleastOneReporterStatus.equalsIgnoreCase("false")) {

			CaseManagementOperations.verifyReportClassificationAsValid();
		} else

		{
			Reports.ExtentReportLog("", Status.FAIL, " Incorrect Details Provided : " + " PatientAvailable : "
					+ patientStatus + "and" + " AtleastoneReporterAvailable : " + atleastOneReporterStatus, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the ReportClassification is
	 *             set as Valid
	 * @InputParameters:
	 * @OutputParameters:scenarioName
	 * @author:Pooja S
	 * @Date :10-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyReportClassificationAsValid() {
		FDE_Operations.tabNavigation("General");
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.caseReportlabel);
		String reportClassification = agGetText(FDE_GeneralPageObjects.reportClassification);
		if (reportClassification.equalsIgnoreCase("--Select--")) {
			Reports.ExtentReportLog("", Status.PASS, "Report Classification set to Valid", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, " Report Classification is not set to Valid", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the ReportClassification is
	 *             set as InValid
	 * @InputParameters:
	 * @OutputParameters:scenarioName
	 * @author:Pooja S
	 * @Date :10-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyReportClassificationAsInValid() {
		FDE_Operations.tabNavigation("General");
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.caseReportlabel);
		String reportClassification = agGetText(FDE_GeneralPageObjects.reportClassification);
		if (reportClassification.equalsIgnoreCase("Invalid")) {
			Reports.ExtentReportLog("", Status.PASS, "Report Classification set to Invalid", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, " Report Classification is not set to Invalid", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}
}