package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class FDE_EventsPageObjects {

	public static String eventSeriousness_Label = "xpath#//label[starts-with(text(),'Event Seriousness')]";
public static String existingTermconformationPopup = "xpath#//p-confirmdialog/div";
	
	public static String existingTermconformationPopup_OkBtn = "xpath#//p-confirmdialog//div/button/span[text()='Yes']";
	public static String eventsAdd_Button = "xpath#//label[text()='Event(s)']/following-sibling::span/a[text()='Add']";
	public static String setData_Textfields = "xpath#//label[contains(text(),'%s')]/following-sibling::span/input";
	public static String click_Checkboxs = "xpath#//label[contains(text(),'%s')]/following-sibling::span/p-checkbox/div";
	public static String select_RadioButtons = "xpath#//label[contains(text(),'%s')]/following-sibling::span/span/p-radiobutton/label[contains(text(),'%r')]";
	public static String click_DropDown = "xpath#//label[contains(text(),'%s')]/following-sibling::span/p-dropdown//div/label";
	public static String setdropDownValue = "xpath#//ul[contains(@class,'ui-dropdown-items')]/child::li/div/span[contains(text(),'%s')]";
	public static String add_Delete_Buttons = "xpath#//p-panel[@id='fdePanelId939']//label[text()='Event(s)']/following-sibling::span[contains(@class,'agAddDeleteBlock')]/a[contains(text(),'%s')]";
	public static String setData_Datesfields = "xpath#//label[contains(text(),'%s')]/following-sibling::span/span/input";
	public static String eventMedDRALLTCode_Lookup = "xpath#//a[@class='agLookupLink']//img";
	public static String reportedTerm_Textfield = "xpath#//label[text()='Reported Term']/following-sibling::span/input";
	public static String OtherMedicallyCondition_Textarea = "xpath#//label[contains(text(),'Other Medically Important Condition Info')]/following-sibling::span/textarea";
	public static String getData_eventMedDRALLTCode = "xpath#//label[text()='Event MedDRA LLT Code']/ancestor::div/span/a[@styleclass='agMedraTooltipLink']";

	public static String causedByDrugInteraction_Radiobtn = "xpath#//label[contains(text(),'Caused By Drug Interaction')]/following-sibling::span/span/p-radiobutton/label[contains(text(),'%r')]";
	public static String medicallyConfirmed_Radiobtn = "xpath#//label[contains(text(),'Medically Confirmed')]/following-sibling::span/span/p-radiobutton/label[contains(text(),'%r')]";
	public static String eventMedDRALLTCode_Textfield = "xpath#//input[@id = 'adverseEventNew:reactionPanelTable:reactionMeddraLltDecode_input']";
	public static String manual_Checkbox = "xpath#(//label[text()='%s']/following::label[text()='Manual']/../descendant::span[contains(@class,'ui-chkbox-icon')])[1]";
	public static String durationManual_Checkbox = "xpath#//div/span/label[text()='Duration ']/ancestor::div[contains(@class,'agDynamicContent row')]/div/label[text()='Manual']/parent::div/p-checkbox/div//span";
	public static String causedByLackOfEffect_Radiobtn = "xpath#//label[contains(text(),'Caused by Lack of Effect')]/following-sibling::span/span/p-radiobutton/label[contains(text(),'%r')]";
	public static String eventInformation_Label = "xpath#//label[text()='Event Information']";
	public static String reportedTerm_Label = "xpath#//label[text()='Reported Term '] ";
	public static String eventMedDRALLTCode = "xpath#//input[@id='adverseEventNew:reactionPanelTable:reactionMeddraLltDecode_input']";

	// Label Names
	public static String causedByDrugInteractionRadioBtn_Label = "Caused By Drug Interaction";
	public static String causedByLackOfEffectRadioBtn_Label = "Caused by Lack of Effect";
	public static String medicallyConfirmedRadioBtn_Label = "Medically Confirmed";
	public static String reportedTerm_Textbox = "Reported Term";
	public static String onsetDate_Date = "Onset date";
	public static String cessationdate_Date = "Cessation date";
	public static String eventType_DropDown = "Event Type";
	public static String outCome_DropDown = "Outcome";
	public static String reportedTermLanguage_Textbox = "Reported Term In Native Language";
	public static String duration_Textbox = "Duration";
	public static String countryDetection_DropDown = "Country of Detection";
	public static String nativeLanguage_DropDown = "Native Language";
	public static String termHighlighted_DropDown = "Term Highlighted";
	public static String severity_DropDown = "Severity";
	public static String AEInformation_Textbox = "AE Additional Information";

	public static String eventMedDRALLTCode_Textbox = "Event MedDRA LLT Code ";
	public static String durationManual_checkbox = "Manual";
	public static String isAlwaysSeriousEvent_checkbox = "Always Serious Event";
	// Event Seriousness
	public static String seriousness_Radiobtn = "Seriousness";
	public static String requiredIntervenation_Radiobtn = "Required Intervention";
	public static String death_Radiobtn = "Death?";
	public static String lifeThreatening_Radiobtn = "Life Threatening?";
	public static String congenitalAnomalyBirthDefect_Radiobtn = "Congenital Anomaly/Birth Defect?";
	public static String caused_prolongedhospitalization_Radiobtn = "Caused/prolonged hospitalization";
	public static String disability_PermanentDamage_Radiobtn = "Disability/Permanent Damage?";
	public static String OtherMedicallyCondition_Radiobtn = "Other Medically Important Condition";
	public static String HospitalizationFrom_Date = "Hospitalization Date: From";
	public static String HospitalizationTo_Date = "Hospitalization Date: To";
	public static String addButton = "xpath#(//a[contains(@class,'agMultiAddLink')][text()='Add'])[2]";
	// Latency
	public static String startLatency_Textfield = "xpath#//input[@id='adverseEventNew:reactionPanelTable:reactionFirstId']";
	public static String endLatency_Textfield = "xpath#//input[@id='adverseEventNew:reactionPanelTable:reactionLastId']";
	public static String startLatency_DropDown = "Start Latency";
	public static String endLatency_DropDown = "End Latency";
	public static String startLatencyManual_Checkbox = "xpath#(//div/span/label[text()='Start Latency ']/ancestor::div[contains(@class,'agFieldWithManual')]/following-sibling::div/p-checkbox/div//span)[1]";
	public static String endLatencyManual_Checkbox = "xpath#//div/span/label[text()='End Latency ']/ancestor::div[contains(@class,'agFieldWithManual')]/following-sibling::div/p-checkbox/div//span";

	public static String MetraLookup = "xpath#//td[text()='%s']";
	public static String MedraValidation = "xpath#//span[contains(text(),'Hierarchy of the Term')]";

	// Treatment
	public static String treatmentPerformed_DropDown = "Treatment Performed";
	public static String treatmentDescription_Textarea = "xpath#//label[contains(text(),'Treatment Description ')]/following-sibling::span/textarea";

	public static String secondEvent = "xpath#//li[contains(@class,'ui-state-default ui-corner-top fdeMultiPanel939_2')]//span[contains(text(),'%s')]";

	// IME , DME
	public static String iME_Checkbox = "IME";
	public static String dME_Checkbox = "DME";

	// Event Seriousness selected
	public static String eventSeriousnessSelected = "xpath#//label[contains(text(),'%s')]/following-sibling::span/span/p-radiobutton/div/div[contains(@class,'ui-state-active')]";

	public static String clickNF_Btn = "xpath#(//div[@class='ui-tabview-panels']//a[@class='agNfAppliedLink'])[5]";

	public static String checkBoxUnder = "xpath#//label[starts-with(normalize-space(text()),'{0}')]/../descendant::div[contains(@class,'ui-chkbox-box')]";

	public static String eventMedraPTCode = "xapth#(//div//label[text()='Event MedDRA PT Code ']/following::input[contains(@id,'reactionMeddraPtDecode')]/following::span/a)[1]";

	public static String aeAdditionalInfoLabel = "xpath#//label[text()='AE Additional Information ']";

	public static String radioBtnVerification = "xpath#//label[contains(text(),'%s')]/parent::span//p-radiobutton//span[@class='ui-radiobutton-icon ui-clickable pi pi-circle-on']";

	public static String checkboxVerification = "xpath#//label[starts-with(normalize-space(text()),'%label%')]/../descendant::div/span[contains(@class,'ui-chkbox-icon ui-clickable pi pi-check')]";

	public static String click_MultipleEvents = "xpath#//div[@class='tabCarouselSty']/ul/li/a/span[contains(text(),'%s')]";
	public static String getListOfEvents = "xpath#//div[@class='tabCarouselSty']/ul[@role='tablist']/li";

	// Labels

	public static String eventInfo_Label = "xpath#//div[contains(@class,'agTopBreadCrumbsHeader')]/ul/li/a[text()='Event Information']";
	public static String eventSerious_Label = "xpath#//div[contains(@class,'agTopBreadCrumbsHeader')]/ul/li/a[text()='Event Seriousness']";
	public static String latency_Label = "xpath#//div[contains(@class,'agTopBreadCrumbsHeader')]/ul/li/a[text()='Latency']";
	public static String treatment_Label = "xpath#//div[contains(@class,'agTopBreadCrumbsHeader')]/ul/li/a[text()='Treatment']";
	public static String similarIncident_Label = "xpath#//div[contains(@class,'agTopBreadCrumbsHeader')]/ul/li/a[text()='Similar Incident']";
	public static String incidentRelatedFields_label = "xpath#//div[contains(@class,'agTopBreadCrumbsHeader')]/ul/li/a[text()='Incident Related Fields']";

	public static String NoInformation = "xpath#//label[contains(text(),'%s')]/parent::span//p-dropdown//span[text()='No Information']";

	public static String prevNavigaterClick = "xpath#//div[@class='tabCarouselSty']//li[contains(@class,'ui-state-default ui-corner-top fdeMultiPanel939_1')]";
	public static String forwardNavigaterClick = "xpath#//div[@class='tabCarouselSty']//li[contains(@class,'ui-state-default ui-corner-top fdeMultiPanel939_2')]";

	public static String suspectEventCodedlist = "xpath#//span[contains(@class,'reactionTabSDLautoCoded')]";
	public static String suspectEventCoded = "xpath#(//span[contains(@class,'reactionTabSDLautoCoded')])[%count%]";
	public static String suspectEventNotCodedlist = "xpath#//span[contains(@class,'reactionTabSDLnotAutoCoded')]";
	public static String suspectEventNotCoded = "xpath#(//span[contains(@class,'reactionTabSDLnotAutoCoded')])[%count%]";

	//R2 tags
	public static String R2ReportedTerm = "xpath#//label[text()='Reported Term ']//parent::span/label[text()='[B.2.i.0]']";
	public static String R2EventMedDRALLTCode = "xpath#//label[text()='[B.2.i.1.b]']";
	public static String R2EventMedDRAPTCode = "xpath#//label[text()='[B.2.i.2.b]']";
	public static String R2TermHighlighted = "xpath#//label[text()='[B.2.i.3]']";
	public static String R2OnsetDate= "xpath#//label[text()='Onset date ']//parent::span/label[text()='[B.2.i.4b]']";
	public static String R2CessationDate = "xpath#//label[text()='Cessation date ']//parent::span/label[text()='[B.2.i.5b]']";
	public static String R2Duration = "xpath#//label[text()='[B.2.i.6a]']";
	public static String R2Outcome = "xpath#//label[text()='Outcome ']//parent::span/label[text()='[B.2.i.8]']";
	public static String R2StartLatency = "xpath#//label[text()='[B.2.i.7.1a/b]']";
	public static String R2EndLatency = "xpath#//label[text()='[B.2.i.7.2a/b]']";
	
	
	//R3 Tags 
	public static String R3ReportedTerm = "xpath#//label[text()='Reported Term ']//parent::span/label[text()='[E.i.1.2]']";
	public static String R3EventMedDRALLTCode ="xpath#//label[text()='[E.i.2.1b]']";
	public static String R3ReportedTermInNativeLanguage = "xpath#//label[text()='[E.i.1.1a]']";
	public static String R3NativeLanguage = "xpath#//label[text()='[E.i.1.1b]']";
	public static String R3TermHighlighted = "xpath#//label[text()='[E.i.3.1]']";
	public static String R3OnsetDate = "xpath#//label[text()='Onset date ']//parent::span/label[text()='[E.i.4]']";
	public static String R3CessationDate = "xpath#//label[text()='Cessation date ']//parent::span/label[text()='[E.i.5]']";
	public static String R3Duration = "xpath#//label[text()='[E.i.6a/b]']";
	public static String R3CountryOfDetection = "xpath#//label[text()='[E.i.9]']";
	public static String R3MedicallyConfirmed = "xpath#//label[text()='[E.i.8]']";
	public static String R3Outcome = "xpath#//label[text()='Outcome ']//parent::span/label[text()='[E.i.7]']";
	public static String R3Seriousness = "xpath#//label[text()='Seriousness ']//parent::span/label[text()='[E.i.3.2]']";
	public static String R3Death = "xpath#//label[text()='[E.i.3.2a]']";
	public static String R3LifeThreatening = "xpath#//label[text()='[E.i.3.2b]']";
	public static String R3Caused_ProlongedHospitalization= "xpath#//label[text()='[E.i.3.2c]']";
	public static String R3Disability_PermanentDamage = "xpath#//label[text()='[E.i.3.2d]']";
	public static String R3CongenitalAnomaly_BirthDefect = "xpath#//label[text()='[E.i.3.2e]']";
	public static String R3OtherMedicallyImportantCondition = "xpath#//label[text()='[E.i.3.2f]']";
	public static String R3RequiredIntervention = "xpath#//label[text()='[FDA.E.i.3.2h]']";
			
	//codelist tags 
	public static String CLCodingType = "xpath#//label[text()='[158]']";
	public static String CLNativeLanguage = "xpath#//label[text()='[9065]']";
	public static String ClHighlightTerm = "xpath#//label[text()='[1011]']";
	public static String CLDuration = "xpath#//label[text()='Duration ']//parent::span/label[text()='[1017]']";
	public static String CLCountryOfDetection = "xpath#//label[text()='[1015]']";
	public static String CLMedicallyConfirmed = "xpath#//label[text()='Medically Confirmed ']//parent::span/label[text()='[1002]']";
	public static String CLEventType = "xpath#//label[text()='[9745]']";
	public static String CLSeverity = "xpath#//label[text()='[8106]']";
	public static String CLOutcome = "xpath#//label[text()='[1012]']";
	public static String CLCausedbyLackofEffect = "xpath#//label[text()='Caused by Lack of Effect ']//parent::span/label[text()='[1002]']";
	public static String CLCausedByDrugInteraction = "xpath#//label[text()='Caused By Drug Interaction ']//parent::span/label[text()='[1002]']";
	public static String CLReactionSite = "xpath#//label[text()='[9993]']";
	public static String CLExemptedEvents = "xpath#//label[text()='Exempted Events ']//parent::span/label[text()='[1002]']";
	public static String CLAnticipatedEvents = "xpath#//label[text()='Anticipated Events ']//parent::span/label[text()='[1002]']";
	public static String CLSeriousness = "Xpath#//label[text()='Seriousness ']//parent::span/label[text()='[1002]']";
	public static String CLDeath = "xpath#//label[text()='Death? ']//parent::span/label[text()='[1002]']";
	public static String CLLifeThreatening = "xpath#//label[text()='Life Threatening? ']//parent::span/label[text()='[1002]']";
	public static String CLCaused_prolongedHospitalization = "xpath#//label[text()='Caused/prolonged hospitalization ']//parent::span/label[text()='[1002]']";
	public static String CLDisability_PermanentDamage = "xpath#//label[text()='Disability/Permanent Damage? ']//parent::span/label[text()='[1002]']";
	public static String CLCongenitalAnomaly_BirthDefect = "xpath#//label[text()= 'Congenital Anomaly/Birth Defect? ']//parent::span/label[text()='[1002]']";
	public static String CLOtherMedicallyImportantCondition = "xpath#//label[text()= 'Other Medically Important Condition ']//parent::span/label[text()='[1002]']";
	public static String CLRequiredIntervention = "xpath#//label[text()= 'Required Intervention ']//parent::span/label[text()='[1002]']";
	public static String CLTreatmentPerformed = "xpath#//label[text()='[7089]']";
	public static String CLStartLatency = "xpath#//label[text()='Start Latency ']//parent::span/label[text()='[1017]']";
	public static String CLEndLatency = "xpath#//label[text()='End Latency ']//parent::span/label[text()='[1017]']";
	public static String CLUnanticipatedSeriousdeteriorationinstateofHealt = "xpath#//label[text()='Unanticipated Serious deterioration in state of Health ']//parent::span/label[text()='[1002]']";
	public static String CLSeriousPublicHealthThreat = "xpath#//label[text()='Serious Public Health Threat ']//parent::span/label[text()='[1002]']";
	public static String CLLocationWhereEventNotOccured = "xpath#//label[text()='[9864]']";
	public static String CLIMDRFCodesUsedForIdentifyingSimilarIncidents = "xpath#//label[text()='[10002]']";
	public static String CLBasisOfSimilarIncidentIdentification = "xpath#//label[text()='[10004]']";
	public static String CLCriteriaForDevicesInMarket  = "xpath#//label[text()='[10005]']";
	
	public static String eventOutcomeValue = "xpath#//label[contains(text(),'Outcome ')]/following-sibling::span/p-dropdown//div/label/span[text()='Fatal ( fat )']";
	public static String eventConfirmationPopUp_Message = "xpath#//div[@class='ui-dialog-content ui-widget-content']//span[@class='ui-confirmdialog-message']";
	public static String eventConfirmationPopUpYes_Btn = "xpath#//span[contains(@class,'ui-button-text ui-clickable') and text()= 'Yes']";
	
	public static String IMEDMEManualCheckBox="xpath#//label[contains(text(),'DME')]/parent::span/parent::div//parent::div/following-sibling::div//label[text()='Manual']/parent::div//p-checkbox";
	public static String IMEDMEManualNoCheckBox="xpath#(//label[contains(text(),'Always Serious Event ')]/parent::span/parent::div//parent::div/preceding-sibling::div//label[text()='Manual']/parent::div//p-checkbox)[3]";
	public static String IMEDEMDowngradePopUp="xpath#//label[contains(text(),'Event is Downgraded')]";
	public static String DowngradeComment="xpath#//textarea[@name='imeDmeDowngraded']";
	public static String SubmitBtnDowngrade="xpath#//p-dialog//span[text()='Submit']";
	public static String IMEUnchecked="xpath#//label[contains(text(),'DME')]/parent::span/parent::div//parent::div[@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-disabled']";
	public static String DMEUnchecked="xpath#//label[contains(text(),'IME')]/parent::span/parent::div//parent::div[@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-disabled']";
	
	public static String exemptedEvents_checkbox = "xpath#//label[text()='Exempted Events ']//parent::span//following-sibling::span/p-checkbox/div/div[2]";
	public static String anticipatedEvents_checkbox = "xpath#//label[text()='Anticipated Events ']//parent::span//following-sibling::span/p-checkbox/div/div[2]";
	
	public static String exemptedEvents_Label = "xpath#//label[text()='Exempted Events ']";
	public static String anticipatedEvents_Label = "xpath#//label[text()='Anticipated Events ']";
	public static String autopsyDone_Label = "xpath#//label[text()='Autopsy Done?']";
	public static String eventMedicallyConfirmed_Label = "xpath#//label[text()='Medically Confirmed ']";
	
	public static String ExemptedEvents_Manual_checkbox = "xpath#//label[contains(text(),'Exempted')]/parent::span/parent::div/following-sibling::div[1]//p-checkbox/div/div[2]";
	public static String AnticipatedEvents_Manual_checkbox = "xpath#//label[contains(text(),'Anticipated')]/parent::span/parent::div/following-sibling::div//p-checkbox/div/div[2]";
	public static String medicallyConfirmed_Manual_checkbox = "xpath#//label[contains(text(),'Medically Confirmed ')]/parent::span/parent::div/parent::div/following-sibling::div[1]/p-checkbox/div/div[2]";
	public static String AlwaysSeriousEvent_Manual_checkbox = "xpath#//label[contains(text(),'Always Serious Event ')]/parent::span/parent::div/parent::div/following-sibling::div[1]//p-checkbox/div/div[2]";
	
	
	public static String getEventCode(String count) {
		String value = suspectEventCoded.replace("%count%", count);
		return value;
	}

	public static String getEventNotCode(String count) {
		String value = suspectEventNotCoded.replace("%count%", count);
		return value;
	}

	public static String clickMultipleEvents(String runTimeLabel) {
		String value = click_MultipleEvents.replace("%s", runTimeLabel);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to verify the check box checked or not
	 * by passing label name at runtime. Input Parameters: ColumnName Scenario Name
	 * Output Parameters:
	 * 
	 * @author:Pooja S Date :25-June-2020 Updated by and when
	 **********************************************************************************************************/
	public static String checkboxVerification(String runTimeLabel) {
		String value = checkboxVerification;
		String value2;
		value2 = value.replace("%label%", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author: Avinash k
	 * @Date : 30-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String resultLocator = null;

	public static String checkBoxUnder(String checkBoxLabel) {
		String actualLocator = checkBoxUnder;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to check the radio button selected or
	 * not by passing label name at runtime. Input Parameters: ColumnName Scenario
	 * Name Output Parameters:
	 * 
	 * @author:Pooja S Date :04-June-2020 Updated by and when
	 **********************************************************************************************************/
	public static String eventSeriousnessSelected(String runTimeLabel) {
		String value = eventSeriousnessSelected;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to set data in text field by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String setData_Textfields(String runTimeLabel) {
		String value = setData_Textfields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to set data in text field by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Wajahat Umar s Date :25-Feb-2020 Updated by and when
	 **********************************************************************************************************/
	public static String setData_Medralookup(String runTimeLabel) {
		String value = MetraLookup;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select manual checkbox by passing
	 * label name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String manual_Checkbox(String runTimeLabel) {
		String value = manual_Checkbox;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click checkboxs by passing label
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String click_Checkboxs(String runTimeLabel) {
		String value = click_Checkboxs;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select radio button by passing label
	 * name and value at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String select_RadioButtons(String runTimeLabel, String valueRuntime) {
		String value = select_RadioButtons.replace("%s", runTimeLabel);
		value = value.replace("%r", valueRuntime);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click checkboxs by passing label
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String setData_Datesfields(String runTimeLabel) {
		String value = setData_Datesfields;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click drop downs by passing label
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String click_DropDown(String runTimeLabel) {
		String value = click_DropDown;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	// Click Drop down value
	public static String setdropDownValue(String data) {
		String value = setdropDownValue.replace("%s", data);
		return value;
	}

	// Add and delete button
	public static String add_Delete_Buttons(String data) {
		String value = add_Delete_Buttons.replace("%s", data);
		return value;
	}

	// Select Radio button
	public static String causedByDrugInteraction_Radiobtn(String data) {
		String value = causedByDrugInteraction_Radiobtn.replace("%r", data);
		return value;
	}

	// Select Radio button
	public static String causedByLackOfEffect_Radiobtn(String data) {
		String value = causedByLackOfEffect_Radiobtn.replace("%r", data);
		return value;
	}

	// Select Radio button
	public static String medicallyConfirmed_Radiobtn(String data) {
		String value = medicallyConfirmed_Radiobtn.replace("%r", data);
		return value;
	}

	public static String clickSecondEvent(String runTimeLabel) {
		String value = secondEvent;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to check the radio button selected or
	 * not by passing label name at runtime. Input Parameters: ColumnName Scenario
	 * Name Output Parameters:
	 * 
	 * @author:Pooja S Date :04-June-2020 Updated by and when
	 **********************************************************************************************************/
	public static String radioBtnVerification(String runTimeLabel) {
		String value = radioBtnVerification;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String NoInformation(String runtimeLabel) {
		String value = NoInformation.replace("%s", runtimeLabel);
		return value;
	}
	
	/**********************************************************************************************************
	 * Objective:The below method is created to verify the Always Seriuos Event Checkbox is selected at 
	 * case level.
	 * Name Output Parameters:
	 * 
	 * @author:Pooja S Date :04-June-2020 Updated by and when
	 **********************************************************************************************************/	
	
	public static String alwaysSeriousEvent_Label = "xpath#//label[contains(text(),'Always Serious Event ')]";
	
	public static String alwaysSeriousEvent_checkbox = "xpath#//label[text()='Always Serious Event ']//parent::span//following-sibling::span/p-checkbox/div/div[2]";
	
	public static String eventsDelete_Button = "xpath#//label[text()='Event(s)']/following-sibling::span/a[text()='Delete']";
	public static String eventsDelete_YesButton = "xpath#//form[@id='fdeAngularForm']/div/p-confirmdialog/div/div[3]/button[1]/span[contains(text(),'Yes')]";
	public static String eventsDelete_Recode_confirmation = "xpath#//form[@id='fdeAngularForm']/div/p-confirmdialog/div/div[2]/span[contains(text(),'Do you want to recode')]";
	public static String eventsDelete_Recode_confirmation_NoBTN = "xpath#//form[@id='fdeAngularForm']/div/p-confirmdialog/div/div[3]/button[2]/span[contains(text(),'No')]";
	public static String alwaysSeriousEvent_confirmationBox = "xpath#//span[@id='ui-dialog-21-label'][contains(text(),'Confirmation')]";
	public static String alwaysSeriousEvent_confirmationBox_Submit = "xpath#//span[@id='ui-dialog-21-label'][contains(text(),'Confirmation')]/parent::div/following-sibling::div//span[contains(text(), 'Submit')]";
	public static String alwaysSeriousEvent_confirmationBox_Cancel = "xpath#//span[@id='ui-dialog-21-label'][contains(text(),'Confirmation')]/parent::div/following-sibling::div//span[contains(text(), 'Cancel')]";
	
	public static String CheckedCheckBox2 = "xpath#//label[starts-with(normalize-space(text()),'{0}')]/../descendant::p-checkbox//span/parent::div";
	
	public static String CheckedCheckBox2(String checkBoxLabel) {
		String actualLocator = CheckedCheckBox2;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}
	

	public static String cessationDateAsText = "xpath#//label[text()='Cessation date ']/../span/span/input";
	public static String medicalHistoryDurationUnit = "xpath#//label[text()='Duration ']/following-sibling::span/p-dropdown/div/label/span";
	public static String medicalHistoryDurationValue = "xpath#//label[text()='Duration ']/following-sibling::span/input";
	
	public static String nearIncident_RadioBtn = "Near Incident";
	public static String incidentOccurredDuring_DropDown = "Incident Occurred During";
	
}


