package com.arisglobal.framework.components.lsmv.L10_3;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;
import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.CommonOperations;
import com.arisglobal.framework.components.lsmv.L10_3.OR.AdvanceSearchPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CompanyUnitLookupPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.ContactLookUpPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.DictionaryCodingBrowser_LookupPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.SenderLookupPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DataBaseOperations;
import com.arisglobal.framework.lib.utils.generic.DateOperations;
import com.arisglobal.framework.lib.utils.generic.FileSystemOperations;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.framework.lib.utils.generic.outlookwebmail.OutlookWebMail;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class CommonOperations extends ToolManager {
	public static WebElement webElement;
	static String className = CommonOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	static Object[][] scenarioArr;

	/**********************************************************************************************************
	 * @Objective: The below method is created get Current date and in desired
	 *             Format.
	 * @InputParameters: DateFormat
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 26-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getCurrentDate(String DateFormat) {
		SimpleDateFormat formDate = new SimpleDateFormat(DateFormat);
		String strDate = formDate.format(System.currentTimeMillis());
		return strDate;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created write Receipt No To Datasheet.
	 * @InputParameters: sheetName, scenarioName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 26-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void writeReceiptNoToDatasheet(String sheetName, String scenarioName, String columnName) {
		agSetStepExecutionDelay("8000");
		String validation = agGetText(CommonPageObjects.validationPopup);
		agSetStepExecutionDelay("1000");
		String[] data = validation.split(" ");
		String receiptID = data[2];
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, columnName, receiptID);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data is visible in
	 *             downloaded report.
	 * @InputParameters: reportType, scenarioName, sheetName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyDataVisible_DownloadedReport(String reportType, String scenarioName, String sheetName,
			String columnName) {
		String RecptNo = FDE_General.getData(scenarioName, "ReceiptNo");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		PDFOperations.pdfverificationForVisible(lsmvConstants.path + "\\" + reportType + "_" + RecptNo + ".pdf",
				getTestDataCellValue(scenarioName, columnName));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data is visible in
	 *             Downloaded Report.
	 * @InputParameters: reportName, scenarioName, sheetName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDataVisible_GeneratedReport(String reportName, String scenarioName, String sheetName,
			String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		PDFOperations.pdfverificationForVisible(lsmvConstants.LSMV_testDataOutput + "\\" + reportName,
				getTestDataCellValue(scenarioName, columnName));
	}

	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data is not visible in
	 *             downloaded report.
	 * @InputParameters: reportType, scenarioName, sheetName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDataNotVisible_DownloadedReport(String reportType, String scenarioName, String sheetName,
			String columnName) {
		String RecptNo = FDE_General.getData(scenarioName, "ReceiptNo");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		PDFOperations.pdfverificationForNotVisible(lsmvConstants.path + "\\" + reportType + "_" + RecptNo + ".pdf",
				getTestDataCellValue(scenarioName, columnName));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to move downloaded report to desired
	 *             location
	 * @InputParameters: reportType, scenarioName, sheetName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 03-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void move_DownloadedReport(String reportType, String scenarioName) {
		String RecptNo = FDE_General.getData(scenarioName, "ReceiptNo");
		String path = lsmvConstants.LSMV_testDataOutput + "\\" + Reports.currenttime();
		lsmvConstants.path = path;
		FileSystemOperations.createFolder(path);
		FileSystemOperations.moveFile(reportType + "_" + RecptNo + ".pdf", lsmvConstants.LSMV_testDataOutput, path);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to move downloaded report to desired
	 *             location
	 * @InputParameters: reportType, scenarioName, sheetName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 03-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void move_DownloadedJSONReport(String reportType, String scenarioName) {
		String RecptNo = FDE_General.getData(scenarioName, "ReceiptNo");
		String FileName= Reports.currenttime();
		String path = lsmvConstants.LSMV_testDataOutput + "\\" + FileName;
		lsmvConstants.path = path;
		FileSystemOperations.createFolder(path);
		FileSystemOperations.moveFile(reportType + "" + RecptNo + ".json", lsmvConstants.LSMV_testDataOutput, path);
		System.out.print(path+RecptNo + ".json");
		
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData,"ImportOperations", scenarioName, 
				"R2Xml","\\"+FileName+ "\\"
				+ RecptNo +".json");
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to move downloaded excel to desired
	 *             location
	 * @InputParameters: reportType, scenarioName, sheetName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 16-Sep-2019
	 * @UpdatedByAndWhen:Yashwanth Naidu 17-March-2020
	 **********************************************************************************************************/
	public static void move_Downloadedexcel(String FileName) {
		String path = lsmvConstants.LSMV_testDataOutput + "\\" + Reports.currenttime();
		lsmvConstants.path = path;
		System.out.println(lsmvConstants.path);
		FileSystemOperations.createFolder(path);
		FileSystemOperations.moveFile(FileName + ".xlsx", lsmvConstants.LSMV_testDataOutput, path);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to save generated report to desired
	 *             location
	 * @InputParameters: FileName with file extension(.pdf, .xlsx, .xls)
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 4-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	/*
	 * public static void save_GeneratedReport(String FileName) { String path =
	 * lsmvConstants.LSMV_testDataOutput + "\\" + Reports.currenttime();
	 * lsmvConstants.path = path; System.out.println(lsmvConstants.path);
	 * FileSystemOperations.createFolder(path);
	 * FileSystemOperations.moveFile(FileName, lsmvConstants.LSMV_testDataOutput,
	 * path); }
	 */

	public static void save_GeneratedReport(String FileName) {
		int count = 1;
		File f = new File(lsmvConstants.LSMV_testDataOutput + "\\" + FileName);
		do {
			try {
				System.out.println("Waiting for File to Download in Path : " + lsmvConstants.LSMV_testDataOutput + "\\"
						+ FileName);
				count++;
				Thread.sleep(6000);
				if (count >= 10) {
					break;
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		} while (!f.exists());
		if (f.exists() == true) {
			System.out.println("File Downloaded Successfully");
		} else {
			System.out.println("Unable to Download File");
		}
		String path = lsmvConstants.LSMV_testDataOutput + "\\" + Reports.currenttime();
		lsmvConstants.path = path;
		System.out.println(lsmvConstants.path);
		FileSystemOperations.createFolder(path);
		FileSystemOperations.moveFile(FileName, lsmvConstants.LSMV_testDataOutput, path);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created write Receipt No To Datasheet
	 * @InputParameters: scenarioName, sheetName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 26-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void writeRecptNo_FDESave(String scenarioName, String sheetName) {
		CommonOperations.agwaitTillVisible(FullDataEntryFormPageObjects.receiptNumber, 20, 1000);
		String receiptNumber = agGetText(FullDataEntryFormPageObjects.receiptNumber);
		/*
		 * String data1 =
		 * receiptNumber.substring(receiptNumber.lastIndexOf("Receipt Number:")); String
		 * RCTNo = data1.substring(15, data1.indexOf("saved successfully"));
		 */

		String[] arrOfStr = receiptNumber.split("Receipt number");
		arrOfStr = arrOfStr[1].split("saved successfully");
		receiptNumber = arrOfStr[0].trim();
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "ReceiptNo", receiptNumber);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created write Receipt No To Datasheet when
	 *             AER Number is displayed
	 * @InputParameters: scenarioName, sheetName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 10-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void writeRecptNo_FDE_AER_Save(String scenarioName, String sheetName) {
		CommonOperations.agwaitTillVisible(FullDataEntryFormPageObjects.receiptNumber, 20, 1000);
		String receiptNumber = agGetText(FullDataEntryFormPageObjects.receiptNumber);
		String data1 = receiptNumber.substring(receiptNumber.lastIndexOf("Receipt Number:"));
		String RCTNo = data1.substring(15, data1.indexOf("saved successfully"));
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "ReceiptNo", RCTNo.trim());
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created write Message No To Datasheet
	 * @InputParameters: scenarioName, sheetName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 26-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void write_MessageNo(String scenarioName, String sheetName) {
		agSetStepExecutionDelay("5000");
		String data = agGetText(CaseListingPageObjects.importvalidationPopup);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		String data1 = data.substring(data.lastIndexOf(":"));
		String MessageNumber = data1.substring(1, data1.indexOf("."));
		System.out.println("MessageNumber: " + MessageNumber);
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "MessageNo",
				MessageNumber.trim());

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created write Receipt No of followup
	 *             scenarios To Datasheet
	 * @InputParameters: scenarioName, sheetName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 20-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void write_CreateNewVersionRCTNo(String scenarioName, String sheetName) {
		agSetStepExecutionDelay("5000");
		String data = agGetText(CaseListingPageObjects.AERVersionPopUp);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		String[] arrOfStr = data.split("Receipt No:");
		arrOfStr = arrOfStr[1].split(" ");
		String RCTNo = arrOfStr[1];
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "ReceiptNo", RCTNo.trim());
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created write AER No To Datasheet
	 * @InputParameters: scenarioName, sheetName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 20-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void write_AERNo(String scenarioName, String sheetName) {
		// String data = agGetText(CaseListingPageObjects.validationPopup);
		// String data = agGetText(CommonPageObjects.validationPopup);
		// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// String data1 = data.substring(data.lastIndexOf(":"));
		// String AERNo = data1.substring(1, data1.indexOf("("));
		// XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName,
		// scenarioName, "AERNo", AERNo.trim());
		// agSetStepExecutionDelay("2000");
		agIsVisible(CommonPageObjects.validationMsg);

		// CommonOperations.captureScreenShot(true);
		String Validation = agGetText(CommonPageObjects.validationMsg);
		status = agIsVisible(CommonPageObjects.validationMsg);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		String data1 = Validation.substring(Validation.lastIndexOf(":"));
		String AER = data1.substring(2, data1.length() - 1);
		String AER1 = AER.substring(0, AER.indexOf("("));
		System.out.println("AER No::" + AER1.trim());		
		agSetStepExecutionDelay("10000");
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "AERNo", AER1.trim());
		if (status) {

			if (!scenarioName.equalsIgnoreCase("LSMV_OQ_QBE_Search_Main")) {
				Reports.ExtentReportLog("", Status.INFO, "As Expected", false);
				Reports.ExtentReportLog("", Status.INFO, "<br />"
						+ "An Action Completed Successfully window is displayed with message INFO : Receipt Number:"
						+ Validation, false);
			}

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Data assesed as New Unsuccessfull" + "<br />", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created write AER No with version To
	 *             Datasheet
	 * @InputParameters: scenarioName, sheetName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 20-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void write_AERNoVersion(String scenarioName, String sheetName) {
		agSetStepExecutionDelay("5000");
		String data = agGetText(CaseListingPageObjects.validationPopup);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		String data1 = data.substring(data.lastIndexOf(":"));
		String AERNo = data1.substring(1);
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "AERNo", AERNo.trim());
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to wait till loading
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void waitTillLoading() {
		for (int i = 1; i < 100; i++)
			if (agIsVisible(FullDataEntryFormPageObjects.loading) == true) {
				agSetStepExecutionDelay("2000");
			} else {
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				break;
			}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to wait till case level
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void waitTillCaseVisible() {
		for (int i = 1; i < 100; i++)
			if (agIsVisible(CaseListingPageObjects.caseListingLoading) == true) {
				agSetStepExecutionDelay("300");
			} else {
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				break;
			}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to wait till case level
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void waitTillCopycaseLoading() {
		for (int i = 1; i < 100; i++)
			if (agIsVisible(CommonPageObjects.copyCaseloading) == true) {
				agSetStepExecutionDelay("2000");
			} else {
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				break;
			}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to wait till visible of element
	 * @InputParameters: object
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void agwaitTillVisible(String object) {
		for (int i = 1; i < 100; i++) {
			if (agIsVisible(object) == false) {
				agSetStepExecutionDelay("2000");
			} else {
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				break;
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to wait till visible of element (This
	 *             is an Overloaded Method)
	 * @InputParameters: object, maxCount, waitTime
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 13-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void agwaitTillVisible(String object, int maxCount, int waitTime) {
		for (int i = 1; i < maxCount; i++) {
			if (agIsVisible(object) == false) {
				agSetStepExecutionDelay(String.valueOf(waitTime));
			} else {
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				break;
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to take screenshot
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void takeScreenShot() {
		Reports.ExtentReportLog("ScreenShot", Status.PASS, "", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to take screenshot passing True/False
	 *             at Runtime
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void takeScreenShot(boolean scresnShot) {
		Reports.ExtentReportLog("ScreenShot", Status.PASS, "", scresnShot);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to return Date as per defined Date
	 *             Format
	 * @InputParameters: testData (Ex: d:m:y)
	 * @OutputParameters: converted date as string
	 * @author:Naresh
	 * @Date : 24-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String returnDateTime(String testData) {
		if (!testData.trim().equalsIgnoreCase("#skip#") || !testData.trim().equalsIgnoreCase("Private")) {
			String data = testData.trim();
			String resultString = null;
			if (data.contains(" ")) {
				String[] result = data.split(" ");
				if (result[1] == "") {
					return DateOperations.getDateByInputData(lsmvConstants.LSMV_dateFormat, result[0]);
				} else {
					String finResult = DateOperations.getDateByInputData(lsmvConstants.LSMV_dateFormat, result[0]);
					resultString = finResult + " " + result[1];
				}
				return resultString;
			}
			return DateOperations.getDateByInputData(lsmvConstants.LSMV_dateFormat, data);
		}
		return testData;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify date in LSMV date fields.
	 * @InputParameters: testData
	 * @OutputParameters:NA
	 * @author:Naresh
	 * @Date : 24-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDate(String object, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(object);
			agCheckPropertyValue("title",
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, columnName)), object);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify message in LSMV
	 *             application.
	 * @InputParameters: testData
	 * @OutputParameters:NA
	 * @author:Avinash K
	 * @Date : 25-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyMessage(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agwaitTillVisible(CommonPageObjects.validationPopup);
		// sagAssertContainsText(CommonPageObjects.validationPopup,
		// getTestDataCellValue(scenarioName, "Message"));
		String validation = agGetText(CommonPageObjects.validationPopup);
		status = agIsVisible(CommonPageObjects.validationPopup);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Validation::" + validation, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Validation::" + validation, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set delete audit info in LSMV
	 *             application.
	 * @InputParameters: testData
	 * @OutputParameters:NA
	 * @author:Avinash K
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDeleteAuditInfo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// if (scenarioName.contains("Delete_TherapeuticArea") ||
		// scenarioName.contains("Study")
		// || scenarioName.contains("Delete_UserGroup") ||
		// scenarioName.contains("Delete_Announcement")) {

		if (agIsVisible(CommonPageObjects.deletevalidation_Popup1) == true) {
			agwaitTillVisible(CommonPageObjects.deletevalidation_Popup1);
			boolean returnDeleteValstatus1 = agIsVisible(CommonPageObjects.deletevalidation_Popup1);
			if (returnDeleteValstatus1 == true) {
				agAssertContainsText(CommonPageObjects.deletevalidation_Popup1, "Are you sure you want to delete");
				String Deletevalidation = agGetText(CommonPageObjects.deletevalidation_Popup1);
				Reports.ExtentReportLog("", Status.INFO, "Delete Validation::" + Deletevalidation, true);
				agClick(CommonPageObjects.deletePopupYes_Btn);
			}
		} else if (agIsVisible(CommonPageObjects.deletevalidation_Popup) == true) {
			agwaitTillVisible(CommonPageObjects.deletevalidation_Popup);
			boolean returnDeleteValstatus = agIsVisible(CommonPageObjects.deletevalidation_Popup);
			if (returnDeleteValstatus == true) {
				agAssertContainsText(CommonPageObjects.deletevalidation_Popup, "Are you sure you want to delete");
				String Deletevalidation = agGetText(CommonPageObjects.deletevalidation_Popup);
				Reports.ExtentReportLog("", Status.INFO, "Delete Validation::" + Deletevalidation, true);
				agClick(CommonPageObjects.deletePopupYes_Btn);
			} else if (agIsVisible(CommonPageObjects.deletevalidation_popup2) == true) {
				agwaitTillVisible(CommonPageObjects.deletevalidation_popup2);
				boolean returnDeleteValstatus2 = agIsVisible(CommonPageObjects.deletevalidation_popup2);
				if (returnDeleteValstatus2 == true) {
					agAssertContainsText(CommonPageObjects.deletevalidation_popup2, "Are you sure you want to delete");
					String Deletevalidation = agGetText(CommonPageObjects.deletevalidation_popup2);
					Reports.ExtentReportLog("", Status.INFO, "Delete Validation::" + Deletevalidation, true);
					agClick(CommonPageObjects.deletePopupYes_Btn);
				}
			}
		}
		agSetStepExecutionDelay("3000");
		boolean returnAudit = agIsVisible(CommonPageObjects.auditInfo_Label);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (returnAudit == true) {
			agClick(CommonPageObjects.clickDeleteAuditReason_dropdwn);
			agClick(CommonPageObjects.setDeleteDropdown_Auditreason(getTestDataCellValue(scenarioName, "ReasonCode")));
			agSetValue(CommonPageObjects.auditreason_Textarea, getTestDataCellValue(scenarioName, "Reason"));
			CommonOperations.takeScreenShot();
			agClick(CommonPageObjects.submit_Btn);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Audit reason is not displayed", false);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.verifyMessage(scenarioName);
		CommonOperations.agClick(CommonPageObjects.validaionOk_Btn);
	}

	public static void setDeleteCompanyUnitAuditInfo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agwaitTillVisible(CommonPageObjects.deletevalidation_Popup1);
		boolean returnDeleteValstatus = agIsVisible(CommonPageObjects.deletevalidation_Popup1);
		if (returnDeleteValstatus == true) {
			agAssertContainsText(CommonPageObjects.deletevalidation_Popup1, "Are you sure you want to delete");
			String Deletevalidation = agGetText(CommonPageObjects.deletevalidation_Popup1);
			Reports.ExtentReportLog("", Status.INFO, "Delete Validation::" + Deletevalidation, true);
			agClick(CommonPageObjects.deletePopupYes_Btn1);
		}
		agSetStepExecutionDelay("3000");
		boolean returnAudit = agIsVisible(CommonPageObjects.auditInfo_Label);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (returnAudit == true) {
			agClick(CommonPageObjects.clickDeleteAuditReason_dropdwn);
			agClick(CommonPageObjects.setDeleteDropdown_Auditreason(getTestDataCellValue(scenarioName, "ReasonCode")));
			agSetValue(CommonPageObjects.auditreason_Textarea, getTestDataCellValue(scenarioName, "Reason"));
			CommonOperations.takeScreenShot();
			agClick(CommonPageObjects.submit_Btn);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Audit reason is not displayed", false);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.verifyMessage(scenarioName);
		CommonOperations.agClick(CommonPageObjects.validaionOk_Btn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set delete department audit info
	 *             in LSMV application.
	 * @InputParameters: testData
	 * @OutputParameters:NA
	 * @author:Yashwanth Naidu
	 * @Date : 25-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDepartmentDeleteAuditInfo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agwaitTillVisible(CommonPageObjects.deletevalidation_Popup1);
		boolean returnDeleteValstatus = agIsVisible(CommonPageObjects.deletevalidation_Popup1);
		if (returnDeleteValstatus == true) {
			agAssertContainsText(CommonPageObjects.deletevalidation_Popup1, "Are you sure you want to delete");
			String Deletevalidation = agGetText(CommonPageObjects.deletevalidation_Popup1);
			Reports.ExtentReportLog("", Status.INFO, "Delete Validation::" + Deletevalidation, true);
			agClick(CommonPageObjects.deptDeletePopupYes_Btn);
		}
		agSetStepExecutionDelay("3000");
		boolean returnAudit = agIsVisible(CommonPageObjects.auditInfo_Label);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (returnAudit == true) {
			agClick(CommonPageObjects.clickDeleteAuditReason_dropdwn);
			agClick(CommonPageObjects.setDeleteDropdown_Auditreason(getTestDataCellValue(scenarioName, "ReasonCode")));
			agSetValue(CommonPageObjects.auditreason_Textarea, getTestDataCellValue(scenarioName, "Reason"));
			CommonOperations.takeScreenShot();
			agClick(CommonPageObjects.submit_Btn);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Audit reason is not displayed", false);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.verifyMessage(scenarioName);
		CommonOperations.agClick(CommonPageObjects.validaionOk_Btn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set delete Account group audit
	 *             info in LSMV application.
	 * @InputParameters: testData
	 * @OutputParameters:NA
	 * @author:Yashwanth Naidu
	 * @Date : 25-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setAccGroupDeleteAuditInfo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agwaitTillVisible(CommonPageObjects.deletevalidation_Popup1);
		boolean returnDeleteValstatus = agIsVisible(CommonPageObjects.deletevalidation_Popup1);
		if (returnDeleteValstatus == true) {
			agAssertContainsText(CommonPageObjects.deletevalidation_Popup1, "Are you sure you want to delete");
			String Deletevalidation = agGetText(CommonPageObjects.deletevalidation_Popup1);
			Reports.ExtentReportLog("", Status.INFO, "Delete Validation::" + Deletevalidation, true);
			agClick(CommonPageObjects.AccGroupDeletePopupYes_Btn);
		}
		agSetStepExecutionDelay("3000");
		boolean returnAudit = agIsVisible(CommonPageObjects.auditInfo_Label);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (returnAudit == true) {
			agClick(CommonPageObjects.clickDeleteAuditReason_dropdwn);
			agClick(CommonPageObjects.setDeleteDropdown_Auditreason(getTestDataCellValue(scenarioName, "ReasonCode")));
			agSetValue(CommonPageObjects.auditreason_Textarea, getTestDataCellValue(scenarioName, "Reason"));
			CommonOperations.takeScreenShot();
			agClick(CommonPageObjects.submit_Btn);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Audit reason is not displayed", false);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.verifyMessage(scenarioName);
		CommonOperations.agClick(CommonPageObjects.validaionOk_Btn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set delete substance audit info in
	 *             LSMV application.
	 * @InputParameters: testData
	 * @OutputParameters:NA
	 * @author:Yashwanth Naidu
	 * @Date : 25-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setsubstanceDeleteAuditInfo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agwaitTillVisible(CommonPageObjects.deletevalidation_Popup1);
		boolean returnDeleteValstatus = agIsVisible(CommonPageObjects.deletevalidation_Popup1);
		if (returnDeleteValstatus == true) {
			agAssertContainsText(CommonPageObjects.deletevalidation_Popup1, "Are you sure you want to delete");
			String Deletevalidation = agGetText(CommonPageObjects.deletevalidation_Popup1);
			Reports.ExtentReportLog("", Status.INFO, "Delete Validation::" + Deletevalidation, true);
			agClick(CommonPageObjects.substanceDeletePopupYes_Btn);
		}
		agSetStepExecutionDelay("3000");
		boolean returnAudit = agIsVisible(CommonPageObjects.auditInfo_Label);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (returnAudit == true) {
			agClick(CommonPageObjects.clickDeleteAuditReason_dropdwn);
			agClick(CommonPageObjects.setDeleteDropdown_Auditreason(getTestDataCellValue(scenarioName, "ReasonCode")));
			agSetValue(CommonPageObjects.auditreason_Textarea, getTestDataCellValue(scenarioName, "Reason"));
			CommonOperations.takeScreenShot();
			agClick(CommonPageObjects.submit_Btn);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Audit reason is not displayed", false);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.verifyMessage(scenarioName);
		CommonOperations.agClick(CommonPageObjects.validaionOk_Btn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set save and update audit info in
	 *             LSMV application.
	 * @InputParameters: testData
	 * @OutputParameters:NA
	 * @author:Avinash K
	 * @Date : 25-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String setAuditInfo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		boolean returnAudit = agIsVisible(CommonPageObjects.auditInfo_Label);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (returnAudit == true) {
			// agClick(CommonPageObjects.clickAuditReason_dropdwn);
			agJavaScriptExecuctorClick(CommonPageObjects.clickAuditReason_dropdwn);
			agClick(CommonPageObjects.setAuditreasonDropdrown(getTestDataCellValue(scenarioName, "ReasonCode")));
			agSetValue(CommonPageObjects.auditreason_Textarea, getTestDataCellValue(scenarioName, "Reason"));
			CommonOperations.takeScreenShot();
			agClick(CommonPageObjects.submit_Btn);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Audit reason popup is not displayed", false);
		}
		String msg = "";
		if (agIsVisible(CommonPageObjects.validationPopup) == true) {
			msg = agGetText(CommonPageObjects.validationPopup);
			CommonOperations.verifyMessage(scenarioName);
			CommonOperations.agClick(CommonPageObjects.validaionOk_Btn);
		} else if (agIsVisible(CommonPageObjects.passwrdChangeValPopup) == true) { // Below Condition to handle password
																					// change
			agAssertContainsText(CommonPageObjects.passwrdChangeValPopup,
					getTestDataCellValue(scenarioName, "Message"));
			String validation = agGetText(CommonPageObjects.passwrdChangeValPopup);
			status = agIsVisible(CommonPageObjects.passwrdChangeValPopup);
			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "Validation::" + validation, true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Validation::" + validation, true);
			}
			CommonOperations.captureScreenShot(true);
			CommonOperations.agClick(CommonPageObjects.passwrdChangeValPopupOk_Btn);
		}
		return msg;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to check checkbox left of specified
	 *             label.
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author:Naresh
	 * @Date : 24-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickCheckBoxLeftOf(String label, String boolCheck) {
		if (!boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus;
			String xpath = CommonPageObjects.checkBoxLeftOf(label);
			checkBoxStatus = ToolManager.agGetAttribute("class", xpath);
			if (checkBoxStatus.contains("ui-icon-check") || checkBoxStatus.contains("pi-check")) {
				checkBoxStatus = "true";
			} else if (checkBoxStatus.contains("ui-icon-blank")
					|| checkBoxStatus.endsWith("ui-chkbox-icon ui-clickable")) {
				checkBoxStatus = "false";
			}
			if ((boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check"))
					&& checkBoxStatus.equalsIgnoreCase("false")) {
				ToolManager.agJavaScriptExecuctorClick(CommonPageObjects.checkBoxLeftOf(label));
			} else if ((boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck"))
					&& checkBoxStatus.equalsIgnoreCase("true")) {
				ToolManager.agJavaScriptExecuctorClick(CommonPageObjects.checkBoxLeftOf(label));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify checkbox left of specified
	 *             label.
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author:Naresh
	 * @Date : 25-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCheckBoxLeftOf(String label, String boolCheck) {
		if (!label.trim().contains("#skip#") && !boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = agGetAttribute("class", CommonPageObjects.checkBoxLeftOf(label));
			if (boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check")) {
				if (checkBoxStatus.contains("pi-check") || checkBoxStatus.contains("ui-icon-check")) {
					Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is checked", false);
				} else if (checkBoxStatus.endsWith("ui-chkbox-icon ui-clickable")
						|| checkBoxStatus.contains("ui-icon-blank")) {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is not checked", true);
				}
			} else if (boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck")) {
				if (checkBoxStatus.contains("pi-check") || checkBoxStatus.contains("ui-icon-check")) {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is checked", true);
				} else if (checkBoxStatus.endsWith("ui-chkbox-icon ui-clickable")
						|| checkBoxStatus.contains("ui-icon-blank")) {
					Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is not checked", true);
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to check checkbox right of specified
	 *             label.
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author:Naresh
	 * @Date : 24-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickCheckBoxRightOf(String label, String boolCheck) {
		if (!boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = null;
			checkBoxStatus = ToolManager.agGetAttribute("class", CommonPageObjects.checkBoxRightOf(label));
			if (checkBoxStatus.contains("blank")) {
				checkBoxStatus = "false";
			} else {
				checkBoxStatus = "true";
			}
			if ((boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check"))
					&& checkBoxStatus.equalsIgnoreCase("false")) {
				ToolManager.agClick(CommonPageObjects.checkBoxRightOf(label));
			} else if ((boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck"))
					&& checkBoxStatus.equalsIgnoreCase("true")) {
				ToolManager.agClick(CommonPageObjects.checkBoxRightOf(label));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify checkbox right of specified
	 *             label.
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author:Naresh
	 * @Date : 25-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCheckBoxRightOf(String label, String boolCheck) {
		if (!label.trim().contains("#skip#") && !boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = agGetAttribute("class", CommonPageObjects.checkBoxRightOf(label));
			if (boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check")) {
				if (checkBoxStatus.contains("ui-icon-blank")) {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is not checked", true);
				} else {
					Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is checked", false);
				}
			} else if (boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck")) {
				if (checkBoxStatus.contains("ui-icon-check")) {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is checked", true);
				} else {
					Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is not checked", false);
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Check/Uncheck Operation on
	 *             CheckBox under Specified Label.
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author:Sanchit
	 * @Date : 5-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickCheckBoxUnder(String label, String boolCheck) {
		if (!boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = null;
			checkBoxStatus = ToolManager.agGetAttribute("class", CommonPageObjects.checkBoxUnder(label));
			if (checkBoxStatus.contains("blank") || !checkBoxStatus.contains("pi-check")) {
				checkBoxStatus = "false";
			} else {
				checkBoxStatus = "true";
			}
			if ((boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check"))
					&& checkBoxStatus.equalsIgnoreCase("false")) {
				ToolManager.agClick(CommonPageObjects.checkBoxUnder(label));
			} else if ((boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck"))
					&& checkBoxStatus.equalsIgnoreCase("true")) {
				ToolManager.agClick(CommonPageObjects.checkBoxUnder(label));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Check/Uncheck Operation on
	 *             CheckBox under Specified Label
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author:Sanchit
	 * @Date : 5-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCheckBoxUnder(String label, String boolCheck) {
		if (!label.trim().contains("#skip#") && !boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = agGetAttribute("class", CommonPageObjects.checkBoxUnder(label));
			if (boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check")) {
				if (!checkBoxStatus.contains("ui-state-active")) {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is not checked", true);
				} else {
					Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is checked", false);
				}
			} else if (boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck")) {
				if (checkBoxStatus.contains("ui-state-active")) {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is checked", true);
				} else {
					Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is not checked", false);
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Check/Uncheck Operation on
	 *             Manual CheckBox under Specified Label
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author:Sanchit
	 * @Date : 5-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickManualCheckBox(String label, String boolCheck) {
		if (!boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = null;
			checkBoxStatus = ToolManager.agGetAttribute("class", CommonPageObjects.manualCheckBox(label));
			if (checkBoxStatus.contains("blank") || !checkBoxStatus.contains("pi-check")) {
				checkBoxStatus = "false";
			} else {
				checkBoxStatus = "true";
			}
			if ((boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check"))
					&& checkBoxStatus.equalsIgnoreCase("false")) {
				ToolManager.agClick(CommonPageObjects.manualCheckBox(label));
			} else if ((boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck"))
					&& checkBoxStatus.equalsIgnoreCase("true")) {
				ToolManager.agClick(CommonPageObjects.manualCheckBox(label));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Check/Uncheck Operation on
	 *             Manual CheckBox under Specified Label
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author:Sanchit
	 * @Date : 5-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyManualCheckBox(String label, String boolCheck) {
		if (!label.trim().contains("#skip#") && !boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = agGetAttribute("class", CommonPageObjects.manualCheckBox(label));
			if (boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check")) {
				if (checkBoxStatus.contains("pi-check")) {
					Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is checked", true);
				} else {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is not checked", true);
				}
			} else if (boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck")) {
				if (!checkBoxStatus.contains("pi-check")) {
					Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is not checked", true);
				} else {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is checked", true);
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select radio button.
	 * @InputParameters: label, radioButtonLabel
	 * @OutputParameters:NA
	 * @author:Naresh
	 * @Date : 07-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickRadioButton(String label, String radioButtonLabel) {
		if (!label.trim().contains("#skip#") && !radioButtonLabel.trim().contains("#skip#")) {
			agClick(CommonPageObjects.selectRadioButton(label, radioButtonLabel));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select radio button.
	 * @InputParameters: label, radioButtonLabel
	 * @OutputParameters:NA
	 * @author:Naresh
	 * @Date : 07-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickRadioButtonUpdated(String label, String radioButtonLabel) {
		if (!label.trim().contains("#skip#") && !radioButtonLabel.trim().contains("#skip#")) {
			agClick(CommonPageObjects.selectRadioButtonUpdated(label, radioButtonLabel));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify radio button.
	 * @InputParameters: label, radioButtonLabel
	 * @OutputParameters:NA
	 * @author:Naresh
	 * @Date : 07-Nov-2019
	 * @UpdatedByAndWhen:31-12-2019
	 **********************************************************************************************************/
	public static void verifyRadioButton(String label, String radioButtonLabel) {
		if (!label.trim().contains("#skip#") && !radioButtonLabel.trim().contains("#skip#")) {
			String radioButtonStatus = agGetAttribute("class",
					CommonPageObjects.selectRadioButton(label, radioButtonLabel));
			if (radioButtonStatus.contains("bullet") || radioButtonStatus.contains("pi-circle-on")) {
				Reports.ExtentReportLog("Radio Button", Status.INFO,
						label + ": value : " + radioButtonLabel + " is selected", true);
			}

			else if (radioButtonStatus.contains("blank")
					|| radioButtonStatus.equalsIgnoreCase("ui-radiobutton-icon ui-clickable")) {
				Reports.ExtentReportLog("Radio Button", Status.INFO,
						label + ": value : " + radioButtonLabel + " is not selected", true);
			}

			/*
			 * if (radioButtonStatus.contains("blank") ||
			 * !radioButtonStatus.contains("pi-circle-on")) {
			 * Reports.ExtentReportLog("Radio Button", Status.FAIL, label + ": value : " +
			 * radioButtonLabel + " is not selected", true); } else {
			 * Reports.ExtentReportLog("Radio Button", Status.PASS, label + ": value : " +
			 * radioButtonLabel + " is selected", true); }
			 */
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click add button on specified div.
	 * @InputParameters: label, radioButtonLabel
	 * @OutputParameters:NA
	 * @author:Naresh
	 * @Date : 13-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickAddDivOf(String label) {
		agClick(CommonPageObjects.clickAddDivOf(label));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click delete button on specified
	 *             div.
	 * @InputParameters: label, radioButtonLabel
	 * @OutputParameters:NA
	 * @author:Naresh
	 * @Date : 13-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickDeleteDivOf(String label) {
		agClick(CommonPageObjects.clickAddDivOf(label));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select list type dropdown value.
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters:NA
	 * @author:Naresh
	 * @Date : 14-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setListDropDownValue(String locator, String valueToSelect) {
		if (!valueToSelect.equalsIgnoreCase("#skip#")) {
			// agJavaScriptExecuctorScrollToElement(locator);
			agSetStepExecutionDelay("2000");
			agClick(locator);
			agClick(CommonPageObjects.selectListDropDown(locator, valueToSelect));
			// agCheckPropertyText(valueToSelect, locator);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select list type dropdown value.
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters:NA
	 * @author:Yashwanth Naidu
	 * @Date : 07-Sept-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setListDistributeDropDownValue(String locator, String valueToSelect) {
		if (!valueToSelect.equalsIgnoreCase("#skip#")) {
			// agJavaScriptExecuctorScrollToElement(locator);
			agSetStepExecutionDelay("2000");
			agClick(locator);
			agClick(CommonPageObjects.selectDistributionListDropDown(locator, valueToSelect));
			// agCheckPropertyText(valueToSelect, locator);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select value in FDE screen
	 *             dropdown.
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters:NA
	 * @author:Naresh
	 * @Date : 22-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setFDEDropDownValue(String locator, String valueToSelect) {
		if (!valueToSelect.equalsIgnoreCase("#skip#")) {
			String classValue = agGetAttribute("class", locator);
			agJavaScriptExecuctorClick(locator);
			agJavaScriptExecuctorClick(CommonPageObjects.selectFDEDropDown(classValue, valueToSelect));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify value in FDE Screen
	 *             dropdown.
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters:NA
	 * @author:Sanchit
	 * @Date : 4-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyFDEDropDownValue(String locator, String valueToSelect) {
		if (!valueToSelect.equalsIgnoreCase("#skip#")) {
			String classValue = agGetAttribute("class", locator);
			// agCheckPropertyValue("value", valueToSelect.trim(),
			// CommonPageObjects.verifyFDEDropDown(classValue, valueToSelect));
			agCheckPropertyText(valueToSelect.trim(),
					CommonPageObjects.verifyFDEDropDown(classValue, valueToSelect.trim()));
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method Returns no of Scenarios
	 * @Input Parameters: scenarioName,sheetName
	 * @Output Parameters: Scenario Size
	 * @@author: Vinayaka Hegde Date : 19-July-2019 Updated by and when:
	 **********************************************************************************************************/
	public static int getScenarioSize(String scenarioName, String sheetName) {
		ArrayList<String> a = new ArrayList<>();
		ArrayList<String> s = Multimaplibraries.getScenarioList(lsmvConstants.LSMV_testData, sheetName);

		for (int i = 0; i < s.size(); i++) {
			if (s.get(i).startsWith(scenarioName) == true) {
				a.add(s.get(i));
			}
		}
		return a.size();
	}

	public static Object[] dataProviderExcel() {
		int i = XlsReader.activeRowcount(lsmvConstants.LSMV_testData, "FDE_Source");
		// scenarioArr = new String[i];
		for (int j = 1; j <= 11; j++) {
			String celldata = XlsReader.getdata(lsmvConstants.LSMV_testData, "FDE_Source", j, 0);

			Object data[] = new Object[i];
			data[j] = celldata;
			// scenarioArr[j - 1][j] = celldata;
		}

		return scenarioArr;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Dictionary Coding Browser
	 *             Details.
	 * @InputParameters: Search Term
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDictionaryCodingBrowserDetails(String searchTerm) {
		agSetValue(DictionaryCodingBrowser_LookupPageObjects.searchTerm_Textbox, searchTerm);
		agClick(DictionaryCodingBrowser_LookupPageObjects.search_Button);
		agSetStepExecutionDelay("5000");
		CommonOperations.takeScreenShot();
		// agClick(DictionaryCodingBrowser_LookupPageObjects.Ok_Button);
		agWaitTillVisibilityOfElement(DictionaryCodingBrowser_LookupPageObjects.Ok_Button);
		agJavaScriptExecuctorClick(DictionaryCodingBrowser_LookupPageObjects.Ok_Button);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (agIsExists(DictionaryCodingBrowser_LookupPageObjects.Ok_Button) == true) {
			agClick(DictionaryCodingBrowser_LookupPageObjects.Ok_Button);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Dictionary Coding Browser
	 *             Details.(Overloaded Method)
	 * @InputParameters: Search Term
	 * @OutputParameters:
	 * @author:Avinash
	 * @Date : 16-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDictionaryCodingBrowserDetails(String searchTerm, String Level) {
		agSetValue(DictionaryCodingBrowser_LookupPageObjects.searchTerm_Textbox, searchTerm);
		agClick(DictionaryCodingBrowser_LookupPageObjects.clickLevelDropdown);
		agClick(DictionaryCodingBrowser_LookupPageObjects.setLevelDropdown(Level));
		agClick(DictionaryCodingBrowser_LookupPageObjects.search_Button);
		agSetStepExecutionDelay("5000");
		agClick(DictionaryCodingBrowser_LookupPageObjects.Ok_Button);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (agIsExists(DictionaryCodingBrowser_LookupPageObjects.Ok_Button) == true) {
			agClick(DictionaryCodingBrowser_LookupPageObjects.Ok_Button);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter SMQ_CMQ Dictionary Coding
	 *             Browser Details.
	 * @InputParameters: Search Term
	 * @OutputParameters:
	 * @author: Avinash k
	 * @Date : 12-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_SMQ_CMQ_DictionaryCodingBrowser(String searchTerm) {
		agSetValue(DictionaryCodingBrowser_LookupPageObjects.sMQ_CMQName_Textbox, searchTerm);
		agSetStepExecutionDelay("3000");
		agClick(DictionaryCodingBrowser_LookupPageObjects.sMQCMQSearch_Button);
		agClick(DictionaryCodingBrowser_LookupPageObjects.sMQCMQ_Select(searchTerm));
		// CommonOperations.takeScreenShot();
		agClick(DictionaryCodingBrowser_LookupPageObjects.sMQCMQOk_Button);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Company Unit Lookup Details.
	 * @InputParameters: Unit Code, Unit Name, Type, Country
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCompanyUnitLookupDetails(String unitCode, String unitName, String type, String country) {
		agwaitTillVisible(CompanyUnitLookupPageObjects.unitCode_TextBox, 10, 2000);
		agSetValue(CompanyUnitLookupPageObjects.unitCode_TextBox, unitCode);
		agSetValue(CompanyUnitLookupPageObjects.unitName_TextBox, unitName);
		CommonOperations.setListDropDownValue(CompanyUnitLookupPageObjects.type_DropDown, type);
		CommonOperations.setListDropDownValue(CompanyUnitLookupPageObjects.country_DropDown, country);
		agClick(CompanyUnitLookupPageObjects.search_Button);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		agwaitTillVisible(CompanyUnitLookupPageObjects.searchResultSelectRadio, 10, 2000);
		agClick(CompanyUnitLookupPageObjects.searchResultSelectRadio);
		CommonOperations.takeScreenShot();
		agClick(CompanyUnitLookupPageObjects.ok_Button);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Sender / Partner Lookup
	 *             Details.
	 * @InputParameters: Search Term
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSenderPartnerLookupDetails(String type, String searchTerm) {
		switch (type) {
		case "Sender":
			agClick(SenderLookupPageObjects.selectRadioButton(SenderLookupPageObjects.sender_Label));
			agwaitTillVisible(SenderLookupPageObjects.accountName_TextBox, 1, 1000);
			agSetValue(SenderLookupPageObjects.accountName_TextBox, searchTerm);
			agClick(SenderLookupPageObjects.search_Button);
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			agwaitTillVisible(CommonPageObjects.searchResultSelectRadio(searchTerm), 1, 1000);
			agClick(CommonPageObjects.searchResultSelectRadio(searchTerm));
			takeScreenShot();
			agClick(SenderLookupPageObjects.okSenderPartner_Button);
			break;
		case "Company Unit":
			agClick(SenderLookupPageObjects.selectRadioButton(SenderLookupPageObjects.companyUnit_Label));
			agwaitTillVisible(SenderLookupPageObjects.companyUnitName_TextBox, 1, 1000);
			agSetValue(SenderLookupPageObjects.companyUnitName_TextBox, searchTerm);
			agClick(SenderLookupPageObjects.search_Button);
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			agwaitTillVisible(CommonPageObjects.searchResultSelectRadio(searchTerm), 1, 1000);
			agClick(CommonPageObjects.searchResultSelectRadio(searchTerm));
			takeScreenShot();
			agClick(SenderLookupPageObjects.okSenderPartner_Button);
			break;
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Contact Lookup Details.
	 * @InputParameters: Search Term
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 4-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setContactLookupDetails(String firstName, String middleName, String lastName) {
		agwaitTillVisible(ContactLookUpPageObjects.firstName_TextBox, 1, 1000);
		agSetValue(ContactLookUpPageObjects.firstName_TextBox, firstName);
		agSetValue(ContactLookUpPageObjects.middleName_TextBox, middleName);
		agSetValue(ContactLookUpPageObjects.lastName_TextBox, lastName);
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Contact Lookup Screen", true);

		agClick(ContactLookUpPageObjects.search_Button);
		agwaitTillVisible(CommonPageObjects.selectListingCheckbox(firstName), 1, 1000);
		agClick(CommonPageObjects.selectListingCheckbox(firstName));
		Reports.ExtentReportLog("", Status.INFO, "Search Result in Contact Lookup Screen", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to move case from one activity to
	 *             next activity
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 13-Jan-2020
	 * @UpdatedByAndWhen:Kishore and 4-Mar-2020
	 **********************************************************************************************************/
	public static void completeActivity(String activityName) {
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
		agWaitTillVisibilityOfElement(CaseListingPageObjects.caseActHeader);
		String WorkFlowheader = agGetText(CaseListingPageObjects.caseActHeader);
		// CommonOperations.takeScreenShot();

		switch (activityName) {

		case "Case Approval":

			if (WorkFlowheader.equalsIgnoreCase("Final Review")) {
				CommonOperations.setActivity("Send to Case Approval");
			}

			break;

		case "Final Review":

			if (WorkFlowheader.equalsIgnoreCase("Medical Review")) {
				CommonOperations.setActivity("Send to Final Review");
			}

			break;

		case "Distribute":

			if (WorkFlowheader.equalsIgnoreCase("Case Approval (Auto)")) {
				CommonOperations.setActivity("Send to Distribute");
			}

			break;

		case "Distribute Transit":

			if (WorkFlowheader.equalsIgnoreCase("Distribute") || WorkFlowheader.equalsIgnoreCase("Minor Change")) {
				CommonOperations.setActivity("Send to Distribute Transit");
			}

			break;

		case "Exit":

			if (WorkFlowheader.equalsIgnoreCase("Distribute Transit")) {
				CommonOperations.setActivity("Exit");
			}

			break;

		case "Minor Change":

			if (WorkFlowheader.equalsIgnoreCase("Distribute Transit")) {
				CommonOperations.setActivity("Send to Minor Change");
			}

			break;

		case "Non Case":
			if (WorkFlowheader.equalsIgnoreCase("Initial")) {
				CommonOperations.setActivity("Send to Non Case");
			}

			break;

		case "Full Data Entry":
			if (WorkFlowheader.equalsIgnoreCase("Review")) {
				CommonOperations.setActivity("Send to Full Data Entry");
			}

			break;

		case "Review":
			if (WorkFlowheader.equalsIgnoreCase("Intake and Assessment")) {
				CommonOperations.setActivity("Send to Review");
			} else if (WorkFlowheader.equalsIgnoreCase("Translation")) {
				CommonOperations.setActivity("Send  to Review");
			}

			break;

		case "Intake and Assessment":

			if (WorkFlowheader.equalsIgnoreCase("Non Case")) {
				CommonOperations.setActivity("Send to Intake and Assessment");
			} else if (WorkFlowheader.equalsIgnoreCase("Initial")) {
				CommonOperations.setActivity("Send to Intake and Assessment");
			}

			break;

		case "Quality Review":
			if (WorkFlowheader.equalsIgnoreCase("Full Data Entry")) {
				CommonOperations.setActivity("Send to Quality Review");
			}

			break;

		case "Medical Review":
			if (WorkFlowheader.equalsIgnoreCase("Quality Review")) {
				CommonOperations.setActivity("Send to Medical Review");
			}

			break;

		case "Supplemental Review":
			if (WorkFlowheader.equalsIgnoreCase("Medical Review")) {
				CommonOperations.setActivity("Send to Supplemental  Review");
			}

			break;

		case "Case Deletion":
			if (WorkFlowheader.equalsIgnoreCase("Case Deletion")) {
				CommonOperations.setActivity("Delete Confirmed");
			}

			break;

		case "To MedDRA Coding":
			if (WorkFlowheader.equalsIgnoreCase("Product/Manufacturer Coding")) {
				CommonOperations.setActivity("To MedDRA Coding");
			}

			break;
		}
		agMouseHover(FullDataEntryFormPageObjects.actions_Btn);
		// agJavaScriptExecuctorMouseHover(FullDataEntryFormPageObjects.completeActivity_link);
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.completeActivity_link);
		agSetStepExecutionDelay("4000");
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
		for(int i=0;i<2;i++) {
		if(agIsVisible(FullDataEntryFormPageObjects.WorkflowHeader)==true) {
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.WorkflowokBtn);
			break;
		}
		}
		agSetStepExecutionDelay("4000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.handelAuditInfo("JapanTest");
		if (agIsVisible(FullDataEntryFormPageObjects.completeAct_WarningLabel)) {

			// agwaitTillVisible(FullDataEntryFormPageObjects.completeAct_WarningLabel, 10,
			// 1000);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.warning_YesBtn);
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.warning_YesBtn);
			Reports.ExtentReportLog("", Status.INFO, "Action completed with Validation Errors", true);
			// Reports.ExtentReportLog("", Status.PASS, "", true);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);

		} else if (agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully)) {

			// System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
			// System.out.println(agGetText(FullDataEntryFormPageObjects.case_MovedToNxtAct));
			Reports.ExtentReportLog("", Status.INFO, "Action completed without Validation Errors", true);
			// Reports.ExtentReportLog("", Status.PASS, "", true);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
			agClick(FullDataEntryFormPageObjects.saveOkButton);
		}
		for(int i=0;i<2;i++) {
			if(agIsVisible(FullDataEntryFormPageObjects.WorkflowHeader)==true) {
				agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.WorkflowokBtn);
				break;
			}
		}
		agSetStepExecutionDelay("3000");
		if (!activityName.equalsIgnoreCase("Exit")) {
			// agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.SaveButton);
			agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
			// System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.INFO, "Case saved", true);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
			Reports.ExtentReportLog("", Status.PASS, "", true);
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Verify whether the ACtivity has
	 *             successfully Moved.
	 * @InputParameters: Receipt Number,ACtivity Name
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @return
	 * @Date : 22-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String VerifyCompleteActivity(String RecieptNo, String ActivityName) {
		CaseManagementOperations.menuNavigation("Case listing");

		if (ActivityName == "Exit") {
			AdvanceSearchOperations.navigateToAdvanceSearch();
			agWaitTillVisibilityOfElement(
					AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.caseDetails_link));
			agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.caseDetails_link));
			CommonOperations.agwaitTillVisible(AdvanceSearchPageObjects.displayCases_Label, 2, 1000);
			agSetStepExecutionDelay("3000");
			agClick(AdvanceSearchPageObjects.displayCases_radioBtn(AdvanceSearchPageObjects.Both_RadioBtn));
			// AdvanceSearchOperations.receiptNumberSearch(scenarioName);
			agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.administrativeFields_link));
			agwaitTillVisible(AdvanceSearchPageObjects.receiptNumber_Txtfield, 2, 1000);
			agSetStepExecutionDelay("5000");
			agSetValue(AdvanceSearchPageObjects.receiptNumber_Txtfield, RecieptNo);
			agClick(AdvanceSearchPageObjects.search_Btn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agwaitTillVisible(CaseListingPageObjects.waitForRCT(RecieptNo), 2, 1000);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			String label = "";

			if (agIsVisible(CaseListingPageObjects.receiptNumberlink)) {
				agClick(CaseListingPageObjects.receiptNumberlink);
				agwaitTillVisible(CaseListingPageObjects.caseActHeader);
				agSetStepExecutionDelay("5000");
				label = agGetText(CaseListingPageObjects.caseActHeader);
			} else {
				boolean chk = searchCaseInAct(RecieptNo, ActivityName);
				if (chk == true) {
					label = agGetText(CaseListingPageObjects.caseActHeader);
				}
			}

			return label;

		} else {
			agSetStepExecutionDelay("3000");
			agSetValue(CaseListingPageObjects.keywordSearchTextbox, RecieptNo);
			agJavaScriptExecuctorClick(CaseListingPageObjects.searchButton);
			CommonOperations.waitTillCaseVisible();
			CommonOperations.takeScreenShot();
			agClick(CaseListingPageObjects.receiptNumberlink);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
			String label = agGetText(CaseListingPageObjects.caseActHeader);

			if (label.equalsIgnoreCase(ActivityName)) {
				Reports.ExtentReportLog("", Status.PASS, "Activity Verification Sucessful", true);
			} else {
				boolean autoComplete = MoreActionsOperations.verifyAutoComplete(label);
				if (autoComplete)
					Reports.ExtentReportLog("", Status.PASS,
							"Activity Verification Sucessful - Activity auto completed to " + label, true);
				else
					Reports.ExtentReportLog("", Status.FAIL, "Activity Verification Unsuccessful", true);
			}
			return label;
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Verify whether the ACtivity has
	 *             successfully Moved.
	 * @InputParameters: ACtivity Name
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @return
	 * @Date : 30-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String VerifyCompleteActivityCaseFlow(String ActivityName) {
		agSetStepExecutionDelay("3000");
		agWaitTillVisibilityOfElement(CaseListingPageObjects.caseActHeader);
		String label = agGetText(CaseListingPageObjects.caseActHeader);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (label.equalsIgnoreCase(ActivityName)) {
			Reports.ExtentReportLog("", Status.PASS, "Activity Verification Sucessful", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Activity Verification Unsuccessful", true);
		}
		return label;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Verify whether the case is present in a
	 *             particular Activity.
	 * @InputParameters: Receipt Number , Activity Name
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @return
	 * @Date : 27-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean searchCaseInAct(String RecieptNo, String ActivityName) {
		CaseManagementOperations.menuNavigation("Case listing");

		agClick(CaseListingPageObjects.workflowlink(ActivityName));
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.workflowNavig_Loading);
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, RecieptNo);
		agClick(CaseListingPageObjects.searchButton);
		CommonOperations.waitTillCaseVisible();
		CommonOperations.takeScreenShot();

		if (agIsVisible(CaseListingPageObjects.receiptNumberlink)) {
			agClick(CaseListingPageObjects.receiptNumberlink);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
			Reports.ExtentReportLog("", Status.PASS, "Search successful", true);
			return true;
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Search Unsuccessful", true);

			return false;
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify radio button is checked or
	 *             not
	 * @InputParameters: label, radioButtonLabel
	 * @OutputParameters:NA
	 * @author:Kishore
	 * @Date : 25-Feb-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyRadioButton(String label, String radioButtonLabel, String boolCheck) {
		if (!label.trim().contains("#skip#") && !radioButtonLabel.trim().contains("#skip#")) {
			String radioButtonStatus = agGetAttribute("class",
					CommonPageObjects.selectRadioButton(label, radioButtonLabel));
			if ((radioButtonStatus.contains("bullet") || radioButtonStatus.contains("pi-circle-on"))
					&& boolCheck.equalsIgnoreCase("true")) {
				Reports.ExtentReportLog("Radio Button", Status.PASS,
						label + ": value : " + radioButtonLabel + " is selected", true);
			}

			else if ((radioButtonStatus.contains("blank")
					|| radioButtonStatus.equalsIgnoreCase("ui-radiobutton-icon ui-clickable"))
					&& boolCheck.equalsIgnoreCase("false")) {
				Reports.ExtentReportLog("Radio Button", Status.PASS,
						label + ": value : " + radioButtonLabel + " is not selected", true);
			}

			else if ((radioButtonStatus.contains("bullet") || radioButtonStatus.contains("pi-circle-on"))
					&& boolCheck.equalsIgnoreCase("false")) {
				Reports.ExtentReportLog("Radio Button", Status.FAIL,
						label + ": value : " + radioButtonLabel + " is selected", true);
			} else {
				Reports.ExtentReportLog("Radio Button", Status.FAIL,
						label + ": value : " + radioButtonLabel + " is not selected", true);
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select activity list type dropdown
	 *             value.
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters:NA
	 * @author:Kishore
	 * @Date : 04-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setActivity(String valueToSelect) {
		if (!valueToSelect.equalsIgnoreCase("#skip#")) {
			// agJavaScriptExecuctorScrollToElement(locator);
			// agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.activty_Dropdwn_label);
			// agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.selectActivity(valueToSelect));
			agSelectByValue(FullDataEntryFormPageObjects.activty_Dropdwn_label, valueToSelect);
			// agCheckPropertyText(valueToSelect, locator);
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created for retrieve the fileName with a format in
	 *             a path
	 * @InputParameters:path ,format
	 * @OutputParameters: String fileName
	 * @author: Kishore
	 * @Date : 13.2.2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String retrieveFileName(String path, String format) {

		File folder = new File(path);
		String fileName = null;
		FilenameFilter anyFileFilter = new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				if (name.endsWith("." + format)) {
					return true;
				} else {
					return false;
				}
			}
		};

		// Passing txtFileFilter to listFiles() method to retrieve only txt files

		File[] files = folder.listFiles(anyFileFilter);

		for (File file : files) {
			fileName = path + "\\" + file.getName();
			System.out.println(file.getName());
		}
		return fileName;
	}

	/**********************************************************************************************************
	 * @Objective: This method is created for clicking
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date : 05.3.2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickOnMenutoggle(String toogle) {
		switch (toogle) {
		case "RightToggle":
			agClick(CommonPageObjects.menuRightToggle);
			break;
		case "LeftToggle":
			agClick(CommonPageObjects.validationToggle);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Check/Uncheck Operation on
	 *             CheckBox under Specified Label.
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author:Yashwanth Naidu
	 * @Date : 5-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void checkAutopsyManual(String label, String boolCheck) {
		if (!boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = null;
			checkBoxStatus = ToolManager.agGetAttribute("class", CommonPageObjects.checkAutopsyManual(label));
			if (checkBoxStatus.contains("blank") || !checkBoxStatus.contains("pi-check")) {
				checkBoxStatus = "false";
			} else {
				checkBoxStatus = "true";
			}
			if ((boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check"))
					&& checkBoxStatus.equalsIgnoreCase("false")) {
				ToolManager.agClick(CommonPageObjects.checkAutopsyManual(label));
			} else if ((boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck"))
					&& checkBoxStatus.equalsIgnoreCase("true")) {
				ToolManager.agClick(CommonPageObjects.checkAutopsyManual(label));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to write Receipt No to
	 *             lsmv_wpa_controller table
	 * @InputParameters: scenarioName, sheetName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void writeReceiptNo(String scenarioName, String sheetName) {
		String receiptNumber = agGetText(FullDataEntryFormPageObjects.caseReceiptNo);
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "Receipt_Number",
				receiptNumber);
		status = agIsVisible(FullDataEntryFormPageObjects.caseReceiptNo);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "ReceiptNo added Successfully " + receiptNumber, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "ReceiptNo added UnSuccessfully " + receiptNumber, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to write Workflow status To
	 *             lsmv_wpa_controller table
	 * @InputParameters: scenarioName, sheetName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void writeWorkFlowStatus(String scenarioName, String sheetName) {
		String workFlowStatus = agGetText(FullDataEntryFormPageObjects.wfStatus);
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "Workflow_Status",
				workFlowStatus);
		status = agIsVisible(FullDataEntryFormPageObjects.wfStatus);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Workflow status added Successfully " + workFlowStatus, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Workflow status added UnSuccessfully " + workFlowStatus, true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the case is moved to out of
	 *             workflow
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 14-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyCaseMovedToOutOfWorkflow() {

		agWaitTillInvisibilityOfElement(CaseListingPageObjects.caseActHeader);
		String CurrentWorkFlow = agGetText(CaseListingPageObjects.caseActHeader);

		if (CurrentWorkFlow.equalsIgnoreCase("Exit")) {
			Reports.ExtentReportLog("", Status.PASS, "Case moved to Out of Workflow", true);

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Case is not moved to Out of Workflow ", true);
		}
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the case remains in
	 *             workflow
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 14-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyCaseRemainsInWorkflow() {

		agWaitTillInvisibilityOfElement(CaseListingPageObjects.caseActHeader);
		String CurrentWorkFlow = agGetText(CaseListingPageObjects.caseActHeader);

		if (!CurrentWorkFlow.equalsIgnoreCase("Exit")) {
			Reports.ExtentReportLog("", Status.PASS, "Case is in Workflow", true);

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Case is not in Workflow ", true);
		}
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is used to validate Case Summary PDFs
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 16-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void validatePDF(String reportType, String recieptNumber) {
		Reports.ExtentReportLog("", Status.INFO,
				"Validate PDF of ReportType:'" + reportType + "' for " + recieptNumber + " Started'", true);

		try {
			if (reportType.equalsIgnoreCase("SUMMARY"))
				reportType = "Case Summary";
			FDE_Operations.openReports(reportType);
			agSetStepExecutionDelay("5000");
			status = agIsVisible(CommonPageObjects.blindedUnblindedReportPopUP);
			if (status) {
				agJavaScriptExecuctorClick(CommonPageObjects.checkMaskedReport);

				status = agIsVisible(CommonPageObjects.checkBlindedUnblindedReport);
				if (status) {
					agJavaScriptExecuctorClick(CommonPageObjects.checkBlindedUnblindedReport);
				}
				agClick(CommonPageObjects.clickGenerateReport);
			}
			downloadPDF(reportType);
			CommonOperations.move_DownloadedReportToFolder(reportType, recieptNumber);
			boolean fileDownloaded = CommonOperations.verifyFileDownaladed(reportType, recieptNumber);
			if (fileDownloaded) {
				Reports.ExtentReportLog("", Status.PASS,
						reportType + " :Downloaded Successfully to folder " + lsmvConstants.path, false);
			} else
				Reports.ExtentReportLog("", Status.FAIL, reportType + " :Downloaded failed", false);
		} catch (Exception ex) {
			Reports.ExtentReportLog("", Status.FAIL,
					"Validate PDF of ReportType:'" + reportType + "' for " + recieptNumber + " Started'", true);

		}
		Reports.ExtentReportLog("", Status.INFO,
				"Validate PDF of ReportType:'" + reportType + "' for " + recieptNumber + " Started'", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download and close the report
	 *             window
	 * @InputParameters: reportType
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 18-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downloadPDF(String reportType) {
		try {
			int i = 0, sz = agGetWindowCount();
			agSetStepExecutionDelay("5000");
			while (!(sz == 2) && i < 75) {
				sz = agGetWindowCount();
				i++;
				System.out.println("Waiting" + i);
			}
			agGetCurrentWindow();
			agSetStepExecutionDelay("3000");
			agWaitTillVisibilityOfElement(CommonPageObjects.downloadPdf);
			if(agIsVisible(CommonPageObjects.downloadPdf)) {
			agJavaScriptExecuctorClick(CommonPageObjects.downloadPdf);}
			Reports.ExtentReportLog("", Status.INFO, reportType + " : Downloaded Successfully", true);
			try {
				Thread.sleep(20000);
			} catch (InterruptedException e) // Hard wait is used reason file to get download taking time
			{
				e.printStackTrace();

			}
			agCloseCurrentWindow();
			agGetWindowControlByInstance(1);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} catch (Exception ex) {
			Reports.ExtentReportLog("", Status.FAIL, reportType + " :Download Failed", true);

		}
	}

	public static void move_DownloadedReportToFolder(String reportType, String recieptNo) {
		String rootPath = lsmvConstants.LSMV_testDataOutput + "\\" + recieptNo;
		FileSystemOperations.createFolder(rootPath);
		String path = rootPath + "\\" + reportType + "_" + recieptNo;
		lsmvConstants.path = path;
		String currentFileName = recieptNo + ".pdf";
		if (reportType.contains("Case Summary"))
			currentFileName = "SUMMARY_" + currentFileName;
		else if (reportType.contains("MEDWATCH"))
			FileSystemOperations.renameFile(lsmvConstants.LSMV_testDataOutput, "MEDWATCH_" + currentFileName,
					currentFileName);
		else if (reportType.contains("CIOMS"))
			FileSystemOperations.renameFile(lsmvConstants.LSMV_testDataOutput, "CIOMS_REPORT_" + currentFileName,
					currentFileName);
		agSetStepExecutionDelay("5000");
		FileSystemOperations.createFolder(path);
		String newFileName = currentFileName;
		if (!reportType.equalsIgnoreCase("Case Summary")) {
			newFileName = reportType + "_" + currentFileName;
			FileSystemOperations.renameFile(lsmvConstants.LSMV_testDataOutput, currentFileName, newFileName);
		}
		FileSystemOperations.moveFile(newFileName, lsmvConstants.LSMV_testDataOutput, path);
		agSetStepExecutionDelay(Constants.globalStepExecutionDelay + "");
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify whetherPDF downloaded
	 *             successfully
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 12-Jun-2020
	 * @UpdatedByAndWhen: Karthikeyan natarajan, 18-Jun-2020
	 **********************************************************************************************************/
	public static boolean verifyFileDownaladed(String reportType, String recptNo) {
		boolean status = false;
		if (reportType.equalsIgnoreCase("Case Summary"))
			reportType = "SUMMARY";
		String fileName = reportType + "_" + recptNo + ".pdf";
		status = PDFOperations.isFileDownloaded(lsmvConstants.path + "\\", fileName);
		return status;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to move downloaded PDF to desired
	 *             location
	 * @InputParameters: reportType
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 16-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void move_DownloadedPDF(String reportType) {
		String path = lsmvConstants.LSMV_testDataOutput + "\\" + Reports.currenttime();
		lsmvConstants.path = path;
		System.out.println(lsmvConstants.path);
		FileSystemOperations.createFolder(path);
		FileSystemOperations.moveFile(reportType, lsmvConstants.LSMV_testDataOutput, path);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to trim receipt from the message.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 03-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String trimReceiptNo(String scenarioName, String sheetName) {
		CommonOperations.agwaitTillVisible(FullDataEntryFormPageObjects.receiptNumber, 20, 1000);
		String receiptNumber = agGetText(FullDataEntryFormPageObjects.receiptNumber);
		String[] arrOfStr = receiptNumber.split("Receipt number");
		arrOfStr = arrOfStr[1].split("saved successfully");
		receiptNumber = arrOfStr[0].trim();
		return receiptNumber;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to move case from one activity to
	 *             next activity
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Yashwanth
	 * @Date : 07-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void japanCompleteActivity(String activityName) {
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
		agWaitTillVisibilityOfElement(CaseListingPageObjects.caseActHeader);
		String WorkFlowheader = agGetText(CaseListingPageObjects.caseActHeader);
		CommonOperations.takeScreenShot();

		switch (activityName) {

		case "JPN Review":

			if (WorkFlowheader.equalsIgnoreCase("JPN Data Entry")) {
				CommonOperations.setActivity("Send to JPN Review");
			}

			break;

		case "Approval":

			if (WorkFlowheader.equalsIgnoreCase("JPN Review")) {
				CommonOperations.setActivity("Send to Approval");
			}

			break;

		case "PMDA Distribute":

			if (WorkFlowheader.equalsIgnoreCase("JPN Approval")) {
				CommonOperations.setActivity("Send to PMDA Distribute");
			}

			break;

		case "JPN Workflow Complete":

			if (WorkFlowheader.equalsIgnoreCase("PMDA Distribute")) {
				CommonOperations.setActivity("JPN Workflow Complete");
			}

			break;
		}
		agMouseHover(FullDataEntryFormPageObjects.actions_Btn);
		// agJavaScriptExecuctorMouseHover(FullDataEntryFormPageObjects.completeActivity_link);
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.completeActivity_link);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
		agSetStepExecutionDelay("10000");
		CommonOperations.handelAuditInfo("JapanTest");
		if (agIsVisible(FullDataEntryFormPageObjects.completeAct_WarningLabel)) {

			// agwaitTillVisible(FullDataEntryFormPageObjects.completeAct_WarningLabel, 10,
			// 1000);
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.warning_YesBtn);
			Reports.ExtentReportLog("", Status.PASS, "Action completed with Validation Errors", true);
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.ActionOkBtn);

		} else if (agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully)) {

			if (activityName.equalsIgnoreCase("JPN Workflow Complete")) {
				System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
				Reports.ExtentReportLog("", Status.PASS, "Action completed without Validation Errors", true);
				agClick(FullDataEntryFormPageObjects.ActionOkBtn);
			} else {
				System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
				System.out.println(agGetText(FullDataEntryFormPageObjects.case_MovedToNxtAct));
				Reports.ExtentReportLog("", Status.PASS, "Action completed without Validation Errors", true);
				agClick(FullDataEntryFormPageObjects.ActionOkBtn);
			}
		}

		agSetStepExecutionDelay("8000");
		if (!activityName.equalsIgnoreCase("Exit")) {
			// agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.SaveButton);
			agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
			System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.PASS, "Case saved", true);
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set save and update audit info in
	 *             LSMV application.
	 * @InputParameters: testData
	 * @OutputParameters:NA
	 * @author:Yashwanth Naidu
	 * @Date : 15-July-2020
	 * @UpdatedByAndWhen: Pooja S on 1-Oct-2020
	 **********************************************************************************************************/
	public static void handelAuditInfo(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		boolean returnAudit = agIsVisible(CommonPageObjects.auditInfo_Label);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (returnAudit == true) {
			// agClick(CommonPageObjects.clickAuditReason_dropdwn);
			// agJavaScriptExecuctorClick(CommonPageObjects.clickAuditReason_dropdwn);
			// agClick(CommonPageObjects.setAuditreasonDropdrown(getTestDataCellValue(scenarioName,
			// "ReasonCode")));
			agSelectByVisibleText(CommonPageObjects.clickAuditReason_dropdwn,
					getTestDataCellValue(scenarioName, "ReasonCode"));
			agSetValue(CommonPageObjects.auditreason_Textarea, getTestDataCellValue(scenarioName, "Reason"));
			CommonOperations.takeScreenShot();
			agClick(CommonPageObjects.submit_Btn);
			agSetStepExecutionDelay("3000");
			agWaitTillInvisibilityOfElement(CommonPageObjects.auditInfo_Label);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Audit reason popup is not displayed", false);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Cases via Email for Medwatch,
	 *             CIOMS, PSP and NTA
	 * @InputParameters: scenarioName, creationType
	 * @OutputParameters:
	 * @author:Karthikeyan Natarajan
	 * @Date : 03-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void createCaseViaEmail(String scenarioName, String creationType) {
		Connection dbCon = null;
		try {
			Reports.ExtentReportLog("", Status.INFO, "Email Case Creation for scenario " + scenarioName + " started",
					false);
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);
			String FileName = null;
			ArrayList<String> files = E2BMessageQueueOperations
					.GetFileCountName(lsmvConstants.lsmvE2EScenarioPath + creationType + "_Input\\");
			System.out.println(files);
			int fileCount = files.size();
			System.out.println("fileCount: " + fileCount);
			int fileNumber = 0;
			String fileName = null;
			for (int j = 0; j < files.size(); j++) {
				fileName = files.get(j);
				if (fileName.contains(scenarioName)) {
					fileNumber = j;
					System.out.println("fileNumber: " + fileNumber);
					System.out.println("fileName: " + fileName);
					break;
				}
			}
			FileName = files.get(fileNumber);
			String rctNum = OutlookWebMail.CaseCreationViaEMail(scenarioName, creationType + "_Input", FileName);

			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
			String RecieptNumberPrefix = getTestDataCellValue("LSMV_ISP_Config", "ReceiptPrefix");

			if (rctNum.contains(RecieptNumberPrefix)) {
				Reports.ExtentReportLog("", Status.PASS,
						"Receipt Numbering Format - Prefix is getting Mapped in Created Reciept Number", true);

			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						"Receipt Numbering Format - Prefix is getting Mapped in Created Reciept Number", true);
			}

			DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set Receipt_Number = '" + rctNum
					+ "' where Scenario='" + scenarioName + "'");
			Reports.ExtentReportLog("", Status.INFO, "Email Case Creation for scenario " + scenarioName + " ended",
					false);
		} catch (Exception ex) {
			Reports.ExtentReportLog("", Status.FAIL, "Email Case Creation for scenario " + scenarioName + " failed",
					false);
			OutlookWebMail.Logout();

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data is visible in
	 *             downloaded report specific for unblinded products
	 * @InputParameters: reportType, scenarioName, sheetName,
	 *                   columnName,scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 04-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyDataVisible_UnBlindedDownloadedReport(String reportType, String scenarioName,
			String sheetName, String columnName, String scenarioName1) {
		String RecptNo = FDE_General.getData(scenarioName, "ReceiptNo");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		PDFOperations.pdfverificationForVisible(lsmvConstants.path + "\\" + reportType + "_" + RecptNo + ".pdf",
				getTestDataCellValue(scenarioName1, columnName));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data is not visible in
	 *             downloaded report specific for unblinded products
	 * @InputParameters: reportType, scenarioName, sheetName,
	 *                   columnName,scenarioName1
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 04-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDataNotVisible_UnBlindedDownloadedReport(String reportType, String scenarioName,
			String sheetName, String columnName, String scenarioName1) {
		String RecptNo = FDE_General.getData(scenarioName, "ReceiptNo");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		PDFOperations.pdfverificationForNotVisible(lsmvConstants.path + "\\" + reportType + "_" + RecptNo + ".pdf",
				getTestDataCellValue(scenarioName1, columnName));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to move downloaded excel which
	 *             contains .XLS extension to desired location
	 * @InputParameters: FileName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 01-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void move_XLSDownloadedexcel(String FileName) {
		String path = lsmvConstants.LSMV_testDataOutput + "\\" + Reports.currenttime();
		lsmvConstants.path = path;
		System.out.println(lsmvConstants.path);
		FileSystemOperations.createFolder(path);
		FileSystemOperations.moveFile(FileName + ".xls", lsmvConstants.LSMV_testDataOutput, path);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data is visible in
	 *             downloaded report specific for unblinded products[without receipt
	 *             number]
	 * @InputParameters: reportType, scenarioName, sheetName,
	 *                   columnName,scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 04-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyDataVisible_UnBlindedGeneratedReport(String reportType, String scenarioName,
			String sheetName, String columnName, String scenarioName1) {
		// String RecptNo = FDE_General.getData(scenarioName, "ReceiptNo");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		PDFOperations.pdfverificationForVisible(lsmvConstants.path + "\\" + reportType + ".pdf",
				getTestDataCellValue(scenarioName1, columnName));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data is not visible in
	 *             downloaded report specific for unblinded products[without receipt
	 *             number]
	 * @InputParameters: reportType, scenarioName, sheetName,
	 *                   columnName,scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 04-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyDataNotVisible_UnBlindedGeneratedReport(String reportType, String scenarioName,
			String sheetName, String columnName, String scenarioName1) {
		// String RecptNo = FDE_General.getData(scenarioName, "ReceiptNo");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		PDFOperations.pdfverificationForNotVisible(lsmvConstants.path + "\\" + reportType + ".pdf",
				getTestDataCellValue(scenarioName1, columnName));
	}

	public static void move_DownloadedFile(String FileName) {
		String path = lsmvConstants.LSMV_testDataOutput + "\\" + Reports.currenttime();
		lsmvConstants.path = path;
		System.out.println(lsmvConstants.path);
		FileSystemOperations.createFolder(path);
		FileSystemOperations.moveFile(FileName, lsmvConstants.LSMV_testDataOutput, path);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data is not visible in
	 *             downloaded report.[without Receipt number]
	 * @InputParameters: reportType, scenarioName, sheetName, columnName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 10-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDataNotVisible_GeneratedReport(String reportType, String scenarioName, String sheetName,
			String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		PDFOperations.pdfverificationForNotVisible(lsmvConstants.path + "\\" + reportType + ".pdf",
				getTestDataCellValue(scenarioName, columnName));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created write Receipt No To Datasheet
	 * @InputParameters: scenarioName, sheetName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 08-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void writeCreatedVersionRecptNo_FDESave(String scenarioName, String sheetName) {
		CommonOperations.agwaitTillVisible(FullDataEntryFormPageObjects.createVersionReceiptNO, 20, 1000);
		String receiptNumber = agGetText(FullDataEntryFormPageObjects.createVersionReceiptNO);
		/*
		 * String data1 =
		 * receiptNumber.substring(receiptNumber.lastIndexOf("Receipt Number:")); String
		 * RCTNo = data1.substring(15, data1.indexOf("saved successfully"));
		 */

		String[] arrOfStr = receiptNumber.split("Receipt No:");
		arrOfStr = arrOfStr[1].split("with ");
		receiptNumber = arrOfStr[0].trim();
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "ReceiptNo", receiptNumber);
	}

	/**********************************************************************************************************
	 * Objective:This method is created to set Step number in ALM scope Input
	 * Parameters:String scenarioName Output Parameters:
	 * 
	 * @author:DushyanthMahesh Date :25-Nov-2020 Updated by and when:
	 **********************************************************************************************************/

	public static void almStepNumber(String stepNum) {
		Constants.stepNo = stepNum;
		lsmvConstants.stepNumber = stepNum;
		Reports.ExtentReportLog("", Status.PASS, "\n", false);
	}

	/**********************************************************************************************************
	 * Objective:This method is created Add logs to components scope Input
	 * Parameters:String scenarioName Output Parameters:
	 * 
	 * @author:DushyanthMahesh Date :25-Nov-2020 Updated by and when:
	 **********************************************************************************************************/

	public static void log(String labelName, String userLogs) {

		if (userLogs == null && userLogs == "null" && userLogs.equalsIgnoreCase(null)) {
		} else {

			if (lsmvConstants.boolLog == true) {
				if (!userLogs.equalsIgnoreCase("#skip#") && userLogs != "#skip#" && userLogs != "#SKIP#"
						&& userLogs != "") {
					Reports.ExtentReportLog("Logs", Status.PASS, labelName + userLogs, false);
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method Created to take screen shot
	 * @Input Parameters:NA
	 * @Output Parameters: NA
	 * @author: DushyanthMahesh Date : 25-Nov-2020 Updated by and when:
	 **********************************************************************************************************/

	public static void captureScreenShot() {
		if (lsmvConstants.boolLog == true) {
			Reports.ExtentReportLog("ScreenShot", Status.PASS, "", lsmvConstants.boolScreenShot);
		}
	}

	public static void captureScreenShot(boolean scresnShot) {
		Reports.ExtentReportLog("ScreenShot", Status.PASS, "", scresnShot);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data is visible in
	 *             downloaded report with reference to the second data sheet (the
	 *             source sheet is other than FDE_General).
	 * @InputParameters: reportType, scenarioName, scenarioName2, sheetName,
	 *                   columnName
	 * @OutputParameters:
	 * @author: Shamanth
	 * @Date : 15-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyDataVisible(String reportType, String scenarioName, String scenarioName2, String sheetName,
			String columnName) {
		String RecptNo = FDE_General.getData(scenarioName, "ReceiptNo");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		CommonOperations.pdfverificationForVisible(lsmvConstants.path + "\\" + reportType + "_" + RecptNo + ".pdf",
				getTestDataCellValue(scenarioName2, columnName));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data is visible in
	 *             downloaded PDF report.
	 * @InputParameters: fileName, scenarioName, sheetName, columnName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 16-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyDataVisible_PDFReport(String fileName, String scenarioName, String sheetName,
			String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		String filePath = lsmvConstants.path + "\\" + fileName + ".pdf";
		CommonOperations.pdfverificationForVisible(filePath, getTestDataCellValue(scenarioName, columnName));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to move case from one activity to
	 *             exit activity without clicking on OK button to minimize the Rule
	 *             Validations
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 13-Jan-2020
	 * @UpdatedByAndWhen:Kishore and 4-Mar-2020
	 **********************************************************************************************************/
	public static void completeActivityWithValidationOnDisplay(String activityName) {
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
		agWaitTillVisibilityOfElement(CaseListingPageObjects.caseActHeader);
		String WorkFlowheader = agGetText(CaseListingPageObjects.caseActHeader);
		CommonOperations.takeScreenShot();

		switch (activityName) {

		case "Case Approval":

			if (WorkFlowheader.equalsIgnoreCase("Final Review")) {
				CommonOperations.setActivity("Send to Case Approval");
			}

			break;

		case "Final Review":

			if (WorkFlowheader.equalsIgnoreCase("Medical Review")) {
				CommonOperations.setActivity("Send to Final Review");
			}

			break;

		case "Distribute":

			if (WorkFlowheader.equalsIgnoreCase("Case Approval (Auto)")) {
				CommonOperations.setActivity("Send to Distribute");
			}

			break;

		case "Distribute Transit":

			if (WorkFlowheader.equalsIgnoreCase("Distribute") || WorkFlowheader.equalsIgnoreCase("Minor Change")) {
				CommonOperations.setActivity("Send to Distribute Transit");
			}

			break;

		case "Exit":

			if (WorkFlowheader.equalsIgnoreCase("Distribute Transit")) {
				CommonOperations.setActivity("Exit");
			}

			break;

		case "Minor Change":

			if (WorkFlowheader.equalsIgnoreCase("Distribute Transit")) {
				CommonOperations.setActivity("Send to Minor Change");
			}

			break;

		case "Non Case":
			if (WorkFlowheader.equalsIgnoreCase("Initial")) {
				CommonOperations.setActivity("Send to Non Case");
			}

			break;

		case "Full Data Entry":
			if (WorkFlowheader.equalsIgnoreCase("Review")) {
				CommonOperations.setActivity("Send to Full Data Entry");
			}

			break;

		case "Review":
			if (WorkFlowheader.equalsIgnoreCase("Intake and Assessment")) {
				CommonOperations.setActivity("Send to Review");
			} else if (WorkFlowheader.equalsIgnoreCase("Translation")) {
				CommonOperations.setActivity("Send  to Review");
			}

			break;

		case "Intake and Assessment":

			if (WorkFlowheader.equalsIgnoreCase("Non Case")) {
				CommonOperations.setActivity("Send to Intake and Assessment");
			}

			break;

		case "Quality Review":
			if (WorkFlowheader.equalsIgnoreCase("Full Data Entry")) {
				CommonOperations.setActivity("Send to Quality Review");
			}

			break;

		case "Medical Review":
			if (WorkFlowheader.equalsIgnoreCase("Quality Review")) {
				CommonOperations.setActivity("Send to Medical Review");
			}

			break;

		case "Supplemental Review":
			if (WorkFlowheader.equalsIgnoreCase("Medical Review")) {
				CommonOperations.setActivity("Send to Supplemental  Review");
			}

			break;

		case "Case Deletion":
			if (WorkFlowheader.equalsIgnoreCase("Case Deletion")) {
				CommonOperations.setActivity("Delete Confirmed");
			}

			break;

		case "To MedDRA Coding":
			if (WorkFlowheader.equalsIgnoreCase("Product/Manufacturer Coding")) {
				CommonOperations.setActivity("To MedDRA Coding");
			}

			break;
		}
		agMouseHover(FullDataEntryFormPageObjects.actions_Btn);
		// agJavaScriptExecuctorMouseHover(FullDataEntryFormPageObjects.completeActivity_link);
		agClick(FullDataEntryFormPageObjects.completeActivity_link);
		agSetStepExecutionDelay("5000");
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
		CommonOperations.handelAuditInfo("JapanTest");
		if (agIsVisible(FullDataEntryFormPageObjects.completeAct_WarningLabel)) {

			// agwaitTillVisible(FullDataEntryFormPageObjects.completeAct_WarningLabel, 10,
			// 1000);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.warning_YesBtn);
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.warning_YesBtn);
			Reports.ExtentReportLog("", Status.PASS, "", true);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.ActionOkBtn);
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.ActionOkBtn);

		} else if (agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully)) {

			// System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
			// System.out.println(agGetText(FullDataEntryFormPageObjects.case_MovedToNxtAct));
			Reports.ExtentReportLog("", Status.PASS, "", true);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.ActionOkBtn);
			agClick(FullDataEntryFormPageObjects.ActionOkBtn);
		}

		agSetStepExecutionDelay("8000");
		if (!activityName.equalsIgnoreCase("Exit")) {
			// agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.SaveButton);
			agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
			// System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.PASS, "", true);
			// agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
			// agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to move case from one activity to
	 *             next activity with verifying the validation
	 * @InputParameters: activityName,scearioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 21-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void completeActivity(String activityName, String scenarioName, String action,
			boolean isValExpected) {
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
		agWaitTillVisibilityOfElement(CaseListingPageObjects.caseActHeader);
		String WorkFlowheader = agGetText(CaseListingPageObjects.caseActHeader);
		CommonOperations.takeScreenShot();

		switch (activityName) {

		case "Case Approval":

			if (WorkFlowheader.equalsIgnoreCase("Final Review")) {
				CommonOperations.setActivity("Send to Case Approval");
			}

			break;

		case "Final Review":

			if (WorkFlowheader.equalsIgnoreCase("Medical Review")) {
				CommonOperations.setActivity("Send to Final Review");
			}

			break;

		case "Distribute":

			if (WorkFlowheader.equalsIgnoreCase("Case Approval (Auto)")) {
				CommonOperations.setActivity("Send to Distribute");
			}

			break;

		case "Distribute Transit":

			if (WorkFlowheader.equalsIgnoreCase("Distribute") || WorkFlowheader.equalsIgnoreCase("Minor Change")) {
				CommonOperations.setActivity("Send to Distribute Transit");
			}

			break;

		case "Exit":

			if (WorkFlowheader.equalsIgnoreCase("Distribute Transit")) {
				CommonOperations.setActivity("Exit");
			}

			break;

		case "Minor Change":

			if (WorkFlowheader.equalsIgnoreCase("Distribute Transit")) {
				CommonOperations.setActivity("Send to Minor Change");
			}

			break;

		case "Non Case":
			if (WorkFlowheader.equalsIgnoreCase("Initial")) {
				CommonOperations.setActivity("Send to Non Case");
			}

			break;

		case "Full Data Entry":
			if (WorkFlowheader.equalsIgnoreCase("Review")) {
				CommonOperations.setActivity("Send to Full Data Entry");
			}

			break;

		case "Review":
			if (WorkFlowheader.equalsIgnoreCase("Intake and Assessment")) {
				CommonOperations.setActivity("Send to Review");
			} else if (WorkFlowheader.equalsIgnoreCase("Translation")) {
				CommonOperations.setActivity("Send  to Review");
			}

			break;

		case "Intake and Assessment":

			if (WorkFlowheader.equalsIgnoreCase("Non Case")) {
				CommonOperations.setActivity("Send to Intake and Assessment");
			}

			break;

		case "Quality Review":
			if (WorkFlowheader.equalsIgnoreCase("Full Data Entry")) {
				CommonOperations.setActivity("Send to Quality Review");
			}

			break;

		case "Medical Review":
			if (WorkFlowheader.equalsIgnoreCase("Quality Review")) {
				CommonOperations.setActivity("Send to Medical Review");
			}

			break;

		case "Supplemental Review":
			if (WorkFlowheader.equalsIgnoreCase("Medical Review")) {
				CommonOperations.setActivity("Send to Supplemental  Review");
			}

			break;

		case "Case Deletion":
			if (WorkFlowheader.equalsIgnoreCase("Case Deletion")) {
				CommonOperations.setActivity("Delete Confirmed");
			}

			break;

		case "To MedDRA Coding":
			if (WorkFlowheader.equalsIgnoreCase("Product/Manufacturer Coding")) {
				CommonOperations.setActivity("To MedDRA Coding");
			}

			break;
		}
		agMouseHover(FullDataEntryFormPageObjects.actions_Btn);
		// agJavaScriptExecuctorMouseHover(FullDataEntryFormPageObjects.completeActivity_link);
		agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.completeActivity_link);
		agSetStepExecutionDelay("5000");
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
		// CommonOperations.handelAuditInfo("JapanTest");
		if (agIsVisible(FullDataEntryFormPageObjects.completeAct_WarningLabel)) {

			// agwaitTillVisible(FullDataEntryFormPageObjects.completeAct_WarningLabel, 10,
			// 1000);
			Validations.getValidations();
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.warning_YesBtn);
			FDE_Operations.readValidation(scenarioName, action, isValExpected);
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.warning_YesBtn);
			Reports.ExtentReportLog("", Status.PASS, "Action completed with Validation Errors", true);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.ActionOkBtn);
			agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.ActionOkBtn);

		} else if (agIsVisible(FullDataEntryFormPageObjects.actComp_Sucessfully)) {

			// System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
			// System.out.println(agGetText(FullDataEntryFormPageObjects.case_MovedToNxtAct));
			Reports.ExtentReportLog("", Status.PASS, "Action completed without Validation Errors", true);
			FDE_Operations.readValidation(scenarioName, action, isValExpected);
			agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.ActionOkBtn);
			agClick(FullDataEntryFormPageObjects.ActionOkBtn);
		}

		agSetStepExecutionDelay("8000");
		// if (!activityName.equalsIgnoreCase("Exit")) {
		// // agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.SaveButton);
		// agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.compAct_Load);
		// // System.out.println(agGetText(FullDataEntryFormPageObjects.receiptNumber));
		// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// Reports.ExtentReportLog("", Status.PASS, "Case saved", true);
		// FDE_Operations.readValidation(scenarioName, "save", false);
		// agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
		// agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);
		// }

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in PDF for downloaded
	 *             report.
	 * @InputParameters: reportType, scenarioName, sheetName, columnName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 05-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyPDFData_DownloadedReport(String reportType, String scenarioName, String sheetName,
			String columnName) {
		String RecptNo = FDE_General.getData(scenarioName, "ReceiptNo");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		PDFOperations.pdfDataverification(lsmvConstants.path + "\\" + reportType + "_" + RecptNo + ".pdf",
				getTestDataCellValue(scenarioName, columnName));
	}

	public static String getReportDownloadPath(String reportType, String scenarioName) {
		String RecptNo = FDE_General.getData(scenarioName, "ReceiptNo");
		String mypath = (lsmvConstants.path + "\\" + reportType + "_" + RecptNo + ".pdf");
		return mypath;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created for PDF verification for data visible
	 * @InputParameters: path, data
	 * @OutputParameters:
	 * @author: Shamanth
	 * @Date : 07-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void pdfverificationForVisible(String path, String data) {

		PDDocument pd;
		try {
			pd = PDDocument.load(new File(path));
			PDFTextStripper pdf = new PDFTextStripper();
			status = (pdf.getText(pd).contains(data));
			if (status) {
				Reports.ExtentReportLog("", Status.INFO, "", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "", true);
			}
		} catch (InvalidPasswordException e) {
			Reports.ExtentReportLog("Pdf not downloaded :", Status.FAIL, "", true);
		} catch (IOException e) {
			Reports.ExtentReportLog("Pdf not downloaded :", Status.FAIL, "", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Cases via Email for Medwatch,
	 *             CIOMS, PSP and NTA
	 * @InputParameters: scenarioName, creationType
	 * @OutputParameters:
	 * @author:praveen patil
	 * @Date : 22-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void createCaseViaEmailPri(String scenarioName, String creationType, String sheetName) {

		try {
			Reports.ExtentReportLog("", Status.INFO, "Email Case Creation for scenario " + scenarioName + " started",
					false);

			String FileName = null;
			ArrayList<String> files = E2BMessageQueueOperations
					.GetFileCountName(lsmvConstants.lsmvE2EScenarioPath + creationType + "_Input\\");
			System.out.println(files);
			int fileCount = files.size();
			System.out.println("fileCount: " + fileCount);
			int fileNumber = 0;
			String fileName = null;
			for (int j = 0; j < files.size(); j++) {
				fileName = files.get(j);
				if (fileName.contains(scenarioName)) {
					fileNumber = j;
					System.out.println("fileNumber: " + fileNumber);
					System.out.println("fileName: " + fileName);
					break;
				}
			}
			FileName = files.get(fileNumber);
			String rctNum = OutlookWebMail.CaseCreationViaEMail(scenarioName, creationType + "_Input", FileName);

			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			// CommonOperations.writeRecptNo_FDESave(scenarioName, sheetName);

			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "ReceiptNo", rctNum);

			// DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set
			// Receipt_Number = '" + rctNum
			// + "' where Scenario='" + scenarioName + "'");

			Reports.ExtentReportLog("", Status.INFO, "Email Case Creation for scenario " + scenarioName + " ended",
					false);
		} catch (Exception ex) {
			Reports.ExtentReportLog("", Status.FAIL, "Email Case Creation for scenario " + scenarioName + " failed",
					false);
			OutlookWebMail.Logout();

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select list type dropdown value in
	 *             unstructured form
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters:NA
	 * @author:Praveen
	 * @Date : 27-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setListUnstructuredDropDownValue(String locator, String valueToSelect) {
		if (!valueToSelect.equalsIgnoreCase("#skip#")) {

			agSetStepExecutionDelay("2000");
			agClick(locator);
			agClick(CommonPageObjects.selectListDropDownUnstructured(locator, valueToSelect));

		}
	}

	public static void distributeActivityVerify() {
		agSetStepExecutionDelay("5000");
		agIsVisible(CaseListingPageObjects.distributeActivity);
		CommonOperations.captureScreenShot(true);

	}

	public static String incremAlmStepNo() {
		int stepNo = 0;
		stepNo = Integer.parseInt(lsmvConstants.stepNumber) + 1;
		lsmvConstants.stepNumber = String.valueOf(stepNo);
		Constants.stepNo = lsmvConstants.stepNumber;
		System.out.println("Step No:" + lsmvConstants.stepNumber);
		Reports.ExtentReportLog("", Status.PASS, "\n", false);
		return lsmvConstants.stepNumber;
	}

	/**********************************************************************************************************
	 * Objective:This method is created to increment Step number in ALM scope Input
	 * Parameters:String Increment or Not or StepNo, Status- Pass or Fail, Message
	 * or Skip , True or False for screenshot Output Parameters:
	 * 
	 * @author:Kishore K R Date :21-Jan-2021 Updated by and when:
	 **********************************************************************************************************/

	public static String incremAlmStepNo(String incTrueOrFalseorStepNo, String status, String msg, Boolean screenshot) {
		int stepNo = 0;
		if (incTrueOrFalseorStepNo.equalsIgnoreCase("True")) {
			stepNo = Integer.parseInt(lsmvConstants.stepNumber) + 1;
			lsmvConstants.stepNumber = String.valueOf(stepNo);
			Constants.stepNo = lsmvConstants.stepNumber;
		} else if (incTrueOrFalseorStepNo.equalsIgnoreCase("False")) {

		} else {
			stepNo = Integer.parseInt(incTrueOrFalseorStepNo);
			lsmvConstants.stepNumber = String.valueOf(stepNo);
			Constants.stepNo = lsmvConstants.stepNumber;
		}
		System.out.println("Step No:" + lsmvConstants.stepNumber);

		if (!msg.equalsIgnoreCase("#skip#")) {
			msg = "\n " + msg;
		}

		if (status.equalsIgnoreCase("Pass")) {
			Reports.ExtentReportLog("", Status.PASS, msg, screenshot);
		} else if (status.equalsIgnoreCase("Skip")) {
			Reports.ExtentReportLog("", Status.SKIP, msg, screenshot);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, msg, screenshot);
		}
		return lsmvConstants.stepNumber;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data with Extent report for
	 *             Hp ALM
	 * @InputParameters: object, scenario name, coloumn name, attribute/text
	 * @OutputParameters:
	 * @author:Kishore
	 * @Date :2-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String verifyData(String object, String scenarioName, String columnName, String attrib) {

		String expVal = "";
		if (columnName.contains("Date"))
			expVal = CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, columnName));
		else
			expVal = getTestDataCellValue(scenarioName, columnName);
		String val = "";
		// System.out.println("Expected Value:"+expVal);
		if (!expVal.equalsIgnoreCase("#skip#")) {
			if (!attrib.equalsIgnoreCase("text")) {
				agClick(object);
				val = agGetAttribute(attrib, object);
			} else {
				val = agGetText(object);
			}
			if (expVal.equalsIgnoreCase(val)) {
				Reports.ExtentReportLog("", Status.PASS, columnName + " value-" + val, false);
				return "Pass";
			} else {
				Reports.ExtentReportLog("", Status.FAIL, columnName + " Exp value-" + expVal + " and Act value-" + val,
						true);
				return "Fail";
			}
		} else {
			return "Skip";
		}
	}
 
	/**********************************************************************************************************
	 * @Objective: The below method is created to Get Date in Required Format
	 * @InputParameters: 
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :09-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	  
	    
	    public static String GetDateinRequiredFormat(String DateFormate)
		{
			LocalDateTime ldt = LocalDateTime.now();
			String Date =DateFormate.replace("DD", "dd");
			String Date1=Date.replace("MON", "MMM");
			String Coverteddate;
			switch (Date1) {
			  case "ddMMYY":
				Coverteddate = DateTimeFormatter.ofPattern("ddMMYY", Locale.ENGLISH).format(ldt);
			    break;
			  case "ddMMYYYY":
				  Coverteddate = DateTimeFormatter.ofPattern("ddMMYYYY", Locale.ENGLISH).format(ldt);
			    break;
			  case "ddMMMYY":
				  Coverteddate = DateTimeFormatter.ofPattern("ddMMMYY", Locale.ENGLISH).format(ldt);
			    break;
			  case "ddMMMYYYY":
				  Coverteddate = DateTimeFormatter.ofPattern("ddMMMYYYY", Locale.ENGLISH).format(ldt);
			    break;
			  case "MMddYY":
				  Coverteddate = DateTimeFormatter.ofPattern("MMddYY", Locale.ENGLISH).format(ldt);
			    break;
			  case "MMddYYYY":
				  Coverteddate = DateTimeFormatter.ofPattern("MMddYYYY", Locale.ENGLISH).format(ldt);
			    break;
			  case "MMMddYY":
				  Coverteddate = DateTimeFormatter.ofPattern("MMMddYY", Locale.ENGLISH).format(ldt);
			    break;
			  case "MMMddYYYY":
				  Coverteddate = DateTimeFormatter.ofPattern("MMMddYYYY", Locale.ENGLISH).format(ldt);
			    break;
			  case "YYYY":
				  Coverteddate = DateTimeFormatter.ofPattern("YYYY", Locale.ENGLISH).format(ldt);
			    break;
			  case "YYYYMMdd":
				  Coverteddate = DateTimeFormatter.ofPattern("YYYYMMdd", Locale.ENGLISH).format(ldt);
			    break; 
			  default:
				  Coverteddate = null;
			}
			return Coverteddate;
		}
	    /**********************************************************************************************************
		 * @Objective: This method is created get data from excel sheet
		 * @InputParameters:
		 * @OutputParameters:
		 * @author:Avinash k
		 * @Date : 09-July-2019
		 * @UpdatedByAndWhen:
		 **********************************************************************************************************/

		public static String getData(String scenarioName,String sheetName, String columnName) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
			return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
		}
		
		/**********************************************************************************************************
		 * @Objective: The below method is created to write HP ALM logs
		 * @InputParameters: Sheet name, Scenario Name, Column name array,Column titles array, actual value
		 * @OutputParameters:
		 * @author: Kishore and Vamsi
		 * @Date : 
		 * @UpdatedByAndWhen: 20-Feb-2021
		 **********************************************************************************************************/
		public static void ALMlogWriter(String sheetName, String scenarioName, String[] columnName, String[] columnTitles,String[] actVal) {
			String val="";
			if(Constants.ALMRun.equals("Yes")) {
				getTestData(lsmvConstants.LSMV_testData, sheetName);
				for (int name = 0; name < columnName.length; name++) {
					val=getTestDataCellValue(scenarioName, columnName[name]);
					if(val.contains(":")) {
						val=CommonOperations.returnDateTime(val);
						System.out.println(val);
					}
					if (!actVal[0].equalsIgnoreCase("#skip#")) {
						if(val.equalsIgnoreCase(actVal[name])) {
							Reports.ExtentReportLog("", Status.PASS, "<br />"+columnTitles[name]+": "+ val+" ", false);
						}
						else {
							Reports.ExtentReportLog("", Status.FAIL, "<br /> "+columnTitles[name]+" Exp value: "+val+"  and Act value-:"+actVal[name]+"  ", true);
						}
					}
					if (!val.equalsIgnoreCase("#skip#") && actVal[0].equalsIgnoreCase("#skip#")) {
						Reports.ExtentReportLog("", Status.PASS, "<br /> "+columnTitles[name]+": "+ val+" ", false);
					}
				}
				
			}else {
				Reports.ExtentReportLog("", Status.INFO,
						"operation in "+sheetName +"tab Case unit section: Scenario Name::" + scenarioName, true);
			}
	 
		}
		
	    
		}
	
	
	
	
	
	

