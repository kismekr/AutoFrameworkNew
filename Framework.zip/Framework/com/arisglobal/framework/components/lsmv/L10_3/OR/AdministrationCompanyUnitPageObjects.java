package com.arisglobal.framework.components.lsmv.L10_3.OR;

import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;

public class AdministrationCompanyUnitPageObjects extends ToolManager {

	public static String keywordSearchTextbox = "xpath#//input[@id='partnerForm:keyword']";
	public static String keywordSearchIcon = "xpath#//img[contains(@src,'search_icon')]";
	public static String newButton = "xpath#//a[@id='partnerForm:newId']";
	public static String deleteButton = "xpath#// a[@id='partnerForm:deleteId']";
	public static String companyUnitDetailsLink = "xpath#//a[@title='Company Unit Details']";
	public static String productsLink = "xpath#// a[@title='Products']";
	public static String exclusionMaskingLink = "xpath#// a[@title='Exclusion And Masking']";
	public static String generalLink = "xpath#// a[@title='General']";
	public static String workingDaysLink = "xpath#// a[@title='Working Days']";
	public static String transportSettingsLink = "xpath#// a[@title='Transport Settings']";
	public static String followupQueriesLink = "xpath#// a[@title='Follow-Up Queries Settings']"; 
	public static String saveButton = "xpath#// button[@id='partnerDetailsForm:visibleSave']";
	public static String cancelButton = "xpath#// button[@id='partnerDetailsForm:cancelId']";
	public static String unitCodeTextBox = "xpath#// input[@id='partnerDetailsForm:unitcode']";
	//public static String typeDropdown = "xpath#// div[@id='partnerDetailsForm:C1-9']";
	public static String typeDropdown = "xpath#// div[@id='partnerDetailsForm:C1-9']//div[@class='ui-selectonemenu-trigger ui-state-default ui-corner-right']";
	public static String buildingNoTextbox = "xpath#// input[@id='partnerDetailsForm:buildingNo']";
	public static String cityTextbox = "xpath#// input[@id='partnerDetailsForm:city']";
	public static String postCodeTextbox = "xpath#	// input[@id='partnerDetailsForm:postalBrick']";
	public static String extnTextbox = "xpath#// input[@id='partnerDetailsForm:postalCode']";
	public static String regionTextbox = "xpath#// input[@id='partnerDetailsForm:region']";
	public static String phoneCountryCodeTextbox = "xpath#// input[@id='partnerDetailsForm:pcountryCode']";
	public static String phoneAreaCodeTextbox = "xpath#// input[@id='partnerDetailsForm:pareaCode']";
	public static String phoneNumberTextbox = "xpath#// input[@id='partnerDetailsForm:pnumber']";
	public static String icsrDistContactYesRadio = "xpath#// table[@id='partnerDetailsForm:usertypeDistributionCntact']//label[contains(text(),'Yes')]";
	public static String icsrDistContactNoRadio = "xpath#// table[@id='partnerDetailsForm:usertypeDistributionCntact']//label[contains(text(),'No')]";
	public static String interChangeIDTextbox = "xpath#// input[@id='partnerDetailsForm:interchangeid']";
	public static String senderOrgTextbox = "xpath#// input[@id='partnerDetailsForm:senderOrgId']";
	public static String unitNameTextbox = "xpath#// input[@id='partnerDetailsForm:name']";
	public static String companyUnitTypeDropdown = "xpath#// div[@id='partnerDetailsForm:companyUnitType']";
	public static String streetAddressTextbox = "xpath#// input[@id='partnerDetailsForm:streetAdd']";
	public static String stateTextbox = "xpath#// input[@id='partnerDetailsForm:state']";
	//public static String countryDropdown = "xpath#// div[@id='partnerDetailsForm:C1-1015']";
	public static String countryDropdown = "xpath#// div[@id='partnerDetailsForm:C1-1015']//div[@class='ui-selectonemenu-trigger ui-state-default ui-corner-right']";
	public static String faxCountryCodeTextbox = "xpath#// input[@id='partnerDetailsForm:countryCode']";
	public static String faxAreaCodeTextbox = "xpath#// input[@id='partnerDetailsForm:areaCode']";
	public static String faxNumberTextbox = "xpath#// input[@id='partnerDetailsForm:number']";
	public static String emailIDTextbox = "xpath#// input[@id='partnerDetailsForm:emailID']";
	public static String icsrExchangePartnerYesRadio = "xpath#// table[@id='partnerDetailsForm:icsrpartner']//label[contains(text(),'Yes')]";
	public static String icsrExchangePartnerNoRadio = "xpath#// table[@id='partnerDetailsForm:icsrpartner']//label[contains(text(),'No')]";
	public static String dtdCorresDropdown = "xpath#// div[@id='partnerDetailsForm:DTDTypeSelectMenu']";
	public static String senderOrgTypeDropdown = "xpath#// div[@id='partnerDetailsForm:senderOrgTypeId']";

	// Submission Settings
	public static String submissionWorkflowDropdown = "xpath#//div[@id='partnerDetailsForm:submissionSelect']";

	// Complaint Settings
	public static String complaintWorkflowDropdown = "xpath#// div[@id='partnerDetailsForm:complaintSelect']";

	// Tracker Settings
	public static String receiptNoFormatTextbox = "xpath#// input[@id='partnerDetailsForm:receiptNumberingFormatId']";
	public static String receiptNoDateFomateDropdown = "xpath#//div[@id='partnerDetailsForm:I-5009']";
	public static String receiptNoDateSepDropdown = "xpath#//div[@id='partnerDetailsForm:dateSep']";
	public static String receiptNoResetSeqDropdown = "xpath#//div[@id='partnerDetailsForm:resetSequenceByMenu']";
	public static String lrnNoFormatTextbox = "xpath#// input[@id='partnerDetailsForm:lrnNumberingFormatId']";
	public static String lrnNoDateFormatDropdown = "xpath#//div[@id='partnerDetailsForm:I1-5009']";
	public static String lrnNoDateSepDropdown = "xpath#//div[@id='partnerDetailsForm:dateSep1']";
	public static String lrnNoResetSeqDropdown = "xpath#//div[@id='partnerDetailsForm:resetSequenceByMenu1']";
	public static String callLogNoFormatTextbox = "xpath#//input[@id='partnerDetailsForm:callLogNumberingFormatId']";
	public static String callLogDateFormatDropdown = "xpath#//div[@id='partnerDetailsForm:I3-5009']";
	public static String callLogDateSepDropdown = "xpath#//div[@id='partnerDetailsForm:dateSep3']";
	public static String callLogResetSeqDropdown = "xpath#//div[@id='partnerDetailsForm:resetSequenceByMenu2']";
	public static String aeWorkflowDropdown = "xpath#//div[@id='partnerDetailsForm:aeSelect']";
	public static String docBackuPathTextbox = "xpath#//input[@id='partnerDetailsForm:documentBackupPathIp']";

	// Company product corpus settings
	public static String uploadCompProdCorpusFileButton = "xpath#// input[@id='partnerDetailsForm:suspectfileupload_input']";

	// Case Due Date Calculation Configuration For Case Triage
	public static String ruleNameDropdown = "xpath#//label[@id='partnerDetailsForm:ctcaseDueDateDataTable:%rowNo%:ctruleNamecdd_label']";
	public static String dateDropdown = "xpath#//label[@id='partnerDetailsForm:ctcaseDueDateDataTable:%rowNo%:ctdueDatecdd_label']";
	public static String dueInDaysTextbox = "xpath#//input[@id='partnerDetailsForm:ctcaseDueDateDataTable:%rowNo%:ctdueDay']";

	public static String paginator = "xpath#//div[contains(@id,'DataTable_paginator_top')]/span[@class='ui-paginator-current']";
	public static String editIcon = "xpath#//img[contains(@id,'editIcon')]";

	// Department Lookup
	public static String departmentNameTextbox = "xpath#//input[@id='departmentLookupSearchForm:departmentName']";
	public static String deptEmailTextbox = "xpath#//input[@id='departmentLookupSearchForm:departmentEmailId']";
	public static String deptSearchButton = "xpath#//button[@id='departmentLookupSearchForm:findDept']";
	public static String deptClearButton = "xpath#//button[@id='departmentLookupSearchForm:clearGroupDept']";
	public static String deptOkButton = "xpath#//button[@id='departmentLookupSearchForm:okButtonbottom']";
	public static String deptCancelButton = "xpath#//button[@id='departmentLookupSearchForm:cancelButtonbottom']";
	public static String deptSearchResultsChkbox = "xpath#//tbody[contains(@id,'departmentLookUpData')]/descendant::span[contains(@class,'ui-chkbox-icon')]";
	

	// Department Grid
	public static String deptartmentNameLabel = "xpath#//tbody[@id='partnerDetailsForm:deptDataTable_data']/tr/td[2]/label[contains(@id,'partnerDetailsForm:deptDataTable:%rowNo%:')]";
	public static String contactPersonLabel = "xpath#//tbody[@id='partnerDetailsForm:deptDataTable_data']/tr/td[3]/label[contains(@id,'partnerDetailsForm:deptDataTable:%rowNo%:')]";
	public static String deptEmailLabel = "xpath#//tbody[@id='partnerDetailsForm:deptDataTable_data']/tr/td[4]/label[contains(@id,'partnerDetailsForm:deptDataTable:%rowNo%:')]";
	public static String corresMailServersLabel = "xpath#//tbody[@id='partnerDetailsForm:deptDataTable_data']/tr/td[5]/label[contains(@id,'partnerDetailsForm:deptDataTable:%rowNo%:')]";
	public static String defaultDataCheckbox = "xpath#//tbody[@id='partnerDetailsForm:deptDataTable_data']/tr/td[6]/label[contains(@id,'partnerDetailsForm:deptDataTable:%rowNo%:')]";
	public static String isE2BDeptCheckbox = "xpath#//tbody[@id='partnerDetailsForm:deptDataTable_data']/tr/td[7]/label[contains(@id,'partnerDetailsForm:deptDataTable:%rowNo%:')]";

	// Company Unit Grid
	public static String domainNameTextbox = "xpath#//input[@id='partnerDetailsForm:compUnitTable:%rowNo%:domNameTextInp']";
	public static String companyUnitDropdown = "xpath#//label[@id='partnerDetailsForm:compUnitTable:%rowNo%:compUnitList_label']";

	//TransposeSettings List Screen
	public static String edittransposesettingscu = "xpath#//img[@id='partnerDetailsForm:transportDataTable:0:editIcon']";
	
	//TrainsposeSettings Page
	public static String transportNameTextbox = "xpath#//label[@id='partnerDetailsForm:j_id_22s']//following::input[@id='partnerDetailsForm:transportName']";
	//public static String transportemailid = "xpath#//label[@id='partnerDetailsForm:j_id_23b']//following::input[@id='partnerDetailsForm:primaryEmailAddress']";
	//public static String transportmediumDropdown = "xpath#//div[@id='partnerDetailsForm:medium']//select[@id='partnerDetailsForm:medium_input']";
	public static String transportemailid = "xpath#//input[@id='partnerDetailsForm:primaryEmailAddress']";
	public static String transportmediumDropdown = "xpath#//div[@id='partnerDetailsForm:medium']//select[@id='partnerDetailsForm:medium_input']/option[@selected='selected']";
	
	// Contacts
	public static String contacts_Label = "Contacts";
	public static String contacts_Div =  "xpath#//div[@id= 'partnerDetailsForm:contactsPanel_header']/descendant::label[text()= 'Contacts']";
	public static String checkPrimary = "xpath#//tbody[contains(@id, 'partnerDetailsForm:contactsDataTable')]//label[contains(@id,'firstName')][text()='%s']//ancestor::td//preceding-sibling::td[2]//span";
	public static String interchangeIDTextbox= "xpath#//input[@id= 'partnerDetailsForm:contactsDataTable:%rowNo%:interchangeId']";
	public static String checkE2BContacts = "xpath#//tbody[contains(@id, 'partnerDetailsForm:contactsDataTable')]//label[contains(@id,'firstName')][text()='%s']//ancestor::td//following-sibling::td//div[contains(@id,'E2bContact')]//span";
	public static String checkDistribute = "xpath#//tbody[contains(@id, 'partnerDetailsForm:contactsDataTable')]//label[contains(@id,'firstName')][text()='%s']//ancestor::td//following-sibling::td//div[contains(@id,'accountDistribute')]//span";
	
	public static String sample(String par,String Par2) {
		return "//label[@id='"+par+"']//following::input[@id='"+Par2+"']";
	}
	

	public static void setPersonalDetails(String scenarioName) {
		agSetValue(sample(Multimaplibraries.getTestDataCellValue(scenarioName, "SearchText"), Multimaplibraries.getTestDataCellValue(scenarioName, "SearchText")), "test");
	}
}
