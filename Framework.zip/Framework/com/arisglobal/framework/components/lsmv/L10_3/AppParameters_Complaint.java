package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AppParameters_CallLogPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.AppParameters_CaseManagementPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.AppParameters_ComplaintPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.WorkFlowPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AppParameters_Complaint extends ToolManager {
	static String className = AppParameters_Complaint.class.getSimpleName();

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Complaint Details in Complaint
	 *             Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 17-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setComplaintDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_ComplaintPageObjects.complaintNumberingFormat_TextBox,
					getTestDataCellValue(scenarioName, "ComplaintNumberingFormat"));
			CommonOperations.setListDropDownValue(AppParameters_ComplaintPageObjects.complaintNumberingFormat1_DropDown,
					getTestDataCellValue(scenarioName, "ComplaintNumberingFormat1"));
			CommonOperations.setListDropDownValue(AppParameters_ComplaintPageObjects.complaintNumberingFormat2_DropDown,
					getTestDataCellValue(scenarioName, "ComplaintNumberingFormat2"));
			CommonOperations.setListDropDownValue(AppParameters_ComplaintPageObjects.complaintNumberingFormat3_DropDown,
					getTestDataCellValue(scenarioName, "ComplaintNumberingFormat3"));
			CommonOperations.setListDropDownValue(AppParameters_ComplaintPageObjects.complaintResetSequenceBy_DropDown,
					getTestDataCellValue(scenarioName, "ComplaintResetSequenceBy"));
			agSetValue(AppParameters_ComplaintPageObjects.recallsNumberingFormat_TextBox,
					getTestDataCellValue(scenarioName, "RecallsNumberingFormat"));
			CommonOperations.setListDropDownValue(AppParameters_ComplaintPageObjects.recallsNumberingFormat1_DropDown,
					getTestDataCellValue(scenarioName, "RecallsNumberingFormat1"));
			CommonOperations.setListDropDownValue(AppParameters_ComplaintPageObjects.recallsNumberingFormat2_DropDown,
					getTestDataCellValue(scenarioName, "RecallsNumberingFormat2"));
			CommonOperations.setListDropDownValue(AppParameters_ComplaintPageObjects.recallsNumberingFormat3_DropDown,
					getTestDataCellValue(scenarioName, "RecallsNumberingFormat3"));
			CommonOperations.setListDropDownValue(AppParameters_ComplaintPageObjects.recallResetSequenceBy_DropDown,
					getTestDataCellValue(scenarioName, "RecallResetSequenceBy"));
			agSetValue(AppParameters_ComplaintPageObjects.archiveComplaintsOlderThan_TextBox,
					getTestDataCellValue(scenarioName, "ArchiveComplaintsOlderThan"));
			CommonOperations.setListDropDownValue(
					AppParameters_ComplaintPageObjects.archiveComplaintsOlderThanUnit_DropDown,
					getTestDataCellValue(scenarioName, "ArchiveComplaintsOlderThanUnit"));
			agSetValue(AppParameters_ComplaintPageObjects.setEndDateforPreliminaryInvestigationByDays_TextBox,
					getTestDataCellValue(scenarioName, "SetEndDateforPreliminaryInvestigationByDays"));
			agSetValue(AppParameters_ComplaintPageObjects.setEndDateforInvestigationByDays_TextBox,
					getTestDataCellValue(scenarioName, "SetEndDateforInvestigationByDays"));
			CommonOperations.clickCheckBoxRightOf(AppParameters_ComplaintPageObjects.standardAEValidation_CheckBox,
					getTestDataCellValue(scenarioName, "StandardAEValidation"));
			agClick(AppParameters_CallLogPageObjects.EnableAutoSaveRadioBtn);
			agSetValue(AppParameters_ComplaintPageObjects.autoSaveComplaintinSec_TextBox,
					getTestDataCellValue(scenarioName, "AutoSaveComplaintinSec"));

			if(getTestDataCellValue(scenarioName, "ProductMandatoryforComplaint").equalsIgnoreCase("true")) {
				if(agIsVisible( AppParameters_ComplaintPageObjects.productMandatoryforComplaint_CheckBox)==true)
					{
					
					}else{
						
						CommonOperations.clickCheckBoxRightOf(AppParameters_ComplaintPageObjects.productMandatoryforComplaint_CheckBox,
								getTestDataCellValue(scenarioName, "ProductMandatoryforComplaint"));
				}
			}
			
			
			if(getTestDataCellValue(scenarioName, "EnableEditChecks").equalsIgnoreCase("true")) {
				if(agIsVisible( AppParameters_ComplaintPageObjects.enableEditChecks_CheckBox)==true)
					{
					
					}else{
						
						CommonOperations.clickCheckBoxRightOf(AppParameters_ComplaintPageObjects.enableEditChecks_CheckBox,
								getTestDataCellValue(scenarioName, "EnableEditChecks"));
				}
			}

			if(getTestDataCellValue(scenarioName, "DueDateCalculation").equalsIgnoreCase("true")) {
				if(agIsVisible( AppParameters_ComplaintPageObjects.dueDateCalculation_Radio)==true)
					{
					
					}else{
						
						CommonOperations.clickCheckBoxRightOf(AppParameters_ComplaintPageObjects.dueDateCalculation_Radio,
								getTestDataCellValue(scenarioName, "DueDateCalculation"));
				}
			}


			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Complaint >> Complaint Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Response Due Days Details in
	 *             Complaint Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 17-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setResponseDueDaysDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			CommonOperations.setListDropDownValue(AppParameters_ComplaintPageObjects.responseDueDays_DropDown,
					getTestDataCellValue(scenarioName, "ResponseDueDays"));
			if (getTestDataCellValue(scenarioName, "boolResponseDueDays_Add").equalsIgnoreCase("true")) {
				CommonOperations.clickAddDivOf(AppParameters_ComplaintPageObjects.responseDueDays_Label);
			}
			CommonOperations.setListDropDownValue(
					(AppParameters_ComplaintPageObjects.priority_DropDown).replace("%rowNO%",
							getTestDataCellValue(scenarioName, "PriorityRowNo")),
					getTestDataCellValue(scenarioName, "Priority"));
			agSetValue(
					(AppParameters_ComplaintPageObjects.priority_TextBox).replace("%rowNO%",
							getTestDataCellValue(scenarioName, "PriorityRowNo")),
					getTestDataCellValue(scenarioName, "PriorityText"));
			CommonOperations.setListDropDownValue(
					(AppParameters_ComplaintPageObjects.priorityUnit_DropDown).replace("%rowNO%",
							getTestDataCellValue(scenarioName, "PriorityRowNo")),
					getTestDataCellValue(scenarioName, "PriorityUnit"));

			agJavaScriptExecuctorScrollToElement(AppParameters_ComplaintPageObjects.responseDueDays_Div);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Complaint >> Response Due Days Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Complaint Details in
	 *             Complaint Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadComplaintDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			agClick(AppParameters_ComplaintPageObjects.complaintNumberingFormat_TextBox);
			String ComplaintNumberingFormat = agGetAttribute("value",
					AppParameters_ComplaintPageObjects.complaintNumberingFormat_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ComplaintNumberingFormat",
					ComplaintNumberingFormat);

			String ComplaintNumberingFormat1 = agGetText(
					AppParameters_ComplaintPageObjects.complaintNumberingFormat1_DropDown);
			if (ComplaintNumberingFormat1.contains("--Select--") || ComplaintNumberingFormat1.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ComplaintNumberingFormat1", "#skip#");
			} else {

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ComplaintNumberingFormat1", ComplaintNumberingFormat1);
			}
			String ComplaintNumberingFormat2 = agGetText(
					AppParameters_ComplaintPageObjects.complaintNumberingFormat2_DropDown);
			if (ComplaintNumberingFormat2.contains("--Select--") || ComplaintNumberingFormat2.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ComplaintNumberingFormat2", "#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ComplaintNumberingFormat2", ComplaintNumberingFormat2);
			}
			String ComplaintNumberingFormat3 = agGetText(
					AppParameters_ComplaintPageObjects.complaintNumberingFormat3_DropDown);
			if (ComplaintNumberingFormat3.contains("--Select--") || ComplaintNumberingFormat3.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ComplaintNumberingFormat3", "#skip#");
			} else {

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ComplaintNumberingFormat3", ComplaintNumberingFormat3);
			}
			String ComplaintResetSequenceBy = agGetText(
					AppParameters_ComplaintPageObjects.complaintNumberingFormat3_DropDown);
			if (ComplaintResetSequenceBy.contains("--Select--") || ComplaintResetSequenceBy.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ComplaintResetSequenceBy", "#skip#");
			} else {

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ComplaintResetSequenceBy", ComplaintResetSequenceBy);
			}
			agClick(AppParameters_ComplaintPageObjects.complaintResetSequenceBy_DropDown);
			String RecallsNumberingFormat = agGetAttribute("value",
					AppParameters_ComplaintPageObjects.complaintResetSequenceBy_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "RecallsNumberingFormat",
					RecallsNumberingFormat);

			String RecallsNumberingFormat1 = agGetText(
					AppParameters_ComplaintPageObjects.recallsNumberingFormat1_DropDown);
			if (RecallsNumberingFormat1.contains("--Select--") || RecallsNumberingFormat1.contains("Select")) {
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"RecallsNumberingFormat1", RecallsNumberingFormat1);
			}
			String RecallsNumberingFormat2 = agGetText(
					AppParameters_ComplaintPageObjects.recallsNumberingFormat2_DropDown);
			if (RecallsNumberingFormat2.contains("--Select--") || RecallsNumberingFormat2.contains("Select")) {
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"RecallsNumberingFormat2", RecallsNumberingFormat2);
			}

			String RecallsNumberingFormat3 = agGetText(
					AppParameters_ComplaintPageObjects.recallsNumberingFormat3_DropDown);
			if (RecallsNumberingFormat3.contains("--Select--") || RecallsNumberingFormat3.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"RecallsNumberingFormat3", "#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"RecallsNumberingFormat3", RecallsNumberingFormat3);
			}
			String RecallResetSequenceBy = agGetText(AppParameters_ComplaintPageObjects.recallResetSequenceBy_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "RecallResetSequenceBy",
					RecallResetSequenceBy);

			agClick(AppParameters_ComplaintPageObjects.archiveComplaintsOlderThan_TextBox);
			String ArchiveComplaintsOlderThan = agGetAttribute("value",
					AppParameters_ComplaintPageObjects.archiveComplaintsOlderThan_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"ArchiveComplaintsOlderThan", ArchiveComplaintsOlderThan);

			String ArchiveComplaintsOlderThanUnit = agGetText(
					AppParameters_ComplaintPageObjects.archiveComplaintsOlderThanUnit_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"ArchiveComplaintsOlderThanUnit", ArchiveComplaintsOlderThanUnit);

			agClick(AppParameters_ComplaintPageObjects.setEndDateforPreliminaryInvestigationByDays_TextBox);
			String SetEndDateforPreliminaryInvestigationByDays = agGetAttribute("value",
					AppParameters_ComplaintPageObjects.setEndDateforPreliminaryInvestigationByDays_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"SetEndDateforPreliminaryInvestigationByDays", SetEndDateforPreliminaryInvestigationByDays);

			agClick(AppParameters_ComplaintPageObjects.setEndDateforInvestigationByDays_TextBox);
			String SetEndDateforInvestigationByDays = agGetAttribute("value",
					AppParameters_ComplaintPageObjects.setEndDateforInvestigationByDays_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"SetEndDateforInvestigationByDays", SetEndDateforInvestigationByDays);
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_ComplaintPageObjects.standardAEValidation_CheckBox)) == true) {

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "StandardAEValidation",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "StandardAEValidation",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(AppParameters_ComplaintPageObjects.Yes)) == true) {

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "StandardAEValidation",
						"true");
				agClick(AppParameters_ComplaintPageObjects.autoSaveComplaintinSec_TextBox);
				String AutoSaveComplaintinSec = agGetAttribute("value",
						AppParameters_ComplaintPageObjects.autoSaveComplaintinSec_TextBox);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AutoSaveComplaintinSec", AutoSaveComplaintinSec);
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "StandardAEValidation",
						"false");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_ComplaintPageObjects.productMandatoryforComplaint_CheckBox)) == true) {

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ProductMandatoryforComplaint", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ProductMandatoryforComplaint", "false");
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_ComplaintPageObjects.enableEditChecks_CheckBox)) == true) {

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableEditChecks",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableEditChecks",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_ComplaintPageObjects.dueDateCalculation_Radio)) == true) {

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DueDateCalculation",
						"By Received Date");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DueDateCalculation",
						"By Entered Date");
			}

			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> Complaint >> Complaint Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data Entered in Application Parameters >> Complaint >> Complaint Section fails", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Response Due Days Details in
	 *             Complaint Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadResponseDueDaysDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			String ResponseDueDays = agGetText(AppParameters_ComplaintPageObjects.responseDueDays_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ResponseDueDays",
					ResponseDueDays);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Complaint >> Response Due Days Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data Entered inApplication Parameters >> Complaint >> Response Due Days Section fails", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set data in Complaint Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 17-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setAppParameters_ComplaintTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >>Complaint Tab Started",
				true);
		setComplaintDetails(scenarioName);
		setResponseDueDaysDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >>Complaint Tab Completed",
				true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read data in Complaint Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadAppParameters_ComplaintTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Read Data Entered in Application Parameters >>Complaint Tab Started",
				true);
		ReadComplaintDetails(scenarioName);
		ReadResponseDueDaysDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO,
				"Read Data Entered in Application Parameters >>Complaint Tab Completed", true);
	}
}
