package com.arisglobal.framework.components.lsmv.L10_3;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_1.FDE_Study;
import com.arisglobal.framework.components.lsmv.L10_3.OR.ANGPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_NarrativePageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.SeleniumActions;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.SystemTimeOperations;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_Narrative extends ToolManager {
	static String className = FDE_Narrative.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Narrative Event description
	 *             details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setNarrativeEventDescription(String scenarioName) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,
		// "ConfigurationSettings");
		// if (getTestDataCellValue(scenarioName,
		// "FDE_Narrative").equalsIgnoreCase("Yes")) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.rationaleLabel);
		if (agIsVisible(FDE_NarrativePageObjects.doNotUseANG_Checkbox) == true) {
			agClick(FDE_NarrativePageObjects.doNotUseANG_Checkbox);
		}
		agSetStepExecutionDelay("2000");
		agWaitTillVisibilityOfElement(FDE_NarrativePageObjects.eventDescription_Textarea);
		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.eventDescription_Textarea);
		agSetValue(FDE_NarrativePageObjects.eventDescription_Textarea,
				getTestDataCellValue(scenarioName, "Narrative_EventDescription"));
		agSendKeyStroke(Keys.TAB);

		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Narrative >> Event Description Section : Scenario Name::" + scenarioName, true);
		// }

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Narrative Event description
	 *             details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyNarrativeEventDescription(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.eventDescription_Textarea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Narrative_EventDescription"),
				FDE_NarrativePageObjects.eventDescription_Textarea);

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Narrative >> Event Description Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Case Narrative details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCaseNarrative(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FDE_NarrativePageObjects.additionalComments_Textarea,
				getTestDataCellValue(scenarioName, "Narrative_CaseNarratives_AdditionalComments"));
		agSetValue(FDE_NarrativePageObjects.additionalManufacturerNarrative_Textarea,
				getTestDataCellValue(scenarioName, "Narrative_CaseNarratives_AdditionalManufacturerNarrative"));
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Narrative >> Case Narratives >> Additional Comments and Additional Manufacturer Narrative Section : Scenario Name::"
						+ scenarioName,
				true);

		agSetValue(FDE_NarrativePageObjects.correctedData_Textarea,
				getTestDataCellValue(scenarioName, "Narrative_CaseNarratives_CorrectedData"));
		agSetValue(FDE_NarrativePageObjects.evaluationSummary_Textarea,
				getTestDataCellValue(scenarioName, "Narrative_CaseNarratives_EvaluationSummary"));
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Narrative >> Case Narratives >> Corrected Data and Evaluation Summary Section : Scenario Name::"
						+ scenarioName,
				true);

		agSetValue(FDE_NarrativePageObjects.reactionDescriptionAsPerReporter_Textarea,
				getTestDataCellValue(scenarioName, "Narrative_CaseNarratives_ReactionDescriptionAsPerReporter"));
		agSetValue(FDE_NarrativePageObjects.companyRemarks_Textarea,
				getTestDataCellValue(scenarioName, "Narrative_CaseNarratives_CompanyRemarksSendersComments"));
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Narrative >> Case Narratives >> Reaction Description as per Reporter and Company Remarks (Sender's Comments) Section : Scenario Name::"
						+ scenarioName,
				true);

		agSetValue(FDE_NarrativePageObjects.summaryDescription_Textarea,
				getTestDataCellValue(scenarioName, "Narrative_CaseNarratives_SummaryDescription"));
		agSetValue(FDE_NarrativePageObjects.pharmacovigilanceComments_Textarea,
				getTestDataCellValue(scenarioName, "Narrative_CaseNarratives_PharmacovigilanceComments"));
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Narrative >> Case Narratives >> Summary Description and Pharmacovigilance Comments Section : Scenario Name::"
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Case Narrative details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCaseNarrative(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.additionalComments_Textarea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Narrative_CaseNarratives_AdditionalComments"),
				FDE_NarrativePageObjects.additionalComments_Textarea);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Narrative_CaseNarratives_AdditionalManufacturerNarrative"),
				FDE_NarrativePageObjects.additionalManufacturerNarrative_Textarea);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Narrative >> Case Narratives >> Additional Comments and Additional Manufacturer Narrative Section : Scenario Name::"
						+ scenarioName,
				true);

		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.correctedData_Textarea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Narrative_CaseNarratives_CorrectedData"),
				FDE_NarrativePageObjects.correctedData_Textarea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Narrative_CaseNarratives_EvaluationSummary"),
				FDE_NarrativePageObjects.evaluationSummary_Textarea);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Narrative >> Case Narratives >> Corrected Data and Evaluation Summary Section : Scenario Name::"
						+ scenarioName,
				true);

		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.reactionDescriptionAsPerReporter_Textarea);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Narrative_CaseNarratives_ReactionDescriptionAsPerReporter"),
				FDE_NarrativePageObjects.reactionDescriptionAsPerReporter_Textarea);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Narrative_CaseNarratives_CompanyRemarksSendersComments"),
				FDE_NarrativePageObjects.companyRemarks_Textarea);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Narrative >> Case Narratives >> Reaction Description as per Reporter and Company Remarks (Sender's Comments) Section : Scenario Name::"
						+ scenarioName,
				true);

		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.summaryDescription_Textarea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Narrative_CaseNarratives_SummaryDescription"),
				FDE_NarrativePageObjects.summaryDescription_Textarea);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Narrative_CaseNarratives_PharmacovigilanceComments"),
				FDE_NarrativePageObjects.pharmacovigilanceComments_Textarea);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Narrative >> Case Narratives >> Summary Description and Pharmacovigilance Comments Section : Scenario Name::"
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Case Summary and Reporters
	 *             Comments
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCaseSummaryandReportersComments(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FDE_NarrativePageObjects.caseSummaryAndReportersCommentsText_Textarea,
				getTestDataCellValue(scenarioName, "Narrative_CaseSummaryandRepCom_CaseSummaryAndRepComText"));
		CommonOperations.setFDEDropDownValue(FDE_NarrativePageObjects.caseSummaryAndReportersCommentsLanguage_DropDown,
				getTestDataCellValue(scenarioName, "Narrative_CaseSummaryReportersComments_CaseSumAndRepComLang"));
		agSetStepExecutionDelay("1000");

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Narrative >> Case Summary and Reporters Comments Section : Scenario Name::"
						+ scenarioName,
				true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Case Summary and Reporters
	 *             Comments
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCaseSummaryandReportersComments(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Narrative_CaseSummaryandRepCom_CaseSummaryAndRepComText"),
				FDE_NarrativePageObjects.caseSummaryAndReportersCommentsText_Textarea);
		CommonOperations.verifyFDEDropDownValue(
				FDE_NarrativePageObjects.caseSummaryAndReportersCommentsLanguage_DropDown,
				getTestDataCellValue(scenarioName, "Narrative_CaseSummaryReportersComments_CaseSumAndRepComLang"));

		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.caseSummaryAndReportersCommentsText_Textarea);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Narrative >> Case Summary and Reporters Comments Section : Scenario Name::"
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Sender Diagnosis
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSenderDiagnosis(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Narrative_SenderDiagnosis_SenderDiagMedDRALLTCode_Lookup")
				.equalsIgnoreCase("true")) {
			agClick(FDE_NarrativePageObjects.senderDiagnosisMedDRALLTCode_Lookup);
			agSetValue(FDE_NarrativePageObjects.searchTermLookUpTextbox,
					getTestDataCellValue(scenarioName, "Narrative_SenderDiagnosis_SendDiagMedDRALLTCode_SearchTerm"));
			agClick(FDE_NarrativePageObjects.searchTermLookUpBtn);
			agSetStepExecutionDelay("2000");
			Reports.ExtentReportLog("", Status.INFO,
					"Data Seleted in Narrative >> Sender Diagnosis >> Dictionary Coding Browser LookUp Window : Scenario Name::"
							+ scenarioName,
					true);
			agClick(FDE_NarrativePageObjects.termOkBtn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} else {
			agSetValue(FDE_NarrativePageObjects.senderDiagnosisTerm_Textbox,
					getTestDataCellValue(scenarioName, "Narrative_SenderDiagnosis_SenderDiagnosisTerm"));
			agSendKeyStroke(Keys.TAB);
			// agClick(FDE_NarrativePageObjects.medDRALLTCodesuggestionItem);
			// agSetStepExecutionDelay("2000");
			if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
				CommonOperations.captureScreenShot(true);
			}
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Narrative >> Sender Diagnosis Section : Scenario Name::" + scenarioName, true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Sender Diagnosis
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySenderDiagnosis(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_NarrativePageObjects.senderDiagnosisTerm_Textbox);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Narrative_SenderDiagnosis_SenderDiagnosisTerm"),
				FDE_NarrativePageObjects.senderDiagnosisTerm_Textbox);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Narrative_SenderDiagnosis_SenderDiagnosisMedDRALLTCode"),
				FDE_NarrativePageObjects.senderDiagnosisMedDRALLTCode_Textbox);
		agClick(FDE_NarrativePageObjects.senderDiagnosisMedDRAPTCode_Textbox);
		agCheckPropertyValue("title",
				getTestDataCellValue(scenarioName, "Narrative_SenderDiagnosis_SenderDiagnosisMedDRAPTCode"),
				FDE_NarrativePageObjects.senderDiagnosisMedDRAPTCode_Textbox);
		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.senderDiagnosisTerm_Textbox);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Narrative >> Sender Diagnosis Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Remarks
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setRemarks(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("1000");
		agSetValue(FDE_NarrativePageObjects.remarks1Textarea,
				getTestDataCellValue(scenarioName, "Narrative_SenderDiagnosis_Remarks1"));
		agSetValue(FDE_NarrativePageObjects.remarks2Textarea,
				getTestDataCellValue(scenarioName, "Narrative_SenderDiagnosis_Remarks2"));
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Narrative >> Remarks 1 and Remarks 2  Section : Scenario Name::" + scenarioName, true);

		agSetValue(FDE_NarrativePageObjects.remarks3Textarea,
				getTestDataCellValue(scenarioName, "Narrative_SenderDiagnosis_Remarks3"));
		agSetValue(FDE_NarrativePageObjects.remarks4Textarea,
				getTestDataCellValue(scenarioName, "Narrative_SenderDiagnosis_Remarks4"));
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Narrative >> Remarks 3 and Remarks 4  Section : Scenario Name::" + scenarioName, true);

		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is verify Remarks
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyRemarks(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.remarks1Textarea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Narrative_SenderDiagnosis_Remarks1"),
				FDE_NarrativePageObjects.remarks1Textarea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Narrative_SenderDiagnosis_Remarks2"),
				FDE_NarrativePageObjects.remarks2Textarea);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Narrative >> Remarks 1 and Remarks 2  Section : Scenario Name::" + scenarioName,
				true);

		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.remarks3Textarea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Narrative_SenderDiagnosis_Remarks3"),
				FDE_NarrativePageObjects.remarks3Textarea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Narrative_SenderDiagnosis_Remarks4"),
				FDE_NarrativePageObjects.remarks4Textarea);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Narrative >> Remarks 3 and Remarks 4  Section : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Narrative data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setNarrativeData(String scenarioName) {
		setNarrativeEventDescription(scenarioName);
		setCaseNarrative(scenarioName);
		setCaseSummaryandReportersComments(scenarioName);
		setSenderDiagnosis(scenarioName);
		// setRemarks(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Narrative data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 03-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyNarrativeData(String scenarioName) {
		verifyNarrativeEventDescription(scenarioName);
		verifyCaseNarrative(scenarioName);
		verifyCaseSummaryandReportersComments(scenarioName);
		verifySenderDiagnosis(scenarioName);
		verifyRemarks(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: To set test value for additional comment text area
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 17-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCaseNarrative() {
		String timeStamp = SystemTimeOperations.getCurrentTime();
		agSetValue(FDE_NarrativePageObjects.additionalComments_Textarea,
				"Update Narrative test automation: " + timeStamp);

	}

	/**********************************************************************************************************
	 * @Objective: Verify R2 tags in Narrative tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyNarrativeR2Tags() {
		Reports.ExtentReportLog("", Status.INFO, "********Narrative R2 tag verification Started*******", true);
		agAssertVisible(FDE_NarrativePageObjects.R2EventDescription);
		agAssertVisible(FDE_NarrativePageObjects.R2ReactionDescriptionAsPerReporter);
		agAssertVisible(FDE_NarrativePageObjects.R2CompanyRemarks_SenderComments);
		agAssertVisible(FDE_NarrativePageObjects.R2SenderDiagnosisTerm);
		Reports.ExtentReportLog("", Status.INFO, "********Narrative R2 tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify R3 tags in Narrative tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyNarrativeR3Tags() {
		Reports.ExtentReportLog("", Status.INFO, "********Narrative R3 tag verification Started*******", true);
		agAssertVisible(FDE_NarrativePageObjects.R3EventDescription);
		agAssertVisible(FDE_NarrativePageObjects.R3ReactionDescriptionAsPerReporter);
		agAssertVisible(FDE_NarrativePageObjects.R3CompanyRemarks_SenderComments);
		agAssertVisible(FDE_NarrativePageObjects.R3CaseSummaryAndReportersCommentsText);
		agAssertVisible(FDE_NarrativePageObjects.R3CaseSummaryAndReportersCommentsLanguage);
		agAssertVisible(FDE_NarrativePageObjects.R3SenderDiagnosisMedDRALLTCode);
		Reports.ExtentReportLog("", Status.INFO, "********Narrative R3 tag verification ompleted*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify Codelist tags in Narrative tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyNarrativeCodeList() {
		Reports.ExtentReportLog("", Status.INFO, "********Narrative Codelist tag verification Started*******", true);
		agAssertVisible(FDE_NarrativePageObjects.CLCaseSummaryAndReportersCommentsLanguage);
		Reports.ExtentReportLog("", Status.INFO, "********Narrative Codelist tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: To verify that Event Description is auto generated and matches
	 *             with the Case Data
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 09-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String verifyAutoGeneratedEventDescription(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.eventDescription_Textarea);
		String autoGeneratedEventDescription = null;

		WebElement element = null;
		try {
			if (FDE_NarrativePageObjects.eventDescription_Textarea.indexOf("#//") > 0
					|| FDE_NarrativePageObjects.eventDescription_Textarea.indexOf("#(//") > 0) {
				element = SeleniumActions.findElement(Constants.driver,
						FDE_NarrativePageObjects.eventDescription_Textarea);
				autoGeneratedEventDescription = element.getAttribute("value");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if (!(autoGeneratedEventDescription.isEmpty())) {
			Reports.ExtentReportLog("", Status.PASS, "Event/Narrative Description is Auto Generated", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Event/Narrative Description is Not Generated, Null value retrieved", true);
		}

		return autoGeneratedEventDescription;
	}
	
	/**********************************************************************************************************
	 * @Objective: To verify that Event Description is auto generated and matches
	 *             with the Case Data
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 09-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String verifyAutoGeneratedEventDescription(String scenarioName,String workFlowEDStatus) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.eventDescription_Textarea);
		String autoGeneratedEventDescription = null;

		WebElement element = null;
		element = SeleniumActions.findElement(Constants.driver,
				FDE_NarrativePageObjects.eventDescription_Textarea);
		autoGeneratedEventDescription = element.getAttribute("value");
//		try {
//			if (FDE_NarrativePageObjects.eventDescription_Textarea.indexOf("#//") > 0
//					|| FDE_NarrativePageObjects.eventDescription_Textarea.indexOf("#(//") > 0) {
//				element = SeleniumActions.findElement(Constants.driver,
//						FDE_NarrativePageObjects.eventDescription_Textarea);
//				autoGeneratedEventDescription = element.getAttribute("value");
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}

		if (!(autoGeneratedEventDescription.isEmpty())&(workFlowEDStatus.equalsIgnoreCase("check"))==true) {
			Reports.ExtentReportLog("", Status.PASS, "Event/Narrative Description is Auto Generated", true);
		} else if((autoGeneratedEventDescription.isEmpty())&(workFlowEDStatus.equalsIgnoreCase("uncheck")==true)){
			Reports.ExtentReportLog("", Status.PASS, "Event/Narrative Description unchecked in work flow and not populated", true);
		}else {
			Reports.ExtentReportLog("", Status.FAIL,"Event/Narrative Description is Not Generated, Null value retrieved", true);
		}
		
		return autoGeneratedEventDescription;
		
	}

	/**********************************************************************************************************
	 * @Objective: To verify that Event Description is auto generated and matches
	 *             with the Case Data
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 09-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCaseDataInEventDescription(String eventDescription, String sheetName, String scenarioName,
			String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.eventDescription_Textarea);

		String caseDataVal = getTestDataCellValue(scenarioName, columnName);

		
		if (eventDescription.contains(caseDataVal)) {
			Reports.ExtentReportLog("", Status.PASS, "Event/Narrative Description has expected Case , '" + columnName
					+ " Data " + caseDataVal + "' in the auto generated Event/Narrative Description", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Event/Narrative Description does not have the expected Case",
					true);
		}

	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to check checkbox right of specified label.
	 * @InputParameters: boolCheck
	 * @OutputParameters:NA
	 * @author: Shamanth
	 * @Date : 16-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickCheckBoxRightOf(String boolCheck) {
		if (!boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = null;
			checkBoxStatus = ToolManager.agGetAttribute("class", FDE_NarrativePageObjects.showNonEditableTextsCheckBox);
			if (checkBoxStatus.contains("blank")) {
				checkBoxStatus = "false";
			} else {
				checkBoxStatus = "true";
			}
			if ((boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check"))
					&& checkBoxStatus.equalsIgnoreCase("false")) {
				ToolManager.agClick(FDE_NarrativePageObjects.showNonEditableTextsCheckBox);
			} else if ((boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck"))
					&& checkBoxStatus.equalsIgnoreCase("true")) {
				ToolManager.agClick(FDE_NarrativePageObjects.showNonEditableTextsCheckBox);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: To verify content of the generated Narrative
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyClinicalTrialEditableEventDes(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.eventDescription_Textarea);

		try {
			agWaitTillVisibilityOfElement(FDE_NarrativePageObjects.editANG_btn);
			agClick(FDE_NarrativePageObjects.editANG_btn);
			int i = 0, sz = agGetWindowCount();
			agSetStepExecutionDelay("5000");
			while (!(sz == 2) && i < 75) {
				sz = agGetWindowCount();
				i++;
				System.out.println("Waiting" + i);
			}
			// switching the driver control to Context View window
			agGetCurrentWindow();
			agSetStepExecutionDelay("3000");

			agWaitTillVisibilityOfElement(FDE_NarrativePageObjects.contextViewANG_btn);
			clickCheckBoxRightOf("false");
			Reports.ExtentReportLog("", Status.PASS, "Selected the Check box", true);
			System.out.println("Waiting after check box showNonEditableTexts_CheckBx selection");

			String rgbColorCodeExpected = "rgba(0, 0, 0, 1)";
			String cssAttribute = "color";
			assessColorCode(
					FDE_NarrativePageObjects.narrativeTextLocatorBuilder(
							FDE_General.getData(scenarioName, "Gen_CaseSpecificInformation_PrimarySourceCountry")),
					rgbColorCodeExpected, cssAttribute);
			assessColorCode(
					FDE_NarrativePageObjects.narrativeTextLocatorBuilder(
							FDE_Patient.getData(scenarioName, "Patient_PatientIdentifiers_Gender")),
					rgbColorCodeExpected, cssAttribute);
			assessColorCode(
					FDE_NarrativePageObjects
							.narrativeTextLocatorBuilder(FDE_Study.getData(scenarioName, "Study_StudyLookup_StudyNo")),
					rgbColorCodeExpected, cssAttribute);
			assessColorCode(
					FDE_NarrativePageObjects.narrativeTextLocatorBuilder(
							FDE_Study.getData(scenarioName, "Study_StudyInformation_StudyType")),
					rgbColorCodeExpected, cssAttribute);
			assessColorCode(
					FDE_NarrativePageObjects.narrativeTextLocatorBuilder(
							FDE_Study.getData(scenarioName, "Study_StudyInformation_StudyPhase")),
					rgbColorCodeExpected, cssAttribute);
			assessColorCode(
					FDE_NarrativePageObjects.narrativeTextLocatorBuilder(
							FDE_Events.getData(scenarioName, "Events_EventInformation_ReportedTerm")),
					rgbColorCodeExpected, cssAttribute);

			agSetStepExecutionDelay("15000");

			System.out.println("before check box showNonEditableTexts_CheckBx deselect");
			CommonOperations.clickCheckBoxRightOf(FDE_NarrativePageObjects.showNonEditableTexts_CheckBx, "false");
			agSetStepExecutionDelay("3000");
			Reports.ExtentReportLog("", Status.PASS, "Deselected the Check box", true);
			agClick(FDE_NarrativePageObjects.OK_Btn);

			// switching the driver control back to main window
			agGetWindowControlByInstance(1);

		} catch (Exception e) {
			Reports.ExtentReportLog("", Status.FAIL, "Failed to operate on ANG - Event Description Data", true);
			e.printStackTrace();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to get CSS value - Font color of the
	 *             particular element.
	 * @InputParameters: locator
	 * @OutputParameters: rgb color notation
	 * @author: Shamanth S
	 * @Date : 12-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void assessColorCode(String locator, String rgbColorCode, String cssAttribute) {
		String textColorCode = null;

		try {
			if (locator.indexOf("#//") > 0 || locator.indexOf("#(//") > 0) {
				textColorCode = SeleniumActions.findElement(Constants.driver, locator).getCssValue(cssAttribute);
				System.out.println("textColorCode: " + textColorCode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (textColorCode.equalsIgnoreCase(rgbColorCode)) {
			Reports.ExtentReportLog("", Status.PASS, "Color code matches the expected value, " + rgbColorCode + ".",
					true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Color code does not matches the expected value, " + rgbColorCode + ".", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: To verify content of the generated Narrative
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 12-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateAndVerifyANGText(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.eventDescription_Textarea);

		try {

			openANGEditWindow();
			if (agIsVisible(ANGPageObjects.AutoNarrative) == true) {
				agClick(ANGPageObjects.NonEditableTextBox);
				ArrayList<String> NonEditable = ANGOperations.GetNonEditableContext();
				int NEcount = NonEditable.size();
				System.out.println("NEcount: " + NEcount);
				ArrayList<String> Editable = ANGOperations.GetEditableContext();
				int Ecount = Editable.size();
				System.out.println("Ecount: " + Ecount);

				for (int i = 1; i < Ecount; i++) {
					String EditableText = Editable.get(i);
					int Space = ' ';
					int comma = ',';
					int stop = '.';

					if (EditableText.equalsIgnoreCase(Integer.toString(Space))
							|| EditableText.equalsIgnoreCase(Integer.toString(Space))
							|| EditableText.equalsIgnoreCase(Integer.toString(stop))) {
						Reports.ExtentReportLog("", Status.INFO, "Delimeters", true);
					} else {
						agSetStepExecutionDelay("3000");
						agClick(ANGPageObjects.Edit(String.valueOf(i)));
						// agClearText(ANGPageObjects.Edit(String.valueOf(i)));

						agSetValue(ANGPageObjects.Edit(String.valueOf(i)), "Update-ANG-Data");
						Reports.ExtentReportLog("", Status.INFO, "ANG Data Updated", true);
						agClick(ANGPageObjects.okBtn);
						// agClick(FullDataEntryFormPageObjects.SaveButton);
						// agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
						// agClick(FullDataEntryFormPageObjects.saveOkButton);

						// switching the driver control back to main window
						agGetWindowControlByInstance(1);
						agSetStepExecutionDelay("3000");

						// saving the changes
						agSetStepExecutionDelay("5000");
						agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.SaveButton);
						// FDE_Operations.resolveValidation();
						if (agIsVisible(CommonPageObjects.auditInfo_Label) == true) {
							CommonOperations.handelAuditInfo(scenarioName);
						}
						agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
						agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);

						agSetStepExecutionDelay("3000");
						agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.eventDescription_Textarea);

						String EventDescription = null;

						WebElement element = null;
						try {
							if (FDE_NarrativePageObjects.eventDescription_Textarea.indexOf("#//") > 0
									|| FDE_NarrativePageObjects.eventDescription_Textarea.indexOf("#(//") > 0) {
								element = SeleniumActions.findElement(Constants.driver,
										FDE_NarrativePageObjects.eventDescription_Textarea);
								EventDescription = element.getAttribute("value");
							}
						} catch (Exception e) {
							Reports.ExtentReportLog("", Status.FAIL, "Failed to identify ANG Event Description field",
									true);
							e.printStackTrace();
						}

						if (EventDescription.contains("Update-ANG-Data")) {
							Reports.ExtentReportLog("", Status.PASS,
									"ANG Data Verified in Event Description TextBox. Description is updated successfully",
									true);

							// Verifying the log
							openANGEditWindow();
							agWaitTillInvisibilityOfElement(FDE_NarrativePageObjects.bannerTag_icon);

							agClick(FDE_NarrativePageObjects.bannerTag_icon);
							agWaitTillInvisibilityOfElement(FDE_NarrativePageObjects.changeLog_Label);
							List<WebElement> logRecords = agGetElementList(
									FDE_NarrativePageObjects.tableRecords_MultiElements);

							if (logRecords.size() > 1) {
								Reports.ExtentReportLog("", Status.PASS,
										"Auto Generated Narrative text is updated " + logRecords.size()
												+ " times. Details Recorded in Change Log table successfully",
										true);
							} else if (logRecords.size() == 1) {
								Reports.ExtentReportLog("", Status.FAIL,
										"Auto Generated Narrative text CHANGE LOG is not updated", true);
							}
							
							if (agIsVisible(FDE_NarrativePageObjects.OK_Btn)) {
								agClick(FDE_NarrativePageObjects.OK_Btn);
							}							

							// switching the driver control back to main window
							agGetWindowControlByInstance(1);
							agSetStepExecutionDelay("3000");
						} else {
							Reports.ExtentReportLog("", Status.FAIL,
									"ANG Data not Verified in Event Description TextBox", true);
						}
						agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
						break;
					}
				}
			} else {
				Reports.ExtentReportLog("", Status.INFO, "Context view not Displayed", true);
			}

		} catch (Exception e) {
			Reports.ExtentReportLog("", Status.FAIL, "Failed to update ANG - Event Description content", true);
			e.printStackTrace();
		}
	}

	/**********************************************************************************************************
	 * @Objective: To verify content of the generated Narrative
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 12-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void openANGEditWindow() {

		agWaitTillVisibilityOfElement(FDE_NarrativePageObjects.editANG_btn);
		agClick(FDE_NarrativePageObjects.editANG_btn);
		int k = 0, sz = agGetWindowCount();
		agSetStepExecutionDelay("5000");
		while (!(sz == 2) && k < 75) {
			sz = agGetWindowCount();
			k++;
			System.out.println("Waiting" + k);
		}
		// switching the driver control to Context View window
		agGetCurrentWindow();
		agSetStepExecutionDelay("3000");

		if (agIsVisible(ANGPageObjects.AutoNarrative) == true) {
			Reports.ExtentReportLog("", Status.INFO, "Context is displayed in AutoNarrative Section", true);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Context View not displayed", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: To verify user is able to get the default template statements
	 *             after all manual changes
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 13-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyANGRegenerationAfterEventDescUpdate(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.eventDescription_Textarea);
		String autoGeneratedEventDescription = null;
		WebElement element = null;

		try {
			if (FDE_NarrativePageObjects.eventDescription_Textarea.indexOf("#//") > 0
					|| FDE_NarrativePageObjects.eventDescription_Textarea.indexOf("#(//") > 0) {
				element = SeleniumActions.findElement(Constants.driver,
						FDE_NarrativePageObjects.eventDescription_Textarea);
				autoGeneratedEventDescription = element.getAttribute("value");

				if (autoGeneratedEventDescription.contains("Update-ANG-Data")) {
					Reports.ExtentReportLog("", Status.INFO,
							"Event Description is updated. Default Template is altered.", true);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		openANGEditWindow();
		agWaitTillVisibilityOfElement(FDE_NarrativePageObjects.contextViewANG_btn);
		if (agIsVisible(FDE_NarrativePageObjects.contextViewANG_btn) == true) {
			agWaitTillVisibilityOfElement(FDE_NarrativePageObjects.regenerate_Btn);
			agClick(FDE_NarrativePageObjects.regenerate_Btn);

			if (agIsExists(FDE_NarrativePageObjects.regenerateConfirmation_Title)) {
				agClick(FDE_NarrativePageObjects.regenerateConfirmYes_Btn);
			}

			agWaitTillVisibilityOfElement(FDE_NarrativePageObjects.OK_Btn);
			agClick(FDE_NarrativePageObjects.OK_Btn);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Context view not Displayed", true);
		}
		// switching the driver control back to main window
		agGetWindowControlByInstance(1);
		agSetStepExecutionDelay("3000");

		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.eventDescription_Textarea);
		try {
			if (FDE_NarrativePageObjects.eventDescription_Textarea.indexOf("#//") > 0
					|| FDE_NarrativePageObjects.eventDescription_Textarea.indexOf("#(//") > 0) {
				element = SeleniumActions.findElement(Constants.driver,
						FDE_NarrativePageObjects.eventDescription_Textarea);
				autoGeneratedEventDescription = element.getAttribute("value");

				if (!(autoGeneratedEventDescription.contains("Update-ANG-Data"))) {
					Reports.ExtentReportLog("", Status.PASS,
							"Event Description is Regenerated. Default Template is restored.", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL,
							"Event Description is not Regenerated. Default Template is not restored.", true);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**********************************************************************************************************
	 * @Objective: To verify user is able to get the default template statements
	 *             after all manual changes
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 13-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyANGContextHighlighter(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.eventDescription_Textarea);
		openANGEditWindow();
		agWaitTillVisibilityOfElement(FDE_NarrativePageObjects.contextViewANG_btn);
		if (agIsVisible(FDE_NarrativePageObjects.contextViewANG_btn) == true) {
			agClick(FDE_NarrativePageObjects.contextTreeNode_LeadStmnt);
			String cssAttribute = "background-color";
			// assessColorCode(FDE_NarrativePageObjects.evetDesc_LeadStmnt, "rgba(182, 255,
			// 182, 1)", cssAttribute);

			agClick(FDE_NarrativePageObjects.contextTreeNode_LastRecvdDt);
			assessColorCode(FDE_NarrativePageObjects.evetDesc_LastRecvdDt, "rgba(182, 255, 182, 1)", cssAttribute);
		}

		// switching the driver control back to main window
		agGetWindowControlByInstance(1);
		agSetStepExecutionDelay("3000");

	}

	/**********************************************************************************************************
	 * @Objective: To regenerate the Event Description
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void regenerateEventDescription(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.eventDescription_Textarea);
		openANGEditWindow();
		agWaitTillVisibilityOfElement(FDE_NarrativePageObjects.contextViewANG_btn);
		if (agIsVisible(FDE_NarrativePageObjects.contextViewANG_btn) == true) {
			agWaitTillVisibilityOfElement(FDE_NarrativePageObjects.regenerate_Btn);
			agClick(FDE_NarrativePageObjects.regenerate_Btn);

			if (agIsExists(FDE_NarrativePageObjects.regenerateConfirmation_Title)) {
				agClick(FDE_NarrativePageObjects.regenerateConfirmYes_Btn);
			}

			agWaitTillVisibilityOfElement(FDE_NarrativePageObjects.OK_Btn);
			agClick(FDE_NarrativePageObjects.OK_Btn);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Context view not Displayed", true);
		}
		// switching the driver control back to main window
		agGetWindowControlByInstance(1);
		agSetStepExecutionDelay("3000");

		agJavaScriptExecuctorScrollToElement(FDE_NarrativePageObjects.eventDescription_Textarea);
	}

	/**********************************************************************************************************
	 * @Objective: To reconcile the auto generated Event Description
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 09-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDataExistence(String scenarioName, String sheetName, String colName,
			boolean toBeAvailable) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		String autoGeneratedEventDescription = null;
		String testVal = getTestDataCellValue(scenarioName, colName);
		WebElement element = null;
		try {
			if (FDE_NarrativePageObjects.eventDescription_Textarea.indexOf("#//") > 0
					|| FDE_NarrativePageObjects.eventDescription_Textarea.indexOf("#(//") > 0) {
				element = SeleniumActions.findElement(Constants.driver,
						FDE_NarrativePageObjects.eventDescription_Textarea);
				autoGeneratedEventDescription = element.getAttribute("value");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (Boolean.compare(autoGeneratedEventDescription.contains(testVal), toBeAvailable) == 0) {
			Reports.ExtentReportLog("", Status.PASS, "Data existence is as expected, " + toBeAvailable + ".", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Data existence is not as expected, " + toBeAvailable + ".", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method created to get the text of event description
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String eventDescription() {
		String res = null;
		agClick(FDE_NarrativePageObjects.eventDescription_Textarea);
		res = agGetAttribute("value", FDE_NarrativePageObjects.eventDescription_Textarea);
		CommonOperations.takeScreenShot();
		return res;
	}
	
	public static void verifyANGEventDescription(String scenarioName) {
		
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
				CaseManagementOperations.caseManagement_MenuNavigations("fullDataEntryForm");

				FDE_General.LSMVSetGeneralBasicDetails(scenarioName);
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
				if (getTestDataCellValue(scenarioName, "FDE_Source").equalsIgnoreCase("Yes")) {
					FDE_Operations.tabNavigation("Source");
					FDE_Source.setSourceDetails(scenarioName);
				}
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
				if (getTestDataCellValue(scenarioName, "FDE_Reporter").equalsIgnoreCase("Yes")) {
					FDE_Operations.tabNavigation("Reporter");
					FDE_Reporter.set_ReporterData(scenarioName);
				}
				// FDE_Reporter.set_ReporterData(scenarioName);
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
				if (getTestDataCellValue(scenarioName, "FDE_Study").equalsIgnoreCase("Yes")) {
					Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
					if (FDE_General.getData(scenarioName, "Gen_CaseReport_ReportType").equalsIgnoreCase("Report from study")) {
						FDE_Operations.tabNavigation("Study");
						FDE_Study.set_StudyData(scenarioName);

						if (scenarioName.equalsIgnoreCase("BlindingUnBlinding")) {
							FDE_Study.copy_Product("BlindingUnBlinding");
						}
					}
				}
				
				// tabNavigation("Study");
				// FDE_Study.set_StudyData(scenarioName);

				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
				if (getTestDataCellValue(scenarioName, "FDE_Patient").equalsIgnoreCase("Yes")) {
					FDE_Operations.tabNavigation("Patient");
					FDE_Patient.set_Patient(scenarioName);
				}
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
				if (getTestDataCellValue(scenarioName, "FDE_Parent").equalsIgnoreCase("Yes")) {
					FDE_Operations.tabNavigation("Parent");
					FDE_Parent.LSMVSetParentDetails(scenarioName);
				}
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
				if (getTestDataCellValue(scenarioName, "FDE_Products").equalsIgnoreCase("Yes")) {
					FDE_Operations.tabNavigation("Product(s)");
					FDE_Products.setProductData(scenarioName);
				}
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
				if (getTestDataCellValue(scenarioName, "FDE_Events").equalsIgnoreCase("Yes")) {
					FDE_Operations.tabNavigation("Event(s)");
					FDE_Events.set_Events(scenarioName);
				}
				
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ConfigurationSettings");
				if (getTestDataCellValue(scenarioName, "FDE_Narrative").equalsIgnoreCase("Yes")) {
					FDE_Operations.tabNavigation("Narrative");
					FDE_Narrative.setNarrativeData(scenarioName);
				}
		
	}
	
	
		
}
