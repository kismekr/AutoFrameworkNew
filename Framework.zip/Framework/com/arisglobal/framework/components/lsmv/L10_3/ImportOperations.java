package com.arisglobal.framework.components.lsmv.L10_3;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.ApplicationParameterPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DataBaseOperations;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class ImportOperations extends ToolManager {
	public static WebElement webElement;
	static String className = ImportOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to Import the XML Input Parameters.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void importXML(String scenarioName) {
		CaseManagementOperations.menuNavigation("Case listing");
		agSetStepExecutionDelay("3000");
		agMouseHover(CaseListingPageObjects.newButton);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agMouseHover(CaseListingPageObjects.importXml);
		agClick(CaseListingPageObjects.importXml);
		agUploadDocuments(lsmvConstants.lsmvXmlPath + getTestDataCellValue(scenarioName, "R2Xml"));
		Reports.ExtentReportLog("", Status.INFO, "Xml is Imported", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Import the XML Input Parameters.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 20-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void importXML(String scenarioName, String colName) {
		getTestData(lsmvConstants.LSMV_testData, className);
		CaseManagementOperations.menuNavigation("Case listing");
		agSetStepExecutionDelay("6000");
		agWaitTillVisibilityOfElement(CaseListingPageObjects.newButton);
		agMouseHover(CaseListingPageObjects.newButton);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// agMouseHover(CaseListingPageObjects.importXml);
		// agClick(CaseListingPageObjects.importXml);
		agSetStepExecutionDelay("3000");
		agSetValue(CaseListingPageObjects.importXml,
				lsmvConstants.lsmvE2EScenarioPath + getTestDataCellValue(scenarioName, colName));
		Reports.ExtentReportLog("", Status.INFO, "Xml is Imported", true);
	}

	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Import the XML Input Parameters.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 20-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void importAERData(String scenarioName, String columnName,String reportType,String sheetName) {
		getTestData(lsmvConstants.LSMV_testData, className);
		CaseManagementOperations.menuNavigation("Case listing");
		agSetStepExecutionDelay("6000");
		agWaitTillVisibilityOfElement(CaseListingPageObjects.newButton);
		agMouseHover(CaseListingPageObjects.newButton);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// agMouseHover(CaseListingPageObjects.importXml);
		// agClick(CaseListingPageObjects.importXml);
		agSetStepExecutionDelay("3000");
		//String RecptNo = FDE_General.getData(scenarioName, "ReceiptNo");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ImportOperations");
		String FilePath=getTestDataCellValue(scenarioName, columnName);
		System.out.print(FilePath);
		
		agSetValue(CaseListingPageObjects.ImportAerData,
				lsmvConstants.LSMV_testDataOutput+FilePath);
		Reports.ExtentReportLog("", Status.INFO, "AER Data File is Imported", true);
	}

	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Import the E2B R3 XML and write
	 *             the message Number to datasheet
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @Date : 10-01-2020
	 * @UpdatedByAndWhen:DushyanthMahesh 07-02-2020
	 **********************************************************************************************************/

	@SuppressWarnings("resource")
	public static void importR3XML() {
		String scenarioName = null;

		ArrayList<String> files = E2BMessageQueueOperations
				.GetFileCountName(lsmvConstants.lsmvXmlPath + "FDE_Input_XML\\");
		System.out.println(files);
		int fileCount = files.size();
		System.out.println("fileCount: " + fileCount);
		Connection dbCon = null;
		try {

			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);
			ResultSet rs = DataBaseOperations.performRead(dbCon, "Select * from lsmv_wpa_controller");
			// ----------------Delete not necessary-----------------
			// DataBaseOperations.performWrite(dbCon, "DELETE FROM lsmv_wpa_controller");

			rs = DataBaseOperations.performRead(dbCon, "Select * from lsmv_wpa_controller");
			rs.beforeFirst();
			for (int i = 1; i <= fileCount; i++) {
				CaseManagementOperations.menuNavigation("Case listing");
				agWaitTillInvisibilityOfElement(CaseListingPageObjects.caseListingLoading);
				// XMLOperations.updateMessageNumber(files.get(fileCount-1));
				rs.next();
				// String scenario = "PairwiseTesting_"+i;

				String name = files.get(i - 1);
				String Name[] = name.split("_R3Import_");
				String scenario = Name[0].toString().trim();
				// System.out.println(Name[0].toString().trim());

				int num = 0;
				for (int k = 0; k < files.size(); k++) {

					if (files.get(k).toString().contains(scenario + "_R3Import_")) {
						num = k;
						break;
					}
				}

				/*
				 * DataBaseOperations.performWrite(dbCon,
				 * "Insert into lsmv_wpa_controller(Scenario) Values('" + scenario + "');");
				 */
				rs = DataBaseOperations.performRead(dbCon,
						"SELECT * FROM lsmv_wpa_controller WHERE Scenario='" + scenario + "'");
				rs.first();
				CommonOperations.waitTillCaseVisible();
				agSetStepExecutionDelay("2000");
				agIsVisible(CaseListingPageObjects.newButton);
				agMouseHover(CaseListingPageObjects.newButton);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				// agMouseHover(CaseListingPageObjects.importXml);
				agWaitTillVisibilityOfElement(CaseListingPageObjects.importXml);
				agSetValue(CaseListingPageObjects.importXml, lsmvConstants.lsmvXmlPath + "FDE_Input_XML\\" + name);
				agSetStepExecutionDelay("3000");
				agIsVisible(CaseListingPageObjects.importvalidationPopup);
				String MSGNUMBER = agGetText(CaseListingPageObjects.importvalidationPopup);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				scenarioName = rs.getString("Scenario");
				if (MSGNUMBER.contains("Message Number:")) {
					String MsgNumber[] = MSGNUMBER.split(".Check");
					Thread.sleep(2000);
					String messageNumber[] = MsgNumber[0].split("Message Number:");
					System.out.println("messageNumber: " + messageNumber[1].trim());
					String MessageNumber = messageNumber[1].trim();
					agIsVisible(CaseListingPageObjects.r3Import_msg);
					String R3Import_Message = agGetText(CaseListingPageObjects.r3Import_msg);
					DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set R3XML_Import_Message= '"
							+ R3Import_Message + "' where Scenario='" + scenarioName + "'");
					DataBaseOperations.performWrite(dbCon,
							"update lsmv_wpa_controller set R3XMLImport_Message_Number = '" + MessageNumber
									+ "' where Scenario='" + scenarioName + "'");

				} else {
					DataBaseOperations.performWrite(dbCon,
							"update lsmv_wpa_controller set R3XMLImport_Message_Number = '" + MSGNUMBER
									+ "' where Scenario='" + scenarioName + "'");
				}
				// agSetStepExecutionDelay("3000");
				// agClick(CaseListingPageObjects.importvalidationPopupOk_Btn);
				agJavaScriptExecuctorClick(CaseListingPageObjects.importvalidationPopupOk_Btn);
				agWaitTillInvisibilityOfElement(CaseListingPageObjects.importvalidationPopupOk_Btn);
				// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			}
			Reports.ExtentReportLog("", Status.INFO, "Xml is Imported", true);

		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		} finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: Import XML in case listing
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 24-01-2021
	 * @UpdatedByAndWhen:DushyanthMahesh 07-02-2020
	 **********************************************************************************************************/

	@SuppressWarnings("resource")
	public static void importXMLComparision(String scenarioName) {
		ArrayList<String> files = E2BMessageQueueOperations
				.GetFileCountName(lsmvConstants.lsmvXmlPath + "FDE_Input_XML\\");
		System.out.println(files);
		int fileCount = files.size();
		System.out.println("fileCount: " + fileCount);
		//Connection dbCon = null;
		try {

			for (int i = 1; i <= fileCount; i++) {
				CaseManagementOperations.menuNavigation("Case listing");
				agWaitTillInvisibilityOfElement(CaseListingPageObjects.caseListingLoading);
				XMLOperations.updateMessageNumberR3xml(lsmvConstants.LSMV_WPAsourceFolderPath,"ImportExportComparision.xml");
				//rs.next();
				// String scenario = "PairwiseTesting_"+i;

				String name = files.get(i - 1);
				
				CommonOperations.waitTillCaseVisible();
				agSetStepExecutionDelay("2000");
				agIsVisible(CaseListingPageObjects.newButton);
				agMouseHover(CaseListingPageObjects.newButton);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				// agMouseHover(CaseListingPageObjects.importXml);
				agWaitTillVisibilityOfElement(CaseListingPageObjects.importXml);
				agSetValue(CaseListingPageObjects.importXml, lsmvConstants.lsmvXmlPath + "FDE_Input_XML\\" + name);
				agSetStepExecutionDelay("6000");
				agIsVisible(CaseListingPageObjects.importvalidationPopup);
				String MSGNUMBER = agGetText(CaseListingPageObjects.importvalidationPopup);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				//scenarioName = rs.getString("Scenario");
				if (MSGNUMBER.contains("Message Number:")) {
					String MsgNumber[] = MSGNUMBER.split(".Check");
					Thread.sleep(2000);
					String messageNumber[] = MsgNumber[0].split("Message Number:");
					System.out.println("messageNumber: " + messageNumber[1].trim());
					String MessageNumber = messageNumber[1].trim();
					agIsVisible(CaseListingPageObjects.r3Import_msg);
					String R3Import_Message = agGetText(CaseListingPageObjects.r3Import_msg);
					/*DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set R3XML_Import_Message= '"
							+ R3Import_Message + "' where Scenario='" + scenarioName + "'");
					DataBaseOperations.performWrite(dbCon,
							"update lsmv_wpa_controller set R3XMLImport_Message_Number = '" + MessageNumber
									+ "' where Scenario='" + scenarioName + "'");
*/
					System.out.println("R3Import_Message: "+R3Import_Message);
					//XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "ImportOperations", scenarioName, "MessageNo", MessageNumber);
				XlsReader.writeToExcel(lsmvConstants.LSMV_testData, "ImportOperations", 1, 3, MessageNumber);
				
				} else {
				/*	DataBaseOperations.performWrite(dbCon,
							"update lsmv_wpa_controller set R3XMLImport_Message_Number = '" + MSGNUMBER
									+ "' where Scenario='" + scenarioName + "'");
				*/}
				// agSetStepExecutionDelay("3000");
				// agClick(CaseListingPageObjects.importvalidationPopupOk_Btn);
				agJavaScriptExecuctorClick(CaseListingPageObjects.importvalidationPopupOk_Btn);
				agWaitTillInvisibilityOfElement(CaseListingPageObjects.importvalidationPopupOk_Btn);
				// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			}
			Reports.ExtentReportLog("", Status.INFO, "Xml is Imported", true);

		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		} /*finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}*/

	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Import the E2B R2 XML and write
	 *             the message Number to datasheet
	 * @InputParameters: Scenario Name , sheetName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void importXmlCaseCreation(String scenarioName, String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		importXML(scenarioName);
		CommonOperations.write_MessageNo(scenarioName, sheetName);
		agAssertContainsText(CaseListingPageObjects.importvalidationPopup,
				getTestDataCellValue(scenarioName, "ImportMSG") + XMLOperations.getData(scenarioName, "MessageNo"));
		String Validation = agGetText(CaseListingPageObjects.importvalidationPopup);
		status = agIsVisible(CaseListingPageObjects.importvalidationPopup);
		if (status) {
			Reports.ExtentReportLog("Import E2B XML", Status.PASS,
					"XML Imported Successfull :: Validation-" + Validation, true);
		} else {
			Reports.ExtentReportLog("Import E2B XML", Status.FAIL, "XML Imported Unsuccessfull", true);
		}

		agClick(CaseListingPageObjects.importvalidationPopupOk_Btn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to case assessment verification based
	 *             on duplicateCheck policy in case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void duplicateCheckVerification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		status = agIsVisible(CaseListingPageObjects.caseListingAssessedcolumn);
		if (status) {
			String data = agGetText(CaseListingPageObjects.caseListingAssessedcolumn);
			agCheckPropertyText(data, getTestDataCellValue(scenarioName, "Assessed"));
			Reports.ExtentReportLog("Case is assessed successfully", Status.PASS, "Case is assesed as : " + data, true);
		} else {
			Reports.ExtentReportLog("Case is not assessed successfully", Status.FAIL, "Case is not assessed", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to verify the import operation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Sagar S
	 * @Date : 13-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static Boolean verifyImport() {

		Boolean status = null;
		agGetCurrentWindow();
		if (agGetText(ApplicationParameterPageObjects.importMessage).contains("Action Completed Successfully")) {
			Reports.ExtentReportLog("", Status.PASS, "Import Successfull", true);
			agClick(CommonPageObjects.validaionOk_Btn);
			status = Boolean.TRUE;
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Import Unsuccessfull", true);
			status = Boolean.FALSE;
		}
		return status;
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to verify the import operation
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 19-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static Boolean verifyImport(String scenariName) {

		Boolean status = null;

		agIsVisible(CaseListingPageObjects.importvalidationPopup);
		String MSGNUMBER = agGetText(CaseListingPageObjects.importvalidationPopup);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// String scenarioName = rs.getString("Scenario");
		if (MSGNUMBER.contains("Message Number:")) {
			String MsgNumber[] = MSGNUMBER.split(".Check");
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String messageNumber[] = MsgNumber[0].split("Message Number:");
			System.out.println("messageNumber: " + messageNumber[1].trim());
			String MessageNumber = messageNumber[1].trim();
			agIsVisible(CaseListingPageObjects.r3Import_msg);

			if (agGetText(CaseListingPageObjects.r3Import_msg).contains("Action Completed Successfully")) {
				Reports.ExtentReportLog("", Status.INFO, "Import Successfull", true);
				// agClick(CommonPageObjects.validaionOk_Btn);
				status = Boolean.TRUE;
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Import Unsuccessfull", true);
				status = Boolean.FALSE;
			}

			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenariName, "MessageNo", MessageNumber);
			agJavaScriptExecuctorClick(CaseListingPageObjects.importvalidationPopupOk_Btn);
			agWaitTillInvisibilityOfElement(CaseListingPageObjects.importvalidationPopupOk_Btn);
		}
		return status;

	}
	/**********************************************************************************************************
	 * @Objective: This method is created to verify the import operation
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 19-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static Boolean verifyAERImport(String scenariName) {

		Boolean status = null;

		agIsVisible(CaseListingPageObjects.importvalidationPopup);
		String MSGNUMBER = agGetText(CaseListingPageObjects.importvalidationPopup);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// String scenarioName = rs.getString("Scenario");
		if (MSGNUMBER.contains("Case created successfully")) {
			String MsgNumber[] = MSGNUMBER.split("Case created successfully : ");
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("Reciept Number: " +MsgNumber[1].trim());
			String MessageNumber = MsgNumber[1].trim();
			

			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "FDE_General", scenariName, "ReceiptNo", MessageNumber);
			agJavaScriptExecuctorClick(CaseListingPageObjects.importvalidationPopupOk_Btn);
			agWaitTillInvisibilityOfElement(CaseListingPageObjects.importvalidationPopupOk_Btn);
		}
		return status;

	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to search the created case in case
	 *             listing and edit
	 * @InputParameters: Scenario Name, sheetName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchCaseAndEdit(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetStepExecutionDelay("10000");
		CaseManagementOperations.menuNavigation("Case listing");
		/*
		 * if(agIsVisible(FullDataEntryFormPageObjects.withOutSaveValidation)==true) {
		 * agClick(FullDataEntryFormPageObjects.yesBtn_withOutSaveValidation); }
		 */
		// agSetStepExecutionDelay("6000");
		// agWaitTillVisibilityOfElement(CaseListingPageObjects.keywordSearchTextbox);
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, columnName));
		agClick(CaseListingPageObjects.searchButton);
		// CommonOperations.waitTillCaseVisible();
		CommonOperations.agwaitTillVisible(
				CaseListingPageObjects.waitForRCT(ImportOperations.getData(scenarioName, columnName)), 4, 1000);

		Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);

		agClick(CaseListingPageObjects.receiptNumberlink);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Import the XML Input Parameters.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 20-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void importEMAR3XML(String scenarioName, String colName) {
		getTestData(lsmvConstants.LSMV_testData, className);
		CaseManagementOperations.menuNavigation("Case listing");
		agSetStepExecutionDelay("5000");
		agMouseHover(CaseListingPageObjects.newButton);
		// agClick(CaseListingPageObjects.importXml);
		// agUploadDocuments(lsmvConstants.lsmvXmlPath + "EMA_R3_Input_XML\\" +
		// getTestDataCellValue(scenarioName, colName));
		agSetValue(CaseListingPageObjects.importXml,
				lsmvConstants.lsmvXmlPath + "EMA_R3_Input_XML\\" + getTestDataCellValue(scenarioName, colName));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.takeScreenShot();
		Reports.ExtentReportLog("", Status.INFO, "Xml is Imported", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Import the XML Input Parameters.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 20-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void importEMAR2XML(String scenarioName, String colName) {
		getTestData(lsmvConstants.LSMV_testData, className);
		CaseManagementOperations.menuNavigation("Case listing");
		agSetStepExecutionDelay("5000");
		agMouseHover(CaseListingPageObjects.newButton);
		agSetValue(CaseListingPageObjects.importXml,
				lsmvConstants.lsmvXmlPath + "EMA_R2_Input_XML\\" + getTestDataCellValue(scenarioName, colName));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.takeScreenShot();
		Reports.ExtentReportLog("", Status.INFO, "Xml is Imported", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Import the E2B R3 XML and write
	 *             the message Number to datasheet
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @Date : 10-01-2020
	 * @UpdatedByAndWhen:DushyanthMahesh 07-02-2020 , Karthikeyan Natarajan 08-07-20
	 **********************************************************************************************************/

	@SuppressWarnings("resource")
	public static void importR3XML(String scenarioName) {
		ArrayList<String> files = E2BMessageQueueOperations
				.GetFileCountName(lsmvConstants.lsmvXmlPath + "FDE_Input_XML\\");
		System.out.println(files);
		int fileCount = files.size();
		System.out.println("fileCount: " + fileCount);
		Connection dbCon = null;
		try {

			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);
			ResultSet rs = DataBaseOperations.performRead(dbCon, "Select * from lsmv_wpa_controller");
			// ----------------Delete not necessary-----------------
			// DataBaseOperations.performWrite(dbCon, "DELETE FROM lsmv_wpa_controller");

			rs = DataBaseOperations.performRead(dbCon, "Select * from lsmv_wpa_controller");
			rs.beforeFirst();
			for (int i = 1; i <= fileCount; i++) {
				CaseManagementOperations.menuNavigation("Case listing");
				agWaitTillInvisibilityOfElement(CaseListingPageObjects.caseListingLoading);
				// XMLOperations.updateMessageNumber(files.get(fileCount-1));
				rs.next();
				// String scenario = "PairwiseTesting_"+i;

				String name = files.get(i - 1);
				String Name[] = name.split("_R3Import_");
				String scenario = Name[0].toString().trim();
				// System.out.println(Name[0].toString().trim());
				if (!scenario.equalsIgnoreCase(scenarioName))
					continue;
				/*
				 * DataBaseOperations.performWrite(dbCon,
				 * "Insert into lsmv_wpa_controller(Scenario) Values('" + scenario + "');");
				 */
				rs = DataBaseOperations.performRead(dbCon,
						"SELECT * FROM lsmv_wpa_controller WHERE Scenario='" + scenario + "'");
				rs.first();
				XMLOperations.updateMessageNumberR3xml(name);
				CommonOperations.waitTillCaseVisible();
				agSetStepExecutionDelay("2000");
				agIsVisible(CaseListingPageObjects.newButton);
				agMouseHover(CaseListingPageObjects.newButton);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				// agMouseHover(CaseListingPageObjects.importXml);
				agWaitTillVisibilityOfElement(CaseListingPageObjects.importXml);
				agSetValue(CaseListingPageObjects.importXml, lsmvConstants.lsmvXmlPath + "FDE_Input_XML\\" + name);
				agSetStepExecutionDelay("3000");
				agIsVisible(CaseListingPageObjects.importvalidationPopup);
				String MSGNUMBER = agGetText(CaseListingPageObjects.importvalidationPopup);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				scenarioName = rs.getString("Scenario");
				if (MSGNUMBER.contains("Message Number:")) {
					String MsgNumber[] = MSGNUMBER.split(".Check");
					Thread.sleep(2000);
					String messageNumber[] = MsgNumber[0].split("Message Number:");
					System.out.println("messageNumber: " + messageNumber[1].trim());
					String MessageNumber = messageNumber[1].trim();
					agIsVisible(CaseListingPageObjects.r3Import_msg);
					String R3Import_Message = agGetText(CaseListingPageObjects.r3Import_msg);
					DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set R3XML_Import_Message= '"
							+ R3Import_Message + "' where Scenario='" + scenarioName + "'");
					DataBaseOperations.performWrite(dbCon,
							"update lsmv_wpa_controller set R3XMLImport_Message_Number = '" + MessageNumber
									+ "' where Scenario='" + scenarioName + "'");
					Reports.ExtentReportLog("", Status.PASS,
							"XML Loaded Successfully. Message Number: " + MessageNumber, true);

				} else {
					DataBaseOperations.performWrite(dbCon,
							"update lsmv_wpa_controller set R3XMLImport_Message_Number = '" + MSGNUMBER
									+ "' where Scenario='" + scenarioName + "'");
					Reports.ExtentReportLog("", Status.FAIL, "XML Load Failed", true);
				}
				// agSetStepExecutionDelay("3000");
				// agClick(CaseListingPageObjects.importvalidationPopupOk_Btn);
				agJavaScriptExecuctorClick(CaseListingPageObjects.importvalidationPopupOk_Btn);
				agWaitTillInvisibilityOfElement(CaseListingPageObjects.importvalidationPopupOk_Btn);
				// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				E2BMessageQueueOperations.ImportXMLStatus(scenarioName);
				break;
			}
			Reports.ExtentReportLog("", Status.INFO, "Xml is Imported", true);
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		} finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Import the E2B R3 XML and write
	 *             the message Number to datasheet
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 15072020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	@SuppressWarnings("resource")
	public static void importR2R3XML(String scenarioName, String XMLType) {
		// String scenarioName = null;

		ArrayList<String> files = E2BMessageQueueOperations
				.GetFileCountName(lsmvConstants.lsmvE2EScenarioPath + XMLType + "_Input\\");
		System.out.println(files);
		int fileCount = files.size();
		System.out.println("fileCount: " + fileCount);
		Connection dbCon = null;
		try {

			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);
			ResultSet rs = DataBaseOperations.performRead(dbCon, "Select * from lsmv_wpa_controller");
			CaseManagementOperations.menuNavigation("Case listing");
			agWaitTillInvisibilityOfElement(CaseListingPageObjects.caseListingLoading);
			int fileNumber = 0;
			String fileName = null;
			for (int j = 0; j < files.size(); j++) {
				fileName = files.get(j);
				if (fileName.contains(scenarioName)) {
					fileNumber = j;
					System.out.println("fileNumber: " + fileNumber);
					System.out.println("fileName: " + fileName);
					break;
				}
			}
			ResultSet rs1 = DataBaseOperations.performRead(dbCon,
					"SELECT * FROM lsmv_wpa_controller WHERE Scenario='" + scenarioName + "'");
			rs1.first();
			CommonOperations.waitTillCaseVisible();
			agSetStepExecutionDelay("2000");
			agIsVisible(CaseListingPageObjects.newButton);
			agMouseHover(CaseListingPageObjects.newButton);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agWaitTillVisibilityOfElement(CaseListingPageObjects.importXml);
			if (XMLType.equalsIgnoreCase("R3XML")) {
				XMLOperations.updateMessageNumberR3xmlE2E(
						"End_End_Scenarios\\" + XMLType + "_Input\\" + files.get(fileNumber));
			} else if (XMLType.equalsIgnoreCase("R2XML")) {
				XMLOperations.updateMessageNumber("End_End_Scenarios\\" + XMLType + "_Input\\" + files.get(fileNumber));
			}
			agSetValue(CaseListingPageObjects.importXml,
					lsmvConstants.lsmvXmlPath + "End_End_Scenarios\\" + XMLType + "_Input\\" + files.get(fileNumber));
			agSetStepExecutionDelay("3000");
			agIsVisible(CaseListingPageObjects.importvalidationPopup);
			String MSGNUMBER = agGetText(CaseListingPageObjects.importvalidationPopup);
			Reports.ExtentReportLog("", Status.INFO, "Xml Import Message", true);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			scenarioName = rs1.getString("Scenario");
			if (MSGNUMBER.contains("Message Number:")) {
				String MsgNumber[] = MSGNUMBER.split(".Check");
				Thread.sleep(2000);
				String messageNumber[] = MsgNumber[0].split("Message Number:");
				System.out.println("messageNumber: " + messageNumber[1].trim());
				String MessageNumber = messageNumber[1].trim();
				agIsVisible(CaseListingPageObjects.r3Import_msg);
				String Import_Message = agGetText(CaseListingPageObjects.r3Import_msg);
				DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set XML_Import_Message= '"
						+ Import_Message + "' where Scenario='" + scenarioName + "'");
				DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set XMLImport_Message_Number = '"
						+ MessageNumber + "' where Scenario='" + scenarioName + "'");

			} else {
				DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set XMLImport_Message_Number = '"
						+ MSGNUMBER + "' where Scenario='" + scenarioName + "'");
			}
			agJavaScriptExecuctorClick(CaseListingPageObjects.importvalidationPopupOk_Btn);
			agWaitTillInvisibilityOfElement(CaseListingPageObjects.importvalidationPopupOk_Btn);
			Reports.ExtentReportLog("", Status.INFO, "Xml is Imported", true);

		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		} finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Import the XML Input Parameters.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 06-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void importFDARXML(String scenarioName, String colName) {
		getTestData(lsmvConstants.LSMV_testData, className);
		CaseManagementOperations.menuNavigation("Case listing");
		agSetStepExecutionDelay("5000");
		agMouseHover(CaseListingPageObjects.newButton);
		agSetValue(CaseListingPageObjects.importXml,
				lsmvConstants.lsmvXmlPath + "FDA_Input_XML\\" + getTestDataCellValue(scenarioName, colName));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.takeScreenShot();
		Reports.ExtentReportLog("", Status.INFO, "Xml is Imported", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Import the XML and write the
	 *             message Number to data sheet
	 * @InputParameters: Scenario Name , SheetName, Import file's absolute path
	 * @author: Shamanth S
	 * @Date : 08-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void importXMLCaseCreation(String xmlPath, String scenarioName, String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		createCaseByXMLImport(xmlPath);
		CommonOperations.write_MessageNo(scenarioName, sheetName);
		String Validation = agGetText(CaseListingPageObjects.importvalidationPopup);
		System.out.println("Validation:" + agGetText(CaseListingPageObjects.importvalidationPopup));
		status = agIsVisible(CaseListingPageObjects.importvalidationPopup);
		if (status) {
			if(Validation.toLowerCase().contains("error")) {
				Reports.ExtentReportLog("Import E2B XML", Status.INFO,
						"XML Imported Failed :: Validation-" + Validation, false);
				Reports.ExtentReportLog("", Status.FAIL, "E2B R3 xml is NOT imported.<br />", true);
			}
			Reports.ExtentReportLog("Import E2B XML", Status.INFO,
					"XML Imported Successfull :: Validation-" + Validation, false);
			Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
		} else {
			Reports.ExtentReportLog("Import E2B XML", Status.FAIL, "Not As Expected", true);
		}
		
		agClick(CaseListingPageObjects.importvalidationPopupOk_Btn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Import the XML Input Parameters.
	 * @InputParameters: Import file's absolute path, Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 08-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void createCaseByXMLImport(String xmlPath) {
		CaseManagementOperations.menuNavigation("Case listing");
		agSetStepExecutionDelay("8000");
		agWaitTillVisibilityOfElement(CaseListingPageObjects.newButton);
		agMouseHover(CaseListingPageObjects.newButton);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// agMouseHover(CaseListingPageObjects.importXml);
		// agClick(CaseListingPageObjects.importXml);
		agSetValue(CaseListingPageObjects.importXml, xmlPath);
		Reports.ExtentReportLog("", Status.INFO, "Xml is Imported", true);
	}
public static String setImportPath(String Path,String Scenario) {
	Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
	String fileName = getTestDataCellValue(Scenario, "R2Xml");
	return Path+fileName;
}

/**********************************************************************************************************
 * @Objective: This method is created to Write data into excel sheet.
 * @InputParameters: scenarioName
 * @OutputParameters:
 * @author:Yashwanth Naidu
 * @Date : 09-July-2019
 * @UpdatedByAndWhen:
 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, columnName, data);
	}
}