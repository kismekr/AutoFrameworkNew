package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class AppParameters_MedDRASettingsPageObjects {
	
	////////// Administration >> System Administration >> Application Parameters >> MedDRA Settings ///////////////

	public static String hostName_TextBox = "xpath#//label[contains(text(), 'Host Name')]/ancestor::div[@id ='applicationParameterForm:meddrasettingsPanel_content']/descendant::input[1]";
	public static String portNumber_TextBox = "xpath#//label[contains(text(), 'Port Number')]/ancestor::div[@id ='applicationParameterForm:meddrasettingsPanel_content']/descendant::input[2]";
	public static String sourceID_TextBox = "xpath#//label[contains(text(), 'Source ID')]/ancestor::div[@id ='applicationParameterForm:meddrasettingsPanel_content']/descendant::input[3]";
	public static String username_TextBox = "xpath#//label[contains(text(), 'Username')]/ancestor::div[@id ='applicationParameterForm:meddrasettingsPanel_content']/descendant::input[4]";
	public static String password_TextBox = "xpath#//label[contains(text(), 'Password')]/ancestor::div[@id ='applicationParameterForm:meddrasettingsPanel_content']/descendant::input[5]";
}
