package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class FDE_LabDataPageObjects {
	public static String labAdd_Button = "xpath#//label[text()='Tests']/following-sibling::span/a[text()='Add']";
	public static String testAdd_Button = "xpath#(//a[contains(@title,'Add')])[1]";
	public static String testDelete_Button = "xpath#(//a[contains(@title,'Delete')])[1]";
	public static String testCopy_Button = "xpath#//a[contains(@title,'Copy')]";
	public static String testGridView_Button = "xpath#//a[contains(text(),'Grid View')]";
	public static String testFormView_Button = "xpath#//label[text()='Tests']//..//a[text()='Form View']";
	public static String testName_Textbox = "xpath#//input[contains(@id,'adverseEventNew:laboratoryPanelTable:idN10C77112104_input')]";
	public static String testNameMedDRALLTCode_Textbox = "xpath#//input[@id='adverseEventNew:laboratoryPanelTable:testNameMeddraLltCode']";
	public static String testNameMedDRALLTCode_Lookup = "xpath#//a[@class='agLookupLink']//img";
	public static String testDate_Datesfield = "xpath#//label[contains(text(),'Test Date')]/following-sibling::span/span/input";
	public static String testResultValue_Textbox = "xpath#//input[@id='adverseEventNew:laboratoryPanelTable:testResultValue']";
	public static String testResultValueUnit_DropDown = "xpath#//select[contains(@name,'laboratoryPanelTable:A1')]";
	public static String testResultValueUnit_Getvalue = "xpath#//input[@id='adverseEventNew:laboratoryPanelTable:A1-8138_focus']/ancestor::p-dropdown/div/label";
	public static String normalValueLow_Textbox = "xpath#//input[contains(@id,'112110')]";
	public static String normalValueHigh_Textbox = "xpath#//input[contains(@id,'112112')]";
	public static String relevantForEventDescription_Checkbox = "xpath#//label[text()='Relevant for Event Description ']/../descendant::div[contains(@class,'ui-chkbox-box')]";
	public static String moreInformationAvailable_Radiobtn = "xpath#//label[contains(text(),'More Information Available?')]/following-sibling::span/span/p-radiobutton/div/following::label[contains(text(),'%s')]";
	// label[contains(text(),'More Information
	// Available?')]/following-sibling::span/span/p-radiobutton/div/following::label[contains(text(),'Yes')]
	public static String resultUnstructuredData_Textarea = "xpath#//textarea[@id='adverseEventNew:laboratoryPanelTable:testResultFreeText']";
	public static String labComments_Textarea = "xpath#//textarea[@id='adverseEventNew:laboratoryPanelTable:956117']";
	public static String relevantLaboratoryTestsOrData_Textarea = "xpath#//textarea[@id='adverseEventNew:laboratoryPanelTable:956119']";
	public static String labCommentsAdd_Button = "xpath#(//a[contains(@title,'Add')])[2]";
	public static String labCommentsDelete_Button = "xpath#(//a[contains(@title,'Delete')])[2]";
	public static String relevantLaboratoryTestsOrDataAdd_Button = "xpath#(//a[contains(@title,'Add')])[3]";
	public static String relevantLaboratoryTestsOrDataDelete_Button = "xpath#(//a[contains(@title,'Delete')])[3]";
	public static String testResultCode_DropDown = "xpath#//select[contains(@name,'testResultCode')]";
	public static String testResultCode_Getvalue = "xpath#//input[@id='adverseEventNew:laboratoryPanelTable:testResultCode-9107_focus']/ancestor::p-dropdown/div/label";
	public static String codingType_DropDown = "xpath#//select[contains(@name,'codingType')]";
	public static String codingType_Getvalue = "xpath#//input[@id='adverseEventNew:laboratoryPanelTable:codingType']/ancestor::p-dropdown/div/label";
	public static String getData_testNameMedDRALLTCode = "xpath#//input[@id='adverseEventNew:laboratoryPanelTable:testNameMeddraLltCode']";
	public static String getData_TestNameMedDRAPTCode = "xpath#//input[@id='adverseEventNew:laboratoryPanelTable:testNameMeddraPtCode']";
	public static String get_DropDownValue = "xpath#//label[@style='visibility: visible;'][contains(text(),'{0}')]/ancestor::span/p-dropdown/div/label/span";
	public static String get_relevantForEventDescriptionCheckboxValue = "xpath#//label[text()='Relevant for Event Description ']/../descendant::div[contains(@class,'ui-chkbox-box')]";
	public static String formView_Btn = "xpath#//p-header/label[text()='Tests']/parent::p-header/span/a[text()='Form View']";

	public static String AddBtnLab = "xpath#(//span[@class='agAddDeleteBlock ng-star-inserted']//a[text()='Add'])[1]";
	public static String clickLabTab = "xpath#//div[@class='tabCarouselSty']/ul/li/following-sibling::li[1]/a/span[contains(text(),'%s')]";
	public static String labEmdedDropdownSelect = "xpath#//label[contains(text(),'{0}')]/ancestor::span/span/p-dropdown/div[not(contains(@class,'agNfDropdown'))]";
	public static String setdropDownValue = "xpath#//ul[contains(@class,'ui-dropdown-items')]/child::li/div/span[contains(text(),'%s')]";
	public static String testResultValueU_DropDown = "Test Result : Unit";
	public static String clickNFbutton = "xpath#//label[text()='%s']//parent::span//parent::div//a[@class='agNfLink']";
	public static String testdata_dropdown = "Test Date";
	public static String testdata = "";
	public static String productNFDropdownSelect = "xpath#//label[contains(text(),'{0}')]/ancestor::span/p-dropdown/div[(contains(@class,'agNfDropdown'))]";
	public static String prevNavigaterClick = "xpath#//div[@class='tabCarouselSty']//following::li[contains(@class,'ui-state-default ui-corner-top fdeMultiPanel949_1')]";
	public static String forwardNavigaterClick = "xpath#//div[@class='tabCarouselSty']//following::li[contains(@class,'ui-state-default ui-corner-top fdeMultiPanel949_2')]";
	public static String click_MultipleLabdata = "xpath#//div[@class='tabCarouselSty']/ul/li/a/span[starts-with(text(),'%s')]";
	public static String GetlistofLabdata = "xpath#//div[@class='tabCarouselSty']/ul[@role='tablist']/li//span[contains(text(),'.')]";


	//R2 tags
	public static String R2TestName = "xpath#//label[text()='[B.3.1c]']";
	public static String R2TestDate = "xpath#//label[text()='[B.3.1b]']";
	public static String R2TestResultValue = "xpath#//label[text()='[B.3.1d]']";
	public static String R2TestResultUnit = "xpath#//label[text()='[B.3.1e]']";
	public static String R2NormalValueLow = "xpath#//label[text()='[B.3.1.1]']";
	public static String R2NormalValueHigh = "xpath#//label[text()='[B.3.1.2]']";
	public static String R2MoreInformationAvailable = "xpath#//label[text()='[B.3.1.3]']";
	public static String R2ResultsOfTests = "xpath#//label[text()='[B.3.2]']";
	
	//R3 tags 	
	public static String R3TestName = "xpath#//label[text()='[F.r.2.1]']";
	public static String R3TestNameMedDRALLTCode = "xpath#//label[text()='[F.r.2.2b]']";
	public static String R3Testdata  = "xpath#//label[text()='[F.r.1]']";
	public static String R3TestResultValue  = "xpath#//label[text()='[F.r.3.2]']";
	public static String R3TestResultUnit  = "xpath#//label[text()='[F.r.3.3]']";	
	public static String R3NormalValueLow  = "xpath#//label[text()='[F.r.4]']";
	public static String R3NormalValueHigh = "xpath#//label[text()='[F.r.5]']";
	public static String R3TestResultCode = "xpath#//label[text()='[F.r.3.1]']";
	public static String R3MoreInformationAvailable = "xpath#//label[text()='[F.r.7]']";
	public static String R3ResultUnstructuredDataFreeText = "xpath#//label[text()='[F.r.3.4]']";
	public static String R3LabComments = "xpath#//label[text()='[F.r.6]']";
	
	
	//Codelist Tags
	public static String CLTestResultUnit = "xpath#//label[text()='[8138]']";
	public static String CLTestResultCode = "xpath#//label[text()='[9107]']";
	public static String CLRelevantforEventDescription = "xpath#//label[text()='Relevant for Event Description']//parent::span/label[text()='[1002]']";
	public static String CLMoreInformationAvailable = "xpath#//label[text()='More Information Available?']//parent::span/label[text()='[1002]']";
	public static String CLCodingType = "xpath#//label[text()='[158]']";
	public static String NextIcon="xpath#//a[@class='tabCarouselNext evAttached']";
	
	
	public static String clickMultipleLabdata(String runTimeLabel) {
		String value = click_MultipleLabdata.replace("%s", runTimeLabel);
		return value;
	}

	public static String clickmoreInformationAvailable_Radiobtn(String runTimeLabel) {
		String value = moreInformationAvailable_Radiobtn;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;

	}

	public static String TextBox(String Value) {
		String value = testName_Textbox;
		String value2;
		value2 = value.replace("%s", Value);
		return value2;
	}

	public static String TextBoxDD(String Value) {
		String value = testResultCode_DropDown;
		String value2;
		value2 = value.replace("%s", Value);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click drop down by passing label
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Avinash K Date :19-Aug-2019 Updated by and when
	 **********************************************************************************************************/
	public static String get_DropDownValue(String label) {
		String value = get_DropDownValue.replace("{0}", label);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click drop down by passing label
	 * name at runtime. Input Parameters: ColumnName Scenario Name Output
	 * Parameters:
	 * 
	 * @author:Yashwanth Naidu Date :23-Apr-2020 Updated by and when
	 **********************************************************************************************************/

	public static String click_NFBtn(String Label) {
		String value = clickNFbutton;
		String value2;
		value2 = value.replace("%s", Label);
		return value2;
	}

	public static String NFLabdataDropdownSelect(String label) {
		String value = productNFDropdownSelect.replace("{0}", label);
		return value;
	}

	public static String clickLabTab(String runTimeLabel) {
		String value = clickLabTab;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	public static String labEmdedDropdownSelect(String label) {
		String value = labEmdedDropdownSelect.replace("{0}", label);
		return value;
	}

	public static String clickDropDownValue(String data) {
		String value = setdropDownValue.replace("%s", data);
		return value;
	}
}
