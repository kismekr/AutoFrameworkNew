package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_PregnancyPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_Pregnancy extends ToolManager {
	static String className = FDE_Pregnancy.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: label, scenarioName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 06-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDownValue(String label, String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_PregnancyPageObjects.click_DropDown(label));
			agClick(FDE_PregnancyPageObjects.setdropDownValue(getTestDataCellValue(scenarioName, columnName)));

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set age at Pregnancy Dropdown
	 *             value
	 * @InputParameters: label, scenarioName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 05-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setEmbededDropDownValue(String label, String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_PregnancyPageObjects.click_embeddedDrpdwn(label));
			agClick(FDE_PregnancyPageObjects.setdropDownValue(getTestDataCellValue(scenarioName, columnName)));

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in drop down
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDropdownValue(String scenarioName, String columnName, String object) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, columnName), object);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in text field value
	 * @InputParameters: object, scenarioName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyData(String object, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(object);
			agCheckPropertyValue("title", getTestDataCellValue(scenarioName, columnName), object);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in text field value
	 * @InputParameters: object, scenarioName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDateField(String object, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agCheckPropertyValue("value",
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, columnName)), object);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Current Pregnancy Details in
	 *             Pregnancy tab
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 06-Sep-2019
	 * @UpdatedByAndWhen:Sanchit, 5-Dec-2019
	 **********************************************************************************************************/
	public static void set_CurrentPregnancyDetail(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		setDropDownValue(FDE_PregnancyPageObjects.pregnancyType_DropDown, scenarioName,
				"Pregnancy_CurrentPregnancyDetails_PregnancyType");
		// setDropDownValue(FDE_PregnancyPageObjects.testDetails_DropDown, scenarioName,
		// "Pregnancy_CurrentPregnancyDetails_TestDetails");
		agSetValue(FDE_PregnancyPageObjects.setData_Datesfields(FDE_PregnancyPageObjects.expectedDeliveryDate_Date),
				CommonOperations.returnDateTime(
						getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyDetails_ExpectedDeliveryDate")));
		// Fields not available in pregnancy tab
		/*
		 * if (getTestDataCellValue(scenarioName,
		 * "Pregnancy_CurrentPregnancyDetails_GestAgeEventUnitManual").equalsIgnoreCase(
		 * "true")) { agClick(FDE_PregnancyPageObjects.gestationalAgemanual_Checkbox);
		 * agSetStepExecutionDelay("2000");
		 * agSetValue(FDE_PregnancyPageObjects.set_GestationalAge_TxtField(
		 * FDE_PregnancyPageObjects.gestationalAgeAtEvent_Textbox),getTestDataCellValue(
		 * scenarioName, "Pregnancy_CurrentPregnancyDetails_GestationalAgeAtEvent"));
		 * agSetStepExecutionDelay(String.valueOf(Constants.
		 * defaultGlobalStepExecutionDelay));
		 * setEmbededDropDownValue(FDE_PregnancyPageObjects.
		 * gestationalAgeEvent_DropDown, scenarioName,
		 * "Pregnancy_CurrentPregnancyDetails_GestationalAgeAtEventUnit"); }
		 */
		setDropDownValue(FDE_PregnancyPageObjects.pregnancyConfirmed_DropDown, scenarioName,
				"Pregnancy_CurrentPregnancyDetails_HowWasPregnancyConfirmed");
		agSetValue(FDE_PregnancyPageObjects.setData_Datesfields(FDE_PregnancyPageObjects.dateofPregnancy_Date),
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName,
						"Pregnancy_CurrentPregnancyDetails_DateOfPregnancyConfirmed")));
		agSetValue(FDE_PregnancyPageObjects.BiologicalFatherName_Txtfield,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyDetails_BiologicalFathersName"));
		agSetValue(FDE_PregnancyPageObjects.BiologicalFatherDOB_Date, CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyDetails_BioFathersDOB")));
		agSetValue(FDE_PregnancyPageObjects.BiologicalFatherAge_Txtfield,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyDetails_BiologicalFathersAge"));
		agSetValue(FDE_PregnancyPageObjects.biologicalFatherAge_Textbox,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyDetails_BiologicalFathersAge"));
		CommonOperations.setFDEDropDownValue(FDE_PregnancyPageObjects.biologicalFatherAge_DropDown,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyDetails_BiologicalFathersAgeUnit"));
		agSetValue(FDE_PregnancyPageObjects.BiologicalFatherContactDetails_Txtfield,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyDetails_BioFathersConDetails"));
		agSetValue(FDE_PregnancyPageObjects.setData_Textfields(FDE_PregnancyPageObjects.gravida_Textbox),
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyDetails_Gravida"));
		agSetValue(FDE_PregnancyPageObjects.setData_Textfields(FDE_PregnancyPageObjects.para_Textbox),
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyDetails_Para"));
		agClick(FDE_PregnancyPageObjects.select_RadioButtons(FDE_PregnancyPageObjects.contraceptivesUsed_Radio,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyDetails_ContraceptivesUsed")));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Pregnancy >> Current Pregnancy Details Section : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Current Pregnancy Details
	 *             in Pregnancy tab
	 * @InputParameters: object, scenarioName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 06-Sep-2019
	 * @UpdatedByAndWhen: Sanchit, 5-Dec-2019
	 **********************************************************************************************************/
	public static void currentPregnancyDetails_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		verifyDropdownValue(scenarioName, "Pregnancy_CurrentPregnancyDetails_PregnancyType",
				FDE_PregnancyPageObjects.click_DropDown(FDE_PregnancyPageObjects.pregnancyType_DropDown));
		// verifyDropdownValue(scenarioName,
		// "Pregnancy_CurrentPregnancyDetails_TestDetails",
		// FDE_PregnancyPageObjects.click_DropDown(FDE_PregnancyPageObjects.testDetails_DropDown));
		verifyDateField(
				FDE_PregnancyPageObjects.setData_Datesfields(FDE_PregnancyPageObjects.expectedDeliveryDate_Date),
				scenarioName, "Pregnancy_CurrentPregnancyDetails_ExpectedDeliveryDate");
		if (getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyDetails_GestAgeEventUnitManual")
				.equalsIgnoreCase("true")) {
			verifyData(
					FDE_PregnancyPageObjects
							.set_GestationalAge_TxtField(FDE_PregnancyPageObjects.gestationalAgeAtEvent_Textbox),
					scenarioName, "Pregnancy_CurrentPregnancyDetails_GestationalAgeAtEvent");
			verifyDropdownValue(scenarioName, "Pregnancy_CurrentPregnancyDetails_GestationalAgeAtEventUnit",
					FDE_PregnancyPageObjects
							.click_embeddedDrpdwn(FDE_PregnancyPageObjects.gestationalAgeEvent_DropDown));
		}
		verifyDropdownValue(scenarioName, "Pregnancy_CurrentPregnancyDetails_HowWasPregnancyConfirmed",
				FDE_PregnancyPageObjects.click_DropDown(FDE_PregnancyPageObjects.pregnancyConfirmed_DropDown));
		verifyDateField(FDE_PregnancyPageObjects.setData_Datesfields(FDE_PregnancyPageObjects.dateofPregnancy_Date),
				scenarioName, "Pregnancy_CurrentPregnancyDetails_DateOfPregnancyConfirmed");
		verifyData(FDE_PregnancyPageObjects.BiologicalFatherName_Txtfield, scenarioName,
				"Pregnancy_CurrentPregnancyDetails_BiologicalFathersName");
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(
						getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyDetails_BioFathersDOB")),
				FDE_PregnancyPageObjects.BiologicalFatherDOB_Date);
		verifyData(FDE_PregnancyPageObjects.BiologicalFatherAge_Txtfield, scenarioName,
				"Pregnancy_CurrentPregnancyDetails_BiologicalFathersAge");
		agCheckPropertyText(
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyDetails_BiologicalFathersAgeUnit"),
				FDE_PregnancyPageObjects.get_BiologicalFatherAgeUnit);
		verifyData(FDE_PregnancyPageObjects.BiologicalFatherContactDetails_Txtfield, scenarioName,
				"Pregnancy_CurrentPregnancyDetails_BioFathersConDetails");
		verifyData(FDE_PregnancyPageObjects.setData_Textfields(FDE_PregnancyPageObjects.gravida_Textbox), scenarioName,
				"Pregnancy_CurrentPregnancyDetails_Gravida");
		verifyData(FDE_PregnancyPageObjects.setData_Textfields(FDE_PregnancyPageObjects.para_Textbox), scenarioName,
				"Pregnancy_CurrentPregnancyDetails_Para");

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Pregnancy >> Current Pregnancy Details Section : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Current Pregnancy Outcomes
	 *             Details in Pregnancy tab
	 * @InputParameters: object, scenarioName, columnName
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 28-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_CurrentPregnancyOutcomes(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.setFDEDropDownValue(FDE_PregnancyPageObjects.pregnancyOutcome_DropDown,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_PregnancyOutcome"));
		agSetValue(FDE_PregnancyPageObjects.dateOfPregnancyOutcome_Date, CommonOperations.returnDateTime(
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_DateOfPregnancyOutcome")));
		// agSetValue(FDE_PregnancyPageObjects.endOfPregnancy_Date,
		// CommonOperations.returnDateTime(getTestDataCellValue(scenarioName,
		// "Pregnancy_CurrentPregnancyOutcomes_EndOfPregnancy")));
		CommonOperations.setFDEDropDownValue(FDE_PregnancyPageObjects.methodOfDelivery_DropDown,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_MethodOfDelivery"));
		CommonOperations.setFDEDropDownValue(FDE_PregnancyPageObjects.liveBirthComplications_DropDown,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_LiveBirthComplications"));
		agSetValue(FDE_PregnancyPageObjects.noOfFoetus_Textbox,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_NoOfFoetus"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Pregnancy >> Current Pregnancy Outcomes Section : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Current Pregnancy Outcomes
	 *             Details in Pregnancy tab
	 * @InputParameters: object, scenarioName, columnName
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 28-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void currentPregnancyOutcomes_Verification(String scenarioName) {
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_PregnancyOutcome"),
				FDE_PregnancyPageObjects.pregnancyOutcome_Getvalue);
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName,
						"Pregnancy_CurrentPregnancyOutcomes_DateOfPregnancyOutcome")),
				FDE_PregnancyPageObjects.dateOfPregnancyOutcome_Date);
		// agCheckPropertyValue("value",
		// CommonOperations.returnDateTime(getTestDataCellValue(scenarioName,
		// "Pregnancy_CurrentPregnancyOutcomes_EndOfPregnancy")),
		// FDE_PregnancyPageObjects.endOfPregnancy_Date);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_MethodOfDelivery"),
				FDE_PregnancyPageObjects.methodOfDelivery_Getvalue);
		agCheckPropertyText(
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_LiveBirthComplications"),
				FDE_PregnancyPageObjects.liveBirthComplications_Getvalue);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_NoOfFoetus"),
				FDE_PregnancyPageObjects.noOfFoetus_Textbox);

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Pregnancy >> Current Pregnancy Outcomes Section : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Neonate Details in Pregnancy
	 *             tab
	 * @InputParameters: object, scenarioName, columnName
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 29-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_Neonate(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FDE_PregnancyPageObjects.neonateWeight_Textbox,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_Neonate1_NeonateWeight"));
		CommonOperations.setFDEDropDownValue(FDE_PregnancyPageObjects.neonateWeightUnit_Dropdown,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_NeonateWeightUnit"));
		agSetValue(FDE_PregnancyPageObjects.neonateBirthLengthTextbox,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_NeonateBirthLength"));
		CommonOperations.setFDEDropDownValue(FDE_PregnancyPageObjects.neonateBirthLengthUnit_Dropdown,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregOutcomes_Neonate_NeonateBirthLenUnit"));
		agSetValue(FDE_PregnancyPageObjects.headCircumferenceAtBirth_Textbox,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregOutcomes_Neonate_HeadCircumAtBirthUnit"));
		CommonOperations.setFDEDropDownValue(FDE_PregnancyPageObjects.headCircumferenceAtBirthUnit_Dropdown,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_HeadCircumAtBirthUnit"));
		agSetValue(FDE_PregnancyPageObjects.APGARScore1Minute_Textbox,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_APGARScore1Minute"));
		agSetValue(FDE_PregnancyPageObjects.APGARScore5Minute_Textbox,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_APGARScore5Minute"));
		agSetValue(FDE_PregnancyPageObjects.APGARScore10Minute_Textbox,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_APGARScore10Minute"));
		agSetValue(FDE_PregnancyPageObjects.otherOutcomeDetails_Textbox,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_OtherOutcomeDetails"));
		agSetValue(FDE_PregnancyPageObjects.otherNeonateDetails_Textbox,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_OtherNeonateDetails"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Pregnancy >> Neonate# Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Neonate Details in
	 *             Pregnancy tab
	 * @InputParameters: object, scenarioName, columnName
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 29-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void neonate_Verification(String scenarioName) {
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_Neonate1_NeonateWeight"),
				FDE_PregnancyPageObjects.neonateWeight_Textbox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_NeonateWeightUnit"),
				FDE_PregnancyPageObjects.neonateWeightUnit_Getvalue);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_NeonateBirthLength"),
				FDE_PregnancyPageObjects.neonateBirthLengthTextbox);
		agCheckPropertyText(
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregOutcomes_Neonate_NeonateBirthLenUnit"),
				FDE_PregnancyPageObjects.neonateBirthLengthUnit_Getvalue);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregOutcomes_Neonate_HeadCircumAtBirthUnit"),
				FDE_PregnancyPageObjects.headCircumferenceAtBirth_Textbox);
		agCheckPropertyText(
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_HeadCircumAtBirthUnit"),
				FDE_PregnancyPageObjects.headCircumferenceAtBirthUnit_Getvalue);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_APGARScore1Minute"),
				FDE_PregnancyPageObjects.APGARScore1Minute_Textbox);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_APGARScore5Minute"),
				FDE_PregnancyPageObjects.APGARScore5Minute_Textbox);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_APGARScore10Minute"),
				FDE_PregnancyPageObjects.APGARScore10Minute_Textbox);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_OtherOutcomeDetails"),
				FDE_PregnancyPageObjects.otherOutcomeDetails_Textbox);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_OtherNeonateDetails"),
				FDE_PregnancyPageObjects.otherNeonateDetails_Textbox);

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Pregnancy >> Neonate# Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Previous Pregnancy Details in
	 *             Pregnancy tab
	 * @InputParameters: object, scenarioName, columnName
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 29-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_PreviousPregnancyDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.setFDEDropDownValue(FDE_PregnancyPageObjects.previousPregnancyOutcome_Dropdown,
				getTestDataCellValue(scenarioName, "Pregnancy_PreviousPregnancyDetails_PreviousPregnancyOutcome"));
		agSetValue(FDE_PregnancyPageObjects.pastPregnancyOutcomeDetails_Textbox,
				getTestDataCellValue(scenarioName, "Pregnancy_PrevPregDetail_PastPregOutcomeDetails"));
		agSetValue(FDE_PregnancyPageObjects.noOfChildren_Textbox,
				getTestDataCellValue(scenarioName, "Pregnancy_PreviousPregnancyDetails_NoOfChildren"));
		agSetValue(FDE_PregnancyPageObjects.numberOfAbortions_Textbox,
				getTestDataCellValue(scenarioName, "Pregnancy_PreviousPregnancyDetails_NumberOfAbortions"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Pregnancy >> Previous Pregnancy Details Section : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify previous Pregnancy Details
	 *             in Pregnancy tab
	 * @InputParameters: object, scenarioName, columnName
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 29-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void previousPregnancyDetails_Verification(String scenarioName) {
		agCheckPropertyText(
				getTestDataCellValue(scenarioName, "Pregnancy_PreviousPregnancyDetails_PreviousPregnancyOutcome"),
				FDE_PregnancyPageObjects.previousPregnancyOutcome_Getvalue);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Pregnancy_PrevPregDetail_PastPregOutcomeDetails"),
				FDE_PregnancyPageObjects.pastPregnancyOutcomeDetails_Textbox);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Pregnancy_PreviousPregnancyDetails_NoOfChildren"),
				FDE_PregnancyPageObjects.noOfChildren_Textbox);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Pregnancy_PreviousPregnancyDetails_NumberOfAbortions"),
				FDE_PregnancyPageObjects.numberOfAbortions_Textbox);

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Pregnancy >> Previous Pregnancy Details Section : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Child Information Details in
	 *             Pregnancy tab
	 * @InputParameters: object, scenarioName, columnName
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 29-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_ChildInformationDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.setFDEDropDownValue(FDE_PregnancyPageObjects.sex_Dropdown,
				getTestDataCellValue(scenarioName, "Pregnancy_ChildInformation_Sex"));
		agSetValue(FDE_PregnancyPageObjects.gestationAge_Textbox,
				getTestDataCellValue(scenarioName, "Pregnancy_ChildInformation_GestationAge"));
		CommonOperations.setFDEDropDownValue(FDE_PregnancyPageObjects.gestationAgeUnit_Dropdown,
				getTestDataCellValue(scenarioName, "Pregnancy_ChildInformation_GestationAgeUnit"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Pregnancy >> Child Information Details Section : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify child Information Details
	 *             in Pregnancy tab
	 * @InputParameters: object, scenarioName, columnName
	 * @OutputParameters:
	 * @author: Mythri Jain
	 * @Date : 29-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void childInformationDetails_Verification(String scenarioName) {
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Pregnancy_ChildInformation_Sex"),
				FDE_PregnancyPageObjects.sex_Getvalue);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Pregnancy_ChildInformation_GestationAge"),
				FDE_PregnancyPageObjects.gestationAge_Textbox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Pregnancy_ChildInformation_GestationAgeUnit"),
				FDE_PregnancyPageObjects.gestationAgeUnit_Getvalue);

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Pregnancy >> Child Information Details Section : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Details in Pregnancy tab
	 * @InputParameters: object, scenarioName, columnName
	 * @OutputParameters:
	 * @author: Avinash K
	 * @Date : 02-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_PregnancyDetails(String scenarioName) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,
		// "ConfigurationSettings");
		// if (getTestDataCellValue(scenarioName,
		// "FDE_Pregnancy").equalsIgnoreCase("Yes")) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!FDE_Patient.getData(scenarioName, "Patient_PatientIdentifiers_Gender").equalsIgnoreCase("Male")) {
			set_CurrentPregnancyDetail(scenarioName);
			set_CurrentPregnancyOutcomes(scenarioName);
			set_Neonate(scenarioName);
			set_PreviousPregnancyDetails(scenarioName);
			// set_ChildInformationDetails(scenarioName);
		}
		// }
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Details in Pregnancy tab
	 * @InputParameters: object, scenarioName, columnName
	 * @OutputParameters:
	 * @author: Avinash K
	 * @Date : 02-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_PregnancyDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!FDE_Patient.getData(scenarioName, "Patient_PatientIdentifiers_Gender").equalsIgnoreCase("Male")) {
			currentPregnancyDetails_Verification(scenarioName);
			currentPregnancyOutcomes_Verification(scenarioName);
			neonate_Verification(scenarioName);
			previousPregnancyDetails_Verification(scenarioName);
			// childInformationDetails_Verification(scenarioName);
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
	
	/**********************************************************************************************************
	 * @Objective: Verify codelist tags in Pregnancy tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 20-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyPregnancyCodeList() {
		Reports.ExtentReportLog("", Status.INFO, "********Pregnancy Codelist tag verification Started*******", true);
		agAssertVisible(FDE_PregnancyPageObjects.CLPregnancyType);
		agAssertVisible(FDE_PregnancyPageObjects.CLTimeToExposure);	
		agAssertVisible(FDE_PregnancyPageObjects.CLHowWasPregnancyConfirmed);	
		agAssertVisible(FDE_PregnancyPageObjects.CLPlannedpregnancy);	
		agAssertVisible(FDE_PregnancyPageObjects.CLContraceptivesUsed);
		agAssertVisible(FDE_PregnancyPageObjects.CLContraceptivefailure);
		agAssertVisible(FDE_PregnancyPageObjects.CLPrePregnancyWeight);
		agAssertVisible(FDE_PregnancyPageObjects.CLFamilyHistoryOfBirthDefects);
		agAssertVisible(FDE_PregnancyPageObjects.CLBiologicalFatherAge);
		agAssertVisible(FDE_PregnancyPageObjects.CLPregnancyOutcome);
		agAssertVisible(FDE_PregnancyPageObjects.CLMethodOfDelivery);
		agAssertVisible(FDE_PregnancyPageObjects.CLLiveBirthComplications);
		agAssertVisible(FDE_PregnancyPageObjects.CLGender);
		agAssertVisible(FDE_PregnancyPageObjects.CLWhichPregnancy);
		agAssertVisible(FDE_PregnancyPageObjects.CLBirthOutcome);
		agAssertVisible(FDE_PregnancyPageObjects.CLResuscitated);
		agAssertVisible(FDE_PregnancyPageObjects.CLNICUAdmission);
		agAssertVisible(FDE_PregnancyPageObjects.CLCongenitalAnomaly);
		agAssertVisible(FDE_PregnancyPageObjects.CLAdmissionDuration);
		agAssertVisible(FDE_PregnancyPageObjects.CLCongenitalAnomalyType);
		agAssertVisible(FDE_PregnancyPageObjects.CLPreviousPregnancyOutcome);
		Reports.ExtentReportLog("", Status.INFO, "********Pregnancy Codelist tag verification Completed*******", true);
	}
}