package com.arisglobal.framework.components.lsmv.L10_3;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.E2bMessageQueueListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.ImportOperations;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DataBaseOperations;
import com.arisglobal.framework.lib.utils.generic.FileSystemOperations;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class E2BMessageQueueOperations extends ToolManager {

	public static WebElement webElement;
	static XMLReader xmlRead = new XMLReader();

	static String className = E2BMessageQueueOperations.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: The Below method is create to search based on message number in
	 *             E2BMessageQueueListing
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchMessageNumber(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ImportOperations");
		CaseManagementOperations.caseManagement_MenuNavigations("e2bMessageQueueListing");
		agSetValue(E2bMessageQueueListingPageObjects.basicsearch_TextField,
				getTestDataCellValue(scenarioName, "MessageNo").trim());
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// agClick(E2bMessageQueueListingPageObjects.XMLImportStatusDropdown);
		// agClick(E2bMessageQueueListingPageObjects.setStatus(getTestDataCellValue(scenarioName,
		// "XMLImportStatus")));
		agWaitTillInvisibilityOfElement(E2bMessageQueueListingPageObjects.loadingicon);
		agClick(E2bMessageQueueListingPageObjects.serachIcon);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to get the receiptID of R2 imported
	 *             case from e2bMessageQueueListing.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void getReceiptIDofImportCase(String scenarioName, String SheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ImportOperations");
		boolean record_found = false;
		for (int i = 0; i <= 12; i++) {
			searchMessageNumber(scenarioName);
			agSetStepExecutionDelay("3000");
			// String paginator = agGetText(E2bMessageQueueListingPageObjects.paginator);
			// if (paginator != null && paginator.startsWith("1")) {
			record_found = true;
			// E2BMessageQueueListingOperations.searchMessageNumber(scenarioName);
			agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects.ReceiptID);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			String receiptID = agGetText(E2bMessageQueueListingPageObjects.ReceiptID);
			
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
			String RecieptNumberPrefix =getTestDataCellValue("LSMV_ISP_Config", "ReceiptPrefix");
			
			if(receiptID .contains(RecieptNumberPrefix)) {
				Reports.ExtentReportLog("", Status.PASS, "Receipt Numbering Format - Prefix is getting Mapped in Created Reciept Number", true);
				
			}else {
				Reports.ExtentReportLog("", Status.FAIL, "Receipt Numbering Format - Prefix is getting Mapped in Created Reciept Number", true);
			}
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, SheetName, scenarioName, "ReceiptNo", receiptID);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "FDE_General", scenarioName, "ReceiptNo", receiptID);
			Reports.ExtentReportLog("Get ReceiptID of Imported case", Status.PASS,
					"Import case is displayed :: Receipt ID -" + receiptID, true);
			break;
		}
		// }

		if (!record_found) {
			Reports.ExtentReportLog("Get ReceiptID of Imported case", Status.FAIL, "Imported case is not displayed",
					true);
			// AdministrationOperations.importSchedulerRestart();
			// getReceiptIDofImportCase(scenarioName, SheetName);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in import case
	 * @InputParameters: scenarioName, datatoVerifiy
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void importDataverification(String scenarioName, String datatoVerifiy) {
		getTestData(lsmvConstants.LSMV_testData, className);
		switch (datatoVerifiy) {
		case "firstName":
			agClick(FDE_GeneralPageObjects.firstName);
			agCheckPropertyValue("title", getTestDataCellValue(scenarioName, "firstName"),
					FDE_GeneralPageObjects.firstName);
			break;
		case "patientinitial":
			FDE_Operations.tabNavigation("Patient");
			agClick(FDE_GeneralPageObjects.patientidTextbox);
			agCheckPropertyValue("title", getTestDataCellValue(scenarioName, "patientinitial"),
					FDE_GeneralPageObjects.patientidTextbox);
			break;
		case "Productname":
			FDE_Operations.tabNavigation("Product(s)");
			agClick(FDE_GeneralPageObjects.productName);
			agCheckPropertyValue("title", getTestDataCellValue(scenarioName, "Productname"),
					FDE_GeneralPageObjects.productName);
			break;
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Write data into excel sheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Fetch the Status of Import XML File.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmarS
	 * @Date : 09-01-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void ImportStatus() {
		agSetStepExecutionDelay("2000");
		CaseManagementOperations.caseManagement_MenuNavigations("e2bMessageQueueListing");
		agSetStepExecutionDelay("2000");
		agClick(E2bMessageQueueListingPageObjects.RefreshBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		/*
		 * ArrayList<String> files = E2BMessageQueueOperations
		 * .GetFileCountName(lsmvConstants.lsmvXmlPath + "FDE_Input_XML\\");
		 */
		// for (int i = 0; i < files.size(); i++) {
		Connection dbCon = null;
		int rowCount = 0;
		try {
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);
			ResultSet rs = DataBaseOperations.performRead(dbCon,
					"Select * from lsmv_wpa_controller where Scenario='PairwiseTesting_3'");

			rs.last();
			rowCount = rs.getRow();
			System.out.println("rowCount" + rowCount);
			// rs = DataBaseOperations.performRead(dbCon, "Select R3XMLImport_Message_Number
			// from lsmv_wpa_controller");
			rs.beforeFirst();
			for (int j = 0; j < rowCount; j++) {
				rs.next();

				String messageNumber = rs.getString("R3XMLImport_Message_Number");

				if (messageNumber == null) {
					continue;
				}

				// String recieptNumber = rs.getString("Case_Reciept_Number");
				String scenarioName = rs.getString("Scenario");
				agWaitTillInvisibilityOfElement(E2bMessageQueueListingPageObjects.loadingicon);
				agAssertVisible(E2bMessageQueueListingPageObjects.basicsearch_TextField);
				agSetValue(E2bMessageQueueListingPageObjects.basicsearch_TextField, messageNumber.trim());
				agAssertVisible(E2bMessageQueueListingPageObjects.serachIcon);
				agClick(E2bMessageQueueListingPageObjects.serachIcon);
				agAssertVisible(E2bMessageQueueListingPageObjects.EmptyRow);
				String EmptyRowStatus = agGetText(E2bMessageQueueListingPageObjects.EmptyRow);
				// Refresh multiples times until case visible

				if (EmptyRowStatus.contains("No records to display")) {
					/*
					 * for (int k = 0; k <= 5; k++) { agSetStepExecutionDelay("2000");
					 * agClick(E2bMessageQueueListingPageObjects.serachIcon);
					 * agSetStepExecutionDelay(String.valueOf(Constants.
					 * defaultGlobalStepExecutionDelay)); // break; }
					 */
					continue;
				}
				String ProcessingStatus, XMLImportStatus, SafetyReportImportStatus, AdditionalComments = null;
				ProcessingStatus = agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.processingStatus));
				XMLImportStatus = agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.importStatus));
				SafetyReportImportStatus = agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.safetyImportStatus));
				AdditionalComments = agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));

				do {
					agSetStepExecutionDelay("2000");
					agClick(E2bMessageQueueListingPageObjects.RefreshBtn);
					agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
					ProcessingStatus = agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.processingStatus));
					XMLImportStatus = agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.importStatus));
					SafetyReportImportStatus = agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.safetyImportStatus));
					AdditionalComments = agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));

				} while (SafetyReportImportStatus.equals("Inprogress") || SafetyReportImportStatus.equals(""));

				if (ProcessingStatus.matches("Parsing") || XMLImportStatus.matches("Failure Import")
						|| SafetyReportImportStatus.matches("Failure")) {

					agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));
					System.out.println(agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments)));
					DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set XML_Import_Status= '"
							+ XMLImportStatus + "' where Scenario='" + scenarioName + "'");
					DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set Additional_Comments= '"
							+ AdditionalComments + "' where Scenario='" + scenarioName + "'");
					DataBaseOperations.performWrite(dbCon,
							"update lsmv_wpa_controller set Workflow_Status='Invalid' where Scenario='" + scenarioName
									+ "'");
					/*
					 * DataBaseOperations.performWrite(dbCon,
					 * "update lsmv_wpa_controller set Case_Reciept_Number= '"+
					 * agGetText(E2bMessageQueueListingPageObjects.ReceiptID) + "' where Scenario='"
					 * +scenarioName + "'");
					 */

					// break;
				} else if (ProcessingStatus.matches("Complete ( 9 of 9)")
						|| SafetyReportImportStatus.matches("Success")) {

					agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));
					agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.receiptNo));
					agSetStepExecutionDelay("2000");
					String rctNum = agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.receiptNo));
					
					Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
					String RecieptNumberPrefix =getTestDataCellValue("LSMV_ISP_Config", "ReceiptPrefix");
					
					if(rctNum.contains(RecieptNumberPrefix)) {
						Reports.ExtentReportLog("", Status.PASS, "Receipt Numbering Format - Prefix is getting Mapped in Created Reciept Number", true);
						
					}else {
						Reports.ExtentReportLog("", Status.FAIL, "Receipt Numbering Format - Prefix is getting Mapped in Created Reciept Number", true);
					}
					agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
					DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set XML_Import_Status= '"
							+ XMLImportStatus + "' where Scenario='" + scenarioName + "'");
					DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set Additional_Comments= '"
							+ AdditionalComments + "' where Scenario='" + scenarioName + "'");
					DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set Receipt_Number= '" + rctNum
							+ "' where Scenario='" + scenarioName + "'");
					DataBaseOperations.performWrite(dbCon,
							"update lsmv_wpa_controller set Workflow_Status='Intake and Assessment' where Scenario='"
									+ scenarioName + "'");
					DataBaseOperations.performWrite(dbCon,
							"update fde_general set ReceiptNo= '" + rctNum + "' where Scenario='" + scenarioName + "'");
					Thread.sleep(5000);
					DataBaseOperations.performWrite(dbCon,
							"update lsmv_wpa_controller set CreationType= 'ImportR3XML' where Scenario='" + scenarioName
									+ "'");
					Thread.sleep(5000);

					// break;
				}

			}

		} catch (SQLException sqle) {
			// TODO Auto-generated catch block
			sqle.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Fetch the Status of Import XML File.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 20-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ImportStatus(String scenarioName) {

		getTestData(lsmvConstants.LSMV_testData, "ImportOperations");

		agSetStepExecutionDelay("2000");
		CaseManagementOperations.caseManagement_MenuNavigations("e2bMessageQueueListing");
		agSetStepExecutionDelay("3000");

		agJavaScriptExecuctorClick(E2bMessageQueueListingPageObjects.importRefreshIcon);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		agWaitTillInvisibilityOfElement(E2bMessageQueueListingPageObjects.loadingicon);
		agSetStepExecutionDelay("3000");
		agAssertVisible(E2bMessageQueueListingPageObjects.basicsearch_TextField);
		agSetValue(E2bMessageQueueListingPageObjects.basicsearch_TextField,
				getTestDataCellValue(scenarioName, "MessageNo").trim());
		agAssertVisible(E2bMessageQueueListingPageObjects.serachIcon);
		agJavaScriptExecuctorClick(E2bMessageQueueListingPageObjects.serachIcon);

		agWaitTillVisibilityOfElement(
				E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.messageNumber));

		String ProcessingStatus = null;
		String SafetyReportImportStatus = null;

		for (int i = 0; i < 10; i++) {
			// agJavaScriptExecuctorClick(E2bMessageQueueListingPageObjects.importRefreshIcon);
			agSetStepExecutionDelay("4000");
			agSetValue(E2bMessageQueueListingPageObjects.basicsearch_TextField,
					getTestDataCellValue(scenarioName, "MessageNo").trim());
			agJavaScriptExecuctorClick(E2bMessageQueueListingPageObjects.serachIcon);
			ProcessingStatus = agGetText(E2bMessageQueueListingPageObjects
					.getTextColumn(E2bMessageQueueListingPageObjects.processingStatus));
			SafetyReportImportStatus = agGetText(
					(E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.importStatus)));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (SafetyReportImportStatus.contains("Failed Import")) {
				Reports.ExtentReportLog("XML Import not successfull", Status.FAIL, "XML Import not successfull", true);
				break;
			}
			if (ProcessingStatus.contains("Complete ( 9 of 9)")) {
				Reports.ExtentReportLog("XML Import successful", Status.PASS, "XML Import successful", true);
				/*
				 * do { agClick(E2bMessageQueueListingPageObjects.RefreshBtn); ProcessingStatus
				 * = agGetText(E2bMessageQueueListingPageObjects
				 * .getTextColumn(E2bMessageQueueListingPageObjects.processingStatus));
				 * SafetyReportImportStatus = agGetText(
				 * (E2bMessageQueueListingPageObjects.getTextColumn(
				 * E2bMessageQueueListingPageObjects.importStatus))); if
				 * (SafetyReportImportStatus.contains("Failed Import")) {
				 * Reports.ExtentReportLog("XML Import not successfull", Status.FAIL,
				 * "XML Import not successfull", true); break; } } while
				 * (ProcessingStatus.contains("Complete ( 9 of 9)"));
				 */
				if (agIsVisible(E2bMessageQueueListingPageObjects.ReceiptID) == true) {

					String receiptID = agGetText(E2bMessageQueueListingPageObjects.ReceiptID);
					agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects.ReceiptID);
					
					Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ImportOperations");
					if (getTestDataCellValue(scenarioName, "AddToExcelFlag").equals("YES")) {
							ImportOperations.setData(scenarioName, "ReceiptNo", receiptID);	
					}
						Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
					String RecieptNumberPrefixs =getTestDataCellValue("LSMV_ISP_Config", "ReceiptPrefix");
					
					if(receiptID.contains(RecieptNumberPrefixs)) {
						Reports.ExtentReportLog("", Status.PASS, "Receipt Numbering Format - Prefix is getting Mapped With Created Reciept Number", true);
						
					}else {
						Reports.ExtentReportLog("", Status.FAIL, "Receipt Numbering Format - Prefix is getting Mapped  With Created Reciept Number", true);
					}
					
					CommonOperations.captureScreenShot(true);
					break;
				}
			
				agSetStepExecutionDelay("2000");
				agIsVisible(
						E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.xmlType));
				agJavaScriptExecuctorClick(E2bMessageQueueListingPageObjects.R2R3Icon);
				agWaitTillVisibilityOfElement(E2bMessageQueueListingPageObjects.easyViewButton);
				agAssertVisible(E2bMessageQueueListingPageObjects.easyViewButton);
				if (agIsExists(E2bMessageQueueListingPageObjects.easyViewButton)) {
					Reports.ExtentReportLog("XML easy View", Status.PASS, "Easy view successfull", true);
				} else {
					Reports.ExtentReportLog("XML easy View", Status.FAIL, "Easy view unsuccessfull", true);
				}

				agWaitTillVisibilityOfElement(E2bMessageQueueListingPageObjects.acknowledgmentTab);
				agClick(E2bMessageQueueListingPageObjects.acknowledgmentTab);

				agWaitTillVisibilityOfElement(E2bMessageQueueListingPageObjects.ackType);
				if (agIsExists(E2bMessageQueueListingPageObjects.ackType)) {
					Reports.ExtentReportLog("Acknowledgement XML View", Status.PASS,
							"Acknowledgement ACK XML successfull", true);
				} else {
					Reports.ExtentReportLog("Acknowledgement XML View", Status.FAIL,
							"Acknowledgement ACK XML unsuccessfull", true);
				}

				agClick(E2bMessageQueueListingPageObjects.ackType);
				agClick(E2bMessageQueueListingPageObjects.ackType);
				agSetStepExecutionDelay("3000");
				agClick(E2bMessageQueueListingPageObjects.ackTypeDropdown(E2bMessageQueueListingPageObjects.ackReport));
				if (agIsExists(E2bMessageQueueListingPageObjects
						.ackTypeDropdown(E2bMessageQueueListingPageObjects.ackReport))) {
					Reports.ExtentReportLog("Acknowledgement ACK REPORT View", Status.PASS,
							"Acknowledgement ACK REPORT successfull", true);
				} else {
					Reports.ExtentReportLog("Acknowledgement ACK REPORT View", Status.FAIL,
							"Acknowledgement ACK REPORT unsuccessfull", true);
				}

				agClick(E2bMessageQueueListingPageObjects.closeComments);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				break;
			}

		}

	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Fetch the Total File Count & File Name.
	 * @InputParameters: filepath
	 * @OutputParameters:
	 * @author:WajahatUmarS
	 * @Date : 09-01-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> GetFileCountName(String filepath) {

		ArrayList<String> File = new ArrayList<String>();
		DirectoryStream<Path> directoryStream;
		try {
			directoryStream = Files.newDirectoryStream(Paths.get(filepath));

			for (Path path : directoryStream) {
				File.add(path.getFileName().toString());
				// System.out.println("File Count:" + File.size());
				// System.out.println("File Name:" + path.getFileName());
			}
			Collections.sort(File);
		} catch (IOException e) {
			e.printStackTrace();
			System.out.print("File Count:" + File.size());
		}
		return File;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify download xml file.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 29-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void Verify_DownloadedFile(String FileName) {
		String path = lsmvConstants.LSMV_testDataOutput + "\\" + Reports.currenttime();
		lsmvConstants.path = path;
		System.out.println(lsmvConstants.path);

		FileSystemOperations.createFolder(path);
		FileSystemOperations.moveFile(FileName + ".xml", lsmvConstants.LSMV_testDataOutput, path);

		if (agIsExists(path)) {

			System.out.println("File exists");
			Reports.ExtentReportLog("", Status.INFO, "XML file exist", true);
		} else {

			System.out.println("File doesn't exist in specifiled path");
			Reports.ExtentReportLog("", Status.INFO, "XML file not exist", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Rename and move xml to folder
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 2-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void Verify_DownloadedXml(String OldFileName, String NewFileName) {
		String path = lsmvConstants.LSMV_destFolderPath;
		lsmvConstants.path = path;
		System.out.println(lsmvConstants.path);
		System.out.println("lsmvConstants.LSMV_testDataOutput: " + lsmvConstants.LSMV_testDataOutput);

		// FileSystemOperations.createFolder(path);
		FileSystemOperations.moveFile(OldFileName + ".xml", lsmvConstants.LSMV_testDataOutput, path);
		FileSystemOperations.renameFile(path, OldFileName + ".xml", NewFileName + ".xml");

		if (agIsExists(path)) {

			System.out.println("File exists");
			Reports.ExtentReportLog("", Status.INFO, "XML file exist", true);
		} else {

			System.out.println("File doesn't exist in specifiled path");
			Reports.ExtentReportLog("", Status.INFO, "XML file not exist", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download and verify xml file.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 29-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void DownloadAndVerifyXML(String FileName) {

		agWaitTillVisibilityOfElement(E2bMessageQueueListingPageObjects.clickToDownload);
		agClick(E2bMessageQueueListingPageObjects.clickToDownload);
		agWaitTillVisibilityOfElement(E2bMessageQueueListingPageObjects.downloadButton);
		agClick(E2bMessageQueueListingPageObjects.downloadButton);
		agSetStepExecutionDelay("12000");
		E2BMessageQueueOperations.Verify_DownloadedFile(FileName);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(E2bMessageQueueListingPageObjects.closeDownloadPopUp);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Rename and move xml to folder
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 16-July-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void Verify_XmlDownloaded(String OldFileName, String NewFileName) {
		String path = lsmvConstants.LSMV_WPAsourceFolderPath;
		lsmvConstants.path = path;
		System.out.println(lsmvConstants.path);

		// FileSystemOperations.createFolder(path);
		FileSystemOperations.moveFile(OldFileName + ".xml", lsmvConstants.LSMV_testDataOutput, path);
		FileSystemOperations.renameFile(path, OldFileName + ".xml", NewFileName + ".xml");

		boolean status = PDFOperations.isFileDownloaded(lsmvConstants.path + "\\", NewFileName + ".xml");

		if (status) {

			System.out.println("File exists");
			Reports.ExtentReportLog("", Status.INFO, "XML file exist", true);
		} else {

			System.out.println("File doesn't exist in specifiled path");
			Reports.ExtentReportLog("", Status.INFO, "XML file not exist", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is create to search based on Submission message
	 *             number in E2BMessageQueueListing
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 24-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchSubmissionMessageNumberCT(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ImportOperations");
		agSetStepExecutionDelay("5000");
		for (int i = 1; i < 10; i++) {
			CaseManagementOperations.caseManagement_MenuNavigations("e2bMessageQueueListing");
			agClick(E2bMessageQueueListingPageObjects.exportQueue);
			agSetValue(E2bMessageQueueListingPageObjects.exportsearch,
					getTestDataCellValue(scenarioName, "SubmissionMessageNo2").trim());
			agWaitTillInvisibilityOfElement(E2bMessageQueueListingPageObjects.loadingicon);
			agClick(E2bMessageQueueListingPageObjects.exportserachIcon);
			agWaitTillVisibilityOfElement(E2bMessageQueueListingPageObjects.exportprocessingStatus);
			String processingStatus = agGetText(E2bMessageQueueListingPageObjects.exportprocessingStatus);
			if (processingStatus.equals("Disposition Successful")) {
				Reports.ExtentReportLog("", Status.PASS, "Disposition Successful ", true);
				break;
			} else
				agClick(E2bMessageQueueListingPageObjects.exportserachIcon);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is create to search based on Submission message
	 *             number in E2BMessageQueueListing
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 24-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchSubmissionMessageNumberNonCT(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		String MessageNumber = SubmissionOperations.getMessageNumber(scenarioName, sheetName, columnName);
		agSetStepExecutionDelay("5000");
		for (int i = 1; i < 10; i++) {
			CaseManagementOperations.caseManagement_MenuNavigations("e2bMessageQueueListing");
			agClick(E2bMessageQueueListingPageObjects.exportQueue);
			agSetValue(E2bMessageQueueListingPageObjects.exportsearch, MessageNumber);
			agWaitTillInvisibilityOfElement(E2bMessageQueueListingPageObjects.loadingicon);
			agClick(E2bMessageQueueListingPageObjects.exportserachIcon);
			agWaitTillVisibilityOfElement(E2bMessageQueueListingPageObjects.exportprocessingStatus);
			String processingStatus = agGetText(E2bMessageQueueListingPageObjects.exportprocessingStatus);
			if (processingStatus.equals("Report Generation Succesful")) {
				Reports.ExtentReportLog("", Status.PASS, "Report Generation Succesful ", true);
				break;
			} else
				agClick(E2bMessageQueueListingPageObjects.exportserachIcon);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The Below method is create to search based on SafetyReportID in
	 *             E2BMessageQueueListing
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 09-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchSafetyReportID(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ImportOperations");
		CaseManagementOperations.caseManagement_MenuNavigations("e2bMessageQueueListing");
		agSetStepExecutionDelay("2000");
		agClick(E2bMessageQueueListingPageObjects.RefreshBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillInvisibilityOfElement(E2bMessageQueueListingPageObjects.loadingicon);
		agSetValue(E2bMessageQueueListingPageObjects.basicsearch_TextField,
				getTestDataCellValue(scenarioName, "SAFETYREPORTID").trim());
		agClick(E2bMessageQueueListingPageObjects.serachIcon);
		agWaitTillVisibilityOfElement(
				E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.messageNumber));
		String SafetyReportImportStatus = null;

		for (int i = 0; i < 15; i++) {
			agSetStepExecutionDelay("5000");
			agClick(E2bMessageQueueListingPageObjects.RefreshBtn);
			SafetyReportImportStatus = agGetText((E2bMessageQueueListingPageObjects
					.getTextColumn(E2bMessageQueueListingPageObjects.safetyImportStatus)));
			if (SafetyReportImportStatus.equals("Success")) {
				Reports.ExtentReportLog("", Status.PASS, "Success", true);
				break;
			} else
				agClick(E2bMessageQueueListingPageObjects.RefreshBtn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Rename and move xml to folder
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 15-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void Verify_WPADownloadedXml(String recieptNumber, String OldFileName, String NewFileName) {
		String path = lsmvConstants.LSMV_testDataOutput + "\\" + recieptNumber + "\\" + "FDE_Dest_XML";
		lsmvConstants.path = path;
		System.out.println(lsmvConstants.path);
		FileSystemOperations.createFolder(path);
		FileSystemOperations.moveFile(OldFileName + ".xml", lsmvConstants.LSMV_testDataOutput, path);
		FileSystemOperations.renameFile(path, OldFileName + ".xml", NewFileName + ".xml");

		boolean status = PDFOperations.isFileDownloaded(lsmvConstants.path + "\\", NewFileName + ".xml");

		if (status) {
			System.out.println("File exists");
			Reports.ExtentReportLog("", Status.PASS, "XML file exist", true);
		} else {

			System.out.println("File doesn't exist in specifiled path");
			Reports.ExtentReportLog("", Status.FAIL, "XML file not exist", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to get the receiptID of R2 imported
	 *             case from e2bMessageQueueListing.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 09-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void getReceiptIDofBatchImportCase(String scenarioName, String SheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ImportOperations");
		boolean record_found = false;
		for (int i = 0; i <= 12; i++) {
			searchSafetyReportID(scenarioName);
			agSetStepExecutionDelay("3000");
			record_found = true;
			agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects.ReceiptID);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			String receiptID = agGetText(E2bMessageQueueListingPageObjects.ReceiptID);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, SheetName, scenarioName, "ReceiptNo", receiptID);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "FDE_General", scenarioName, "ReceiptNo", receiptID);
			Reports.ExtentReportLog("Get ReceiptID of Imported case", Status.PASS,
					"Import case is displayed :: Receipt ID -" + receiptID, true);
			break;
		}
		if (!record_found) {
			Reports.ExtentReportLog("Get ReceiptID of Imported case", Status.FAIL, "Imported case is not displayed",
					true);
		}
	}

	public static void ImportXMLStatus(String scenarioName) {
		agSetStepExecutionDelay("2000");
		CaseManagementOperations.caseManagement_MenuNavigations("e2bMessageQueueListing");
		agSetStepExecutionDelay("2000");
		agClick(E2bMessageQueueListingPageObjects.RefreshBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		/*
		 * ArrayList<String> files = E2BMessageQueueOperations
		 * .GetFileCountName(lsmvConstants.lsmvXmlPath + "FDE_Input_XML\\");
		 */
		// for (int i = 0; i < files.size(); i++) {
		Connection dbCon = null;
		int rowCount = 0;
		try {
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);
			ResultSet rs = DataBaseOperations.performRead(dbCon,
					"Select * from lsmv_wpa_controller where Scenario='" + scenarioName + "'");

			rs.last();
			rowCount = rs.getRow();
			System.out.println("rowCount" + rowCount);
			// rs = DataBaseOperations.performRead(dbCon, "Select R3XMLImport_Message_Number
			// from lsmv_wpa_controller");
			rs.beforeFirst();
			for (int j = 0; j < rowCount; j++) {
				rs.next();

				String messageNumber = rs.getString("R3XMLImport_Message_Number");

				if (messageNumber == null) {
					continue;
				}

				// String recieptNumber = rs.getString("Case_Reciept_Number");
				// String scenarioName = rs.getString("Scenario");
				agWaitTillInvisibilityOfElement(E2bMessageQueueListingPageObjects.loadingicon);
				agAssertVisible(E2bMessageQueueListingPageObjects.basicsearch_TextField);
				agSetValue(E2bMessageQueueListingPageObjects.basicsearch_TextField, messageNumber.trim());
				agAssertVisible(E2bMessageQueueListingPageObjects.serachIcon);
				agClick(E2bMessageQueueListingPageObjects.serachIcon);
				agAssertVisible(E2bMessageQueueListingPageObjects.EmptyRow);
				String EmptyRowStatus = agGetText(E2bMessageQueueListingPageObjects.EmptyRow);
				// Refresh multiples times until case visible

				if (EmptyRowStatus.contains("No records to display")) {
					/*
					 * for (int k = 0; k <= 5; k++) { agSetStepExecutionDelay("2000");
					 * agClick(E2bMessageQueueListingPageObjects.serachIcon);
					 * agSetStepExecutionDelay(String.valueOf(Constants.
					 * defaultGlobalStepExecutionDelay)); // break; }
					 */
					continue;
				}
				String ProcessingStatus, XMLImportStatus, SafetyReportImportStatus, AdditionalComments = null;
				ProcessingStatus = agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.processingStatus));
				XMLImportStatus = agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.importStatus));
				SafetyReportImportStatus = agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.safetyImportStatus));
				AdditionalComments = agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));

				do {
					agSetStepExecutionDelay("2000");
					agClick(E2bMessageQueueListingPageObjects.RefreshBtn);
					agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
					ProcessingStatus = agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.processingStatus));
					XMLImportStatus = agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.importStatus));
					SafetyReportImportStatus = agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.safetyImportStatus));
					AdditionalComments = agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));

				} while (SafetyReportImportStatus.equals("Inprogress") || SafetyReportImportStatus.equals(""));

				if (ProcessingStatus.matches("Parsing") || XMLImportStatus.matches("Failure Import")
						|| SafetyReportImportStatus.matches("Failure")) {

					agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));
					System.out.println(agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments)));
					DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set XML_Import_Status= '"
							+ XMLImportStatus + "' where Scenario='" + scenarioName + "'");
					DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set Additional_Comments= '"
							+ AdditionalComments + "' where Scenario='" + scenarioName + "'");
					DataBaseOperations.performWrite(dbCon,
							"update lsmv_wpa_controller set Workflow_Status='Invalid' where Scenario='" + scenarioName
									+ "'");
					/*
					 * DataBaseOperations.performWrite(dbCon,
					 * "update lsmv_wpa_controller set Case_Reciept_Number= '"+
					 * agGetText(E2bMessageQueueListingPageObjects.ReceiptID) + "' where Scenario='"
					 * +scenarioName + "'");
					 */

					// break;
				} else if (ProcessingStatus.matches("Complete ( 9 of 9)")
						|| SafetyReportImportStatus.matches("Success")) {

					agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));
					agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.receiptNo));
					agSetStepExecutionDelay("2000");
					String rctNum = agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.receiptNo));
					agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
					DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set XML_Import_Status= '"
							+ XMLImportStatus + "' where Scenario='" + scenarioName + "'");
					DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set Additional_Comments= '"
							+ AdditionalComments + "' where Scenario='" + scenarioName + "'");
					DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set Receipt_Number= '" + rctNum
							+ "' where Scenario='" + scenarioName + "'");
					DataBaseOperations.performWrite(dbCon,
							"update lsmv_wpa_controller set Workflow_Status='Intake and Assessment' where Scenario='"
									+ scenarioName + "'");
					DataBaseOperations.performWrite(dbCon,
							"update fde_general set ReceiptNo= '" + rctNum + "' where Scenario='" + scenarioName + "'");
					Thread.sleep(5000);
					DataBaseOperations.performWrite(dbCon,
							"update lsmv_wpa_controller set CreationType= 'ImportR3XML' where Scenario='" + scenarioName
									+ "'");
					Thread.sleep(5000);

					// break;
				}

			}

		} catch (SQLException sqle) {
			// TODO Auto-generated catch block
			sqle.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Fetch the Status of Import XML File.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmarS
	 * @Date : 09-12-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void FetchRecieptNumberFromImportXML(String scenarioName) {
		getTestData(lsmvConstants.LSMV_testData, "ImportOperations");

		agSetStepExecutionDelay("2000");
		CaseManagementOperations.caseManagement_MenuNavigations("e2bMessageQueueListing");

		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		agWaitTillInvisibilityOfElement(E2bMessageQueueListingPageObjects.loadingicon);
		agAssertVisible(E2bMessageQueueListingPageObjects.basicsearch_TextField);
		agSetStepExecutionDelay("4000");
		agSetValue(E2bMessageQueueListingPageObjects.basicsearch_TextField,
				getTestDataCellValue(scenarioName, "MessageNo").trim());
		agAssertVisible(E2bMessageQueueListingPageObjects.serachIcon);
		agClick(E2bMessageQueueListingPageObjects.serachIcon);

		agWaitTillVisibilityOfElement(
				E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.messageNumber));

		String receiptID = null;
		for (int i = 0; i < 10; i++) {
			agSetStepExecutionDelay("2000");
			agClick(E2bMessageQueueListingPageObjects.importRefreshIcon);
			agSetValue(E2bMessageQueueListingPageObjects.basicsearch_TextField,
					getTestDataCellValue(scenarioName, "MessageNo").trim());
			agAssertVisible(E2bMessageQueueListingPageObjects.serachIcon);
			agClick(E2bMessageQueueListingPageObjects.serachIcon);

			if (agIsVisible(E2bMessageQueueListingPageObjects.ReceiptID) == true) {

				receiptID = agGetText(E2bMessageQueueListingPageObjects.ReceiptID);
				agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects.ReceiptID);
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
				String RecieptNumberPrefixs =getTestDataCellValue("LSMV_ISP_Config", "ReceiptPrefix");
				
				if(receiptID.contains(RecieptNumberPrefixs)) {
					Reports.ExtentReportLog("", Status.PASS, "Receipt Numbering Format - Prefix is getting Mapped With Created Reciept Number", true);
					
				}else {
					Reports.ExtentReportLog("", Status.FAIL, "Receipt Numbering Format - Prefix is getting Mapped  With Created Reciept Number", true);
				}
				
				CommonOperations.captureScreenShot(true);
				break;
			}
		}
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "FDE_General", scenarioName, "ReceiptNo", receiptID);

	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Fetch the Status of Import XML File.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmarS
	 * @Date : 09-01-2020
	 * @UpdatedByAndWhen: Karthikeyan Natarajan, 05-Aug-2020
	 **********************************************************************************************************/

	public static void ImportR2R3XMLStatus(String scenarioName, String XMLType) {
		agSetStepExecutionDelay("2000");
		CaseManagementOperations.caseManagement_MenuNavigations("e2bMessageQueueListing");
		agSetStepExecutionDelay("2000");
		agClick(E2bMessageQueueListingPageObjects.RefreshBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Connection dbCon = null;
		int rowCount = 0;
		try {
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);
			ResultSet rs = DataBaseOperations.performRead(dbCon,
					"Select * from lsmv_wpa_controller where CreationType='" + XMLType + "' and scenario='"
							+ scenarioName + "'");

			rs.last();
			rowCount = rs.getRow();
			System.out.println("rowCount" + rowCount);
			rs.beforeFirst();
			rs.next();

			String messageNumber = rs.getString("XMLImport_Message_Number");

			if (messageNumber == null) {
				Reports.ExtentReportLog("", Status.FAIL,
						"Message Number for scenario " + scenarioName + " is not generated", true);
				return;
			}

			agWaitTillInvisibilityOfElement(E2bMessageQueueListingPageObjects.loadingicon);
			agAssertVisible(E2bMessageQueueListingPageObjects.basicsearch_TextField);
			agSetValue(E2bMessageQueueListingPageObjects.basicsearch_TextField, messageNumber.trim());
			agAssertVisible(E2bMessageQueueListingPageObjects.serachIcon);
			agClick(E2bMessageQueueListingPageObjects.serachIcon);
			agAssertVisible(E2bMessageQueueListingPageObjects.EmptyRow);
			agWaitTillVisibilityOfElement(E2bMessageQueueListingPageObjects.EmptyRow);
			String EmptyRowStatus = agGetText(E2bMessageQueueListingPageObjects.EmptyRow);
			// Refresh multiples times until case visible

			if (EmptyRowStatus.contains("No records to display")) {
				DataBaseOperations.performWrite(dbCon,
						"update lsmv_wpa_controller set Workflow_Status='Message Number Not Found' where Scenario='"
								+ scenarioName + "'");
				Reports.ExtentReportLog("", Status.FAIL,
						"Given Message Number for scenario " + scenarioName + " fetches no records", true);
				return;
			}
			String ProcessingStatus, XMLImportStatus, SafetyReportImportStatus, AdditionalComments = null;
			ProcessingStatus = agGetText(E2bMessageQueueListingPageObjects
					.getTextColumn(E2bMessageQueueListingPageObjects.processingStatus));
			XMLImportStatus = agGetText(
					E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.importStatus));
			SafetyReportImportStatus = agGetText(E2bMessageQueueListingPageObjects
					.getTextColumn(E2bMessageQueueListingPageObjects.safetyImportStatus));
			AdditionalComments = agGetText(E2bMessageQueueListingPageObjects
					.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));

			do {
				agSetStepExecutionDelay("2000");
				agClick(E2bMessageQueueListingPageObjects.RefreshBtn);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				agWaitTillVisibilityOfElement((E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.processingStatus)));
				agSetStepExecutionDelay("2000");
				ProcessingStatus = agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.processingStatus));
				XMLImportStatus = agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.importStatus));
				SafetyReportImportStatus = agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.safetyImportStatus));
				AdditionalComments = agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			} while (SafetyReportImportStatus.equals("Inprogress") || SafetyReportImportStatus.equals(""));

			if (ProcessingStatus.matches("Parsing") || XMLImportStatus.matches("Failure Import")
					|| SafetyReportImportStatus.matches("Failure")) {

				agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));
				System.out.println(agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments)));
				DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set XML_Import_Status= '"
						+ XMLImportStatus + "' where Scenario='" + scenarioName + "'");
				DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set Additional_Comments= '"
						+ AdditionalComments + "' where Scenario='" + scenarioName + "'");
				DataBaseOperations.performWrite(dbCon,
						"update lsmv_wpa_controller set Workflow_Status='Invalid' where Scenario='" + scenarioName
								+ "'");

			} else if (ProcessingStatus.matches("Complete ( 9 of 9)") || SafetyReportImportStatus.matches("Success")) {

				agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));
				agJavaScriptExecuctorScrollToElement(
						E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.receiptNo));
				agSetStepExecutionDelay("2000");
				agWaitTillVisibilityOfElement(
						E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.receiptNo));
				String rctNum = agGetText(
						E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.receiptNo));
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
				String RecieptNumberPrefix =getTestDataCellValue("LSMV_ISP_Config", "ReceiptPrefix");
				
				if(rctNum.contains(RecieptNumberPrefix)) {
					Reports.ExtentReportLog("", Status.PASS, "Receipt Numbering Format - Prefix is getting Mapped With Created Reciept Number", true);
					
				}else {
					Reports.ExtentReportLog("", Status.FAIL, "Receipt Numbering Format - Prefix is getting Mapped  With Created Reciept Number", true);
				}
				
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set XML_Import_Status= '"
						+ XMLImportStatus + "' where Scenario='" + scenarioName + "'");
				DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set Additional_Comments= '"
						+ AdditionalComments + "' where Scenario='" + scenarioName + "'");
				DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set Receipt_Number= '" + rctNum
						+ "' where Scenario='" + scenarioName + "'");
				Thread.sleep(5000);
				DataBaseOperations.performWrite(dbCon,
						"update fde_general set ReceiptNo= '" + rctNum + "' where Scenario='" + scenarioName + "'");
				Thread.sleep(5000);
				DataBaseOperations.performWrite(dbCon,
						"update lsmv_wpa_controller set Workflow_Status='Intake and Assessment' where Scenario='"
								+ scenarioName + "'");
				Thread.sleep(5000);
				DataBaseOperations.performWrite(dbCon, "update advancesearchoperations set ReceiptNo='" + rctNum
						+ "' where Scenario='" + scenarioName + "'");
				Thread.sleep(5000);
				DataBaseOperations.performWrite(dbCon, "update advancesearchoperations set MessageNo='" + messageNumber
						+ "' where Scenario='" + scenarioName + "'");

				DataBaseOperations.performWrite(dbCon, "update dataassessmentoperations set ReceiptNo='" + rctNum
						+ "' where Scenario='" + scenarioName + "'");
			}

		} catch (SQLException sqle) {
			// TODO Auto-generated catch block
			sqle.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Fetch the Status of Imported XML File
	 *             without BD interaction.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @throws InterruptedException 
	 * @Date : 08-12-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void ImportR2R3XMLStatus(String scenarioName) throws InterruptedException {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ImportOperations");
		String rctNum, messageNumber, EmptyRowStatus = null;

		CaseManagementOperations.caseManagement_MenuNavigations("e2bMessageQueueListing");
		Thread.sleep(5000);
		agSetStepExecutionDelay("2000");
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.LoadingIcon);
		messageNumber = ImportOperations.getTestDataCellValue(scenarioName, "MessageNo");
		System.out.println("messageNumber: " + messageNumber);
		Thread.sleep(12000);
		agAssertVisible(E2bMessageQueueListingPageObjects.basicsearch_TextField);
		agSetValue(E2bMessageQueueListingPageObjects.basicsearch_TextField, messageNumber.trim());
		agSetStepExecutionDelay("3000");
		Thread.sleep(5000);
		agClick(E2bMessageQueueListingPageObjects.serachIcon);
		agWaitTillInvisibilityOfElement(E2bMessageQueueListingPageObjects.loadingicon);

		agWaitTillVisibilityOfElement(E2bMessageQueueListingPageObjects.EmptyRow);
		EmptyRowStatus = agGetText(E2bMessageQueueListingPageObjects.EmptyRow);
		if (EmptyRowStatus.contains("No records to display")) {
			Reports.ExtentReportLog("", Status.FAIL, messageNumber + ", message Number fetches no records", true);
		}

		String ProcessingStatus, XMLImportStatus, SafetyReportImportStatus, AdditionalComments = null;
		ProcessingStatus = agGetText(
				E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.processingStatus));
		XMLImportStatus = agGetText(
				E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.importStatus));
		SafetyReportImportStatus = agGetText(
				E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.safetyImportStatus));
		AdditionalComments = agGetText(
				E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));
		
		rctNum = agGetText(
				E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.receiptNo));
		if (rctNum != null) {
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "FDE_General", scenarioName, "ReceiptNo", rctNum);
			// Reports.ExtentReportLog("", Status.PASS,"", true);
		}
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
		String RecieptNumberPrefix =getTestDataCellValue("LSMV_ISP_Config", "ReceiptPrefix");
		
		if(rctNum.contains(RecieptNumberPrefix)) {
			Reports.ExtentReportLog("", Status.PASS, "Receipt Numbering Format - Prefix is getting Mapped With Created Reciept Number", true);
			
		}else {
			Reports.ExtentReportLog("", Status.FAIL, "Receipt Numbering Format - Prefix is getting Mapped With Created Reciept Number", true);
		}
		
		/*do {
			agSetStepExecutionDelay("2000");
			agClick(E2bMessageQueueListingPageObjects.refreshImportQueue);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agWaitTillVisibilityOfElement((E2bMessageQueueListingPageObjects
					.getTextColumn(E2bMessageQueueListingPageObjects.processingStatus)));
			agSetStepExecutionDelay("2000");
			messageNumber = ImportOperations.getTestDataCellValue(scenarioName, "MessageNo");
			System.out.println("messageNumber: " + messageNumber+": Inside Do");
			agAssertVisible(E2bMessageQueueListingPageObjects.basicsearch_TextField);
			agSetValue(E2bMessageQueueListingPageObjects.basicsearch_TextField, messageNumber.trim());
			agAssertVisible(E2bMessageQueueListingPageObjects.serachIcon);
			agClick(E2bMessageQueueListingPageObjects.serachIcon);
			agWaitTillInvisibilityOfElement(E2bMessageQueueListingPageObjects.loadingicon);
			ProcessingStatus = agGetText(E2bMessageQueueListingPageObjects
					.getTextColumn(E2bMessageQueueListingPageObjects.processingStatus));
			XMLImportStatus = agGetText(E2bMessageQueueListingPageObjects
					.getTextColumn(E2bMessageQueueListingPageObjects.importStatus));
			SafetyReportImportStatus = agGetText(E2bMessageQueueListingPageObjects
					.getTextColumn(E2bMessageQueueListingPageObjects.safetyImportStatus));
			AdditionalComments = agGetText(E2bMessageQueueListingPageObjects
					.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} while (SafetyReportImportStatus.equals("In Progress"));*/
		
		//while (SafetyReportImportStatus.equals("Inprogress") || SafetyReportImportStatus.equals("")) {
			/*agSetStepExecutionDelay("2000");
			agClick(E2bMessageQueueListingPageObjects.refreshImportQueue);
			agWaitTillInvisibilityOfElement(E2bMessageQueueListingPageObjects.loadingicon);
			agSetStepExecutionDelay("2000");

			messageNumber = ImportOperations.getTestDataCellValue(scenarioName, "MessageNo");
			System.out.println("messageNumber: " + messageNumber);
			agAssertVisible(E2bMessageQueueListingPageObjects.basicsearch_TextField);
			agSetValue(E2bMessageQueueListingPageObjects.basicsearch_TextField, messageNumber.trim());
			agAssertVisible(E2bMessageQueueListingPageObjects.serachIcon);
			agWaitTillInvisibilityOfElement(E2bMessageQueueListingPageObjects.loadingicon);
			agSetStepExecutionDelay("3000");*/

			ProcessingStatus = agGetText(E2bMessageQueueListingPageObjects
					.getTextColumn(E2bMessageQueueListingPageObjects.processingStatus));
			XMLImportStatus = agGetText(
					E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.importStatus));
			SafetyReportImportStatus = agGetText(E2bMessageQueueListingPageObjects
					.getTextColumn(E2bMessageQueueListingPageObjects.safetyImportStatus));
			AdditionalComments = agGetText(E2bMessageQueueListingPageObjects
					.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			rctNum = agGetText(
					E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.receiptNo));
			if (rctNum != null) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "FDE_General", scenarioName, "ReceiptNo",
						rctNum);
				// Reports.ExtentReportLog("", Status.PASS,"", true);
			}

			else if (ProcessingStatus.matches("(.*)Parsing(.*)") || XMLImportStatus.matches("(.*)Failure Import(.*)")
					|| SafetyReportImportStatus.matches("Failure")) {

				agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));
				System.out.println(agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments)));
				Reports.ExtentReportLog("", Status.FAIL, "", true);
			}


			else if (ProcessingStatus.matches("(.*)Complete ( 9 of 9)(.*)")
					|| SafetyReportImportStatus.matches("(.*)Success(.*)")) {
				agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));
				agJavaScriptExecuctorScrollToElement(
						E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.receiptNo));
				agGetText(E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.receiptNo));
				
				Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
				String RecieptNumberPrefixs =getTestDataCellValue("LSMV_ISP_Config", "ReceiptPrefix");
				
				if(agGetText(E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.receiptNo)).contains(RecieptNumberPrefixs)) {
					Reports.ExtentReportLog("", Status.PASS, "Receipt Numbering Format - Prefix is getting Mapped With Created Reciept Number", true);
					
				}else {
					Reports.ExtentReportLog("", Status.FAIL, "Receipt Numbering Format - Prefix is getting Mapped  With Created Reciept Number", true);
				}
				
				
				
				System.out.println("E2bMessageQueueListingPageObjects.receiptNo: " + agGetText(
						E2bMessageQueueListingPageObjects.getTextColumn(E2bMessageQueueListingPageObjects.receiptNo)));
			
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "FDE_General", scenarioName, "ReceiptNo",
						agGetText(E2bMessageQueueListingPageObjects
								.getTextColumn(E2bMessageQueueListingPageObjects.receiptNo)));
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				Reports.ExtentReportLog("", Status.PASS, "", true);
			}

		}
	//}
	
	
	@SuppressWarnings("unused")
	public static Boolean ImportStatus(String scenarioName,String SheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, SheetName);
		String messageNumber =getTestDataCellValue(scenarioName, "MessageNo");
		agSetStepExecutionDelay("2000");
		CaseManagementOperations.caseManagement_MenuNavigations("e2bMessageQueueListing");
		agSetStepExecutionDelay("2000");
		agClick(E2bMessageQueueListingPageObjects.importRefreshIcon);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		
				agWaitTillInvisibilityOfElement(E2bMessageQueueListingPageObjects.loadingicon);
				agAssertVisible(E2bMessageQueueListingPageObjects.basicsearch_TextField);
				
				agSetValue(E2bMessageQueueListingPageObjects.basicsearch_TextField, messageNumber.trim());
				agAssertVisible(E2bMessageQueueListingPageObjects.serachIcon);
				agClick(E2bMessageQueueListingPageObjects.serachIcon);
				agAssertVisible(E2bMessageQueueListingPageObjects.EmptyRow);
				String EmptyRowStatus = agGetText(E2bMessageQueueListingPageObjects.EmptyRow);
				// Refresh multiples times until case visible

				if (messageNumber == null) {
					Reports.ExtentReportLog("", Status.FAIL,
							"Message Number for scenario " + scenarioName + " is not generated", true);
					return false;
				}
				String ProcessingStatus, XMLImportStatus, SafetyReportImportStatus, AdditionalComments = null;
				ProcessingStatus = agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.processingStatus));
				XMLImportStatus = agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.importStatus));
				SafetyReportImportStatus = agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.safetyImportStatus));
				AdditionalComments = agGetText(E2bMessageQueueListingPageObjects
						.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));

				do {
					agSetStepExecutionDelay("2000");
					agClick(E2bMessageQueueListingPageObjects.importRefreshIcon);
					
					ProcessingStatus = agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.processingStatus));
					XMLImportStatus = agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.importStatus));
					SafetyReportImportStatus = agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.safetyImportStatus));
					AdditionalComments = agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));
					agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				} while (SafetyReportImportStatus.equals("Inprogress") || SafetyReportImportStatus.equals(""));

				if (ProcessingStatus.matches("Parsing") || XMLImportStatus.matches("Failure Import")
						|| SafetyReportImportStatus.matches("Failure")) {

					agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));
					System.out.println(agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments)));
					
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "XMLImportStatus", XMLImportStatus);
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AdditionalComments", AdditionalComments);

				} else if (ProcessingStatus.matches("Complete ( 9 of 9)")
						|| SafetyReportImportStatus.matches("Success")) {

					agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.additionalComments));
					agJavaScriptExecuctorScrollToElement(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.receiptNo));
					agSetStepExecutionDelay("2000");
					String rctNum = agGetText(E2bMessageQueueListingPageObjects
							.getTextColumn(E2bMessageQueueListingPageObjects.receiptNo));
					agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
					System.out.println("XMLImportStatus "+XMLImportStatus+" AdditionalComments"+AdditionalComments+" rctNum"+rctNum);
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "XMLImportStatus", XMLImportStatus);
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AdditionalComments", AdditionalComments);
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptNo", rctNum);
				}
				return false;

			}
}
