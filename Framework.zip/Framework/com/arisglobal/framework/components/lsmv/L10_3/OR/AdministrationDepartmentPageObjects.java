package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class AdministrationDepartmentPageObjects {

	public static String departmentLabel = "xpath#//label[text()='Department']";
	public static String downloadIcon = "xpath#//img[contains(@src,'Gear_off_new')]";
	public static String quickColFilterIcon = "xpath#//a[@id='deptListform:filterId']";
	public static String columnSelectionIcon = "xpath#//button[@id='deptListform:lazyDataTable:toggler']";
	public static String refreshLink = "xpath#//img[@title='Refresh Listing Screen']";
	public static String keywordSearchTextbox = "xpath#//input[@id='deptListform:keywordSearch']";
	public static String keywordSearchButton = "xpath#//a[@id='deptListform:searchId']";
	public static String newButton = "xpath#//a[@id='deptListform:newId']";
	public static String deleteButton = "xpath#//a[@id='deptListform:deleteDepartment']";

	public static String deptNameTextbox = "xpath#//input[@id='deptFormId:deptNew']";
	public static String contactPersonTextbox = "xpath#//input[@id='deptFormId:deptperson']";
	public static String phoneCountryCodeTextbox = "xpath#//input[@id='deptFormId:deptcountry']";
	public static String phoneAredCodeTextbox = "xpath#//input[@id='deptFormId:deptArea']";
	public static String phoneNoTextbox = "xpath#//input[@id='deptFormId:deptNumber']";
	public static String faxCountryCodeTextbox = "xpath#//input[@id='deptFormId:deptfaxcountry']";
	public static String faxAreaCodeTextbox = "xpath#//input[@id='deptFormId:deptfaxArea']";
	public static String faxNoTextbox = "xpath#//input[@id='deptFormId:deptfaxNumber']";
	public static String emailIDTextbox = "xpath#//input[@id='deptFormId:deptEmail']";

	public static String corresMailServerDropdown = "xpath#//div[@id='deptFormId:corresmailServerDropdown']";
	public static String saveButton = "xpath#//button[@id='deptFormId:visibleSave']";
	public static String cancelButton = "xpath#//button[@id='deptFormId:cancelId']";

	public static String reportNotificationChkbox = "xpath#//div[@id='deptFormId:reportNotifications']";
	public static String sourceDocChkbox = "xpath#//label[text()='Source Document']";
	public static String supportDocChkbox = "xpath#//label[text()='Support Document']";
	public static String caseSummaryChkbox = "xpath#//label[text()='Case Summary Sheet']";
	public static String e2bXMLChkbox = "xpath#//label[text()='E2B XML']";

	public static String paginator = "xpath#//div[contains(@id,'DataTable_paginator_top')]/span[@class='ui-paginator-current']";

	public static String validation_Popup = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String validationOk_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']";

	public static String editIcon = "xpath#//img[@id='deptListform:lazyDataTable:0:editImgId']";
	public static String noRecordsText = "xpath#//tbody[contains(@id,'lazyDataTable_data')]/tr/td[text()='No records found.']";
	public static String export_Btn = "xpath#//button[contains(@id,'submitId')]";
	public static String exportCancel_Btn = "xpath#//button[contains(@id,'cancelDialogId')]";
}
