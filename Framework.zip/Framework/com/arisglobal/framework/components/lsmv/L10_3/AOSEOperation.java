package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AOSEPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.aventstack.extentreports.Status;

public class AOSEOperation extends ToolManager {
	
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to navigate to AOSE 
	 * @InputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 03-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void navigateToAOSE() {	
		
		agIsVisible(AOSEPageObjects.AOSEIcon);
		agClick(AOSEPageObjects.AOSEIcon);
		agSetStepExecutionDelay("5000");
		status = agIsVisible(AOSEPageObjects.validationPopUp);
		if(status) {
			agClick(AOSEPageObjects.okBtn);
		}		
		 agIsVisible(AOSEPageObjects.AOSEHeader);		
		 status = agIsVisible(AOSEPageObjects.companyUnit);
		if(status) {
			Reports.ExtentReportLog("", Status.PASS, "AOSE Records Exist Successfully", true);
		}else {
			Reports.ExtentReportLog("", Status.FAIL, "AOSE Records not Exist", true);
		}		
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to download compare report under AOSE PopUP 	 
	 * @InputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 05-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void compareAndDownload(String FileName) {
		agIsVisible(AOSEPageObjects.compareBtn);
		agClick(AOSEPageObjects.compareBtn);
		try {
			Thread.sleep(15000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}	
		CommonOperations.move_Downloadedexcel(FileName);
		Reports.ExtentReportLog("", Status.INFO, "Report downloaded successfully", true);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to generate and download report under AOSE PopUP	 
	 * @InputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 05-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void generateReport(String FileName) {
		agIsVisible(AOSEPageObjects.generateReport);
		agClick(AOSEPageObjects.generateReport);
		CommonOperations.agSwitchFrameByLocator(AOSEPageObjects.embedid);
		agIsVisible(AOSEPageObjects.openBtn);
		agJavaScriptExecuctorClick(AOSEPageObjects.openBtn);
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		CommonOperations.move_DownloadedFile(FileName);	
		Reports.ExtentReportLog("", Status.INFO, "Report Generate successfully", true);
		CommonOperations.agSwitchToDefaultFrame();
		agJavaScriptExecuctorClick(AOSEPageObjects.closeBtn);	
		agJavaScriptExecuctorClick(AOSEPageObjects.closeAOSEPopUp);
	}
}
