package com.arisglobal.framework.components.lsmv.L10_3;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.DocumentsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.TemplatesPageObjects;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.aventstack.extentreports.Status;

public class DocumentsOperations extends ToolManager{
	public static WebElement webElement;
	static String className = TemplatesOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	
	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in templates Module
	 * @InputParameters: pageObject
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 20-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void menuNavigation(String pageObject) {
		agMouseHover(DocumentsPageObjects.DocumentsHover);
		agClick(pageObject);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in templates Module and verify the label name
	 * @InputParameters: menu
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 20-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void documentsNavigations(String menu) {
		switch (menu) {
	case "DocumentListing":
		menuNavigation(DocumentsPageObjects.DocumentListing);
		agSetStepExecutionDelay("3000");
		status = agIsVisible(DocumentsPageObjects.basicsearchTextbox);
	
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Navigation to documents Listing is successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Navigation to documents Listing is Unsuccessfull", true);
		}
		break;
	default:
		System.out.println("Invalid Menu Link!");
		}
		
	
	}
}
