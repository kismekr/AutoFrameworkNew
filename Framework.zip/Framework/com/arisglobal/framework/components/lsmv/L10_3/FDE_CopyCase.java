package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDEFormCopyWindowPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDEMoreOptionsPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_CopyCase extends ToolManager {
	static boolean status;
	static String className = FDE_CopyCase.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();

	/**********************************************************************************************************
	 * @Objective: The below method will write copied receipt number to datasheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 24-jun-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void writeCopyReceiptNo(String scenarioName) {
		status = agIsVisible(FDEFormCopyWindowPageObjects.copyCaseReceiptNumber);
		if (status) {
			String copiedReceiptNumber = agGetText(FDEFormCopyWindowPageObjects.copyCaseReceiptNumber);
			String[] arrOfStr = copiedReceiptNumber.split("copied as");
			arrOfStr = arrOfStr[1].split("and available");
			copiedReceiptNumber = arrOfStr[0].trim();
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CopiedReceiptNo",
					copiedReceiptNumber);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
			String RecieptNumberPrefix =getTestDataCellValue("LSMV_ISP_Config", "ReceiptPrefix");
			
			if(copiedReceiptNumber.contains(RecieptNumberPrefix)) {
				Reports.ExtentReportLog("", Status.PASS, "Receipt Numbering Format - Prefix is getting Mapped in Created Copied Reciept Number", true);
				
			}else {
				Reports.ExtentReportLog("", Status.FAIL, "Receipt Numbering Format - Prefix is getting Mapped in Created Copied Reciept Number", true);
			}
			if (scenarioName.contains("QBEBasedonCaseDocuments")) {
				CommonOperations.captureScreenShot(true);
				
			}else if(!scenarioName.contains("QBEBasedonCaseDocuments")){
			Reports.ExtentReportLog("Copy case", Status.INFO,
					"Copy case creation successfull :: receiptNumber-" + copiedReceiptNumber, false);
			}
			else {
			Reports.ExtentReportLog("Copy case", Status.FAIL, "Copy case creation unsuccessfull", true);
		}
		}
			
		
	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method will search the case based on Receipt ID and
	 *             edit the case to perform copy case.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 24-jun-2019
	 * @UpdatedByAndWhen:WajahatUmar S
	 **********************************************************************************************************/
	public static void copyCase(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		FDE_Operations.MoreOptionsLinksNavigation(FDEMoreOptionsPageObjects.moreOptions("Copy"));
		agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.moreOptions("Copy"));
		agIsVisible(FDEFormCopyWindowPageObjects.VerifyReciptNumber);

		if (scenarioName.contains("QBEBasedonCaseDocuments")) {
			Reports.ExtentReportLog("Receipt No", Status.INFO, "Copy Case Window", true);
		} else {
			String VerifyReciptNum = agGetText(FDEFormCopyWindowPageObjects.VerifyReciptNumber);
			String VerifyReptNo[] = VerifyReciptNum.split("Copy > ");
			System.out.println(VerifyReptNo[1]);
			agSetStepExecutionDelay("2000");
			// To Verify if Receipt Number in Full Data Entry page Matches with Receipt
			// Number in Copy Case Pop Up
			// agCheckPropertyText(FDE_CopyCase.getData(scenarioName,
			// "ReceiptNo"),FDE_CopyCase.getData(scenarioName, "CopiedReceiptNo"));
			if (getTestDataCellValue(scenarioName, "ReceiptNo").equalsIgnoreCase(VerifyReptNo[1])) {
				Reports.ExtentReportLog("Receipt No", Status.INFO,
						"Receipt Number " + getTestDataCellValue(scenarioName, "ReceiptNo")
								+ " Matches successfull with ::" + VerifyReptNo[1],
						false);

			} else {
				Reports.ExtentReportLog("Receipt No", Status.FAIL, "Receipt Number "
						+ getTestDataCellValue(scenarioName, "ReceiptNo") + " Doesn't Matches with -" + VerifyReptNo[1],
						false);
			}
		}
		if (getTestDataCellValue(scenarioName, "Receipt Details").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.receiptDetails_CheckBox));
		}
		if (getTestDataCellValue(scenarioName, "Classify as New").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.ClassfyasNew_CheckBox));
		}
		// if(getTestDataCellValue(scenarioName, "Document").equalsIgnoreCase("True")) {
		// agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.Documents_CheckBox));
		// }
		if (getTestDataCellValue(scenarioName, "Correspondence").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.Correspondence_CheckBox));
		}
		if (getTestDataCellValue(scenarioName, "Retain Activity").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.Retain_ActivityChkbox));
		}
		if (getTestDataCellValue(scenarioName, "Notes").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.Notes_CheckBox));
		}

		if (getTestDataCellValue(scenarioName, "Linked Cases").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.LinkedCases_CheckBoxLabel));
		}
		// if(getTestDataCellValue(scenarioName, "Retain
		// Activity").equalsIgnoreCase("True")) {
		// agClick(FDEFormCopyWindowPageObjects.Retain_Activity);
		// }
		if (getTestDataCellValue(scenarioName, "Form Data").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.FormData_CheckBox));
		}
		if (getTestDataCellValue(scenarioName, "General").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.General_CheckBox));
		}

		if (getTestDataCellValue(scenarioName, "Source").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.Source_CheckBox));
		}

		if (getTestDataCellValue(scenarioName, "Reporter").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.Reporter_CheckBox));
		}

		if (getTestDataCellValue(scenarioName, "Study").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.Study_CheckBox));
		}

		if (getTestDataCellValue(scenarioName, "Patient").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.Patient_CheckBox));
		}

		if (getTestDataCellValue(scenarioName, "Parent").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.Parent_CheckBox));
		}

		if (getTestDataCellValue(scenarioName, "Product").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.Product_CheckBox));
		}

		if (getTestDataCellValue(scenarioName, "Event").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.Event_CheckBox));
		}
		if (getTestDataCellValue(scenarioName, "Narrative").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.Narrative_CheckBox));
		}
		if (getTestDataCellValue(scenarioName, "Pregnancy").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.Pregnancy_CheckBox));
		}
		if (getTestDataCellValue(scenarioName, "LabData").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.LabData_CheckBox));
		}

		if (getTestDataCellValue(scenarioName, "Literature").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.Literature_CheckBox));
		}
		if (getTestDataCellValue(scenarioName, "EditCopiedCase").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.EditCopiedCase_CheckBox));
		}

		if (getTestDataCellValue(scenarioName, "CopyIntoMultipleCases").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.CopyInto_CheckBox));
		}

		if (getTestDataCellValue(scenarioName, "LinkCopiedCase").equalsIgnoreCase("True")) {
			agClick(CommonPageObjects.ManualCheckBoxNew(FDEFormCopyWindowPageObjects.LinkCopiedCase_CheckBox));

		}
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.receiptDetails_CheckBox,
		// getTestDataCellValue(scenarioName, "Receipt Details"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.ClassfyasNew_CheckBox,
		// getTestDataCellValue(scenarioName, "Classify as New"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.Correspondence_CheckBox,
		// getTestDataCellValue(scenarioName, "Correspondence"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.ClassfyasNew_CheckBox,
		// getTestDataCellValue(scenarioName, "Receipt Details"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.Documents_CheckBox,
		// getTestDataCellValue(scenarioName, "Documents"));
		// //CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.Notes_CheckBox,
		// getTestDataCellValue(scenarioName, "Notes"));
		//
		// if(getTestDataCellValue(scenarioName, "Linked
		// Cases").equalsIgnoreCase("True")) {
		// agClick(FDEFormCopyWindowPageObjects.LinkedCases_CheckBox);
		// }
		// CommonOperations.clickCheckBoxRightOf(FDEFormCopyWindowPageObjects.LinkedCases_CheckBox,
		// getTestDataCellValue(scenarioName, "Linked Cases"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.FormData_CheckBox,
		// getTestDataCellValue(scenarioName, "Form Data"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.General_CheckBox,
		// getTestDataCellValue(scenarioName, "General"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.Source_CheckBox,
		// getTestDataCellValue(scenarioName, "Source"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.Reporter_CheckBox,
		// getTestDataCellValue(scenarioName, "Reporter"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.Study_CheckBox,
		// getTestDataCellValue(scenarioName, "Study"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.Patient_CheckBox,
		// getTestDataCellValue(scenarioName, "Patient"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.Parent_CheckBox,
		// getTestDataCellValue(scenarioName, "Parent"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.Product_CheckBox,
		// getTestDataCellValue(scenarioName, "Product"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.Event_CheckBox,
		// getTestDataCellValue(scenarioName, "Event"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.Narrative_CheckBox,
		// getTestDataCellValue(scenarioName, "Narrative"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.Pregnancy_CheckBox,
		// getTestDataCellValue(scenarioName, "Pregnancy"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.LabData_CheckBox,
		// getTestDataCellValue(scenarioName, "LabData"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.Literature_CheckBox,
		// getTestDataCellValue(scenarioName, "Literature"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.EditCopiedCase_CheckBox,
		// getTestDataCellValue(scenarioName, "EditCopiedCase"));
		// CommonOperations.clickCheckBoxLeftOf(FDEFormCopyWindowPageObjects.CopyInto_CheckBox,
		// getTestDataCellValue(scenarioName, "CopyIntoMultipleCases"));
		//
		//

		if (getTestDataCellValue(scenarioName, "SourceDocument_CheckBox").equalsIgnoreCase("True")) {
			agClick(FDEFormCopyWindowPageObjects.SourceDocumentCheckBox);
		}
		if (getTestDataCellValue(scenarioName, "SupportDocument_CheckBox").equalsIgnoreCase("True")) {
			agClick(FDEFormCopyWindowPageObjects.SupportDocumentCheckBox);
		}
		if (scenarioName.contains("QBEBasedonCaseDocuments")) {
			ToolManager.agJavaScriptExecuctorScrollToElement(FDEFormCopyWindowPageObjects.SupportDocumentCheckBox);
			CommonOperations.captureScreenShot(true);
		}
		agSetValue(FDEFormCopyWindowPageObjects.copyCaseCommentTextarea,
				getTestDataCellValue(scenarioName, "CopyReceiptComment"));
		agClick(FDEFormCopyWindowPageObjects.copyButton);
		agSetStepExecutionDelay("4000");
		CommonOperations.agwaitTillVisible(FDEFormCopyWindowPageObjects.copyCaseReceiptNumber);
		writeCopyReceiptNo(scenarioName);
		agSetStepExecutionDelay("3000");
		agJavaScriptExecuctorClick(FDEFormCopyWindowPageObjects.okButton);
		agSetStepExecutionDelay("5000");
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Write data into excel sheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, columnName, data);
	}
}