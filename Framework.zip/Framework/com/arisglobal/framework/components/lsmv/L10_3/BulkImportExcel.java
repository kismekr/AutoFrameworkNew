package com.arisglobal.framework.components.lsmv.L10_3;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.BulkImportExcelPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DataBaseOperations;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class BulkImportExcel extends ToolManager {

	static String className = BulkImportExcel.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: The below Method is created to do Bulk Import via Excel
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void bulkImportExcel() {
		Reports.ExtentReportLog("", Status.INFO, "Bulk Import Starts", false);
		try {
			agSetStepExecutionDelay("3000");
			String bulkImportExcelPath = lsmvConstants.lsmvE2EScenarioPath + "BulkImportExcel\\BulkImportExcel.xlsx";
			CaseManagementOperations.caseManagement_MenuNavigations("bulkImports");
			agWaitTillVisibilityOfElement(BulkImportExcelPageObjects.addImportBtn);
			agClick(BulkImportExcelPageObjects.addImportBtn);
			agWaitTillVisibilityOfElement(BulkImportExcelPageObjects.ImportNameTxt);
			String importName = "BIE-" + System.currentTimeMillis();
			agSetValue(BulkImportExcelPageObjects.ImportNameTxt, importName);
			agClick(BulkImportExcelPageObjects.templateDropDown);
			agClick(BulkImportExcelPageObjects.templateSelect("BulkImportAutomation"));
			agSetStepExecutionDelay("4000");
			agSetValue(BulkImportExcelPageObjects.uploadExcelBtn, bulkImportExcelPath);
			Reports.ExtentReportLog("", Status.INFO, "Bulk Import Details", true);
			agClick(BulkImportExcelPageObjects.saveImportBtn);
			agSetStepExecutionDelay(Constants.defaultGlobalStepExecutionDelay + "");
			agSetStepExecutionDelay("3000");
			agWaitTillVisibilityOfElement(BulkImportExcelPageObjects.importExcelOkBtn);
			Reports.ExtentReportLog("", Status.INFO, "Bulk Import Saved", true);
			agClick(BulkImportExcelPageObjects.importExcelOkBtn);
			CaseManagementOperations.caseManagement_MenuNavigations("bulkImports");
			searchImport(importName);
			agWaitTillVisibilityOfElement(BulkImportExcelPageObjects.importChkBoxSelect);
			agClick(BulkImportExcelPageObjects.importChkBoxSelect);
			agClick(BulkImportExcelPageObjects.importSubmitBtn);
			agWaitTillVisibilityOfElement(BulkImportExcelPageObjects.importExcelOkBtn);
			Reports.ExtentReportLog("", Status.INFO, "Bulk Import Submitted", true);
			agClick(BulkImportExcelPageObjects.importExcelOkBtn);
			agSetStepExecutionDelay(Constants.defaultGlobalStepExecutionDelay + "");
			String importStatus = agGetText(BulkImportExcelPageObjects.importStatus);
			int counter = 0;
			while (!importStatus.equalsIgnoreCase("Processed") && counter < 50) {
				System.out.println(counter);
				if (importStatus.equalsIgnoreCase("Failed")) {
					Reports.ExtentReportLog("", Status.FAIL, "Bulk Import Failed", true);
					break;
				} else if (importStatus.equalsIgnoreCase("Submitted")) {
					try {
						Thread.sleep(10000);
					} catch (Exception e) {
						e.printStackTrace();
						// TODO: handle exception
					}
					agSetStepExecutionDelay("3000");
					agClick(BulkImportExcelPageObjects.importRefresh);
					agSetStepExecutionDelay(Constants.defaultGlobalStepExecutionDelay + "");
					counter++;
					agSetStepExecutionDelay("3000");
					importStatus = agGetText(BulkImportExcelPageObjects.importStatus);
					agSetStepExecutionDelay(Constants.defaultGlobalStepExecutionDelay + "");
				}
			}
			importStatus = agGetText(BulkImportExcelPageObjects.importStatus);
			boolean processed = false;
			if (importStatus.equalsIgnoreCase("Processed"))
				processed = true;
			if (processed)
				openImport();
			else
				Reports.ExtentReportLog("", Status.FAIL, "Bulk Import Faied with " + importStatus + " Status", true);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Bulk Import Failed", true);

		}

		Reports.ExtentReportLog("", Status.INFO, "Bulk Import Ends", false);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to search Bulk Import saved
	 * @InputParameters:importName
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void searchImport(String importName) {
		agWaitTillVisibilityOfElement(BulkImportExcelPageObjects.importSearchTxt);
		agSetValue(BulkImportExcelPageObjects.importSearchTxt, importName);
		agClick(BulkImportExcelPageObjects.importSearch);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to Open Bulk Import submitted
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void openImport() {
		agClick(BulkImportExcelPageObjects.editImport);
		Reports.ExtentReportLog("", Status.INFO, "Import RCT number Details", true);
		agWaitTillVisibilityOfElement(BulkImportExcelPageObjects.ImportNameTxt);
		List<WebElement> rowCount = agGetElementList(BulkImportExcelPageObjects.totalRowCount);

		for (int index = 1; index <= rowCount.size() - 1; index++) {
			String scenarioName = agGetText(BulkImportExcelPageObjects.scenarioNameSelect(index + ""));
			String rctNumber = agGetText(BulkImportExcelPageObjects.rctNumSelect(index + ""));
			String[] rct = rctNumber.split("Receipt number ");
			rctNumber = rct[1].trim();
			System.out.println("Row: " + index + ":ScenarioName: " + scenarioName);
			System.out.println("Row: " + index + ":RctNumber: " + rctNumber);
			bulkImportExcelDBOperations(scenarioName, rctNumber);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to update table values for scenarios
	 *             created via bulk import through excel
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 29-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void bulkImportExcelDBOperations(String scenarioName, String rctNumber) {
		Connection dbCon = null;
		try {
			dbCon = DataBaseOperations.getDBConnection(DataBaseOperations.getDBName(), Constants.DB_UserName,
					Constants.DB_Password);
			DataBaseOperations.performWrite(dbCon, "update lsmv_wpa_controller set Receipt_Number= '" + rctNumber
					+ "' where Scenario='" + scenarioName + "'");
			DataBaseOperations.performWrite(dbCon,
					"update lsmv_wpa_controller set Workflow_Status= 'Intake and Assessment' " + "where Scenario='"
							+ scenarioName + "'");
			DataBaseOperations.performWrite(dbCon,
					"update fde_general set ReceiptNo= '" + rctNumber + "' where Scenario='" + scenarioName + "'");
			DataBaseOperations.performWrite(dbCon, "update dataassessmentoperations set ReceiptNo= '" + rctNumber
					+ "' where Scenario='" + scenarioName + "'");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				dbCon.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
