package com.arisglobal.framework.components.lsmv.L10_3;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.ApplicationParameterPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class applicationParameterOperations extends ToolManager{
	public static WebElement webElement;
	static String className = applicationParameterOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to select dropdown value in application parameter
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 15-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/		
	public static void setDropDown(String label, String scenarioName, String colName){
         agClick(ApplicationParameterPageObjects.clickDropdown(label));
         agClick(ApplicationParameterPageObjects.setDropdown(getTestDataCellValue(scenarioName, colName)));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to set date format.
	 * @InputParameters: Scenario Name 
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 15-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void setDateFormat(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(ApplicationParameterPageObjects.disclaimerMessage_Label);
		setDropDown(ApplicationParameterPageObjects.timeZonePreference,scenarioName,"TimeZonePreference");
		setDropDown(ApplicationParameterPageObjects.dateFormat,scenarioName,"DateFormat");
		agClick(ApplicationParameterPageObjects.save_Btn);
		String validation = agGetText(ApplicationParameterPageObjects.validationPopup);
		status = agIsVisible(ApplicationParameterPageObjects.validationPopup);
		if (status) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Message"), ApplicationParameterPageObjects.validationPopup);
			Reports.ExtentReportLog("", Status.PASS, "Message :"+validation, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Message :"+validation, true);
		}
      
	agClick(ApplicationParameterPageObjects.ok_Btn);
	}
	
	
	
}