package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;
 
public class FDE_CaseDataEntry extends ToolManager{
	static String className = FDE_CaseDataEntry.class.getSimpleName();
	static boolean status;
	
	public static void caseManagement(String sn, String tcApplicableForOQ, String tcScenario, String NoOfScenarios) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		String subScenario, scenarioName, ws,tcRequired,subsn;
		int j=0;
		int NoOfRecs=0;
		subsn="";
		CaseManagementOperations.caseManagement_MenuNavigations("fullDataEntryForm");
		for(int i=1; i<= 14; i++) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);					// Reloading the Worksheet after every Iteration.
			scenarioName = sn + "_" + String.valueOf(i);											// Creating unique Scenario Name
			tcRequired = Multimaplibraries.getTestDataCellValue(scenarioName, tcApplicableForOQ);	//  Test Case Applicable Yes OR No storing into a variable
			subScenario = Multimaplibraries.getTestDataCellValue(scenarioName, tcScenario);			//  Test Case Applicable Yes OR No storing into a variable
			ws = Multimaplibraries.getTestDataCellValue(scenarioName, "WorkSheetName");
			NoOfRecs = Integer.parseInt(Multimaplibraries.getTestDataCellValue(scenarioName, NoOfScenarios));
			if(tcRequired.equals("Yes")){
				if(!ws.equals("FDE_General")) {
					if(!ws.equals("CaseSave")) {
					FDE_Operations.tabNavigation(Multimaplibraries.getTestDataCellValue(scenarioName, "NavigateTo"));
					}
				}
				switch (ws){
					case "FDE_General":
						FDE_General.LSMVSetGeneralBasicDetails(subScenario);
						System.out.println("testing3v======== " + scenarioName);
						break;

					case "FDE_Source":
						FDE_Source.setSourceDetails(subScenario);
						break;						
						
					case "FDE_Study":
						FDE_Study.set_StudyData(subScenario);
						break;
						
					case "FDE_Reporter":
						FDE_Reporter.set_ReporterData(subScenario);
						break;
						
					case "FDE_Patient":
						FDE_Patient.set_Patient(subScenario);
						break;
						
					case "FDE_Parent":
						FDE_Parent.LSMVSetParentDetails(subScenario);
						break;
						
					case "FDE_Products":
						do {// To read multiple scenarios from Product Worksheet based on the NoOfScenriosParameter
//							if(NoOfRecs <= 1 ) {
//								//j=0;
//								FDE_Products.setProductData(subScenario);
//							}else {
								j=j+1;
								subsn= subScenario + "_" + String.valueOf(j);
								FDE_Products.setProductData(subsn);
//							}
							
							j=j++;
							System.out.println("Outside the While loop " + subsn + "j val " + j + " NoOfRecs " + NoOfRecs);
						}while(NoOfRecs > j);
						System.out.println("Outside the While loop  " + subsn + "j val " + j + " NoOfRecs " + NoOfRecs);
						break;
						
					case "FDE_Events":
						FDE_Events.set_Events(subScenario);
						break;
						
					case "FDE_Narrative":
						FDE_Narrative.setNarrativeData(subScenario);
						break;
						
					case "FDE_Labelling": 								// This should be updated with respective Method name.
					//	FDE_Source.setSourceData(scenarioName);
						break;
					
					case "FDE_Pregnancy":
						FDE_Pregnancy.	set_PregnancyDetails(subScenario);
						break;
	
					case "FDE_Literature":
						FDE_Literature.set_Literature(subScenario);
						break;
	
					case "FDE_LabData":
						FDE_LabData.set_TestsData(subScenario);
						break;
					case "CaseSave":		// This requires separate dedicated method.
						System.out.println("testing1 ======== " + className);
						System.out.println("testing2v======== " + scenarioName);
						try {
						LSMVSave(scenarioName);
						}catch(Exception e) {
							e.printStackTrace();
						}
						break;
				}
			}
		}
	}

	public static void LSMVSave(String scenarioName) {
	//	Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		System.out.println("testing5 ======== " + className);
		agClick(FullDataEntryFormPageObjects.SaveButton);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.writeRecptNo_FDESave(scenarioName, className);
	//	writeRecptNo_FDECaseSave(scenarioName, className, "ReceiptNumber");
		System.out.println("testing6 ======== " + className);
	//	agAssertContainsText(FullDataEntryFormPageObjects.receiptNumber, FDE_General.getData(scenarioName, "SaveMessage"));
		String msg = Multimaplibraries.getTestDataCellValue(scenarioName, "NavigateTo");
		agAssertContainsText(FullDataEntryFormPageObjects.receiptNumber, msg);
		String receiptNumber = agGetText(FullDataEntryFormPageObjects.receiptNumber);
		status = agIsVisible(FullDataEntryFormPageObjects.receiptNumber);
		if (status) {
			Reports.ExtentReportLog("LSMV create new case receipt", Status.PASS,
					"New case creation successfull :: Validation-" + receiptNumber, true);
		} else {
			Reports.ExtentReportLog("LSMV create new case receipt", Status.FAIL,
					"New case creation unsuccessfull :: Validation-" + receiptNumber, true);
		}

		agClick(FullDataEntryFormPageObjects.saveOkButton);

	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to create a FDE case with mandatory
	 *             data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 24-jun-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
//	public static void CaseManagement(String scenarioName, String screenName) {
//		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
//		CaseManagementOperations.caseManagement_MenuNavigations("fullDataEntryForm");
//		FDE_General.LSMVSetGeneralBasicDetails(scenarioName);
//		tabNavigation("Source");
//		FDE_Source.setSourceDetails(scenarioName);
//		tabNavigation("Reporter");
//		FDE_Reporter.set_ReporterData(scenarioName);
//		tabNavigation("Study");
//		FDE_Study.set_StudyData(scenarioName);
//		tabNavigation("Patient");
//		FDE_Patient.set_Patient(scenarioName);
//		tabNavigation("Parent");
//		FDE_Parent.LSMVSetParentDetails(scenarioName);
//		tabNavigation("Product(s)");
//		FDE_Products.setProductData(scenarioName);
//		tabNavigation("Event(s)");
//		FDE_Events.set_Events(scenarioName);
//		tabNavigation("Narrative");
//		FDE_Narrative.setNarrativeData(scenarioName);
//		tabNavigation("Pregnancy");
//		FDE_Pregnancy.set_PregnancyDetails(scenarioName);
//		tabNavigation("Lab Data");
//		FDE_LabData.set_TestsData(scenarioName);
//		tabNavigation("Literature");
//		FDE_Literature.set_Literature(scenarioName);
//
//	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created write Receipt No To Datasheet
	 * @InputParameters: scenarioName, sheetName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 26-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void writeRecptNo_FDECaseSave(String scenarioName, String sheetName, String ColName) {
		CommonOperations.agwaitTillVisible(FullDataEntryFormPageObjects.receiptNumber, 20, 1000);
		String receiptNumber = agGetText(FullDataEntryFormPageObjects.receiptNumber);
		/*String data1 = receiptNumber.substring(receiptNumber.lastIndexOf("Receipt Number:"));
		String RCTNo = data1.substring(15, data1.indexOf("saved successfully"));
		*/
		
		String[] arrOfStr = receiptNumber.split("Receipt number");
		arrOfStr = arrOfStr[1].split("saved successfully");
		receiptNumber = arrOfStr[0].trim();
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, ColName, receiptNumber);
	}
	
	
	
}
