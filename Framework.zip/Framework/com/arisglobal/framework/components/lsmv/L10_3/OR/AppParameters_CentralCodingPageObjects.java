package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class AppParameters_CentralCodingPageObjects {

	/////////////////////////////// Administration >> System Administration >>
	/////////////////////////////// Application Parameters >> Central Coding
	/////////////////////////////// //////////////////////////////
	/////////////////////////////////////////////////// Central Coding
	/////////////////////////////// ////////////////////////////////////////////////////////////////

	public static String centralCoding_Div = "xpath#//label[contains(@id, 'applicationParameterForm') and contains(text(), 'Central Coding')]";
	public static String codingMatchOrder_Radio = "Coding Match Order";
	public static String medDRAHierarchyOfTerm_Radio = "MedDRA Hierarchy of Term";
	public static String medDRAVersionInUse_DropDown = "xpath#//div[@id='applicationParameterForm:orderByDisplayOrder_A1-5073']";
	public static String whoDDVersionInUse_DropDown = "xpath#//div[@id='applicationParameterForm:whoDDVersion']//label";
	public static String snomedCTVersionInUse_DropDown = "xpath#//div[@id='applicationParameterForm:whoDDVersion']//label";
	public static String loincVersionInUse_DropDown = "xpath#//div[@id='applicationParameterForm:loincVersion']//label";
	public static String koreanDDVersionInUse_DropDown = "xpath#//div[@id='applicationParameterForm:kddVersion']//label";
	public static String enableAdvancedSearchOptions_Radio = "Enable Advanced Search Options";
	public static String enableTermTypeBasedMedDRACoding_Radio = "Enable Term Type Based MedDRA Coding";
	public static String enableCentralCodingInbox_Radio = "Enable Central Coding Inbox";
	public static String event_CheckBox = "Event";
	public static String indication_CheckBox = "Indication";
	public static String lab_CheckBox = "Lab";
	public static String disease_CheckBox = "Disease";
	public static String senderDiagnosis_CheckBox = "Sender Diagnosis";
	public static String numberOfVTAReviewsRequired_DropDown = "xpath#//div[@id='applicationParameterForm:refValue']//label";
	public static String advancedSynonymsThesaurusName_TextBox = "xpath#//input[@id ='applicationParameterForm:ccsAdvancedSynonyms']";

}
