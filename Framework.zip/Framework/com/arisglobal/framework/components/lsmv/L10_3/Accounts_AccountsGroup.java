package com.arisglobal.framework.components.lsmv.L10_3;

import java.io.File;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AccountsGroupPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.AccountsPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Accounts_AccountsGroup extends ToolManager {
	static String className = Accounts_AccountsGroup.class.getSimpleName();

	static Boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to search and create Accounts Group
	 *             Class.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen: Avinash K
	 **********************************************************************************************************/

	public static void searchAndCreateAccountsGroup(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		if (verifysearchData(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Accounts Group already exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "AccountsGroup"),
					AccountsGroupPageObjects.get_ListofAccountsGroup);
		} else {
			agClick(AccountsGroupPageObjects.new_Button);
			createAccountsGroup(scenarioName);
			search(scenarioName);
			verifyAccountGroup(scenarioName);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Accounts Group record.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void search(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(AccountsGroupPageObjects.accountsGroupListingSearch_Textbox,
				getTestDataCellValue(scenarioName, "AccountsGroup"));
		agClick(AccountsGroupPageObjects.search_Icon);
		agSetStepExecutionDelay("3000");
		agIsVisible(AccountsGroupPageObjects.paginator);
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Accounts Group exist or not
	 *             based on Accounts group field
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Boolean verifysearchData(String scenarioName) {
		Boolean falg = false;
		String paginator = agGetText(AccountsGroupPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			List<WebElement> list = agGetElementList(AccountsGroupPageObjects.get_ListofAccountsGroup);
			String columnHeader = null;
			for (int j = 1; j <= list.size(); j++) {
				columnHeader = agGetText(AccountsGroupPageObjects.columnHeaderList(Integer.toString(j)));
				if (getTestDataCellValue(scenarioName, "AccountsGroup").equalsIgnoreCase(columnHeader)) {
					falg = true;
					break;
				}
			}
		}
		return falg;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create Accounts Group Class.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createAccountsGroup(String scenarioName) {
		agAssertVisible(AccountsGroupPageObjects.accountsGroupLable);
		agSetValue(AccountsGroupPageObjects.AccountsGroup_Txtfield,
				getTestDataCellValue(scenarioName, "AccountsGroup"));
		agSetValue(AccountsGroupPageObjects.Description_Txtfield, getTestDataCellValue(scenarioName, "Description"));
		CommonOperations.takeScreenShot();
		agClick(AccountsGroupPageObjects.save_Button);
		CommonOperations.setAuditInfo(scenarioName);
		agClick(AccountsGroupPageObjects.cancel_Button);
		agIsVisible(AccountsPageObjects.accountGroupSearchTextbox);
		CommonOperations.takeScreenShot();

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify AccountGroup.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyAccountGroup(String scenarioName) {
		agClick(AccountsGroupPageObjects.edit_Icon);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "AccountsGroup"),
				AccountsGroupPageObjects.AccountsGroup_Txtfield);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Description"),
				AccountsGroupPageObjects.Description_Txtfield);
		CommonOperations.takeScreenShot();
		agClick(AccountsGroupPageObjects.cancel_Button);
		agIsVisible(AccountsGroupPageObjects.paginator);
	}

	public static void updateAccountsGroup(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(AccountsGroupPageObjects.edit_Icon);
		createAccountsGroup(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Accounts Group.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 12-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void searchAccountsGroup(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		String paginator = agGetText(AccountsGroupPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "AccountsGroup"),
					AccountsGroupPageObjects.get_AccountsGroup);
			Reports.ExtentReportLog("", Status.PASS, "Search Accounts Group: Accounts Group Listed", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Search Accounts Group: Accounts Group Not Listed", true);
		}
		agClick(AccountsGroupPageObjects.refresh_Icon);
		agIsVisible(AccountsPageObjects.accountGroupSearchTextbox);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete Accounts Group.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 13-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteAccountsGroup(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		String paginator = agGetText(AccountsGroupPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "AccountsGroup"),
					AccountsGroupPageObjects.get_AccountsGroup);
			Reports.ExtentReportLog("", Status.PASS, "Accounts Group Found", true);
			agClick(AccountsGroupPageObjects
					.selectListingCheckbox(getTestDataCellValue(scenarioName, "AccountsGroup")));
			delete(scenarioName);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Accounts Group Not Found", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete Accounts Group.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 13-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void delete(String scenarioName) {
		agClick(AccountsGroupPageObjects.delete_Button);
		CommonOperations.setAccGroupDeleteAuditInfo(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search for deleted Accounts Group.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void searchDeletedAccountsGroup(String scenarioName) {
		search(scenarioName);
		String paginator = agGetText(AccountsGroupPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.FAIL,
					"Search for Deleted Accounts GroupPage: Deleted Accounts GroupPage is listed", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS,
					"Search for Deleted Accounts GroupPage: Deleted Accounts GroupPage is not listed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download Pharmacological Class
	 *             export to excel.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:Shamanth S | 08-Feb-2021
	 **********************************************************************************************************/
	public static void exportToexcel(String FileName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(AccountsGroupPageObjects.download_Icon);
		agClick(AccountsGroupPageObjects.exporttoExcel_link);
		agWaitTillVisibilityOfElement(AccountsGroupPageObjects.export_Button);
		if (agIsVisible(AccountsGroupPageObjects.export_Button) == true) {
			agClick(AccountsGroupPageObjects.export_Button);
			try {
				Thread.sleep(8000);
				//Added wait condition till the file gets downloaded ~Shamanth
				String filePath = lsmvConstants.LSMV_testDataOutput +"\\"+ FileName+".xlsx";
				File file = new File(filePath);				
				do{
					agSetStepExecutionDelay("10000");	      
				}while(!file.exists());
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			CommonOperations.move_Downloadedexcel(FileName);
			agClick(AccountsGroupPageObjects.exportexcelcancel_Button);
		} else {
			Reports.ExtentReportLog("Export to excel pop is not displayed", Status.INFO, "", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to compare record count with download
	 *             excel
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:Avinash K
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void recordCountVerification(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		String count = xls.getCellData("Account Group", 2, 4);
		String[] Totalcount = count.split(":");
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in exported excel::" + Totalcount[1].trim(),
				false);
		String applrecordcount = agGetText(AccountsGroupPageObjects.paginator);
		String[] data = applrecordcount.split(" ");
		String recordCount = data[4];
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in application::" + recordCount, false);
		if (recordCount.equalsIgnoreCase(Totalcount[1].trim())) {
			Reports.ExtentReportLog("", Status.PASS, "Record count verification is successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Record count verification is Unsuccessfull", true);
		}
	}
}
