package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.CaseManagementPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_MultipleCaseOperations extends ToolManager {
	static String className = FDE_MultipleCaseOperations.class.getSimpleName();
	static boolean status;
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify multiple case in FDE screen
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Sep-2019 
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
    	public static void verifyMultipleCase(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "RCTNO_1"), FullDataEntryFormPageObjects.rct1_Link);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "RCTNO_2"), FullDataEntryFormPageObjects.rct2_Link);
		agAssertExists(FullDataEntryFormPageObjects.cancel_Button);
		agAssertExists(FullDataEntryFormPageObjects.moreOptions_Button);
		agAssertExists(FullDataEntryFormPageObjects.edit_Button);
		CommonOperations.takeScreenShot();
	}
	
    	/**********************************************************************************************************
    	 * @Objective: The below method is created to  switch case in FDE screen
    	 * @InputParameters:
    	 * @OutputParameters:
    	 * @author:Avinash k
    	 * @Date : 11-Sep-2019 
    	 * @UpdatedByAndWhen:
    	 **********************************************************************************************************/

	
	public static void SwitchCase() {
		agClick(FullDataEntryFormPageObjects.rct2_Link);
		//agClick(FullDataEntryFormPageObjects.receiptNo_Link(getTestDataCellValue(scenarioName, "RCTNO_2")));
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.caseEditloading);
		agAssertExists(FullDataEntryFormPageObjects.edit_Button);
		CommonOperations.takeScreenShot();
	}
	
  	/**********************************************************************************************************
	 * @Objective:The below method is created to edit and update the case data FDE screen
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Sep-2019 
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void editCase(String scenarioName) {
        agClick(FullDataEntryFormPageObjects.edit_Button);
        FDE_General.setCaseDates(scenarioName);
	}
	
  	/**********************************************************************************************************
	 * @Objective:The below method is created to Close the Case one after the other FDE screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Sep-2019 
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void MultipleCaseClose() {
        agClick(FullDataEntryFormPageObjects.close_Link);
        agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.caseEditloading);
        CommonOperations.takeScreenShot();
        agClick(FullDataEntryFormPageObjects.close_Link);
        agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.caseEditloading);
		status = agIsVisible(CaseManagementPageObjects.caseListingkeywordSearchTextbox);
		if (status) {
			Reports.ExtentReportLog("Multiple Cases closed Successfully", Status.PASS, "Cases Closed Successfull", true);
		} else {
			Reports.ExtentReportLog("Multiple Cases not closed", Status.PASS, "Cases Not Closed", true);
		}
	}
}