package com.arisglobal.framework.components.lsmv.L10_3;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.LibrariesPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.ProductsPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.aventstack.extentreports.Status;

public class LibrariesOperations extends ToolManager {
	public static WebElement webElement;
	static String className = LibrariesOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in
	 *             libraries Module.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void menuNavigation(String menu) {

		switch (menu) {
		case "pharmacologicClass":
			agMouseHover(ProductsPageObjects.ProductHoverNew);
			agClick(LibrariesPageObjects.pharmacologicalClass);
			break;

		case "activeMoiety":
			agMouseHover(ProductsPageObjects.ProductHoverNew);
			agClick(LibrariesPageObjects.activeMoiety);
			break;

		case "substances":
			agMouseHover(ProductsPageObjects.ProductHoverNew);
			agClick(LibrariesPageObjects.substances);
			break;

		case "listedness":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agClick(LibrariesPageObjects.listedness);
			break;

		case "aEKeywords":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agClick(LibrariesPageObjects.aeKeywords);
			break;

		case "therapeuticArea":
			agMouseHover(ProductsPageObjects.ProductHoverNew);
			agClick(LibrariesPageObjects.therapeuticArea);
			break;

		case "study":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agClick(LibrariesPageObjects.study);
			break;

		case "glossaryofTerms":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agClick(LibrariesPageObjects.glossaryofTerms);
			break;

		case "annotationLibrary":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agClick(LibrariesPageObjects.annotationLibrary);
			break;

		case "scheduledMaintenance ":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agMouseHover(LibrariesPageObjects.customMaintenance);
			agClick(LibrariesPageObjects.scheduledMaintenance);
			break;

		case "pharamacologicalTree":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agMouseHover(LibrariesPageObjects.tree);
			agClick(LibrariesPageObjects.pharamacologicalTree);
			break;

		case "productTree":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agMouseHover(LibrariesPageObjects.tree);
			agClick(LibrariesPageObjects.productTree);
			break;

		case "tagFormLibrary":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agClick(LibrariesPageObjects.TagformLibrary);
			break;

		case "caseScoreMetadata":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agClick(LibrariesPageObjects.casescoreMetadata);
			break;

		case "questions":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agClick(LibrariesPageObjects.questions);
			break;

		case "iMEDMEManagement":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agClick(LibrariesPageObjects.iMEDMEManagement);
			break;

		case "alwaysSeriousEvent":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agClick(LibrariesPageObjects.alwaysSeriousEvent);
			break;

		case "medDRAVTAMaintenance":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agMouseHover(LibrariesPageObjects.centralCoding);
			agClick(LibrariesPageObjects.medDRAVTAMaintenance);
			break;

		case "wHODDVTAMaintenance":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agMouseHover(LibrariesPageObjects.centralCoding);
			agClick(LibrariesPageObjects.wHODDVTAMaintenance);
			break;

		case "dictionaryBrowser":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agMouseHover(LibrariesPageObjects.centralCoding);
			agClick(LibrariesPageObjects.dictionaryBrowser);
			break;

		case "stopWordMaintenance":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agMouseHover(LibrariesPageObjects.centralCoding);
			agClick(LibrariesPageObjects.stopWordMaintenance);
			break;

		case "advanceSynonymMaintenance":
			agMouseHover(LibrariesPageObjects.librariesHover);
			agMouseHover(LibrariesPageObjects.centralCoding);
			agClick(LibrariesPageObjects.advanceSynonymMaintenance);
			break;

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is create to perform menu navigations in
	 *             libraries Module and verify the label name.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void librariesNavigations(String menu) {
		switch (menu) {
		case "pharmacologicClass":
			menuNavigation("pharmacologicClass");
			agSetStepExecutionDelay("5000");
			status = agIsVisible(LibrariesPageObjects.pharmaClassKeywordSearch);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to pharmacologic Class is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to pharmacologic Class is Unsuccessfull", true);
			}
			break;
		case "activeMoiety":
			menuNavigation("activeMoiety");
			agSetStepExecutionDelay("5000");
			status = agIsVisible(LibrariesPageObjects.activeMoietyKeywordSearch);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to active Moiety is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to active Moiety is Unsuccessfull", true);
			}
			break;
		case "substances":
			menuNavigation("substances");
			agSetStepExecutionDelay("5000");
			status = agIsVisible(LibrariesPageObjects.substancesKeywordSearch);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to substances is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to substances is Unsuccessfull", true);
			}
			break;

		case "listedness":
			menuNavigation("listedness");
			status = agIsVisible(LibrariesPageObjects.listednessKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to listedness is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to listedness is Unsuccessfull", true);
			}
			break;
		case "aEKeywords":
			menuNavigation("aEKeywords");
			agSetStepExecutionDelay("5000");
			status = agIsVisible(LibrariesPageObjects.AEKeywordTextarea);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to aEKeywords is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to aEKeywords is Unsuccessfull", true);
			}
			break;

		case "therapeuticArea":
			menuNavigation("therapeuticArea");
			agSetStepExecutionDelay("5000");
			status = agIsVisible(LibrariesPageObjects.therapeuticAreaKeywordSearch);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to Therapeutic Area is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Therapeutic Area is Unsuccessfull", true);
			}
			break;

		case "study":
			menuNavigation("study");
			agSetStepExecutionDelay("5000");
			status = agIsVisible(LibrariesPageObjects.studyKeywordSearch);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to study is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to study is Unsuccessfull", true);
			}
			break;

		case "glossaryofTerms":
			menuNavigation("glossaryofTerms");
			agSetStepExecutionDelay("5000");
			status = agIsVisible(LibrariesPageObjects.glossaryKeywordSearch);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to glossary of Terms is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to glossary of Terms is Unsuccessfull", true);
			}
			break;
		case "annotationLibrary":
			menuNavigation("annotationLibrary");
			status = agIsVisible(LibrariesPageObjects.annotationKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to annotation Library is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to annotation Library is Unsuccessfull", true);
			}
			break;
		case "pharamacologicalTree":
			menuNavigation("pharamacologicalTree");
			agSetStepExecutionDelay("10000");
			status = agIsVisible(LibrariesPageObjects.pharamacologicalTreeLable);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to pharamacological Tree is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to pharamacological Tree is Unsuccessfull", true);
			}
			break;
		case "productTree":
			menuNavigation("productTree");
			agSetStepExecutionDelay("10000");
			status = agIsVisible(LibrariesPageObjects.productTreeLable);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to product Tree is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to product Tree is Unsuccessfull", true);
			}
			break;
		case "tagFormLibrary":
			menuNavigation("tagFormLibrary");
			status = agIsVisible(LibrariesPageObjects.TagLibraryKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to tagForm Library is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to tagForm Library is Unsuccessfull", true);
			}
			break;
		case "caseScoreMetadata":
			menuNavigation("caseScoreMetadata");
			status = agIsVisible(LibrariesPageObjects.caseScoreMetadataKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to case Score Metadata is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to case Score Metadata is Unsuccessfull", true);
			}
			break;

		case "questions":
			menuNavigation("questions");
			status = agIsVisible(LibrariesPageObjects.questionKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to questions is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to questions is Unsuccessfull", true);
			}
			break;
		case "iMEDMEManagement":
			menuNavigation("iMEDMEManagement");
			status = agIsVisible(LibrariesPageObjects.imeKeywordSearch);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to iMEDMEManagement is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to iMEDMEManagement is Unsuccessfull", true);
			}
			break;
		case "alwaysSeriousEvent":
			menuNavigation("alwaysSeriousEvent");
			agSetStepExecutionDelay("6000");
			status = agIsVisible(LibrariesPageObjects.alwaysSeriousKeywordSearch);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to always Serious Event is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to always Serious Event is Unsuccessfull", true);
			}
			break;

		case "medDRAVTAMaintenance":
			menuNavigation("medDRAVTAMaintenance");
			agSetStepExecutionDelay("8000");
			status = agIsVisible(LibrariesPageObjects.MedDRAVTAKeywordSearch);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to medDRAVTAMaintenance is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to medDRAVTAMaintenance is Unsuccessfull", true);
			}
			break;

		case "wHODDVTAMaintenance":
			menuNavigation("wHODDVTAMaintenance");
			agSetStepExecutionDelay("10000");
			status = agIsVisible(LibrariesPageObjects.WHODDVTAKeywordSearch);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to wHODDVTAMaintenance is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to wHODDVTAMaintenance is Unsuccessfull", true);
			}
			break;

		case "dictionaryBrowser":
			menuNavigation("dictionaryBrowser");
			agGetCurrentWindow();
			status = agIsVisible(LibrariesPageObjects.dictionaryBrowserLable);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to dictionary Browser is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to dictionary Browser is Unsuccessfull", true);
			}
			break;

		case "stopWordMaintenance":
			menuNavigation("stopWordMaintenance");
			agSetStepExecutionDelay("10000");
			status = agIsVisible(LibrariesPageObjects.stopWordKeywordSearch);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to stop Word Maintenance is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to stop Word Maintenance is Unsuccessfull", true);
			}
			break;

		case "advanceSynonymMaintenance":
			menuNavigation("advanceSynonymMaintenance");
			agSetStepExecutionDelay("10000");
			status = agIsVisible(LibrariesPageObjects.advanceSynonymKeywordSearch);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to advance Synonym Maintenance is successfull",
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to advance Synonym Maintenance is Unsuccessfull",
						true);
			}
			break;
		default:
			System.out.println("Invalid Menu Link!");
			break;
		}

	}
}