package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.Product_LookupPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.StudyPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Libraries_Study extends ToolManager {
	static String className = Libraries_Study.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Study.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 6-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean searchStudy(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		agAssertVisible(StudyPageObjects.searchListing_TextBox);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(StudyPageObjects.searchListing_TextBox, getTestDataCellValue(scenarioName, "SearchText"));
		agClick(StudyPageObjects.search_Icon);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay("5000");
		String paginator = agGetText(StudyPageObjects.paginator);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.PASS,
					"Search Result with '" + getTestDataCellValue(scenarioName, "SearchText") + "' exists!", true);
			return true;
		} else {
			return false;
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click on New Button in Study
	 *             Listing Screen.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 6-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickNewButton() {
		agClick(StudyPageObjects.newButton);
		agAssertVisible(StudyPageObjects.studyNo_TextBox);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit Study.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 6-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void editStudy() {
		agClick(StudyPageObjects.edit_Icon);
		agAssertVisible(StudyPageObjects.studyNo_TextBox);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Study Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setStudyDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(StudyPageObjects.projectNo_TextBox, getTestDataCellValue(scenarioName, "ProjectNo"));
		agSetValue(StudyPageObjects.studyNo_TextBox, getTestDataCellValue(scenarioName, "StudyNo"));
		agSetValue(StudyPageObjects.studyDescription_TextArea, getTestDataCellValue(scenarioName, "StudyDescription"));
		agSetValue(StudyPageObjects.studyTitle_TextArea, getTestDataCellValue(scenarioName, "StudyTitle"));
		CommonOperations.setListDropDownValue(StudyPageObjects.studyDesign_DropDown,
				getTestDataCellValue(scenarioName, "StudyDesign"));
		CommonOperations.setListDropDownValue(StudyPageObjects.studyPhase_DropDown,
				getTestDataCellValue(scenarioName, "StudyPhase"));
		CommonOperations.setListDropDownValue(StudyPageObjects.blindedStudy_DropDown,
				getTestDataCellValue(scenarioName, "BlindedStudy"));
		agSetValue(StudyPageObjects.eudraCTNumber_TextBox, getTestDataCellValue(scenarioName, "EudraCTNumber"));
		CommonOperations.setListDropDownValue(StudyPageObjects.codeBroken_DropDown,
				getTestDataCellValue(scenarioName, "CodeBroken"));
		agSetValue(StudyPageObjects.primaryTestCompound_TextBox,
				getTestDataCellValue(scenarioName, "PrimaryTestCompound"));
		if (!getTestDataCellValue(scenarioName, "CodeBrokenOn").equalsIgnoreCase("#skip#")) {
			agSetValue(StudyPageObjects.codeBrokenOn_TextBox,
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "CodeBrokenOn")));
			agClick(CommonPageObjects.applicationLogo);
		}
		agSetValue(StudyPageObjects.clinicalTrialsGovID_TextBox,
				getTestDataCellValue(scenarioName, "ClinicalTrialsGovID"));
		agSetValue(StudyPageObjects.studyDesignDescription_TextArea,
				getTestDataCellValue(scenarioName, "StudyDesignDescription"));
		agSetValue(StudyPageObjects.primaryIND_TextBox, getTestDataCellValue(scenarioName, "PrimaryIND"));

		agJavaScriptExecuctorScrollToElement(StudyPageObjects.study_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Libraries >> Study Section 1 : Scenario Name:: " + scenarioName, true);

		CommonOperations.setListDropDownValue(StudyPageObjects.studyType_DropDown,
				getTestDataCellValue(scenarioName, "StudyType"));
		CommonOperations.clickRadioButton(StudyPageObjects.active_RadioBtn,
				getTestDataCellValue(scenarioName, "Active"));
		if (agIsVisible(StudyPageObjects.queryContact_TextBox) == true) {
			agSetValue(StudyPageObjects.queryContact_TextBox, getTestDataCellValue(scenarioName, "QueryContact"));
		} else {
			CommonOperations.setListDropDownValue(StudyPageObjects.queryContact_DropDown,
					getTestDataCellValue(scenarioName, "QueryContact"));
		}
		agSetValue(StudyPageObjects.protocolDetails_TextArea, getTestDataCellValue(scenarioName, "ProtocolDetails"));
		agSetValue(StudyPageObjects.studyAcronym_TextBox, getTestDataCellValue(scenarioName, "StudyAcronym"));
		if (agIsVisible(StudyPageObjects.iis_CheckBox) == true) {
			CommonOperations.clickCheckBoxUnder(StudyPageObjects.iis_CheckBox,
					getTestDataCellValue(scenarioName, "IIS"));
		}
		CommonOperations.clickCheckBoxRightOf(StudyPageObjects.euCTRegulation_CheckBox,
				getTestDataCellValue(scenarioName, "EuCTRegulation"));
		CommonOperations.clickCheckBoxRightOf(StudyPageObjects.addToCase_CheckBox,
				getTestDataCellValue(scenarioName, "AddToCase"));

		agJavaScriptExecuctorScrollToElement(StudyPageObjects.studyDesignDescription_TextArea);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Libraries >> Study Section 2 : Scenario Name:: " + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Study Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyStudyDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ProjectNo"),
				StudyPageObjects.projectNo_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "StudyNo"), StudyPageObjects.studyNo_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "StudyDescription"),
				StudyPageObjects.studyDescription_TextArea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "StudyTitle"),
				StudyPageObjects.studyTitle_TextArea);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "StudyDesign"), StudyPageObjects.studyDesign_DropDown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "StudyPhase"), StudyPageObjects.studyPhase_DropDown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "BlindedStudy"), StudyPageObjects.blindedStudy_DropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "EudraCTNumber"),
				StudyPageObjects.eudraCTNumber_TextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "CodeBroken"), StudyPageObjects.codeBroken_DropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PrimaryTestCompound"),
				StudyPageObjects.primaryTestCompound_TextBox);
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "CodeBrokenOn")),
				StudyPageObjects.codeBrokenOn_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ClinicalTrialsGovID"),
				StudyPageObjects.clinicalTrialsGovID_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "StudyDesignDescription"),
				StudyPageObjects.studyDesignDescription_TextArea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PrimaryIND"),
				StudyPageObjects.primaryIND_TextBox);

		agJavaScriptExecuctorScrollToElement(StudyPageObjects.study_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Libraries >> Study Section 1 : Scenario Name:: " + scenarioName, true);

		agCheckPropertyText(getTestDataCellValue(scenarioName, "StudyType"), StudyPageObjects.studyType_DropDown);
		CommonOperations.verifyRadioButton(StudyPageObjects.active_RadioBtn,
				getTestDataCellValue(scenarioName, "Active"));
		if (agIsVisible(StudyPageObjects.queryContact_TextBox) == true) {
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "QueryContact"),
					StudyPageObjects.queryContact_TextBox);
		} else {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "QueryContact"),
					StudyPageObjects.queryContact_DropDown);
		}
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ProtocolDetails"),
				StudyPageObjects.protocolDetails_TextArea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "StudyAcronym"),
				StudyPageObjects.studyAcronym_TextBox);
		if (agIsVisible(StudyPageObjects.iis_CheckBox) == true) {
			CommonOperations.verifyCheckBoxUnder(StudyPageObjects.iis_CheckBox,
					getTestDataCellValue(scenarioName, "IIS"));
		}
		CommonOperations.verifyCheckBoxRightOf(StudyPageObjects.euCTRegulation_CheckBox,
				getTestDataCellValue(scenarioName, "EuCTRegulation"));
		CommonOperations.verifyCheckBoxRightOf(StudyPageObjects.addToCase_CheckBox,
				getTestDataCellValue(scenarioName, "AddToCase"));

		agJavaScriptExecuctorScrollToElement(StudyPageObjects.studyDesignDescription_TextArea);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Libraries >> Study Section 2 : Scenario Name:: " + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Study Product Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:Yashwanth 10-June-2020
	 **********************************************************************************************************/
	public static void setProductDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "boolProductAdd").equalsIgnoreCase("true")) {
			String prodName = getTestDataCellValue(scenarioName, "ProductName");
			String[] totalRecords = prodName.split(",");

			for (int i = 0; i < totalRecords.length; i++) {
				agClick(StudyPageObjects.clickAddBtton(StudyPageObjects.product_Label));
				agSetValue(Product_LookupPageObjects.productNameTextbox, totalRecords[i]);
				agClick(Product_LookupPageObjects.searchButton);
				agSetStepExecutionDelay("2000");
				agClick(Product_LookupPageObjects.localTradeName);
				// agClick(Product_LookupPageObjects.selectProdLookUpListingCheckBox(totalRecords[i]));
				agClick(Product_LookupPageObjects.prodLookUpSelectChkbox);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				CommonOperations.takeScreenShot();
				agClick(Product_LookupPageObjects.prodLibOkButton);
				agWaitTillInvisibilityOfElement(Product_LookupPageObjects.prodLibOkButton);
			}
			String Studyprodtype = getTestDataCellValue(scenarioName, "StudyProductType");
			String[] StudyprodRecords = Studyprodtype.split(",");
			String rowNO = "";
			for (int j = 0; j < totalRecords.length; j++) {

				if (j != 0) {
					rowNO = Integer.toString(j);
				} else {
					rowNO = getTestDataCellValue(scenarioName, "RowNo_StudyProduct");
				}
				agSetStepExecutionDelay("2000");
				CommonOperations.setListDropDownValue(
						(StudyPageObjects.studyProductType_DropDown).replace("%rowNo%", rowNO), StudyprodRecords[j]);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			}
		}

		CommonOperations.agwaitTillVisible(StudyPageObjects.product_Div, 10, 1000);
		agJavaScriptExecuctorScrollToElement(StudyPageObjects.product_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Libraries >> Study >> Product Section : Scenario Name:: " + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Study Product Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyProductDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "boolProductAdd").equalsIgnoreCase("true")) {
			if (!getTestDataCellValue(scenarioName, "ProductName").equalsIgnoreCase("#skip#")) {
				agAssertVisible(StudyPageObjects.prodNameStudy(getTestDataCellValue(scenarioName, "ProductName")));
			}
			agCheckPropertyText(getTestDataCellValue(scenarioName, "StudyProductType"),
					(StudyPageObjects.studyProductType_DropDown).replace("%rowNo%",
							getTestDataCellValue(scenarioName, "RowNo_StudyProduct")));
		}
		agJavaScriptExecuctorScrollToElement(StudyPageObjects.product_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Libraries >> Study >> Product Section : Scenario Name:: " + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Study Exempted Events
	 *             Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setExemptedEventsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, "ExemptedEventsLLTTerm").equalsIgnoreCase("#skip#")) {
			agClick(StudyPageObjects.clickAddBtton(StudyPageObjects.exemptedEvents_Label));
			agClick((StudyPageObjects.exemptedEventslltTerm_LookUp).replace("%rownNo%",
					getTestDataCellValue(scenarioName, "RowNo_ExemptedEvents")));
			CommonOperations
					.setDictionaryCodingBrowserDetails(getTestDataCellValue(scenarioName, "ExemptedEventsLLTTerm"));

			CommonOperations.agwaitTillVisible(StudyPageObjects.exemptedEvents_Div, 10, 1000);
			agJavaScriptExecuctorScrollToElement(StudyPageObjects.exemptedEvents_Div);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Libraries >> Study >> Exempted Events Section : Scenario Name:: " + scenarioName,
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Study Exempted Events
	 *             Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyExemptedEventsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, "ExemptedEventsLLTTerm").equalsIgnoreCase("#skip#")) {
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ExemptedEventsLLTTerm"),
					(StudyPageObjects.exemptedEventslltTerm_TextBox).replace("%rownNo%",
							getTestDataCellValue(scenarioName, "RowNo_ExemptedEvents")));

			agJavaScriptExecuctorScrollToElement(StudyPageObjects.exemptedEvents_Div);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Verification in Libraries >> Study >> Exempted Events Section : Scenario Name:: "
							+ scenarioName,
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Study Anticipated Events
	 *             Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setAnticipatedEventsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, "AnticipatedEventsLLTTerm").equalsIgnoreCase("#skip#")) {
			agClick(StudyPageObjects.clickAddBtton(StudyPageObjects.anticipatedEvents_Label));
			agClick((StudyPageObjects.anticipatedEvents_LookUp).replace("%rownNo%",
					getTestDataCellValue(scenarioName, "RowNo_AnticipatedEvents")));
			CommonOperations
					.setDictionaryCodingBrowserDetails(getTestDataCellValue(scenarioName, "AnticipatedEventsLLTTerm"));

			CommonOperations.agwaitTillVisible(StudyPageObjects.anticipatedEvents_Div, 10, 1000);
			agJavaScriptExecuctorScrollToElement(StudyPageObjects.anticipatedEvents_Div);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Libraries >> Study >> Anticipated Events Section : Scenario Name:: "
							+ scenarioName,
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Study Anticipated Events
	 *             Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyAnticipatedEventsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, "AnticipatedEventsLLTTerm").equalsIgnoreCase("#skip#")) {
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "AnticipatedEventsLLTTerm"),
					(StudyPageObjects.anticipatedEvents_TextBox).replace("%rownNo%",
							getTestDataCellValue(scenarioName, "RowNo_AnticipatedEvents")));

			agJavaScriptExecuctorScrollToElement(StudyPageObjects.anticipatedEvents_Div);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Verification in Libraries >> Study >> Anticipated Events Section : Scenario Name:: "
							+ scenarioName,
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Study Indications Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setIndicationsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, "IndicationLLTTerm").equalsIgnoreCase("#skip#")) {
			agClick(StudyPageObjects.clickAddBtton(StudyPageObjects.indications_Label));
			agClick((StudyPageObjects.indicationslltTerm_LookUp).replace("%rownNo%",
					getTestDataCellValue(scenarioName, "RowNo_StudyIndication")));
			CommonOperations.setDictionaryCodingBrowserDetails(getTestDataCellValue(scenarioName, "IndicationLLTTerm"));

			CommonOperations.agwaitTillVisible(StudyPageObjects.indications_Div, 10, 1000);
			agJavaScriptExecuctorScrollToElement(StudyPageObjects.indications_Div);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Libraries >> Study >> Indications Section : Scenario Name:: " + scenarioName,
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Study Indications Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyIndicationsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, "IndicationLLTTerm").equalsIgnoreCase("#skip#")) {
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "IndicationLLTTerm"),
					(StudyPageObjects.indicationslltTerm_TextBox).replace("%rownNo%",
							getTestDataCellValue(scenarioName, "RowNo_StudyIndication")));

			agJavaScriptExecuctorScrollToElement(StudyPageObjects.indications_Div);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Verification in Libraries >> Study >> Indications Section : Scenario Name:: " + scenarioName,
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Study Registration
	 *             Information Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setStudyRegistrationInformationDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, "RegistrationNumber").equalsIgnoreCase("#skip#")) {
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorClick(
					StudyPageObjects.clickAddBtton(StudyPageObjects.studyRegistrationInformation_Label));
			agWaitTillVisibilityOfElement(StudyPageObjects.registrationNumber_TextBox);
			agSetValue(StudyPageObjects.registrationNumber_TextBox,
					getTestDataCellValue(scenarioName, "RegistrationNumber"));
			agSetStepExecutionDelay("3000");
			CommonOperations.setListDropDownValue(StudyPageObjects.authority_DropDown,
					getTestDataCellValue(scenarioName, "Authority"));
			CommonOperations.setListDropDownValue(StudyPageObjects.statusOfTheTrail_DropDown,
					getTestDataCellValue(scenarioName, "StatusOfTheTrail"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (getTestDataCellValue(scenarioName, "boolResponsibleOPU").equalsIgnoreCase("true")) {
				agSetStepExecutionDelay("2000");
				agClick(StudyPageObjects.responsibleOPU_LookUpIcon);
				agSetStepExecutionDelay("3000");
				CommonOperations.setCompanyUnitLookupDetails(getTestDataCellValue(scenarioName, "UnitCode"),
						getTestDataCellValue(scenarioName, "UnitName"), getTestDataCellValue(scenarioName, "Type"),
						getTestDataCellValue(scenarioName, "Country_CompUnit"));
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			}
			agSetStepExecutionDelay("2000");
			CommonOperations.setListDropDownValue(StudyPageObjects.country_DropDown,
					getTestDataCellValue(scenarioName, "Country"));
			agSetValue(StudyPageObjects.localApprovalNumber_TextBox,
					getTestDataCellValue(scenarioName, "LocalApprovalNumber"));
			CommonOperations.setListDropDownValue(StudyPageObjects.ecReportingFlag_DropDown,
					getTestDataCellValue(scenarioName, "ECReportingFlag"));
			CommonOperations.takeScreenShot();
			agClick(StudyPageObjects.addRegistrationNumber_Button);

			CommonOperations.agwaitTillVisible(StudyPageObjects.studyRegistrationInformation_Div, 10, 1000);
			agJavaScriptExecuctorScrollToElement(StudyPageObjects.studyRegistrationInformation_Div);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Libraries >> Study >> Study Registration Information Section : Scenario Name:: "
							+ scenarioName,
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Study Registration
	 *             Information Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyStudyRegistrationInformationDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, "RegistrationNumber").equalsIgnoreCase("#skip#")) {
			agAssertVisible(
					StudyPageObjects.registrationNumberStudy(getTestDataCellValue(scenarioName, "RegistrationNumber")));
		}
		if (!getTestDataCellValue(scenarioName, "Authority").equalsIgnoreCase("#skip#")) {
			agAssertVisible(StudyPageObjects.authorityStudy(getTestDataCellValue(scenarioName, "Authority")));
		}
		if (!getTestDataCellValue(scenarioName, "Country").equalsIgnoreCase("#skip#")) {
			agAssertVisible(StudyPageObjects.countryStudy(getTestDataCellValue(scenarioName, "Country")));
		}

		agJavaScriptExecuctorScrollToElement(StudyPageObjects.studyRegistrationInformation_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Libraries >> Study >> Study Registration Information Section : Scenario Name:: "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Study Cross Referenced INDs
	 *             Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCrossReferencedINDsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "boolAdd_CrossReferencedINDs").equalsIgnoreCase("true")) {
			agClick(StudyPageObjects.clickAddBtton(StudyPageObjects.crossReferencedINDs_Label));
		}
		agSetValue(
				(StudyPageObjects.crossReferencedIND_TextBox).replace("%rownNo%",
						getTestDataCellValue(scenarioName, "RowNo_CrossReferencedINDs")),
				getTestDataCellValue(scenarioName, "CrossReferencedIND"));
		CommonOperations.setListDropDownValue(
				(StudyPageObjects.studyTypeCrossReferencedIND_DropDown).replace("%rownNo%",
						getTestDataCellValue(scenarioName, "RowNo_CrossReferencedINDs")),
				getTestDataCellValue(scenarioName, "StudyTypeCrossReferencedIND"));

		agJavaScriptExecuctorScrollToElement(StudyPageObjects.crossReferencedINDs_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Libraries >> Study >> Cross Referenced INDs Section : Scenario Name:: " + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Study Cross Referenced INDs
	 *             Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCrossReferencedINDsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "CrossReferencedIND"),
				(StudyPageObjects.crossReferencedIND_TextBox).replace("%rownNo%",
						getTestDataCellValue(scenarioName, "RowNo_CrossReferencedINDs")));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "StudyTypeCrossReferencedIND"),
				(StudyPageObjects.studyTypeCrossReferencedIND_DropDown).replace("%rownNo%",
						getTestDataCellValue(scenarioName, "RowNo_CrossReferencedINDs")));

		agJavaScriptExecuctorScrollToElement(StudyPageObjects.crossReferencedINDs_Div);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Libraries >> Study >> Cross Referenced INDs Section : Scenario Name:: "
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create new Study.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 6-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createStudy(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		clickNewButton();
		setStudyDetails(scenarioName);
		setProductDetails(scenarioName);
		setExemptedEventsDetails(scenarioName);
		setAnticipatedEventsDetails(scenarioName);
		setIndicationsDetails(scenarioName);
		setStudyRegistrationInformationDetails(scenarioName);
		setCrossReferencedINDsDetails(scenarioName);
		agClick(StudyPageObjects.saveButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to update Study.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 6-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateStudy(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		searchStudy(scenarioName);
		editStudy();
		setStudyDetails(scenarioName);
		setProductDetails(scenarioName);
		setExemptedEventsDetails(scenarioName);
		setAnticipatedEventsDetails(scenarioName);
		setIndicationsDetails(scenarioName);
		setStudyRegistrationInformationDetails(scenarioName);
		setCrossReferencedINDsDetails(scenarioName);
		agClick(StudyPageObjects.saveButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Study Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 6-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyStudy(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		searchStudy(scenarioName);
		editStudy();
		verifyStudyDetails(scenarioName);
		verifyProductDetails(scenarioName);
		verifyExemptedEventsDetails(scenarioName);
		verifyAnticipatedEventsDetails(scenarioName);
		verifyIndicationsDetails(scenarioName);
		verifyStudyRegistrationInformationDetails(scenarioName);
		verifyCrossReferencedINDsDetails(scenarioName);
		agClick(StudyPageObjects.cancelButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete Study.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 6-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndDeleteStudy(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		boolean searchResults = searchStudy(scenarioName);
		if (searchResults) {
			agClick(CommonPageObjects.checkLibrariesStudyList(getTestDataCellValue(scenarioName, "SearchText")));
			agClick(StudyPageObjects.deleteButton);
			CommonOperations.setDeleteAuditInfo("Delete_Study");
		}
		boolean deleteSearchResults = searchStudy(scenarioName);
		if (deleteSearchResults) {
			Reports.ExtentReportLog("", Status.FAIL,
					"Study : " + getTestDataCellValue(scenarioName, "SearchText") + " is not deleted", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS,
					"Study : " + getTestDataCellValue(scenarioName, "SearchText") + " is deleted", true);
		}
	}
}
