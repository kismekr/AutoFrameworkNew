package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class AppParameters_GeneralPageObjects {

	/////////////////////////////// Administration >> System Administration >>
	/////////////////////////////// Application Parameters >> General
	/////////////////////////////// //////////////////////////////////////////
	/////////////////////////////////////////////////// General
	/////////////////////////////// ////////////////////////////////////////////////////////////////

	public static String companyName_TextBox = "xpath#//input[@id ='applicationParameterForm:companyName']";
	public static String alertOrigin_TextBox = "xpath#//input[@id ='applicationParameterForm:alertOrigin']";
	public static String alertAdminEmail_TextBox = "xpath#//input[@id ='applicationParameterForm:alertAdminEmail']";
	public static String paginatorGroupSize_DropDown = "xpath#//div[@id='applicationParameterForm:paginatorMaxPages']";
	public static String numberOfRecordsPerPage_TextBox = "xpath#//input[@id ='applicationParameterForm:pagesPerRecordText']";
	public static String numberOfCasesForReassignation_TextBox = "xpath#//input[@id ='applicationParameterForm:casesForReassignation']";
	public static String auditReasonRequired_CheckBox = "Audit Reason Required";
	public static String caseRemoveReasonRequired_CheckBox = "Case Remove Reason Required";
	public static String allowUsersToUnlockTheirOwnRecords_CheckBox = "Allow Users to Unlock Their Own Records";
	public static String disableInactiveUsersAfterDays_TextBox = "xpath#//input[@id ='applicationParameterForm:inactiveDueDays']";
	public static String confidentialityNoteForReports_TextBox = "xpath#//input[@id ='applicationParameterForm:confidentialReport']";
	public static String font_TextBox = "xpath#//input[@id ='applicationParameterForm:font']";
	public static String logFilePath_TextBox = "xpath#//input[@id ='applicationParameterForm:logFilePath']";
	public static String maxFileSizeForManualUpload_TextBox = "xpath#//input[@id ='applicationParameterForm:maxFileSize']";
	public static String convertInboundDocumentIntoPDF_CheckBox = "Convert Inbound document(s) into PDF";
	public static String temporaryPathForpdftiffFiles_TextBox = "xpath#//input[@id ='applicationParameterForm:tempPath']";
	public static String imageURL_TextBox = "xpath#//input[@id ='applicationParameterForm:imageUrl']";
	public static String ARISgClientURL_TextBox = "xpath#//input[@id ='applicationParameterForm:arisgClientUrl']";
	public static String integratedTo_DropDown = "xpath#//div[@id='applicationParameterForm:integratedTo']//label";
	public static String screenLockTimeoutMinutes_TextBox = "xpath#//input[@id ='applicationParameterForm:appIdleTime']";
	public static String bulkImportPath_TextBox = "xpath#//input[@id ='applicationParameterForm:importPath']";
	public static String ocrPath_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'OCR Path']";
	public static String ocrPath_TextBox = "xpath#//input[@id ='applicationParameterForm:ocrPath']";
	public static String fuzzySearchFolderPath_TextBox = "xpath#//input[@id ='applicationParameterForm:fuzzyfolderpath']";
	public static String fuzzySimilarityScore_DropDown = "xpath#//div[@id='applicationParameterForm:fuzzySimilarityScore']";
	public static String authenticateAgainstDatabaseIfUserIDnotFoundinLDAPServer_CheckBox = "Authenticate against database if user ID not found in LDAP Server";
	public static String createCaseForEachInboundFile_CheckBox = "Create Case For Each Inbound File";
	public static String displayErrorStacktrace_CheckBox = "Display Error Stacktrace";
	public static String newDashboard_CheckBox = "New Dashboard";
	public static String displayAnnouncementandTaskPopup_Radio = "Display Announcement and Task Popup";
	public static String dataPrivacyRequired_CheckBox = "Data Privacy Required";
	public static String encryptionStandard_DropDown = "xpath#//div[@id='applicationParameterForm:encryptionStandard']";
	public static String passwordCheckForDocuments_CheckBox = "Password Check for Documents";
	public static String applicationTheme_DropDown = "xpath#//div[@id='applicationParameterForm:theme']";
	public static String companyUnitAccess_DropDown = "xpath#//div[@id='applicationParameterForm:companyGroupAndRole']";
	public static String displayCopyright_Radio = "Display Copyright";
	public static String displayCopyright_TextBox = "xpath#//textarea[@id ='applicationParameterForm:copyrightMsg']";
	public static String disclaimerMessage_TextBox = "xpath#//textarea[@id ='applicationParameterForm:disclaimerMsg']";
	public static String timeZonePreference_DropDown = "xpath#//div[@id='applicationParameterForm:timeZoneMenuId']";
	public static String dateFormat_DropDown = "xpath#//div[@id='applicationParameterForm:T1-319']";
	public static String ruleBuilderReportAccess_Radio = "Rule Builder Report Access";
	public static String mergeAllRoles_CheckBox = "Merge All Roles";
	public static String importConfigurationPath_TextBox = "xpath#//input[@id ='applicationParameterForm:importConfigPath']";

	////////////////////////////////////////// General >> Password Management
	////////////////////////////////////////// ///////////////////////////////////////////////////////////

	public static String passwordManagement_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Password Management']";
	public static String minimumPasswordLength_TextBox = "xpath#//input[@id ='applicationParameterForm:minPwdLength']";
	public static String passwordExpiryDurationDays_TextBox = "xpath#//input[@id ='applicationParameterForm:passwordExp']";
	public static String countOfWrongPasswordBeforeLockingAccount_TextBox = "xpath#//input[@id ='applicationParameterForm:maxLogins']";
	public static String noOfWrongPasswordLoginSendingAlerts_TextBox = "xpath#//input[@id ='applicationParameterForm:alertMailCount']";
	public static String passwordResetReminderBeforeExpiry_TextBox = "xpath#//input[@id ='applicationParameterForm:passwordResetRemainderMail']";
	public static String lockAccountPermanently_CheckBox = "Lock Account Permanently";
	public static String lockAccountPermanentlyMinutes_TextBox = "xpath#//input[@id ='applicationParameterForm:unlockmin']";
	public static String passwordReuseRestrictionCount_TextBox = "xpath#//input[@id ='applicationParameterForm:passwordReuseId']";

	///////////////////////////////////// General >> Case Triage and Adverse Event
	///////////////////////////////////// /////////////////////////////////////
	///////////////////////////////////// /////////////////////////////////////////

	public static String caseTriageAndAdverseEvent_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Case Triage and Adverse Event']";
	public static String defaultNumberOfRecentlyOpenedAdverseEvents_TextBox = "xpath#//input[@id ='applicationParameterForm:defaultAEOpenedId']";
	public static String maxNumberOfCasesForCompleteActivity_TextBox = "xpath#//input[@id='applicationParameterForm:completewfcases']";
	public static String manageUserWorkload_DropDown = "xpath#//div[@id='applicationParameterForm:manageUserWorkloadMenu']//label";
	public static String displayProductLookup_CheckBox = "Display Product Lookup";
	public static String formLevelUnitValidationOnSave_CheckBox = "Form level unit validation on Save";
	public static String displaySwitchToForm_CheckBox = "Display Switch to Form";
	public static String showSupplementFieldsInSmartView_CheckBox = "Show supplement fields in Smart view";
	public static String displaySupplementFieldsOnCondition_CheckBox = "Display Supplement fields on Condition";
	public static String protectConfidentiality_CheckBox = "Protect Confidentiality";

	///////////////////////////////// Case Identifier
	///////////////////////////////// /////////////////////////////////
	///////////////////////////////// //////////////////////////////////////////////////

	public static String caseIdentifier_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Case Identifier']";
	public static String atLeastOneSuspectProduct_CheckBox = "At least one Suspect Product";
	public static String atLeastOneReportedTerm_CheckBox = "At least one Reported Term";
	public static String considerOnlyCompanySuspectProduct_CheckBox = "Consider only Company Suspect Product";

	///////////////////////////////// Case Validity Identifier
	///////////////////////////////// /////////////////////////////////
	///////////////////////////////// //////////////////////////////////////////

	public static String caseValidityIdentifier_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Case Validity Identifier']";
	public static String patientAvailable_CheckBox = "Patient Available";
	public static String atLeastOneReporter_CheckBox = "At least One Reporter";

	////////////////////////////////////////// General >> FAQ's & Templates
	////////////////////////////////////////// //////////////////////////////////////////
	////////////////////////////////////////// ///////////////////////////////////////////

	public static String FAQsTemplates_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and contains(text(), '& Templates')]";
	public static String faqNumberingFormat_TextBox = "xpath#//input[@id ='applicationParameterForm:faqPrefix']";
	public static String faqNumberingFormat1_DropDown = "xpath#//div[@id='applicationParameterForm:FAQNumberingFormat1']//label";
	public static String faqNumberingFormat2_DropDown = "xpath#//div[@id='applicationParameterForm:FAQNumberingFormat2']//label";
	public static String faqExpiryPeriodDays_TextBox = "xpath#//input[@id ='applicationParameterForm:faqExpiryPeriod']";
	public static String faqTemplateWarningPeriodDays_TextBox = "xpath#//input[@id ='applicationParameterForm:faqOrTemplateWarningPeriod']";
	public static String templateNumberingFormat_TextBox = "xpath#//input[@id ='applicationParameterForm:templatePrefix']";
	public static String templateNumberingFormat1_DropDown = "xpath#//div[@id='applicationParameterForm:templateNumberingFormat1']//label";
	public static String templateNumberingFormat2_DropDown = "xpath#//div[@id='applicationParameterForm:templateNumberingFormat2']//label";
	public static String templateExpiryPeriodDays_TextBox = "xpath#//input[@id ='applicationParameterForm:templateExpiryPeriod']";

	/////////////////////////////////////// General >> Documents
	/////////////////////////////////////// ///////////////////////////////////////
	/////////////////////////////////////// ////////////////////////////////////////////////////////

	public static String documents_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Documents']";
	public static String documentsNumberingFormat_TextBox = "xpath#//input[@id ='applicationParameterForm:literaturePrefix']";
	public static String documentsNumberingFormat1_DropDown = "xpath#//div[@id='applicationParameterForm:documentsNumberingFormat1']//label";
	public static String documentsNumberingFormat2_DropDown = "xpath#//div[@id='applicationParameterForm:documentsNumberingFormat2']//label";
	public static String documentsExpiryPeriodDays_TextBox = "xpath#//input[@id ='applicationParameterForm:expiryPeriod']";
	public static String documentsWarningPeriodDay_TextBox = "xpath#//input[@id ='applicationParameterForm:warningPeriod']";
	public static String expiryWarningPeriodApplicableFor_DropDown = "xpath#//div[@id='applicationParameterForm:litExpWar']//label";
	public static String waterMarkRuleForInternalEditor_TextBox = "xpath#//input[@id ='applicationParameterForm:watermarkRuleForinternalEditor']";
	public static String documentsFefaultBccEmailAddressForCorrespondence_TextBox = "xpath#//input[@id ='applicationParameterForm:deafultBccEmailForCorrespondence']";

	////////////////////////////////////// General >> Bibliography
	////////////////////////////////////// //////////////////////////////////////
	////////////////////////////////////// //////////////////////////////////////////////////////////

	public static String bibliography_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Bibliography']";
	public static String bibliographyNumberingFormat_TextBox = "xpath#//input[@id ='applicationParameterForm:bibilographyPrefix']";
	public static String bibliographyNumberingFormat1_DropDown = "xpath#//div[@id='applicationParameterForm:bibilographyFormat']//label";
	public static String bibliographyNumberingFormat2_DropDown = "xpath#//div[@id='applicationParameterForm:bibilographySeperation']//label";
	public static String alwaysAvailable_Radio = "Always Available?";
	public static String bibliographyExpiryPeriodDays_TextBox = "xpath#//input[contains(@id ,'applicationParameterForm:bibliographyExpiryPeriod')]";
	public static String bibliographyWarningPeriodDay_TextBox = "xpath#//input[@id ='applicationParameterForm:bibliographyWarningPeriod']";
	public static String defaultNumberRecentlyOpenedBibliographies_TextBox = "xpath#//input[@id ='applicationParameterForm:defaultRecentNobibios']";
	public static String bibliographyDefaultBccEmailAddressCorrespondence_TextBox = "xpath#//input[@id ='applicationParameterForm:bccEmailCorresBib']";

	////////////////////////////////////// General >> E-Signature
	////////////////////////////////////// //////////////////////////////////////
	////////////////////////////////////// ////////////////////////////////////////////////////

	public static String eSignature_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'E-Signature']";
	public static String faq_CheckBox = "FAQ";
	public static String document_CheckBox = "Document";
	public static String template_CheckBox = "Template";
	public static String inquiry_CheckBox = "Inquiry";
	public static String bibliography_CheckBox = "Bibliography";

	//////////////////////////////////////// General >> Import Settings For Product
	//////////////////////////////////////// Lot/Batch Details Migration
	//////////////////////////////////////// ////////////////////////////////////////

	public static String importSettingsforProduct_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Import Settings For Product Lot/Batch Details Migration']";
	public static String configurationFolderPath_TextBox = "xpath#//input[@id ='applicationParameterForm:ConfigfoldId']";
	public static String backupFolderPath_TextBox = "xpath#//input[@id ='applicationParameterForm:successFoldId']";
	public static String errorFolderPath_TextBox = "xpath#//input[@id ='applicationParameterForm:errorFoldID']";
	public static String acknowledgmentFolderPath_TextBox = "xpath#//input[@id ='applicationParameterForm:ackFoldId']";

	////////////////////////////////////////// General >> Import Settings For
	////////////////////////////////////////// Contact
	////////////////////////////////////////// ////////////////////////////////////////////

	public static String importSettingsForContact_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Import Settings For Contact']";
	public static String importContactConfigurationFolderPath_TextBox = "xpath#//input[@id ='applicationParameterForm:ConfigfoldImportId']";
	public static String importContactBackupFolderPath_TextBox = "xpath#//input[@id ='applicationParameterForm:successFoldImportId']";
	public static String importContactErrorFolderPath_TextBox = "xpath#//input[@id ='applicationParameterForm:errorFoldImportID']";
	public static String importContactAcknowledgmentFolderPath_TextBox = "xpath#//input[@id ='applicationParameterForm:ackFoldImportId']";

	//////////////////////////////////////////// General >> Export Settings For
	//////////////////////////////////////////// Contact
	//////////////////////////////////////////// ///////////////////////////////////////////

	public static String exportSettingsForContact_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Export Settings For Contact']";
	public static String exportContactConfigurationFolderPath_TextBox = "xpath#//input[@id ='applicationParameterForm:ConfigfoldExportId']";
	public static String exportContactBackupFolderPath_TextBox = "xpath#//input[@id ='applicationParameterForm:successFoldExportId']";
	public static String exportContactErrorFolderPath_TextBox = "xpath#//input[@id ='applicationParameterForm:errorFoldExportID']";
	public static String exportContactAcknowledgmentFolderPath_TextBox = "xpath#//input[@id ='applicationParameterForm:ackFoldExportId']";

	/////////////////////////////////////////// General >> Data Privacy Setting
	/////////////////////////////////////////// /////////////////////////////////////////////////////////

	public static String dataPrivacySetting_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Data Privacy Setting']";
	public static String dataPrivacySetting_AddButton = "xpath#//a[@id = 'applicationParameterForm:addFieldDataPrivacy']";
	public static String contactCategory_DropDown = "xpath#//div[@id='applicationParameterForm:requesterTyperadio']//label";
	public static String contactSubCategory_Value = "xpath#//div[@id = 'applicationParameterForm:requesterSubCategory']/descendant::li[text() = '%value%']";
	public static String contactSubCategory_Values = "xpath#//div[@id = 'applicationParameterForm:requesterSubCategory']/descendant::li";
	/////////////////////////////////////////// General >> Busy Scheduler Status
	/////////////////////////////////////////// Alert Settings
	/////////////////////////////////////////// /////////////////////////////////////////////////////////

	public static String busySchedulerStatusAlertSettings_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Busy Scheduler Status Alert Settings']";
	public static String busySchedulerStatusAlertSettings_Button = "xpath#//div[@id = 'applicationParameterForm:schedulerStatusAlertlistId']/descendant::button[@title = '%option%']";
	public static String busySchedulerStatusAlertSettings_List = "xpath#//div[@id = 'applicationParameterForm:schedulerStatusAlertlistId']/descendant::ul[contains(@class, 'picklist-source')]/li[text() = '%value%']";
	public static String busySchedulerStatusAlertSettings_DropDown = "xpath#//div[@id='applicationParameterForm:B1-9064']//label";
	public static String BusySelectedSchedularList = "xpath#(//div[@id='applicationParameterForm:j_id_18j_content']//ul)[2]//li";
	/////////////////////////////////////////// General >> Stopped/Idle Scheduler
	/////////////////////////////////////////// Status Alert Settings
	/////////////////////////////////////////// /////////////////////////////////////////////////////////

	public static String stoppedIdleSchedulerStatusAlertSettings_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and text()= 'Stopped/Idle Scheduler Status Alert Settings']";
	public static String stoppedIdleSchedulerStatusAlertSettings_Button = "xpath#//div[@id = 'applicationParameterForm:stoppedSchedulerStatusAlertlistId']/descendant::button[@title = '%option%']";
	public static String stoppedIdleSchedulerStatusAlertSettings_List = "xpath#(//div[@id='applicationParameterForm:stoppedSchedulerStatusAlertlistId']//ul)[2]/li";
	public static String stoppedIdleSchedulerStatusAlertSettings_DropDown = "xpath#//div[@id='applicationParameterForm:B2-9064']//label";

	/////////////////////////////////////////// General >> Additional Alert Email
	/////////////////////////////////////////// ID's
	/////////////////////////////////////////// ///////////////////////////////////////////

	public static String additionalAlertEmailID_Label = "xpath#//label[contains(@id, 'applicationParameterForm') and contains(text(), 'Additional Alert Email ID')]";
	public static String additionalAlertEmailID_AddButton = "xpath#//a[@id = 'applicationParameterForm:addSearchField']";
	public static String emailAddress_TextBox = "xpath#//input[@id ='applicationParameterForm:contactsDatatable:%rowNo%:contactName']";
	public static String language_DropDown = "xpath#//div[@id='applicationParameterForm:contactsDatatable:%rowNo%:AR-535']//label";

}
