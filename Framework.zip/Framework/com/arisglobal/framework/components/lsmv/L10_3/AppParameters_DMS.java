package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AppParameters_DMSPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AppParameters_DMS extends ToolManager {
	static String className = AppParameters_DMS.class.getSimpleName();

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set DMS Details in DMS Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 17-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setDMSDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			CommonOperations.setListDropDownValue(AppParameters_DMSPageObjects.dmsType_DropDown,
					getTestDataCellValue(scenarioName, "DMSType"));
			CommonOperations.setListDropDownValue(AppParameters_DMSPageObjects.documentTransferType_DropDown,
					getTestDataCellValue(scenarioName, "DocumentTransferType"));

			Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >> DMS >> DMS Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set DMS Details in DMS Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar s
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadDMSDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			String DMSType = agGetText(AppParameters_DMSPageObjects.dmsType_DropDown);
			if (DMSType.contains("--Select--") || DMSType.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DMSType", "#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DMSType", DMSType);
			}
			String DocumentTransferType = agGetText(AppParameters_DMSPageObjects.documentTransferType_DropDown);
			if (DocumentTransferType.contains("--Select--") || DocumentTransferType.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DocumentTransferType",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DocumentTransferType",
						DocumentTransferType);
			}
			Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >> DMS >> DMS Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set data in DMS Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 17-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setAppParameters_DMSTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >>DMS Tab Started", true);
		setDMSDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >>DMS Tab Completed", true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read data in DMS Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadAppParameters_DMSTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "ReadData Entered in Application Parameters >>DMS Tab Started", true);
		ReadDMSDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO, "Read Data Entered in Application Parameters >>DMS Tab Completed",
				true);
	}
}
