package com.arisglobal.framework.components.lsmv.L10_3;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CaseListingReassignPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class CaseReassignOperations extends ToolManager {
	public static WebElement webElement;
	static String className = CaseReassignOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to select dropdown value in reassign
	 *             popUp
	 * @InputParameters: dropdownObject, value
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 26-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setReassignDropdown(String dropdownObject, String value) {
		agClick(dropdownObject);
		// agSetValue(CaseListingReassignPageObjects.CompUnit_DD_Textbox, value);
		agClick(CaseListingReassignPageObjects.selectDropdrown(value));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform case Reassign operations
	 *             in case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 20-Jul-2019
	 * @UpdatedByAndWhen:Pooja S on 09-Apr-2020
	 **********************************************************************************************************/
	public static void setReassignData(String scenarioName) {
		agClick(CaseListingPageObjects.reAssignButton);
		CommonOperations.agwaitTillVisible(CaseListingReassignPageObjects.reAssignLabel);
		agAssertExists(CaseListingReassignPageObjects.reAssignLabel);
		agSetStepExecutionDelay("3000");

		// Select the radio button company unit or Manager based on the value passed in
		// the test data sheet

		if (getTestDataCellValue(scenarioName, "CompanyUnit").equalsIgnoreCase("True")) {
			agClick(CaseListingReassignPageObjects.clickRadioButton(CaseListingReassignPageObjects.CompanyUnit));
		}
		if (getTestDataCellValue(scenarioName, "Manager").equalsIgnoreCase("True")) {
			agClick(CaseListingReassignPageObjects.clickRadioButton(CaseListingReassignPageObjects.Manager));
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		// setReassignDropdown(CaseListingReassignPageObjects.companyunitDropDown,getTestDataCellValue(scenarioName,
		// "CompanyUnit"));

		agClick(CaseListingReassignPageObjects.clickRadioButton(getTestDataCellValue(scenarioName, "Re_assignedTo")));

		if (getTestDataCellValue(scenarioName, "Re_assignedTo").equalsIgnoreCase("User")
				|| getTestDataCellValue(scenarioName, "Re_assignedTo").equalsIgnoreCase("Group")) {
			agSetStepExecutionDelay("3000");
			setReassignDropdown(CaseListingReassignPageObjects.clickUserGroupDropDown,
					getTestDataCellValue(scenarioName, "User_Group"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		agSetValue(CaseListingReassignPageObjects.commentsTextArea, getTestDataCellValue(scenarioName, "Comments"));
		agJavaScriptExecuctorClick(CaseListingReassignPageObjects.reAssign_Button);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform case Reassign operations
	 *             in case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 20-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void caseReassign(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		agClick(CaseListingPageObjects.listingCheckBox);
		setReassignData(scenarioName);
		agSetStepExecutionDelay("3000");
		agWaitTillVisibilityOfElement(CaseListingPageObjects.OkPopup_reassignbtn);
		/*
		 * status = agIsVisible(CaseListingPageObjects.validationPopup);
		 * agSetStepExecutionDelay(String.valueOf(Constants.
		 * defaultGlobalStepExecutionDelay)); if (status) { String validation =
		 * agGetText(CaseListingPageObjects.validationPopup);
		 * CommonOperations.writeReceiptNoToDatasheet("caseReassignOperations",
		 * scenarioName, "ReceiptNo");
		 * agAssertContainsText(CommonPageObjects.validationPopup,
		 * "re-assigned successfully");
		 * Reports.ExtentReportLog("Case Reassign is successfull", Status.PASS,
		 * "Validation : " + validation, true); } else {
		 * Reports.ExtentReportLog("Case Reassign is Unsuccessfull", Status.FAIL, "",
		 * true); }
		 */
		agJavaScriptExecuctorClick(CaseListingPageObjects.OkPopup_reassignbtn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to reassign Data Verificationn
	 *             functionality in case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 21-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void reassignDataVerification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("4000");
		agAssertExists(CaseListingPageObjects.getReceiptNumber);
		// agCheckPropertyText(getTestDataCellValue(scenarioName,
		// "ReceiptNo"),CaseListingPageObjects.getReceiptNumber);
		// agSetStepExecutionDelay("3000");
		agClick(CaseListingPageObjects.receiptNumberlink);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetStepExecutionDelay("3000");
		agCheckPropertyText(getTestDataCellValue(scenarioName, "CompanyUnit"),
				FDE_GeneralPageObjects.getCompanyUnitValue);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		agJavaScriptExecuctorScrollToElement(FullDataEntryFormPageObjects.assignToLabel);

		if (getTestDataCellValue(scenarioName, "Re_assignedTo").equalsIgnoreCase("User")
				|| getTestDataCellValue(scenarioName, "Re_assignedTo").equalsIgnoreCase("Group")) {
			agSetStepExecutionDelay("3000");
			agCheckPropertyText(getTestDataCellValue(scenarioName, "User_Group"),
					FullDataEntryFormPageObjects.reAssignvalue);

		} else {
			Reports.ExtentReportLog("", Status.INFO, "User assigned to Unassigned::" + scenarioName, true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify case Reassign functionality
	 *             in case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 21-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void caseReassignVerification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String ReceiptNo = agGetText(CaseListingPageObjects.getReceiptNumber);
		System.out.println(ReceiptNo);
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ReceiptNo", ReceiptNo);
		CaseManagementOperations.menuNavigation("Case listing");
		agWaitTillInvisibilityOfElement(CaseListingReassignPageObjects.Searchload_icon);
		// agSetStepExecutionDelay("5000");
		CaseListingOperations.setDropDown_CaseListing("Assign To", getTestDataCellValue(scenarioName, "AssignTo"));
		agSetStepExecutionDelay("5000");
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, ReceiptNo);
		agClick(CaseListingPageObjects.searchButton);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.waitTillCaseVisible();
		reassignDataVerification(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Write data into excel sheet.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 09-July-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, columnName, data);
	}
}