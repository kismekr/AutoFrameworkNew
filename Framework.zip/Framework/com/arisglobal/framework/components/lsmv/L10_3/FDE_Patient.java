package com.arisglobal.framework.components.lsmv.L10_3;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

import org.openqa.selenium.Keys;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AppParameters_CaseManagementPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CaseManagementPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.DictionaryCodingBrowser_LookupPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_EventsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_PatientPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_ProductsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.Product_LookupPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.WorkFlowPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

import bsh.ParseException;

public class FDE_Patient extends ToolManager {
	static String className = FDE_Patient.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value.
	 * @InputParameters: label, scenarioName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 04-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDownValue(String label, String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agSetStepExecutionDelay("2000");
			agClick(FDE_PatientPageObjects.click_DropDown(label));
			agSetStepExecutionDelay("2000");
			agClick(FDE_PatientPageObjects.setdropDownValue(getTestDataCellValue(scenarioName, columnName)));
		}
	}

	public static void setNullFlavourDropDownValue(String label, String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agSetStepExecutionDelay("2000");
			agJavaScriptExecuctorClick(FDE_PatientPageObjects.NullFlavourDropDown(label));
			agSetStepExecutionDelay("2000");
			agClick(FDE_PatientPageObjects.setdropDownValue(getTestDataCellValue(scenarioName, columnName)));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set age at patient Dropdown value
	 * @InputParameters: label, scenarioName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :05-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setEmbededDropDownValue(String label, String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(FDE_PatientPageObjects.click_embeddedDrpdwn(label));
			agClick(FDE_PatientPageObjects.setdropDownValue(getTestDataCellValue(scenarioName, columnName)));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set multi Value DropDown in FDE
	 *             General Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :25-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void multiValueDropDown(String el, String dropdownValue) {
		if (dropdownValue != "" && dropdownValue != null) {
			agClick(el);
			String excelData = dropdownValue;
			String[] data = excelData.split(",");
			if (data.length == 1) {
				agClick(FDE_PatientPageObjects.raceDropdown(dropdownValue.trim()));
			} else {
				for (int i = 0; i < data.length; i++) {
					agClick(FDE_PatientPageObjects.raceDropdown(data[i].trim()));
				}
			}
			// agClick(el);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in text field value
	 * @InputParameters: scenarioName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :05-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean verifyData(String object, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(object);
			agCheckPropertyValue("title", getTestDataCellValue(scenarioName, columnName), object);
		}
		return status;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in drop down
	 * @InputParameters: scenarioName, columnName, object
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean verifyDropdownValue(String scenarioName, String columnName, String object) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, columnName), object);
		}
		return status;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Dictionary Coding Browser
	 *             Details.
	 * @InputParameters: Search Term
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDictionaryCodingBrowserDetails(String searchTerm) {
		agSetValue(DictionaryCodingBrowser_LookupPageObjects.searchTerm_Textbox, searchTerm);
		agClick(DictionaryCodingBrowser_LookupPageObjects.search_Button);
		CommonOperations.agwaitTillVisible(
				DictionaryCodingBrowser_LookupPageObjects.selectDictionarySearchResultData(searchTerm), 10, 2000);
		// agClick(DictionaryCodingBrowser_LookupPageObjects.selectDictionarySearchResultData(searchTerm));
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay("5000");
		agClick(DictionaryCodingBrowser_LookupPageObjects.Ok_Button);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Age Patient tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :04-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_Age(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent_Manual")
				.equalsIgnoreCase("Check")) {
			agSetValue(FDE_PatientPageObjects.ageAtEvent,
					getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent"));
			setEmbededDropDownValue(FDE_PatientPageObjects.ageTimeEvent_DropDown, scenarioName,
					"Patient_PatientIdentifiers_AgeAtTheTimeOfEvent_Units");
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Patient Identifiers fields in
	 *             Patient
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :04-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_PatientIdentifiers_Data(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.patientID_Textbox),
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_PatientID"));
		agSetStepExecutionDelay("3000");

		if (getTestDataCellValue(scenarioName, "CustomDateFlag").equalsIgnoreCase("YES")) {
			agSetValue(FDE_PatientPageObjects.setData_Datesfields(FDE_PatientPageObjects.patientDOB_Date),
					getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_PatientDOB"));
		} else {
			agSetValue(FDE_PatientPageObjects.setData_Datesfields(FDE_PatientPageObjects.patientDOB_Date),
					CommonOperations.returnDateTime(
							getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_PatientDOB")));
		}
		CommonOperations.clickCheckBoxUnder(FDE_PatientPageObjects.protectConfidentiality_Checkbx,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_ProtectConfidentiality"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.clickCheckBoxUnder(FDE_PatientPageObjects.manual_Checkbx,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent_Manual"));
		set_Age(scenarioName);
		setDropDownValue(FDE_PatientPageObjects.consentcontactPatient_DropDown, scenarioName,
				"Patient_PatientIdentifiers_ConsentToContactPatient");

		if (agIsVisible(CommonPageObjects.manualCheckBox(FDE_PatientPageObjects.ageGroup_DropDown)) == true) {
			CommonOperations.clickManualCheckBox(FDE_PatientPageObjects.ageGroup_DropDown,
					getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeGroup_Manual"));
		}
		setDropDownValue(FDE_PatientPageObjects.ageGroup_DropDown, scenarioName, "Patient_PatientIdentifiers_AgeGroup");
		agClick(FDE_PatientPageObjects.select_RadioButtons(FDE_PatientPageObjects.Pregnant_label,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_Pregnant")));
		agSetValue(FDE_PatientPageObjects.set_WeightHeight(FDE_PatientPageObjects.weight_DropDown),
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_Weight"));
		setEmbededDropDownValue(FDE_PatientPageObjects.weight_DropDown, scenarioName,
				"Patient_PatientIdentifiers_Weight_Units");
		agSetValue(FDE_PatientPageObjects.set_WeightHeight(FDE_PatientPageObjects.height_DropDown),
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_Height"));
		setEmbededDropDownValue(FDE_PatientPageObjects.height_DropDown, scenarioName,
				"Patient_PatientIdentifiers_Height_Units");
		if (agIsVisible(FDE_PatientPageObjects.GenderNF)) {
			agClick(FDE_PatientPageObjects.GenderNF);
			agWaitTillVisibilityOfElement(FDE_PatientPageObjects.GenderAppliedNF);
			agClick(FDE_PatientPageObjects.GenderAppliedNF);
			agWaitTillVisibilityOfElement(FDE_PatientPageObjects.GenderNF);
		}

		setDropDownValue(FDE_PatientPageObjects.gender_DropDown, scenarioName, "Patient_PatientIdentifiers_Gender");
		if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("NO")) {
			multiValueDropDown(FDE_PatientPageObjects.clickRaceDropdown,
					getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_Race"));
		}
		setDropDownValue(FDE_PatientPageObjects.ethnicity_DropDown, scenarioName,
				"Patient_PatientIdentifiers_Ethnicity");
		if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}
		agSetValue(FDE_PatientPageObjects.setData_Datesfields(FDE_PatientPageObjects.lMPDate_Date), CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_LMPDate")));
		agSetValue(FDE_PatientPageObjects.setData_Datesfields(FDE_PatientPageObjects.lMPDate_Date), CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_LMPDate")));
		agSetValue(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.specialistRecordNumber_Textbox),
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_SpecialistRecordNumber"));
		agSetValue(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.hospitalRecordNumber_Textbox),
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_HospitalRecordNumber"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Patient >> Patient Identifiers Section 1 : Scenario Name::" + scenarioName, true);

		agSetValue(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.gpMedicalRecordNumber_Textbox),
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_GPMedicalRecordNumber"));
		agSetValue(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.investigationNumber_Textbox),
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_InvestigationNumber"));
		CommonOperations.clickCheckBoxUnder(FDE_PatientPageObjects.concomitantTherapies_Checkbx,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_ConcomitantTherapies"));
		agSetValue(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.registrationNumber_Textbox),
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_RegistrationNumber"));
		// CommonOperations.clickCheckBoxUnder(FDE_PatientPageObjects.identifiablePatient_Checkbx,
		// getTestDataCellValue(scenarioName,"Patient_PatientIdentifiers_IdentifiablePatient"));
		agSetValue(FDE_PatientPageObjects.birthWeight_Textbox,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_BirthWeight"));
		CommonOperations.setFDEDropDownValue(FDE_PatientPageObjects.birthWeightUnit_DropDown,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_BirthWeight_Units"));

		/*
		 * CommonOperations.clickManualCheckBox(FDE_PatientPageObjects.
		 * bodySurfaceIndex_label, getTestDataCellValue(scenarioName,
		 * "Patient_PatientIdentifiers_BodySurfaceIndex_Manual")); if
		 * (getTestDataCellValue(scenarioName,
		 * "Patient_PatientIdentifiers_BodySurfaceIndex_Manual").equalsIgnoreCase(
		 * "Check")) { agSetValue(FDE_PatientPageObjects.bodySurfaceIndex_Textbox,
		 * getTestDataCellValue(scenarioName,
		 * "Patient_PatientIdentifiers_BodySurfaceIndex")); }
		 * CommonOperations.clickManualCheckBox(FDE_PatientPageObjects.
		 * bodyMassIndex_label, getTestDataCellValue(scenarioName,
		 * "Patient_PatientIdentifiers_BodyMassIndex_Manual")); if
		 * (getTestDataCellValue(scenarioName,
		 * "Patient_PatientIdentifiers_BodyMassIndex_Manual").equalsIgnoreCase("Check"))
		 * { agSetValue(FDE_PatientPageObjects.bodyMassIndex_Textbox,
		 * getTestDataCellValue(scenarioName,
		 * "Patient_PatientIdentifiers_BodyMassIndex")); }
		 */
		// Not available in app
		/*
		 * agSetValue(FDE_PatientPageObjects.setData_TextArea(FDE_PatientPageObjects.
		 * medicalHistoryAndConcurrentConditions_TextArea),
		 * getTestDataCellValue(scenarioName,
		 * "Patient_PatientIdentifiers_MedHistoryAndConcurCond"));
		 */
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Patient >> Patient Identifiers Section 2 : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Patient Identifiers data in
	 *             Patient tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 05-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void patientIdentifiers_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		verifyData(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.patientID_Textbox), scenarioName,
				"Patient_PatientIdentifiers_PatientID");
		// verifyData(FDE_PatientPageObjects.setData_Datesfields(FDE_PatientPageObjects.patientDOB_Date),
		// scenarioName, "Patient_PatientIdentifiers_PatientDOB");
		agClick(FDE_PatientPageObjects.setData_Datesfields(FDE_PatientPageObjects.patientDOB_Date));
		agCheckPropertyValue("title",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_PatientDOB")),
				FDE_PatientPageObjects.setData_Datesfields(FDE_PatientPageObjects.patientDOB_Date));
		CommonOperations.verifyCheckBoxUnder(FDE_PatientPageObjects.protectConfidentiality_Checkbx,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_ProtectConfidentiality"));
		CommonOperations.verifyCheckBoxUnder(FDE_PatientPageObjects.manual_Checkbx,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent_Manual"));
		verifyData(FDE_PatientPageObjects.ageAtEvent, scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent");
		verifyDropdownValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent_Units",
				FDE_PatientPageObjects.click_embeddedDrpdwn(FDE_PatientPageObjects.ageTimeEvent_DropDown));
		verifyDropdownValue(scenarioName, "Patient_PatientIdentifiers_ConsentToContactPatient",
				FDE_PatientPageObjects.click_DropDown(FDE_PatientPageObjects.consentcontactPatient_DropDown));
		verifyDropdownValue(scenarioName, "Patient_PatientIdentifiers_AgeGroup",
				FDE_PatientPageObjects.click_DropDown(FDE_PatientPageObjects.ageGroup_DropDown));
		verifyData(FDE_PatientPageObjects.set_WeightHeight(FDE_PatientPageObjects.weight_DropDown), scenarioName,
				"Patient_PatientIdentifiers_Weight");
		verifyDropdownValue(scenarioName, "Patient_PatientIdentifiers_Weight_Units",
				FDE_PatientPageObjects.click_embeddedDrpdwn(FDE_PatientPageObjects.weight_DropDown));
		verifyData(FDE_PatientPageObjects.set_WeightHeight(FDE_PatientPageObjects.height_DropDown), scenarioName,
				"Patient_PatientIdentifiers_Height");
		verifyDropdownValue(scenarioName, "Patient_PatientIdentifiers_Height_Units",
				FDE_PatientPageObjects.click_embeddedDrpdwn(FDE_PatientPageObjects.height_DropDown));
		verifyDropdownValue(scenarioName, "Patient_PatientIdentifiers_Gender",
				FDE_PatientPageObjects.click_DropDown(FDE_PatientPageObjects.gender_DropDown));
		verifyDropdownValue(scenarioName, "Patient_PatientIdentifiers_Ethnicity",
				FDE_PatientPageObjects.click_DropDown(FDE_PatientPageObjects.ethnicity_DropDown));
		agJavaScriptExecuctorClick(FDE_PatientPageObjects.get_LMPDate);
		agClick(FDE_PatientPageObjects.get_LMPDate);
		agSetStepExecutionDelay("3000");
		agCheckPropertyValue("title",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_LMPDate")),
				FDE_PatientPageObjects.get_LMPDate);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		verifyData(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.specialistRecordNumber_Textbox),
				scenarioName, "Patient_PatientIdentifiers_SpecialistRecordNumber");
		verifyData(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.hospitalRecordNumber_Textbox),
				scenarioName, "Patient_PatientIdentifiers_HospitalRecordNumber");
		verifyData(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.gpMedicalRecordNumber_Textbox),
				scenarioName, "Patient_PatientIdentifiers_GPMedicalRecordNumber");
		verifyData(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.investigationNumber_Textbox),
				scenarioName, "Patient_PatientIdentifiers_InvestigationNumber");
		verifyData(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.registrationNumber_Textbox),
				scenarioName, "Patient_PatientIdentifiers_RegistrationNumber");
		CommonOperations.verifyCheckBoxUnder(FDE_PatientPageObjects.concomitantTherapies_Checkbx,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_ConcomitantTherapies"));
		CommonOperations.verifyCheckBoxUnder(FDE_PatientPageObjects.identifiablePatient_Checkbx,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_IdentifiablePatient"));
		verifyData(FDE_PatientPageObjects.birthWeight_Textbox, scenarioName, "Patient_PatientIdentifiers_BirthWeight");
		CommonOperations.verifyFDEDropDownValue(FDE_PatientPageObjects.birthWeightUnit_DropDown,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_BirthWeight_Units"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Patient >> Patient Identifiers Section 1 : Scenario Name::" + scenarioName, true);

		CommonOperations.verifyManualCheckBox(FDE_PatientPageObjects.bodySurfaceIndex_label,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_BodySurfaceIndex_Manual"));
		if (getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_BodySurfaceIndex_Manual")
				.equalsIgnoreCase("Check")) {
			verifyData(FDE_PatientPageObjects.bodySurfaceIndex_Textbox, scenarioName,
					"Patient_PatientIdentifiers_BodySurfaceIndex");
		}
		CommonOperations.verifyManualCheckBox(FDE_PatientPageObjects.bodyMassIndex_label,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_BodyMassIndex_Manual"));
		if (getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_BodyMassIndex_Manual")
				.equalsIgnoreCase("Check")) {
			verifyData(FDE_PatientPageObjects.bodyMassIndex_Textbox, scenarioName,
					"Patient_PatientIdentifiers_BodyMassIndex");
		}
		agClick(FDE_PatientPageObjects
				.setData_TextArea(FDE_PatientPageObjects.medicalHistoryAndConcurrentConditions_TextArea));
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_MedHistoryAndConcurCond"),
				FDE_PatientPageObjects
						.setData_TextArea(FDE_PatientPageObjects.medicalHistoryAndConcurrentConditions_TextArea));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Patient >> Patient Identifiers Section 2 : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: To set Medical History Details in Patient tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	// Below Hard Coded Value done for Data Modeling executions.
	static String rowNo_MedicalHistory = "0"; // getTestDataCellValue(scenarioName, "RowNo_MedicalHistory");
	static String boolAdd_MedicalHistory = "false"; // getTestDataCellValue(scenarioName, "boolAdd_MedicalHistory");

	public static void setMedicalHistoryDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (agIsVisible(CaseManagementPageObjects.GridViewCheck("Medical History"))) {
			agJavaScriptExecuctorClick(CaseManagementPageObjects.GridViewCheck("Medical History"));
		}
		if (boolAdd_MedicalHistory.equalsIgnoreCase("true")
				|| getTestDataCellValue(scenarioName, "AddButtonFlag").equalsIgnoreCase("YES")) {
			agClick(FDE_PatientPageObjects.clickAddButton(FDE_PatientPageObjects.medicalHistory_Label));
		}
		if (scenarioName.equalsIgnoreCase("LSMV_OQ_QBE_Search_2")) {
			agSetValue((FDE_PatientPageObjects.newDiseaseTerm_Textbox),
					getTestDataCellValue(scenarioName, "Patient_MedicalHistory_DiseaseTerm"));
		} else {

			agSetValue((FDE_PatientPageObjects.diseaseTerm_Textbox).replace("%rowNo%", rowNo_MedicalHistory),
					getTestDataCellValue(scenarioName, "Patient_MedicalHistory_DiseaseTerm"));
			agSendKeyStroke(Keys.TAB);
		}
		if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}
		if (getTestDataCellValue(scenarioName, "Patient_MedicalHistory_MedDRALLTForDiseaseTerm_LookUp")
				.equalsIgnoreCase("Yes")) {
			agClick((FDE_PatientPageObjects.medDRALLTforDiseaseTerm_LookUpIcon).replace("%rowNo%",
					rowNo_MedicalHistory));
			setDictionaryCodingBrowserDetails(
					getTestDataCellValue(scenarioName, "Patient_MedicalHistory_MedDRALLTForDiseaseTerm_SearchTerm"));
		}

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Patient >> Medical History Section 1 : Scenario Name::" + scenarioName, true);

		if (getTestDataCellValue(scenarioName, "Patient_MedicalHistory_StartDate").equalsIgnoreCase("d:m:y")
				&& getTestDataCellValue(scenarioName, "Patient_MedicalHistory_EndDate").equalsIgnoreCase("d:m:y")) {
			agSetValue((FDE_PatientPageObjects.startDateMedHist_Textbox).replace("%rowNo%", rowNo_MedicalHistory),
					CommonOperations
							.returnDateTime(getTestDataCellValue(scenarioName, "Patient_MedicalHistory_StartDate")));
			agSetValue((FDE_PatientPageObjects.endDateMedHist_Textbox).replace("%rowNo%", rowNo_MedicalHistory),
					CommonOperations
							.returnDateTime(getTestDataCellValue(scenarioName, "Patient_MedicalHistory_EndDate")));
		} else {
			agSetValue((FDE_PatientPageObjects.startDateMedHist_Textbox).replace("%rowNo%", rowNo_MedicalHistory),
					getTestDataCellValue(scenarioName, "Patient_MedicalHistory_StartDate"));
			agSetValue((FDE_PatientPageObjects.endDateMedHist_Textbox).replace("%rowNo%", rowNo_MedicalHistory),
					getTestDataCellValue(scenarioName, "Patient_MedicalHistory_EndDate"));
		}

		if (!getTestDataCellValue(scenarioName, "Patient_MedicalHistory_Continuing").equalsIgnoreCase("#skip#")) {
			switch (getTestDataCellValue(scenarioName, "Patient_MedicalHistory_Continuing")) {
			case "Yes":
				agClick((FDE_PatientPageObjects.ContinuingYes_Radio).replace("%rowNo%", rowNo_MedicalHistory));
				break;
			case "No":
				agClick((FDE_PatientPageObjects.ContinuingNo_Radio).replace("%rowNo%", rowNo_MedicalHistory));
				break;
			case "Unknown":
				if (agIsVisible(
						(FDE_PatientPageObjects.ContinuingUnknown_Radio).replace("%rowNo%", rowNo_MedicalHistory))) {
					agClick((FDE_PatientPageObjects.ContinuingUnknown_Radio).replace("%rowNo%", rowNo_MedicalHistory));
				}
				break;
			}
		}
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Patient >> Medical History Section 2 : Scenario Name::" + scenarioName, true);

	}

	/**********************************************************************************************************
	 * @Objective: To verify Medical History Details in Patient tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyMedicalHistoryDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		verifyData((FDE_PatientPageObjects.diseaseTerm_Textbox).replace("%rowNo%", rowNo_MedicalHistory), scenarioName,
				"Patient_MedicalHistory_DiseaseTerm");
		verifyData((FDE_PatientPageObjects.medDRALLTforDiseaseTerm_Textbox).replace("%rowNo%", rowNo_MedicalHistory),
				scenarioName, "Patient_MedicalHistory_MedDRALLTForDiseaseTerm");
		verifyData((FDE_PatientPageObjects.medDRAPTforDiseaseTerm_Textbox).replace("%rowNo%", rowNo_MedicalHistory),
				scenarioName, "Patient_MedicalHistory_MedDRAPTForDiseaseTerm");
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Patient_MedicalHistory_StartDate")),
				(FDE_PatientPageObjects.startDateMedHist_Textbox).replace("%rowNo%", rowNo_MedicalHistory));
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Patient_MedicalHistory_EndDate")),
				(FDE_PatientPageObjects.endDateMedHist_Textbox).replace("%rowNo%", rowNo_MedicalHistory));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Patient >> Medical History Section : Scenario Name::" + scenarioName, true);

	}

	/**********************************************************************************************************
	 * @Objective: To set Patient Past Therapy Details in Patient tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	// Below Hard Coded Value done for Data Modeling executions.
	// static String rowNo_PatientPastTherapy = "0";
	// //getTestDataCellValue(scenarioName, "RowNo_PatientPastTherapy");
	// static String boolAdd_PatientPastTherapy = "false";
	// //getTestDataCellValue(scenarioName, "boolAdd_PatientPastTherapy");

	public static void setPatientPastTherapyDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String rowNo_PatientPastTherapy = getTestDataCellValue(scenarioName, "RowNo_PatientPastTherapy");
		String boolAdd_PatientPastTherapy = getTestDataCellValue(scenarioName, "boolAdd_PatientPastTherapy");

		if (agIsVisible(CaseManagementPageObjects.GridViewCheck("Patient Past Therapy"))) {
			agClick(CaseManagementPageObjects.GridViewCheck("Patient Past Therapy"));
		}
		if (boolAdd_PatientPastTherapy.equalsIgnoreCase("true")) {
			agClick(FDE_PatientPageObjects.clickAddButton(FDE_PatientPageObjects.patientPastTherapy_Label));
		}
		if (getTestDataCellValue(scenarioName, "Patient_PatientPastTherapy_ProdDescAsReport_Null")
				.equalsIgnoreCase("Yes")) {
			agClick(Product_LookupPageObjects.prodDescAsRepNullButton);
		}
		if (getTestDataCellValue(scenarioName, "Patient_PatientPastTherapy_ProdDescAsReport_Lookup")
				.equalsIgnoreCase("Yes")) {
			agClick((FDE_PatientPageObjects.productDescriptionReported_LookUpIcon).replace("%rowNo%",
					rowNo_PatientPastTherapy));
			if (!scenarioName.equalsIgnoreCase("JapanTest") || !scenarioName.equalsIgnoreCase("JapanDomFDE")) {
				if (!scenarioName.contains("FDA")) {
					agSetValue(Product_LookupPageObjects.productNameTextbox,
							getTestDataCellValue(scenarioName, "Patient_PatientPastTherapy_ProdDescAsReport"));
				} else
					agSetValue(Product_LookupPageObjects.FDAProdName,
							getTestDataCellValue(scenarioName, "Patient_PatientPastTherapy_ProdDescAsReport"));
			}
			agClick(Product_LookupPageObjects.searchButton);
			agClick(Product_LookupPageObjects.selectProdLookUpListing_Radio(
					getTestDataCellValue(scenarioName, "Patient_PatientPastTherapy_ProdDescAsReport")));
			if (scenarioName.equalsIgnoreCase("JapanTest")) {
				agClick(FDE_ProductsPageObjects.checkFirstProdInProdLib);
			}
			CommonOperations.takeScreenShot();
			agClick(Product_LookupPageObjects.okButton);
		} else {
			agSetValue(
					(FDE_PatientPageObjects.productDescriptionReported_Textbox).replace("%rowNo%",
							rowNo_PatientPastTherapy),
					getTestDataCellValue(scenarioName, "Patient_PatientPastTherapy_ProdDescAsReport"));
		}
		agSetValue((FDE_PatientPageObjects.startDatePatPastTherap_Textbox).replace("%rowNo%", rowNo_PatientPastTherapy),
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Patient_PatientPastTherapy_StartDate")));
		agSetValue((FDE_PatientPageObjects.endDatePatPastTherap_Textbox).replace("%rowNo%", rowNo_PatientPastTherapy),
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Patient_PatientPastTherapy_EndDate")));
		agSetValue((FDE_PatientPageObjects.indicationTerm_Textbox).replace("%rowNo%", rowNo_PatientPastTherapy),
				getTestDataCellValue(scenarioName, "Patient_PatientPastTherapy_IndicationTerm"));
		agSendKeyStroke(Keys.TAB);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Patient >> Patient Past Therapy Section 1 : Scenario Name::" + scenarioName, true);

		if (getTestDataCellValue(scenarioName, "Patient_PatientPastTherapy_MedLLTForIndiTerm_Lookup")
				.equalsIgnoreCase("Yes")) {
			agClick((FDE_PatientPageObjects.medDRALLTCodeIndicationTerm_LookUpIcon).replace("%rowNo%",
					rowNo_PatientPastTherapy));
			setDictionaryCodingBrowserDetails(
					getTestDataCellValue(scenarioName, "Patient_PatientPastTherapy_MedCodeIndiTerm_SearchTerm"));
		}
		agSetValue((FDE_PatientPageObjects.reactionTerm_Textbox).replace("%rowNo%", rowNo_PatientPastTherapy),
				getTestDataCellValue(scenarioName, "Patient_PatientPastTherapy_ReactionTerm"));
		agSendKeyStroke(Keys.TAB);
		if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}
		if (getTestDataCellValue(scenarioName, "Patient_PatientPastTherapy_MedLLTForReacTerm_Lookup")
				.equalsIgnoreCase("Yes")) {
			agClick((FDE_PatientPageObjects.medDRALLTCodeReactionTerm_LookUpIcon).replace("%rowNo%",
					rowNo_PatientPastTherapy));
			setDictionaryCodingBrowserDetails(
					getTestDataCellValue(scenarioName, "Patient_PatientPastTherapy_MedDReactionTerm_SearchTerm"));
		}

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Patient >> Patient Past Therapy Section 2 : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: To verify Patient Past Therapy Details in Patient tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyPatientPastTherapyDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String rowNo_PatientPastTherapy = getTestDataCellValue(scenarioName, "RowNo_PatientPastTherapy");
		String boolAdd_PatientPastTherapy = getTestDataCellValue(scenarioName, "boolAdd_PatientPastTherapy");
		verifyData((FDE_PatientPageObjects.productDescriptionReported_Textbox).replace("%rowNo%",
				rowNo_PatientPastTherapy), scenarioName, "Patient_PatientPastTherapy_ProdDescAsReport");
		agCheckPropertyValue("value",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Patient_PatientPastTherapy_StartDate")),
				(FDE_PatientPageObjects.startDatePatPastTherap_Textbox).replace("%rowNo%", rowNo_PatientPastTherapy));
		agCheckPropertyValue("value",
				CommonOperations
						.returnDateTime(getTestDataCellValue(scenarioName, "Patient_PatientPastTherapy_EndDate")),
				(FDE_PatientPageObjects.endDatePatPastTherap_Textbox).replace("%rowNo%", rowNo_PatientPastTherapy));
		verifyData((FDE_PatientPageObjects.indicationTerm_Textbox).replace("%rowNo%", rowNo_PatientPastTherapy),
				scenarioName, "Patient_PatientPastTherapy_IndicationTerm");
		CommonOperations.takeScreenShot();

		verifyData(
				(FDE_PatientPageObjects.medDRALLTCodeIndicationTerm_Textbox).replace("%rowNo%",
						rowNo_PatientPastTherapy),
				scenarioName, "Patient_PatientPastTherapy_MedDRALLTCodeForIndicationTerm");
		verifyData(
				(FDE_PatientPageObjects.medDRAPTCodeIndicationTerm_Textbox).replace("%rowNo%",
						rowNo_PatientPastTherapy),
				scenarioName, "Patient_PatientPastTherapy_MedDRAPTCodeForIndicationTerm");
		verifyData((FDE_PatientPageObjects.reactionTerm_Textbox).replace("%rowNo%", rowNo_PatientPastTherapy),
				scenarioName, "Patient_PatientPastTherapy_ReactionTerm");
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Patient >> Patient Past Therapy Section 1 : Scenario Name::" + scenarioName,
				true);

		verifyData(
				(FDE_PatientPageObjects.medDRALLTCodeReactionTerm_Textbox).replace("%rowNo%", rowNo_PatientPastTherapy),
				scenarioName, "Patient_PatientPastTherapy_MedDRALLTCodeForReactionTerm");
		verifyData(
				(FDE_PatientPageObjects.medDRAPTCodeReactionTerm_Textbox).replace("%rowNo%", rowNo_PatientPastTherapy),
				scenarioName, "Patient_PatientPastTherapy_MedDRAPTCodeForReactionTerm");

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Patient >> Patient Past Therapy Section 2 : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: To set Death Details in Patient tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 05-Sep-2019
	 * @UpdatedByAndWhen:Yashwanth on 31-March-2020
	 **********************************************************************************************************/
	public static void setDeathDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FDE_PatientPageObjects.setData_Datesfields(FDE_PatientPageObjects.dateOfDeath_Date), CommonOperations
				.returnDateTime(getTestDataCellValue(scenarioName, "Patient_DeathDetails_DateOfDeath")));
		if (agIsVisible((FDE_PatientPageObjects.ManualAutopsycheckboxVerify)) == true) {
			CommonOperations.checkAutopsyManual(FDE_PatientPageObjects.manual_Checkbx,
					getTestDataCellValue(scenarioName, "Patient_DeathDetails_AutopsyDone_Manual"));
		}
		agClick(FDE_PatientPageObjects.select_RadioButtons(FDE_PatientPageObjects.autopsyDone_Radio,
				getTestDataCellValue(scenarioName, "Patient_DeathDetails_AutopsyDone")));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Patient >> Death Details Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: To verify death details in Patient tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDeathDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value",
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Patient_DeathDetails_DateOfDeath")),
				FDE_PatientPageObjects.setData_Datesfields(FDE_PatientPageObjects.dateOfDeath_Date));
		CommonOperations.verifyRadioButton(FDE_PatientPageObjects.autopsyDone_Radio,
				getTestDataCellValue(scenarioName, "Patient_DeathDetails_AutopsyDone"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Patient >> Death Details Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: To set Reported Cause(s) of Death Details in Patient tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	// Below Hard Coded Value done for Data Modeling executions.
	static String rowNo_ReportedCauseOfDeath = "0"; // getTestDataCellValue(scenarioName, "RowNo_ReportedCauseOfDeath");
	static String boolAdd_ReportedCauseOfDeath = "false"; // getTestDataCellValue(scenarioName,
															// "boolAdd_ReportedCauseOfDeath");

	public static void setReportedCauseOfDeathDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (boolAdd_ReportedCauseOfDeath.equalsIgnoreCase("true")) {
			agClick(FDE_PatientPageObjects.clickAddButton(FDE_PatientPageObjects.reportedCauseofDeath_Label));
		}
		agSetValue((FDE_PatientPageObjects.reportedCauseofDeath_Textbox).replace("%rowNo%", rowNo_ReportedCauseOfDeath),
				getTestDataCellValue(scenarioName, "Patient_ReportedCausesofDeath_ReportedCauseOfDeath"));
		agSendKeyStroke(Keys.TAB);
		if (getTestDataCellValue(scenarioName, "Patient_ReportedCausesofDeath_MedDForRepCauseOfDeath_Lookup")
				.equalsIgnoreCase("Yes")) {
			agClick((FDE_PatientPageObjects.medDRALLTCodeforReportedCauseofDeath_LookUpIcon).replace("%rowNo%",
					rowNo_ReportedCauseOfDeath));
			setDictionaryCodingBrowserDetails(
					getTestDataCellValue(scenarioName, "Patient_ReportedCausesofDeath_MedRepCausOfDeath_SearchTerm"));
		}

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Patient >> Reported Cause(s) of Death Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: To verify Reported Cause(s) of Death Details in Patient tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyReportedCauseOfDeathDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		verifyData((FDE_PatientPageObjects.reportedCauseofDeath_Textbox).replace("%rowNo%", rowNo_ReportedCauseOfDeath),
				scenarioName, "Patient_ReportedCausesofDeath_ReportedCauseOfDeath");
		verifyData(
				(FDE_PatientPageObjects.medDRALLTCodeforReportedCauseofDeath_Textbox).replace("%rowNo%",
						rowNo_ReportedCauseOfDeath),
				scenarioName, "Patient_ReportedCausesofDeath_MedDForRepCauseOfDeath");
		verifyData((FDE_PatientPageObjects.medDRAPTCodeForReportedCauseOfDeath_Textbox).replace("%rowNo%",
				rowNo_ReportedCauseOfDeath), scenarioName, "Patient_ReportedCauseofDeath_MedPTRepCauseOfDeath");

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Patient >> Reported Cause(s) of Death Section : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: To set Autopsy Determined Cause(s) of Death Details in Patient
	 *             tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 05-Sep-2019
	 * @UpdatedByAndWhen: Sanchit on 27-Nov-2019
	 **********************************************************************************************************/
	// Below Hard Coded Value done for Data Modeling executions.
	static String rowNo_AutopsyDeterminedCauseofDeath = "0"; // getTestDataCellValue(scenarioName,
																// "RowNo_AutopsyDeterminedCauseofDeath");
	static String boolAdd_AutopsyDeterminedCauseOfDeath = "false"; // getTestDataCellValue(scenarioName,
																	// "boolAdd_AutopsyDeterminedCauseOfDeath");

	public static void setAutopsyDeterminedCauseOfDeath(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (boolAdd_AutopsyDeterminedCauseOfDeath.equalsIgnoreCase("true")) {
			agClick(FDE_PatientPageObjects.clickAddButton(FDE_PatientPageObjects.autopsyDeterminedCauseofDeath_Label));
		}
		agSetValue(
				(FDE_PatientPageObjects.autopsyDeterminedCauseofDeath_Textbox).replace("%rowNo%",
						rowNo_AutopsyDeterminedCauseofDeath),

				getTestDataCellValue(scenarioName, "Patient_AutoDetCauofDeath_AutopsyDeterminedCauseOfDeath"));
		agSendKeyStroke(Keys.TAB);
		if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}
		if (getTestDataCellValue(scenarioName, "Patient_AutopsyDeterminedCausesofDeath_MedDRALLTCode_Lookup")
				.equalsIgnoreCase("Yes")) {
			agClick((FDE_PatientPageObjects.medDRALLTCodeforAutopsyDeterminedCauseofDeath_LookUpIcon).replace("%rowNo%",
					rowNo_AutopsyDeterminedCauseofDeath));
			setDictionaryCodingBrowserDetails(
					getTestDataCellValue(scenarioName, "Patient_AutpsyDeterCauseofDeath_MedLLT_SearchTerm"));
		}

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Patient >> Autopsy Determined Cause(s) of Death Section : Scenario Name::"
						+ scenarioName,
				true);
	}

	/********************************************************************************************************
	 * @Objective: To verify Autopsy Determined Cause(s) of Death Details in Patient
	 *             tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyAutopsyDeterminedCauseOfDeath(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		verifyData(
				(FDE_PatientPageObjects.autopsyDeterminedCauseofDeath_Textbox).replace("%rowNo%",
						rowNo_AutopsyDeterminedCauseofDeath),
				scenarioName, "Patient_AutoDetCauofDeath_AutopsyDeterminedCauseOfDeath");
		verifyData(
				(FDE_PatientPageObjects.medDRALLTCodeforAutopsyDeterminedCauseofDeath_Textbox).replace("%rowNo%",
						rowNo_AutopsyDeterminedCauseofDeath),
				scenarioName, "Patient_AutopsyDeterminedCausesofDeath_MedDRALLTCode");
		verifyData(
				(FDE_PatientPageObjects.medDRAPTCodeForAutopsyDeterminedCauseOfDeath_Textbox).replace("%rowNo%",
						rowNo_AutopsyDeterminedCauseofDeath),
				scenarioName, "Patient_AutopsyDeterminedCausesofDeath_MedDRAPTCode");

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Patient >> Autopsy Determined Cause(s) of Death Section : Scenario Name::"
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: To set Risk Factor Details in Patient tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 5-Dec-2019
	 * @UpdatedByAndWhen:WajahatUmar S
	 **********************************************************************************************************/
	// Below Hard Coded Value done for Data Modeling executions.
	static String rowNo_RiskFactor = "0"; // getTestDataCellValue(scenarioName, "RowNo_RiskFactor");
	static String boolAdd_RiskFactor = "false"; // getTestDataCellValue(scenarioName, "boolAdd_RiskFactor");

	public static void setRiskFactor(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (boolAdd_RiskFactor.equalsIgnoreCase("true")) {
			agClick(FDE_PatientPageObjects.clickAddButton(FDE_PatientPageObjects.riskFactor_Label));
		}

		// agSelectByVisibleText(FDE_PatientPageObjects.evaluation_DropDown,
		// getTestDataCellValue(scenarioName, "Patient_RiskFactor_Evaluation"));
		// agSelectByVisibleText(FDE_PatientPageObjects.riskFactor_DropDown,
		// getTestDataCellValue(scenarioName, "Patient_RiskFactor_RiskFactor"));
		agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.riskFactor);
		CommonOperations.setFDEDropDownValue(
				(FDE_PatientPageObjects.evaluation_DropDown).replace("%rowNo%", rowNo_RiskFactor),
				getTestDataCellValue(scenarioName, "Patient_RiskFactor_Evaluation"));
		CommonOperations.setFDEDropDownValue(
				(FDE_PatientPageObjects.riskFactor_DropDown).replace("%rowNo%", rowNo_RiskFactor),
				getTestDataCellValue(scenarioName, "Patient_RiskFactor_RiskFactor"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Patient >> Risk Factor Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: To verify Risk Factor Details in Patient tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 5-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyRiskFactor(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.verifyFDEDropDownValue((FDE_PatientPageObjects.evaluation_DropDown),
				getTestDataCellValue(scenarioName, "Patient_RiskFactor_Evaluation"));
		CommonOperations.verifyFDEDropDownValue((FDE_PatientPageObjects.riskFactor_DropDown),
				getTestDataCellValue(scenarioName, "Patient_RiskFactor_RiskFactor"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Patient >> Risk Factor Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: To verify Autopsy Done in Patient tab
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 05-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verify_AutopsyDone() {
		String value = agGetAttribute("class",
				FDE_PatientPageObjects.select_RadioButtons(FDE_PatientPageObjects.autopsyDone_Radio, "Yes"));
		if (value.contains("active")) {
			Reports.ExtentReportLog("Autopsy done radio auto selected on save", Status.PASS, "", true);
		} else {
			Reports.ExtentReportLog("Autopsy done radio auto not selected on save", Status.FAIL, "", true);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Patient data in Patient tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :04-Sep-2019
	 * @UpdatedByAndWhen:Sanchit on 27-Nov-2019
	 **********************************************************************************************************/
	public static void set_Patient(String scenarioName) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,
		// "ConfigurationSettings");
		// if (getTestDataCellValue(scenarioName, "FDE_Parent").equalsIgnoreCase("Yes"))
		// {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		set_PatientIdentifiers_Data(scenarioName);
		Reports.ExtentReportLog("", Status.PASS, "", true);
		setMedicalHistoryDetails(scenarioName);
		setPatientPastTherapyDetails(scenarioName);
		setDeathDetails(scenarioName);
		setReportedCauseOfDeathDetails(scenarioName);
		setAutopsyDeterminedCauseOfDeath(scenarioName);
		setRiskFactor(scenarioName);
		// }
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in patient tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :05-Sep-2019
	 * @UpdatedByAndWhen:Sanchit on 27-Nov-2019
	 **********************************************************************************************************/
	public static void patientData_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		patientIdentifiers_Verification(scenarioName);
		verifyMedicalHistoryDetails(scenarioName);
		verifyPatientPastTherapyDetails(scenarioName);
		verifyDeathDetails(scenarioName);
		verifyReportedCauseOfDeathDetails(scenarioName);
		verifyAutopsyDeterminedCauseOfDeath(scenarioName);
		verifyRiskFactor(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to check Null Flavour and selected
	 *             dropdown value based on excel data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 22-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void set_PatientNullFlavours(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agClick(FDE_PatientPageObjects.click_NFBtn(FDE_PatientPageObjects.patientID_Textbox));
		setNullFlavourDropDownValue(FDE_PatientPageObjects.patientID_Textbox, scenarioName,
				"Patient_PatientIdentifiers_PatientID");

		agClick(FDE_PatientPageObjects.click_NFBtn(FDE_PatientPageObjects.patientDOB_Date));
		setNullFlavourDropDownValue(FDE_PatientPageObjects.patientDOB_Date, scenarioName,
				"Patient_PatientIdentifiers_PatientDOB");

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Automatic calculation of Patient Age and
	 *             Patient Age Group
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @throws ParseException
	 * @throws java.text.ParseException
	 * @Date : 06-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AutocalculationofPatientAgeandPatientageGroup() throws ParseException, java.text.ParseException {
		Reports.ExtentReportLog("", Status.INFO, "Auto calculation of Patient Age and Pateint age Group Started", true);
		try {
			FDE_Operations.tabNavigation("Event(s)");
			agClick(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date));
			String OnsetDate = agGetAttribute("title",
					FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date));
			FDE_Operations.tabNavigation("Patient");
			agClick(FDE_PatientPageObjects.setData_Datesfields(FDE_PatientPageObjects.patientDOB_Date));
			String LMPDate = agGetAttribute("title",
					FDE_PatientPageObjects.setData_Datesfields(FDE_PatientPageObjects.patientDOB_Date));

			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);

			String AgeatEventDropdown = agGetText(FDE_PatientPageObjects.AgeAtTimeofEVentDropDownValue);
			agClick(FDE_PatientPageObjects.AgeAtTimeofEventTextBoxValue);
			String AgeAtEventTextBox = agGetAttribute("title", FDE_PatientPageObjects.AgeAtTimeofEventTextBoxValue);

			if (LMPDate.equals("") || OnsetDate.equals("")) {
				Reports.ExtentReportLog("", Status.INFO, "No Data Found To Calculate Patient Age and Patient Age Group",
						true);
			} else {
				Date firstDate = sdf.parse(LMPDate);
				Date secondDate = sdf.parse(OnsetDate);
				int diffYear = Math.abs(secondDate.getYear() - firstDate.getYear());
				int diffMonth = diffYear * 12 + secondDate.getMonth() - firstDate.getMonth();
				long diffDay = Math.abs(secondDate.getDay() - firstDate.getDay());

				System.out.print(AgeAtEventTextBox);
				System.out.print(diffMonth);
				if (AgeatEventDropdown.equalsIgnoreCase("Month(s) ( M )")) {

					if (AgeAtEventTextBox.equalsIgnoreCase(String.valueOf(diffMonth))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Patient Age in Months Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Patient Age in Months Doesnt Match", true);
					}

					if (diffMonth <= 23) {
						agCheckPropertyText("Infant ( Inf )",
								FDE_PatientPageObjects.click_DropDown(FDE_PatientPageObjects.ageGroup_DropDown));
					}

				} else if (AgeatEventDropdown.equalsIgnoreCase("Year(s) ( Y )")) {

					if (AgeAtEventTextBox.equalsIgnoreCase(String.valueOf(diffYear))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Patient Age in Years Matches", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Patient Age in Years Doesnt Match", true);
					}
					if (diffYear == 2 || diffYear <= 11) {
						agCheckPropertyText("Child ( Chi ) ",
								FDE_PatientPageObjects.click_DropDown(FDE_PatientPageObjects.ageGroup_DropDown));
					} else if (diffYear == 12 || diffYear <= 18) {
						agCheckPropertyText("Adolescent ( Ado )",
								FDE_PatientPageObjects.click_DropDown(FDE_PatientPageObjects.ageGroup_DropDown));
					} else if (diffYear > 18 || diffYear <= 65) {
						agCheckPropertyText("Adult ( Adu )",
								FDE_PatientPageObjects.click_DropDown(FDE_PatientPageObjects.ageGroup_DropDown));
					} else if (diffYear > 65) {
						agCheckPropertyText("Elderly ( Eld )",
								FDE_PatientPageObjects.click_DropDown(FDE_PatientPageObjects.ageGroup_DropDown));
					}
				} else if (AgeatEventDropdown.equalsIgnoreCase("Day(s) ( D )")) {

					if (AgeAtEventTextBox.equalsIgnoreCase(String.valueOf(diffDay))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Patient Age in Days", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Calculated Patient Age Doesnt Match", true);
					}
					if (diffDay == 0 || diffDay <= 27) {
						// Neonate: 0-27 days
						agCheckPropertyText("Neonate ( Neo )",
								FDE_PatientPageObjects.click_DropDown(FDE_PatientPageObjects.ageGroup_DropDown));
					} else if (diffDay >= 28) {
						agCheckPropertyText("Infant ( Inf )",
								FDE_PatientPageObjects.click_DropDown(FDE_PatientPageObjects.ageGroup_DropDown));
					}

				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Patient Age and Patient Group Failed to AutoCalculate",
							true);
				}
			}

		}

		catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Auto calculation of Patient Age and Pateint age Group Fails",
					true);
		}
		Reports.ExtentReportLog("", Status.INFO, "Auto calculation of Patient Age and Pateint age Group Ends", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Automatic calculation of BSI and BMI
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @throws ParseException
	 * @throws java.text.ParseException
	 * @Date : 11-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AutocalculationofBSIandBMI() {
		Reports.ExtentReportLog("", Status.INFO, "Auto calculation of BSI and BMI Started", true);
		try {
			FDE_Operations.tabNavigation("Patient");
			agClick(FDE_PatientPageObjects.set_WeightHeight(FDE_PatientPageObjects.weight_DropDown));
			String Weight = agGetAttribute("title",
					FDE_PatientPageObjects.set_WeightHeight(FDE_PatientPageObjects.weight_DropDown));
			agClick(FDE_PatientPageObjects.set_WeightHeight(FDE_PatientPageObjects.height_DropDown));
			String Height = agGetAttribute("title",
					FDE_PatientPageObjects.set_WeightHeight(FDE_PatientPageObjects.height_DropDown));

			if (Weight.equals("") || Height.equals("")) {
				Reports.ExtentReportLog("", Status.INFO, "No Data Found to Calculate BSI and BMI", true);
			} else {

				double WeightBSI = Double.parseDouble(Weight);
				double HeightBSI = Double.parseDouble(Height);
				String WeightUnits = agGetText(FDE_PatientPageObjects.WeightUnits).trim();
				String HeightUnits = agGetText(FDE_PatientPageObjects.HeightUnits).trim();
				double ConvertToKiloGrams;
				double ConvertToMeter;
				double BodySurfaceIndex;
				double BodyMassIndex;
				agSetStepExecutionDelay("3000");
				agClick(FDE_PatientPageObjects.bodyMassIndex_Textbox);
				String BMIAutoCalculated = agGetAttribute("title", FDE_PatientPageObjects.bodyMassIndex_Textbox);
				agSetStepExecutionDelay("3000");
				agClick(FDE_PatientPageObjects.bodySurfaceIndex_Textbox);
				String BSIAutoCalculated = agGetAttribute("title", FDE_PatientPageObjects.bodySurfaceIndex_Textbox);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				if (WeightUnits.equalsIgnoreCase("Ounce ( Oz )")) {
					// Converting Ounce into KiloGram
					ConvertToKiloGrams = WeightBSI * 0.0283495;

				} else if (WeightUnits.equalsIgnoreCase("Pounds")) {
					// Converting Pound into KiloGram
					ConvertToKiloGrams = WeightBSI * 0.4535148;
				} else {

					ConvertToKiloGrams = WeightBSI;
				}
				if (HeightUnits.equalsIgnoreCase("Centimeters")) {
					// Convert Centimeter into meter
					ConvertToMeter = HeightBSI * 0.01;
					// Formula to Calculate Body Mass Index
					BodyMassIndex = ConvertToKiloGrams / (ConvertToMeter * ConvertToMeter);
					// Formula to Calculate Body Surface Index
					BodySurfaceIndex = Math.sqrt((HeightBSI * ConvertToKiloGrams) / 3600);
					String BMI = String.valueOf(BodyMassIndex).substring(0, 4);
					String BSI = String.valueOf(BodySurfaceIndex).substring(0, 4);
					if ((BMI.equalsIgnoreCase(BMIAutoCalculated.substring(0, 4)))
							&& (BSI.equalsIgnoreCase(BSIAutoCalculated))) {
						Reports.ExtentReportLog("", Status.PASS, "Automatic calculation of BSI and BMI Matches ", true);

					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Automatic calculation of BSI and BMI Doesnt Matches ",
								true);
					}

				} else if (HeightUnits.equalsIgnoreCase("Inches")) {
					// Convert inch into meter
					ConvertToMeter = HeightBSI * 39.3701;
					// sFormula to Calculate Body Mass Index
					BodyMassIndex = ConvertToKiloGrams / (ConvertToMeter * ConvertToMeter);
					// Formula to Calculate Body Surface Index
					BodySurfaceIndex = Math.sqrt((HeightBSI * ConvertToKiloGrams) / 3600);
					String BMI = String.valueOf(BodyMassIndex).substring(0, 4);
					String BSI = String.valueOf(BodySurfaceIndex).substring(0, 4);
					if ((BMI.equalsIgnoreCase(BMIAutoCalculated)) && (BSI.equalsIgnoreCase(BSIAutoCalculated))) {
						Reports.ExtentReportLog("", Status.PASS, "Automatic calculation of BSI and BMI Matches ", true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL, "Automatic calculation of BSI and BMI Doesnt Matches ",
								true);
					}

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Auto calculation of BMI and BSI Fails", true);
		}

		Reports.ExtentReportLog("", Status.INFO, "Auto calculation of BMI and BSI Ends", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Automatic calculation of Gestation Week in
	 *             Patient Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @throws ParseException
	 * @throws java.text.ParseException
	 * @Date : 12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AutocalculationofGestationWeek() throws ParseException, java.text.ParseException {
		Reports.ExtentReportLog("", Status.INFO, "Auto calculation of Gestation Week Started", true);
		try {
			FDE_Operations.tabNavigation("Patient");
			agClick(FDE_PatientPageObjects.setData_Datesfields(FDE_PatientPageObjects.lMPDate_Date));
			String LMPDate = agGetAttribute("title",
					FDE_PatientPageObjects.setData_Datesfields(FDE_PatientPageObjects.lMPDate_Date));

			FDE_Operations.tabNavigation("Event(s)");
			agClick(FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date));
			String OnsetDate = agGetAttribute("title",
					FDE_EventsPageObjects.setData_Datesfields(FDE_EventsPageObjects.onsetDate_Date));
			FDE_Operations.tabNavigation("Patient");
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
			if (LMPDate.equals("") || OnsetDate.equals("")) {
				Reports.ExtentReportLog("", Status.INFO, "No Data Found", true);
			} else {

				Date firstDate = sdf.parse(LMPDate);
				Date secondDate = sdf.parse(OnsetDate);
				String GestationalWeekDD = agGetText(FDE_PatientPageObjects.GestationAgeDropDownValue);
				agClick(FDE_PatientPageObjects.GestationAgeTextBoxValue);
				String GestationalWeek = agGetAttribute("title", FDE_PatientPageObjects.GestationAgeTextBoxValue);

				int diffYear = Math.abs(secondDate.getYear() - firstDate.getYear());
				int diffMonth = diffYear * 12 + secondDate.getMonth() - firstDate.getMonth();
				long diffDay = Math.abs(secondDate.getDay() - firstDate.getDay());
				long weeks = diffDay / 7;

				long WEEKS_IN_PREGNANCY = 40;
				long DAYS_IN_PREGNANCY = WEEKS_IN_PREGNANCY * 7;

				if (GestationalWeekDD.equalsIgnoreCase("Days")) {
					if (GestationalWeek.equalsIgnoreCase(String.valueOf(diffDay))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Gestational Age At Event in Days Matches",
								true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL,
								"Calculated Gestational Age At Event in Days Doesnt Matches", true);
					}
				} else if (GestationalWeekDD.equalsIgnoreCase("Months")) {
					if (GestationalWeek.equalsIgnoreCase(String.valueOf(diffMonth))) {
						Reports.ExtentReportLog("", Status.PASS, "Calculated Gestational Age At Event in Month Matches",
								true);
					} else {
						Reports.ExtentReportLog("", Status.FAIL,
								"Calculated Gestational Age At Event in Month Doesnt Matches", true);
					}
				} else if (GestationalWeekDD.equalsIgnoreCase("Trimester")) {
					if (diffMonth <= 3) {
						if (GestationalWeek.equalsIgnoreCase("1")) {
							Reports.ExtentReportLog("", Status.PASS,
									"Calculated Gestational Age At Event in Trimester Matches", true);
						} else {
							Reports.ExtentReportLog("", Status.FAIL,
									"Calculated Gestational Age At Event in Trimester Doesnt Matches", true);
						}
					} else if (diffMonth > 3 || diffMonth <= 6) {
						if (GestationalWeek.equalsIgnoreCase("2")) {
							Reports.ExtentReportLog("", Status.PASS,
									"Calculated Gestational Age At Event in Trimester Matches Matches", true);
						} else {
							Reports.ExtentReportLog("", Status.FAIL,
									"Calculated Gestational Age At Event in Trimester Matches Doesnt Matches", true);

						}
					} else if (diffMonth > 6 || diffMonth <= 9) {
						if (GestationalWeek.equalsIgnoreCase("3")) {
							Reports.ExtentReportLog("", Status.PASS,
									"Calculated Gestational Age At Event in Trimester Matches", true);
						} else {
							Reports.ExtentReportLog("", Status.FAIL,
									"Calculated Gestational Age At Event in Trimester Matches Doesnt Matches", true);
						}

					}

				} else if (GestationalWeekDD.equalsIgnoreCase("Weeks")) {
					if (GestationalWeek.equalsIgnoreCase(String.valueOf(weeks))) {
						Reports.ExtentReportLog("Calculated Gestational Age At Event in Weeks Matches", Status.PASS, "",
								true);
					} else {
						Reports.ExtentReportLog("Calculated Gestational Age At Event in Weeks Doesnt Matches",
								Status.FAIL, "", true);
					}
				} else {
					Reports.ExtentReportLog("", Status.FAIL,

							"Gestational Age At Event in Trimester are not getting AutoCalculated", true);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Auto calculation of Gestation Week Fails", true);
		}

		Reports.ExtentReportLog("", Status.INFO, "Auto calculation of Gestation Week Ends", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below methodAutopsy Performed must be set to Yes, if a
	 *             Disease record has Determined by Autopsy data
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @Date : 24-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AutopsyPerformedMustbeYesifDiseaseRecord() {
		Reports.ExtentReportLog("", Status.INFO, "Autopsy Performed Must be Yes if Disease Record Started", true);
		try {
			FDE_Operations.tabNavigation("Patient");
			agClick((FDE_PatientPageObjects.autopsyDeterminedCauseofDeath_Textbox).replace("%rowNo%",
					rowNo_AutopsyDeterminedCauseofDeath));
			String VerifyAutopsyData = agGetAttribute("title",
					(FDE_PatientPageObjects.autopsyDeterminedCauseofDeath_Textbox).replace("%rowNo%",
							rowNo_AutopsyDeterminedCauseofDeath));
			if (!VerifyAutopsyData.isEmpty()) {
				FDE_Patient.verify_AutopsyDone();

			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Autopsy Performed Must be Yes if Disease Record Fails", true);
		}
		Reports.ExtentReportLog("", Status.INFO, "Autopsy Performed Must be Yes if Disease Record Ends", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify R2 tags in Patient tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 18-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyPatientR2Tags() {
		Reports.ExtentReportLog("", Status.INFO, "********Study R2 tag verification Started*******", true);
		agAssertVisible(FDE_PatientPageObjects.R2PatientId);
		agAssertVisible(FDE_PatientPageObjects.R2PatientDOB);
		agAssertVisible(FDE_PatientPageObjects.R2AgeAtTheTimeOfEvent);
		agAssertVisible(FDE_PatientPageObjects.R2GestationalAgeAtEvent);
		agAssertVisible(FDE_PatientPageObjects.R2AgeGroup);
		agAssertVisible(FDE_PatientPageObjects.R2Gender);
		agAssertVisible(FDE_PatientPageObjects.R2Weight);
		agAssertVisible(FDE_PatientPageObjects.R2Height);
		agAssertVisible(FDE_PatientPageObjects.R2LMPDate);
		agAssertVisible(FDE_PatientPageObjects.R2SpecialistRecordNumber);
		agAssertVisible(FDE_PatientPageObjects.R2HospitalRecordNo);
		agAssertVisible(FDE_PatientPageObjects.R2GPMedicalRecordNumber);
		agAssertVisible(FDE_PatientPageObjects.R2InvestigationNumber);
		agAssertVisible(FDE_PatientPageObjects.R2MedicalHistoryAndConcurrentConditions);
		agAssertVisible(FDE_PatientPageObjects.R2DiseaseTerm);
		agAssertVisible(FDE_PatientPageObjects.R2StartDate);
		agAssertVisible(FDE_PatientPageObjects.R2EndDate);
		agAssertVisible(FDE_PatientPageObjects.R2Continuing);
		agAssertVisible(FDE_PatientPageObjects.R2DiseaseComments);
		agAssertVisible(FDE_PatientPageObjects.R2ProductNameAsReported);
		agAssertVisible(FDE_PatientPageObjects.R2PPTStartDate);
		agAssertVisible(FDE_PatientPageObjects.R2PPTEndDate);
		agAssertVisible(FDE_PatientPageObjects.R2IndicationTerm);
		agAssertVisible(FDE_PatientPageObjects.R2ReactionTerm);
		agAssertVisible(FDE_PatientPageObjects.R2DateOfDeath);
		agAssertVisible(FDE_PatientPageObjects.R2AutopsyDone);
		agAssertVisible(FDE_PatientPageObjects.R2ReportedCauseOfDeath);
		agAssertVisible(FDE_PatientPageObjects.R2AutopsyDeterminedCauseOfDeath);
		Reports.ExtentReportLog("", Status.INFO, "********Study R2 tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify R3 tags in Patient tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 18-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyPatientR3Tags() {
		Reports.ExtentReportLog("", Status.INFO, "********Study R3 tag verification Started*******", true);
		agAssertVisible(FDE_PatientPageObjects.R3PatientId);
		agAssertVisible(FDE_PatientPageObjects.R3PatientDob);
		agAssertVisible(FDE_PatientPageObjects.R3AgeAtTheTimeOfEvent);
		agAssertVisible(FDE_PatientPageObjects.R3GestationalAgeAtEvent);
		agAssertVisible(FDE_PatientPageObjects.R3AgeGroup);
		agAssertVisible(FDE_PatientPageObjects.R3Gender);
		agAssertVisible(FDE_PatientPageObjects.R3Weight);
		agAssertVisible(FDE_PatientPageObjects.R3Race);
		agAssertVisible(FDE_PatientPageObjects.R3Ethnicity);
		agAssertVisible(FDE_PatientPageObjects.R3Height);
		agAssertVisible(FDE_PatientPageObjects.R3LMPDate);
		agAssertVisible(FDE_PatientPageObjects.R3SpecialistRecordNumber);
		agAssertVisible(FDE_PatientPageObjects.R3HospitalRecordNumber);
		agAssertVisible(FDE_PatientPageObjects.R3GPMedicalRecordNumber);
		agAssertVisible(FDE_PatientPageObjects.R3InvestigationNumber);
		agAssertVisible(FDE_PatientPageObjects.R3ConcomitantTherapies);
		agAssertVisible(FDE_PatientPageObjects.R3MedicalHistoryAndConcurrentConditions);
		agAssertVisible(FDE_PatientPageObjects.R3FamilyHistory);
		agAssertVisible(FDE_PatientPageObjects.R3MedDRALLTForDiseaseTerm);
		agAssertVisible(FDE_PatientPageObjects.R3StartDate);
		agAssertVisible(FDE_PatientPageObjects.R3EndDate);
		agAssertVisible(FDE_PatientPageObjects.R3Continuing);
		agAssertVisible(FDE_PatientPageObjects.R3DiseaseComments);
		agAssertVisible(FDE_PatientPageObjects.R3ProductNameAsReported);
		agAssertVisible(FDE_PatientPageObjects.R3MPIDVersionDate_Number);
		agAssertVisible(FDE_PatientPageObjects.R3MedicinalProductIdentifier_MPID);
		agAssertVisible(FDE_PatientPageObjects.R3PhPID);
		agAssertVisible(FDE_PatientPageObjects.R3PhPIDVersionDate_Number);
		agAssertVisible(FDE_PatientPageObjects.R3PPtStartDate);
		agAssertVisible(FDE_PatientPageObjects.R3PPtEndDate);
		agAssertVisible(FDE_PatientPageObjects.R3MedDRALLTCodeForIndicationTerm);
		agAssertVisible(FDE_PatientPageObjects.R3MedDRALLTCodeForReactionTerm);
		agAssertVisible(FDE_PatientPageObjects.R3ScientificName);
		agAssertVisible(FDE_PatientPageObjects.R3TrademarkName);
		agAssertVisible(FDE_PatientPageObjects.R3StrengthName);
		agAssertVisible(FDE_PatientPageObjects.R3FormName);
		agAssertVisible(FDE_PatientPageObjects.R3ContainerName);
		agAssertVisible(FDE_PatientPageObjects.R3InventedName);
		agAssertVisible(FDE_PatientPageObjects.R3DeviceName);
		agAssertVisible(FDE_PatientPageObjects.R3IntendedUseName);
		agAssertVisible(FDE_PatientPageObjects.R3Substance_SpecifiedSubstanceName);
		agAssertVisible(FDE_PatientPageObjects.R3SubstanceTermIDVerDate_Num);
		agAssertVisible(FDE_PatientPageObjects.R3Substance_SpecifiedSubstanceTermID);
		agAssertVisible(FDE_PatientPageObjects.R3Strength_Number);
		agAssertVisible(FDE_PatientPageObjects.R3DeathDate);
		agAssertVisible(FDE_PatientPageObjects.R3AutopsyDone);
		agAssertVisible(FDE_PatientPageObjects.R3ReportedCauseOfDeath);
		agAssertVisible(FDE_PatientPageObjects.R3MedDRALLTCodeForReportedCauseOfDeath);
		agAssertVisible(FDE_PatientPageObjects.R3AutopsyDeterminedCauseOfDeath);
		agAssertVisible(FDE_PatientPageObjects.R3MedDRALLTCodeForAutopsyDeterminedCauseOfDeath);
		Reports.ExtentReportLog("", Status.INFO, "********Study R3 tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify Codelist tags in Patient tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 18-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyPatientCodeList() {
		Reports.ExtentReportLog("", Status.INFO, "********Study Codelist tag verification Started*******", true);
		agAssertVisible(FDE_PatientPageObjects.CLProtectConfidentiality);
		agAssertVisible(FDE_PatientPageObjects.CLAgeAtTheTimeOfEvent);
		agAssertVisible(FDE_PatientPageObjects.CLGestationalAgeAtEvent);
		agAssertVisible(FDE_PatientPageObjects.CLConsentToContactPatient);
		agAssertVisible(FDE_PatientPageObjects.CLAgeGroup);
		agAssertVisible(FDE_PatientPageObjects.CLGender);
		agAssertVisible(FDE_PatientPageObjects.CLWeight);
		agAssertVisible(FDE_PatientPageObjects.CLRace);
		agAssertVisible(FDE_PatientPageObjects.CLEthnicity);
		agAssertVisible(FDE_PatientPageObjects.ClPregnant);
		agAssertVisible(FDE_PatientPageObjects.CLHeight);
		agAssertVisible(FDE_PatientPageObjects.CLIdentifiablePatient);
		agAssertVisible(FDE_PatientPageObjects.CLConcomitantTherapies);
		agAssertVisible(FDE_PatientPageObjects.CLBirthWeight);
		agAssertVisible(FDE_PatientPageObjects.CLDiseaseType);
		agAssertVisible(FDE_PatientPageObjects.CLFamilyHistory);
		agAssertVisible(FDE_PatientPageObjects.CLContinuing);
		agAssertVisible(FDE_PatientPageObjects.CLRelevantforEventDescription);
		agAssertVisible(FDE_PatientPageObjects.CLConditionTreated);
		agAssertVisible(FDE_PatientPageObjects.CLCodingType);
		agAssertVisible(FDE_PatientPageObjects.CLStrengthNumber);
		agAssertVisible(FDE_PatientPageObjects.CLAutopsyDone);
		agAssertVisible(FDE_PatientPageObjects.CLRiskFactor);
		agAssertVisible(FDE_PatientPageObjects.CLEvaluation);
		Reports.ExtentReportLog("", Status.INFO, "********Study Codelist tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to key data in patient's details for
	 *             Age group calculations
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 14-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void loadAgeGroupCaluculatorData(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AgeGroupCalculator");
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to key data in patient's details for
	 *             Age group calculations
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 14-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void keyDateForAgeGroupCalculation(String scenarioName, String prevScenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AgeGroupCalculator");
		System.out.println("Scenario Name: " + scenarioName);
		agSetStepExecutionDelay("1000");

		try {
			CommonOperations.clickManualCheckBox(FDE_PatientPageObjects.ageTimeEvent_DropDown,
					getTestDataCellValue(scenarioName, "AgeAtTheTimeOfEvent_Manual"));
			agSetValue(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.patientID_Textbox),
					getTestDataCellValue(scenarioName, "PatientID"));
			System.out.println("Patient DOB: " + getTestDataCellValue(scenarioName, "DOB"));
			agClearText(FDE_PatientPageObjects.patientDOB_Text);
			agSetValue(FDE_PatientPageObjects.patientDOB_Text, getTestDataCellValue(scenarioName, "DOB"));
			agSendKeyStroke(Keys.TAB);

			if (getTestDataCellValue(scenarioName, "AgeAtTheTimeOfEvent_Manual").equalsIgnoreCase("Check")) {
				agSetValue(FDE_PatientPageObjects.ageAtEvent,
						getTestDataCellValue(scenarioName, "AgeAtTheTimeOfEvent"));
				if (!getTestDataCellValue(scenarioName, "AgeAtTheTimeOfEvent_Units").equalsIgnoreCase("#skip#")) {
					agClick(FDE_PatientPageObjects.click_embeddedDrpdwn(FDE_PatientPageObjects.ageTimeEvent_DropDown));
					agWaitTillVisibilityOfElement(FDE_PatientPageObjects
							.setdropDownValue(getTestDataCellValue(scenarioName, "AgeAtTheTimeOfEvent_Units")));
					agClick(FDE_PatientPageObjects
							.setdropDownValue(getTestDataCellValue(scenarioName, "AgeAtTheTimeOfEvent_Units")));
				}
			}

			agSetStepExecutionDelay("4000");
			Reports.ExtentReportLog("", Status.PASS, "", true);
			FDE_Operations.LSMVSaveReconsile();

			// if (!getTestDataCellValue(scenarioName, "PatientID").equalsIgnoreCase("") ||
			// !getTestDataCellValue(scenarioName, "PatientID").equalsIgnoreCase("#skip#"))
			// {
			// CommonOperations.log("<br />"+"PatientID: ",
			// getTestDataCellValue(scenarioName, "PatientID"));
			// }
			//
			// if (prevScenarioName.equalsIgnoreCase("AutoAgeGroupCalculator_0")) {
			//
			// CommonOperations.log("<br />"+"Patient DOB: ",
			// getTestDataCellValue(scenarioName, "DOB"));
			// }
			// else if (!getTestDataCellValue(scenarioName,
			// "DOB").equalsIgnoreCase(getTestDataCellValue(prevScenarioName, "DOB"))) {
			// CommonOperations.log("<br />"+"Patient DOB: ",
			// getTestDataCellValue(scenarioName, "DOB"));
			// }
			//
			// System.out.println("AgeAtTheTimeOfEvent_Manual: "+
			// getTestDataCellValue(scenarioName, "AgeAtTheTimeOfEvent_Manual"));
			// if (getTestDataCellValue(scenarioName,
			// "AgeAtTheTimeOfEvent_Manual").trim().equalsIgnoreCase("check")) {
			// CommonOperations.log("<br />"+"AgeAtTheTimeOfEvent: ",
			// getTestDataCellValue(scenarioName, "AgeAtTheTimeOfEvent")+ " "
			// + getTestDataCellValue(scenarioName, "AgeAtTheTimeOfEvent_Units"));
			// }

		} catch (Exception e) {
			Reports.ExtentReportLog("", Status.FAIL, "<br />" + "Failed to key Patient's details for scenario.", false);
		}
		agSetStepExecutionDelay("1000");
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to key data in patient's details for
	 *             Age group calculations
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 14-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void validateAutoAgeGroupCalculation(String scenarioName) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,
		// "AgeGroupCalculator");
		System.out.println("Scenario Name: " + scenarioName);
		/*
		 * String boolCheck = getTestDataCellValue(scenarioName,
		 * "AgeAtTheTimeOfEvent_Manual"); String date =
		 * getTestDataCellValue(scenarioName, "DOB"); boolean boolAgeVal = true; boolean
		 * boolAgeUnit = false; boolean boolageGroup = false;
		 */

		/*
		 * if(agGetText(FDE_PatientPageObjects.ageAtEvent).trim().equalsIgnoreCase(
		 * getTestDataCellValue(scenarioName, "AgeAtTheTimeOfEvent"))) {
		 * Reports.ExtentReportLog("", Status.PASS, "", false); boolAgeVal = true; }
		 * else { Reports.ExtentReportLog("", Status.FAIL, "", false); }
		 */
		System.out.println("FDE_PatientPageObjects.ageTimeEvent_DropDown: "
				+ agGetText(FDE_PatientPageObjects.click_embeddedDrpdwn(FDE_PatientPageObjects.ageTimeEvent_DropDown)));

		if (agGetText(FDE_PatientPageObjects.click_embeddedDrpdwn(FDE_PatientPageObjects.ageTimeEvent_DropDown)).trim()
				.equalsIgnoreCase(getTestDataCellValue(scenarioName, "AgeAtTheTimeOfEvent_Units"))) {
			Reports.ExtentReportLog("", Status.PASS, "", false);
			// boolAgeUnit = true;
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "", false);
		}

		System.out.println("FDE_PatientPageObjects.ageGroup_DropDown: "
				+ agGetText(FDE_PatientPageObjects.click_DropDown(FDE_PatientPageObjects.ageGroup_DropDown)));

		if (agGetText(FDE_PatientPageObjects.click_DropDown(FDE_PatientPageObjects.ageGroup_DropDown)).trim()
				.equalsIgnoreCase(getTestDataCellValue(scenarioName, "AgeGroup"))) {
			Reports.ExtentReportLog("", Status.PASS, "", false);
			// boolageGroup = true;
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "", false);
		}

		/*
		 * if(date.length()<11) { Reports.ExtentReportLog("", Status.INFO,
		 * "\r\n Age at time of event  get auto calculated for imprecise dates.", true);
		 * } else if(boolCheck.equalsIgnoreCase("false") ||
		 * boolCheck.equalsIgnoreCase("uncheck")) { Reports.ExtentReportLog("",
		 * Status.INFO, "\r\n Age at time of event  and Age Group get auto calculated.",
		 * true); } else if (boolCheck.equalsIgnoreCase("true") ||
		 * boolCheck.equalsIgnoreCase("check")) { Reports.ExtentReportLog("",
		 * Status.INFO,
		 * "\r\n Automatically calculated Age Group is manually override successfully.",
		 * true); }
		 */

		Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
		agSetStepExecutionDelay("2000");
		Reports.ExtentReportLog("", Status.PASS,
				"<br />" + "Age at time of event: " + getTestDataCellValue(scenarioName, "AgeAtTheTimeOfEvent") + " "
						+ getTestDataCellValue(scenarioName, "AgeAtTheTimeOfEvent_Units"),
				false);
		Reports.ExtentReportLog("", Status.PASS,
				"<br />" + "AgeGroup: " + getTestDataCellValue(scenarioName, "AgeGroup"), false);

		agSetStepExecutionDelay("1000");
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify auto calculate fields
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Kishore
	 * @Date :20-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verificationAgeBSIandBMI(String scenarioName) {
		getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.verifyData(FDE_PatientPageObjects.ageAtEvent, scenarioName,
				"Patient_PatientIdentifiers_AgeAtTheTimeOfEvent", "title");
		CommonOperations.verifyData(
				FDE_PatientPageObjects.click_embeddedDrpdwn(FDE_PatientPageObjects.ageTimeEvent_DropDown), scenarioName,
				"Patient_PatientIdentifiers_AgeAtTheTimeOfEvent_Units", "text");

		CommonOperations.verifyData(FDE_PatientPageObjects.click_DropDown(FDE_PatientPageObjects.ageGroup_DropDown),
				scenarioName, "Patient_PatientIdentifiers_AgeGroup", "text");
		CommonOperations.verifyData(FDE_PatientPageObjects.set_WeightHeight(FDE_PatientPageObjects.weight_DropDown),
				scenarioName, "Patient_PatientIdentifiers_Weight", "title");
		CommonOperations.verifyData(FDE_PatientPageObjects.click_embeddedDrpdwn(FDE_PatientPageObjects.weight_DropDown),
				scenarioName, "Patient_PatientIdentifiers_Weight_Units", "text");
		CommonOperations.verifyData(FDE_PatientPageObjects.set_WeightHeight(FDE_PatientPageObjects.height_DropDown),
				scenarioName, "Patient_PatientIdentifiers_Height", "title");
		CommonOperations.verifyData(FDE_PatientPageObjects.click_embeddedDrpdwn(FDE_PatientPageObjects.height_DropDown),
				scenarioName, "Patient_PatientIdentifiers_Height_Units", "text");
		CommonOperations.verifyData(FDE_PatientPageObjects.click_DropDown(FDE_PatientPageObjects.gender_DropDown),
				scenarioName, "Patient_PatientIdentifiers_Gender", "text");
		CommonOperations.verifyData(FDE_PatientPageObjects.bodySurfaceIndex_Textbox, scenarioName,
				"Patient_PatientIdentifiers_BodySurfaceIndex", "title");
		CommonOperations.verifyData(FDE_PatientPageObjects.bodyMassIndex_Textbox, scenarioName,
				"Patient_PatientIdentifiers_BodyMassIndex", "title");

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set and generate unique Patient ID
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Kishore
	 * @Date :21-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void uniqPatientIdGen(String scenarioName) {
		Random r = new Random(System.currentTimeMillis());
		String randPID = "PAT" + 0121 + r.nextInt(20000);
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
				"Patient_PatientIdentifiers_PatientID", randPID);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify the functionality of Manual
	 *             Checkbox for Autopsy Done field which is enabled at Application
	 *             Parametre at case level.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :09-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void autopsyDone_ManualFlagEnabled() {

		String No = agGetAttribute("class",
				FDE_PatientPageObjects.select_RadioButtons(FDE_PatientPageObjects.autopsyDone_Radio, "No"));
		String yes = agGetAttribute("class",
				FDE_PatientPageObjects.select_RadioButtons(FDE_PatientPageObjects.autopsyDone_Radio, "Yes"));

		if (yes.contains("active")) {

			agClick(FDE_PatientPageObjects.autopsyDone_No_radiobtn);

			agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.patientIdentifier_label);
			// agClick(FDE_PatientPageObjects.collapse_icon);

			FDE_Operations.LSMVSaveTheCase();
			agClick(FDE_PatientPageObjects.collapse_icon);
			agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.deathDetails_label);
			// agClick(FDE_PatientPageObjects.collapse_icon);

			String NoBtn = agGetAttribute("class",
					FDE_PatientPageObjects.select_RadioButtons(FDE_PatientPageObjects.autopsyDone_Radio, "No"));
			if (NoBtn.contains("active")) {
				Reports.ExtentReportLog("Autopsy done - No - radio button selected on save", Status.PASS,
						"Autopsy done -No- radio is selected", true);
			} else {
				Reports.ExtentReportLog("Autopsy done - No - radio button selected on save", Status.FAIL,
						"Autopsy done -No- radio is not selected", true);

			}

			agClick(FDE_PatientPageObjects.autopsyDone_Yes_radiobtn);

			agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.patientIdentifier_label);
			// agClick(FDE_PatientPageObjects.collapse_icon);

			FDE_Operations.LSMVSaveTheCase();
			agClick(FDE_PatientPageObjects.collapse_icon);
			agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.deathDetails_label);

			String yesBtn = agGetAttribute("class",
					FDE_PatientPageObjects.select_RadioButtons(FDE_PatientPageObjects.autopsyDone_Radio, "Yes"));
			if (yesBtn.contains("active")) {
				Reports.ExtentReportLog("Autopsy done - Yes - radio button selected on save", Status.PASS,
						"Autopsy done -Yes- radio is selected", true);
			} else {
				Reports.ExtentReportLog("Autopsy done - Yes - radio button selected on save", Status.FAIL,
						"Autopsy done -Yes- radio is not selected", true);

			}
		}

		else if (No.contains("active")) {
			agClick(FDE_PatientPageObjects.autopsyDone_Yes_radiobtn);

			agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.patientIdentifier_label);
			// agClick(FDE_PatientPageObjects.collapse_icon);

			FDE_Operations.LSMVSaveTheCase();
			agClick(FDE_PatientPageObjects.collapse_icon);
			agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.deathDetails_label);

			String yesBtn = agGetAttribute("class",
					FDE_PatientPageObjects.select_RadioButtons(FDE_PatientPageObjects.autopsyDone_Radio, "Yes"));
			if (yesBtn.contains("active")) {
				Reports.ExtentReportLog("Autopsy done - Yes - radio button selected on save", Status.PASS,
						"Autopsy done -Yes- radio is selected", true);
			} else {
				Reports.ExtentReportLog("Autopsy done - Yes - radio button selected on save", Status.FAIL,
						"Autopsy done -Yes- radio is not selected", true);

			}

			agClick(FDE_PatientPageObjects.autopsyDone_No_radiobtn);

			agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.patientIdentifier_label);
			// agClick(FDE_PatientPageObjects.collapse_icon);

			FDE_Operations.LSMVSaveTheCase();
			agClick(FDE_PatientPageObjects.collapse_icon);
			agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.deathDetails_label);
			// agClick(FDE_PatientPageObjects.collapse_icon);

			String NoBtn = agGetAttribute("class",
					FDE_PatientPageObjects.select_RadioButtons(FDE_PatientPageObjects.autopsyDone_Radio, "No"));
			if (NoBtn.contains("active")) {
				Reports.ExtentReportLog("Autopsy done - No - radio button selected on save", Status.PASS,
						"Autopsy done -No- radio is selected", true);
			} else {
				Reports.ExtentReportLog("Autopsy done - No - radio button selected on save", Status.FAIL,
						"Autopsy done -No- radio is not selected", true);

			}

		}

		else {
			agClick(FDE_PatientPageObjects.autopsyDone_No_radiobtn);

			agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.patientIdentifier_label);
			// agClick(FDE_PatientPageObjects.collapse_icon);

			FDE_Operations.LSMVSaveTheCase();
			agClick(FDE_PatientPageObjects.collapse_icon);
			agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.deathDetails_label);
			// agClick(FDE_PatientPageObjects.collapse_icon);

			String NoBtn = agGetAttribute("class",
					FDE_PatientPageObjects.select_RadioButtons(FDE_PatientPageObjects.autopsyDone_Radio, "No"));
			if (NoBtn.contains("active")) {
				Reports.ExtentReportLog("Autopsy done - No - radio button selected on save", Status.PASS,
						"Autopsy done -No- radio is selected", true);
			} else {
				Reports.ExtentReportLog("Autopsy done - No - radio button selected on save", Status.FAIL,
						"Autopsy done -No- radio is not selected", true);

			}

			agClick(FDE_PatientPageObjects.autopsyDone_Yes_radiobtn);

			agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.patientIdentifier_label);
			// agClick(FDE_PatientPageObjects.collapse_icon);

			FDE_Operations.LSMVSaveTheCase();
			agClick(FDE_PatientPageObjects.collapse_icon);
			agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.deathDetails_label);

			String yesBtn = agGetAttribute("class",
					FDE_PatientPageObjects.select_RadioButtons(FDE_PatientPageObjects.autopsyDone_Radio, "Yes"));
			if (yesBtn.contains("active")) {
				Reports.ExtentReportLog("Autopsy done - Yes - radio button selected on save", Status.PASS,
						"Autopsy done -Yes- radio is selected", true);
			} else {
				Reports.ExtentReportLog("Autopsy done - Yes - radio button selected on save", Status.FAIL,
						"Autopsy done -Yes- radio is not selected", true);

			}
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify the Autopsy Done -
	 *             Application Parametre at case level.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :09-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyAutopsyDone_AppParameters_CaseLevel(String scenarioName) {
		agSetStepExecutionDelay("5000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
		String boolAutopsyDone = getTestDataCellValue(scenarioName, "EnableAutopsyDone");

		if (boolAutopsyDone.equalsIgnoreCase("true")) {
			agSetStepExecutionDelay("5000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
			agSetStepExecutionDelay("10000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			FDE_Operations.tabNavigation("Patient");
			agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.deathDetails_label);

			Reports.ExtentReportLog("", Status.INFO, "verify Manual Flag for Autopsy Done at Case Level", true);

			if (agIsVisible(FDE_PatientPageObjects.autopsyDone_Manual_checkbox) == true) {
				Reports.ExtentReportLog("Manual Flag for Autopsy Done field", Status.PASS,
						"Manual Flag for Autopsy Done field is displayed at case level", true);

				if ((agGetAttribute("class", FDE_PatientPageObjects.autopsyDone_Manual_checkbox)).contains("active")) {
					FDE_Patient.autopsyDone_ManualFlagEnabled();
				}

				else {
					agClick(FDE_PatientPageObjects.autopsyDone_Manual_checkbox);
					FDE_Patient.autopsyDone_ManualFlagEnabled();
					agClick(FDE_PatientPageObjects.autopsyDone_Manual_checkbox);
					agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.patientIdentifier_label);
					FDE_Operations.LSMVSaveTheCase();
				}
			}

			else {
				Reports.ExtentReportLog("Manual Flag for Autopsy Done field", Status.FAIL,
						"Manual Flag for Autopsy Done field is not displayed at case level", true);
			}

		}

		else {
			agSetStepExecutionDelay("5000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
			agSetStepExecutionDelay("10000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Operations.tabNavigation("Patient");
			agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.deathDetails_label);
			Reports.ExtentReportLog("", Status.INFO,
					"verify Manual Flag for Autopsy Done at Case Level when flag is disabled at Application Parametre Level",
					true);
			if (agIsVisible(FDE_PatientPageObjects.autopsyDone_Manual_checkbox) == true) {
				Reports.ExtentReportLog(
						"Manual Flag for Autopsy Done field when flag is disabled at Application Parametre Level",
						Status.FAIL,
						"Manual Flag for Autopsy Done field is displayed at case level when flag is disabled at Application Parametre Level",
						true);
			}

			else {
				Reports.ExtentReportLog(
						"Manual Flag for Autopsy Done field when flag is disabled at Application Parametre Level",
						Status.PASS,
						"Manual Flag for Autopsy Done field is not displayed at case level when flag is disabled at Application Parametre Level",
						true);
			}
			SystemAdministrationOperations.systemAdministrationNavigations("applicationParameters");
			SystemAdministrationOperations.systemAdministrationNavigations("CaseManagement");
			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
			agClick(WorkFlowPageObjects
					.CheckedCheckBox2(AppParameters_CaseManagementPageObjects.enableAutopsyDone_CheckBox));
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.Save);
			agWaitTillVisibilityOfElement(AppParameters_CaseManagementPageObjects.SaveOkBtn);
			agSetStepExecutionDelay("8000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("Autopsy Done flag enabled at App Parametre level", Status.PASS,
					"Autopsy Flag enabled successfully at Application Parametre Level", true);
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.SaveOkBtn);

			AppParameters_CaseManagement.verifyAppParameters_AutopsyDone_CaseManagementTabDetails(scenarioName);

			agSetStepExecutionDelay("5000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
			agSetStepExecutionDelay("10000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			FDE_Operations.tabNavigation("Patient");
			agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.deathDetails_label);
			Reports.ExtentReportLog("", Status.INFO, "verify Manual Flag for Autopsy Done at Case Level", true);
			if (agIsVisible(FDE_PatientPageObjects.autopsyDone_Manual_checkbox) == true) {
				Reports.ExtentReportLog("Manual Flag for Autopsy Done field", Status.PASS,
						"Manual Flag for Autopsy Done field is displayed at case level", true);

				if ((agGetAttribute("class", FDE_PatientPageObjects.autopsyDone_Manual_checkbox)).contains("active")) {
					FDE_Patient.autopsyDone_ManualFlagEnabled();

				}

				else {
					agClick(FDE_PatientPageObjects.autopsyDone_Manual_checkbox);
					FDE_Patient.autopsyDone_ManualFlagEnabled();
					agClick(FDE_PatientPageObjects.autopsyDone_Manual_checkbox);
					agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.patientIdentifier_label);
					FDE_Operations.LSMVSaveTheCase();
				}
			}
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify the Autopsy Done -
	 *             Application Parametre at case level.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :09-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verify_AutopsyDoneSelection() {

		String No = agGetAttribute("class",
				FDE_PatientPageObjects.select_RadioButtons(FDE_PatientPageObjects.autopsyDone_Radio, "No"));
		String yes = agGetAttribute("class",
				FDE_PatientPageObjects.select_RadioButtons(FDE_PatientPageObjects.autopsyDone_Radio, "Yes"));

		agJavaScriptExecuctorScrollToElement(FDE_PatientPageObjects.deathDetails_label);

		if (yes.contains("active")) {

			Reports.ExtentReportLog("Autopsy done - YES - radio button selected", Status.PASS,
					"Autopsy done -YES- radio is selected at case level", true);

		}

		else if (No.contains("active")) {

			Reports.ExtentReportLog("Autopsy done - NO - radio button selected ", Status.PASS,
					"Autopsy done -NO- radio is selected at case level", true);

		}

		else {

			Reports.ExtentReportLog("", Status.PASS, "Autopsy done radio button not selected at case level", true);

		}

	}

	/**********************************************************************************************************
	 * @Objective: This method is created to verify Age Group Value in
	 *             AgeGroupDropdown in Patient Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 18-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void ageGroup_Verification() {

		Reports.ExtentReportLog("", Status.INFO, "verify Age Group Dropdown Selection", true);
		agJavaScriptExecuctorScrollToElement(
				FDE_PatientPageObjects.labelField(FDE_PatientPageObjects.ageGroup_DropDown));
		// agSetStepExecutionDelay("3000");
		CommonOperations.takeScreenShot();
		if (agCheckPropertyText("--Select--", FDE_PatientPageObjects.ageGroupDropDown)) {
			Reports.ExtentReportLog("Age Group Dropdown Verification", Status.PASS,
					"Age Group Dropdown do not have auto-populated value", true);
		} else {
			Reports.ExtentReportLog("Age Group Dropdown Verification", Status.PASS,
					"Age Group Dropdown is having auto-populated value", true);
		}
		// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify the Age Group - Application
	 *             Parametre at case level.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :19-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verify_AgeGroup_AppParameters_CaseLevel(String scenarioName, String scenarioName1) {
		// agSetStepExecutionDelay("5000");
		// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
		String boolAgeGroup = getTestDataCellValue(scenarioName, "EnableAgeGroup");

		if (boolAgeGroup.equalsIgnoreCase("true")) {
			// agSetStepExecutionDelay("5000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
			// agSetStepExecutionDelay("10000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			FDE_Operations.tabNavigation("Patient");
			agJavaScriptExecuctorScrollToElement(
					FDE_PatientPageObjects.labelField(FDE_PatientPageObjects.ageGroup_DropDown));

			Reports.ExtentReportLog("", Status.INFO,
					"verify Manual Flag for Age Group at Case Level when flag is enabled at App Parametre level", true);

			if (agIsVisible(
					CommonPageObjects.manualCheckBoxSelection(FDE_PatientPageObjects.ageGroup_DropDown)) == true) {
				Reports.ExtentReportLog("Manual Flag for Age Group field ", Status.PASS,
						"Manual Flag for Age Group field is displayed at case level when respective flag is enabled at Application Parametre level",
						true);

				if ((agGetAttribute("class",
						CommonPageObjects.manualCheckBoxSelection(FDE_PatientPageObjects.ageGroup_DropDown)))
								.contains("active")) {
					setData_AgeGroup(scenarioName1);

				}

				else {
					agClick(CommonPageObjects.manualCheckBoxClick(FDE_PatientPageObjects.ageGroup_DropDown));
					setData_AgeGroup(scenarioName1);
					// agClick(CommonPageObjects.manualCheckBoxSelection(FDE_PatientPageObjects.ageGroup_DropDown));
					// FDE_Operations.LSMVSaveTheCase();
					/*
					 * if(agIsVisible(CommonPageObjects.collapse_icon)) {
					 * agJavaScriptExecuctorClick(CommonPageObjects.collapse_icon);
					 * agJavaScriptExecuctorScrollToElement(CommonPageObjects.mainForm_Header);
					 * agSetStepExecutionDelay("3000");
					 * agSetStepExecutionDelay(String.valueOf(Constants.
					 * defaultGlobalStepExecutionDelay)); }
					 */
				}
			}

			else {
				Reports.ExtentReportLog("Manual Flag for Age Group field ", Status.FAIL,
						"Manual Flag for Age Group field is not displayed at case level though respective flag is enabled at Application Parametre level",
						true);
			}

		}

		else {
			// agSetStepExecutionDelay("5000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
			// agSetStepExecutionDelay("10000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			FDE_Operations.tabNavigation("Patient");
			agJavaScriptExecuctorScrollToElement(
					FDE_PatientPageObjects.labelField(FDE_PatientPageObjects.ageGroup_DropDown));
			Reports.ExtentReportLog("", Status.INFO,
					"verify Manual Flag for Age Group at Case Level when flag is disabled at App Parametre level",
					true);
			if (agIsVisible(
					CommonPageObjects.manualCheckBoxSelection(FDE_PatientPageObjects.ageGroup_DropDown)) == true) {
				Reports.ExtentReportLog(
						"Manual Flag for Age Group field when flag is disabled at Application Parametre Level",
						Status.FAIL,
						"Manual Flag for Age Group field is displayed at case level though flag is disabled at Application Parametre Level",
						true);
			}

			else {
				Reports.ExtentReportLog(
						"Manual Flag for Age Group field when flag is disabled at Application Parametre Level",
						Status.PASS,
						"Manual Flag for Age Group field is not displayed at case level when flag is disabled at Application Parametre Level",
						true);
			}
			SystemAdministrationOperations.systemAdministrationNavigations("applicationParameters");
			SystemAdministrationOperations.systemAdministrationNavigations("CaseManagement");
			agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.enableManualFlag_label);
			agClick(WorkFlowPageObjects
					.CheckedCheckBox2(AppParameters_CaseManagementPageObjects.enableAgeGroup_CheckBox));
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.Save);
			agWaitTillVisibilityOfElement(AppParameters_CaseManagementPageObjects.SaveOkBtn);
			// agSetStepExecutionDelay("8000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("Age Group flag enabled at App Parametre level", Status.PASS,
					"Age Group Flag enabled successfully at Application Parametre Level", true);
			agJavaScriptExecuctorClick(AppParameters_CaseManagementPageObjects.SaveOkBtn);

			AppParameters_CaseManagement.verifyAppParameters_AgeGroup_CaseManagementTabDetails(scenarioName);

			// agSetStepExecutionDelay("5000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			CaseListingOperations.searchCaseAndEdit(scenarioName, "FDE_General", "ReceiptNo");
			// agSetStepExecutionDelay("10000");
			// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			FDE_Operations.tabNavigation("Patient");
			agJavaScriptExecuctorScrollToElement(
					FDE_PatientPageObjects.labelField(FDE_PatientPageObjects.ageGroup_DropDown));
			Reports.ExtentReportLog("", Status.INFO, "verify Manual Flag for Age Group at Case Level", true);
			if (agIsVisible(
					CommonPageObjects.manualCheckBoxSelection(FDE_PatientPageObjects.ageGroup_DropDown)) == true) {
				Reports.ExtentReportLog("Manual Flag for Age Group field ", Status.PASS,
						"Manual Flag for Age Group field is displayed at case level when respective flag is enabled at Application Parametre level",
						true);

				if ((agGetAttribute("class",
						CommonPageObjects.manualCheckBoxSelection(FDE_PatientPageObjects.ageGroup_DropDown)))
								.contains("active")) {
					setData_AgeGroup(scenarioName1);

				}

				else {
					agClick(CommonPageObjects.manualCheckBoxSelection(FDE_PatientPageObjects.ageGroup_DropDown));
					setData_AgeGroup(scenarioName1);
					// agClick(CommonPageObjects.manualCheckBoxSelection(FDE_PatientPageObjects.ageGroup_DropDown));
					// FDE_Operations.LSMVSaveTheCase();
					/*
					 * if(agIsVisible(CommonPageObjects.collapse_icon)) {
					 * agJavaScriptExecuctorClick(CommonPageObjects.collapse_icon);
					 * agJavaScriptExecuctorScrollToElement(CommonPageObjects.mainForm_Header);
					 * agSetStepExecutionDelay("3000");
					 * agSetStepExecutionDelay(String.valueOf(Constants.
					 * defaultGlobalStepExecutionDelay)); }
					 */
				}
			}
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is to set value at "Age Group" Dropdown
	 * 
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date :19-Feb-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setData_AgeGroup(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		// agSetStepExecutionDelay("3000");

		// agClick(CommonPageObjects.manualCheckBox(FDE_PatientPageObjects.ageGroup_DropDown));
		String preValue = agGetText(FDE_PatientPageObjects.ageGroupDropDown);

		agJavaScriptExecuctorClick(FDE_PatientPageObjects.ageGroupDropDown);
		agJavaScriptExecuctorClick(FDE_PatientPageObjects
				.setdropDownValue(getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeGroup")));

		FDE_Operations.LSMVSaveTheCase();

		if (agIsVisible(CommonPageObjects.collapse_icon)) {
			// agJavaScriptExecuctorClick(CommonPageObjects.collapse_icon);
			agClick(CommonPageObjects.collapse_icon);
			agJavaScriptExecuctorScrollToElement(CommonPageObjects.mainForm_Header);
			agSetStepExecutionDelay("3000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}

		agJavaScriptExecuctorScrollToElement(
				FDE_PatientPageObjects.labelField(FDE_PatientPageObjects.ageGroup_DropDown));

		String newValue = agGetText(FDE_PatientPageObjects.ageGroupDropDown);

		CommonOperations.takeScreenShot();
		if (preValue.equalsIgnoreCase(newValue)) {
			Reports.ExtentReportLog("Verification of AGE Group value update", Status.FAIL,
					"Age Group value not updated", true);
		} else {
			Reports.ExtentReportLog("Verification of AGE Group value update", Status.PASS, "Age Group value updated",
					true);
		}

	}

	/***********************************************************************************************************************
	 * @Objective: The below method is to set Medical History Start Date and Stop
	 *             Date
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 04-Mar-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setMedHistoryStart_StopDate(String scenarioName) {

		if (!getTestDataCellValue(scenarioName, "Patient_MedHistory_StartDate_AsText").equalsIgnoreCase("#skip#")) {
			// Medical History Start Date
			agClearText(FDE_PatientPageObjects.startDateMedHist_FormView);
			agSetValue((FDE_PatientPageObjects.startDateMedHist_FormView),
					getTestDataCellValue(scenarioName, "Patient_MedHistory_StartDate_AsText"));
			agSendKeyStroke(Keys.TAB);
		}

		if (!getTestDataCellValue(scenarioName, "Patient_MedHistory_StopDate_AsText").equalsIgnoreCase("#skip#")) {
			// Medical History End Date
			agClearText(FDE_PatientPageObjects.endDateMedHist_FormView);
			agSetValue((FDE_PatientPageObjects.endDateMedHist_FormView),
					getTestDataCellValue(scenarioName, "Patient_MedHistory_StopDate_AsText"));
			agSendKeyStroke(Keys.TAB);
		}
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is to set Medical History Start Date and Stop
	 *             Date
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 04-Mar-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void addMedHistoryButton() {
		agClick(FDE_PatientPageObjects.clickAddButton(FDE_PatientPageObjects.medicalHistory_Label));
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is to set Medical History Start Date and Stop
	 *             Date
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 04-Mar-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void clickOnMedHistoryRecordHeader(String recNum) {
		agClick(FDE_PatientPageObjects.medicalHistoryRecHeader(recNum));
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is to set Product Description value *
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:
	 * @Date : 04-Mar-2021
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setPatientPastTherapyProduct(String scenarioName) {

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the Patient details present
	 *             or not
	 * @InputParameters:
	 * @OutputParameters:scenarioName
	 * @author:Pooja S
	 * @Date :10-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	static boolean isPatDetKeyed(String PatScenario) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		boolean isAvailable = false;
		FDE_Operations.tabNavigation("Patient");
		agClick(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.patientID_Textbox));
		String patID = agGetAttribute("title",
				FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.patientID_Textbox));
		CommonOperations.takeScreenShot();
		if (patID.equalsIgnoreCase(getTestDataCellValue(PatScenario, "Patient_PatientIdentifiers_PatientID"))) {
			isAvailable = true;
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		return isAvailable;

	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to set patient ID
	 * @InputParameters:
	 * @OutputParameters:scenarioName
	 * @author:Yashwanth Naidu
	 * @Date :11-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setPatientID(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FDE_PatientPageObjects.setData_Textfields(FDE_PatientPageObjects.patientID_Textbox),
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_PatientID"));
	}
}