package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class DictonaryBrowserObjects {
	
	
	public static String viewModeDropdown = "xpath#//p-dropdown[@name='viewModeDropDown']/div/label";
	public static String viewVersionDropdown = "xpath#//p-dropdown[@name='medVerDropDown']/div//label";
	public static String searchBtn = "xpath#//button/span[text()='Search']";
	public static String searchResult = "xpath#//div[@id='ui-panel-0-content']/div/p-tree/div/ul";
	
	public static String listOfResult="xpath#//div[@id='ui-panel-0-content']/div/p-tree/div/ul/p-treenode";
	
	public static String setLabelDropdown = "xpath#//ul/p-dropdownitem/li/span[text()='%label%']";
	
	/**********************************************************************************************************
	 * Objective: The below method is created to select level Result Data in Dictionary Coding Browser Look Up Screen. 
	 * Input Parameters: Label Name
	 * Parameters:
	 * @author:Avinash K
	 * Date :13-Mar-2020 Updated by and when
	 **********************************************************************************************************/
	public static String setLabelDropdown(String srchResultLabel) {
		String value = setLabelDropdown.replace("%label%", srchResultLabel);
		return value;
	}
	
	public static String getTerm = "xpath#(//div[@id='ui-panel-0-content']/div/p-tree/div/ul/p-treenode/li/div/span[1])[%count%]";
	
	public static String getTerms(String count) {
		String value = getTerm.replace("%count%", count);
		return value;
	}
	
	public static String listOfChildResult = "xpath#//div[@id='ui-panel-0-content']/div/p-tree/div/ul/p-treenode[%i%]/li/ul";
	
	public static String getchildCount(String count) {
		String value = listOfChildResult.replace("%i%", count);
		return value;
	}
	
	public static String getPTterm = "xpath#(//div[@id='ui-panel-0-content']/div/p-tree/div/ul/p-treenode[%i%]/li/ul//span[3]/span)[%j%]";
	
	public static String getPTterm(String i, String j) {
		String value = getPTterm.replace("%i%", i);
		String value2 = value.replace("%j%", j);
		return value2;
	}
	
	
	public static String smqcmq = "xpath#//div[@id='ui-panel-0-content']/div/p-tree/div/ul/p-treenode[%i%]/li/div/span[3]/span";
	
	public static String smqcmqText(String i) {
		String value = smqcmq.replace("%i%", i);
		
		return value;
	}

}
