package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class BatchListingPageObjects {
	
	public static String batchPrintListingBreadScrum = "xpath#//div/label[text()='Batch Print Listing']";
	
	//Header Button components
	public static String new_button = "xpath#//div/a[@id='listingForm:newId'][text()='New']";
	public static String delete_button = "xpath#//div/a[@id='listingForm:deleteId'][text()='Delete']";
	public static String archive_button = "xpath#//button[@id='listingForm:archvBtn']/span[text()='Archive']";
	public static String status_dropdown = "xpath#//div[@id='listingForm:archiveSeleMenu']//following::label[@id='listingForm:archiveSeleMenu_label']";
	public static String unArchive_button = "xpath#//span[@id='listingForm:unArchvPnlGrp']/button[@id='listingForm:unArchvBtn']";
	
	//Delete Prompt Window
	public static String deletePromptMessage = "xpath#//div[@id='listingForm:deleteconfirm']/div/following-sibling::div/div[@class='confmDlgLblBtm']/label";
	public static String deleteConfirm_Button = "xpath#//div[@id='listingForm:removeConfirmdialogPanelGroup']/div/button[@id='listingForm:confirmation_yes']";
	public static String deleteCancel_Button = "xpath#//div[@id='listingForm:removeConfirmdialogPanelGroup']/div/button[@id='listingForm:confirmation_no']";
	
	//Acknowledgement Window
	public static String ackWindowHeaderText = "xpath#//div/div/span[@id='mandatoryDialogform:mandatoryID_title']";
	public static String ackWindowInfoText = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String ackWindowInfoTextCheck ="xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo'][contains(text(),'ed successfully')]";
	public static String ackWindowInfoOK_button = "xpath#//div[@class='buttonBg']/button[@id='mandatoryDialogform:okButton']";
	
	//Header tool components
	public static String exportHoverButton = "xpath#//div[@class='Action-tooltip']/a/img";
	public static String exportToExcelBtn = "xpath#//div[@class='exportXl']/button/span";
	public static String exportToPDFBtn = "xpath#//div[@class='exportPdf']/button/span";
	public static String export_Btn = "xpath#//div[@class='buttonBg']/button/span[text()='Export']";
	public static String cancel_Btn = "xpath#//div[@class='buttonBg']/button/span[text()='Cancel']";
	public static String filterButton = "xpath#//a[@id='listingForm:filterId']/img";
	public static String saveButton = "xpath#//a[@id='listingForm:savebpColOrderBtn']/img";
	public static String columnSelectionButton = "xpath#//div[@class='columnSty']/button[@id='listingForm:batchPrintDataTable:toggler']";
	
	//Table Components
	public static String refreshButton = "xpath#//div[@class='refreshPosition']/a[@id='listingForm:refreshImage']/img";
	public static String searchTextArea = "xpath#//div[contains(@class,'keySearchDatainput')]/input[@id='listingForm:searchCriteria']";
	public static String searchIcon = "xpath#//div/a[@id='listingForm:searchbutton']/img";
	public static String pagination_RecordCount = "xpath#//div[@id='listingForm:batchPrintDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String pagination_PrevPageToolTip = "xpath#//a[contains(@class,'ui-paginator-prev')]/span[@class='ui-icon ui-icon-seek-prev']";
	public static String pagination_NextPageToolTip = "xpath#//a[contains(@class,'ui-paginator-next')]/span[@class='ui-icon ui-icon-seek-next']";
	
	public static String filter_BatchName_txtField = "xpath#//input[contains(@id,'batchName:filter')]";
	public static String filter_DocumentsDropdown = "xpath#//th[contains(@id,'printConfigDoc')]/div/div[contains(@id,'printConfigDocFilterId')]";
	public static String filter_StatusDropdown = "xpath#//th[contains(@id,'printStatus')]/div/div[contains(@id,'printStatusFilterId')]";
	
	public static String tbHeader_SelectAllCheckBox = "xpath#//div[contains(@class,'ui-chkbox-all ')]/div[contains(@class,'ui-corner-all')]";
	
		
	public static String tbHeader_value = "xpath#//th/span[text()='{%s}']";
	public static String tbHeader_Edit = "Edit";
	public static String tbHeader_BatchName ="Batch Name";
	public static String tbHeader_NoOfCases ="No Of Cases";
	public static String tbHeader_Document ="Document(s)";
	public static String tbHeader_Status ="Status";
	public static String tbHeader_Progress ="Progress";
	public static String tbHeader_ReRun ="Re-Run";
	public static String tbHeader_Download ="Download";
	public static String tbHeader_RequestedBy ="Requested By";
	public static String tbHeader_RequestDate ="Request Date";
	public static String tbHeader_ExecutionStartDate ="Execution Start Date";
	public static String tbHeader_ExecutionEndDate ="Execution End Date";
	public static String tbHeader_TimeTaken ="Time Taken";
	
	
	public static String tbRow_NoRecords = "xpath#//tbody[@id='listingForm:batchPrintDataTable_data']/tr/td[text()='No records found.']";
	
	//Locator should be used after retrieving single record through search option
	public static String tbdata_BatchName = "xpath#//tbody[contains(@id,'batchPrintDataTable')]/tr/td/a[text()='{%s}']";
	public static String tbdata_BatchStatus = "xpath#//tr/td/a[text()='{%s}']/following::td/a[contains(@onclick,'batchPrintStatus')]";
	public static String tbdata_BatchProgress = "xpath#//tr/td/a[text()='{%s}']/following::td/div[contains(@id,'progressBarId')]/div[@class='ui-progressbar-label']";
	public static String tbdata_BatchReRun_icon = "xpath#//tr/td/a[text()='{%s}']/following::td/a[contains(@onclick,'reRunDialog')]/img";
	public static String tbdata_BatchDownload_icon = "xpath#//tr/td/a[text()='{%s}']/following::td/a/img[@id='listingForm:batchPrintDataTable:0:downloadImg']";
	public static String tbdata_BatchRecord_checkBox = "xpath#//tbody[@id='listingForm:batchPrintDataTable_data']/tr/child::td/div/div[2]/span";
	public static String tbdata_EditRecord_icon = "xpath#//tr/td/a[@id='listingForm:batchPrintDataTable:0:editLink']/img";
	
	/**********************************************************************************************************
	 * @Objective: To construct xpath to locate the desired table/Column header
	 * @InputParameters: Edit, Batch Name, No Of Cases, Document(s), Status, Progress, Re-Run, Download, Requested By, 
	 * Request Date, Execution Start Date, Execution End Date, Time Taken
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 02-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectTableHeaderByName(String colHeader) {		
		String value1 = tbHeader_value;
		String value2 = value1.replace("{%s}", colHeader);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: To construct xpath to locate the desired record's Batch Name
	 * @InputParameters: Batch Name to be read from test data sheet or variable based on the user operation
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 03-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectBatchRecordName(String batchName) {		
		String value1 = tbdata_BatchName;
		String value2 = value1.replace("{%s}", batchName);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: To construct xpath to locate the desired record's Batch Status
	 * @InputParameters: Batch Name to be read from test data sheet or variable based on the user operation
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 03-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectBatchRecordStatus(String batchName) {		
		String value1 = tbdata_BatchStatus;
		String value2 = value1.replace("{%s}", batchName);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: To construct xpath to locate the desired record's Batch Progress bar
	 * @InputParameters: Batch Name to be read from test data sheet or variable based on the user operation
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 03-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectBatchRecordProgress(String batchName) {		
		String value1 = tbdata_BatchProgress;
		String value2 = value1.replace("{%s}", batchName);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: To construct xpath to locate the ReRun icon
	 * @InputParameters: Batch Name to be read from test data sheet or variable based on the user operation
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 03-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectBatchRecordReRun(String batchName) {		
		String value1 = tbdata_BatchReRun_icon;
		String value2 = value1.replace("{%s}", batchName);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: To construct xpath to locate the Download icon
	 * @InputParameters: Batch Name to be read from test data sheet or variable based on the user operation
	 * @OutputParameters:
	 * @author: Shamanth S
	 * @Date : 03-Sep-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectBatchRecordDownload(String batchName) {		
		String value1 = tbdata_BatchDownload_icon;
		String value2 = value1.replace("{%s}", batchName);
		return value2;
	}
	
}
