package com.arisglobal.framework.components.lsmv.L10_3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1_0_2.CommonOperations;
import com.arisglobal.framework.components.lsmv.L10_3.OR.AdvanceSearchPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CaseListingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.DataAssessmentPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDEMoreOptionsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FollowupNotificationPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.OutofWorkFlowPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.SubmissionTrackingPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.FileSystemOperations;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class CaseListingOperations extends ToolManager {
	public static WebElement webElement;
	static String className = CaseListingOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify data in Validation
	 *             displayed in case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 10-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void columnSelectionValidation(String scenarioName) {
		agSetStepExecutionDelay("3000");
		if (agIsVisible(CaseListingPageObjects.columnSelec_validationPopup) == true) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "columnSelection_Message"),
					CaseListingPageObjects.validationPopup);
			Reports.ExtentReportLog("Adverse Event columns updated successfully", Status.INFO,
					"Column Name:" + getTestDataCellValue(scenarioName, "ColumnName"), true);
			agClick(CaseListingPageObjects.PopupOkButton);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the column to be displayed
	 *             in case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 10-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void columnSelection(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		agClick(CaseListingPageObjects.columnSelectionButton);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		String attribute = agGetAttribute("class",
				CaseListingPageObjects.get_columnAttribute(getTestDataCellValue(scenarioName, "ColumnName")));
		if (null != attribute && attribute.contains("ui-state-active")) {
			CommonOperations.takeScreenShot();
			agClick(CaseListingPageObjects.saveColumnReorderButton);
			columnSelectionValidation(scenarioName);
			agSetStepExecutionDelay("2000");
			columnVerification(scenarioName);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} else {
			agClick(CaseListingPageObjects.selectColumn(getTestDataCellValue(scenarioName, "ColumnName")));
			agClick(CaseListingPageObjects.saveColumnReorderButton);
			columnSelectionValidation(scenarioName);
			agSetStepExecutionDelay("2000");
			columnVerification(scenarioName);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify whether selected column is
	 *             displayed in case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 01-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void columnVerification(String scenarioName) {
		status = agIsExists(CaseListingPageObjects.verifyColumnName(getTestDataCellValue(scenarioName, "ColumnName")));
		if (status) {
			Reports.ExtentReportLog("Selected Column is Visible in Case listing screen", Status.PASS,
					"Column Name:" + getTestDataCellValue(scenarioName, "ColumnName"), true);
		} else

		{
			Reports.ExtentReportLog("Selected Column is Not Visible", Status.FAIL,
					"Column Name :" + getTestDataCellValue(scenarioName, "ColumnName"), true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to case assessment verification based
	 *             on duplicateCheck policy in case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void duplicateCheckVerification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		status = agIsVisible(CaseListingPageObjects.caseListingAssessedcolumn);
		if (status) {
			String data = agGetText(CaseListingPageObjects.caseListingAssessedcolumn);
			agCheckPropertyText(data, getTestDataCellValue(scenarioName, "Assessed"));
			Reports.ExtentReportLog("Case is assessed successfully", Status.PASS, "Case is assesed as : " + data, true);
		} else {
			Reports.ExtentReportLog("Case is not assessed successfully", Status.FAIL, "Case is not assessed", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to follow up case verification based
	 *             in case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 20-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void followupCaseVerifiction(String scenarioName) {
		agIsVisible(FollowupNotificationPageObjects.followupNotified_icon);
		agClick(FollowupNotificationPageObjects.followupNotified_icon);
		agSetStepExecutionDelay("3000");
		agAssertVisible(FollowupNotificationPageObjects
				.followupColoumn_header(FollowupNotificationPageObjects.receiptDetails_colmHeader));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agAssertVisible(FollowupNotificationPageObjects
				.followupColoumn_header(FollowupNotificationPageObjects.AERNo_colmHeader));
		dataVerificationFollowupPopup(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to followup case Receipt Details
	 *             column verification in followup popup based in case listing
	 *             screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 23-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void followupReceiptDetailsVerifiction(String scenarioName) {
		agClick(FollowupNotificationPageObjects.followupNotified_icon);
		receiptColumnVerify_followupPopup(scenarioName);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(FollowupNotificationPageObjects
				.followupRCTColunm_verification(DataAssessmentOperations.getData(scenarioName, "AERNo")));
		Reports.ExtentReportLog("", Status.INFO, "Followup notification window", true);
		agMouseHover(FollowupNotificationPageObjects.followupClose_link);
		agClick(FollowupNotificationPageObjects.followupClose_link);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to parent case RECEIPT DETAILS column
	 *             verification in followup popup based in case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 23-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void parentReceiptDetailsVerifiction(String scenarioName) {
		agClick(FollowupNotificationPageObjects.followupReceived_icon);
		receiptColumnVerify_followupPopup(scenarioName);
		CommonOperations.takeScreenShot();
		agMouseHover(FollowupNotificationPageObjects.followupClose_link);
		agClick(FollowupNotificationPageObjects.followupClose_link);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to RECEIPT DETAILS column
	 *             verification in followup popup based in case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 23-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void receiptColumnVerify_followupPopup(String scenarioName) {
		agSetStepExecutionDelay("3000");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(FollowupNotificationPageObjects
				.followupRCTColunm_verification(FDE_General.getData(scenarioName, "ReceiptNo")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		/*
		 * agAssertVisible(CaseListingPageObjects.followupRCTColunm_verification(
		 * E2BMessageQueueOperations.getData(scenarioName, "WorkFlowActivity")));
		 * agAssertVisible(CaseListingPageObjects.followupRCTColunm_verification(
		 * E2BMessageQueueOperations.getData(scenarioName, "XML_LatestReceiveDate")));
		 */
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to parent case verification based in
	 *             case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 20-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void parentCaseVerifiction(String scenarioName) {
		agIsVisible(FollowupNotificationPageObjects.followupReceived_icon);
		agClick(FollowupNotificationPageObjects.followupReceived_icon);
		agSetStepExecutionDelay("3000");
		agIsVisible(FollowupNotificationPageObjects
				.followupColoumn_header(FollowupNotificationPageObjects.followupReceiptDetails_colmHeader));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		dataVerificationFollowupPopup(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created data verification in followup popup
	 *             in case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 20-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void dataVerificationFollowupPopup(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyText(FDE_General.getData(scenarioName, "ReceiptNo"),
				FollowupNotificationPageObjects.followupTitle_header);
		agAssertVisible(FollowupNotificationPageObjects
				.followupColoumn_header(FollowupNotificationPageObjects.seriousnessMasterCase_colmHeader));
		agAssertVisible(FollowupNotificationPageObjects
				.followupColoumn_header(FollowupNotificationPageObjects.seriousnessFollowUpCase_colmHeader));
		agAssertExists(FollowupNotificationPageObjects
				.death_Lable(FDE_Events.getData(scenarioName, "Events_EventSeriousness_Death")));
		agAssertExists(FollowupNotificationPageObjects
				.lifeThreatening_label(FDE_Events.getData(scenarioName, "Events_EventSeriousness_LifeThreatening")));
		agAssertExists(FollowupNotificationPageObjects.disability_PermanentDamage_label(
				FDE_Events.getData(scenarioName, "Events_EventSeriousness_DisabilityPermanentDamage")));
		agAssertExists(FollowupNotificationPageObjects.caused_prolongedhospitalization_label(
				FDE_Events.getData(scenarioName, "Events_EventSeriousness_CausedProlongedHospitalization")));
		agAssertExists(FollowupNotificationPageObjects.caused_prolongedhospitalization_label(
				FDE_Events.getData(scenarioName, "Events_EventSeriousness_CongenitalAnomalyBirthDefect")));
		agAssertExists(FollowupNotificationPageObjects.otherMedicallyImportantCondition_label(
				FDE_Events.getData(scenarioName, "Events_EventSeriousness_OtherMedicallyImportantCondition")));
		agAssertExists(FollowupNotificationPageObjects.followupWindowoutcomeVerification(
				FDE_Events.getData(scenarioName, "Events_EventInformation_Outcome")));
		Reports.ExtentReportLog("", Status.INFO, "Followup notification window", true);
		agMouseHover(FollowupNotificationPageObjects.followupClose_link);
		agClick(FollowupNotificationPageObjects.followupClose_link);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify case is in non editable
	 *             mode in case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 20-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void caseNoteditabelVerification() {
		String value = agGetAttribute("class", FollowupNotificationPageObjects.getfollowupCase_attribute);
		if (value.contains("ui-state-disabled")) {
			Reports.ExtentReportLog("", Status.PASS, "Case is Noneditable", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Case is Editable", true);

		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search the created case in case
	 *             listing and edit
	 * @InputParameters: Scenario Name, sheetName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchCaseAndEdit(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetStepExecutionDelay("10000");
		CaseManagementOperations.menuNavigation("Case listing");
		// CaseManagementOperations.menusubmenuNavigation("Case listing");

		/*
		 * if(agIsVisible(FullDataEntryFormPageObjects.withOutSaveValidation)==true) {
		 * agClick(FullDataEntryFormPageObjects.yesBtn_withOutSaveValidation); }
		 */
		// agSetStepExecutionDelay("6000");
		// agWaitTillVisibilityOfElement(CaseListingPageObjects.keywordSearchTextbox);
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, columnName));
		agJavaScriptExecuctorClick(CaseListingPageObjects.searchButton);
		// CommonOperations.waitTillCaseVisible();
		/*
		 * CommonOperations.agwaitTillVisible(
		 * CaseListingPageObjects.waitForRCT(FDE_General.getData(scenarioName,
		 * columnName)), 4, 1000);
		 */
		agWaitTillVisibilityOfElement(getTestDataCellValue(scenarioName, columnName));
//		Reports.ExtentReportLog("", Status.INFO, "Case is listed in Listing Screen", true);
		if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			// CommonOperations.captureScreenShot(true);
		}
		agSetStepExecutionDelay("6000");
		agClick(CaseListingPageObjects.receiptNumberlink);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search the created case in case
	 *             listing and edit
	 * @InputParameters: Scenario Name, sheetName, columnName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 26-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchCase_Edit(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetStepExecutionDelay("10000");
		CaseManagementOperations.menuNavigation("Case listing");
		agWaitTillVisibilityOfElement(CaseListingPageObjects.paginator);
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, columnName));
		agJavaScriptExecuctorClick(CaseListingPageObjects.searchButton);
		// CommonOperations.waitTillCaseVisible();
		CommonOperations.agwaitTillVisible(
				CaseListingPageObjects.waitForRCT(FDE_General.getData(scenarioName, columnName)), 4, 1000);

		Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);

		agClick(CaseListingPageObjects.receiptNumberlink);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search the created case in case
	 *             listing
	 * @InputParameters: Scenario Name, sheetName, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchCreatedCase(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		CaseManagementOperations.menuNavigation("Case listing");
		/// CaseManagementOperations.menusubmenuNavigation("Case listing");

		/*
		 * if(agIsVisible(FullDataEntryFormPageObjects.withOutSaveValidation)==true) {
		 * agClick(FullDataEntryFormPageObjects.yesBtn_withOutSaveValidation); }
		 */
		agSetStepExecutionDelay("10000");
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, columnName));
		agClick(CaseListingPageObjects.searchButton);
		// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		// CommonOperations.waitTillCaseVisible();
		CommonOperations.agwaitTillVisible(
				CaseListingPageObjects.waitForRCT(getTestDataCellValue(scenarioName, columnName)), 4, 1000);
		Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the case and perform delete
	 *             operation from case listing
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteCase(String scenarioName) {
		CaseDeleteOperations.deleteCase(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select AssignTo and Show dropdown
	 *             value in FDE form case listing screen
	 * @InputParameters: LabelName, value
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDown_CaseListing(String LabelName, String value) {

		agClick(CaseListingPageObjects.clickDropDown(LabelName));
		agSetStepExecutionDelay("10000");
		// agWaitTillVisibilityOfElement(CaseListingPageObjects.AssignToDD_Textbox);
		// agSetValue(CaseListingPageObjects.AssignToDD_Textbox, value);
		agClick(CaseListingPageObjects.selectDropdown(value));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify deleted case in case
	 *             listing and in outofWorkFlow listing
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDeletedcase(String scenarioName) {
		CaseDeleteOperations.verifyDeletedcase(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to perform case Reassign operations in
	 *                case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 20-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void caseReassign(String scenarioName) {
		CaseReassignOperations.caseReassign(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to verify case Reassign functionality
	 *                in case listing screen
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 21-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void caseReassignVerification(String scenarioName) {
		CaseReassignOperations.caseReassignVerification(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select multiple case from case
	 *                listing screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void selectMultipleCase() {
		agClick(CaseListingPageObjects.multipleCheckbox);
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select multiple case from case
	 *                listing screen and click on open Multiplelink
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void openmultiplelink() {
		selectMultipleCase();
		caseListing_Moreoptions(CaseListingPageObjects.openMultiple_link);

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select the links in Moreoptions in
	 *                case listing screen.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 13-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void caseListing_Moreoptions(String object) {
		agMouseHover(CaseListingPageObjects.moreOptions_Button);
		agClick(CaseListingPageObjects.moreOptionsLink(object));

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select multiple case from case
	 *                listing screen and click on compare button.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 13-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void compareCase() {
		selectMultipleCase();
		agClick(CaseListingPageObjects.compareButton);

	}

	/**********************************************************************************************************
	 * @Objective:Search receipt number
	 * @InputParameters: Receipt number
	 * @OutputParameters: void
	 * @author:DushyanthMahesh
	 * @Date : 14/02/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchCase(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		CaseManagementOperations.menuNavigation("Case listing");

		agSetStepExecutionDelay("3000");
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, columnName));
		agClick(CaseListingPageObjects.searchButton);
		agWaitTillInvisibilityOfElement(CaseListingPageObjects.oWS_SearchLoading);
		// wait statements
	}

	/**********************************************************************************************************
	 * @Objective:Search receipt number
	 * @InputParameters: Receipt number
	 * @OutputParameters: void
	 * @author:DushyanthMahesh
	 * @Date : 14/02/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchCase(String rctNumber) {
		CaseManagementOperations.menuNavigation("Case listing");
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, rctNumber);
		agClick(CaseListingPageObjects.searchButton);
		agWaitTillInvisibilityOfElement(CaseListingPageObjects.oWS_SearchLoading);
		// wait statements
	}

	/**********************************************************************************************************
	 * @Objective:Edit receipt number
	 * @InputParameters: Edit number
	 * @OutputParameters: void
	 * @author:DushyanthMahesh
	 * @Date : 14/02/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchEdit() {
		agSetStepExecutionDelay("5000");
		if (agIsVisible(CaseListingPageObjects.receiptNumberlink) == true) {
			Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);
			agJavaScriptExecuctorClick(CaseListingPageObjects.receiptNumberlink);
		} else {
			Reports.ExtentReportLog("", Status.PASS, "Case is not listed for UnPriveleged user", true);
		}
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
		agWaitTillInvisibilityOfElement(CaseListingPageObjects.oWS_SearchLoading);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to open Reports in Case Listing
	 *             Screen
	 * @InputParameters: reportName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 20-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void openCaseReports(String reportName) {
		agMouseHover(CaseListingPageObjects.caseAttributesReports_Icon);
		agSetStepExecutionDelay("5000");
		agMouseHover((CaseListingPageObjects.reports_Link).replace("%reportType%", reportName));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick((CaseListingPageObjects.reports_Link).replace("%reportType%", reportName));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download Case Summary,MEDWATCH
	 *             3500, 3500A and 3500B Reports.
	 * @InputParameters: ReportName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date :20-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downLoadReport() {
		agSetStepExecutionDelay("5000");
		agGetCurrentWindow();
		agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
		agSwitchFrame(CaseListingPageObjects.pdfFrameid);
		CommonOperations.takeScreenShot();
		agJavaScriptExecuctorClick((CaseListingPageObjects.downloadIcon));
		agCloseCurrentWindow();
		agGetCurrentWindow();
	}

	/**********************************************************************************************************
	 * @Objective:Data Export movehover
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 20/02/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void DataExport(String Value) {
		agClick(CaseListingPageObjects.listingCheckBox);
		agMouseHover(CaseListingPageObjects.ExportHover);
		agJavaScriptExecuctorClick(CaseListingPageObjects.ExportClick);
	}

	/**********************************************************************************************************
	 * @Objective:Data Export movehover
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 22/04/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ExportToExcel() {
		agClick(CaseListingPageObjects.listingCheckBox);
		agMouseHover(CaseListingPageObjects.ExportHover);
		agJavaScriptExecuctorClick(CaseListingPageObjects.ExportClick);
		// agClick(CaseListingPageObjects.SelectAllCheckboxCheck);
		agClick(CaseListingPageObjects.ExportBtn);
		Reports.ExtentReportLog("", Status.INFO, "Export To Excel", true);
	}

	/**********************************************************************************************************
	 * @Objective:Enable Columns
	 * @InputParameters: Column name
	 * @OutputParameters:
	 * @author:Kishore K R
	 * @Date : 10/03/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void enableColumn(String columnName) {
		agMouseHover(CaseListingPageObjects.columnSelectionImg);
		agJavaScriptExecuctorClick(CaseListingPageObjects.columnSelectionFilter);
		agSetValue(CaseListingPageObjects.columnSelectionFilter, columnName);
		if (!agIsSelected(CaseListingPageObjects.columnSelectionCheckbox)) {
			agJavaScriptExecuctorClick(CaseListingPageObjects.columnSelectionCheckbox);
		}
	}

	/**********************************************************************************************************
	 * @Objective:Verify current Workflow Activity of an receipt
	 * @InputParameters: Expected Activity Name
	 * @OutputParameters: True or False
	 * @author:Kishore K R
	 * @Date : 10/03/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean verifyWorkflowActivity(String activityName) {
		String currentActivity = agGetText(CaseListingPageObjects.wfCurrentActivity);
		agClick(CaseListingPageObjects.wfCurrentActivity);
		if (currentActivity.equalsIgnoreCase(activityName)) {
			Reports.ExtentReportLog("Case Listing", Status.INFO,
					"Workflow activty " + currentActivity + " is displayed", true);
			return true;
		} else {
			Reports.ExtentReportLog("Case Listing", Status.INFO,
					"Workflow activty " + currentActivity + " is displayed", true);
			return false;
		}
	}

	/**********************************************************************************************************
	 * @Objective:Navigate to ISP Case processing workflow Filter
	 * @InputParameters: void
	 * @author:DushyanthMahesh
	 * @Date : 16/03/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static boolean ISP_CPWorkflow_Filter_Navigation(String filterName) {
		agClick(CaseListingPageObjects.ISP_CaseProcessingWF_Filters(filterName));
		agWaitTillVisibilityOfElement(CaseListingPageObjects.workflowCurrentStatus);
		String curWorkflow = agGetText(CaseListingPageObjects.workflowCurrentStatus);
		if (curWorkflow.trim().equalsIgnoreCase(filterName.trim())) {
			Reports.ExtentReportLog("Case Listing", Status.PASS,
					"Current Workflow activity " + curWorkflow + "is displayed", true);
			return true;
		} else {
			Reports.ExtentReportLog("Case Listing", Status.FAIL,
					"Current Workflow activity " + curWorkflow + "is displayed", true);
			return false;
		}

	}

	/**********************************************************************************************************
	 * @Objective:Navigate to Filter
	 * @InputParameters: void
	 * @author:DushyanthMahesh
	 * @Date : 16/03/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void selectSearchedCase() {
		agClick(CaseListingPageObjects.selectSearchedCase);
	}

	/**********************************************************************************************************
	 * @Objective:Create new version
	 * @InputParameters: void
	 * @author:DushyanthMahesh
	 * @Date : 16/03/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void createNewVersion() {
		agWaitTillVisibilityOfElement(CaseListingPageObjects.createNewVersionDialog);
		agSetValue(CaseListingPageObjects.createNewVerComments, "Test Automation Comment");
		agClick(CaseListingPageObjects.createNewversionSubmit);
		agSetStepExecutionDelay("5000");
		agWaitTillInvisibilityOfElement(CaseListingPageObjects.oWS_SearchLoading);
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);

		FDE_Operations.okOnValidation();
		agSetStepExecutionDelay(String.valueOf((Constants.defaultGlobalStepExecutionDelay)));
	}

	/**********************************************************************************************************
	 * @Objective:Create new version
	 * @InputParameters: void
	 * @author:DushyanthMahesh
	 * @Date : 16/03/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void distributionContactsVerNumFilterVerification() {
		agWaitTillVisibilityOfElement(SubmissionTrackingPageObjects.submissionTrackingPaginator);
		if (agIsExists(SubmissionTrackingPageObjects.AERVerNumSelect)) {
			String verNum = agGetText(SubmissionTrackingPageObjects.AERverNum);
			verNum = verNum.replace("(", "");
			verNum = verNum.replace(")", "");
			System.out.println("Version number count: " + verNum);
			for (int i = 0; i <= Integer.parseInt(verNum); i++) {
				agClick(SubmissionTrackingPageObjects.AERVerNumSelect);
				agSetStepExecutionDelay("3000");
				agClick(SubmissionTrackingPageObjects.AERVerNumSelectOption(Integer.toString(i)));
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				List<WebElement> contactsList = agGetElementList(
						SubmissionTrackingPageObjects.distributionContactListGrid);
				if (contactsList.size() > 0) {
					Reports.ExtentReportLog("Distribution contacts list", Status.PASS,
							"List of distributed contacts loading successfull", true);
				} else {
					Reports.ExtentReportLog("Distribution contacts list", Status.FAIL,
							"List of distributed contacts loading unsuccessfull", true);
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective:Create new version in case listing page
	 * @InputParameters: scenarioName
	 * @author:Pooja S
	 * @Date : 03/04/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createNewVersion(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agWaitTillVisibilityOfElement(CaseListingPageObjects.createNewVersionDialog);
		// agSetValue(CaseListingPageObjects.createNewVerComments,
		// getTestDataCellValue(scenarioName, "Newversioncomments"));
		agClick(CaseListingPageObjects.createNewversionSubmit);
		agSetStepExecutionDelay("5000");
		agWaitTillInvisibilityOfElement(CaseListingPageObjects.oWS_SearchLoading);
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton_newVersion);
		CommonOperations.write_CreateNewVersionRCTNo(scenarioName, "FDE_General");
		// FDE_Operations.okOnValidation();
		agClick(FullDataEntryFormPageObjects.saveOkButton_newVersion);
		Reports.ExtentReportLog("", Status.INFO, "Create New Version case: Scenario Name::" + scenarioName, true);
		agSetStepExecutionDelay(String.valueOf((Constants.defaultGlobalStepExecutionDelay)));
	}

	/**********************************************************************************************************
	 * @Objective:Create new version in case listing page
	 * @InputParameters: void
	 * @author:Pooja S
	 * @Date : 03/04/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void newVersion(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		agClick(CaseListingPageObjects.listingCheckBox);
		caseListing_Moreoptions(CaseListingPageObjects.Createnewverion);
		createNewVersion(scenarioName);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform search in advance search
	 *             listing.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 22-Apr-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AdvanceSearch(String scenarioName, String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetStepExecutionDelay("3000");
		CaseManagementOperations.menuNavigation("Case listing");
		// CaseManagementOperations.menusubmenuNavigation("Case listing");
		agWaitTillVisibilityOfElement(CaseListingPageObjects.searchLinks(CaseListingPageObjects.advanceSearch_link));
		agClick(CaseListingPageObjects.searchLinks(CaseListingPageObjects.advanceSearch_link));
		CommonOperations.agwaitTillVisible(AdvanceSearchPageObjects.receiptNumber_Txtfield, 3, 1000);
		agClick(AdvanceSearchPageObjects.searchLinks(AdvanceSearchPageObjects.administrativeFields_link));
		CommonOperations.agwaitTillVisible(AdvanceSearchPageObjects.receiptNumber_Txtfield, 2, 1000);
		agSetValue(AdvanceSearchPageObjects.receiptNumber_Txtfield, getTestDataCellValue(scenarioName, "ReceiptNo"));
		agClick(AdvanceSearchPageObjects.displayCases_radioBtn(AdvanceSearchPageObjects.Both_RadioBtn));
		agSetStepExecutionDelay("2000");
		agClick(AdvanceSearchPageObjects.search_Btn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.agwaitTillVisible(
				CaseListingPageObjects.waitForRCT(getTestDataCellValue(scenarioName, "ReceiptNo")), 2, 1000);
		Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform search in outofWorkFlow
	 *             listing.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 23-04-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void OutofWorkFlow(String scenarioName, String SheetName) {
		agSetStepExecutionDelay("3000");
		CaseManagementOperations.menuNavigation("Case listing");
		// CaseManagementOperations.menusubmenuNavigation("Case listing");
		agWaitTillVisibilityOfElement(CaseListingPageObjects.searchLinks(CaseListingPageObjects.advanceSearch_link));
		agClick(CaseListingPageObjects.searchLinks(CaseListingPageObjects.advanceSearch_link));
		agSetStepExecutionDelay("3000");
		ToolManager.agJavaScriptExecuctorClick(OutofWorkFlowPageObjects.outofWorkflowChkbox);
		Reports.ExtentReportLog("", Status.INFO, "Out of WorkFlow Checked", true);
		agClick(OutofWorkFlowPageObjects.SearchBtn);
		agWaitTillVisibilityOfElement(OutofWorkFlowPageObjects.OutofWOrkflowValidation);
		Reports.ExtentReportLog("", Status.INFO, "Out of WorkFlow Validation", true);
		if (agIsVisible(OutofWorkFlowPageObjects.Noreorcfound) == true) {
			Reports.ExtentReportLog("", Status.INFO, "No Case Found of Out of Workflow", true);
		} else {
			for (int i = 1; i <= 5; i++) {
				String j = String.valueOf(i);
				if (agIsVisible(OutofWorkFlowPageObjects.RecptNumber(j))) {
					agClick(OutofWorkFlowPageObjects.RecptNumber(j));
					break;

				}
			}
			agWaitTillVisibilityOfElement(OutofWorkFlowPageObjects.WorkflowStatus);
			String WorkFlowheader = agGetText(OutofWorkFlowPageObjects.WorkflowStatus);

			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (WorkFlowheader.equalsIgnoreCase("Out Of WF")) {

				Reports.ExtentReportLog("Case Sucessfully Moved to Out of Wf", Status.PASS,
						"Case Sucessfully Moved to Out of Wf", true);
			} else {
				Reports.ExtentReportLog("Case Unsucessfull", Status.FAIL, "Case Unsucessfull", true);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective:Create new version in case listing page
	 * @InputParameters: void
	 * @author:Pooja S
	 * @Date : 03/04/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void newVersion_EditCase(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		FDE_Operations.MoreOptionsLinksNavigation(FDEMoreOptionsPageObjects.moreOptions("Create New Version"));
		agWaitTillInvisibilityOfElement(FDEMoreOptionsPageObjects.Reasonlabel);

		/*
		 * agClick(CaseListingPageObjects.Aer_lookup);
		 * agSetValue(CaseListingPageObjects.AERNotextbox,
		 * DataAssessmentOperations.getData(scenarioName, "AERNo"));
		 * agClick(CaseListingPageObjects.SearchBtn);
		 * agClick(CaseListingPageObjects.Aerradiobtn);
		 * agClick(CaseListingPageObjects.AerokBtn);
		 */
		agSetValue(CaseListingPageObjects.newversioncomments, getTestDataCellValue(scenarioName, "Newversioncomments"));
		agClick(CaseListingPageObjects.CreatenewverSubmit);
		agSetStepExecutionDelay(String.valueOf((Constants.defaultGlobalStepExecutionDelay)));
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay("5000");
		agWaitTillInvisibilityOfElement(CaseListingPageObjects.oWS_SearchLoading);
		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton_newVersion);
		CommonOperations.write_CreateNewVersionRCTNo(scenarioName, "FDE_General");
		// FDE_Operations.okOnValidation();
		agClick(FullDataEntryFormPageObjects.saveOkButton_newVersion);
		Reports.ExtentReportLog("", Status.INFO, "Create New Version case: Scenario Name::" + scenarioName, true);
		agSetStepExecutionDelay(String.valueOf((Constants.defaultGlobalStepExecutionDelay)));
	}

	/**********************************************************************************************************
	 * @Objective:Validation for Reconsile notification alert
	 * @InputParameters: void
	 * @author:Pooja S
	 * @Date : 22/04/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setReconcileNotificationalert() {
		agSetStepExecutionDelay("2000");
		status = agIsVisible(DataAssessmentPageObjects.reconsileNotificationAlert);
		String reconcileNotification = agGetText(DataAssessmentPageObjects.reconsileNotificationAlert);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS,
					"Reconcile Notification Alert is visible :: Alert-" + reconcileNotification, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Reconcile Notification Alert is not visible", true);
		}
		agClick(DataAssessmentPageObjects.ReconsileYesBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.loading);
		CommonOperations.takeScreenShot();

		if (agIsVisible(DataAssessmentPageObjects.reconcileSubmitBtn) == true) {
			agClick(CaseListingPageObjects.showMoreLink);
			agClick(DataAssessmentPageObjects.reconcileSubmitBtn);
			agWaitTillVisibilityOfElement(DataAssessmentPageObjects.reconcileMessage);
		}
		agSetStepExecutionDelay(String.valueOf((Constants.defaultGlobalStepExecutionDelay)));
	}

	/**********************************************************************************************************
	 * @Objective:Validation for follow up notification alert
	 * @InputParameters: void
	 * @author:Pooja S
	 * @Date : 22/04/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setFollowUpNotificationalert() {
		agSetStepExecutionDelay("2000");
		agIsVisible(DataAssessmentPageObjects.followupNotificationAlert);
		String reconcileNotification = agGetText(DataAssessmentPageObjects.followupNotificationAlert);
		status = agIsVisible(DataAssessmentPageObjects.followupNotificationAlert);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS,
					"Reconcile followup Notification Alert is visible :: Alert-" + reconcileNotification, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Reconcile followup Notification Alert is not visible", true);
		}
		agClick(DataAssessmentPageObjects.followupReconsileYesBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.loading);
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective:To Click the append to existing and Create new version button in
	 *               Followup
	 * @InputParameters: void
	 * @author:Pooja S
	 * @Date : 22/04/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void appendtoExisting() {

		agSetStepExecutionDelay("5000");
		agWaitTillVisibilityOfElement(CaseListingPageObjects.appendtoexisitngbtn);
		agClick(CaseListingPageObjects.showMoreLink);
		agClick(CaseListingPageObjects.appendtoexisitngbtn);
		agSetStepExecutionDelay("2000");
		String Validation = agGetText(CommonPageObjects.validationMsg);
		status = agIsVisible(CommonPageObjects.validationMsg);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		String data1 = Validation.substring(Validation.lastIndexOf(":"));
		String AERNo = data1.substring(2, data1.length() - 1);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Case Information was appended/merged to AER No:" + AERNo.trim(),
					true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Case Information was not appended/merged to AER No:", true);
		}
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf((Constants.defaultGlobalStepExecutionDelay)));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify column data displayed in
	 *             listing screen.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 29-04-2020
	 * @UpdatedByAndWhen:
	 * @Note:All the Date/Time Related fields are excluded in the verification and
	 *           only those fields are verified which exist in excel sheet.
	 **********************************************************************************************************/

	public static void verifylistingScreenColumnData(String scenarioName, String sheetName) {

		agWaitTillVisibilityOfElement(CaseListingPageObjects.columnSelection);
		agClick(CaseListingPageObjects.columnSelection);
		agJavaScriptExecuctorClick(CaseListingPageObjects.columnSelection);
		agSetStepExecutionDelay("5000");

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		agAssertContainsText(CaseListingPageObjects.receiptNumberlink, getTestDataCellValue(scenarioName, "ReceiptNo"));
		agAssertContainsText(CaseListingPageObjects.reportTypeFieldData,
				getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportType"));
		agAssertContainsText(CaseListingPageObjects.companyUnitData,
				getTestDataCellValue(scenarioName, "Gen_CaseUnits_CompanyUnit"));
		agAssertContainsText(CaseListingPageObjects.reportReceivingMediumData,
				getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportReceivingMedium"));
		agAssertContainsText(CaseListingPageObjects.safetyReportIdData,
				getTestDataCellValue(scenarioName, "Gen_CaseReferences_SafetyReportID"));
		agAssertContainsText(CaseListingPageObjects.reportPriorityData,
				getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportPriority"));
		agAssertContainsText(CaseListingPageObjects.reportReceivingFormatData,
				getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportReceivingFormat"));
		agAssertContainsText(CaseListingPageObjects.reportClassificationData,
				getTestDataCellValue(scenarioName, "Gen_CaseReport_ReportClassification"));
		agAssertContainsText(CaseListingPageObjects.casePriorityData,
				getTestDataCellValue(scenarioName, "Gen_CaseUnits_localCriteriaReportType"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "DataAssessmentOperations");
		agAssertContainsText(CaseListingPageObjects.aerNolink, getTestDataCellValue(scenarioName, "AERNo"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		agAssertContainsText(CaseListingPageObjects.productNameFieldData,
				getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
		agAssertContainsText(CaseListingPageObjects.reportTermData,
				getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Reporter");
		agAssertContainsText(CaseListingPageObjects.reporterEmailIdData,
				getTestDataCellValue(scenarioName, "Reporter_EmailId"));
		agAssertContainsText(CaseListingPageObjects.reporterStateData,
				getTestDataCellValue(scenarioName, "Reporter_State"));
		agAssertContainsText(CaseListingPageObjects.reporterCountryData,
				getTestDataCellValue(scenarioName, "Reporter_Country"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Study");
		agAssertContainsText(CaseListingPageObjects.studyTypeData,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyType"));

		agSetStepExecutionDelay(String.valueOf((Constants.defaultGlobalStepExecutionDelay)));
	}

	/**********************************************************************************************************
	 * @Objective:Search using receipt number and verify notification icon in parent
	 *                   case and child case
	 * @InputParameters: Receipt number
	 * @OutputParameters: void
	 * @author:Yashwanth Naidu
	 * @Date : 13/05/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyNotificatioIconInParentAndChildCase(String parentScenarioName, String childScenarioName,
			String sheetName, String columnName) {

		CaseListingOperations.searchCase(parentScenarioName, sheetName, columnName);
		status = agIsVisible(FollowupNotificationPageObjects.followupReceived_icon);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Parent Notification Icon is visible", true);

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Parent Notification Icon is not visible", true);
		}
		CommonOperations.takeScreenShot();

		agIsVisible(CaseListingPageObjects.keywordSearchTextbox);
		agClearText(CaseListingPageObjects.keywordSearchTextbox);
		CaseListingOperations.searchCase(childScenarioName, sheetName, columnName);
		status = agIsVisible(FollowupNotificationPageObjects.followupNotified_icon);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Child Notification Icon is visible", true);

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Child Notification Icon is not visible", true);
		}
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective:This method is used to verify that the child case is in
	 *                 non-editable mode from listing screen
	 * @InputParameters:
	 * @OutputParameters: void
	 * @author:Yashwanth Naidu
	 * @Date : 13/05/2020
	 * @UpdatedByAndWhen:WajahatUmar S on 18-Nov-2020
	 **********************************************************************************************************/

	public static void VerifyChildCaseInNonEditableMode() {

		if (agIsVisible(CaseListingPageObjects.caseApproved) == true) {
			agWaitTillVisibilityOfElement(CaseListingPageObjects.caseApproved);
			status = agIsVisible(CaseListingPageObjects.caseApproved);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Child Case is in non-editable mode", true);

			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Child Case is not in editable mode", true);
			}
		} else if (agIsVisible(CaseListingPageObjects.NotifiedFollowupIcon) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Case is Notified and Child Case is in non-editable mode", true);
		}

		agClick(CaseListingPageObjects.receiptNumberlink);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);

		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.nonEditableCompanyUnit);
		status = agIsVisible(FullDataEntryFormPageObjects.nonEditableCompanyUnit);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Child Case is in non-editable mode", true);

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Child Case is not in editable mode", true);
		}
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective:This method is used to move case to Japan workflow
	 * @InputParameters:
	 * @OutputParameters: void
	 * @author:Yashwanth Naidu
	 * @Date : 03 jult 2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void moveCaseToJapanWF(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetStepExecutionDelay("10000");
		CaseManagementOperations.menuNavigation("Case listing");
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, columnName));
		agClick(CaseListingPageObjects.searchButton);

		agWaitTillVisibilityOfElement(getTestDataCellValue(scenarioName, columnName));

		Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);
		agSetStepExecutionDelay("6000");

		agClick(CaseListingPageObjects.japanDataEntryLink);

		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
	}

	/**********************************************************************************************************
	 * @Objective:This method is used to Verification of Source Document from the
	 *                 Listing Screen
	 * @InputParameters:
	 * @OutputParameters: void
	 * @author:WajahatUmar S
	 * @Date : 15-JULY-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerificationofSourceDocumnetfromListingScreen(String scenarioName, String sheetName,
			String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		try {
			agSetStepExecutionDelay("5000");
			CaseManagementOperations.menuNavigation("Case listing");
			agSetValue(CaseListingPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, columnName));
			agClick(CaseListingPageObjects.searchButton);
			agWaitTillVisibilityOfElement(getTestDataCellValue(scenarioName, columnName));
			Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);
			String winHandleBefore = driver.getWindowHandle();
			Reports.ExtentReportLog("", Status.INFO, "Column Selection", true);
			agMouseHover(CaseListingPageObjects.columnSelection);
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorClick(CaseListingPageObjects.columnSelectAll);
			Reports.ExtentReportLog("", Status.INFO, "All Columns Selected", true);
			agClick(CaseListingPageObjects.columnSelectionFilter);
			agSetStepExecutionDelay("3000");
			if (agIsVisible(CaseListingPageObjects.CaseAttributeHTML)) {
				agMouseHover(CaseListingPageObjects.CaseAttributeHTML);
				agSetStepExecutionDelay("3000");
				Reports.ExtentReportLog("", Status.INFO, "Case Summary Document", true);
				agJavaScriptExecuctorClick(CaseListingPageObjects.DocumentSelection("Case Summary"));
				agSetStepExecutionDelay("3000");
				Set<String> allWindows = driver.getWindowHandles();
				for (String winHandle : allWindows) {
					agSetStepExecutionDelay("3000");
					driver.switchTo().window(winHandle);
					agGetCurrentWindow();
					Reports.ExtentReportLog("", Status.INFO, "Case Summary Document Opened in New Window", true);
					agCloseCurrentWindow();
				}
				driver.switchTo().window(winHandleBefore);
				agGetCurrentWindow();

				// agGetCurrentWindow();
				agSetStepExecutionDelay("3000");
				agMouseHover(CaseListingPageObjects.CaseAttributeHTML);
				Reports.ExtentReportLog("", Status.INFO, "MEDWATCH 3500A Document", true);
				agJavaScriptExecuctorClick(CaseListingPageObjects.DocumentSelection("MEDWATCH 3500A"));
				agSetStepExecutionDelay("3000");

				for (String winHandle : driver.getWindowHandles()) {
					agSetStepExecutionDelay("3000");
					driver.switchTo().window(winHandle);
					agGetCurrentWindow();
					Reports.ExtentReportLog("", Status.INFO, "MEDWATCH 3500A Document Opened in New Window", true);
					agCloseCurrentWindow();
				}
				driver.switchTo().window(winHandleBefore);
				agGetCurrentWindow();
				agSetStepExecutionDelay("3000");

				agMouseHover(CaseListingPageObjects.CaseAttributeHTML);
				Reports.ExtentReportLog("", Status.INFO, "CIOMS Document", true);
				agJavaScriptExecuctorClick(CaseListingPageObjects.DocumentSelection("CIOMS"));
				agSetStepExecutionDelay("3000");

				for (String winHandle : driver.getWindowHandles()) {
					agSetStepExecutionDelay("3000");
					driver.switchTo().window(winHandle);
					agGetCurrentWindow();
					Reports.ExtentReportLog("", Status.INFO, "CIOMS Document Opened in New Window", true);
					agCloseCurrentWindow();

				}
				driver.switchTo().window(winHandleBefore);
				agGetCurrentWindow();
				agSetStepExecutionDelay("3000");
				// Not Required
				// agClick(CaseListingPageObjects.receiptNumberlink);
				// agClick(DocumentsPageObjects.CaseDocumentBtn);
				// String winHandleBeforeCase = driver.getWindowHandle();
				// if (agIsVisible(FDE_CaseDocumentsPageObjects.filenameLink)) {
				Reports.ExtentReportLog("", Status.INFO, "Source Document Present in Case", true);
				// agClick(FDE_CaseDocumentsPageObjects.filenameLink);
				// for (String winHandle : driver.getWindowHandles()) {
				// agSetStepExecutionDelay("3000");
				// driver.switchTo().window(winHandle);
				// agGetCurrentWindow();
				// Reports.ExtentReportLog("", Status.INFO, "Source Document Opened in New
				// Window", true);
				// agCloseCurrentWindow();
				//
				// }
				// driver.switchTo().window(winHandleBeforeCase);
				// agGetCurrentWindow();
				// agSetStepExecutionDelay("3000");
				// agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			} else {
				Reports.ExtentReportLog("", Status.INFO, "Source Document not Present in Case", true);
			}

			// }

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Verification of Source Document failed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective:This method is used to download and verify the XML from case
	 *                 listing screen
	 * @InputParameters:scenarioName,sheetName,columnName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 06-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void downloadXMLVerificationfromListingScreen(String scenarioName, String sheetName,
			String columnName) {
		Reports.ExtentReportLog("", Status.INFO, "Download and verification of XML in case listing screen started",
				true);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		try {
			agSetStepExecutionDelay("5000");
			CaseManagementOperations.menuNavigation("Case listing");
			agWaitTillVisibilityOfElement(CaseListingPageObjects.keywordSearchTextbox);
			CaseListingOperations.searchCase(scenarioName, sheetName, columnName);
			agIsVisible(CaseListingPageObjects.columnSelection);
			agClick(CaseListingPageObjects.columnSelection);
			agClick(CaseListingPageObjects.selectAll_checkbox);
			agClick(CaseListingPageObjects.keywordSearchTextbox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (agIsVisible(CaseListingPageObjects.XMLicon) == true) {
				CommonOperations.takeScreenShot();
				String XML = agGetAttribute("title", CaseListingPageObjects.XMLicon);
				if (XML.equalsIgnoreCase("R2 XML") || XML.equalsIgnoreCase("R3 XML")) {
					agSetStepExecutionDelay("2000");
					Reports.ExtentReportLog("", Status.INFO, " XML Exists : " + XML, true);
					agJavaScriptExecuctorClick(CaseListingPageObjects.XMLicon);
					agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
					agWaitTillVisibilityOfElement(CaseListingPageObjects.downloadBtn);
					agJavaScriptExecuctorClick(CaseListingPageObjects.downloadBtn);
					CommonOperations.takeScreenShot();
					agSetStepExecutionDelay("15000");
					CaseListingOperations.verifyDownloadedXML(scenarioName);
					agJavaScriptExecuctorClick(CaseListingPageObjects.closeBtn);
					agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				}
			} else {
				Reports.ExtentReportLog("", Status.INFO, "XML icon is not visible", true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			agClick(CaseListingPageObjects.closeBtn);
			Reports.ExtentReportLog("", Status.FAIL,
					"Download and verification of XML in case listing screen not verified" + e, true);
		}
		Reports.ExtentReportLog("", Status.INFO, "Download and verification of XML in case listing screen ended", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the downloaded xml in case
	 *             listing screen
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 06-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDownloadedXML(String scenarioName) {
		String RecptNo = FDE_General.getData(scenarioName, "ReceiptNo");
		String path = lsmvConstants.LSMV_testDataOutput + "\\" + Reports.currenttime();
		lsmvConstants.path = path;
		System.out.println(lsmvConstants.path);
		agSetStepExecutionDelay("15000");
		FileSystemOperations.createFolder(path);
		FileSystemOperations.moveFile(RecptNo + ".xml", lsmvConstants.LSMV_testDataOutput, path);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		FileSystemOperations.renameFile(path, RecptNo + ".xml", scenarioName + ".xml");
		agSetStepExecutionDelay("15000");
		boolean status = PDFOperations.isFileDownloaded(lsmvConstants.path + "\\", scenarioName + ".xml");
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "XML file exist", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "XML file not exist", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created for verification of products coded in
	 *             case listing
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 06-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void productCodedVerification() {
		if (agIsVisible(CaseListingPageObjects.partialCodeIcon) == true) {
			Reports.ExtentReportLog("", Status.INFO, "Partially Case coded Successfully", true);
			agClick(CaseListingPageObjects.partialCodeIcon);
		} else if (agIsVisible(CaseListingPageObjects.caseCodedIcon) == true) {
			Reports.ExtentReportLog("", Status.INFO, "Case coded Successfully", true);
			agClick(CaseListingPageObjects.caseCodedIcon);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Case not coded Successfully", true);
		}
		agIsVisible(CaseListingPageObjects.caseCoding_Label);
	}

	/**********************************************************************************************************
	 * @Objective: This function is created to get the blinded and unblinded
	 *             ProductNameAsReported in coded window
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 06-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> getProductNameAsReportedCodedList() {
		List<WebElement> productList = agGetElementList(CaseListingPageObjects.prodNameAsReportedList);
		ArrayList Al = new ArrayList<>();
		for (int i = 0; i < productList.size(); i++) {
			agIsVisible(CaseListingPageObjects.getProdNameAsReported(Integer.toString(i + 1)));
			String getProduct = agGetText(CaseListingPageObjects.getProdNameAsReported(Integer.toString(i + 1)));
			List<String> list = Arrays.asList(getProduct.toString());
			Al.addAll(i, list);
			System.out.println(Al);
		}
		return Al;
	}

	/**********************************************************************************************************
	 * @Objective: This function is created to get the blinded and unblinded
	 *             ProductNameAsReported in coded window for previleged user
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 06-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void productStatusVerificationInCaseListing_PrevilegedUser(String scenarioName) {
		ArrayList<String> productCode = new ArrayList<>();
		ArrayList<String> ProductList = getProductNameAsReportedCodedList();
		productCode.addAll(ProductList);

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "Product_LookupOperations");
		String unblindProd = getTestDataCellValue(scenarioName, "ProductLibraryProductName");

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Study");
		String blindProd = getTestDataCellValue(scenarioName, "BlindedProduct_1");

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		String nonProd = getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductNameAsReported");

		for (int i = 0; i < productCode.size(); i++) {
			String prodCode = productCode.get(i).toString();
			String[] arrStr = prodCode.split("M");
			String Product = arrStr[0].trim();
			System.out.println(Product);
			if (Product.equalsIgnoreCase(unblindProd)
					|| (Product.equalsIgnoreCase(blindProd) || Product.equalsIgnoreCase(nonProd))) {
				String codeStatus = agGetAttribute("title",
						CaseListingPageObjects.productCodingStatus(Integer.toString(i + 1)));

				if (codeStatus.contains("Coded")) {
					Reports.ExtentReportLog("", Status.PASS,
							" product Status coded verification in case listing done for previlged user  " + Product,
							true);
				} else if (codeStatus.contains("Not Coded")) {
					Reports.ExtentReportLog("", Status.PASS,
							" product Status not coded verification in case listing done for unprevilged user  "
									+ Product,
							true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL,
							" product Coded Status in case listing not visible " + Product, true);
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: This function is created to get the blinded and unblinded
	 *             ProductNameAsReported in coded window for unprevileged user
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 06-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void productStatusVerificationInCaseListing_UnPrevilegedUser(String scenarioName) {
		ArrayList<String> productCode = new ArrayList<>();
		ArrayList<String> ProductList = getProductNameAsReportedCodedList();
		productCode.addAll(ProductList);

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Study");
		String blindProd = getTestDataCellValue(scenarioName, "BlindedProduct_1");

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		String nonProd = getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductNameAsReported");

		for (int i = 0; i < productCode.size(); i++) {
			String prodCode = productCode.get(i).toString();
			String[] arrStr = prodCode.split("M");
			String Product = arrStr[0].trim();
			System.out.println(Product);
			if (Product.equalsIgnoreCase(blindProd) && Product.equalsIgnoreCase(nonProd)) {
				String codeStatus = agGetAttribute("title",
						CaseListingPageObjects.productCodingStatus(Integer.toString(i + 1)));

				if (codeStatus.contains("Coded")) {
					Reports.ExtentReportLog("", Status.PASS,
							" product Status coded verification in case listing done for previlged user  " + Product,
							true);
				} else if (codeStatus.contains("Not Coded")) {
					Reports.ExtentReportLog("", Status.PASS,
							" product Status not coded verification in case listing done for unprevilged user  "
									+ Product,
							true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL,
							" product Coded Status in case listing not visible " + Product, true);
				}

			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: This function is created to get the blinded and unblinded
	 *             ProductNameAsReported in coded window
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> getIndicationTermsinCodedList() {
		List<WebElement> IndicationList = agGetElementList(CaseListingPageObjects.getindicationTermList);
		ArrayList Al = new ArrayList<>();
		for (int i = 0; i < IndicationList.size(); i++) {
			agIsVisible(CaseListingPageObjects.getIndication(Integer.toString(i + 1)));
			String getProduct = agGetText(CaseListingPageObjects.getIndication(Integer.toString(i + 1)));
			List<String> list = Arrays.asList(getProduct.toString());
			Al.addAll(i, list);
			System.out.println(Al);
		}
		return Al;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created verification for products indication
	 *             in split window
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void indicationsVerification(String scenarioName) {
		agJavaScriptExecuctorScrollToElement(CaseListingPageObjects.drugIndicationLabel);
		ArrayList<String> code = new ArrayList<>();
		ArrayList<String> codeList = getIndicationTermsinCodedList();
		code.addAll(codeList);

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Study");
		String studyIndication = getTestDataCellValue(scenarioName, "Study_Indication");

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		String nonindication = getTestDataCellValue(scenarioName,
				"Products_Indications_IndicationMedDRALLTCode_SearchTerm");

		for (int i = 0; i < code.size(); i++) {
			String indication = code.get(i).toString();
			if (indication.equalsIgnoreCase(studyIndication) || (indication.equalsIgnoreCase(nonindication))) {
				String codedSrc = agGetAttribute("src",
						CaseListingPageObjects.getIndicationStatus(Integer.toString(i + 1)));

				if (codedSrc.contains("greenCheck")) {
					Reports.ExtentReportLog("", Status.PASS, "Indication Status coded " + indication, true);
				} else if (codedSrc.contains("delete")) {
					Reports.ExtentReportLog("", Status.PASS, "Indication Status not coded  " + indication, true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, " Indication Status not visible " + indication, true);
				}

			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to close the indication/product code
	 *             scren
	 * @InputParameters: scenarioName , sheetName ,columnName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 09-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void close() {
		agClick(CaseListingPageObjects.closeIcon);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the case is coded in case
	 *             listing screen
	 * @InputParameters: scenarioName , sheetName ,columnName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 06-Oct-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCaseCoded(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetStepExecutionDelay("10000");
		CaseManagementOperations.menuNavigation("Case listing");
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, columnName));
		agClick(CaseListingPageObjects.searchButton);
		agWaitTillVisibilityOfElement(getTestDataCellValue(scenarioName, columnName));
		Reports.ExtentReportLog("", Status.INFO, "Case is listed", true);
		agSetStepExecutionDelay("6000");

		status = agIsVisible(CaseListingPageObjects.caseCodedIcon);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Case coded Successfully", true);

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Case not coded Successfully", true);
		}
		CommonOperations.takeScreenShot();
	}

	public static void navigateToCaseListing() {
		agSetStepExecutionDelay("10000");
		CaseManagementOperations.menuNavigation("Case listing");
		agWaitTillVisibilityOfElement(CaseListingPageObjects.keywordSearchTextbox);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform search in duplicate search
	 *             and verify result
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 11-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDuplicateSearchResult(String scenarioName, String scenarioName1, String sheetName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetStepExecutionDelay("3000");
		CaseManagementOperations.menuNavigation("Case listing");
		agWaitTillVisibilityOfElement(CaseListingPageObjects.searchLinks(CaseListingPageObjects.duplicateSearch_Link));
		agClick(CaseListingPageObjects.searchLinks(CaseListingPageObjects.duplicateSearch_Link));
		agIsVisible(CaseListingPageObjects.duplicateSearchHeader);

		agSetValue(CaseListingPageObjects.receiptNo, getTestDataCellValue(scenarioName, "ReceiptNo"));
		agClick(CaseListingPageObjects.dupSearchBtn);
		String orgrctno = getTestDataCellValue(scenarioName, "ReceiptNo");
		agAssertExists(CaseListingPageObjects.dupRCTNo(orgrctno));

		agClick(CaseListingPageObjects.searchLinks(CaseListingPageObjects.duplicateSearch_Link));
		agIsVisible(CaseListingPageObjects.duplicateSearchHeader);

		agClearText(CaseListingPageObjects.receiptNo);
		agSetValue(CaseListingPageObjects.receiptNo, getTestDataCellValue(scenarioName1, "ReceiptNo"));
		agClick(CaseListingPageObjects.dupSearchBtn);
		String duprctno = getTestDataCellValue(scenarioName1, "ReceiptNo");
		agAssertExists(CaseListingPageObjects.dupRCTNo(duprctno));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to write copied case AER no in Data
	 *             Assessment operation
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 18-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void WriteAERNo(String scenarioName, String sheetName) {
		agIsVisible(CaseListingPageObjects.copiedAERNo);
		status = agIsVisible(CaseListingPageObjects.copiedAERNo);
		String AER = agGetText(CaseListingPageObjects.copiedAERNo);
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, "AERNo", AER.trim());
		if (status) {
			Reports.ExtentReportLog("", Status.INFO, "AER No copied " + AER, true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "AER No is not copied successfully", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to open the searched case in case
	 *             listing
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Praveen Patil
	 * @Date : 22-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void openSearchedCase() {

		agWaitTillVisibilityOfElement(CaseListingPageObjects.receiptNumberlink);
		agClick(CaseListingPageObjects.receiptNumberlink);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Case is opened", true);

	}

	/**********************************************************************************************************
	 * @Objective:This method is used to verify that the case is in non-editable
	 *                 mode from case screen
	 * @InputParameters:
	 * @OutputParameters: void
	 * @author:Kishore K R
	 * @Date : 19/01/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void VerifyCaseInNonEditableMode() {
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.editCase_Loading);

		agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.nonEditableCompanyUnit);
		status = agIsVisible(FullDataEntryFormPageObjects.nonEditableCompanyUnit);
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Child Case is in non-editable mode", true);

		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Child Case is not in editable mode", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective:This method is used to close the case
	 * @InputParameters:
	 * @OutputParameters: void
	 * @author:Kishore K R
	 * @Date : 28/01/2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void CloseCase() {
		agClick(FullDataEntryFormPageObjects.LSMVCancel);
		agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.nonEditableCompanyUnit);
		agWaitTillVisibilityOfElement(CaseListingPageObjects.keywordSearchTextbox);
		status = agIsVisible(CaseListingPageObjects.keywordSearchTextbox);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Case closed successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Case close is Unsuccessfull", true);
		}
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective:This method is used to verify the follwoup up recieved icon for
	 *                 the case
	 * @InputParameters:
	 * @OutputParameters: void
	 * @author:Pooja S
	 * @Date : 18/02/2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyFollowupRecievedIcon() {
		status = agIsVisible(CaseListingPageObjects.followupRecvdIcon);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (status) {
			Reports.ExtentReportLog("", Status.PASS, "Followup received icon is visible", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Followup received icon is not visible", true);
		}
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective:This method is used to click on given Rct link the case
	 * @InputParameters:
	 * @OutputParameters: void
	 * @author:Vamsi krishna RS
	 * @Date : 19/02/2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void ClickGivenRCT(String rctnum) {
		agClick(CaseListingPageObjects.genericrecptCheckbox(rctnum));
	}

	/**********************************************************************************************************
	 * @Objective:This method is used to get data form caselisting sheet the case
	 * @InputParameters:
	 * @OutputParameters: void
	 * @author:Vamsi krishna RS
	 * @Date : 19/02/2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String GetRCTNumTestData(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		String TestDataRect = getTestDataCellValue(scenarioName, columnName);
		return TestDataRect;

	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select multiple case from case
	 *                listing screen and click on open Multiplelink
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void openmultipleRecipts() {
		caseListing_Moreoptions(CaseListingPageObjects.openMultiple_link);
	}

	public static void SimplesearchCase(String rctnum) {
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, rctnum);
		agClick(CaseListingPageObjects.searchButton);
		agWaitTillInvisibilityOfElement(CaseListingPageObjects.oWS_SearchLoading);
		// wait statements
	}

	public static String GetAppRCT(String scenarioName, String sheetName, String column) {
		String Rct = agGetText(CaseListingPageObjects.receiptNumberlink);
		XlsReader.writeToTestData(lsmvConstants.LSMV_testData, sheetName, scenarioName, column, Rct.trim());
		return Rct;
	}
	
	
	
	public static void ExportAERData(String scenarioName, String sheetName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetName);
		agSetStepExecutionDelay("10000");
		CaseManagementOperations.menuNavigation("Case listing");
		
		agSetValue(CaseListingPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, columnName));
		agJavaScriptExecuctorClick(CaseListingPageObjects.searchButton);
		Reports.ExtentReportLog("", Status.INFO, "Case is listed in Listing Screen", true);
		agJavaScriptExecuctorClick(CaseListingPageObjects.SelectReptCheckBox);
		agSetStepExecutionDelay("3000");
		agMouseHover(CaseListingPageObjects.MoreActionsListing);
		agJavaScriptExecuctorClick(CaseListingPageObjects.ExportAERBTn);		
		
		
	}
}
