package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class FDE_LabellingPageObjects {

	public static String blindedButton = "xpath#//button[text()='Switch to Blinded']";
	public static String unblindedButton = "xpath#//button[text()='Switch to Unblinded']";
	public static String productDropdown = "xpath#//span[@class='tableHeaderCol']/p-dropdown/div";
	public static String productList = "xpath#//div[contains(@class,'ng-trigger ng-trigger-overlayAnimation')]/div/ul/li/div";
	public static String productGetText = "xpath#(//div[contains(@class,'ng-trigger ng-trigger-overlayAnimation')]/div/ul/li/div)[{0}]";
	public static String checkBoxUnder = "xpath#//table/thead[@class='ui-table-thead']/tr[2]/th[text()='{0}']//ancestor::p-table/div//tbody/tr/td[8]/p-checkbox/div/div[2]";
	public static String manualCheckBoxUnder = "xpath#//table/thead[@class='ui-table-thead']/tr[2]/th[text()='{0}']//ancestor::p-table/div//tbody/tr/td[9]/p-checkbox/div/div[2]";
	public static String SUSAR_CheckBox = "SUSAR";
	public static String clickReporterTerm_Dropdown = "xpath#//p-multiselect/div//label[text()='Reported Term']";
	public static String reporterTerm_Dropdown = "xpath#//ul[contains(@class,'ui-multiselect-items')]/li/child::div/following-sibling::label[text()='%s']";

	public static String addButton = "xpath#(//a[@class='agMultiAddLink ng-star-inserted'])[2]";
	public static String AddAllEvents = "xpath#(//a[@class='agMultiAddLink ng-star-inserted'])[1]";
	public static String clickAddedNewTermDropdown = "xpath#//p-dropdown/div//label[contains(text(),'Select')]";
	public static String addedNewTermDropdown = "xpath#//ul[contains(@class,'ui-dropdown-items')]/li/span[text()='%s']";
	public static String clickCountryDropdown = "xpath#//tbody/tr/td/p-dropdown/div/label/span[contains(text(),'Select')]";
	public static String addedCountryDropdown = "xpath#//ul[contains(@class,'ui-dropdown-items')]/li/div/span[text()='%s ']";
	public static String selectCountryDropdown = "xpath#//ul[contains(@class,'ui-dropdown-items')]/li/div/span[text()='%s']";
	public static String clicklabelingDropdown = "xpath#//tbody/tr/td[5]/p-dropdown/div/label/span[contains(text(),'Select')]";
	public static String addedLabelingDropdown = "xpath#//ul[contains(@class,'ui-dropdown-items')]/li/div/span[contains(text(),'%s')]";
	public static String manual_Checkbx = "Manual";
	public static String manaul_SUSAR_CheckBox = "xpath#(//table/thead[@class='ui-table-thead']/tr[2]/th[text()='{0}']//ancestor::p-table/div//tbody/tr/td/p-checkbox/div/div[2])[1]";

	public static String labelling_Label = "xpath#//span[text()='%event%']/ancestor::td/following::td/descendant::label/span[text() = '%country%']/ancestor::td/following::td[1]/descendant::span[text() = '%label%']";

	public static String RadioBtn = "xpath#//span[@class='ui-radiobutton-icon ui-clickable']";
	public static String deleteBtn = "xpath#//a[@class='agMultiDeleteLink ng-star-inserted']";
	public static String YesBtn = "xpath#//p-confirmdialog//span[text()='Yes']";
	// unlabelled

	public static String unlablled = "xpath#(//thead[@class='ui-table-thead']/tr/th[text()='Labeling ']//following::tbody/tr/td[5]/p-dropdown/div//span[text()='Unlabeled'])[{%count%}]";
	public static String SusarCheckBoxChecked = "xpath#//p-checkbox//div//input[contains(@id,'labellingSusar')]/parent::div/following-sibling::div//span[contains(@class,'ui-chkbox-icon ui-clickable pi pi-check')]";

	// codelist tags
	public static String CLCountry = "xpath#//label[text()='[9744_1015]']";
	public static String CLLabelling = "xpath#//label[text()='[7077]']";

	public static String countryDSUR = "Xpath#//span[text()='DSUR']";
	public static String CountryDropdown = "xpath#//tbody/tr/td[4]/p-dropdown//span[contains(text(),'Select')]";
	public static String LSMVCancel = "xpath#//a[@id='adverseEventNew:cancelId']";
	public static String exitConfirmation = "xpath#//label[text()='Do you want to exit without saving?']";
	public static String YesBTn = "xpath#//button[@id='formModifyYes']";
	public static String caselistingHeader = "xpath#//label[text()='All Case Listing']";
	public static String loader = "xpath#//img[@id='headerForm:j_id_1f']";
	public static String labellingDropdown = "xpath#//tbody/tr/td[5]/p-dropdown/div[not(contains(@class,'ui-state-disabled'))]//span[contains(text(),'Select')]";

	// Manual SUSAR
	public static String SUSARChkBox = "xpath#(//p-checkbox//div//input[contains(@id,'labellingSusar')]/parent::div//following::div[1])[1]";
	public static String ManualSUSARCheckBox = "xpath#(//p-checkbox//div//input[contains(@id,'labellingsusarManual')]/parent::div//following::div[1])[%s]";
	public static String SUSAREventCount = "xpath#//p-table//tbody//tr";
	public static String SUSARCountry = "xpath#//p-table//tbody//tr[%s]//td[4]//p-dropdown//label//span";
	public static String productCount = "xpath#//a[text()='Product(s)']//span";
	public static String NextProduct = "xpath#//a[@class='labellingNext']";

	public static String labelingHeader = "xpath#//span[@class='agCasPanelHeader']//a";
	public static String DSURCountry = "xpath#//tbody/tr/td[4]/p-dropdown//span[contains(text(),'Select')]";
	public static String DSURLabeling = "xpath#//tbody/tr[2]/td[5]/p-dropdown//span[contains(text(),'Labeled')]";

	public static String labelingNextProduct = "xpath#//i[@class='pi pi-caret-right greyOut']";
	public static String addNewReportTermDD = "xpath#//label[text()='Select']";
	public static String newreportedTermDD = "xpath#//ul[contains(@class,'ui-dropdown-items')]/li//span[text()='%s']";

	public static String labelingProductClick = "xpath#//a[@class='labellingPrev']//parent::span/p-dropdown/div//div[3]";
	public static String labelingProductValue = "xpath#(//div[@class='ui-dropdown-items-wrapper']/ul/li/div/span[text()='%s'])[1]";
	public static String addAllEvents_Btn = "xpath#//span/a[text()='Add All Events']";

	public static String CountryDD = "xpath#//span[text()='CUBA ( CUB )']";
	public static String LabellingDD = "xpath#//span[text()='Labeled']";
	public static String UnlabellingDD = "xpath#(//span[text()='Unlabeled'])[2]";

	public static String CheckBoxSUsarGeneralScreen = "xpath#//label[text()='SUSAR']/parent::span//span[@class='ui-chkbox-icon ui-clickable pi pi-check']";
	public static String CheckBoxSusarLabellingScreen = "xpath#(//p-checkbox//div//input[contains(@id,'labellingSusar')]/parent::div//following::div[1]//span[@class='ui-chkbox-icon ui-clickable pi pi-check'])[1]";

	public static String LabelDD = "xpath#//label[@class='ng-tns-c2-123 ui-dropdown-label ui-inputtext ui-corner-all ng-star-inserted']";
	public static String LabelDDValue = "xpath#//span[text()='Unlabelled ']";
	public static String ManualCheckBoxChecked = "xpath#(//span[@class='ui-chkbox-icon ui-clickable pi pi-check'])[1]";
	public static String ManualCheckBoxUnChecked = "xpath#(//span[@class='ui-chkbox-icon ui-clickable'])[1]";

	public static String addedSecondCountryDropdown = "xpath#(//ul[contains(@class,'ui-dropdown-items')]/li/div/span[text()='%s'])[2]";
	public static String labellingSecondDropdown = "xpath#//tbody/tr/td[5]/p-dropdown/div[1]//span[contains(text(),'Select')]";
	public static String addedLabelingSecondDropdownValue = "xpath#(//ul[contains(@class,'ui-dropdown-items')]/li/div/span[text()='%s'])[2]";

	public static String nextProduct = "xpath#//a[@class='labellingNext']/i";
	public static String labelingDDValue = "xpath#(//span[text()='Labeled'])[2]";

	/**********************************************************************************************************
	 * @Objective:get Question name by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:Pooja S Date :08-May-2020 Updated by and when
	 **********************************************************************************************************/
	public static String indexCount(String count) {
		String value = unlablled;
		String value2;
		value2 = value.replace("{%count%}", count);
		return value2;
	}

	public static String productGetText(String num) {
		String value = productGetText.replace("{0}", num);
		return value;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author: Avinash k
	 * @Date : 30-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String resultLocator = null;

	public static String checkBoxUnder(String checkBoxLabel) {
		String actualLocator = checkBoxUnder;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}

	public static String ManualCheckBoxUnder(String checkBoxLabel) {
		String actualLocator = manualCheckBoxUnder;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to select the dropdown specified
	 *             label passing value at runtime.
	 * @InputParameters:
	 * @OutputParameters: Return's dynamic xpath
	 * @author: Avinash k
	 * @Date : 11-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectReporterTerm(String label) {
		String value = reporterTerm_Dropdown.replace("%s", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify Auto Labeling passing value
	 *             at runtime.
	 * @InputParameters: event, country, label
	 * @OutputParameters: Return's dynamic xpath
	 * @author: Avinash k
	 * @Date : 27-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String labellingData(String event, String country, String label) {
		String temp1 = labelling_Label.replace("%event%", event);
		String temp2 = temp1.replace("%country%", country);
		String temp3 = temp2.replace("%label%", label);
		return temp3;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the dropdown specified
	 *             label passing value at runtime in newly added.
	 * @InputParameters:
	 * @OutputParameters: Return's dynamic xpath
	 * @author: Yashwanth Naidu
	 * @Date : 01-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static String selectAddedTerm(String label) {
		String value = addedNewTermDropdown.replace("%s", label);
		return value;
	}

	public static String addNewReportedTerm(String label) {
		String value = newreportedTermDD.replace("%s", label);
		return value;
	}

	public static String labelingProduct(String label) {
		String value = labelingProductValue.replace("%s", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the dropdown specified
	 *             label passing value at runtime.
	 * @InputParameters:
	 * @OutputParameters: Return's dynamic xpath
	 * @author: Yashwanth Naidu
	 * @Date : 01-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectCountry(String label) {
		String value = addedCountryDropdown.replace("%s", label);
		return value;
	}

	public static String selectSecondCountry(String label) {
		String value = addedSecondCountryDropdown.replace("%s", label);
		return value;
	}

	public static String CountrySelect(String label) {
		String value = selectCountryDropdown.replace("%s", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the dropdown specified
	 *             label passing value at runtime.
	 * @InputParameters:
	 * @OutputParameters: Return's dynamic xpath
	 * @author: Yashwanth Naidu
	 * @Date : 01-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectLabeling(String label) {
		String value = addedLabelingDropdown.replace("%s", label);
		return value;
	}

	public static String selectsecondLabeling(String label) {
		String value = addedLabelingSecondDropdownValue.replace("%s", label);
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Yashwanth Naidu
	 * @Date : 1-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String checkSusarManual(String checkBoxLabel) {
		String actualLocator = manaul_SUSAR_CheckBox;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}

	public static String ManualSUSARCheckBox(String chkBox, int row) {
		String actualLocator = chkBox;
		resultLocator = actualLocator.replace("%s", row + "");
		return resultLocator;
	}

	public static String autoProductLabel_Table = "xpath#//div[contains(@class, 'ui-table-wrapper ng-star-inserted')]//tbody";
	public static String label_tag = "xpath#//div[contains(@class, 'ui-table-wrapper ng-star-inserted')]//tbody";

	public static String label_default = "xpath#//span/ancestor::td/following::td/descendant::label/span[text() = '%country%']/ancestor::td/following::td[1]/descendant::span[text() = '%label%']";
	public static String label_default2 = "xpath#//span/ancestor::td/following::td/descendant::label/span[text() = '%country%']";

	public static String labellingData(String country, String label) {
		String temp1 = label_default.replace("%country%", country);
		String temp2 = temp1.replace("%label%", label);

		return temp2;
	}

	public static String labellingData(String country) {
		String temp1 = label_default2.replace("%country%", country);

		return temp1;
	}
}
