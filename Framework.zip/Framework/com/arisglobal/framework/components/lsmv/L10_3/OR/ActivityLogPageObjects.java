package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class ActivityLogPageObjects {
	
	
	public static String data_Verification = "xpath#//td[contains(text(),'%s')]";
    public static String activityLog_header ="xpath#//span[@id='activityLogFormId:addactivityDialog_title']";
    public static String close_btn = "xpath#//a[@id='activityLogFormId:closeId']";
    
    public static String activityLog_Link ="Activity Log";
 
    /**********************************************************************************************************
	 * @Objective:The below method is created to verify activity log data by passing data at runtime.
	 * @Input Parameters: 
	 * @Output Parameters:
	 * @author:Avinash K Date :23-Sep-2019 Updated by and when   	 
	**********************************************************************************************************/
    public static String data_Verification(String runTimeLabel) {
        String value = data_Verification;
        String value2;
        value2 = value.replace("%s", runTimeLabel);
        return value2;
    }
}
