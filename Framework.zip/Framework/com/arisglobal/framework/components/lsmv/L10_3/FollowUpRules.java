package com.arisglobal.framework.components.lsmv.L10_3;


import java.util.List;

import org.openqa.selenium.WebElement;


import com.arisglobal.framework.components.lsmv.L10_3.OR.FollowUpRulesPageObjects;

import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FollowUpRules extends ToolManager {

	static String className = FollowUpRules.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to create new Rule
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :  12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createNewRule()
	{
		agAssertVisible(FollowUpRulesPageObjects.ruleKeyword_Textbox);
		agClick(FollowUpRulesPageObjects.newbtn);
		agAssertVisible(FollowUpRulesPageObjects.ruleName);
		CommonOperations.takeScreenShot();
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Edit new Rule
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :  12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void editRule()
	{
		agSetStepExecutionDelay("3000");
		agClick(FollowUpRulesPageObjects.edit_Icon);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to search Rule.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean searchRule(String scenarioName) {
	Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
	agSetStepExecutionDelay("3000");
	agAssertVisible(FollowUpRulesPageObjects.ruleKeyword_Textbox);
	agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	agSetValue(FollowUpRulesPageObjects.ruleKeyword_Textbox, getTestDataCellValue(scenarioName, "RuleName"));
	agClick(FollowUpRulesPageObjects.rulesearch_Icon);
	CommonOperations.takeScreenShot();
	agSetStepExecutionDelay("5000");
	String paginator = agGetText(FollowUpRulesPageObjects.paginator);
	agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	if (paginator != null && paginator.startsWith("1")) {
		Reports.ExtentReportLog("", Status.PASS,
					"Search Result with '" + getTestDataCellValue(scenarioName, "RuleName") + "' exists!",
					true);
		return true;
	} else {
			return false;
	}
}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to delete new Rule
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :  12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void deleteRuleConditions()
	{
		agSetStepExecutionDelay("3000");
		agClick(FollowUpRulesPageObjects.ruleconditiondel);
		agAssertVisible(FollowUpRulesPageObjects.deletevalidation_popup);
		agClick(FollowUpRulesPageObjects.deleteyesbtn);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	//not completed
	/**********************************************************************************************************
	 * @Objective: The below method is created to delete new Rule
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date :  12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
	public static void deleteQuestionaryConditions()
	{
		agSetStepExecutionDelay("3000");
		agClick(FollowUpRulesPageObjects.questionaryconditiondel);
		agAssertVisible(FollowUpRulesPageObjects.deletevalidation_popup);
		agClick(FollowUpRulesPageObjects.deleteyesbtn);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Basic details of Rule.
	 * @InputParameters: 
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void setRuleBasicDetails(String scenarioName)
	{
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		agSetValue(FollowUpRulesPageObjects.ruleName, getTestDataCellValue(scenarioName, "RuleName"));
		CommonOperations.setListDropDownValue(FollowUpRulesPageObjects.module_Dropdown, getTestDataCellValue(scenarioName, "Module"));
		
		if (!getTestDataCellValue(scenarioName, "Active").equalsIgnoreCase("Check")) {
			CommonOperations.clickCheckBoxLeftOf(FollowUpRulesPageObjects.active, getTestDataCellValue(scenarioName, "Active"));
		}
		
		if (getTestDataCellValue(scenarioName, "BasicRules").equalsIgnoreCase("true")) {
			CommonOperations.clickCheckBoxLeftOf(FollowUpRulesPageObjects.basicRules, getTestDataCellValue(scenarioName, "BasicRules"));
		}
		
		if (getTestDataCellValue(scenarioName, "FormLibrary").equalsIgnoreCase("true")) {
		CommonOperations.clickCheckBoxLeftOf(FollowUpRulesPageObjects.formLibrary, getTestDataCellValue(scenarioName, "FormLibrary"));
		}
		
		if (getTestDataCellValue(scenarioName, "FieldLibrary").equalsIgnoreCase("true")) {
			CommonOperations.clickCheckBoxLeftOf(FollowUpRulesPageObjects.fieldLibrary, getTestDataCellValue(scenarioName, "FieldLibrary"));
			}
			
		
		CommonOperations.clickCheckBoxLeftOf(FollowUpRulesPageObjects.standardRule, getTestDataCellValue(scenarioName, "StandardRule"));	
		CommonOperations.clickCheckBoxLeftOf(FollowUpRulesPageObjects.methodLibrary, getTestDataCellValue(scenarioName, "MethodLibrary"));
		CommonOperations.clickCheckBoxLeftOf(FollowUpRulesPageObjects.criteriaBuilderRules, getTestDataCellValue(scenarioName, "CriteriaBuildRules"));
		CommonOperations.clickCheckBoxLeftOf(FollowUpRulesPageObjects.scriptedRules, getTestDataCellValue(scenarioName, "ScriptedRules"));
		CommonOperations.clickCheckBoxLeftOf(FollowUpRulesPageObjects.displayE2BR2Tag, getTestDataCellValue(scenarioName, "DisplayE2BR2Tag"));
		CommonOperations.clickCheckBoxLeftOf(FollowUpRulesPageObjects.displayE2BR3Tag, getTestDataCellValue(scenarioName, "DisplayE2BR3Tag"));
		CommonOperations.clickCheckBoxLeftOf(FollowUpRulesPageObjects.doNotRegenerateRuleScript, getTestDataCellValue(scenarioName, "DoNotRegenerateRuleScript"));
		CommonOperations.clickCheckBoxLeftOf(FollowUpRulesPageObjects.alwaysExecute, getTestDataCellValue(scenarioName, "AlwaysExceute"));
		agSetValue(FollowUpRulesPageObjects.descriptiontextbox, getTestDataCellValue(scenarioName, "Description"));
		CommonOperations.setListDropDownValue(FollowUpRulesPageObjects.formName_Dropdown, getTestDataCellValue(scenarioName, "FormName"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Basic Details for Rule is entered for Scenario Name:: "+scenarioName, true);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify the Basic details of Rule.
	 * @InputParameters: 
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyRuleBasicDetails(String scenarioName)
	{
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "RuleName"), FollowUpRulesPageObjects.ruleName);
		
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Module"),FollowUpRulesPageObjects.module_Dropdown);
		
		CommonOperations.verifyCheckBoxLeftOf(FollowUpRulesPageObjects.active, getTestDataCellValue(scenarioName, "Active"));
		CommonOperations.verifyCheckBoxLeftOf(FollowUpRulesPageObjects.basicRules, getTestDataCellValue(scenarioName, "BasicRules"));
		CommonOperations.verifyCheckBoxLeftOf(FollowUpRulesPageObjects.formLibrary, getTestDataCellValue(scenarioName, "FormLibrary"));
		CommonOperations.verifyCheckBoxLeftOf(FollowUpRulesPageObjects.standardRule, getTestDataCellValue(scenarioName, "StandardRule"));	
		CommonOperations.verifyCheckBoxLeftOf(FollowUpRulesPageObjects.fieldLibrary, getTestDataCellValue(scenarioName, "FieldLibrary"));	
		CommonOperations.verifyCheckBoxLeftOf(FollowUpRulesPageObjects.methodLibrary, getTestDataCellValue(scenarioName, "MethodLibrary"));
		CommonOperations.verifyCheckBoxLeftOf(FollowUpRulesPageObjects.criteriaBuilderRules, getTestDataCellValue(scenarioName, "CriteriaBuildRules"));
		CommonOperations.verifyCheckBoxLeftOf(FollowUpRulesPageObjects.scriptedRules, getTestDataCellValue(scenarioName, "ScriptedRules"));
		CommonOperations.verifyCheckBoxLeftOf(FollowUpRulesPageObjects.displayE2BR2Tag, getTestDataCellValue(scenarioName, "DisplayE2BR2Tag"));
		CommonOperations.verifyCheckBoxLeftOf(FollowUpRulesPageObjects.displayE2BR3Tag, getTestDataCellValue(scenarioName, "DisplayE2BR3Tag"));
		CommonOperations.verifyCheckBoxLeftOf(FollowUpRulesPageObjects.doNotRegenerateRuleScript, getTestDataCellValue(scenarioName, "DoNotRegenerateRuleScript"));
		CommonOperations.verifyCheckBoxLeftOf(FollowUpRulesPageObjects.alwaysExecute, getTestDataCellValue(scenarioName, "AlwaysExceute"));
		
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Description"), FollowUpRulesPageObjects.descriptiontextbox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "FormName"),FollowUpRulesPageObjects.formName_Dropdown);
		agClick(FollowUpRulesPageObjects.cancelbtn);
	}
	

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Context and Show dropdown
	 *             value in Followup Rules screen
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 08-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setQuestionnarieContext(String scenarioName) 
	{	
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agIsVisible(FollowUpRulesPageObjects.clickDropDown(FollowUpRulesPageObjects.contextdropdown));
		agClick(FollowUpRulesPageObjects.clickDropDown(FollowUpRulesPageObjects.contextdropdown));
		agSetStepExecutionDelay("5000");
		agClick(FollowUpRulesPageObjects.selectDropdown(FollowUpRulesPageObjects.contextdropdown,
				getTestDataCellValue(scenarioName,"Questionnaires_Context")));
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to select field and Show dropdown
	 *             value in Followup Rules screen
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setQuestionnarieField(String scenarioName) 
	{	
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agIsVisible(FollowUpRulesPageObjects.clickDropDown(FollowUpRulesPageObjects.fielddropdown));
		agClick(FollowUpRulesPageObjects.clickDropDown(FollowUpRulesPageObjects.fielddropdown));
		agSetStepExecutionDelay("5000");
		agClick(FollowUpRulesPageObjects.selectDropdown(FollowUpRulesPageObjects.fielddropdown,
				getTestDataCellValue(scenarioName,"Questionnaires_Field")));
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to select Compare values and Show dropdown
	 *             value in Followup Rules screen
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setQuestionnarieCompare(String scenarioName) 
	{	
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agIsVisible(FollowUpRulesPageObjects.clickDropDown(FollowUpRulesPageObjects.comparedropdown));
		agClick(FollowUpRulesPageObjects.clickDropDown(FollowUpRulesPageObjects.comparedropdown));
		agSetStepExecutionDelay("5000");
		agJavaScriptExecuctorClick(FollowUpRulesPageObjects.selectDropdown(FollowUpRulesPageObjects.comparedropdown,
				getTestDataCellValue(scenarioName,"Questionnaires_Compare")));
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to select Question ID from Libraries QuestionLookUp 
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setQuestionID(String scenarioName) 
	{	
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agIsVisible(FollowUpRulesPageObjects.questionId_icon);
		agClick(FollowUpRulesPageObjects.questionId_icon);
		agIsVisible(FollowUpRulesPageObjects.questionnarielookup_label);
		agIsVisible(FollowUpRulesPageObjects.questionName_filter);
		agSetValue(FollowUpRulesPageObjects.questionName_filter,getTestDataCellValue(scenarioName, "Questionnaires_QuestionName"));
		agSetStepExecutionDelay("5000");
		agClick(FollowUpRulesPageObjects.question_checkbox);
		agClick(FollowUpRulesPageObjects.question_OkBtn);
		agAssertVisible(FollowUpRulesPageObjects.addToRuleBtn2);
		agClick(FollowUpRulesPageObjects.addToRuleBtn2);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to set Questionnarie conditions 
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setQuestionnarieDetails(String scenarioName) 
	{
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		//agJavaScriptExecuctorScrollToElement(FollowUpRulesPageObjects.addToRuleBtn2);
		setQuestionnarieContext(scenarioName);
		setQuestionnarieField(scenarioName);
		setQuestionnarieCompare(scenarioName);
		setQuestionID(scenarioName);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Save the Rule.
	 * @InputParameters: 
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void save()
	{
		/*Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");*/
		agClick(FollowUpRulesPageObjects.savebtn);
		/*agIsVisible(FollowUpRulesPageObjects.validationmsg);
		agClick(FollowUpRulesPageObjects.saveokbtn);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));*/
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Rule name exist or not based on Rule name 
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Boolean verifysearchData(String scenarioName) {
		Boolean falg = false;
		String paginator = agGetText(FollowUpRulesPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			List<WebElement> list = agGetElementList(FollowUpRulesPageObjects.get_listofRuleName);
			String columnHeader = null;
			for (int j = 1; j <= list.size(); j++) {
				columnHeader = agGetText(FollowUpRulesPageObjects.columnHeaderList(Integer.toString(j)));
				if (getTestDataCellValue(scenarioName, "RuleName").equalsIgnoreCase(columnHeader)) {
					falg = true;
					break;
				}
			}
		}
		return falg;
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to search Rule .
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 12-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreateRule(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		searchRule(scenarioName);
		if (verifysearchData(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Rule Name already exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "RuleName"),
					FollowUpRulesPageObjects.get_listofRuleName);
		} else {
			createNewRule();
			setRuleBasicDetails(scenarioName);
			verifyRuleBasicDetails(scenarioName);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Search and Update
	 *             >> Rule.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Pooja S
	 * @Date : 13-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndUpdateRule(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		boolean searchResults = searchRule(scenarioName);
		if (searchResults == true) {
			editRule();
			setRuleBasicDetails(scenarioName);
			verifyRuleBasicDetails(scenarioName);
		}
	}
	
	
}
