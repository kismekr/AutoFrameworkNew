package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AppParameters_CaseManagementPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.AppParameters_CentralCodingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.WorkFlowPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AppParameters_CentralCoding extends ToolManager {
	static String className = AppParameters_CentralCoding.class.getSimpleName();

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Central Coding Details in
	 *             Central Coding Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadCentralCodingDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CentralCodingPageObjects.codingMatchOrder_Radio)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CodingMatchOrder",
						"Dictionary Match First");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CodingMatchOrder",
						"VTA Match First");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CentralCodingPageObjects.medDRAHierarchyOfTerm_Radio)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "MedDRAHierarchyOfTerm",
						"Show Entire Hierarchy");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "MedDRAHierarchyOfTerm",
						"Show Only SOC, PT and LLT");
			}

			String MedDRAVersionInUse = agGetText(AppParameters_CentralCodingPageObjects.medDRAVersionInUse_DropDown);

			if (MedDRAVersionInUse.contains("--Select--") || MedDRAVersionInUse.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "MedDRAVersionInUse",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "MedDRAVersionInUse",
						MedDRAVersionInUse);
			}

			String WHODDVersionInUse = agGetText(AppParameters_CentralCodingPageObjects.whoDDVersionInUse_DropDown);
			if (WHODDVersionInUse.contains("--Select--") || WHODDVersionInUse.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "WHODDVersionInUse",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "WHODDVersionInUse",
						WHODDVersionInUse);
			}
			String SNOMEDCTVersionInUse = agGetText(
					AppParameters_CentralCodingPageObjects.snomedCTVersionInUse_DropDown);
			if (SNOMEDCTVersionInUse.contains("--Select--") || SNOMEDCTVersionInUse.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SNOMEDCTVersionInUse",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SNOMEDCTVersionInUse",
						SNOMEDCTVersionInUse);
			}

			String LOINCVersionInUse = agGetText(AppParameters_CentralCodingPageObjects.loincVersionInUse_DropDown);
			if (LOINCVersionInUse.contains("--Select--") || LOINCVersionInUse.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LOINCVersionInUse",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LOINCVersionInUse",
						LOINCVersionInUse);
			}
			String KoreanDDVersionInUse = agGetText(
					AppParameters_CentralCodingPageObjects.koreanDDVersionInUse_DropDown);
			if (KoreanDDVersionInUse.contains("--Select--") || KoreanDDVersionInUse.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "KoreanDDVersionInUse",
						"#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "KoreanDDVersionInUse",
						KoreanDDVersionInUse);
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBoxYes(
					AppParameters_CentralCodingPageObjects.enableAdvancedSearchOptions_Radio)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EnableAdvancedSearchOptions", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EnableAdvancedSearchOptions", "No");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBoxYes(
					AppParameters_CentralCodingPageObjects.enableTermTypeBasedMedDRACoding_Radio)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EnableTermTypeBasedMedDRACoding", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EnableTermTypeBasedMedDRACoding", "No");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBoxYes(
					AppParameters_CentralCodingPageObjects.enableCentralCodingInbox_Radio)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EnableCentralCodingInbox", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EnableCentralCodingInbox", "No");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CentralCodingPageObjects.event_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Event", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Event", "false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CentralCodingPageObjects.indication_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Indication", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Indication", "false");
			}
			if (agIsVisible(
					WorkFlowPageObjects.CheckedCheckBox(AppParameters_CentralCodingPageObjects.lab_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Lab", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Lab", "false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CentralCodingPageObjects.disease_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Disease", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Disease", "false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CentralCodingPageObjects.senderDiagnosis_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SenderDiagnosis",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SenderDiagnosis",
						"false");
			}

			String NumberOfVTAReviewsRequired = agGetText(
					AppParameters_CentralCodingPageObjects.numberOfVTAReviewsRequired_DropDown);
			if (NumberOfVTAReviewsRequired.contains("--Select--") || NumberOfVTAReviewsRequired.contains("Select")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"NumberOfVTAReviewsRequired", "#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"NumberOfVTAReviewsRequired", NumberOfVTAReviewsRequired);
			}
			agClick(AppParameters_CentralCodingPageObjects.advancedSynonymsThesaurusName_TextBox);
			String AdvancedSynonymsThesaurusName = agGetAttribute("value",
					AppParameters_CentralCodingPageObjects.advancedSynonymsThesaurusName_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"AdvancedSynonymsThesaurusName", AdvancedSynonymsThesaurusName);

			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Central Coding >> Central Coding Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Central Coding Details in
	 *             Central Coding Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 17-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setCentralCodingDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			CommonPageObjects.selectRadioButtonLatest(AppParameters_CentralCodingPageObjects.codingMatchOrder_Radio,
					getTestDataCellValue(scenarioName, "CodingMatchOrder"));
			CommonPageObjects.selectRadioButtonLatest(
					AppParameters_CentralCodingPageObjects.medDRAHierarchyOfTerm_Radio,
					getTestDataCellValue(scenarioName, "MedDRAHierarchyOfTerm"));
			CommonOperations.setListDropDownValue(AppParameters_CentralCodingPageObjects.medDRAVersionInUse_DropDown,
					getTestDataCellValue(scenarioName, "MedDRAVersionInUse"));
			CommonOperations.setListDropDownValue(AppParameters_CentralCodingPageObjects.whoDDVersionInUse_DropDown,
					getTestDataCellValue(scenarioName, "WHODDVersionInUse"));
			CommonOperations.setListDropDownValue(AppParameters_CentralCodingPageObjects.snomedCTVersionInUse_DropDown,
					getTestDataCellValue(scenarioName, "SNOMEDCTVersionInUse"));
			CommonOperations.setListDropDownValue(AppParameters_CentralCodingPageObjects.loincVersionInUse_DropDown,
					getTestDataCellValue(scenarioName, "LOINCVersionInUse"));
			CommonOperations.setListDropDownValue(AppParameters_CentralCodingPageObjects.koreanDDVersionInUse_DropDown,
					getTestDataCellValue(scenarioName, "KoreanDDVersionInUse"));
			CommonPageObjects.selectRadioButtonLatest(
					AppParameters_CentralCodingPageObjects.enableAdvancedSearchOptions_Radio,
					getTestDataCellValue(scenarioName, "EnableAdvancedSearchOptions"));
			CommonPageObjects.selectRadioButtonLatest(
					AppParameters_CentralCodingPageObjects.enableTermTypeBasedMedDRACoding_Radio,
					getTestDataCellValue(scenarioName, "EnableTermTypeBasedMedDRACoding"));
			CommonPageObjects.selectRadioButtonLatest(
					AppParameters_CentralCodingPageObjects.enableCentralCodingInbox_Radio,
					getTestDataCellValue(scenarioName, "EnableCentralCodingInbox"));
			
			
			if(getTestDataCellValue(scenarioName, "Event").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CentralCodingPageObjects.event_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CentralCodingPageObjects.event_CheckBox,
								getTestDataCellValue(scenarioName, "Event"));
				}
			}

			if(getTestDataCellValue(scenarioName, "Indication").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CentralCodingPageObjects.indication_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CentralCodingPageObjects.indication_CheckBox,
								getTestDataCellValue(scenarioName, "Indication"));
				}
			}
			if(getTestDataCellValue(scenarioName, "Lab").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CentralCodingPageObjects.lab_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CentralCodingPageObjects.lab_CheckBox,
								getTestDataCellValue(scenarioName, "Lab"));
				}
			}

			if(getTestDataCellValue(scenarioName, "Disease").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CentralCodingPageObjects.disease_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CentralCodingPageObjects.disease_CheckBox,
								getTestDataCellValue(scenarioName, "Disease"));
				}
			}
			if(getTestDataCellValue(scenarioName, "SenderDiagnosis").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CentralCodingPageObjects.senderDiagnosis_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_CentralCodingPageObjects.senderDiagnosis_CheckBox,
								getTestDataCellValue(scenarioName, "SenderDiagnosis"));
				}
			}

			CommonOperations.setListDropDownValue(
					AppParameters_CentralCodingPageObjects.numberOfVTAReviewsRequired_DropDown,
					getTestDataCellValue(scenarioName, "NumberOfVTAReviewsRequired"));
			agSetValue(AppParameters_CentralCodingPageObjects.advancedSynonymsThesaurusName_TextBox,
					getTestDataCellValue(scenarioName, "AdvancedSynonymsThesaurusName"));

			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Central Coding >> Central Coding Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set data in Central Coding Tab
	 *             under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 17-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setAppParameters_CentralCodingTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >> Central Coding Tab Started",
				true);
		setCentralCodingDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Application Parameters >> Central Coding Tab Completed", true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read data in Central Coding Tab
	 *             under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadAppParameters_CentralCodingTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO,
				"Read Data Entered in Application Parameters >> Central Coding Tab Started", true);
		ReadCentralCodingDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO,
				"Read Data Entered in Application Parameters >> Central Coding Tab Completed", true);
	}
}
