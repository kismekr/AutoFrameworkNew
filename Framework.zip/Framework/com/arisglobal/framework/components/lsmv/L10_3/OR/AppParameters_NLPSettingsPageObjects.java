package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class AppParameters_NLPSettingsPageObjects {

	////////// Administration >> System Administration >> Application Parameters >> NLP Settings ///////////////////////////

	public static String  nlpConfigurationPath_TextBox = "xpath#//input[@id ='applicationParameterForm:nlpConfigPath']";
	public static String defaultCompanyProduct_DropDown = "xpath#//div[@id='applicationParameterForm:suspectComanyUnits2']";

}
