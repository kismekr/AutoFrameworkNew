package com.arisglobal.framework.components.lsmv.L10_3;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.ActivityLogPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDEMoreOptionsPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class ActivityLogOperations extends ToolManager {

	static String className = ActivityLogOperations.class.getSimpleName();
	public static WebElement webElement;
	static boolean status;
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to activity log verification
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash
	 * @Date : 24-Sep-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void activityLogVerification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(FDEMoreOptionsPageObjects.moreOptionsHover);
		agClick(FDEMoreOptionsPageObjects.moreOptions(ActivityLogPageObjects.activityLog_Link));
         agSetStepExecutionDelay("3000");
         String message=agGetText(ActivityLogPageObjects.activityLog_header);
 		status = agIsVisible(ActivityLogPageObjects.activityLog_header);
 		if (status) {
 			Reports.ExtentReportLog("", Status.PASS, "Header:"+message, true);
 			agAssertVisible(ActivityLogPageObjects.data_Verification(getTestDataCellValue(scenarioName, "Data")));
 			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
 		} else {
 			Reports.ExtentReportLog("", Status.FAIL, "Activity Log window is not displayed", true);

 		}
		//agAssertContainsText(ActivityLogPageObjects.activityLog_header, E2BMessageQueueOperations.getData(scenarioName, "ReceiptNo"));
		agClick(ActivityLogPageObjects.close_btn);
	}
	
	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	
    public static String getData(String scenarioName, String columnName) {
        Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
        return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
    }
    
}
