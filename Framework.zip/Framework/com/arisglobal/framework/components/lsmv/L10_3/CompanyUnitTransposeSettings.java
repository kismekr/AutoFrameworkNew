package com.arisglobal.framework.components.lsmv.L10_3;

//import org.apache.poi.util.SystemOutLogger;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AdministrationCompanyUnitPageObjects;
//import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;
 
public class CompanyUnitTransposeSettings extends ToolManager {
	static String className = CompanyUnitTransposeSettings.class.getSimpleName();
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to search Company Unit Transport Records.
	 * @InputParameters: Scenario Name
	 * @OutputParameters: Boolean
	 * @author: MP Ramkumar
	 * @return 
	 * @Date : 30-Jan-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Boolean searchCompanyUnitVerifyTransportSettings(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(AdministrationCompanyUnitPageObjects.transportSettingsLink);
		agClick(AdministrationCompanyUnitPageObjects.edittransposesettingscu);
		Boolean searchtxtcheck = agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "SearchText"),
				AdministrationCompanyUnitPageObjects.transportNameTextbox);
		Boolean searchemailid = agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ToEmailID"), 
				AdministrationCompanyUnitPageObjects.transportemailid);
//		Boolean searchmedium = agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Medium"),
//				AdministrationCompanyUnitPageObjects.transportmediumDropdown);

		Boolean outcome = false;
		if((searchtxtcheck && searchemailid)) { //&& searchmedium)) {
			Reports.ExtentReportLog("CompanyUnitTransposeSettings", Status.PASS, "Company Unit Transport Data Verification Successfull", true);
		} else
			Reports.ExtentReportLog("CompanyUnitTransposeSettings", Status.FAIL, "Company Unit Transport Data Verification Unsuccessfull", true);
		return outcome;
 }
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Company Unit Transport Settings Records data.
	 * @InputParameters: Scenario Name
	 * @OutputParameters: Boolean
	 * @author: MP Ramkumar
	 * @return 
	 * @Date : 30-Jan-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCompanyUnitEditTransportSettings(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(AdministrationCompanyUnitPageObjects.transportSettingsLink);
		agClick(AdministrationCompanyUnitPageObjects.edittransposesettingscu);
		agSetValue(AdministrationCompanyUnitPageObjects.transportemailid, 
				getTestDataCellValue(scenarioName, "ToEmailID"));
		agClick(AdministrationCompanyUnitPageObjects.saveButton);
		CommonOperations.setAuditInfo("Update_CompanyUnit");
		
 }	
	
	
	
	
}



