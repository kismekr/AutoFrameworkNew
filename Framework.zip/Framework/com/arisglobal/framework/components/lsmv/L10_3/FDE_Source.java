package com.arisglobal.framework.components.lsmv.L10_3;

import org.openqa.selenium.Keys;

import com.arisglobal.framework.components.lsmv.L10_1.CommonOperations;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_SourcePageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_Source extends ToolManager

{
	static String className = FDE_Source.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: The below method is created to get the length of data in row
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 02-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static int getLength(String scenarioName, String columnName, String className) {
		String excelData = getTestDataCellValue(scenarioName, columnName);
		String[] data = excelData.split("::");
		System.out.print("Length::" + data.length);
		return data.length;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Source tab details
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 26-Nov-2019
	 * @UpdatedByAndWhen: Avinash K on 24-Aug-2020
	 **********************************************************************************************************/
	public static void setSourceDetails(String scenarioName) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,
		// "ConfigurationSettings");
		// if (getTestDataCellValue(scenarioName, "FDE_Source").equalsIgnoreCase("Yes"))
		// {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		Multimaplibraries.getTestDataCellLength(scenarioName, "Source_Source");

		for (int j = 1; j <= Constants.testDataParentLength; j++) {
			Constants.testDataChildLoopCount = j;

			if (j > 1) {
				agClick(FDE_SourcePageObjects.addButton);
				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			if (getTestDataCellValue(scenarioName, "Source_PrimarySource").equalsIgnoreCase("Check")) {
				CommonOperations.clickCheckBoxUnder(FDE_SourcePageObjects.primarySourceCheckLabel, "true");
			}
			CommonOperations.setFDEDropDownValue(FDE_SourcePageObjects.sourceDropdown,
					getTestDataCellValue(scenarioName, "Source_Source"));
			agSetValue(FDE_SourcePageObjects.dateReceivedTextBox,
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Source_DateReceived")));

			if (getTestDataCellValue(scenarioName, "Source_SenderOrganizationCoded").equalsIgnoreCase("Yes")) {
				setSenderOrgLookUpDetails(scenarioName);
			}
			CommonOperations.setFDEDropDownValue(FDE_SourcePageObjects.referenceTypeDropdown,
					getTestDataCellValue(scenarioName, "Source_ReferenceType"));
			agSetValue(FDE_SourcePageObjects.ReferenceNumberTextBox,
					getTestDataCellValue(scenarioName, "Source_ReferenceNumber"));
			agSendKeyStroke(Keys.TAB);
			agSetValue(FDE_SourcePageObjects.DescriptionTextBox,
					getTestDataCellValue(scenarioName, "Source_Description"));

			// Commenting as it is adding another source
			// agClick(FDE_SourcePageObjects.buttonLabel("Add"));
			agSetStepExecutionDelay("3000");

			Reports.ExtentReportLog("", Status.INFO,
					"~~~~~~~~~~~~~~~~~~~Data Entered in Source_00" + j + "~~~~~~~~~~~~~~~~~~", true);
		}
		// }
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Sender Organization look up
	 *             details.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 26-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSenderOrgLookUpDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_SourcePageObjects.senderOrganizationLookUpIcon);

		if (getTestDataCellValue(scenarioName, "Source_Sender_Account").equalsIgnoreCase("Yes")) {
			agClick(FDE_SourcePageObjects.senderRadiobtn);
			agSetStepExecutionDelay("2000");
			agSetValue(FDE_SourcePageObjects.accountNameTextBox,
					getTestDataCellValue(scenarioName, "Source_SenderAccountName"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agClick(FDE_SourcePageObjects.searchSenderButton);
			agSetStepExecutionDelay("2000");
			agClick(FDE_SourcePageObjects.selectBySenderRecRadioBtn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agClick(FDE_SourcePageObjects.senderOkBtn);
		} else {
			agClick(FDE_SourcePageObjects.companyUnitRadiobtn);
			agSetStepExecutionDelay("2000");
			agSetValue(FDE_SourcePageObjects.companyUnitNameTextBox,
					getTestDataCellValue(scenarioName, "Source_SenderCompanyUnitName"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agClick(FDE_SourcePageObjects.searchSenderButton);
			agSetStepExecutionDelay("2000");
			agClick(FDE_SourcePageObjects.selectByCompanyUnitRecRadioBtn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agClick(FDE_SourcePageObjects.senderOkBtn);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Source data entered.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 27-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySourceDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Multimaplibraries.getTestDataCellLength(scenarioName, "Source_Source");

		for (int j = 1; j <= Constants.testDataParentLength; j++) {
			Constants.testDataChildLoopCount = j;

			if (j >= 1) {
				if (!agIsVisible(FDE_SourcePageObjects.clickMultipleSource(Integer.toString(j)))) {
					agJavaScriptExecuctorClick(FDE_SourcePageObjects.navigaterClick);
				}

				agClick(FDE_SourcePageObjects.clickMultipleSource(Integer.toString(j)));

				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			agCheckPropertyText(getTestDataCellValue(scenarioName, "Source_ReferenceType"),
					FDE_SourcePageObjects.sourceRefTypeDropdownSelect);

			if (getTestDataCellValue(scenarioName, "Source_PrimarySource").equalsIgnoreCase("Check")) {
				CommonOperations.verifyCheckBoxUnder(FDE_SourcePageObjects.primarySourceCheckLabel, "Yes");
			}
			agClick(FDE_SourcePageObjects.dateRecevied);
			agCheckPropertyValue("title",
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Source_DateReceived")),
					FDE_SourcePageObjects.dateRecevied);
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Source_ReferenceNumber"),
					FDE_SourcePageObjects.ReferenceNumberTextBox);
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Source_Description"),
					FDE_SourcePageObjects.DescriptionTextBox);

			agCheckPropertyText(getTestDataCellValue(scenarioName, "Source_Source"),
					FDE_SourcePageObjects.sourceDropdownSelect);

			Reports.ExtentReportLog("", Status.INFO,
					"~~~~~~~~~~~~~~~~~~~Data Verified in Source_00" + j + "~~~~~~~~~~~~~~~~~~", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: Verify Codelist tags in Source tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 18-NOv-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySourceCodeList() {
		System.out.println("********Source Codelist verification Started*******");
		agAssertVisible(FDE_SourcePageObjects.CLPrimarySource);
		agAssertVisible(FDE_SourcePageObjects.CLSource);
		agAssertVisible(FDE_SourcePageObjects.CLReferenceType);
		System.out.println("********Source Codelist verification Completed*******");
	}

	/**********************************************************************************************************
	 * @Objective: The below method is Enhanced to handle adding multiple Source
	 *             records
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:MP Ramkumar
	 * @Date : 29-Feb-2020
	 * @UpdatedByAndWhen: start
	 **********************************/
	public static void setSourceData(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// scenarioName = scenarioName + String.valueOf(scenarioCounterStarting); //
		// This is to handle the scenario when already a record exists in the case.
		if (!getTestDataCellValue(scenarioName, "ApplicableForThisTenant").equalsIgnoreCase("false")) {
			int i = 1;
			do {
				if (getTestDataCellValue(scenarioName, "Source_MultipleData").equalsIgnoreCase("true")) {
					agClick(FDE_SourcePageObjects.buttonLabel("Add"));
				}
				if (getTestDataCellValue(scenarioName, "Source_PrimarySource").equalsIgnoreCase("Check")) {
					CommonOperations.clickCheckBoxUnder(FDE_SourcePageObjects.primarySourceCheckLabel, "true");
				}

				if (getTestDataCellValue(scenarioName, "Source_SenderOrganizationCoded").equalsIgnoreCase("Yes")) {
					setSenderOrgLookUpDetails(scenarioName);
				} else {
					agSetValue(FDE_SourcePageObjects.senderOrganizationTextBox,
							getTestDataCellValue(scenarioName, "Source_SenderOrganization"));
				}
				agSetValue(FDE_SourcePageObjects.dateReceivedTextBox,
						CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Source_DateReceived")));
				agSetValue(FDE_SourcePageObjects.ReferenceNumberTextBox,
						getTestDataCellValue(scenarioName, "Source_ReferenceNumber"));
				agSetValue(FDE_SourcePageObjects.DescriptionTextBox,
						getTestDataCellValue(scenarioName, "Source_Description"));

				CommonOperations.setFDEDropDownValue(FDE_SourcePageObjects.sourceDropdown,
						getTestDataCellValue(scenarioName, "Source_Source"));
				CommonOperations.setFDEDropDownValue(FDE_SourcePageObjects.referenceTypeDropdown,
						getTestDataCellValue(scenarioName, "Source_ReferenceType"));

				Reports.ExtentReportLog("", Status.INFO, "Data entered in source tab: Scenario Name::" + scenarioName,
						true);
				if (getTestDataCellValue(scenarioName, "Source_MultipleData").equalsIgnoreCase("true")) {
					i = i++;
					scenarioName = scenarioName + "_" + String.valueOf(i);
				} else
					break;
			} while (getTestDataCellValue(scenarioName, "Source_MultipleData").equalsIgnoreCase("true"));
		}
	}
}
