package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AdministrationDepartmentPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.GlossaryOfTermsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.PharmacologicalClassPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Libraries_GlossaryOfTerms extends ToolManager {

	static String className = Libraries_GlossaryOfTerms.class.getSimpleName();

	/********************************************************************************************************
	 * @Objective: The below method is created to search Glossary Term.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 24-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static boolean searchGlossaryTerm(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agSetValue(GlossaryOfTermsPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, "Term"));
		agClick(GlossaryOfTermsPageObjects.keywordSearchLookUp);
		agSetStepExecutionDelay("2000");
		String paginator = agGetText(AdministrationDepartmentPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.PASS, "Searched Term  exists", true);
			return true;
		} else
			return false;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create a new Glossary Term.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 25-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createNewGlossaryTerm(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agClick(GlossaryOfTermsPageObjects.newButton);
		agIsVisible(GlossaryOfTermsPageObjects.termTextbox);
		agSetValue(GlossaryOfTermsPageObjects.termTextbox, getTestDataCellValue(scenarioName, "Term"));
		agSetValue(GlossaryOfTermsPageObjects.descriptionTextArea, getTestDataCellValue(scenarioName, "Description"));
		agClick(GlossaryOfTermsPageObjects.saveButton);
		CommonOperations.setAuditInfo("CreateGlossaryTerm");
		// if (agIsVisible(GlossaryOfTermsPageObjects.successfulLabel)) {
		// agAssertContainsText(GlossaryOfTermsPageObjects.successfulMsg,
		// getTestDataCellValue(scenarioName, "SaveMessage"));
		// Reports.ExtentReportLog("Term Creation", Status.PASS, "Glossary Term Creation
		// Successful", true);
		// } else {
		// Reports.ExtentReportLog("Term Creation", Status.FAIL, "Glossary Term Creation
		// Unsuccessful", true);
		// }

		// agClick(GlossaryOfTermsPageObjects.validationOk_Btn);
		boolean res = searchGlossaryTerm(scenarioName);

		if (res == true) {
			Reports.ExtentReportLog("Term Search", Status.PASS, "Glossary Term Listed", true);
		} else {
			Reports.ExtentReportLog("Term Search", Status.FAIL, "Glossary Term Not Listed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete an existing Glossary Term.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteGlossaryTerm(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agClick(GlossaryOfTermsPageObjects.selectRec);
		agClick(GlossaryOfTermsPageObjects.deleteButton);
		agSetStepExecutionDelay("5000");
		agClick(GlossaryOfTermsPageObjects.deleteYes_Button);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.verifyMessage(scenarioName);
		CommonOperations.agClick(CommonPageObjects.validaionOk_Btn);
		//CommonOperations.takeScreenShot();
		//CommonOperations.setDeleteAuditInfo("DeleteGlossaryTerm");
		// if(status == true)
		// {
		//
		// //agAssertContainsText(GlossaryOfTermsPageObjects.successfulMsg,
		// getTestDataCellValue(scenarioName, "DeleteMessage"));
		// //agClick(GlossaryOfTermsPageObjects.validationOk_Btn);
		// Reports.ExtentReportLog("Delete Term", Status.PASS, "Delete Glossary Term
		// Successful", true);
		// }
		// else {
		// Reports.ExtentReportLog("Delete Term", Status.FAIL, "Delete Glossary Term
		// Unsuccessful", true);
		// }
		//
		boolean res = searchGlossaryTerm(scenarioName);

		if (res == true) {
			Reports.ExtentReportLog("Term Search", Status.FAIL, "Glossary Term Not Deleted", true);
		} else {
			Reports.ExtentReportLog("Term Search", Status.PASS, "Glossary Term Deleted", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to update an existing Glossary Term.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateGlossaryTerm(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(GlossaryOfTermsPageObjects.editIcon);
		agClearText(GlossaryOfTermsPageObjects.descriptionTextArea);
		agSetValue(GlossaryOfTermsPageObjects.descriptionTextArea, getTestDataCellValue(scenarioName, "Description"));
		CommonOperations.takeScreenShot();
		agClick(GlossaryOfTermsPageObjects.saveButton);
		CommonOperations.setAuditInfo("UpdateGlossaryTerm");
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download GlossaryTerm List to
	 *             excel.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 18-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportToexcel(String FileName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(GlossaryOfTermsPageObjects.downloadGlossaryListIcon);
		agSetStepExecutionDelay("3000");
		agClick(GlossaryOfTermsPageObjects.exportGlossaryList_link);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agWaitTillVisibilityOfElement(GlossaryOfTermsPageObjects.export_Btn);
		if (agIsVisible(GlossaryOfTermsPageObjects.export_Btn) == true) {
			agClick(GlossaryOfTermsPageObjects.export_Btn);
			try {
				Thread.sleep(8000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			CommonOperations.move_Downloadedexcel(FileName);
			agClick(GlossaryOfTermsPageObjects.cancelExport_Btn);
		} else {
			Reports.ExtentReportLog("Export to excel pop is not displayed", Status.INFO, "", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to check if the searched record
	 *             exists.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 5-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean recordExists() {
		boolean searchResult = agIsVisible(GlossaryOfTermsPageObjects.editIcon);
		if (searchResult == true) {
			Reports.ExtentReportLog("", Status.PASS, "Record Exists!", true);
			return searchResult;
		} else {
			return searchResult;
		}
	}

}
