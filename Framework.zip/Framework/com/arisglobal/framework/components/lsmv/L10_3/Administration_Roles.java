package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.RolespageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Administration_Roles extends ToolManager {
	public static String className =  Administration_Roles.class.getSimpleName();
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to search Role.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 13-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean searchRole(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.agwaitTillVisible(RolespageObjects.keywordSearchBtn, 1, 1000);
		agAssertVisible(RolespageObjects.keywordSearchBtn);
		agSetValue(RolespageObjects.keywordSearchBtn, getTestDataCellValue(scenarioName, "RoleName"));
		agClick(RolespageObjects.keywordSearchIcon);
		agSetStepExecutionDelay("5000");
		String paginator = agGetText(RolespageObjects.paginator);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.PASS,
						"Search Result with '" + getTestDataCellValue(scenarioName, "RoleName") + "' exists!",
						true);
			return true;
		} else {
				return false;
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Edit Role
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date :13-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void editRole() {
		agClick(RolespageObjects.editIcon);
		agAssertVisible(RolespageObjects.descriptionTextarea);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to Copy Role
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date :13-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void copyRole(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(RolespageObjects.keywordSearchBtn, getTestDataCellValue(scenarioName, "RoleCopy"));
		agClick(RolespageObjects.keywordSearchIcon);
		agSetStepExecutionDelay("5000");
		agClick(CommonPageObjects.selectListingCheckbox(getTestDataCellValue(scenarioName, "RoleCopy")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.takeScreenShot();
		agClick(RolespageObjects.copyBtn);
		CommonOperations.agwaitTillVisible(RolespageObjects.newRoleName_Textbox, 1, 1000);
		agSetValue(RolespageObjects.newRoleName_Textbox, getTestDataCellValue(scenarioName, "RoleName"));
		agSetValue(RolespageObjects.description_Textbox, getTestDataCellValue(scenarioName, "Description"));
		CommonOperations.takeScreenShot();
		agClick(RolespageObjects.copy_Button);
		CommonOperations.setAuditInfo("Role_Copy");
	}
	
	
	
  public static void createNewRole(String scenarioName)  {
	  Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
	  
	  agSetValue(RolespageObjects.RoleNameTextbox , getTestDataCellValue(scenarioName, "RoleName"));
	  agSetValue(RolespageObjects.descriptionTextarea , getTestDataCellValue(scenarioName, "Description"));

  }
}
