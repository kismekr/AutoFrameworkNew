package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AdministrationAnnouncementPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.GroupLookUpPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.UserLookUpPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AdministrationAnnouncement extends ToolManager {
	static String className = AdministrationAnnouncement.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Announcement.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 24-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAnnouncement(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.agwaitTillVisible(AdministrationAnnouncementPageObjects.searchTextbox, 1, 1000);
		agSetStepExecutionDelay("5000");
		agAssertVisible(AdministrationAnnouncementPageObjects.searchTextbox);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(AdministrationAnnouncementPageObjects.searchTextbox,
				getTestDataCellValue(scenarioName, "Search Text"));
		agClick(AdministrationAnnouncementPageObjects.searchIcon);
		agSetStepExecutionDelay("5000");
		String paginator = agGetText(AdministrationAnnouncementPageObjects.paginator);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.PASS,
					"Search Result with '" + getTestDataCellValue(scenarioName, "Search Text") + "' exists!", true);
		}

		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to check Record Exists.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 24-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static boolean checkRecordExists(String scenarioName) {
		boolean searchResults = false;
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		String paginator = agGetText(AdministrationAnnouncementPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			agAssertVisible(AdministrationAnnouncementPageObjects
					.searchResult(getTestDataCellValue(scenarioName, "Search Text")));
			boolean searchResult = agIsVisible(AdministrationAnnouncementPageObjects
					.searchResult(getTestDataCellValue(scenarioName, "Search Text")));
			if (searchResult == true) {
				Reports.ExtentReportLog("", Status.PASS,
						"Announcement : " + getTestDataCellValue(scenarioName, "Search Text") + " Already Exists!",
						true);
				return searchResults = true;
			}
		} else {
			return searchResults = false;
		}
		return searchResults;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit Announcement.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 30-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void editAnnouncement() {
		agClick(AdministrationAnnouncementPageObjects.edit_Icon);
		agAssertVisible(AdministrationAnnouncementPageObjects.subjectTextBox);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Announcement Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 24-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setAnnouncementDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(AdministrationAnnouncementPageObjects.subjectTextBox);
		agSetValue(AdministrationAnnouncementPageObjects.subjectTextBox, getTestDataCellValue(scenarioName, "Subject"));
		if (!getTestDataCellValue(scenarioName, "UploadFileName").equalsIgnoreCase("#skip#")) {
			agSetValue(AdministrationAnnouncementPageObjects.sourceDocButton,
					lsmvConstants.LSMV_testDataInput + getTestDataCellValue(scenarioName, "UploadFileName"));
		}
		System.out.println(CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Expiry Date")));
		setDateCalender(CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "Expiry Date")));
		agSetValue(AdministrationAnnouncementPageObjects.messageTextArea,
				getTestDataCellValue(scenarioName, "Message"));
		CommonOperations.clickCheckBoxRightOf(AdministrationAnnouncementPageObjects.publicCheckBoxLabel,
				getTestDataCellValue(scenarioName, "Public"));

		String publicCheckbox = getTestDataCellValue(scenarioName, "Public");
		if (publicCheckbox.equalsIgnoreCase("false")) {
			agClick(AdministrationAnnouncementPageObjects
					.assignToRadioBtn(getTestDataCellValue(scenarioName, "Assign To")));
			agClick(AdministrationAnnouncementPageObjects.addButton);
			if (getTestDataCellValue(scenarioName, "Assign To").equalsIgnoreCase("Group")) {
				agIsVisible(GroupLookUpPageObjects.keywordTextBox);
				agSetValue(GroupLookUpPageObjects.keywordTextBox,
						getTestDataCellValue(scenarioName, "User Group Search"));
				agClick(GroupLookUpPageObjects.searchButton);
				agIsVisible(GroupLookUpPageObjects
						.selectGroupData(getTestDataCellValue(scenarioName, "User Group Search")));
				agClick(GroupLookUpPageObjects
						.selectGroupData(getTestDataCellValue(scenarioName, "User Group Search")));
				agClick(GroupLookUpPageObjects.okButton);
			}
			if (getTestDataCellValue(scenarioName, "Assign To").equalsIgnoreCase("User")) {
				agIsVisible(UserLookUpPageObjects.userNameTextBox);
				agSetValue(UserLookUpPageObjects.userNameTextBox, getTestDataCellValue(scenarioName, "User Name"));
				agSetValue(UserLookUpPageObjects.firstNameTextBox, getTestDataCellValue(scenarioName, "First Name"));
				agSetValue(UserLookUpPageObjects.lastNameTextBox, getTestDataCellValue(scenarioName, "Last Name"));
				agSetValue(UserLookUpPageObjects.emailIdTextBox, getTestDataCellValue(scenarioName, "Email ID"));
				agClick(UserLookUpPageObjects.searchButton);
				agIsVisible(
						UserLookUpPageObjects.selectUserData(getTestDataCellValue(scenarioName, "User Select Data")));
				agClick(UserLookUpPageObjects.selectUserData(getTestDataCellValue(scenarioName, "User Select Data")));
				agClick(UserLookUpPageObjects.okButton);
			}
		}
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Announcement Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 30-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyAnnouncementDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Subject"),
				AdministrationAnnouncementPageObjects.subjectTextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Message"),
				AdministrationAnnouncementPageObjects.messageTextArea);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "UploadFileName"),
				AdministrationAnnouncementPageObjects.sourceDocLink);
		CommonOperations.verifyCheckBoxRightOf(AdministrationAnnouncementPageObjects.publicCheckBoxLabel,
				getTestDataCellValue(scenarioName, "Public"));

		CommonOperations.takeScreenShot();

		agClick(AdministrationAnnouncementPageObjects.cancelButton);
		agIsVisible(AdministrationAnnouncementPageObjects.newButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete Announcement.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 30-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void deleteAnnouncement(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		searchAnnouncement(scenarioName);
		boolean searchResult = agIsVisible(
				AdministrationAnnouncementPageObjects.searchResult(getTestDataCellValue(scenarioName, "Search Text")));
		if (searchResult == true) {
			agClick(AdministrationAnnouncementPageObjects
					.selectListingCheckbox(getTestDataCellValue(scenarioName, "Search Text")));
			agIsSelected(AdministrationAnnouncementPageObjects
					.selectListingCheckbox(getTestDataCellValue(scenarioName, "Search Text")));
			agSetStepExecutionDelay("5000");
			
			Reports.ExtentReportLog("", Status.PASS, "Announcement Details to be deleted", true);
			agClick(AdministrationAnnouncementPageObjects.deleteButton);
			
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CommonOperations.setDeleteAuditInfo(scenarioName);

			searchAnnouncement(scenarioName);

			String paginator = agGetText(AdministrationAnnouncementPageObjects.paginator);
			if (paginator != null && paginator.startsWith("1")) {
				Reports.ExtentReportLog("", Status.FAIL,
						"Search for Deleted Announcement : Deleted Announcement is listed", true);
			} else {

				Reports.ExtentReportLog("", Status.PASS,
						"Search for Deleted Announcement : Deleted Announcement is not listed", true);
			}

			/*
			 * boolean delSearchResult = agIsVisible(AdministrationAnnouncementPageObjects
			 * .searchResult(getTestDataCellValue(scenarioName, "Search Text"))); if
			 * (delSearchResult == true) { Reports.ExtentReportLog("", Status.FAIL,
			 * "Search for Deleted Announcement : Deleted Announcement is listed", true); }
			 * else { Reports.ExtentReportLog("", Status.PASS,
			 * "Search for Deleted Announcement : Deleted Announcement is not listed",
			 * true); }
			 */
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create new Announcement.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 30-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createAnnouncement(String scenarioName) {
		agClick(AdministrationAnnouncementPageObjects.newButton);
		setAnnouncementDetails(scenarioName);
		agClick(AdministrationAnnouncementPageObjects.saveButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to update existing Announcement.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 30-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateAnnouncement(String scenarioName) {
		searchAnnouncement(scenarioName);
		editAnnouncement();
		setAnnouncementDetails(scenarioName);
		agClick(AdministrationAnnouncementPageObjects.saveButton);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Announcement.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 30-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyAnnouncement(String scenarioName) {
		searchAnnouncement(scenarioName);
		editAnnouncement();
		verifyAnnouncementDetails(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Export Operations on
	 *             Announcement Listing Screen data.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportAnnouncementData(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(AdministrationAnnouncementPageObjects.downloadIcon);
		agClick(AdministrationAnnouncementPageObjects
				.selectExportType(getTestDataCellValue(scenarioName, "ExportType")));
		if (agIsVisible(AdministrationAnnouncementPageObjects.export_Btn) == true) {
			agJavaScriptExecuctorClick(AdministrationAnnouncementPageObjects.export_Btn);
			CommonOperations.save_GeneratedReport(getTestDataCellValue(scenarioName, "GeneratedFileName"));
			agClick(AdministrationAnnouncementPageObjects.exportCancel_Btn);
		} else {
			Reports.ExtentReportLog("Export Pop up is not displayed", Status.INFO, "", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to compare record count in listing
	 *             screen with download excel
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void recordCountVerification(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		String count = xls.getCellData("Announcement", 2, 4);
		String[] Totalcount = count.split(":");
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in exported excel::" + Totalcount[1].trim(),
				false);
		String applrecordcount = agGetText(AdministrationAnnouncementPageObjects.paginator);
		String[] data = applrecordcount.split(" ");
		String recordCount = data[4];
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in application::" + recordCount, false);
		if (recordCount.equalsIgnoreCase(Totalcount[1].trim())) {
			Reports.ExtentReportLog("", Status.PASS, "Record count verification is successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Record count verification is Unsuccessfull", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to generate and verify record count
	 *             for Announcement.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 30-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void generateAndVerifyAnnouncementData(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		exportAnnouncementData(scenarioName);
		String filePath = lsmvConstants.path + "\\" + getTestDataCellValue(scenarioName, "GeneratedFileName");
		recordCountVerification(filePath);
	}

	/**********************************************************************************************************
	 * @Objective: Select date in JS calendar
	 * @InputParameters: Date
	 * @OutputParameters:NA
	 * @author:DushyanthMahesh
	 * @Date : 06-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDateCalender(String date) {
		if (!date.trim().equalsIgnoreCase("#skip#")) {
			String[] Date = date.split("-");
			agClick(AdministrationAnnouncementPageObjects.expireDateTextbox);
			agClick(AdministrationAnnouncementPageObjects.monthSelect);
			agClick(AdministrationAnnouncementPageObjects.monthDropdown(Date[1]));
			agClick(AdministrationAnnouncementPageObjects.yearSelect);
			agClick(AdministrationAnnouncementPageObjects.yearDropdown(Date[2]));
			agClick(AdministrationAnnouncementPageObjects.dateSelect(Date[0].replaceFirst("0", "")));
		}
	}

}
