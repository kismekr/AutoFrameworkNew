package com.arisglobal.framework.components.lsmv.L10_3;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_1.CommonOperations;
import com.arisglobal.framework.components.lsmv.L10_3.OR.AccountsPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AccountsOperations extends ToolManager {
	public static WebElement webElement;
	static String className = AccountsOperations.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform menu navigation in Account
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen: avinash
	 **********************************************************************************************************/
	public static void menuNavigation(String pageObject) {
		agMouseHover(AccountsPageObjects.accountHover);
		agJavaScriptExecuctorClick(pageObject);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform menu navigation in Account
	 *             module and verify each menu based on label name.
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 12-Jul-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void accountsNavigations(String menu) {
		switch (menu) {
		case "accountsNew":
			menuNavigation(AccountsPageObjects.accountNew);
			status = agIsVisible(AccountsPageObjects.accountNameTextbox);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to Accounts New is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Accounts New is Unsuccessfull", true);
			}
			break;
		case "accountsListing":
			menuNavigation(AccountsPageObjects.accountListing);
			agSetStepExecutionDelay("5000");
			status = agIsVisible(AccountsPageObjects.accountListingSearchTextbox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to Accounts Listing is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Accounts Listing is Unsuccessfull", true);
			}
			break;
		case "accountsGroup":
			menuNavigation(AccountsPageObjects.accountsGroup);
			status = agIsVisible(AccountsPageObjects.accountGroupSearchTextbox);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to Accounts Group is successfull", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to Accounts Group is Unsuccessfull", true);
			}
			break;

		case "unresolvedCorrespondence":
			menuNavigation(AccountsPageObjects.unresolvedCorrespondence);
			status = agIsVisible(AccountsPageObjects.unResolveCorrSearchTextbox);
			if (status) {
				Reports.ExtentReportLog("", Status.PASS, "Navigation to Unresolved Correspondence is successfull",
						true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Navigation to unresolved Correspondence is Unsuccessfull",
						true);
			}
			break;
		default:
			System.out.println("Invalid Menu Link!");
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit and update account.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 08-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateAccount(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(AccountsPageObjects.editIcon);
		createAccount(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search account.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 08-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAccount(String scenarioName) {
		search(scenarioName);
		String paginator = agGetText(AccountsPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "AccountID"),
					AccountsPageObjects.get_ListofAccountID);
			Reports.ExtentReportLog("", Status.PASS, "Search Account: Account Listed", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Search Account: Account Not Listed", true);
		}
		agClick(AccountsPageObjects.refresh_icon);
		agIsVisible(AccountsPageObjects.accountListingSearchTextbox);
	}

	/**********************************************************************************************************
	 * @Objective: This method is to search data in advance search screen and edit
	 *             account in Listing screen
	 * @InputParameters: scenarioName
	 * @OutputParameters:NA
	 * @author: Avinash k
	 * @Date : 16-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void advanceSearchAndEdit(String scenarioName, boolean edit) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(AccountsPageObjects.advanceSearchBtn);
		agSetStepExecutionDelay("5000");
		agSetValue(AccountsPageObjects.advaSrchAccountNameTxtFeild, getTestDataCellValue(scenarioName, "AccountName"));
		agClick(AccountsPageObjects.advSearchBtn);
		agSetStepExecutionDelay("10000");
		if (agIsVisible(AccountsPageObjects.searchRecEdit(getTestDataCellValue(scenarioName, "AccountName")))) {
			Reports.ExtentReportLog("", Status.INFO, "Account Search successful", true);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Account Search Unsuccessful", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		if (edit == true) {
			agClick(AccountsPageObjects.searchRecEdit(getTestDataCellValue(scenarioName, "AccountName")));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Synonyms
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 07-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addSynonyms(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "AddSynonyms").equalsIgnoreCase("True")) {
			agClick(AccountsPageObjects.synonyms_tab);
			agSetStepExecutionDelay("10000");
			agWaitTillVisibilityOfElement(AccountsPageObjects.synonyms_Label);
			agIsVisible(AccountsPageObjects.synonyms_Label);
			String excelData = getTestDataCellValue(scenarioName, "Synonyms");
			String[] data = excelData.split(",");
			for (int i = 0; i < data.length; i++) {
				agClick(AccountsPageObjects.synonymsAdd_Btn);
				agSetStepExecutionDelay("5000");
				agSetValue(AccountsPageObjects.setSynonyms(Integer.toString(i)), data[i]);
			}
			Reports.ExtentReportLog("", Status.INFO, "Data entred in Synonyms", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: scenarioName, label, columnName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 07-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(AccountsPageObjects.clickdropdown(label));
			agClick(AccountsPageObjects.selectDropdownvalue(getTestDataCellValue(scenarioName, columnName)));

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add account group
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 07-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addAccountGroup(String scenarioName) {
		if (getTestDataCellValue(scenarioName, "AddAccountGroup").equals("True")) {
			agClick(AccountsPageObjects.accountsGroupNameLookup_icon);
			agSetStepExecutionDelay("3000");
			agIsVisible(AccountsPageObjects.accountLookup_label);
			agSetValue(AccountsPageObjects.accountsGroupName_Txtfield,
					getTestDataCellValue(scenarioName, "AccountsGroupName"));

			agClick(AccountsPageObjects.lookupSearch_Btn);
			agWaitTillVisibilityOfElement(AccountsPageObjects
					.selectAccountLookupRadioBtn(getTestDataCellValue(scenarioName, "AccountsGroupName")));
			agClick(AccountsPageObjects
					.selectAccountLookupRadioBtn(getTestDataCellValue(scenarioName, "AccountsGroupName")));

			Reports.ExtentReportLog("", Status.INFO, "Data entred in Account Group", true);
			agSetStepExecutionDelay("2000");
			agJavaScriptExecuctorClick(AccountsPageObjects.lookupOK_Btn);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agWaitTillInvisibilityOfElement(AccountsPageObjects.lookupOK_Btn);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Account Group is not added", false);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Account exist or not based
	 *             on Account ID name
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 07-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Boolean verifysearchData(String scenarioName) {
		Boolean falg = false;
		agSetStepExecutionDelay(5000);
		agWaitTillVisibilityOfElement(AccountsPageObjects.paginator);
		String paginator = agGetText(AccountsPageObjects.paginator);
		System.out.println(paginator);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (paginator != null && paginator.startsWith("1")) {
			List<WebElement> list = agGetElementList(AccountsPageObjects.get_ListofAccountName);
			String columnHeader = null;
			for (int j = 1; j <= list.size(); j++) {
				columnHeader = agGetText(AccountsPageObjects.columnHeaderList(Integer.toString(j)));
				if (getTestDataCellValue(scenarioName, "AccountName").equalsIgnoreCase(columnHeader)) {
					falg = true;
					break;
				}
			}
		}
		return falg;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Firm detalis.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 07-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setFirmDetails(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(AccountsPageObjects.setFirmDetailsTxtfields(AccountsPageObjects.FirmSiteName_txtfield),
				getTestDataCellValue(scenarioName, "FirmSiteName"));
		agSetValue(AccountsPageObjects.setFirmDetailsTxtfields(AccountsPageObjects.firmCity_txtfield),
				getTestDataCellValue(scenarioName, "FirmCity"));
		agSetValue(AccountsPageObjects.setFirmDetailsTxtfields(AccountsPageObjects.firmState_txtfield),
				getTestDataCellValue(scenarioName, "FirmState"));
		agSetValue(AccountsPageObjects.firmPostcode_txtfield, getTestDataCellValue(scenarioName, "FirmPostalCode"));
		if (!getTestDataCellValue(scenarioName, "FirmCountry").equalsIgnoreCase("#skip#")) {
			agClick(AccountsPageObjects.clickCountry_FirmdetailsSection);
			agSetStepExecutionDelay("1000");
			agClick(AccountsPageObjects.selectFirmCountry(getTestDataCellValue(scenarioName, "FirmCountry")));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		agSetValue(AccountsPageObjects.setFirmDetailsTxtfields(AccountsPageObjects.firmSiteFEINumber_txtfield),
				getTestDataCellValue(scenarioName, "FirmSiteNumber"));
		agSetValue(AccountsPageObjects.setFirmDetailsTxtfields(AccountsPageObjects.parentCompanyName_txtfield),
				getTestDataCellValue(scenarioName, "ParentCompanyName"));
		agSetValue(AccountsPageObjects.setFirmDetailsTxtfields(AccountsPageObjects.parentCompanyCity_txtfield),
				getTestDataCellValue(scenarioName, "ParentCompanyCity"));
		agSetValue(AccountsPageObjects.setFirmDetailsTxtfields(AccountsPageObjects.parentCompanyState_txtfield),
				getTestDataCellValue(scenarioName, "ParentCompanyState"));
		agSetValue(AccountsPageObjects.parentCompanyPostalCode_txtfield,
				getTestDataCellValue(scenarioName, "ParentPostCode"));
		if (!getTestDataCellValue(scenarioName, "ParentCountry").equalsIgnoreCase("#skip#")) {
			agClick(AccountsPageObjects.clickdropdown(AccountsPageObjects.parentCompanyCountry));
			agSetStepExecutionDelay("1000");
			agClick(AccountsPageObjects.selectParentCountry(getTestDataCellValue(scenarioName, "ParentCountry")));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		agSetValue(AccountsPageObjects.setFirmDetailsTxtfields(AccountsPageObjects.parentCompanyFEINumber_txtfield),
				getTestDataCellValue(scenarioName, "ParentFEINumb"));
		Reports.ExtentReportLog("", Status.INFO, "Data entred in Firm Details", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set account detalis.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 07-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setAccountDetails(String scenarioName) {

		agAssertVisible(AccountsPageObjects.accountNewLable);
		agSetValue(AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.accountName_txtfield),
				getTestDataCellValue(scenarioName, "AccountName"));
		setDropDownValue(AccountsPageObjects.accountType_dropdown, scenarioName, "AccountType");
		setDropDownValue(AccountsPageObjects.healthAuthority_dropdwn, scenarioName, "HealthAuthority");
		addAccountGroup(scenarioName);
		agSetStepExecutionDelay("5000");
		agClick(AccountsPageObjects.setAccountStatus(getTestDataCellValue(scenarioName, "AccountStatus")));
		// agClick(AccountsPageObjects.setAccountStatus(getTestDataCellValue(scenarioName,
		// "AccountStatus")));
		agSetStepExecutionDelay("5000");
		if (getTestDataCellValue(scenarioName, "AccountStatus").equalsIgnoreCase("Inactive")) {
			agJavaScriptExecuctorSendKeys(AccountsPageObjects.reasonforDeactivate_Txtarea,
					getTestDataCellValue(scenarioName, "ReasonforDeactivate"));
		}
		agSetValue(AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.industry_txtfield),
				getTestDataCellValue(scenarioName, "Industry"));
		agSetStepExecutionDelay("2000");
		if (getTestDataCellValue(scenarioName, "AccountStatus").equalsIgnoreCase("Inactive")) {
			agJavaScriptExecuctorSendKeys(AccountsPageObjects.reasonforDeactivate_Txtarea,
					getTestDataCellValue(scenarioName, "ReasonforDeactivate"));
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetStepExecutionDelay("3000");
		agSetValue(AccountsPageObjects.phoneCountryCode, getTestDataCellValue(scenarioName, "Phone_CountryCode"));
		agSetValue(AccountsPageObjects.phoneAreaCode, getTestDataCellValue(scenarioName, "Phone_AreaCode"));
		agSetValue(AccountsPageObjects.phoneNumber, getTestDataCellValue(scenarioName, "Phone_Number"));
		agSetValue(AccountsPageObjects.faxCountryCode, getTestDataCellValue(scenarioName, "Fax_CountryCode"));
		agSetValue(AccountsPageObjects.faxAreaCode, getTestDataCellValue(scenarioName, "Fax_AreaCode"));
		agSetValue(AccountsPageObjects.faxNumber, getTestDataCellValue(scenarioName, "Fax_Number"));
		agJavaScriptExecuctorScrollToElement(
				AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.emailID_txtfield));
		agSetValue(AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.emailID_txtfield),
				getTestDataCellValue(scenarioName, "EmailID"));
		agSetValue(AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.streetAddress_txtfield),
				getTestDataCellValue(scenarioName, "StreetAddress"));
		agSetValue(AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.city_txtfield),
				getTestDataCellValue(scenarioName, "City"));
		agSetValue(AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.state_txtfield),
				getTestDataCellValue(scenarioName, "State"));
		agSetValue(AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.postcode_txtfield),
				getTestDataCellValue(scenarioName, "Postcode"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(AccountsPageObjects.clickCountry_AccdetailsSection);
		agSetStepExecutionDelay("1000");
		agClick(AccountsPageObjects.selectDropdownvalue(getTestDataCellValue(scenarioName, "AccountCountry")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.faxDirectory_txtfield),
				getTestDataCellValue(scenarioName, "FaxDirectory"));
		agSetValue(AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.faxDomain_txtfield),
				getTestDataCellValue(scenarioName, "FaxDomain"));
		agSetValue(AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.website_txtfield),
				getTestDataCellValue(scenarioName, "Website"));
		agSetValue(AccountsPageObjects.domain_txtfield, getTestDataCellValue(scenarioName, "Domain"));
		agSetValue(AccountsPageObjects.description_Txtarea, getTestDataCellValue(scenarioName, "Description"));

		agJavaScriptExecuctorScrollToElement(AccountsPageObjects.description_Txtarea);

		if (getTestDataCellValue(scenarioName, "IsDistributionContact?").equalsIgnoreCase("Yes")) {
			agClick(AccountsPageObjects
					.setIsDistributionContact(getTestDataCellValue(scenarioName, "IsDistributionContact?")));
			agClick(AccountsPageObjects
					.setIsDistributionContact(getTestDataCellValue(scenarioName, "IsDistributionContact?")));
		}
		setDropDownValue(AccountsPageObjects.distribution_dropdwn, scenarioName, "DistributionSetting");
		agSetValue(AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.qcSamplingCount_txtfield),
				getTestDataCellValue(scenarioName, "QCSamplingCount"));
		setDropDownValue(AccountsPageObjects.language_dropdwn, scenarioName, "Language");
		agSetValue(AccountsPageObjects.regionCode_txtfield, getTestDataCellValue(scenarioName, "RegionCode"));
		agSetValue(AccountsPageObjects.region_txtfield, getTestDataCellValue(scenarioName, "Region"));
		agSetValue(AccountsPageObjects.statusDate,
				CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "StatusDate")));
		setDropDownValue(AccountsPageObjects.companyStatus_dropdwn, scenarioName, "CompanyStatus");

		Reports.ExtentReportLog("", Status.INFO, "Data entred in Account Details", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set E2B Details.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 16-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SetE2BDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agJavaScriptExecuctorScrollToElement(AccountsPageObjects.e2bDetails_label);

		if (getTestDataCellValue(scenarioName, "ICSRExchangePartner?").equalsIgnoreCase("Yes")) {
			agClick(AccountsPageObjects
					.setICSRExchangePartner(getTestDataCellValue(scenarioName, "ICSRExchangePartner?")));
			agSetStepExecutionDelay("2000");

			setDropDownValue(AccountsPageObjects.encodingFormat_dropdwn, scenarioName, "EncodingFormat");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		}
		agSetStepExecutionDelay("2000");
		agSetValue(AccountsPageObjects.limitErrorMessageinACK_txtfield,
				getTestDataCellValue(scenarioName, "LimitErrorMessageinACK"));
		setDropDownValue(AccountsPageObjects.e2BMedDRAcodingforExport_dropdwn, scenarioName,
				"E2BMedDRAcodingforExport");
		setDropDownValue(AccountsPageObjects.senderOrgType_dropdwn, scenarioName, "SenderOrganizationType");
		setDropDownValue(AccountsPageObjects.timeZone_dropdwn, scenarioName, "TimeZone");
		setDropDownValue(AccountsPageObjects.documentCompressionAlgorithm_dropdwn, scenarioName,
				"DocumentCompressionAlgorithm");
		setDropDownValue(AccountsPageObjects.IRDLRDforE2BImport_dropdwn, scenarioName, "IRDLRDforE2BImport");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Data entred in E2B Details", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set E2B Details.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 16-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyE2BDetailsSection(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "LimitErrorMessageinACK"),
				AccountsPageObjects.limitErrorMessageinACK_txtfield);

		agCheckPropertyText(getTestDataCellValue(scenarioName, "E2BMedDRAcodingforExport"),
				AccountsPageObjects.get_e2BMedDRAcodingforExport_dropdwn);

		agCheckPropertyText(getTestDataCellValue(scenarioName, "SenderOrganizationType"),
				AccountsPageObjects.get_SenderOrganizationType_dropdwn);

		agCheckPropertyText(getTestDataCellValue(scenarioName, "TimeZone"), AccountsPageObjects.get_TimeZone_dropdwn);

		agCheckPropertyText(getTestDataCellValue(scenarioName, "DocumentCompressionAlgorithm"),
				AccountsPageObjects.get_SenderOrganizationType_dropdwn);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "IRDLRDforE2BImport"),
				AccountsPageObjects.get_IRDLRDforE2BImport_dropdwn);

		Reports.ExtentReportLog("", Status.INFO, "Data verified in E2B Details", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search account.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 17-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void search(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(AccountsPageObjects.accountListingSearchTextbox, getTestDataCellValue(scenarioName, "AccountName"));
		agClick(AccountsPageObjects.searchIcon);
		agSetStepExecutionDelay(5000);
		agIsVisible(AccountsPageObjects.paginator);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create account.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 07-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createAccount(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		setAccountDetails(scenarioName);
		SetE2BDetails(scenarioName);
		setFirmDetails(scenarioName);
		addSynonyms(scenarioName);
		addContacts(scenarioName);
		addEstablishment(scenarioName);
		addSLA(scenarioName, "1");
		addContractByLookup(scenarioName);
		agJavaScriptExecuctorClick(AccountsPageObjects.saveAndExit_Btn);
		agWaitTillVisibilityOfElement(AccountsPageObjects.saveOkbtn);
		CommonOperations.takeScreenShot();
		agClick(AccountsPageObjects.saveOkbtn);
		agSetStepExecutionDelay("5000");
		agIsVisible(AccountsPageObjects.keywordSearchTextbox);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Establishment account.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addEstablishment(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorScrollToElement(AccountsPageObjects.accounts_tab);

		if (getTestDataCellValue(scenarioName, "AddEstablishment").equalsIgnoreCase("true")) {
			agClick(AccountsPageObjects.addEstablishmentBtn);
			agSetStepExecutionDelay("5000");
			agIsVisible(AccountsPageObjects.establishmentIdTxtfield);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agSetValue(AccountsPageObjects.establishmentIdTxtfield,
					getTestDataCellValue(scenarioName, "ESTABLISHMENTID"));
			agSetValue(AccountsPageObjects.establishmentcontactIdTxtfield,
					getTestDataCellValue(scenarioName, "ESTABLISHMENTContactID"));
			agSetValue(AccountsPageObjects.establishmentapplicationTypeTxtfield,
					getTestDataCellValue(scenarioName, "EstApplicationType"));
			agClick(AccountsPageObjects.click_LicenseType);
			agClick(AccountsPageObjects.setlicenseType(getTestDataCellValue(scenarioName, "LICENSESTATUS")));

			Reports.ExtentReportLog("", Status.INFO, "Data entered in Establishment", true);
		}

		else {
			Reports.ExtentReportLog("", Status.INFO, "Data not entered in Establishment", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Establishment account.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 19-Jul-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyEstablishment(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("5000");
		agJavaScriptExecuctorScrollToElement(AccountsPageObjects.accounts_tab);
		agWaitTillVisibilityOfElement(AccountsPageObjects.accountNewLable);
		agJavaScriptExecuctorScrollToElement(AccountsPageObjects.accounts_tab);
		if (getTestDataCellValue(scenarioName, "AddEstablishment").equalsIgnoreCase("true")) {
			agWaitTillVisibilityOfElement(AccountsPageObjects.establishmentIdTxtfield);
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ESTABLISHMENTID"),
					AccountsPageObjects.establishmentIdTxtfield);
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ESTABLISHMENTContactID"),
					AccountsPageObjects.establishmentcontactIdTxtfield);
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "EstApplicationType"),
					AccountsPageObjects.establishmentapplicationTypeTxtfield);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "LICENSESTATUS"),
					AccountsPageObjects.get_LicenseType);
			Reports.ExtentReportLog("", Status.INFO, "Data verified in Establishment", true);

		} else {
			Reports.ExtentReportLog("", Status.INFO, "Data not verified in Establishment", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created search and create account.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 07-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreateAccount(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		
		search(scenarioName);
		if (verifysearchData(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Account already exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "AccountID"),
					AccountsPageObjects.get_ListofAccountID);
		} else {
			agClick(AccountsPageObjects.new_Btn);
			createAccount(scenarioName);
			CommonOperations.setAuditInfo(scenarioName);
			agIsVisible(AccountsPageObjects.accountListingSearchTextbox);
			CommonOperations.takeScreenShot();
			search(scenarioName);
			verifyAccount(scenarioName);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created search and create Account.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 06-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreateAccountRecord(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		if (verifysearchData(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Account already exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "AccountID"),
					AccountsPageObjects.get_ListofAccountID);
		} else {
			agClick(AccountsPageObjects.new_Btn);
			createAccount(scenarioName);
			CommonOperations.setAuditInfo("Create_Account");
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify accounts.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 08-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyAccount(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		
		agWaitTillVisibilityOfElement(AccountsPageObjects.editIcon);
		agClick(AccountsPageObjects.editIcon);
		agIsVisible(AccountsPageObjects.accountNewLable);
		verifyAccountDetailsSection(scenarioName);
		verifyE2BDetailsSection(scenarioName);
		verifyFirmDetailsSection(scenarioName);
		verifyEstablishment(scenarioName);
		verifySynonyms(scenarioName);
		// agClick(AccountsPageObjects.cancel_Btn);
		agJavaScriptExecuctorClick(AccountsPageObjects.cancel_Btn);
		agSetStepExecutionDelay("5000");
		agIsVisible(AccountsPageObjects.accountListingSearchTextbox);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit and verify Synonyms Section.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 08-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySynonyms(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "AddSynonyms").equalsIgnoreCase("True")) {
			agClick(AccountsPageObjects.synonyms_tab);
			agWaitTillVisibilityOfElement(AccountsPageObjects.synonyms_Label);
			agIsVisible(AccountsPageObjects.synonyms_Label);
			String excelData = getTestDataCellValue(scenarioName, "Synonyms");
			List<String> data = new ArrayList<>();
			String[] array = excelData.split(",");
			for (int i = 0; i < array.length; i++) {
				data.add(array[i]);
				agCheckPropertyValue("value", data.get(i), AccountsPageObjects.setSynonyms(Integer.toString(i)));
			}

			Reports.ExtentReportLog("", Status.INFO, "Data verification in Synonyms is successfull", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit and verify Firm Details
	 *             Section.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 08-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyFirmDetailsSection(String scenarioName) {
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FirmSiteName"),
				AccountsPageObjects.setFirmDetailsTxtfields(AccountsPageObjects.FirmSiteName_txtfield));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FirmCity"),
				AccountsPageObjects.setFirmDetailsTxtfields(AccountsPageObjects.firmCity_txtfield));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FirmState"),
				AccountsPageObjects.setFirmDetailsTxtfields(AccountsPageObjects.firmState_txtfield));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FirmPostalCode"),
				AccountsPageObjects.firmPostcode_txtfield);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "FirmCountry"), AccountsPageObjects.get_Firmcountry);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FirmSiteNumber"),
				AccountsPageObjects.setFirmDetailsTxtfields(AccountsPageObjects.firmSiteFEINumber_txtfield));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ParentCompanyName"),
				AccountsPageObjects.setFirmDetailsTxtfields(AccountsPageObjects.parentCompanyName_txtfield));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ParentCompanyCity"),
				AccountsPageObjects.setFirmDetailsTxtfields(AccountsPageObjects.parentCompanyCity_txtfield));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ParentCompanyState"),
				AccountsPageObjects.setFirmDetailsTxtfields(AccountsPageObjects.parentCompanyState_txtfield));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ParentPostCode"),
				AccountsPageObjects.parentCompanyPostalCode_txtfield);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ParentCountry"),
				AccountsPageObjects.get_ParentCompanyCountry);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ParentFEINumb"),
				AccountsPageObjects.setFirmDetailsTxtfields(AccountsPageObjects.parentCompanyFEINumber_txtfield));
		Reports.ExtentReportLog("", Status.INFO, "Data verification in Firm Details section is successfull", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit and verify Account Details
	 *             Section.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 08-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyAccountDetailsSection(String scenarioName) {

		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "AccountName"),
				AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.accountName_txtfield));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "AccountType"), AccountsPageObjects.get_AccountType);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "AccountID"),
				AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.accountId_txtfield));
		if (getTestDataCellValue(scenarioName, "AddAccountGroup").equals("True")) {
			agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "AccountsGroupName"),
					AccountsPageObjects.get_AccountsGroupName);
		}
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Industry"),
				AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.industry_txtfield));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Phone_CountryCode"),
				AccountsPageObjects.phoneCountryCode);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Phone_AreaCode"),
				AccountsPageObjects.phoneAreaCode);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Phone_Number"),
				AccountsPageObjects.phoneNumber);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Fax_CountryCode"),
				AccountsPageObjects.faxCountryCode);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Fax_AreaCode"),
				AccountsPageObjects.faxAreaCode);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Fax_Number"), AccountsPageObjects.faxNumber);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "EmailID"),
				AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.emailID_txtfield));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "StreetAddress"),
				AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.streetAddress_txtfield));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "City"),
				AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.city_txtfield));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "State"),
				AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.state_txtfield));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Postcode"),
				AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.postcode_txtfield));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "AccountCountry"),
				AccountsPageObjects.get_AccountCountry);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FaxDirectory"),
				AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.faxDirectory_txtfield));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FaxDomain"),
				AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.faxDomain_txtfield));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Website"),
				AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.website_txtfield));

		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Domain"),
				AccountsPageObjects.domain_txtfield);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Description"), AccountsPageObjects.description_Txtarea);
		if (getTestDataCellValue(scenarioName, "ICSRExchangePartner?").equalsIgnoreCase("Yes")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "EncodingFormat"),
					AccountsPageObjects.get_EncodingFormat);
		}
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "QCSamplingCount"),
				AccountsPageObjects.setAccountsDetailsTxtfields(AccountsPageObjects.qcSamplingCount_txtfield));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "DistributionSetting"),
				AccountsPageObjects.get_DistributionSetting);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "HealthAuthority"),
				AccountsPageObjects.get_HealthAuthority);
		Reports.ExtentReportLog("", Status.INFO, "Data verification in Account Details section is successfull", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search for deleted account.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchDeleteAccount(String scenarioName) {
		search(scenarioName);
		String paginator = agGetText(AccountsPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.FAIL, "Search for Deleted Account: Deleted Account is listed", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS, "Search for Deleted Account: Deleted Account is not listed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete account.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void delete(String scenarioName) {
		agClick(AccountsPageObjects.delete_Btn);
		agSetStepExecutionDelay("3000");
		if (agIsVisible(AccountsPageObjects.deleteConfirm_YesBtn)) {
			Reports.ExtentReportLog("", Status.PASS, "", true);
			agClick(AccountsPageObjects.deleteConfirm_YesBtn);
			agSetStepExecutionDelay("5000");
			agClick(AccountsPageObjects.saveOkbtn);
			agSetStepExecutionDelay("2000");
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete account.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 11-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteAccount(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		String paginator = agGetText(AccountsPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			// agCheckPropertyText(getTestDataCellValue(scenarioName, "AccountID"),
			// AccountsPageObjects.get_ListofAccountID);
			Reports.ExtentReportLog("", Status.PASS, "Account Found", true);
			agClick(AccountsPageObjects.selectListingCheckbox(getTestDataCellValue(scenarioName, "AccountName")));
			agSetStepExecutionDelay(3000);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			delete(scenarioName);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Account Not Found", true);
		}
	}

	private static void agSetStepExecutionDelay(int i) {
		// TODO Auto-generated method stub
		
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download account export to excel.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 15-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportToexcel(String FileName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(AccountsPageObjects.downloadIcon);
		agClick(AccountsPageObjects.exporttoExcel_link);
		if (agIsVisible(AccountsPageObjects.export_Btn) == true) {
			agClick(AccountsPageObjects.export_Btn);
			try {
				Thread.sleep(8000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			CommonOperations.move_Downloadedexcel(FileName);
			agClick(AccountsPageObjects.exportexcelcancel_Btn);
		} else {
			Reports.ExtentReportLog("Export to excel pop is not displayed", Status.INFO, "", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to compare record count with download
	 *             excel
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:Avinash K
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void recordCountVerification(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		String count = xls.getCellData("Accounts", 2, 4);
		String[] Totalcount = count.split(":");
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in exported excel::" + Totalcount[1].trim(),
				false);
		String applrecordcount = agGetText(AccountsPageObjects.paginator);
		String[] data = applrecordcount.split(" ");
		String recordCount = data[4];
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in application::" + recordCount, false);
		if (recordCount.equalsIgnoreCase(Totalcount[1].trim())) {
			Reports.ExtentReportLog("", Status.PASS, "Record count verification is successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Record count verification is Unsuccessfull", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add contacts from Lookup
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 16-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addContacts(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agClick(AccountsPageObjects.accounts_tab);
		agSetStepExecutionDelay("5000");
		agJavaScriptExecuctorScrollToElement(AccountsPageObjects.addContactButton);
		//agJavaScriptExecuctorClick(AccountsPageObjects.addContactButton);
		agClick(AccountsPageObjects.addContactButton);
		
		
		agWaitTillVisibilityOfElement(AccountsPageObjects.contactIdTextbox);
		agSetValue(AccountsPageObjects.contactIdTextbox,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_ContactId"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.setListDropDownValue(AccountsPageObjects.countryDropdown,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_Country"));
		agSetValue(AccountsPageObjects.firstNameTextbox,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_FirstName"));
		agSetValue(AccountsPageObjects.middleNameTextbox,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_MiddleName"));
		agSetValue(AccountsPageObjects.lastNameTextbox,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_LastName"));
		agSetValue(AccountsPageObjects.countryCodeTextbox,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_CountryCode"));
		agSetValue(AccountsPageObjects.areaCodeTextbox,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_AreaCode"));
		agSetValue(AccountsPageObjects.NumberTextbox,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_Number"));
		agSetValue(AccountsPageObjects.extNoTextbox,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_ExtnNo"));
		agSetValue(AccountsPageObjects.emailAddressTextbox,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_EmailAddress"));
		agSetValue(AccountsPageObjects.degreeTextbox,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_Degree"));
		agSetValue(AccountsPageObjects.otherPhNumberTextbox,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_OtherPhoneNumber"));
		CommonOperations.setListDropDownValue(AccountsPageObjects.specializationDropdown,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_Specialization"));
		agSetValue(AccountsPageObjects.ifOtherTextbox,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_Ifother"));
		CommonOperations.setListDropDownValue(AccountsPageObjects.departmentDropdown,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_Department"));
		agSetValue(AccountsPageObjects.primaryAccountTextbox,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_PrimaryAccount"));
		agSetValue(AccountsPageObjects.postalCodeTextbox,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_PostalCode"));
		agSetValue(AccountsPageObjects.customerMasterIdTextbox,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_CustomerMasterId"));
		agSetValue(AccountsPageObjects.interchangeIdTextbox,
				getTestDataCellValue(scenarioName, "Accounts_New_Contacts_InterchangeId"));

		String boolCheck = getTestDataCellValue(scenarioName, "Accounts_New_Contacts_IsAlsoAnE2BContact");

		if (boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("true")) {
			CommonOperations.clickCheckBoxRightOf(AccountsPageObjects.isAlsoAnE2BContact, "true");
		}
		Reports.ExtentReportLog("", Status.PASS, "Contact Lookup details entered", true);

		agClick(AccountsPageObjects.searchContactButton);
		agSetStepExecutionDelay("5000");
		agClick(AccountsPageObjects
				.selectContactFromLookupList(getTestDataCellValue(scenarioName, "Accounts_New_Contacts_FirstName")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(AccountsPageObjects.okContactButton);
		agSetStepExecutionDelay("5000");
		agClick(AccountsPageObjects.primaryContactChkBox);
		agIsVisible(AccountsPageObjects.addEstablishmentBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add contacts details in Contact
	 *             grid.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 09-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addContactsGridDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Contact_E2BContacts").equalsIgnoreCase("true")) {
			agClick((AccountsPageObjects.checkE2BContacts).replace("%s",
					getTestDataCellValue(scenarioName, "Accounts_New_Contacts_FirstName")));
			agSetStepExecutionDelay("3000");
			agSetValue(
					(AccountsPageObjects.interchangeIDTextbox).replace("%rowNo%",
							getTestDataCellValue(scenarioName, "RowNo_Contact")),
					getTestDataCellValue(scenarioName, "Contact_InterchangeID"));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		if (getTestDataCellValue(scenarioName, "Contact_Distribute").equalsIgnoreCase("true")) {
			agClick((AccountsPageObjects.checkDistribute).replace("%s",
					getTestDataCellValue(scenarioName, "Accounts_New_Contacts_FirstName")));
		}

		agJavaScriptExecuctorScrollToElement(AccountsPageObjects.contacts_Label);
		Reports.ExtentReportLog("", Status.PASS, "Contacts Grid Section Details Entered", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete contacts from List
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 16-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteContactRecord(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agClick(AccountsPageObjects
				.checkContact(getTestDataCellValue(scenarioName, "Accounts_New_Contacts_FirstName")));
		agClick(AccountsPageObjects.deleteContactButton);

		if (agIsVisible(AccountsPageObjects.confirmdelDialog)) {
			agClick(AccountsPageObjects.confirmdel_YesBtn);
			agSetStepExecutionDelay("3000");
			if (!agIsVisible(AccountsPageObjects
					.checkContact(getTestDataCellValue(scenarioName, "Accounts_New_Contacts_FirstName")))) {

				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				Reports.ExtentReportLog("", Status.PASS, "Deleting Contact Successful", true);
			} else {
				Reports.ExtentReportLog("", Status.PASS, "Deleting Contact UnSuccessful", true);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add SLA Record
	 * @InputParameters: scenarioName , rowNo (starts from 0,1,2,3..,)
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 16-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addSLA(String scenarioName, String rowNo) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "addSLAdata").equalsIgnoreCase("false")) {
		} else {
			agClick(AccountsPageObjects.addSLAButton);
			agSetStepExecutionDelay("3000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CommonOperations.setListDropDownValue(AccountsPageObjects.selectPriorityDropdown(rowNo),
					getTestDataCellValue(scenarioName, "Accounts_New_SLA_Priority"));
			agSetValue(AccountsPageObjects.selectDurationTextbox(rowNo),
					getTestDataCellValue(scenarioName, "Accounts_New_SLA_Duration"));
			CommonOperations.setListDropDownValue(AccountsPageObjects.selectUnitDropdown(rowNo),
					getTestDataCellValue(scenarioName, "Accounts_New_SLA_Unit"));
			Reports.ExtentReportLog("", Status.PASS, "SLA details entered", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Delete SLA Record
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 16-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteSLA(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		agClick(AccountsPageObjects.checkSLARecord(getTestDataCellValue(scenarioName, "Accounts_New_SLA_Priority")));
		agClick(AccountsPageObjects.deleteSLAButton);
		agSetStepExecutionDelay("3000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		if (agIsVisible(AccountsPageObjects.confirmSLADel_Dialog)) {
			agClick(AccountsPageObjects.confirmSLADel_Yes);
			if (!agIsVisible(AccountsPageObjects
					.checkSLARecord(getTestDataCellValue(scenarioName, "Accounts_New_SLA_Priority")))) {
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				Reports.ExtentReportLog("", Status.PASS, "Deleting SLA Successful", true);
			} else {
				Reports.ExtentReportLog("", Status.PASS, "Deleting SLA UnSuccessful", true);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add contract from lookup.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 16-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addContractByLookup(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (getTestDataCellValue(scenarioName, "Accounts_New_Contracts__Lookup_boolDocLitTab")
				.equalsIgnoreCase("true")) {
			agClick(AccountsPageObjects.addContractsButton);
			agSetStepExecutionDelay("3000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			agSetValue(AccountsPageObjects.documentIdTextbox,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_DocumentId"));
			agSetValue(AccountsPageObjects.titleTextbox,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_Title"));
			agSetValue(AccountsPageObjects.fileNameTextbox,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_FileName"));
			CommonOperations.setListDropDownValue(AccountsPageObjects.subTypeDropdown,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_SubType"));
			agSetValue(AccountsPageObjects.productTextbox,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_Product"));
			agSetValue(AccountsPageObjects.tradeNameTextbox,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_TradeName"));
			CommonOperations.setListDropDownValue(AccountsPageObjects.requestCategoryDropdown,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_RequestCategory"));
			CommonOperations.setListDropDownValue(AccountsPageObjects.requestSubCategoryDropdown,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_RequestSubCategory"));
			CommonOperations.setListDropDownValue(AccountsPageObjects.languageDropdown,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_Language"));
			CommonOperations.setListDropDownValue(AccountsPageObjects.assetTypeDropdown,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_AssetType"));
			CommonOperations.setListDropDownValue(AccountsPageObjects.documentStatusDropdown,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_DocumentStatus"));

			CommonOperations.clickCheckBoxLeftOf(AccountsPageObjects.offLabelCheckbox,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_OffLabel"));
			agSetValue(AccountsPageObjects.documentKeywordsTextarea,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_DocumentKeywords"));
			CommonOperations.clickCheckBoxLeftOf(AccountsPageObjects.docContectSearchCheckbox,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_DocumentContentSearch"));

			if (getTestDataCellValue(scenarioName, "Accounts_New_Contracts_DocumentContentSearch")
					.equalsIgnoreCase("true")) {
				agSetValue(AccountsPageObjects.keywordTextarea,
						getTestDataCellValue(scenarioName, "Accounts_New_Contracts_Keyword"));
			}

			Reports.ExtentReportLog("", Status.PASS, "Documents Library details entered", true);
			agClick(AccountsPageObjects.documentsSearchButton);

		} else if (getTestDataCellValue(scenarioName, "Accounts_New_Contracts_Lookup_boolContractsTab")
				.equalsIgnoreCase("true")) {

			agClick(AccountsPageObjects.addContractsButton);
			agSetStepExecutionDelay("5000");

			agClick(AccountsPageObjects.ContractsTab);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agSetValue(AccountsPageObjects.ContractNameTextbox,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_ContractName"));
			agSetValue(AccountsPageObjects.ContractNoTextbox,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_ContractNumber"));

			setDocumentUpload(scenarioName);
			agSetStepExecutionDelay("2000");
			agSetValue(AccountsPageObjects.startDateTextbox, CommonOperations
					.returnDateTime(getTestDataCellValue(scenarioName, "Accounts_New_Contracts_StartDate")));
			agSetValue(AccountsPageObjects.endDateTextbox, CommonOperations
					.returnDateTime(getTestDataCellValue(scenarioName, "Accounts_New_Contracts_EndDate")));
			agSetValue(AccountsPageObjects.descriptionTextarea,
					getTestDataCellValue(scenarioName, "Accounts_New_Contracts_Description"));
			agSetStepExecutionDelay("2000");
			agClick(AccountsPageObjects.uploadContractButton);
			agWaitTillInvisibilityOfElement(AccountsPageObjects.uploadContractButton);
			agSetStepExecutionDelay("10000");
			Reports.ExtentReportLog("", Status.PASS, "Contracts details entered", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to upload document in contract Lookup .
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mithun M P
	 * @Date : 20-Jan-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDocumentUpload(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		String fileName = Multimaplibraries.getTestDataCellValue(scenarioName, "Accounts_New_Contracts_DocumentName");
		agSetValue(AccountsPageObjects.uploadFileButton, lsmvConstants.LSMV_testDataInput + "\\" + fileName);
		agSetGlobalTimeOut("10000");
		agAssertVisible(AccountsPageObjects.fileUploadedLink(fileName));
		agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
		Reports.ExtentReportLog("Documents", Status.INFO, "Added document", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to set Account Exclusion.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :12-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setAccountExlucionSingle(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (agIsVisible(AccountsPageObjects.AccountNameValidation) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Contact Already Exist", true);
			// agClick(AccountsPageObjects.AccountCheckbox);
			// agClick(AccountsPageObjects.deleteAccountExclusionLink);
			// agSetStepExecutionDelay("2000");
			// agWaitTillVisibilityOfElement(AccountsPageObjects.DeleteYesBtn);
			// agClick(AccountsPageObjects.DeleteYesBtn);
			//
			// agSetStepExecutionDelay("3000");

		} else {
			agClick(AccountsPageObjects.addAccountExclusionLink);
			agSetStepExecutionDelay("3000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			agClick(AccountsPageObjects.aE_LastPage_Paginator);
			agSetStepExecutionDelay("3000");
			String val = CommonOperations.agGetText(AccountsPageObjects.aE_LastPage);
			agClick(AccountsPageObjects.aE_FirstPage_Paginator);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			int last = Integer.parseInt(val);
			boolean b = false;

			for (int i = 1; i <= last; i++) {
				if (agIsVisible(AccountsPageObjects
						.checkAccExcRecord(getTestDataCellValue(scenarioName, "Accounts_New_EandM_AccountId")))) {
					agClick(AccountsPageObjects
							.checkAccExcRecord(getTestDataCellValue(scenarioName, "Accounts_New_EandM_AccountId")));
					b = true;
					break;
				} else {
					agClick(AccountsPageObjects.aE_NextPage_Paginator);
				}
			}

			agWaitTillVisibilityOfElement(AccountsPageObjects.aE_OkButton);
			agClick(AccountsPageObjects.aE_OkButton);
			agWaitTillVisibilityOfElement(AccountsPageObjects.AccountNameValidation);
			agSetStepExecutionDelay("3000");
			agClick(AccountsPageObjects.saveAndExit_Btn);
			agWaitTillVisibilityOfElement(AccountsPageObjects.SaveOkBtn);
			agClick(AccountsPageObjects.SaveOkBtn);
			agSetStepExecutionDelay("2000");
			if (b == true) {
				Reports.ExtentReportLog("", Status.PASS, "Account Exlucion Details Set", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Account Exlucion Details are not Set", true);
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to set Partner Exclusion.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Wajahat Umar
	 * @Date : 16-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setPartnerExlucionSingle(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (agIsVisible(AccountsPageObjects.UnitNamevalidation) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Partner Already Exist", true);
		} else {

			agClick(AccountsPageObjects.addPartnerExclusionButton);
			agSetStepExecutionDelay("3000");
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			agClick(AccountsPageObjects.pE_LastPage_Paginator);
			agSetStepExecutionDelay("3000");
			String val = CommonOperations.agGetText(AccountsPageObjects.pE_LastPage);
			agClick(AccountsPageObjects.pE_FirstPage_Paginator);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

			int last = Integer.parseInt(val);
			boolean b = false;

			for (int i = 1; i <= last; i++) {
				if (agIsVisible(AccountsPageObjects
						.checkPartExcRecord(getTestDataCellValue(scenarioName, "Accounts_New_EandM_UnitCode")))) {
					agClick(AccountsPageObjects
							.checkPartExcRecord(getTestDataCellValue(scenarioName, "Accounts_New_EandM_UnitCode")));
					b = true;
				} else {
					agClick(AccountsPageObjects.pE_NextPage_Paginator);
				}
			}

			agClick(AccountsPageObjects.pE_OkButton);

			if (b == true) {
				Reports.ExtentReportLog("", Status.PASS, "partner Exlucion Details Set", true);
			} else {
				Reports.ExtentReportLog("", Status.FAIL, "Partner Exlucion Details are not Set", true);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to set Account Exclusion.
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Wajahat Umar S
	 * @Date : 11-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void EditAccount(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(
				AccountsPageObjects.EditParticularAccount(getTestDataCellValue(scenarioName, "AccountName")));
		agWaitTillVisibilityOfElement(AccountsPageObjects.ExclusionAndMaskingTab);
		agJavaScriptExecuctorClick(AccountsPageObjects.ExclusionAndMaskingTab);
		Reports.ExtentReportLog("", Status.PASS, "Edit Account", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to add the masking fields
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAccountName(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		agSetValue(AccountsPageObjects.keywordSearchTextbox, getTestDataCellValue(scenarioName, "AccountName"));
		agClick(AccountsPageObjects.searchButton);
		Reports.ExtentReportLog("", Status.INFO, "Account name search", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to add the masking fields
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	/**********************************************************************************************************
	 * @Objective: The below Method is to add the masking fields
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 01-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addmaskfields(String scenarioName) {
		String sectionName = getTestDataCellValue(scenarioName, "Masking_Section");
		String panelName = getTestDataCellValue(scenarioName, "Masking_Panel");
		String fieldName = getTestDataCellValue(scenarioName, "Masking_FieldName");

		if (agIsVisible(AccountsPageObjects.checkbox(sectionName, panelName, fieldName)) == true) {
			agSetStepExecutionDelay("5000");
			agJavaScriptExecuctorScrollToElement(AccountsPageObjects.checkbox(sectionName, panelName, fieldName));
			String attribute = agGetAttribute("Class", AccountsPageObjects.checkbox(sectionName, panelName, fieldName));
			if (attribute.contains("ui-icon-blank")) {
				CommonOperations.takeScreenShot();
				agClick(AccountsPageObjects.checkbox(sectionName, panelName, fieldName));
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			} else {
				Reports.ExtentReportLog("", Status.INFO, " CheckBox already checked ", true);
			}
		} else {
			Reports.ExtentReportLog("", Status.FAIL, " Section and field name not Visible", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to delete the masking fields
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 14-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteMaskFields() {
		agSetStepExecutionDelay("4000");
		agClick(AccountsPageObjects.deleteAllCheckbox);
		agClick(AccountsPageObjects.deletelink);
		agWaitTillVisibilityOfElement(AccountsPageObjects.deleteMessage);
		agClick(AccountsPageObjects.deleteyesBtn);
		agJavaScriptExecuctorClick(AccountsPageObjects.savebtn);
		agWaitTillVisibilityOfElement(AccountsPageObjects.validationpopup);
		agClick(AccountsPageObjects.saveOkbtn);
		Reports.ExtentReportLog("", Status.PASS, "Deleted Mask fields", true);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to add the masking fields
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 12-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addLink() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		agClick(AccountsPageObjects.Addlink);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is to click save and save ok button
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 12-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void saveOKBtnValidation() {
		agSetStepExecutionDelay("4000");
		agJavaScriptExecuctorClick(AccountsPageObjects.Okbtn);
		CommonOperations.agwaitTillVisible(AccountsPageObjects.pagination, 10, 1000);
		agWaitTillVisibilityOfElement(AccountsPageObjects.savebtn);
		agJavaScriptExecuctorClick(AccountsPageObjects.savebtn);
		agWaitTillVisibilityOfElement(AccountsPageObjects.validationpopup);
		String validation = agGetText(AccountsPageObjects.validationpopup);
		Reports.ExtentReportLog("", Status.PASS, " Mask fields added/updated : " + validation, true);
		agClick(AccountsPageObjects.saveOkbtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

}