package com.arisglobal.framework.components.lsmv.L10_3.OR;

public abstract class DuplicateCheckPageObjects {
	
	public static String duplicateChecklink = "xpath#//span[contains(text(),'Duplicate check policies')]";
	public static String NewButton = "xpath#//a[@id='DuplicateCheckListform:newId']";
	public static String PolicyNameTextbox = "xpath#//input[@id='dupCheckPolicyDetailsform:regionId']";
	public static String clickReportTypeDropDown = "xpath#//input[@id='dupCheckPolicyDetailsform:reportTypeListId_focus']/following::div[2]/span[@class='ui-icon ui-icon-triangle-1-s']";
	public static String setReportTypeCheckbox = "xpath#//ul[@class='ui-selectcheckboxmenu-items ui-selectcheckboxmenu-list ui-widget-content ui-widget ui-corner-all ui-helper-reset']/child::li/label[contains(text(),'%s')]";
	public static String setCaseAttributesCheckbox = "xpath#//ul[@class='ui-selectcheckboxmenu-items ui-selectcheckboxmenu-list ui-widget-content ui-widget ui-corner-all ui-helper-reset']/child::li/label[contains(text(),'%s')]";
	public static String statusandSourceRadioButton = "xpath#//table[contains(@id,'dupCheckPolicyDetailsform')]//child::label[contains(text(),'%s')]";
	public static String DefaultCheckbox = "xpath#//span[@id='dupCheckPolicyDetailsform:defautPanelGrp']//following::div[1]/span[@class='ui-chkbox-icon ui-icon ui-icon-blank ui-c']";
	public static String Addlevellink = "xpath#//div[@id='dupCheckPolicyDetailsform:AddDeletePanelGrid']/a[@id='dupCheckPolicyDetailsform:levelsAddLink']";
	public static String SelectLevelDropDown = "xpath#//select[@id='dupCheckPolicyDetailsform:dupLevelDataTable:0:A1-9129_input']";
	public static String ClickCaseAttributesDropDown = "xpath#//div[@id='dupCheckPolicyDetailsform:dupLevelDataTable:0:selectManyFields']/child::div[3]/span[@class='ui-icon ui-icon-triangle-1-s']";
	public static String CaseAttributeSelectSubjectID = "xpath#//div[@id='dupCheckPolicyDetailsform:dupLevelDataTable:0:selectManyFields_panel']/child::div[2]/ul/li/following::label[text()='Safety Report ID']";
	public static String AddRule_1Link= "xpath#//img[contains(@id,'dupCheckPolicyDetailsform:dupLevelDataTable:0')]";
	public static String AddConditions_1Link = "xpath#//a[contains(@id,'dupCheckPolicyDetailsform:dupLevelDataTable:0:dupRulesDataTable:0:j')]/img[contains(@id,'dupCheckPolicyDetailsform:dupLevelDataTable:0:dupRulesDataTable:0')]";
	public static String ConditionpopupOkbutton = "xpath#//span[contains(@id,'dupCheckPolicyDetailsform:dataTablePanelGrp')]//button/span[text()='OK']";
	public static String ActionTaken_1DropDown = "xpath#//label[@id='dupCheckPolicyDetailsform:dupLevelDataTable:0:dupRulesDataTable:0:actionToBeTakenId_label']/preceding::select[@id='dupCheckPolicyDetailsform:dupLevelDataTable:0:dupRulesDataTable:0:actionToBeTakenId_input']";
	public static String AddRule_2Link = "xpath#//a[contains(@id,'dupCheckPolicyDetailsform:dupLevelDataTable:0:dupRulesDataTable:0:rulesAddLink')]/img[contains(@id,'dupCheckPolicyDetailsform:dupLevelDataTable:0:dupRulesDataTable:0:')]";
	public static String AddConditions_2Link = "xpath#//a[contains(@id,'dupCheckPolicyDetailsform:dupLevelDataTable:0:dupRulesDataTable:1:j')]/img[contains(@id,'dupCheckPolicyDetailsform:dupLevelDataTable:0:dupRulesDataTable:1')]";
	public static String UnconditionalCheckbox = "xpath#//input[@id='dupCheckPolicyDetailsform:unconditionalId_input']/following::div/span";
	public static String ActionTaken_2DropDown  = "xpath#//label[@id='dupCheckPolicyDetailsform:dupLevelDataTable:0:dupRulesDataTable:1:actionToBeTakenId_label']/preceding::select[@id='dupCheckPolicyDetailsform:dupLevelDataTable:0:dupRulesDataTable:1:actionToBeTakenId_input']";
	public static String SaveButton = "xpath#//span[contains(text(),'Save')]";
	public static String validationPopup = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String popupOkButton = "xpath#//button[@id='mandatoryDialogform:okButton']//span[@class='ui-button-text ui-c'][contains(text(),'OK')]";
	public static String CancelButton = "xpath#//button[@id='dupCheckPolicyDetailsform:cancelId']//span[@class='ui-button-text ui-c'][contains(text(),'Cancel')]";
	public static String YesButton = "xpath#//driver.findElement(By.xpath(\"//button[@id='dupCheckPolicyDetailsform:j_id_ua']\")).click();";
	public static String keywordSearchTextbox = "xpath#//input[@id='DuplicateCheckListform:searchText']";
	public static String searchIcon = "xpath#//a[@id='DuplicateCheckListform:findButton']/img[contains(@id,'DuplicateCheckListform')]";
	public static String paginator = "xpath#//div[@id='DuplicateCheckListform:dupPolicy_paginator_top']/span[@class='ui-paginator-current']";
	public static String descriptionTextarea = "xpath#//textarea[@id='dupCheckPolicyDetailsform:regionDesc']";
	
	//Dushyanth Duplicate check policy
	public static String dupCheckSummaryTitle = "xpath#//div[@aria-describedby='dupCheckPolicyDailog']/div/span[@class='ui-dialog-title']";
	public static String assessedText = "xpath#//table[@id='listingTable']/tbody/tr/td[@class=' ADL_table_classified']";
	public static String assessedLink = "xpath#//table[@id='listingTable']/tbody/tr/td[@class=' ADL_table_classified']/a";
	
	//First count is header of the table
	public static String levelCount = "xpath#//div[@id='criteriaMatchingPanel']/div/table/tbody/tr";
	//First count is header of the table
	public static String levelCriteriaCaseFound = "xpath#//div[@id='criteriaMatchingPanel']/div/table/tbody/tr[%s]/td";
	public static String casesMatchingCount = "xpath#//div[@id='casesMatchingPanel']/div/span/label[@id='casesMatchingCount']";
	//First count is header of the table
	public static String casesMatchingtableRowCount = "xpath//div[@id='casesMatchingPanel']/div[@class='htmlPanelContent']/table/tbody/tr";
	
	
	/**********************************************************************************************************
	 * Objective:The below method is created to select the radio button by passing the label at runtime.
	 * Input Parameters: runTimeLabel
	 * Scenario Name Output
	 * Parameters:
	 * @author:DushyanthMahesh Date :26012021 Updated by and when   	 
	**********************************************************************************************************/
    public static String levelCriteriaCaseFound(String count) {
        String value = levelCriteriaCaseFound;
        String value2;
        value2 = value.replace("%s", count);
        return value2;
    }
	
	
	
	
	/**********************************************************************************************************
	 * Objective:The below method is created to select the radio button by passing the label at runtime.
	 * Input Parameters: runTimeLabel
	 * Scenario Name Output
	 * Parameters:
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when   	 
	**********************************************************************************************************/
    public static String selectRadioButton(String runTimeLabel) {
        String value = statusandSourceRadioButton;
        String value2;
        value2 = value.replace("%s", runTimeLabel);
        return value2;
    }
	/**********************************************************************************************************
	 * Objective:The below method is created to set reportType by passing the value at runtime.
	 * Input Parameters: runTimeLabel
	 * Scenario Name Output
	 * Parameters:
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when   	 
	**********************************************************************************************************/
    public static String setreportType(String runTimeLabel) {
        String value = setReportTypeCheckbox;
        String value2;
        value2 = value.replace("%s", runTimeLabel);
        return value2;
    }
	/**********************************************************************************************************
	 * Objective:The below method is created to set caseAttributes by passing the value at runtime.
	 * Input Parameters: runTimeLabel
	 * Scenario Name Output
	 * Parameters:
	 * @author:Avinash K Date :12-Jul-2019 Updated by and when   	 
	**********************************************************************************************************/
    public static String setcaseAttributes(String runTimeLabel) {
        String value = setCaseAttributesCheckbox;
        String value2;
        value2 = value.replace("%s", runTimeLabel);
        return value2;
    }
}
