package com.arisglobal.framework.components.lsmv.L10_3;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_CausalityPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_EventsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_LabellingPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_StudyLookUpPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_StudyPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_Labelling extends ToolManager {
	static String className = FDE_Labelling.class.getSimpleName();
	static String studySheet = FDE_Study.class.getSimpleName();
	static String eventsSheet = FDE_Events.class.getSimpleName();
	static String casualitySheet = FDE_Causality.class.getSimpleName();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: To get Blinded product list
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 28-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void getBlindedProducts() {
		agClick(FDE_LabellingPageObjects.blindedButton);
		agAssertExists(FDE_LabellingPageObjects.unblindedButton);
		if (agIsVisible(FDE_LabellingPageObjects.unblindedButton)) {

			clickBlindedDropDown();
		}
	}

	/**********************************************************************************************************
	 * @Objective: To click Blinded DropDown
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 28-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickBlindedDropDown() {
		agClick(FDE_LabellingPageObjects.productDropdown);
		List<WebElement> list = agGetElementList(FDE_LabellingPageObjects.productList);
		for (int i = 1; i <= list.size(); i++) {
			Reports.ExtentReportLog("Blinded and Normal Products", Status.INFO,
					"" + agGetText(FDE_LabellingPageObjects.productGetText(Integer.toString(i))), true);
			System.out.println(agGetText(FDE_LabellingPageObjects.productGetText(Integer.toString(i))));
		}
		agClick(FDE_LabellingPageObjects.productDropdown);
	}

	/**********************************************************************************************************
	 * @Objective: click Unblinded DropDown
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 28-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickUnblindedDropDown() {
		agClick(FDE_LabellingPageObjects.productDropdown);
		List<WebElement> list = agGetElementList(FDE_LabellingPageObjects.productList);
		for (int i = 1; i <= list.size(); i++) {
			Reports.ExtentReportLog("Unblinded and Normal Products", Status.INFO,
					"" + agGetText(FDE_LabellingPageObjects.productGetText(Integer.toString(i))), true);
			System.out.println(agGetText(FDE_LabellingPageObjects.productGetText(Integer.toString(i))));
		}
		agClick(FDE_LabellingPageObjects.productDropdown);
	}

	/**********************************************************************************************************
	 * @Objective: To get UnBlinded product list
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 28-Aug-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void getUnblindedProducts() {
		// agClick(FDE_LabellingPageObjects.unblindedButton);
		agAssertExists(FDE_LabellingPageObjects.blindedButton);
		if (agIsVisible(FDE_LabellingPageObjects.blindedButton)) {
			clickUnblindedDropDown();
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Check/Uncheck Operation on
	 *             CheckBox under Specified Label
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author: Avinash
	 * @Date : 30-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCheckBox(String label, String boolCheck) {
		if (!label.trim().contains("#skip#") && !boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = agGetAttribute("class", FDE_LabellingPageObjects.checkBoxUnder(label));
			if (boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check")) {
				if (!checkBoxStatus.contains("ui-state-active")) {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is not checked", true);
				} else {
					Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is checked", false);
				}
			} else if (boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck")) {
				if (checkBoxStatus.contains("ui-state-active")) {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : Checkbox is checked", true);
				} else {
					Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : Checkbox is not checked", false);
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: To Verify SUSAR Checkbox
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 30-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifySUSARCheckLabelling(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		CommonOperations.takeScreenShot();
		verifyCheckBox(FDE_LabellingPageObjects.SUSAR_CheckBox, getTestDataCellValue(scenarioName, "Labelling_SUSAR"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: To Verify Auto Labelling
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 27-Jan-2020
	 * @UpdatedByAndWhen:praveen patil 17-03-2021
	 **********************************************************************************************************/

	public static void verifylabellingData(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(FDE_LabellingPageObjects.labellingData(getTestDataCellValue(scenarioName, "ReportedTerm"),
				getTestDataCellValue(scenarioName, "Country"), getTestDataCellValue(scenarioName, "Labeling")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Auto Labelling Verified", true);
	}

	/**********************************************************************************************************
	 * @Objective: To select Reporter term
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Avinash K
	 * @Date : 11-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void selectReporterTerm(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_LabellingPageObjects.clickReporterTerm_Dropdown);
		agClick(FDE_LabellingPageObjects.selectReporterTerm(getTestDataCellValue(scenarioName, "ReportedTerm")));
		Reports.ExtentReportLog("", Status.INFO, "Reporter Term", true);
		agClick(FDE_LabellingPageObjects.clickReporterTerm_Dropdown);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Check/Uncheck Operation on
	 *             CheckBox.
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author:Yashwanth Naidu
	 * @Date : 5-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void checkManualCheckBox(String label, String boolCheck) {
		if (!boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = null;
			checkBoxStatus = ToolManager.agGetAttribute("class", FDE_LabellingPageObjects.checkSusarManual(label));
			if (checkBoxStatus.contains("blank") || !checkBoxStatus.contains("pi-check")) {
				checkBoxStatus = "false";
			} else {
				checkBoxStatus = "true";
			}
			if ((boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check"))
					&& checkBoxStatus.equalsIgnoreCase("false")) {
				ToolManager.agJavaScriptExecuctorClick(FDE_LabellingPageObjects.checkSusarManual(label));
			} else if ((boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck"))
					&& checkBoxStatus.equalsIgnoreCase("true")) {
				ToolManager.agJavaScriptExecuctorClick(FDE_LabellingPageObjects.checkSusarManual(label));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to perform Check/Uncheck Operation on
	 *             CheckBox.
	 * @InputParameters: label, boolCheck
	 * @OutputParameters:NA
	 * @author:Yashwanth Naidu
	 * @Date : 5-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void checkSasurCheckBox(String label, String boolCheck) {
		if (!boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = null;
			checkBoxStatus = ToolManager.agGetAttribute("class", FDE_LabellingPageObjects.checkBoxUnder(label));
			if (checkBoxStatus.contains("blank") || !checkBoxStatus.contains("pi-check")) {
				checkBoxStatus = "false";
			} else {
				checkBoxStatus = "true";
			}
			if ((boolCheck.equalsIgnoreCase("true") || boolCheck.equalsIgnoreCase("check"))
					&& checkBoxStatus.equalsIgnoreCase("false")) {
				ToolManager.agClick(FDE_LabellingPageObjects.ManualCheckBoxUnder(label));
				ToolManager.agClick(FDE_LabellingPageObjects.checkBoxUnder(label));
			} else if ((boolCheck.equalsIgnoreCase("false") || boolCheck.equalsIgnoreCase("uncheck"))
					&& checkBoxStatus.equalsIgnoreCase("true")) {
				ToolManager.agClick(FDE_LabellingPageObjects.checkBoxUnder(label));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set data in Labelling Tab tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Yashwanth Naidu
	 * @Date : 01-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void set_Labelling(String scenarioName) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,
		// "ConfigurationSettings");
		// if (getTestDataCellValue(scenarioName,
		// "FDE_Labelling").equalsIgnoreCase("Yes")) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_LabellingPageObjects.addButton);
		agClick(FDE_LabellingPageObjects.clickAddedNewTermDropdown);
		agClick(FDE_LabellingPageObjects.selectAddedTerm(getTestDataCellValue(scenarioName, "ReportedTerm")));
		agSetStepExecutionDelay("10000");
		agClick(FDE_LabellingPageObjects.clickCountryDropdown);
		agClick(FDE_LabellingPageObjects.CountrySelect(getTestDataCellValue(scenarioName, "Country")));
		agClick(FDE_LabellingPageObjects.clicklabelingDropdown);
		agClick(FDE_LabellingPageObjects.selectLabeling(getTestDataCellValue(scenarioName, "Labeling")));
		agSetStepExecutionDelay("10000");
		checkManualCheckBox(FDE_LabellingPageObjects.manual_Checkbx,
				getTestDataCellValue(scenarioName, "SUSAR_Manual"));
		checkSasurCheckBox(FDE_LabellingPageObjects.SUSAR_CheckBox,
				getTestDataCellValue(scenarioName, "Labelling_SUSAR"));
		if(scenarioName.equalsIgnoreCase("LSMV_OQ_QBE_Search_1_2") || scenarioName.equalsIgnoreCase("LSMV_OQ_QBE_Search_2_2" )) {
			status = agIsVisible(FDE_LabellingPageObjects.labelingDDValue);
			if(status) {
				agSetStepExecutionDelay("5000");
				CommonOperations.captureScreenShot(true);
			}		
		}
		// }
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Delete in Labelling Tab
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 17-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void Delete_Labelling(String scenarioName) {
		if (agIsVisible(FDE_LabellingPageObjects.RadioBtn) == true) {
			agClick(FDE_LabellingPageObjects.RadioBtn);
			agClick(FDE_LabellingPageObjects.deleteBtn);
			agWaitTillVisibilityOfElement(FDE_LabellingPageObjects.YesBtn);
			agClick(FDE_LabellingPageObjects.YesBtn);

		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to get the text from labeling
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 24-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getLabelingText(String indexcount) {
		String unlabelled = agGetText(FDE_LabellingPageObjects.indexCount(indexcount));
		return unlabelled;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to get the text from Company
	 *             Causality
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 24-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getCompanyCasualityText(String indexcount) {
		String companyCasuality = agGetText(FDE_CausalityPageObjects.indexCount(indexcount));
		return companyCasuality;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify the SUSAR in Labeling based
	 *             on the below conditions Event Serious=Yes,Study
	 *             type=CT,Labeling=Unlabeled,Company Causality=Reasonable
	 *             possibility
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 03-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySUSARinLabelling(String indexcount) {
		Reports.ExtentReportLog("", Status.INFO, "SUSAR Labelling verification started", true);
		try {
			FDE_Operations.tabNavigation("Study");
			if (agIsVisible(FDE_StudyPageObjects.studyConfirmationPopUp_Message) == true) {
				FDE_Study.handleValidationMessageforNonStudy();
			}
			String clinicalTrial = agGetText(
					FDE_StudyPageObjects.get_DropDownValue(FDE_StudyPageObjects.studyType_DropDown));
			Reports.ExtentReportLog("", Status.INFO, "Study Type Dropdown :" + clinicalTrial, true);
			System.out.println(clinicalTrial);
			FDE_Operations.tabNavigation("Labeling");
			if (agIsVisible(FDE_LabellingPageObjects.indexCount(indexcount)) == true) {
				getLabelingText(indexcount);
				Reports.ExtentReportLog("", Status.INFO, "Labelling is :" + getLabelingText(indexcount), true);
			} else {
				Reports.ExtentReportLog("", Status.INFO, "Event in Labelling is not visible :", true);
			}
			String unlabelled = getLabelingText(indexcount);
			FDE_Operations.tabNavigation("Causality");
			if (agIsVisible(FDE_CausalityPageObjects.companyCasuality) == true) {
				getCompanyCasualityText(indexcount);
				Reports.ExtentReportLog("", Status.INFO,
						"Company Casuality is  :" + getCompanyCasualityText(indexcount), true);
			} else {
				Reports.ExtentReportLog("", Status.INFO, "Event in Company Casuality is not Visible :", true);
			}
			String companyCasuality = getCompanyCasualityText(indexcount);
			FDE_Operations.tabNavigation("Event(s)");
			agJavaScriptExecuctorScrollToElement(FDE_EventsPageObjects.aeAdditionalInfoLabel);
			status = agIsVisible(
					FDE_EventsPageObjects.radioBtnVerification(FDE_EventsPageObjects.seriousness_Radiobtn));
			CommonOperations.takeScreenShot();
			FDE_Operations.tabNavigation("Labeling");
			agSetStepExecutionDelay("3000");
			if (unlabelled.equalsIgnoreCase("Unlabeled") && companyCasuality.equalsIgnoreCase("Reasonable possibility")
					&& clinicalTrial.equalsIgnoreCase("Clinical Trials") && status) {
				boolean susarCheck = agIsVisible(FDE_LabellingPageObjects.SusarCheckBoxChecked);
				if (susarCheck) {
					Reports.ExtentReportLog("", Status.PASS, "SUSAR Check box checked", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "SUSAR Check box not checked", true);
				}
			} else {
				boolean susarCheck = agIsVisible(FDE_LabellingPageObjects.SusarCheckBoxChecked);
				if (susarCheck) {
					Reports.ExtentReportLog("", Status.FAIL, "SUSAR Check box checked", true);
				} else {
					Reports.ExtentReportLog("", Status.PASS, "SUSAR Check box not checked", true);
				}
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "SUSAR Check box verification in labelling is not verified" + e,
					true);
		}
		Reports.ExtentReportLog("", Status.INFO, "SUSAR Labelling verification ended", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Check/Uncheck Operation
	 *             from the application
	 * @InputParameters: label
	 * @OutputParameters:NA
	 * @author: Pooja S
	 * @Date : 10-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verificationOfCheckBox(String label) {
		if (!label.trim().contains("#skip#")) {
			String checkBoxStatus = agGetAttribute("class", FDE_LabellingPageObjects.checkBoxUnder(label));
			if (checkBoxStatus.contains("ui-state-active")) {
				Reports.ExtentReportLog("Checkbox", Status.PASS, label + " : SUSAR Checkbox is checked", true);
			} else {
				Reports.ExtentReportLog("Checkbox", Status.FAIL, label + " : SUSAR Checkbox is not checked", true);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is Verify rollover from SUSAR field from
	 *             labelling to SUSAR in general screen for each reaction upon save,
	 *             import and export of the case.
	 * @InputParameters: label
	 * @OutputParameters:NA
	 * @author: WajahatUmar S
	 * @Date : 22-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyRolloverSusarFieldFromLabelingtoGeneral() {
		Reports.ExtentReportLog("", Status.INFO, "verify Rollover Susar Field From Labeling to General Begins", true);
		try {
			FDE_Operations.tabNavigation("Labeling");
			agSetStepExecutionDelay("3000");
			if (agIsVisible(FDE_LabellingPageObjects.SusarCheckBoxChecked) == true) {
				Reports.ExtentReportLog("", Status.PASS, "Susar is Checked in Labelling Tab", true);
				FDE_Operations.tabNavigation("General");
				agSetStepExecutionDelay("3000");
				if (agIsVisible(FDE_GeneralPageObjects.SusarCheckBoxSelected) == true) {
					agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.SusarCheckBoxSelected);
					Reports.ExtentReportLog("", Status.PASS, "Susar is Selected in General TAB", true);
				} else {
					Reports.ExtentReportLog("", Status.INFO, "Susar is not Selected in General TAB", true);
				}

			} else {
				Reports.ExtentReportLog("", Status.INFO, "Susar is not Selected in Labelling TAB", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "verify Rollover Susar Field From Labeling to General Fails",
					true);
		}
		Reports.ExtentReportLog("", Status.INFO, "verify Rollover Susar Field From Labeling to General Begins", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify Codelist tags in Labelling tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 19-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyLabellingCodeList() {
		Reports.ExtentReportLog("", Status.INFO, "********Labelling Codelist tag verification Started*******", true);
		agAssertVisible(FDE_LabellingPageObjects.CLCountry);
		agAssertVisible(FDE_LabellingPageObjects.CLLabelling);
		Reports.ExtentReportLog("", Status.INFO, "********Labelling Codelist tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify DSUR is exist in country inLabelling tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addAndVerifyDSURCountryLabeling(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// agClick(FDE_LabellingPageObjects.labelingNextProduct);
		agSetStepExecutionDelay("3000");
		if (getTestDataCellValue(scenarioName, "ReportedTermFlag").equalsIgnoreCase("YES")) {
			agClick(FDE_LabellingPageObjects.addButton);
			// setCountryAndLabellingForDSUR(scenarioName);
			agClick(FDE_LabellingPageObjects.addNewReportTermDD);
			agClick(FDE_LabellingPageObjects.addNewReportedTerm(getTestDataCellValue(scenarioName, "ReportedTerm")));
		}
//		if (scenarioName.equalsIgnoreCase("ConfigureDSURCodelist_1")) {
//			seletctCountryAndLabellingForDSUR(scenarioName);
//		} else {
			setCountryAndLabellingForDSUR(scenarioName);
//		}

	}

	/**********************************************************************************************************
	 * @Objective: Created to add country and lebeling data
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 03-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCountryAndLabellingForDSUR(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_LabellingPageObjects.CountryDropdown);
		agClick(FDE_LabellingPageObjects.selectCountry(getTestDataCellValue(scenarioName, "Country")));
		agClick(FDE_LabellingPageObjects.labellingDropdown);
		agClick(FDE_LabellingPageObjects.selectLabeling(getTestDataCellValue(scenarioName, "Labeling")));
		agIsVisible(FDE_LabellingPageObjects.countryDSUR);
		CommonOperations.captureScreenShot(true);
	}

	public static void seletctCountryAndLabellingForDSUR(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_LabellingPageObjects.CountryDropdown);
		agClick(FDE_LabellingPageObjects.selectSecondCountry(getTestDataCellValue(scenarioName, "Country")));
		agClick(FDE_LabellingPageObjects.labellingSecondDropdown);
		agClick(FDE_LabellingPageObjects.selectsecondLabeling(getTestDataCellValue(scenarioName, "Labeling")));
		agIsVisible(FDE_LabellingPageObjects.countryDSUR);
		CommonOperations.captureScreenShot(true);
	}
	
	

	public static void ClickOnBlinded() {
		status = agIsVisible(FDE_LabellingPageObjects.blindedButton);
		if (status) {
			agJavaScriptExecuctorClick(FDE_LabellingPageObjects.blindedButton);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verify Manual SUSAR
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySUSARManual(String scenarioName) {
		try {
			CaseListingOperations.searchCaseAndEdit(scenarioName, "lsmv_wpa_controller", "Receipt_Number");
			Reports.ExtentReportLog("", Status.INFO, "SUSAR Manual Verification Starts", false);
			FDE_Operations.tabNavigation("Labeling");
			agWaitTillVisibilityOfElement(FDE_LabellingPageObjects.NextProduct);
			int productCount = Integer.parseInt(
					agGetText(FDE_LabellingPageObjects.productCount).replace("[", "").replace("]", "").trim());

			for (int productIndex = 1; productIndex <= productCount; productIndex++) {
				if (productIndex != 1) {
					agClick(FDE_LabellingPageObjects.NextProduct);
				}
				int eventCount = agGetElementList(FDE_LabellingPageObjects.SUSAREventCount).size();
				for (int eventIndex = 1; eventIndex <= eventCount; eventIndex++) {
					String country = agGetText(FDE_LabellingPageObjects.SUSARCountry.replace("%s", eventIndex + ""));
					if (!country.equalsIgnoreCase("IB")) {
						Reports.ExtentReportLog("", Status.INFO, "SUSAR Not Eligible", false);
						continue;
					}
					boolean SUSARDisbaled = dibaledOrEnabled(FDE_LabellingPageObjects
							.ManualSUSARCheckBox(FDE_LabellingPageObjects.SUSARChkBox, eventIndex), "Disabled");
					boolean SUSARChecked = dibaledOrEnabled(FDE_LabellingPageObjects
							.ManualSUSARCheckBox(FDE_LabellingPageObjects.SUSARChkBox, eventIndex), "Checked");
					agClick(FDE_LabellingPageObjects.ManualSUSARCheckBox(FDE_LabellingPageObjects.ManualSUSARCheckBox,
							eventIndex));
					boolean SUSARDisbaledAfterManual = dibaledOrEnabled(FDE_LabellingPageObjects
							.ManualSUSARCheckBox(FDE_LabellingPageObjects.SUSARChkBox, eventIndex), "Disabled");
					agClick(FDE_LabellingPageObjects.ManualSUSARCheckBox(FDE_LabellingPageObjects.SUSARChkBox,
							eventIndex));
					boolean SUSARCheckedafterManual = dibaledOrEnabled(FDE_LabellingPageObjects
							.ManualSUSARCheckBox(FDE_LabellingPageObjects.SUSARChkBox, eventIndex), "Checked");

					if (SUSARDisbaled) {
						if (!SUSARDisbaledAfterManual) {
							if (SUSARChecked) {
								if (!SUSARCheckedafterManual)
									Reports.ExtentReportLog("", Status.PASS, "SUSAR Manual Verification is sucessfull",
											true);
								else
									Reports.ExtentReportLog("", Status.FAIL,
											"SUSAR Manual Verification is unsucessfull", true);
							} else {
								if (SUSARCheckedafterManual)
									Reports.ExtentReportLog("", Status.PASS, "SUSAR Manual Verification is sucessfull",
											true);
								else
									Reports.ExtentReportLog("", Status.FAIL,
											"SUSAR Manual Verification is unsucessfull", true);
							}

						} else {
							Reports.ExtentReportLog("", Status.PASS, "SUSAR Manual Verification is unsucessfull", true);
						}
					} else {
						if (SUSARDisbaledAfterManual) {
							if (SUSARChecked) {
								if (!SUSARCheckedafterManual)
									Reports.ExtentReportLog("", Status.PASS, "SUSAR Manual Verification is sucessfull",
											true);
								else
									Reports.ExtentReportLog("", Status.FAIL,
											"SUSAR Manual Verification is unsucessfull", true);
							} else {
								if (SUSARCheckedafterManual)
									Reports.ExtentReportLog("", Status.PASS, "SUSAR Manual Verification is sucessfull",
											true);
								else
									Reports.ExtentReportLog("", Status.FAIL,
											"SUSAR Manual Verification is unsucessfull", true);
							}

						} else {
							Reports.ExtentReportLog("", Status.PASS, "SUSAR Manual Verification is unsucessfull", true);
						}
					}

				}
			}

			Reports.ExtentReportLog("", Status.INFO, "SUSAR Manual Verification Ends", false);

		} catch (Exception ex) {
			System.out.println(ex);
			Reports.ExtentReportLog("", Status.FAIL, "SUSAR Manual Verification Failed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verify Check box is disbaled or checked
	 * @OutputParameters:
	 * @author: Karthikeyan Natarajan
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean dibaledOrEnabled(String locator, String disbaledOrdEnabled) {
		boolean value = false;
		String attributeClass = agGetAttribute("class", locator);
		if (disbaledOrdEnabled.equalsIgnoreCase("Disabled")) {
			if (attributeClass.contains("disabled")) {
				value = true;
			} else
				value = false;
		} else if (disbaledOrdEnabled.equalsIgnoreCase("Checked")) {
			if (attributeClass.contains("ui-state-active")) {
				value = true;
			} else
				value = false;
		}
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: Set country and labeling data
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setProductLabelling(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Susar")) {
			agIsVisible(FDE_LabellingPageObjects.blindedButton);
			agClick(FDE_LabellingPageObjects.blindedButton);
		} else if (scenarioName.equalsIgnoreCase("DSUREnhancementCaseSeries_Susar1")) {
			agIsVisible(FDE_LabellingPageObjects.unblindedButton);
			agClick(FDE_LabellingPageObjects.unblindedButton);
		}
		agClick(FDE_LabellingPageObjects.labelingProductClick);
		agClick(FDE_LabellingPageObjects.labelingProduct(getTestDataCellValue(scenarioName, "ProductLabeling")));

		agClick(FDE_LabellingPageObjects.addButton);
		agClick(FDE_LabellingPageObjects.addNewReportTermDD);
		agClick(FDE_LabellingPageObjects.addNewReportedTerm(getTestDataCellValue(scenarioName, "ReportedTerm")));
		agSetStepExecutionDelay("2000");
		agClick(FDE_LabellingPageObjects.CountryDropdown);
		agClick(FDE_LabellingPageObjects.selectCountry(getTestDataCellValue(scenarioName, "Country")));
		agClick(FDE_LabellingPageObjects.labellingDropdown);
		agClick(FDE_LabellingPageObjects.selectLabeling(getTestDataCellValue(scenarioName, "Labeling")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: Below method is created to select product labeling
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 16-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void SelectProductLabeling(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(FDE_LabellingPageObjects.labelingProductClick);
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorClick(FDE_LabellingPageObjects.labelingProduct(getTestDataCellValue(scenarioName, "ProductLabeling")));
	}

	/**********************************************************************************************************
	 * @Objective: Below method is created to verify auto labeling
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 16-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyautolabellingData(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		status = agIsVisible(FDE_LabellingPageObjects.labellingData(getTestDataCellValue(scenarioName, "ReportedTerm"),
				getTestDataCellValue(scenarioName, "Country"), getTestDataCellValue(scenarioName, "Labeling")));
		if (status) {
			
			Reports.ExtentReportLog("", Status.FAIL, "The Automatic labeling records are created", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
			Reports.ExtentReportLog("", Status.INFO,"<br />"+ "The Automatic labeling records are not created", false);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: To Verify Labeling
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: Shamanth Somegowda
	 * @Date : 05-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyMRLabellingData(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(FDE_LabellingPageObjects.labellingData(getTestDataCellValue(scenarioName, "ReportedTerm"),
				getTestDataCellValue(scenarioName, "Country"), getTestDataCellValue(scenarioName, "Labeling")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: To Verify Labeling
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 07-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void VerifyCountry_Labelling(String Susar) {

		if (Susar.equalsIgnoreCase("Susar")) {
			String Country = agGetText(FDE_LabellingPageObjects.CountryDD);
			String UnLabellingDD = agGetText(FDE_LabellingPageObjects.UnlabellingDD);
			if (Country.equalsIgnoreCase("CUBA ( CUB )") && UnLabellingDD.equalsIgnoreCase("UnLabeled")) {
				Reports.ExtentReportLog("", Status.PASS,
						"As Expected"+
						"<br />"+"Labeling record as Country:CUBA" +
						"<br />"+"Labeling: UnLabelled", true);
			}
		} else if (Susar.equalsIgnoreCase("Susar-NoLabel")) {
			if (agIsVisible(FDE_LabellingPageObjects.clickCountryDropdown) == true) {
				Reports.ExtentReportLog("", Status.PASS,
						"<br />"+"As Expected", true);

			}
		} else if(Susar.equalsIgnoreCase("")){
			String LabellingDD = agGetText(FDE_LabellingPageObjects.LabellingDD);
			if (LabellingDD.equalsIgnoreCase("Labeled")) {
				Reports.ExtentReportLog("", Status.PASS, "As Expected"+
						"<br />"+ "Labeling record as Country:CUBA" +
						"<br />"+ "Labeling: Labelled <br/>", true);
			}

		}else if(Susar.equalsIgnoreCase("Non-Susar")) {
			String LabellingDD = agGetText(FDE_LabellingPageObjects.LabellingDD);
			if (LabellingDD.equalsIgnoreCase("Labeled")) {
				Reports.ExtentReportLog("", Status.PASS, "As Expected"+
						"<br />"+ "ABC-Cancer", true);
			}
		}
	}
	/**********************************************************************************************************
	 * @Objective: To Verify Labeling
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 08-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void VerifySusarInLabellingGeneralScreen(String scenarioName) {
		FDE_Operations.tabNavigation("Labeling");

		if (agIsVisible(FDE_LabellingPageObjects.CheckBoxSusarLabellingScreen) == true) {
			CommonOperations.captureScreenShot(true);
			FDE_Operations.tabNavigation("General");
			agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.SUSAR_Label);
			if (agIsVisible(FDE_LabellingPageObjects.CheckBoxSUsarGeneralScreen) == true) {
				Reports.ExtentReportLog("", Status.PASS,
						"<br />"+"As Expected",
						true);
			}
		} else {
			FDE_Operations.tabNavigation("General");
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
			agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.caseReportlabel);

			FDE_General.setDropDownValue(FDE_GeneralPageObjects.reportType_Dropdown, scenarioName,
					"Gen_CaseReport_ReportType");
			agWaitTillVisibilityOfElement(FDE_GeneralPageObjects.Confirmation_Text);

			agClick(FDE_GeneralPageObjects.ConfirmationYes_Btn);
			agSetStepExecutionDelay("2000");

			FDE_Operations.tabNavigation("Study");
			FDE_Study.handleValidationMessage();
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Study");
			if (getTestDataCellValue(scenarioName, "Study_StudyInformation_ProtocolNo_Lookup")
					.equalsIgnoreCase("Yes")) {
				agClick(FDE_StudyPageObjects.protocolNo_Lookup);
				agSetStepExecutionDelay("3000");
				agWaitTillVisibilityOfElement(FDE_GeneralPageObjects.Confirmation_Text);

				agClick(FDE_GeneralPageObjects.ConfirmationYes_Btn);
				agSetStepExecutionDelay("2000");
				// agSetValue(FDE_StudyLookUpPageObjects.projectNo_TextField,
				// getTestDataCellValue(scenarioName, "Study_StudyInformation_ProjectNo"));
				agSetValue(FDE_StudyLookUpPageObjects.studyNo_TextField,
						getTestDataCellValue(scenarioName, "Study_StudyLookup_StudyNo"));
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				agClick(FDE_StudyLookUpPageObjects.search_button);
				agSetStepExecutionDelay("4000");
				agClick(FDE_StudyLookUpPageObjects
						.radioButton(getTestDataCellValue(scenarioName, "Study_StudyLookup_StudyNo")));
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				Reports.ExtentReportLog("", Status.INFO,
						"Data Selected in Study >> Study Protocol LookUp Windpw : Scenario Name::" + scenarioName,
						true);
				agClick(FDE_StudyLookUpPageObjects.ok_button);
			}
			FDE_Operations.tabNavigation("Labeling");
			agSetStepExecutionDelay("3000");
			agClick(FDE_LabellingPageObjects.addAllEvents_Btn);
			agClick(FDE_LabellingPageObjects.clickCountryDropdown);
			agClick(FDE_LabellingPageObjects.CountrySelect("IB "));
			agClick(FDE_LabellingPageObjects.clicklabelingDropdown);
			agClick(FDE_LabellingPageObjects.selectLabeling("Unlabeled "));
			FDE_Operations.saveCase();
			FDE_Operations.clickSaveOKBtn();

			// if (agIsVisible(FDE_LabellingPageObjects.ManualCheckBoxChecked) == true) {
			//
			// } else {
			// agClick(FDE_LabellingPageObjects.ManualCheckBoxUnChecked);
			// }

		}

	}

	/**********************************************************************************************************
	 * @Objective: To Verify Labeling
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 11-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void VerifyManualCheckBoxExistforSUSAR() {
		if (agIsVisible(FDE_LabellingPageObjects.checkSusarManual(FDE_LabellingPageObjects.manual_Checkbx)) == true) {

			Reports.ExtentReportLog("", Status.PASS,
					"SUSAR Manual CheckBox is Present", true);
			agClick(FDE_LabellingPageObjects.checkSusarManual(FDE_LabellingPageObjects.manual_Checkbx));
			if (agIsVisible(FDE_LabellingPageObjects.SusarCheckBoxChecked) == true) {
				
			}else {
				
			
			agJavaScriptExecuctorClick(FDE_LabellingPageObjects.SUSARChkBox);
			Reports.ExtentReportLog("", Status.PASS,
					"SUSAR Checkbox is Checked and Verified as Editable", true);
			//agClick(FDE_LabellingPageObjects.SUSARChkBox);
			}
			
			} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"SUSAR Manual CheckBox is not Present", true);

		}

	}

	/**********************************************************************************************************
	 * @Objective: To Verify Labeling
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 11-Jan-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void VerifyManualCheckBoxNotExistforSUSAR() {
		if (!agIsVisible(FDE_LabellingPageObjects.checkSusarManual(FDE_LabellingPageObjects.manual_Checkbx)) == true) {

			Reports.ExtentReportLog("", Status.PASS,
					"SUSAR Manual CheckBox is Not Present", true);	
			
		
			
			if (agIsVisible(FDE_LabellingPageObjects.SusarCheckBoxChecked) == true) {
				Reports.ExtentReportLog("", Status.FAIL,
						"SUSAR Checkbox is Non-Editable", true);
			}else {
			Reports.ExtentReportLog("", Status.PASS,
					"SUSAR Checkbox is Non-Editable", true);
			}
			
			} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"SUSAR Manual CheckBox is Present", true);

		}

	}
	
	public static void set_LabellingData(String scenarioName , int i) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(FDE_LabellingPageObjects.addButton);
		agClick(FDE_LabellingPageObjects.clickAddedNewTermDropdown);
		agClick(FDE_LabellingPageObjects.selectAddedTerm(getTestDataCellValue(scenarioName, "ReportedTerm")));
		agSetStepExecutionDelay("10000");
		agClick(FDE_LabellingPageObjects.clickCountryDropdown);
		if(i==1) {
			
			agClick(FDE_LabellingPageObjects.CountrySelect(getTestDataCellValue(scenarioName, "Country")));
		}else {
			agClick(FDE_LabellingPageObjects.selectSecondCountry(getTestDataCellValue(scenarioName, "Country")));
		}
		agClick(FDE_LabellingPageObjects.clicklabelingDropdown);
		if(i==1) {
			agClick(FDE_LabellingPageObjects.selectLabeling(getTestDataCellValue(scenarioName, "Labeling")));
		}else {
			agClick(FDE_LabellingPageObjects.selectsecondLabeling(getTestDataCellValue(scenarioName, "Labeling")));
		}	
		checkManualCheckBox(FDE_LabellingPageObjects.manual_Checkbx,
				getTestDataCellValue(scenarioName, "SUSAR_Manual"));
		checkSasurCheckBox(FDE_LabellingPageObjects.SUSAR_CheckBox,
				getTestDataCellValue(scenarioName, "Labelling_SUSAR"));
		if(getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}
	}

	public static void nextProduct() {
		agClick(FDE_LabellingPageObjects.nextProduct);
		agSetStepExecutionDelay("3000");
	}
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to verify whether any labeling details is displayed in the table
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 23-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyAutoProductLabelling(String scenarioName) {
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
		
		//agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.defaultDueDate_Label);
		agMouseHover(FDE_LabellingPageObjects.label_tag);
		
		String boolAutoProductLabelling =getTestDataCellValue(scenarioName, "AutoProductLabeling");
		if(boolAutoProductLabelling.equalsIgnoreCase("true"))
		{
			status = agIsVisible(FDE_LabellingPageObjects.autoProductLabel_Table);
		
			if (status) {
			
			Reports.ExtentReportLog("", Status.PASS, "The Auto Product labeling records are displayed", true);
		} else 
		{
			Reports.ExtentReportLog("", Status.FAIL, "The Auto Product labeling records are not displayed though flag is checked at App Parametre", true);
			
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
		
		else
		{
			status = agIsVisible(FDE_LabellingPageObjects.autoProductLabel_Table);
		
			if (status) {
			
				Reports.ExtentReportLog("", Status.FAIL, "The Auto Product labeling records are displayed though flag is checked at App Parametre", true);	
			
		} else {
			Reports.ExtentReportLog("", Status.PASS, "The Auto Product labeling records are not displayed", true);
			
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}
	}
	
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to verify whether any default labeling details is displayed in the table
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 23-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDefaultLabelling(String scenarioName) {
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "AppParameters_CaseManagement");
		
		//agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.defaultDueDate_Label);
		agMouseHover(FDE_LabellingPageObjects.label_tag);
		
		String valueDefaultLabeling =getTestDataCellValue(scenarioName, "DefaultLabeling");
		
		if(valueDefaultLabeling.equalsIgnoreCase("Blank"))
		{
			//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if(agIsVisible(FDE_LabellingPageObjects.labellingData("CORE", "--Select--")))
			{
				Reports.ExtentReportLog("", Status.PASS, "The Default labeling displayed as Blank", true);
			}
			
			else
			{
				Reports.ExtentReportLog("", Status.FAIL, "The Default labeling not displayed as Blank though at App Parametre it is set to Blank", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			
		}	
		
		else if(valueDefaultLabeling.equalsIgnoreCase("Unlabeled"))
		{
			//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if(agIsVisible(FDE_LabellingPageObjects.labellingData("CORE", "Unlabeled")))
			{
				Reports.ExtentReportLog("", Status.PASS, "The Default labeling displayed as Unlabeled", true);
			}
			
			else
			{
				Reports.ExtentReportLog("", Status.FAIL, "The Default labeling not displayed as Unlabeled though at App Parametre it is set to Unlabeled", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			
		}

	}
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to verify whether Default Core labeling for Clinical Trial case is displayed in the table
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 24-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDefaultCoreLabelling_CT(String scenarioName, String sheetname, String columnName) {
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetname);
		
		//agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.defaultDueDate_Label);
		agMouseHover(FDE_LabellingPageObjects.label_tag);
		
		String valueDefaultLabeling =getTestDataCellValue(scenarioName, columnName);
		
		if(valueDefaultLabeling.equalsIgnoreCase("True"))
		{
			//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if(agIsVisible(FDE_LabellingPageObjects.labellingData("CORE")))
			{
				Reports.ExtentReportLog("", Status.PASS, "The Default Core labeling is displayed for Clinical Trial Case", true);
			}
			
			else
			{
				Reports.ExtentReportLog("", Status.FAIL, "The Default Core labeling is not displayed though at App Parametre it is checked for Clinical Trial Case", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			
		}	
		
		else
		{
			//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if(agIsVisible(FDE_LabellingPageObjects.labellingData("CORE")))
			{
				Reports.ExtentReportLog("", Status.FAIL, "The Default Core labeling is displayed though at App Parametre it is unchecked for Clinical Trial Case", true);
			}
			
			else
			{
				Reports.ExtentReportLog("", Status.PASS, "The Default Core labeling is not displayed for Clinical Trial Case", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			
		}

	}
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to verify whether Default Core labeling for Post Marketing case is displayed in the table
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 24-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDefaultCoreLabelling_PM(String scenarioName, String sheetname, String columnName) {
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetname);
		
		//agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.defaultDueDate_Label);
		agMouseHover(FDE_LabellingPageObjects.label_tag);
		
		String valueDefaultLabeling =getTestDataCellValue(scenarioName, columnName);
		
		if(valueDefaultLabeling.equalsIgnoreCase("True"))
		{
			//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if(agIsVisible(FDE_LabellingPageObjects.labellingData("CORE")))
			{
				Reports.ExtentReportLog("", Status.PASS, "The Default Core labeling is displayed for Post Marketing Case", true);
			}
			
			else
			{
				Reports.ExtentReportLog("", Status.FAIL, "The Default Core labeling is not displayed though at App Parametre it is checked for Post Marketing Case", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			
		}	
		
		else
		{
			//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if(agIsVisible(FDE_LabellingPageObjects.labellingData("CORE")))
			{
				Reports.ExtentReportLog("", Status.FAIL, "The Default Core labeling is displayed though at App Parametre it is unchecked for Post Marketing Case", true);
			}
			
			else
			{
				Reports.ExtentReportLog("", Status.PASS, "The Default Core labeling is not displayed for Post Marketing Case", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			
		}

	}
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to verify whether Default Core labeling for Clinical Trial case is displayed in the table
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 24-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDefaultIBLabelling_CT(String scenarioName, String sheetname, String columnName) {
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetname);
		
		//agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.defaultDueDate_Label);
		agMouseHover(FDE_LabellingPageObjects.label_tag);
		
		String valueDefaultLabeling =getTestDataCellValue(scenarioName, columnName);
		
		if(valueDefaultLabeling.equalsIgnoreCase("True"))
		{
			//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if(agIsVisible(FDE_LabellingPageObjects.labellingData("IB")))
			{
				Reports.ExtentReportLog("", Status.PASS, "The Default IB labeling is displayed for Clinical Trial Case", true);
			}
			
			else
			{
				Reports.ExtentReportLog("", Status.FAIL, "The Default IB labeling is not displayed though at App Parametre it is checked for Clinical Trial Case", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			
		}	
		
		else
		{
			//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if(agIsVisible(FDE_LabellingPageObjects.labellingData("IB")))
			{
				Reports.ExtentReportLog("", Status.FAIL, "The Default IB labeling is displayed though at App Parametre it is unchecked for Clinical Trial Case", true);
			}
			
			else
			{
				Reports.ExtentReportLog("", Status.PASS, "The Default IB labeling is not displayed for Clinical Trial Case", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			
		}

	}

	/**********************************************************************************************************
	 * @Objective: Below method is created to verify whether Default IB labeling for Post Marketing case is displayed in the table
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 25-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDefaultIBLabelling_PM(String scenarioName, String sheetname, String columnName) {
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetname);
		
		//agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.defaultDueDate_Label);
		agMouseHover(FDE_LabellingPageObjects.label_tag);
		
		String valueDefaultLabeling =getTestDataCellValue(scenarioName, columnName);
		
		if(valueDefaultLabeling.equalsIgnoreCase("True"))
		{
			//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if(agIsVisible(FDE_LabellingPageObjects.labellingData("IB")))
			{
				Reports.ExtentReportLog("", Status.PASS, "The Default IB labeling is displayed for Post Marketing Case", true);
			}
			
			else
			{
				Reports.ExtentReportLog("", Status.FAIL, "The Default IB labeling is not displayed though at App Parametre it is checked for Post Marketing Case", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			
		}	
		
		else
		{
			//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if(agIsVisible(FDE_LabellingPageObjects.labellingData("IB")))
			{
				Reports.ExtentReportLog("", Status.FAIL, "The Default IB labeling is displayed though at App Parametre it is unchecked for Post Marketing Case", true);
			}
			
			else
			{
				Reports.ExtentReportLog("", Status.PASS, "The Default IB labeling is not displayed for Post Marketing Case", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			
		}

	}
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to verify whether both Default Core and IB labeling for Clinical Trial case is displayed in the table
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 24-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDefault_CORE_IBLabelling_CT(String scenarioName, String sheetname, String columnName1, String columnName2) {
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetname);
		
		//agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.defaultDueDate_Label);
		agMouseHover(FDE_LabellingPageObjects.label_tag);
		
		String valueCoreLabeling =getTestDataCellValue(scenarioName, columnName1);
		String valueIBLabeling =getTestDataCellValue(scenarioName, columnName2);
		
		if(valueCoreLabeling.equalsIgnoreCase("True") && valueIBLabeling.equalsIgnoreCase("True"))
		{
			//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if(agIsVisible(FDE_LabellingPageObjects.labellingData("CORE")))
			{
				if(agIsVisible(FDE_LabellingPageObjects.labellingData("IB")))
				{
				
					Reports.ExtentReportLog("", Status.PASS, "The Default Core and IB labeling is displayed together for Clinical Trial Case", true);
				
				}
			}
			
			else
			{
				Reports.ExtentReportLog("", Status.FAIL, "The Default Core and IB labeling is not displayed together though at App Parametre both are checked for Clinical Trial Case", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			
		}	
		
			
			else
			{
				Reports.ExtentReportLog("", Status.FAIL, "The Default Core and IB labeling are not selected at Application Parametre for Clinical Trial Case", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			
		}
	/**********************************************************************************************************
	 * @Objective: Below method is created to verify whether both Default Core and IB labeling for Post Market case is displayed in the table
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 24-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDefault_CORE_IBLabelling_PM(String scenarioName, String sheetname, String columnName1, String columnName2) {
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, sheetname);
		
		//agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.defaultDueDate_Label);
		agMouseHover(FDE_LabellingPageObjects.label_tag);
		
		String valueCoreLabeling =getTestDataCellValue(scenarioName, columnName1);
		String valueIBLabeling =getTestDataCellValue(scenarioName, columnName2);
		
		if(valueCoreLabeling.equalsIgnoreCase("True") && valueIBLabeling.equalsIgnoreCase("True"))
		{
			//Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if(agIsVisible(FDE_LabellingPageObjects.labellingData("CORE")))
			{
				if(agIsVisible(FDE_LabellingPageObjects.labellingData("IB")))
				{
				
				Reports.ExtentReportLog("", Status.PASS, "The Default Core and IB labeling is displayed together for Post Market Case", true);
				
				}
			}
			
			else
			{
				Reports.ExtentReportLog("", Status.FAIL, "The Default Core and IB labeling is not displayed together though at App Parametre both are checked for Post Market Case", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			
		}	
		
			
			else
			{
				Reports.ExtentReportLog("", Status.FAIL, "The Default Core and IB labeling are not selected at Application Parametre for Post Market Case", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			
		}
	/**********************************************************************************************************
	 * @Objective: Below method is created to verify whether any default Data Sheet labeling details is displayed in the table
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 23-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyDefaultLabelling_DataSheet(String scenarioName, String columnName, String labelingScenario) {
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, columnName);
		
		//agJavaScriptExecuctorScrollToElement(AppParameters_CaseManagementPageObjects.defaultDueDate_Label);
		agMouseHover(FDE_LabellingPageObjects.label_tag);
		
		
		/*agAssertVisible(FDE_LabellingPageObjects.labellingData(getTestDataCellValue(scenarioName, "ReportedTerm"),
				getTestDataCellValue(scenarioName, "Country"), getTestDataCellValue(scenarioName, "Labeling")));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));*/
		
		String valueDefaultLabeling =getTestDataCellValue(scenarioName, "DefaultLabelingForDataSheet");
		
		if(valueDefaultLabeling.equalsIgnoreCase("Blank"))
		{
			
			verify_DataSheet_blank(labelingScenario);

			
		}	
		
		else if(valueDefaultLabeling.equalsIgnoreCase("Unlabeled"))
		{
			verify_DataSheet_unlabeled(labelingScenario);
			
		}

	}
	
	
	public static void verify_DataSheet_blank(String labelingScenario) {
		
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if(agIsVisible(FDE_LabellingPageObjects.labellingData(getTestDataCellValue(labelingScenario, "ReportedTerm"),
					getTestDataCellValue(labelingScenario, "Country"), "--Select--")))
			{
				Reports.ExtentReportLog("", Status.PASS, "The Default Data Sheet labeling displayed as Blank", true);
			}
			
			else
			{
				Reports.ExtentReportLog("", Status.FAIL, "The Default data sheet labeling not displayed as Blank though at App Parametre it is set to Blank", true);
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			
		}	
	
	
	public static void verify_DataSheet_unlabeled(String labelingScenario) {
		
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if(agIsVisible(FDE_LabellingPageObjects.labellingData(getTestDataCellValue(labelingScenario, "ReportedTerm"),
				getTestDataCellValue(labelingScenario, "Country"), "Unlabeled")))
		{
			Reports.ExtentReportLog("", Status.PASS, "The Default Data Sheet labeling displayed as Unlabeled", true);
		}
		
		else
		{
			Reports.ExtentReportLog("", Status.FAIL, "The Default Data Sheet labeling not displayed as Unlabeled though at App Parametre it is set to Unlabeled", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		
		
	}
	
	/**********************************************************************************************************
	 * @Objective: Below method is created to verify auto labeling for SMQ and CMQ terms added at Product level
	 * @OutputParameters:
	 * @author: Abhisek Ghosh
	 * @Date : 08-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyautolabelling_SmqCmq(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		status = agIsVisible(FDE_LabellingPageObjects.labellingData(getTestDataCellValue(scenarioName, "ReportedTerm"),
				getTestDataCellValue(scenarioName, "Country"), getTestDataCellValue(scenarioName, "Labeling")));
		if (status) {
			
			Reports.ExtentReportLog("", Status.PASS, "As Expected", true);
			Reports.ExtentReportLog("", Status.PASS, "The Automatic labeling records are created for :"+scenarioName, true);
		} else {
			
			Reports.ExtentReportLog("", Status.FAIL,"<br />"+ "The Automatic labeling records are not created for :"+scenarioName, false);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	
	}
	}

