package com.arisglobal.framework.components.lsmv.L10_3;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AppParameters_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.WorkFlowPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AppParameters_General extends ToolManager {
	static String className = AppParameters_General.class.getSimpleName();

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set General Details in General Tab
	 *             under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 9-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setGeneralDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_GeneralPageObjects.companyName_TextBox,
					getTestDataCellValue(scenarioName, "CompanyName"));
			agSetValue(AppParameters_GeneralPageObjects.alertOrigin_TextBox,
					getTestDataCellValue(scenarioName, "AlertOrigin"));
			agSetValue(AppParameters_GeneralPageObjects.alertAdminEmail_TextBox,
					getTestDataCellValue(scenarioName, "AlertAdminEmail"));
			
			
			CommonOperations.setListDropDownValue(AppParameters_GeneralPageObjects.paginatorGroupSize_DropDown,
					getTestDataCellValue(scenarioName, "PaginatorGroupSize"));
			agSetValue(AppParameters_GeneralPageObjects.numberOfRecordsPerPage_TextBox,
					getTestDataCellValue(scenarioName, "NumberOfRecordsPerPage"));
			agSetValue(AppParameters_GeneralPageObjects.numberOfCasesForReassignation_TextBox,
					getTestDataCellValue(scenarioName, "NumberOfCasesForReassignation"));
			
			if(getTestDataCellValue(scenarioName, "AuditReasonRequired").equalsIgnoreCase("true")) {
			if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.auditReasonRequired_CheckBox))==true)
				{
				
				}else{
				CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.auditReasonRequired_CheckBox,getTestDataCellValue(scenarioName, "AuditReasonRequired"));
			}
				}	
			
			if(getTestDataCellValue(scenarioName, "CaseRemoveReasonRequired").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.caseRemoveReasonRequired_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.caseRemoveReasonRequired_CheckBox,
								getTestDataCellValue(scenarioName, "CaseRemoveReasonRequired"));
				}
					}
			if(getTestDataCellValue(scenarioName, "AllowUsersToUnlockTheirOwnRecords").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.allowUsersToUnlockTheirOwnRecords_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.allowUsersToUnlockTheirOwnRecords_CheckBox,
								getTestDataCellValue(scenarioName, "AllowUsersToUnlockTheirOwnRecords"));
				}
					}
		
			agSetValue(AppParameters_GeneralPageObjects.disableInactiveUsersAfterDays_TextBox,
					getTestDataCellValue(scenarioName, "DisableInactiveUsersAfterDays"));
			agSetValue(AppParameters_GeneralPageObjects.confidentialityNoteForReports_TextBox,
					getTestDataCellValue(scenarioName, "ConfidentialityNoteForReports"));
			agSetValue(AppParameters_GeneralPageObjects.font_TextBox, getTestDataCellValue(scenarioName, "Font"));
			agSetValue(AppParameters_GeneralPageObjects.logFilePath_TextBox,
					getTestDataCellValue(scenarioName, "LogFilePath"));
			agSetValue(AppParameters_GeneralPageObjects.maxFileSizeForManualUpload_TextBox,
					getTestDataCellValue(scenarioName, "MaxFileSizeForManualUpload"));
			
			if(getTestDataCellValue(scenarioName, "ConvertInboundDocumentIntoPDF").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.convertInboundDocumentIntoPDF_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.convertInboundDocumentIntoPDF_CheckBox,
								getTestDataCellValue(scenarioName, "ConvertInboundDocumentIntoPDF"));
				}
					}
		
			
			
			agSetValue(AppParameters_GeneralPageObjects.temporaryPathForpdftiffFiles_TextBox,
					getTestDataCellValue(scenarioName, "TemporaryPathForpdftiffFiles"));
			agSetValue(AppParameters_GeneralPageObjects.imageURL_TextBox,
					getTestDataCellValue(scenarioName, "ImageURL"));
			agSetValue(AppParameters_GeneralPageObjects.ARISgClientURL_TextBox,
					getTestDataCellValue(scenarioName, "ARISgClientURL"));
			CommonOperations.setListDropDownValue(AppParameters_GeneralPageObjects.integratedTo_DropDown,
					getTestDataCellValue(scenarioName, "IntegratedTo"));
			agSetValue(AppParameters_GeneralPageObjects.screenLockTimeoutMinutes_TextBox,
					getTestDataCellValue(scenarioName, "ScreenLockTimeoutMinutes"));
			agSetValue(AppParameters_GeneralPageObjects.bulkImportPath_TextBox,
					getTestDataCellValue(scenarioName, "BulkImportPath"));

			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> General >> General Section - 1", true);

			// agSetValue(AppParameters_GeneralPageObjects.ocrPath_TextBox,
			// getTestDataCellValue(scenarioName, "OCRPath"));
			agSetValue(AppParameters_GeneralPageObjects.fuzzySearchFolderPath_TextBox,
					getTestDataCellValue(scenarioName, "FuzzySearchFolderPath"));
			CommonOperations.setListDropDownValue(AppParameters_GeneralPageObjects.fuzzySimilarityScore_DropDown,
					getTestDataCellValue(scenarioName, "FuzzySimilarityScore"));
			
			
			if(getTestDataCellValue(scenarioName, "AuthenticateAgainstDatabaseIfUserIDnotFoundinLDAPServe").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.authenticateAgainstDatabaseIfUserIDnotFoundinLDAPServer_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.authenticateAgainstDatabaseIfUserIDnotFoundinLDAPServer_CheckBox,
								getTestDataCellValue(scenarioName, "AuthenticateAgainstDatabaseIfUserIDnotFoundinLDAPServe"));
				}
					}
		
			
			if(getTestDataCellValue(scenarioName, "CreateCaseForEachInboundFile").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.createCaseForEachInboundFile_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.createCaseForEachInboundFile_CheckBox,
								getTestDataCellValue(scenarioName, "CreateCaseForEachInboundFile"));
				}
					}


			if(getTestDataCellValue(scenarioName, "DisplayErrorStacktrace").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.displayErrorStacktrace_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.displayErrorStacktrace_CheckBox,
								getTestDataCellValue(scenarioName, "DisplayErrorStacktrace"));
				}
			}

			if(getTestDataCellValue(scenarioName, "NewDashboard").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.newDashboard_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.newDashboard_CheckBox,
								getTestDataCellValue(scenarioName, "NewDashboard"));
				}
			}

			if(getTestDataCellValue(scenarioName, "DataPrivacyRequired").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.dataPrivacyRequired_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.dataPrivacyRequired_CheckBox,
								getTestDataCellValue(scenarioName, "DataPrivacyRequired"));
				}
			}
			// CommonOperations.clickRadioButton(AppParameters_GeneralPageObjects.displayAnnouncementandTaskPopup_Radio,
			// getTestDataCellValue(scenarioName, "DisplayAnnouncementandTaskPopup"));

			CommonOperations.setListDropDownValue(AppParameters_GeneralPageObjects.encryptionStandard_DropDown,
					getTestDataCellValue(scenarioName, "EncryptionStandard"));
			
			if(getTestDataCellValue(scenarioName, "PasswordCheckForDocuments").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.passwordCheckForDocuments_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.passwordCheckForDocuments_CheckBox,
								getTestDataCellValue(scenarioName, "PasswordCheckForDocuments"));
				}
			}
			
			

			
			CommonOperations.setListDropDownValue(AppParameters_GeneralPageObjects.applicationTheme_DropDown,
					getTestDataCellValue(scenarioName, "ApplicationTheme"));
			CommonOperations.setListDropDownValue(AppParameters_GeneralPageObjects.companyUnitAccess_DropDown,
					getTestDataCellValue(scenarioName, "CompanyUnitAccess"));
			// CommonOperations.clickRadioButton(AppParameters_GeneralPageObjects.displayCopyright_Radio,
			// getTestDataCellValue(scenarioName, "DisplayCopyright"));
			agSetValue(AppParameters_GeneralPageObjects.displayCopyright_TextBox,
					getTestDataCellValue(scenarioName, "DisplayCopyrightMessage"));
			agSetValue(AppParameters_GeneralPageObjects.disclaimerMessage_TextBox,
					getTestDataCellValue(scenarioName, "DisclaimerMessage"));
			CommonOperations.setListDropDownValue(AppParameters_GeneralPageObjects.timeZonePreference_DropDown,
					getTestDataCellValue(scenarioName, "TimeZonePreference"));
			if (getTestDataCellValue(scenarioName, "TimeZonePreference").equalsIgnoreCase("Client Machine")) {
				CommonOperations.setListDropDownValue(AppParameters_GeneralPageObjects.dateFormat_DropDown,
						getTestDataCellValue(scenarioName, "DateFormat"));
			}

			// CommonOperations.clickRadioButton(AppParameters_GeneralPageObjects.ruleBuilderReportAccess_Radio,
			// getTestDataCellValue(scenarioName, "RuleBuilderReportAccess"));
			CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.mergeAllRoles_CheckBox,
					getTestDataCellValue(scenarioName, "MergeAllRoles"));
			agSetValue(AppParameters_GeneralPageObjects.importConfigurationPath_TextBox,
					getTestDataCellValue(scenarioName, "ImportConfigurationPath"));

			// agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.ocrPath_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> General >> General Section - 2", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> General >> General Section - 1,2 Fails", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify General Details in General
	 *             Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 27-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyGeneralDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "CompanyName"),
				AppParameters_GeneralPageObjects.companyName_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "AlertOrigin"),
				AppParameters_GeneralPageObjects.alertOrigin_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "AlertAdminEmail"),
				AppParameters_GeneralPageObjects.alertAdminEmail_TextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "PaginatorGroupSize"),
				AppParameters_GeneralPageObjects.paginatorGroupSize_DropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "NumberOfRecordsPerPage"),
				AppParameters_GeneralPageObjects.numberOfRecordsPerPage_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "NumberOfCasesForReassignation"),
				AppParameters_GeneralPageObjects.numberOfCasesForReassignation_TextBox);
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.auditReasonRequired_CheckBox,
				getTestDataCellValue(scenarioName, "AuditReasonRequired"));
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.caseRemoveReasonRequired_CheckBox,
				getTestDataCellValue(scenarioName, "CaseRemoveReasonRequired"));
		CommonOperations.verifyCheckBoxLeftOf(
				AppParameters_GeneralPageObjects.allowUsersToUnlockTheirOwnRecords_CheckBox,
				getTestDataCellValue(scenarioName, "AllowUsersToUnlockTheirOwnRecords"));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "DisableInactiveUsersAfterDays"),
				AppParameters_GeneralPageObjects.disableInactiveUsersAfterDays_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ConfidentialityNoteForReports"),
				AppParameters_GeneralPageObjects.confidentialityNoteForReports_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Font"),
				AppParameters_GeneralPageObjects.font_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "LogFilePath"),
				AppParameters_GeneralPageObjects.logFilePath_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MaxFileSizeForManualUpload"),
				AppParameters_GeneralPageObjects.maxFileSizeForManualUpload_TextBox);
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.convertInboundDocumentIntoPDF_CheckBox,
				getTestDataCellValue(scenarioName, "ConvertInboundDocumentIntoPDF"));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "TemporaryPathForpdftiffFiles"),
				AppParameters_GeneralPageObjects.temporaryPathForpdftiffFiles_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ImageURL"),
				AppParameters_GeneralPageObjects.imageURL_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ARISgClientURL"),
				AppParameters_GeneralPageObjects.ARISgClientURL_TextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "IntegratedTo"),
				AppParameters_GeneralPageObjects.integratedTo_DropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ScreenLockTimeoutMinutes"),
				AppParameters_GeneralPageObjects.screenLockTimeoutMinutes_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "BulkImportPath"),
				AppParameters_GeneralPageObjects.bulkImportPath_TextBox);

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Application Parameters >> General >> General Section - 1", true);

		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "OCRPath"),
				AppParameters_GeneralPageObjects.ocrPath_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FuzzySearchFolderPath"),
				AppParameters_GeneralPageObjects.fuzzySearchFolderPath_TextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "FuzzySimilarityScore"),
				AppParameters_GeneralPageObjects.fuzzySimilarityScore_DropDown);
		CommonOperations.verifyCheckBoxLeftOf(
				AppParameters_GeneralPageObjects.authenticateAgainstDatabaseIfUserIDnotFoundinLDAPServer_CheckBox,
				getTestDataCellValue(scenarioName, "AuthenticateAgainstDatabaseIfUserIDnotFoundinLDAPServer"));
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.createCaseForEachInboundFile_CheckBox,
				getTestDataCellValue(scenarioName, "CreateCaseForEachInboundFile"));
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.displayErrorStacktrace_CheckBox,
				getTestDataCellValue(scenarioName, "DisplayErrorStacktrace"));
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.newDashboard_CheckBox,
				getTestDataCellValue(scenarioName, "NewDashboard"));
		CommonOperations.verifyRadioButton(AppParameters_GeneralPageObjects.displayAnnouncementandTaskPopup_Radio,
				getTestDataCellValue(scenarioName, "DisplayAnnouncementandTaskPopup"));
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.dataPrivacyRequired_CheckBox,
				getTestDataCellValue(scenarioName, "DataPrivacyRequired"));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "EncryptionStandard"),
				AppParameters_GeneralPageObjects.encryptionStandard_DropDown);
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.passwordCheckForDocuments_CheckBox,
				getTestDataCellValue(scenarioName, "PasswordCheckForDocuments"));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ApplicationTheme"),
				AppParameters_GeneralPageObjects.applicationTheme_DropDown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "CompanyUnitAccess"),
				AppParameters_GeneralPageObjects.companyUnitAccess_DropDown);
		CommonOperations.verifyRadioButton(AppParameters_GeneralPageObjects.displayCopyright_Radio,
				getTestDataCellValue(scenarioName, "DisplayCopyright"));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "DisplayCopyrightMessage"),
				AppParameters_GeneralPageObjects.displayCopyright_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "DisclaimerMessage"),
				AppParameters_GeneralPageObjects.disclaimerMessage_TextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "TimeZonePreference"),
				AppParameters_GeneralPageObjects.timeZonePreference_DropDown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "DateFormat"),
				AppParameters_GeneralPageObjects.dateFormat_DropDown);
		CommonOperations.verifyRadioButton(AppParameters_GeneralPageObjects.ruleBuilderReportAccess_Radio,
				getTestDataCellValue(scenarioName, "RuleBuilderReportAccess"));
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.mergeAllRoles_CheckBox,
				getTestDataCellValue(scenarioName, "MergeAllRoles"));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "ImportConfigurationPath"),
				AppParameters_GeneralPageObjects.importConfigurationPath_TextBox);

		agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.ocrPath_Label);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Application Parameters >> General >> General Section - 2", true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Password Management Details in
	 *             General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 9-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setPasswordManagementDetails(String scenarioName) {
		try {
			agClick(AppParameters_GeneralPageObjects.minimumPasswordLength_TextBox);

			if (agGetAttribute("value", AppParameters_GeneralPageObjects.minimumPasswordLength_TextBox)
					.equalsIgnoreCase("")) {

				// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
				agSetValue(AppParameters_GeneralPageObjects.minimumPasswordLength_TextBox,
						getTestDataCellValue(scenarioName, "MinimumPasswordLength"));
				agSetValue(AppParameters_GeneralPageObjects.passwordExpiryDurationDays_TextBox,
						getTestDataCellValue(scenarioName, "PasswordExpiryDurationDays"));
			}
			agSetValue(AppParameters_GeneralPageObjects.countOfWrongPasswordBeforeLockingAccount_TextBox,
					getTestDataCellValue(scenarioName, "CountOfWrongPasswordBeforeLockingAccount"));
			agSetValue(AppParameters_GeneralPageObjects.noOfWrongPasswordLoginSendingAlerts_TextBox,
					getTestDataCellValue(scenarioName, "NoOfWrongPasswordLoginSendingAlerts"));
			agSetValue(AppParameters_GeneralPageObjects.passwordResetReminderBeforeExpiry_TextBox,
					getTestDataCellValue(scenarioName, "PasswordResetReminderBeforeExpiry"));
			
			if(getTestDataCellValue(scenarioName, "LockAccountPermanently").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.lockAccountPermanently_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.lockAccountPermanently_CheckBox,
								getTestDataCellValue(scenarioName, "LockAccountPermanently"));
				}
			}
			
			
			agSetValue(AppParameters_GeneralPageObjects.lockAccountPermanentlyMinutes_TextBox,
					getTestDataCellValue(scenarioName, "LockAccountPermanentlyMinutes"));
			agSetValue(AppParameters_GeneralPageObjects.passwordReuseRestrictionCount_TextBox,
					getTestDataCellValue(scenarioName, "PasswordReuseRestrictionCount"));

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.passwordManagement_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> General >> Password Management Section", true);
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> General >> Password Management Section Fails", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify Password Management Details
	 *             in General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 27-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyPasswordManagementDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MinimumPasswordLength"),
				AppParameters_GeneralPageObjects.minimumPasswordLength_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PasswordExpiryDurationDays"),
				AppParameters_GeneralPageObjects.passwordExpiryDurationDays_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "CountOfWrongPasswordBeforeLockingAccount"),
				AppParameters_GeneralPageObjects.countOfWrongPasswordBeforeLockingAccount_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "NoOfWrongPasswordLoginSendingAlerts"),
				AppParameters_GeneralPageObjects.noOfWrongPasswordLoginSendingAlerts_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PasswordResetReminderBeforeExpiry"),
				AppParameters_GeneralPageObjects.passwordResetReminderBeforeExpiry_TextBox);
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.lockAccountPermanently_CheckBox,
				getTestDataCellValue(scenarioName, "LockAccountPermanently"));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "CompanyUnitAccess"),
				AppParameters_GeneralPageObjects.companyUnitAccess_DropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "LockAccountPermanentlyMinutes"),
				AppParameters_GeneralPageObjects.lockAccountPermanentlyMinutes_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PasswordReuseRestrictionCount"),
				AppParameters_GeneralPageObjects.passwordReuseRestrictionCount_TextBox);

		agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.passwordManagement_Label);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Application Parameters >> General >> Password Management Section", true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Case Triage and Adverse Event
	 *             Details in General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 9-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setCaseTriageAndAdverseEventDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_GeneralPageObjects.defaultNumberOfRecentlyOpenedAdverseEvents_TextBox,
					getTestDataCellValue(scenarioName, "DefaultNumberOfRecentlyOpenedAdverseEvents"));
			agSetValue(AppParameters_GeneralPageObjects.maxNumberOfCasesForCompleteActivity_TextBox,
					getTestDataCellValue(scenarioName, "MaxNumberOfCasesForCompleteActivity"));
		
			CommonOperations.setListDropDownValue(AppParameters_GeneralPageObjects.manageUserWorkload_DropDown,
					getTestDataCellValue(scenarioName, "ManageUserWorkload"));
			
			if(getTestDataCellValue(scenarioName, "DisplayProductLookup").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.displayProductLookup_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.displayProductLookup_CheckBox,
								getTestDataCellValue(scenarioName, "DisplayProductLookup"));
				}
			}
			
			
			if(getTestDataCellValue(scenarioName, "DisplayProductLookup").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.displayProductLookup_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.displayProductLookup_CheckBox,
								getTestDataCellValue(scenarioName, "DisplayProductLookup"));
				}
			}

			if(getTestDataCellValue(scenarioName, "FormLevelUnitValidationOnSave").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.formLevelUnitValidationOnSave_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.formLevelUnitValidationOnSave_CheckBox,
								getTestDataCellValue(scenarioName, "FormLevelUnitValidationOnSave"));
				}
			}
			
			if(getTestDataCellValue(scenarioName, "DisplaySwitchToForm").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.displaySwitchToForm_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.displaySwitchToForm_CheckBox,
								getTestDataCellValue(scenarioName, "DisplaySwitchToForm"));
				}
			}
			if(getTestDataCellValue(scenarioName, "ShowSupplementFieldsInSmartView").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.showSupplementFieldsInSmartView_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.showSupplementFieldsInSmartView_CheckBox,
								getTestDataCellValue(scenarioName, "ShowSupplementFieldsInSmartView"));
				}
			}
			if(getTestDataCellValue(scenarioName, "DisplaySupplementFieldsOnCondition").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.displaySupplementFieldsOnCondition_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.displaySupplementFieldsOnCondition_CheckBox,
								getTestDataCellValue(scenarioName, "DisplaySupplementFieldsOnCondition"));
				}
			}
			if(getTestDataCellValue(scenarioName, "ProtectConfidentiality").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.protectConfidentiality_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.protectConfidentiality_CheckBox,
								getTestDataCellValue(scenarioName, "ProtectConfidentiality"));
				}
			}
			
			

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.caseTriageAndAdverseEvent_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> General >> Case Triage and Adverse Event Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> General >> Case Triage and Adverse Event Section Fails",
					true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify Case Triage and Adverse
	 *             Event Details in General Tab under Application Parameters
	 *             Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 27-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyCaseTriageAndAdverseEventDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "DefaultNumberOfRecentlyOpenedAdverseEvents"),
				AppParameters_GeneralPageObjects.defaultNumberOfRecentlyOpenedAdverseEvents_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MaxNumberOfCasesForCompleteActivity"),
				AppParameters_GeneralPageObjects.maxNumberOfCasesForCompleteActivity_TextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ManageUserWorkload"),
				AppParameters_GeneralPageObjects.manageUserWorkload_DropDown);
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.displayProductLookup_CheckBox,
				getTestDataCellValue(scenarioName, "DisplayProductLookup"));
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.formLevelUnitValidationOnSave_CheckBox,
				getTestDataCellValue(scenarioName, "FormLevelUnitValidationOnSave"));
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.displaySwitchToForm_CheckBox,
				getTestDataCellValue(scenarioName, "DisplaySwitchToForm"));
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.showSupplementFieldsInSmartView_CheckBox,
				getTestDataCellValue(scenarioName, "ShowSupplementFieldsInSmartView"));
		CommonOperations.verifyCheckBoxLeftOf(
				AppParameters_GeneralPageObjects.displaySupplementFieldsOnCondition_CheckBox,
				getTestDataCellValue(scenarioName, "DisplaySupplementFieldsOnCondition"));
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.protectConfidentiality_CheckBox,
				getTestDataCellValue(scenarioName, "ProtectConfidentiality"));

		agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.caseTriageAndAdverseEvent_Label);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Application Parameters >> General >> Case Triage and Adverse Event Section",
				true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Case Identifier Details in
	 *             General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 9-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setCaseIdentifierDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			
			if(getTestDataCellValue(scenarioName, "AtLeastOneSuspectProduct").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.atLeastOneSuspectProduct_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.atLeastOneSuspectProduct_CheckBox,
								getTestDataCellValue(scenarioName, "AtLeastOneSuspectProduct"));
				}
			}
			
			if(getTestDataCellValue(scenarioName, "AtLeastOneReportedTerm").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.atLeastOneReportedTerm_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.atLeastOneReportedTerm_CheckBox,
								getTestDataCellValue(scenarioName, "AtLeastOneReportedTerm"));
				}
			}
			if(getTestDataCellValue(scenarioName, "ConsiderOnlyCompanySuspectProduct").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.considerOnlyCompanySuspectProduct_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.considerOnlyCompanySuspectProduct_CheckBox,
								getTestDataCellValue(scenarioName, "ConsiderOnlyCompanySuspectProduct"));
				}
			}


			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.caseIdentifier_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> General >> Case Identifier Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> General >> Case Identifier Section Fail", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify Case Identifier Details in
	 *             General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 27-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyCaseIdentifierDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.atLeastOneSuspectProduct_CheckBox,
				getTestDataCellValue(scenarioName, "AtLeastOneSuspectProduct"));
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.atLeastOneReportedTerm_CheckBox,
				getTestDataCellValue(scenarioName, "AtLeastOneReportedTerm"));
		CommonOperations.verifyCheckBoxLeftOf(
				AppParameters_GeneralPageObjects.considerOnlyCompanySuspectProduct_CheckBox,
				getTestDataCellValue(scenarioName, "ConsiderOnlyCompanySuspectProduct"));

		agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.caseIdentifier_Label);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Application Parameters >> General >> Case Identifier Section", true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Case Validity Identifier
	 *             Details in General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 9-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setCaseValidityIdentifierDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			
			if(getTestDataCellValue(scenarioName, "PatientAvailable").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.patientAvailable_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.patientAvailable_CheckBox,
								getTestDataCellValue(scenarioName, "PatientAvailable"));
				}
			}
			if(getTestDataCellValue(scenarioName, "AtLeastOneReporter").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.atLeastOneReporter_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.atLeastOneReporter_CheckBox,
								getTestDataCellValue(scenarioName, "AtLeastOneReporter"));
				}
			}



			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.caseValidityIdentifier_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> General >> Case Validity Identifier Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> General >> Case Validity Identifier Section Fails",
					true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify Case Validity Identifier
	 *             Details in General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 27-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyCaseValidityIdentifierDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.patientAvailable_CheckBox,
				getTestDataCellValue(scenarioName, "PatientAvailable"));
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.atLeastOneReporter_CheckBox,
				getTestDataCellValue(scenarioName, "AtLeastOneReporter"));

		agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.caseValidityIdentifier_Label);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Application Parameters >> General >> Case Validity Identifier Section", true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set FAQ's & Templates Details in
	 *             General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 13-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setFAQsTemplatesDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_GeneralPageObjects.faqNumberingFormat_TextBox,
					getTestDataCellValue(scenarioName, "FAQNumberingFormat"));
			CommonOperations.setListDropDownValue(AppParameters_GeneralPageObjects.faqNumberingFormat1_DropDown,
					getTestDataCellValue(scenarioName, "FAQNumberingFormat1"));
			CommonOperations.setListDropDownValue(AppParameters_GeneralPageObjects.faqNumberingFormat2_DropDown,
					getTestDataCellValue(scenarioName, "FAQNumberingFormat2"));
			agSetValue(AppParameters_GeneralPageObjects.faqExpiryPeriodDays_TextBox,
					getTestDataCellValue(scenarioName, "FAQExpiryPeriodDays"));
			agSetValue(AppParameters_GeneralPageObjects.faqTemplateWarningPeriodDays_TextBox,
					getTestDataCellValue(scenarioName, "FAQTemplateWarningPeriodDays"));
			agSetValue(AppParameters_GeneralPageObjects.templateNumberingFormat_TextBox,
					getTestDataCellValue(scenarioName, "TemplateNumberingFormat"));
			CommonOperations.setListDropDownValue(AppParameters_GeneralPageObjects.templateNumberingFormat1_DropDown,
					getTestDataCellValue(scenarioName, "TemplateNumberingFormat1"));
			CommonOperations.setListDropDownValue(AppParameters_GeneralPageObjects.templateNumberingFormat2_DropDown,
					getTestDataCellValue(scenarioName, "TemplateNumberingFormat2"));
			agSetValue(AppParameters_GeneralPageObjects.templateExpiryPeriodDays_TextBox,
					getTestDataCellValue(scenarioName, "TemplateExpiryPeriodDays"));

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.FAQsTemplates_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> General >> FAQ's & Templates Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> General >> FAQ's & Templates Section Fail", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify FAQ's & Templates Details
	 *             in General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 27-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyFAQsTemplatesDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FAQNumberingFormat"),
				AppParameters_GeneralPageObjects.faqNumberingFormat_TextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "FAQNumberingFormat1"),
				AppParameters_GeneralPageObjects.faqNumberingFormat1_DropDown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "FAQNumberingFormat2"),
				AppParameters_GeneralPageObjects.faqNumberingFormat2_DropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FAQExpiryPeriodDays"),
				AppParameters_GeneralPageObjects.faqExpiryPeriodDays_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FAQTemplateWarningPeriodDays"),
				AppParameters_GeneralPageObjects.faqTemplateWarningPeriodDays_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "TemplateNumberingFormat"),
				AppParameters_GeneralPageObjects.templateNumberingFormat_TextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "TemplateNumberingFormat1"),
				AppParameters_GeneralPageObjects.templateNumberingFormat1_DropDown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "TemplateNumberingFormat2"),
				AppParameters_GeneralPageObjects.templateNumberingFormat2_DropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "TemplateExpiryPeriodDays"),
				AppParameters_GeneralPageObjects.templateExpiryPeriodDays_TextBox);

		agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.FAQsTemplates_Label);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Application Parameters >> General >> FAQ's & Templates Section", true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Documents Details in General
	 *             Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 13-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setDocumentsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_GeneralPageObjects.documentsNumberingFormat_TextBox,
					getTestDataCellValue(scenarioName, "DocumentsNumberingFormat"));
			CommonOperations.setListDropDownValue(AppParameters_GeneralPageObjects.documentsNumberingFormat1_DropDown,
					getTestDataCellValue(scenarioName, "DocumentsNumberingFormat1"));
			CommonOperations.setListDropDownValue(AppParameters_GeneralPageObjects.documentsNumberingFormat2_DropDown,
					getTestDataCellValue(scenarioName, "DocumentsNumberingFormat2"));
			agSetValue(AppParameters_GeneralPageObjects.documentsExpiryPeriodDays_TextBox,
					getTestDataCellValue(scenarioName, "DocumentsExpiryPeriodDays"));
			agSetValue(AppParameters_GeneralPageObjects.documentsWarningPeriodDay_TextBox,
					getTestDataCellValue(scenarioName, "DocumentsWarningPeriodDays"));
			CommonOperations.setListDropDownValue(
					AppParameters_GeneralPageObjects.expiryWarningPeriodApplicableFor_DropDown,
					getTestDataCellValue(scenarioName, "ExpiryWarningPeriodApplicableFor"));
			agSetValue(AppParameters_GeneralPageObjects.waterMarkRuleForInternalEditor_TextBox,
					getTestDataCellValue(scenarioName, "WaterMarkRuleForInternalEditor"));
			agSetValue(AppParameters_GeneralPageObjects.documentsFefaultBccEmailAddressForCorrespondence_TextBox,
					getTestDataCellValue(scenarioName, "DocumentsFefaultBccEmailAddressForCorrespondence"));

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.documents_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> General >> Documents Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> General >> Documents Section Fail", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify Documents Details in
	 *             General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 27-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyDocumentsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "DocumentsNumberingFormat"),
				AppParameters_GeneralPageObjects.documentsNumberingFormat_TextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "DocumentsNumberingFormat1"),
				AppParameters_GeneralPageObjects.documentsNumberingFormat1_DropDown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "DocumentsNumberingFormat2"),
				AppParameters_GeneralPageObjects.documentsNumberingFormat2_DropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "DocumentsExpiryPeriodDays"),
				AppParameters_GeneralPageObjects.documentsExpiryPeriodDays_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "DocumentsWarningPeriodDays"),
				AppParameters_GeneralPageObjects.documentsWarningPeriodDay_TextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "ExpiryWarningPeriodApplicableFor"),
				AppParameters_GeneralPageObjects.expiryWarningPeriodApplicableFor_DropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "WaterMarkRuleForInternalEditor"),
				AppParameters_GeneralPageObjects.waterMarkRuleForInternalEditor_TextBox);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "DocumentsFefaultBccEmailAddressForCorrespondence"),
				AppParameters_GeneralPageObjects.documentsFefaultBccEmailAddressForCorrespondence_TextBox);

		agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.documents_Label);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Application Parameters >> General >> Documents Section", true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Bibliography Details in
	 *             General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 13-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setBibliographyDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_GeneralPageObjects.bibliographyNumberingFormat_TextBox,
					getTestDataCellValue(scenarioName, "BibliographyNumberingFormat"));
			CommonOperations.setListDropDownValue(
					AppParameters_GeneralPageObjects.bibliographyNumberingFormat1_DropDown,
					getTestDataCellValue(scenarioName, "BibliographyNumberingFormat1"));
			CommonOperations.setListDropDownValue(
					AppParameters_GeneralPageObjects.bibliographyNumberingFormat2_DropDown,
					getTestDataCellValue(scenarioName, "BibliographyNumberingFormat2"));
			CommonOperations.clickRadioButtonUpdated(AppParameters_GeneralPageObjects.alwaysAvailable_Radio,
					getTestDataCellValue(scenarioName, "AlwaysAvailable"));
			if (getTestDataCellValue(scenarioName, "AlwaysAvailable").equalsIgnoreCase("No")) {
				agSetValue(AppParameters_GeneralPageObjects.bibliographyExpiryPeriodDays_TextBox,
						getTestDataCellValue(scenarioName, "BibliographyExpiryPeriodDays"));
				agSetValue(AppParameters_GeneralPageObjects.bibliographyWarningPeriodDay_TextBox,
						getTestDataCellValue(scenarioName, "BibliographyWarningPeriodDay"));
			}

			agSetValue(AppParameters_GeneralPageObjects.defaultNumberRecentlyOpenedBibliographies_TextBox,
					getTestDataCellValue(scenarioName, "DefaultNumberRecentlyOpenedBibliographies"));
			agSetValue(AppParameters_GeneralPageObjects.bibliographyDefaultBccEmailAddressCorrespondence_TextBox,
					getTestDataCellValue(scenarioName, "BibliographyDefaultBccEmailAddressCorrespondence"));

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.bibliography_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> General >> Bibliography Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> General >> Bibliography Section Fails", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify Bibliography Details in
	 *             General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 27-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyBibliographyDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "BibliographyNumberingFormat"),
				AppParameters_GeneralPageObjects.bibliographyNumberingFormat_TextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "BibliographyNumberingFormat1"),
				AppParameters_GeneralPageObjects.bibliographyNumberingFormat1_DropDown);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "BibliographyNumberingFormat2"),
				AppParameters_GeneralPageObjects.bibliographyNumberingFormat2_DropDown);
		CommonOperations.verifyRadioButton(AppParameters_GeneralPageObjects.alwaysAvailable_Radio,
				getTestDataCellValue(scenarioName, "AlwaysAvailable"));
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "BibliographyExpiryPeriodDays"),
				AppParameters_GeneralPageObjects.bibliographyExpiryPeriodDays_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "BibliographyWarningPeriodDay"),
				AppParameters_GeneralPageObjects.bibliographyWarningPeriodDay_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "DefaultNumberRecentlyOpenedBibliographies"),
				AppParameters_GeneralPageObjects.defaultNumberRecentlyOpenedBibliographies_TextBox);
		agCheckPropertyValue("value",
				getTestDataCellValue(scenarioName, "BibliographyDefaultBccEmailAddressCorrespondence"),
				AppParameters_GeneralPageObjects.bibliographyDefaultBccEmailAddressCorrespondence_TextBox);

		agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.bibliography_Label);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Application Parameters >> General >> Bibliography Section", true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set E-Signature Details in General
	 *             Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 13-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setESignatureDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			
			if(getTestDataCellValue(scenarioName, "FAQ_ESignature").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.faq_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.faq_CheckBox,
								getTestDataCellValue(scenarioName, "FAQ_ESignature"));
				}
			}
			
			if(getTestDataCellValue(scenarioName, "Document_ESignature").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.document_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.document_CheckBox,
								getTestDataCellValue(scenarioName, "Document_ESignature"));
				}
			}
			
			
			if(getTestDataCellValue(scenarioName, "Template_ESignature").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.template_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.template_CheckBox,
								getTestDataCellValue(scenarioName, "Template_ESignature"));
				}
			}
			if(getTestDataCellValue(scenarioName, "Inquiry_ESignature").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.inquiry_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.inquiry_CheckBox,
								getTestDataCellValue(scenarioName, "Inquiry_ESignature"));
				}
			}
			if(getTestDataCellValue(scenarioName, "Bibliography_ESignature").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_GeneralPageObjects.bibliography_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_GeneralPageObjects.bibliography_CheckBox,
								getTestDataCellValue(scenarioName, "Bibliography_ESignature"));
				}
			}
	

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.eSignature_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> General >> E-Signature Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> General >> E-Signature Section Fail", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify E-Signature Details in
	 *             General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 27-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyESignatureDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.faq_CheckBox,
				getTestDataCellValue(scenarioName, "FAQ_ESignature"));
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.document_CheckBox,
				getTestDataCellValue(scenarioName, "Document_ESignature"));
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.template_CheckBox,
				getTestDataCellValue(scenarioName, "Template_ESignature"));
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.inquiry_CheckBox,
				getTestDataCellValue(scenarioName, "Inquiry_ESignature"));
		CommonOperations.verifyCheckBoxLeftOf(AppParameters_GeneralPageObjects.bibliography_CheckBox,
				getTestDataCellValue(scenarioName, "Bibliography_ESignature"));

		agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.eSignature_Label);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in Application Parameters >> General >> E-Signature Section", true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Import Settings For Product
	 *             Lot/Batch Details Migration Details in General Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 13-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setImportSettingsforProductLotBatchDetailsMigrationDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_GeneralPageObjects.configurationFolderPath_TextBox,
					getTestDataCellValue(scenarioName, "ConfigurationFolderPath"));
			agSetValue(AppParameters_GeneralPageObjects.backupFolderPath_TextBox,
					getTestDataCellValue(scenarioName, "BackupFolderPath"));
			agSetValue(AppParameters_GeneralPageObjects.errorFolderPath_TextBox,
					getTestDataCellValue(scenarioName, "ErrorFolderPath"));
			agSetValue(AppParameters_GeneralPageObjects.acknowledgmentFolderPath_TextBox,
					getTestDataCellValue(scenarioName, "AcknowledgmentFolderPath"));

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.importSettingsforProduct_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> General >> Import Settings For Product Lot/Batch Details Migration Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> General >> Import Settings For Product Lot/Batch Details Migration Section Fail",
					true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Import Settings For Contact
	 *             Details in General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 13-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setImportSettingsForContactDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_GeneralPageObjects.importContactConfigurationFolderPath_TextBox,
					getTestDataCellValue(scenarioName, "ImportContactConfigurationFolderPath"));
			agSetValue(AppParameters_GeneralPageObjects.importContactBackupFolderPath_TextBox,
					getTestDataCellValue(scenarioName, "ImportContactBackupFolderPath"));
			agSetValue(AppParameters_GeneralPageObjects.importContactErrorFolderPath_TextBox,
					getTestDataCellValue(scenarioName, "ImportContactErrorFolderPath"));
			agSetValue(AppParameters_GeneralPageObjects.importContactAcknowledgmentFolderPath_TextBox,
					getTestDataCellValue(scenarioName, "ImportContactAcknowledgmentFolderPath"));

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.importSettingsForContact_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> General >> Import Settings For Contact Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Export Settings For Contact
	 *             Details in General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 13-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setExportSettingsForContactDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_GeneralPageObjects.exportContactConfigurationFolderPath_TextBox,
					getTestDataCellValue(scenarioName, "ExportContactConfigurationFolderPath"));
			agSetValue(AppParameters_GeneralPageObjects.exportContactBackupFolderPath_TextBox,
					getTestDataCellValue(scenarioName, "ExportContactBackupFolderPath"));
			agSetValue(AppParameters_GeneralPageObjects.exportContactErrorFolderPath_TextBox,
					getTestDataCellValue(scenarioName, "ExportContactErrorFolderPath"));
			agSetValue(AppParameters_GeneralPageObjects.exportContactAcknowledgmentFolderPath_TextBox,
					getTestDataCellValue(scenarioName, "ExportContactAcknowledgmentFolderPath"));

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.exportSettingsForContact_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> General >> Export Settings For Contact Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Data Privacy Setting in
	 *             General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 13-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setDataPrivacySettingDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			CommonOperations.setListDropDownValue(AppParameters_GeneralPageObjects.contactCategory_DropDown,
					getTestDataCellValue(scenarioName, "ContactCategory"));
			agClick((AppParameters_GeneralPageObjects.contactSubCategory_Value).replace("%value%",
					getTestDataCellValue(scenarioName, "ContactSubCategory")));
			if (getTestDataCellValue(scenarioName, "boolDataPrivacySetting").equalsIgnoreCase("true")) {
				agClick(AppParameters_GeneralPageObjects.dataPrivacySetting_AddButton);
			}

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.dataPrivacySetting_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> General >> Data Privacy Setting Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> General >> Data Privacy Setting Section Fail", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Busy Scheduler Status Alert
	 *             Settings Details in General Tab under Application Parameters
	 *             Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 16-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setBusySchedulerStatusAlertSettingsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (getTestDataCellValue(scenarioName, "allBusySchedulerStatusAlertSettings").equalsIgnoreCase("true")) {
				agClick((AppParameters_GeneralPageObjects.busySchedulerStatusAlertSettings_Button).replace("%option%",
						"Add All"));
			} else {
				String fieldName = getTestDataCellValue(scenarioName, "BusySchedulerStatusAlertSettings");
				String[] totalRecords = fieldName.split(",");
				for (int i = 0; i < totalRecords.length; i++) {
					agClick((AppParameters_GeneralPageObjects.busySchedulerStatusAlertSettings_List).replace("%value%",
							totalRecords[i]));
					agClick((AppParameters_GeneralPageObjects.busySchedulerStatusAlertSettings_Button)
							.replace("%option%", "Add"));
				}
			}
			CommonOperations.setListDropDownValue(
					AppParameters_GeneralPageObjects.busySchedulerStatusAlertSettings_DropDown,
					getTestDataCellValue(scenarioName, "BusyAlertIfBusyFrom"));

			agJavaScriptExecuctorScrollToElement(
					AppParameters_GeneralPageObjects.busySchedulerStatusAlertSettings_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> General >> Busy Scheduler Status Alert Settings Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> General >> Busy Scheduler Status Alert Settings Section Fails",
					true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Stopped/Idle Scheduler Status
	 *             Alert Settings Details in General Tab under Application
	 *             Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 16-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setStoppedIdleSchedulerStatusAlertSettingsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "allStoppedIdleSchedulerStatusAlertSettings").equalsIgnoreCase("true")) {
			agClick((AppParameters_GeneralPageObjects.stoppedIdleSchedulerStatusAlertSettings_Button)
					.replace("%option%", "Add All"));
		} else {
			String fieldName = getTestDataCellValue(scenarioName, "StoppedIdleSchedulerStatusAlertSettings");
			String[] totalRecords = fieldName.split(",");
			for (int i = 0; i < totalRecords.length; i++) {
				agClick((AppParameters_GeneralPageObjects.stoppedIdleSchedulerStatusAlertSettings_List)
						.replace("%value%", totalRecords[i]));
				agClick((AppParameters_GeneralPageObjects.stoppedIdleSchedulerStatusAlertSettings_Button)
						.replace("%option%", "Add"));
			}
		}
		CommonOperations.setListDropDownValue(
				AppParameters_GeneralPageObjects.stoppedIdleSchedulerStatusAlertSettings_DropDown,
				getTestDataCellValue(scenarioName, "StoppedIdleAlertIfBusyFrom"));

		agJavaScriptExecuctorScrollToElement(
				AppParameters_GeneralPageObjects.stoppedIdleSchedulerStatusAlertSettings_Label);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in Application Parameters >> General >> Stopped/Idle Scheduler Status Alert Settings Section",
				true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Additional Alert Email ID's in
	 *             General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 13-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setAdditionalAlertEmailIDsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (getTestDataCellValue(scenarioName, "boolAddAdditionalAlertEmailIDs").equalsIgnoreCase("true")) {
				agClick(AppParameters_GeneralPageObjects.additionalAlertEmailID_AddButton);
			}
			agSetValue(
					(AppParameters_GeneralPageObjects.emailAddress_TextBox).replace("%rowNo%",
							getTestDataCellValue(scenarioName, "RowNoAlertEmailAddress")),
					getTestDataCellValue(scenarioName, "AlertEmailAddress"));
			CommonOperations.setListDropDownValue(
					(AppParameters_GeneralPageObjects.language_DropDown).replace("%rowNo%",
							getTestDataCellValue(scenarioName, "RowNoAlertEmailAddress")),
					getTestDataCellValue(scenarioName, "AlertLanguage"));

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.additionalAlertEmailID_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> General >> Additional Alert Email ID's Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Data Entered in Application Parameters >> General >> Additional Alert Email ID's Section Fails",
					true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read General Details in General
	 *             Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: SWajahatUmar
	 * @Date : 9-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadGeneralDetails(String scenarioName) {

		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			agClick(AppParameters_GeneralPageObjects.companyName_TextBox);
			String CompanyName = agGetAttribute("value", AppParameters_GeneralPageObjects.companyName_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CompanyName", CompanyName);

			agClick(AppParameters_GeneralPageObjects.alertOrigin_TextBox);
			String AlertOrigin = agGetAttribute("value", AppParameters_GeneralPageObjects.alertOrigin_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AlertOrigin", AlertOrigin);

			agClick(AppParameters_GeneralPageObjects.alertAdminEmail_TextBox);
			String AlertAdminEmail = agGetAttribute("value", AppParameters_GeneralPageObjects.alertAdminEmail_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AlertAdminEmail",
					AlertAdminEmail);

			String PaginatorGroupSize = agGetText(AppParameters_GeneralPageObjects.paginatorGroupSize_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "PaginatorGroupSize",
					PaginatorGroupSize);

			agClick(AppParameters_GeneralPageObjects.numberOfRecordsPerPage_TextBox);
			String NumberOfRecordsPerPage = agGetAttribute("value",
					AppParameters_GeneralPageObjects.numberOfRecordsPerPage_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "NumberOfRecordsPerPage",
					NumberOfRecordsPerPage);

			agClick(AppParameters_GeneralPageObjects.numberOfCasesForReassignation_TextBox);
			String NumberOfCasesForReassignation = agGetAttribute("value",
					AppParameters_GeneralPageObjects.numberOfCasesForReassignation_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"NumberOfCasesForReassignation", NumberOfCasesForReassignation);

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.auditReasonRequired_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AuditReasonRequired",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AuditReasonRequired",
						"false");
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.caseRemoveReasonRequired_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"CaseRemoveReasonRequired", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"CaseRemoveReasonRequired", "false");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_GeneralPageObjects.allowUsersToUnlockTheirOwnRecords_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowUsersToUnlockTheirOwnRecords", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowUsersToUnlockTheirOwnRecords", "false");
			}

			agClick(AppParameters_GeneralPageObjects.disableInactiveUsersAfterDays_TextBox);
			String DisableInactiveUsersAfterDays = agGetAttribute("value",
					AppParameters_GeneralPageObjects.disableInactiveUsersAfterDays_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"DisableInactiveUsersAfterDays", DisableInactiveUsersAfterDays);

			agClick(AppParameters_GeneralPageObjects.confidentialityNoteForReports_TextBox);
			String ConfidentialityNoteForReports = agGetAttribute("value",
					AppParameters_GeneralPageObjects.confidentialityNoteForReports_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"ConfidentialityNoteForReports", ConfidentialityNoteForReports);

			agClick(AppParameters_GeneralPageObjects.font_TextBox);
			String Font = agGetAttribute("value", AppParameters_GeneralPageObjects.font_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Font", Font);

			agClick(AppParameters_GeneralPageObjects.logFilePath_TextBox);
			String LogFilePath = agGetAttribute("value", AppParameters_GeneralPageObjects.logFilePath_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "LogFilePath", LogFilePath);

			agClick(AppParameters_GeneralPageObjects.maxFileSizeForManualUpload_TextBox);
			String MaxFileSizeForManualUpload = agGetAttribute("value",
					AppParameters_GeneralPageObjects.maxFileSizeForManualUpload_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"MaxFileSizeForManualUpload", MaxFileSizeForManualUpload);

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_GeneralPageObjects.convertInboundDocumentIntoPDF_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ConvertInboundDocumentIntoPDF", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ConvertInboundDocumentIntoPDF", "false");
			}
			agClick(AppParameters_GeneralPageObjects.temporaryPathForpdftiffFiles_TextBox);
			String TemporaryPathForpdftiffFiles = agGetAttribute("value",
					AppParameters_GeneralPageObjects.temporaryPathForpdftiffFiles_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"TemporaryPathForpdftiffFiles", TemporaryPathForpdftiffFiles);

			agClick(AppParameters_GeneralPageObjects.imageURL_TextBox);
			String ImageURL = agGetAttribute("value", AppParameters_GeneralPageObjects.imageURL_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ImageURL", ImageURL);

			agClick(AppParameters_GeneralPageObjects.ARISgClientURL_TextBox);
			String ARISgClientURL = agGetAttribute("value", AppParameters_GeneralPageObjects.ARISgClientURL_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ARISgClientURL",
					ARISgClientURL);

			String IntegretedToDD = agGetText(AppParameters_GeneralPageObjects.integratedTo_DropDown);

			if (IntegretedToDD.equalsIgnoreCase("--Select--")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "IntegratedTo", "");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "IntegratedTo",
						IntegretedToDD);
			}
			agClick(AppParameters_GeneralPageObjects.screenLockTimeoutMinutes_TextBox);
			String ScreenLockTimeoutMinutes = agGetAttribute("value",
					AppParameters_GeneralPageObjects.ARISgClientURL_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ScreenLockTimeoutMinutes",
					ScreenLockTimeoutMinutes);

			agClick(AppParameters_GeneralPageObjects.bulkImportPath_TextBox);
			String BulkImportPath = agGetAttribute("value", AppParameters_GeneralPageObjects.bulkImportPath_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "BulkImportPath",
					BulkImportPath);

			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> General Section - 1", true);

			// agSetValue(AppParameters_GeneralPageObjects.ocrPath_TextBox,
			// getTestDataCellValue(scenarioName, "OCRPath"));

			agClick(AppParameters_GeneralPageObjects.fuzzySearchFolderPath_TextBox);
			String FuzzySearchFolderPath = agGetAttribute("value",
					AppParameters_GeneralPageObjects.fuzzySearchFolderPath_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "FuzzySearchFolderPath",
					FuzzySearchFolderPath);

			String fuzzySimilarityScore_DropDown = agGetText(
					AppParameters_GeneralPageObjects.fuzzySimilarityScore_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "FuzzySimilarityScore",
					fuzzySimilarityScore_DropDown);

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_GeneralPageObjects.authenticateAgainstDatabaseIfUserIDnotFoundinLDAPServer_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AuthenticateAgainstDatabaseIfUserIDnotFoundinLDAPServer", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AuthenticateAgainstDatabaseIfUserIDnotFoundinLDAPServer", "false");
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.createCaseForEachInboundFile_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"CreateCaseForEachInboundFile", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"CreateCaseForEachInboundFile", "false");
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.displayErrorStacktrace_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DisplayErrorStacktrace", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DisplayErrorStacktrace", "false");
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.newDashboard_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "NewDashboard", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "NewDashboard",
						"false");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBoxYes(
					AppParameters_GeneralPageObjects.displayAnnouncementandTaskPopup_Radio)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DisplayAnnouncementandTaskPopup", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DisplayAnnouncementandTaskPopup", "No");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.dataPrivacyRequired_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DataPrivacyRequired",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DataPrivacyRequired",
						"false");
			}

			String EncryptionStandard = agGetText(AppParameters_GeneralPageObjects.encryptionStandard_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EncryptionStandard",
					EncryptionStandard);

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.passwordCheckForDocuments_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"PasswordCheckForDocuments", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"PasswordCheckForDocuments", "false");
			}

			String ApplicationTheme = agGetText(AppParameters_GeneralPageObjects.applicationTheme_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ApplicationTheme",
					ApplicationTheme);

			String CompanyUnitAccess = agGetText(AppParameters_GeneralPageObjects.companyUnitAccess_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CompanyUnitAccess",
					CompanyUnitAccess);

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.displayCopyright_Radio)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DisplayCopyright",
						"Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DisplayCopyright",
						"No");
			}

			agClick(AppParameters_GeneralPageObjects.displayCopyright_TextBox);
			String DisplayCopyrightMessage = agGetAttribute("value",
					AppParameters_GeneralPageObjects.displayCopyright_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DisplayCopyrightMessage",
					DisplayCopyrightMessage);

			agClick(AppParameters_GeneralPageObjects.disclaimerMessage_TextBox);
			String DisclaimerMessage = agGetAttribute("value",
					AppParameters_GeneralPageObjects.disclaimerMessage_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DisclaimerMessage",
					DisclaimerMessage);

			String TimeZonePreference = agGetText(AppParameters_GeneralPageObjects.timeZonePreference_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "TimeZonePreference",
					TimeZonePreference);

			String DateFormat = agGetText(AppParameters_GeneralPageObjects.dateFormat_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DateFormat", DateFormat);

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.ruleBuilderReportAccess_Radio)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"RuleBuilderReportAccess", "Masked");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"RuleBuilderReportAccess", "UnMasked");
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.mergeAllRoles_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "MergeAllRoles",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "MergeAllRoles",
						"false");
			}

			agClick(AppParameters_GeneralPageObjects.importConfigurationPath_TextBox);
			String ImportConfigurationPath = agGetAttribute("value",
					AppParameters_GeneralPageObjects.importConfigurationPath_TextBox);

			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ImportConfigurationPath",
					ImportConfigurationPath);

			// agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.ocrPath_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> General Section - 2", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data in Application Parameters >> General >> General Section - 2", true);
		}

	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Password Management Details
	 *             in General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 23-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadPasswordManagementDetails(String scenarioName) {
		try {
			agClick(AppParameters_GeneralPageObjects.minimumPasswordLength_TextBox);
			String MinimumPasswordLength = agGetAttribute("value",
					AppParameters_GeneralPageObjects.minimumPasswordLength_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "MinimumPasswordLength",
					MinimumPasswordLength);

			agClick(AppParameters_GeneralPageObjects.passwordExpiryDurationDays_TextBox);
			String PasswordExpiryDurationDays = agGetAttribute("value",
					AppParameters_GeneralPageObjects.passwordExpiryDurationDays_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"PasswordExpiryDurationDays", PasswordExpiryDurationDays);

			agClick(AppParameters_GeneralPageObjects.countOfWrongPasswordBeforeLockingAccount_TextBox);
			String CountOfWrongPasswordBeforeLockingAccount = agGetAttribute("value",
					AppParameters_GeneralPageObjects.countOfWrongPasswordBeforeLockingAccount_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"CountOfWrongPasswordBeforeLockingAccount", CountOfWrongPasswordBeforeLockingAccount);

			agClick(AppParameters_GeneralPageObjects.noOfWrongPasswordLoginSendingAlerts_TextBox);
			String NoOfWrongPasswordLoginSendingAlerts = agGetAttribute("value",
					AppParameters_GeneralPageObjects.noOfWrongPasswordLoginSendingAlerts_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"NoOfWrongPasswordLoginSendingAlerts", NoOfWrongPasswordLoginSendingAlerts);

			agClick(AppParameters_GeneralPageObjects.passwordResetReminderBeforeExpiry_TextBox);
			String PasswordResetReminderBeforeExpiry = agGetAttribute("value",
					AppParameters_GeneralPageObjects.passwordResetReminderBeforeExpiry_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"PasswordResetReminderBeforeExpiry", PasswordResetReminderBeforeExpiry);

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.lockAccountPermanently_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"LockAccountPermanently", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"LockAccountPermanently", "false");
			}

			String LockAccountPermanentlyMinutes = agGetText(
					AppParameters_GeneralPageObjects.lockAccountPermanentlyMinutes_TextBox);

			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"LockAccountPermanentlyMinutes", LockAccountPermanentlyMinutes);

			agClick(AppParameters_GeneralPageObjects.passwordReuseRestrictionCount_TextBox);
			String PasswordReuseRestrictionCount = agGetAttribute("value",
					AppParameters_GeneralPageObjects.passwordReuseRestrictionCount_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"PasswordReuseRestrictionCount", PasswordReuseRestrictionCount);

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.passwordManagement_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> Password Management Section", true);
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data in Application Parameters >> General >> Password Management Section Fails", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Case Triage and Adverse Event
	 *             Details in General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 23-falsev-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadCaseTriageAndAdverseEventDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			agClick(AppParameters_GeneralPageObjects.defaultNumberOfRecentlyOpenedAdverseEvents_TextBox);
			String DefaultNumberOfRecentlyOpenedAdverseEvents = agGetAttribute("value",
					AppParameters_GeneralPageObjects.defaultNumberOfRecentlyOpenedAdverseEvents_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"DefaultNumberOfRecentlyOpenedAdverseEvents", DefaultNumberOfRecentlyOpenedAdverseEvents);

			agClick(AppParameters_GeneralPageObjects.maxNumberOfCasesForCompleteActivity_TextBox);
			String MaxNumberOfCasesForCompleteActivity = agGetAttribute("value",
					AppParameters_GeneralPageObjects.maxNumberOfCasesForCompleteActivity_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"MaxNumberOfCasesForCompleteActivity", MaxNumberOfCasesForCompleteActivity);

			String ManageUserWorkload = agGetText(AppParameters_GeneralPageObjects.manageUserWorkload_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ManageUserWorkload",
					ManageUserWorkload);

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.displayProductLookup_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DisplayProductLookup",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DisplayProductLookup",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_GeneralPageObjects.formLevelUnitValidationOnSave_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"FormLevelUnitValidationOnSave", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"FormLevelUnitValidationOnSave", "false");
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.displaySwitchToForm_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DisplaySwitchToForm",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DisplaySwitchToForm",
						"false");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_GeneralPageObjects.showSupplementFieldsInSmartView_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ShowSupplementFieldsInSmartView", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ShowSupplementFieldsInSmartView", "false");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_GeneralPageObjects.displaySupplementFieldsOnCondition_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DisplaySupplementFieldsOnCondition", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DisplaySupplementFieldsOnCondition", "false");
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.protectConfidentiality_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ProtectConfidentiality", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ProtectConfidentiality", "false");
			}
			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.caseTriageAndAdverseEvent_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> Case Triage and Adverse Event Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data in Application Parameters >> General >> Case Triage and Adverse Event Section", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Case Identifier Details in
	 *             General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date :23-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadCaseIdentifierDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.protectConfidentiality_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ProtectConfidentiality", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ProtectConfidentiality", "false");
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.atLeastOneSuspectProduct_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AtLeastOneSuspectProduct", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AtLeastOneSuspectProduct", "false");
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.atLeastOneReportedTerm_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AtLeastOneReportedTerm", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AtLeastOneReportedTerm", "false");
			}

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_GeneralPageObjects.considerOnlyCompanySuspectProduct_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ConsiderOnlyCompanySuspectProduct", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ConsiderOnlyCompanySuspectProduct", "false");
			}

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.caseIdentifier_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> Case Identifier Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data in Application Parameters >> General >> Case Identifier Section", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Case Validity Identifier
	 *             Details in General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 23-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadCaseValidityIdentifierDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.patientAvailable_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "PatientAvailable",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "PatientAvailable",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.atLeastOneReporter_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AtLeastOneReporter",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AtLeastOneReporter",
						"false");

			}
			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.caseValidityIdentifier_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> Case Validity Identifier Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data in Application Parameters >> General >> Case Validity Identifier Section Fails", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read FAQ's & Templates Details in
	 *             General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 23-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadFAQsTemplatesDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			agClick(AppParameters_GeneralPageObjects.faqNumberingFormat_TextBox);
			String FAQNumberingFormat = agGetAttribute("value",
					AppParameters_GeneralPageObjects.faqNumberingFormat_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "FAQNumberingFormat",
					FAQNumberingFormat);

			String FAQNumberingFormat1 = agGetText(AppParameters_GeneralPageObjects.faqNumberingFormat1_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "FAQNumberingFormat1",
					FAQNumberingFormat1);

			String FAQNumberingFormat2 = agGetText(AppParameters_GeneralPageObjects.faqNumberingFormat2_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "FAQNumberingFormat2",
					FAQNumberingFormat2);

			agClick(AppParameters_GeneralPageObjects.faqExpiryPeriodDays_TextBox);
			String FAQExpiryPeriodDays = agGetAttribute("value",
					AppParameters_GeneralPageObjects.faqExpiryPeriodDays_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "FAQExpiryPeriodDays",
					FAQExpiryPeriodDays);

			agClick(AppParameters_GeneralPageObjects.faqTemplateWarningPeriodDays_TextBox);
			String FAQTemplateWarningPeriodDays = agGetAttribute("value",
					AppParameters_GeneralPageObjects.faqTemplateWarningPeriodDays_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"FAQTemplateWarningPeriodDays", FAQTemplateWarningPeriodDays);
			agClick(AppParameters_GeneralPageObjects.faqNumberingFormat_TextBox);
			String TemplateNumberingFormat = agGetAttribute("value",
					AppParameters_GeneralPageObjects.templateNumberingFormat_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "TemplateNumberingFormat",
					TemplateNumberingFormat);

			String TemplateNumberingFormat1 = agGetText(
					AppParameters_GeneralPageObjects.templateNumberingFormat1_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "TemplateNumberingFormat1",
					TemplateNumberingFormat1);

			String TemplateNumberingFormat2 = agGetText(
					AppParameters_GeneralPageObjects.templateNumberingFormat2_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "TemplateNumberingFormat2",
					TemplateNumberingFormat2);

			agClick(AppParameters_GeneralPageObjects.templateExpiryPeriodDays_TextBox);
			String TemplateExpiryPeriodDays = agGetAttribute("value",
					AppParameters_GeneralPageObjects.templateExpiryPeriodDays_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "TemplateExpiryPeriodDays",
					TemplateExpiryPeriodDays);

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.FAQsTemplates_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> FAQ's & Templates Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data in Application Parameters >> General >> FAQ's & Templates Section Fails", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Documents Details in General
	 *             Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar s
	 * @Date : 23-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadDocumentsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			agClick(AppParameters_GeneralPageObjects.documentsNumberingFormat_TextBox);
			String DocumentsNumberingFormat = agGetAttribute("value",
					AppParameters_GeneralPageObjects.documentsNumberingFormat_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DocumentsNumberingFormat",
					DocumentsNumberingFormat);

			String DocumentsNumberingFormat1 = agGetText(
					AppParameters_GeneralPageObjects.documentsNumberingFormat1_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DocumentsNumberingFormat1",
					DocumentsNumberingFormat1);

			String DocumentsNumberingFormat2 = agGetText(
					AppParameters_GeneralPageObjects.documentsNumberingFormat2_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DocumentsNumberingFormat2",
					DocumentsNumberingFormat2);

			agClick(AppParameters_GeneralPageObjects.documentsExpiryPeriodDays_TextBox);
			String DocumentsExpiryPeriodDays = agGetAttribute("value",
					AppParameters_GeneralPageObjects.documentsExpiryPeriodDays_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "DocumentsNumberingFormat",
					DocumentsExpiryPeriodDays);

			agClick(AppParameters_GeneralPageObjects.documentsWarningPeriodDay_TextBox);
			String DocumentsWarningPeriodDays = agGetAttribute("value",
					AppParameters_GeneralPageObjects.documentsWarningPeriodDay_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"DocumentsWarningPeriodDays", DocumentsWarningPeriodDays);

			String ExpiryWarningPeriodApplicableFor = agGetText(
					AppParameters_GeneralPageObjects.expiryWarningPeriodApplicableFor_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"ExpiryWarningPeriodApplicableFor", ExpiryWarningPeriodApplicableFor);

			agClick(AppParameters_GeneralPageObjects.waterMarkRuleForInternalEditor_TextBox);
			String WaterMarkRuleForInternalEditor = agGetAttribute("value",
					AppParameters_GeneralPageObjects.waterMarkRuleForInternalEditor_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"WaterMarkRuleForInternalEditor", WaterMarkRuleForInternalEditor);

			agClick(AppParameters_GeneralPageObjects.documentsFefaultBccEmailAddressForCorrespondence_TextBox);
			String DocumentsFefaultBccEmailAddressForCorrespondence = agGetAttribute("value",
					AppParameters_GeneralPageObjects.documentsFefaultBccEmailAddressForCorrespondence_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"DocumentsFefaultBccEmailAddressForCorrespondence",
					DocumentsFefaultBccEmailAddressForCorrespondence);

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.documents_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> Documents Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data in Application Parameters >> General >> Documents Section Fails", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Bibliography Details in
	 *             General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Umar
	 * @Date : 23-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadBibliographyDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agClick(AppParameters_GeneralPageObjects.bibliographyNumberingFormat_TextBox);
			String BibliographyNumberingFormat = agGetAttribute("value",
					AppParameters_GeneralPageObjects.bibliographyNumberingFormat_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"BibliographyNumberingFormat", BibliographyNumberingFormat);

			String BibliographyNumberingFormat1 = agGetText(
					AppParameters_GeneralPageObjects.bibliographyNumberingFormat1_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"BibliographyNumberingFormat1", BibliographyNumberingFormat1);

			String BibliographyNumberingFormat2 = agGetText(
					AppParameters_GeneralPageObjects.bibliographyNumberingFormat2_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"BibliographyNumberingFormat2", BibliographyNumberingFormat2);
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBoxYes(AppParameters_GeneralPageObjects.alwaysAvailable_Radio)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AlwaysAvailable",
						"Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AlwaysAvailable",
						"No");

			
				String BibliographyExpiryPeriodDays = agGetText(
						AppParameters_GeneralPageObjects.bibliographyExpiryPeriodDays_TextBox);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"BibliographyExpiryPeriodDays", BibliographyExpiryPeriodDays);

				agClick(AppParameters_GeneralPageObjects.bibliographyWarningPeriodDay_TextBox);
				String BibliographyWarningPeriodDay = agGetAttribute("value",
						AppParameters_GeneralPageObjects.bibliographyWarningPeriodDay_TextBox);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"BibliographyWarningPeriodDay", BibliographyWarningPeriodDay);
			}

			agClick(AppParameters_GeneralPageObjects.defaultNumberRecentlyOpenedBibliographies_TextBox);
			String DefaultNumberRecentlyOpenedBibliographies = agGetAttribute("value",
					AppParameters_GeneralPageObjects.defaultNumberRecentlyOpenedBibliographies_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"DefaultNumberRecentlyOpenedBibliographies", DefaultNumberRecentlyOpenedBibliographies);

			agClick(AppParameters_GeneralPageObjects.bibliographyDefaultBccEmailAddressCorrespondence_TextBox);
			String BibliographyDefaultBccEmailAddressCorrespondence = agGetAttribute("value",
					AppParameters_GeneralPageObjects.bibliographyDefaultBccEmailAddressCorrespondence_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"BibliographyDefaultBccEmailAddressCorrespondence",
					BibliographyDefaultBccEmailAddressCorrespondence);

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.bibliography_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> Bibliography Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read E-Signature Details in
	 *             General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar s
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadESignatureDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			if (agIsVisible(
					WorkFlowPageObjects.CheckedCheckBox(AppParameters_GeneralPageObjects.faq_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "FAQ_ESignature",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "FAQ_ESignature",
						"false");
			}
			if (agIsVisible(
					WorkFlowPageObjects.CheckedCheckBox(AppParameters_GeneralPageObjects.document_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Document_ESignature",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Document_ESignature",
						"false");
			}
			if (agIsVisible(
					WorkFlowPageObjects.CheckedCheckBox(AppParameters_GeneralPageObjects.template_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Template_ESignature",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Template_ESignature",
						"false");
			}

			if (agIsVisible(
					WorkFlowPageObjects.CheckedCheckBox(AppParameters_GeneralPageObjects.inquiry_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Inquiry_ESignature",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "Inquiry_ESignature",
						"false");
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_GeneralPageObjects.bibliography_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"Bibliography_ESignature", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"Bibliography_ESignature", "false");
			}

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.eSignature_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> E-Signature Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data in Application Parameters >> General >> E-Signature Section Fails", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Import Settings For Product
	 *             Lot/Batch Details Migration Details in General Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar s
	 * @Date :24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadImportSettingsforProductLotBatchDetailsMigrationDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			agClick(AppParameters_GeneralPageObjects.configurationFolderPath_TextBox);
			String ConfigurationFolderPath = agGetAttribute("value",
					AppParameters_GeneralPageObjects.configurationFolderPath_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ConfigurationFolderPath",
					ConfigurationFolderPath);

			agClick(AppParameters_GeneralPageObjects.backupFolderPath_TextBox);
			String BackupFolderPath = agGetAttribute("value",
					AppParameters_GeneralPageObjects.backupFolderPath_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "BackupFolderPath",
					BackupFolderPath);

			agClick(AppParameters_GeneralPageObjects.errorFolderPath_TextBox);
			String ErrorFolderPath = agGetAttribute("value", AppParameters_GeneralPageObjects.backupFolderPath_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ErrorFolderPath",
					ErrorFolderPath);

			agClick(AppParameters_GeneralPageObjects.acknowledgmentFolderPath_TextBox);
			String AcknowledgmentFolderPath = agGetAttribute("value",
					AppParameters_GeneralPageObjects.acknowledgmentFolderPath_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AcknowledgmentFolderPath",
					AcknowledgmentFolderPath);

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.importSettingsforProduct_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> Import Settings For Product Lot/Batch Details Migration Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data in Application Parameters >> General >> Import Settings For Product Lot/Batch Details Migration Section Fails",
					true);

		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Import Settings For Contact
	 *             Details in General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar s
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadImportSettingsForContactDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			agClick(AppParameters_GeneralPageObjects.importContactConfigurationFolderPath_TextBox);
			String ImportContactConfigurationFolderPath = agGetAttribute("value",
					AppParameters_GeneralPageObjects.importContactConfigurationFolderPath_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"ImportContactConfigurationFolderPath", ImportContactConfigurationFolderPath);

			agClick(AppParameters_GeneralPageObjects.importContactBackupFolderPath_TextBox);
			String ImportContactBackupFolderPath = agGetAttribute("value",
					AppParameters_GeneralPageObjects.importContactBackupFolderPath_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"ImportContactBackupFolderPath", ImportContactBackupFolderPath);

			agClick(AppParameters_GeneralPageObjects.importContactErrorFolderPath_TextBox);
			String ImportContactErrorFolderPath = agGetAttribute("value",
					AppParameters_GeneralPageObjects.importContactErrorFolderPath_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"ImportContactErrorFolderPath", ImportContactErrorFolderPath);

			agClick(AppParameters_GeneralPageObjects.importContactAcknowledgmentFolderPath_TextBox);
			String ImportContactAcknowledgmentFolderPath = agGetAttribute("value",
					AppParameters_GeneralPageObjects.importContactAcknowledgmentFolderPath_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"ImportContactAcknowledgmentFolderPath", ImportContactAcknowledgmentFolderPath);

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.importSettingsForContact_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> Import Settings For Contact Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data in Application Parameters >> General >> Import Settings For Contact Section Fails",
					true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Export Settings For Contact
	 *             Details in General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadExportSettingsForContactDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			agClick(AppParameters_GeneralPageObjects.exportContactConfigurationFolderPath_TextBox);
			String ExportContactConfigurationFolderPath = agGetAttribute("value",
					AppParameters_GeneralPageObjects.exportContactConfigurationFolderPath_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"ExportContactConfigurationFolderPath", ExportContactConfigurationFolderPath);

			agClick(AppParameters_GeneralPageObjects.exportContactBackupFolderPath_TextBox);
			String ExportContactBackupFolderPath = agGetAttribute("value",
					AppParameters_GeneralPageObjects.exportContactBackupFolderPath_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"ExportContactBackupFolderPath", ExportContactBackupFolderPath);

			agClick(AppParameters_GeneralPageObjects.exportContactErrorFolderPath_TextBox);
			String ExportContactErrorFolderPath = agGetAttribute("value",
					AppParameters_GeneralPageObjects.exportContactErrorFolderPath_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"ExportContactErrorFolderPath", ExportContactErrorFolderPath);

			agClick(AppParameters_GeneralPageObjects.exportContactAcknowledgmentFolderPath_TextBox);
			String ExportContactAcknowledgmentFolderPath = agGetAttribute("value",
					AppParameters_GeneralPageObjects.exportContactAcknowledgmentFolderPath_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"ExportContactAcknowledgmentFolderPath", ExportContactAcknowledgmentFolderPath);

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.exportSettingsForContact_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> Export Settings For Contact Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data in Application Parameters >> General >> Export Settings For Contact Section Fails",
					true);

		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Busy Scheduler Status Alert
	 *             Settings Details in General Tab under Application Parameters
	 *             Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadBusySchedulerStatusAlertSettingsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			String BusyAlertIfBusyFrom = agGetText(
					AppParameters_GeneralPageObjects.busySchedulerStatusAlertSettings_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "BusyAlertIfBusyFrom",
					BusyAlertIfBusyFrom);

			if (agIsVisible(AppParameters_GeneralPageObjects.BusySelectedSchedularList) == true) {
				{

					List<WebElement> Value = agGetElementList(
							AppParameters_GeneralPageObjects.BusySelectedSchedularList);
					String delim = ",";
					StringBuilder sb = new StringBuilder();
					int i = 0;
					for (i = 0; i < Value.size(); i++) {
						sb.append(Value.get(i).getText());
						sb.append(delim);
					}

					String res = sb.toString();
					res = sb.deleteCharAt(sb.length() - 1).toString();
					System.out.println(res);

					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
							"BusySchedulerStatusAlertSettings", res);
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
							"allBusySchedulerStatusAlertSettings", "#skip#");
				}

			}
			agJavaScriptExecuctorScrollToElement(
					AppParameters_GeneralPageObjects.busySchedulerStatusAlertSettings_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> Busy Scheduler Status Alert Settings Section",
					true);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> Busy Scheduler Status Alert Settings Section Fails",
					true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Busy Scheduler Status Alert
	 *             Settings Details in General Tab under Application Parameters
	 *             Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadStoppedIdleSchedulerStatusAlertReadtingsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			String BusyAlertIfBusyFrom = agGetText(
					AppParameters_GeneralPageObjects.stoppedIdleSchedulerStatusAlertSettings_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"StoppedIdleAlertIfBusyFrom", BusyAlertIfBusyFrom);
			if (agIsVisible(AppParameters_GeneralPageObjects.stoppedIdleSchedulerStatusAlertSettings_List) == true) {

				List<WebElement> Value = agGetElementList(
						AppParameters_GeneralPageObjects.stoppedIdleSchedulerStatusAlertSettings_List);
				String delim = ",";
				StringBuilder sb = new StringBuilder();
				int i = 0;
				for (i = 0; i < Value.size(); i++) {
					sb.append(Value.get(i).getText());
					sb.append(delim);
				}

				String res = sb.toString();
				res = sb.deleteCharAt(sb.length() - 1).toString();
				System.out.println(res);

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"StoppedIdleSchedulerStatusAlertSettings", res);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"allStoppedIdleSchedulerStatusAlertSettings", "#skip#");
			}

			agJavaScriptExecuctorScrollToElement(
					AppParameters_GeneralPageObjects.busySchedulerStatusAlertSettings_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> Busy Scheduler Status Alert Settings Section",
					true);
			// }

			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >>Read Stopped Idle Scheduler Status AlertReadtingsDetails Section",
					true);

		} catch (

		Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> Busy Scheduler Status Alert Settings Section Fails",
					true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Additional Alert Email ID's
	 *             in General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar s
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadAdditionalAlertEmailIDsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (agIsVisible(AppParameters_GeneralPageObjects.emailAddress_TextBox) == true) {

				agClick(AppParameters_GeneralPageObjects.emailAddress_TextBox);
				String AlertEmailAddress = agGetAttribute("value",
						AppParameters_GeneralPageObjects.emailAddress_TextBox);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AlertEmailAddress",
						AlertEmailAddress);
				String AlertLanguage = agGetText(AppParameters_GeneralPageObjects.language_DropDown);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AlertLanguage",
						AlertLanguage);

				agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.additionalAlertEmailID_Label);

				Reports.ExtentReportLog("", Status.INFO,
						"Read Data in Application Parameters >> General >> Additional Alert Email ID's Section", true);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data in Application Parameters >> General >> Additional Alert Email ID's Section Fails",
					true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Data Privacy Setting in
	 *             General Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 25-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadDataPrivacySettingDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			String ContactCategory = agGetText(AppParameters_GeneralPageObjects.contactCategory_DropDown);
			if (ContactCategory.equalsIgnoreCase("--Select--")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ContactCategory", "");
			} else {

				List<WebElement> Value = agGetElementList(AppParameters_GeneralPageObjects.contactSubCategory_Values);
				String delim = ",";
				StringBuilder sb = new StringBuilder();
				int i = 0;
				for (i = 0; i < Value.size(); i++) {
					sb.append(Value.get(i).getText());
					sb.append(delim);
				}

				String res = sb.toString();
				res = sb.deleteCharAt(sb.length() - 1).toString();
				System.out.println(res);

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "ContactSubCategory",
						res);
			}

			agJavaScriptExecuctorScrollToElement(AppParameters_GeneralPageObjects.dataPrivacySetting_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data in Application Parameters >> General >> Data Privacy Setting Section", true);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					"Read Data in Application Parameters >> General >> Data Privacy Setting Section Fails", true);
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set data in General Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 17-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setAppParameters_GeneralTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >>General Tab Started", true);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		setGeneralDetails(scenarioName);
		setPasswordManagementDetails(scenarioName);
		setCaseTriageAndAdverseEventDetails(scenarioName);
		setCaseIdentifierDetails(scenarioName);
		setCaseValidityIdentifierDetails(scenarioName);
		setFAQsTemplatesDetails(scenarioName);
		setDocumentsDetails(scenarioName);
		setBibliographyDetails(scenarioName);
		setESignatureDetails(scenarioName);
		setImportSettingsforProductLotBatchDetailsMigrationDetails(scenarioName);
		setImportSettingsForContactDetails(scenarioName);
		setExportSettingsForContactDetails(scenarioName);
		setDataPrivacySettingDetails(scenarioName);
		setBusySchedulerStatusAlertSettingsDetails(scenarioName);
		setStoppedIdleSchedulerStatusAlertSettingsDetails(scenarioName);
		setAdditionalAlertEmailIDsDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >>General Tab Completed",
				true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to verify General Details in General
	 *             Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 9-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void verifyAppParameters_GeneralTabDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		verifyGeneralDetails(scenarioName);
		verifyPasswordManagementDetails(scenarioName);
		verifyCaseTriageAndAdverseEventDetails(scenarioName);
		verifyCaseIdentifierDetails(scenarioName);
		verifyCaseValidityIdentifierDetails(scenarioName);
		verifyFAQsTemplatesDetails(scenarioName);
		verifyDocumentsDetails(scenarioName);
		verifyBibliographyDetails(scenarioName);
		verifyESignatureDetails(scenarioName);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read data in General Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 23-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadAppParameters_GeneralTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Read Data Entered in Application Parameters >>General Tab Started",
				true);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		ReadGeneralDetails(scenarioName);
		ReadPasswordManagementDetails(scenarioName);
		ReadCaseTriageAndAdverseEventDetails(scenarioName);
		ReadCaseIdentifierDetails(scenarioName);
		ReadCaseValidityIdentifierDetails(scenarioName);
		ReadFAQsTemplatesDetails(scenarioName);
		ReadDocumentsDetails(scenarioName);
		ReadBibliographyDetails(scenarioName);
		ReadESignatureDetails(scenarioName);
		ReadImportSettingsforProductLotBatchDetailsMigrationDetails(scenarioName);
		ReadImportSettingsForContactDetails(scenarioName);
		ReadImportSettingsForContactDetails(scenarioName);
		ReadDataPrivacySettingDetails(scenarioName);
		ReadBusySchedulerStatusAlertSettingsDetails(scenarioName);
		ReadStoppedIdleSchedulerStatusAlertReadtingsDetails(scenarioName);
		ReadAdditionalAlertEmailIDsDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO, "Read Data Entered in Application Parameters >>General Tab Completed",
				true);
	}
}
