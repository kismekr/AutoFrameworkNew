package com.arisglobal.framework.components.lsmv.L10_3;

import java.util.ArrayList;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.ANGPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class ANGOperations extends ToolManager {

	static String className = ANGOperations.class.getSimpleName();
	public static WebElement webElement;
	static XMLReader xmlRead = new XMLReader();
	public static String testDataPath = lsmvConstants.LSMV_testData;
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the NONAECase Narrative
	 *             template
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 22-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void verifyNonAENarrativeTemplate(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Study");
		agWaitTillInvisibilityOfElement(ANGPageObjects.contextViewBtn);
		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_SubjectID"));
		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_CenterNumber"));
		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyType"));
		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyName"));
		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyPhase"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Patient");
		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent"));
		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent_Units"));
		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_Gender"));
		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_LMPDate"));

		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Patient_MedicalHistory_DiseaseTerm"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductCharacterization")
				.equalsIgnoreCase("Suspect")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"));
		}
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductCharacterization")
				.equalsIgnoreCase("Concomitant")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"));
		}

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Pregnancy");
		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Pregnancy_CurrentPregnancyOutcomes_PregnancyOutcome"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Gen_CaseDates_InitialReceivedDate"));
		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_PrimarySourceCountry"));
		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Gen_CaseReferences_AuthorityNoCompNumber"));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click refresh button in Narrative
	 *             Edit screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 22-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void clickRefresh() {
		agClick(ANGPageObjects.editBtn);
		agClick(ANGPageObjects.refreshBtn);
		agClick(ANGPageObjects.okBtn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click regenerate button in
	 *             Narrative Edit screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 22-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void clickRegenerate() {
		agClick(ANGPageObjects.editBtn);
		agClick(ANGPageObjects.regenerateBtn);
		agClick(ANGPageObjects.okBtn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the CT[Clinical Trial] and
	 *             NTA[Non Trail Activities] Narrative template
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 22-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyCTNarrativeTemplate(String scenarioName) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		agWaitTillInvisibilityOfElement(ANGPageObjects.contextViewBtn);

		// Primary Source Country
		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_PrimarySourceCountry"));

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Study");
		// Center Number
		if (!getTestDataCellValue(scenarioName, "Study_StudyInformation_CenterNumber").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Study_StudyInformation_CenterNumber"));
		}
		// Subject ID
		if (!getTestDataCellValue(scenarioName, "Study_StudyInformation_SubjectID").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Study_StudyInformation_SubjectID"));
		}
		// Study no[Protocol No]
		if (!getTestDataCellValue(scenarioName, "Study_StudyLookup_StudyNo").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Study_StudyLookup_StudyNo"));
		}
		// Study Type
		if (!getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyType").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyType"));
		}
		// Study Name
		if (!getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyName").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyName"));
		}
		// Study Phase
		if (!getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyPhase").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Study_StudyInformation_StudyPhase"));
		}

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Patient");
		if (!getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent")
				.equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent"));
		}

		if (!getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent_Units")
				.equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent_Units"));
		}

		if (!getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_Gender").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_Gender"));
		}

		// Therapy start date
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		if (!getTestDataCellValue(scenarioName, "Products_Therapies_TherapyStartDate").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, " Study medication was started on "
					+ getTestDataCellValue(scenarioName, "Products_Therapies_TherapyStartDate"));
		} else {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"Start date of study medication was not provided");
			Reports.ExtentReportLog("", Status.PASS, "Start date of study medication was not provided", true);
		}

		// Product
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductCharacterization")
				.equalsIgnoreCase("Suspect")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "The patient was also taking "
					+ getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"));
		}

		// Event Onset Date
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
		if (!getTestDataCellValue(scenarioName, "Events_EventInformation_OnsetDate").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Events_EventInformation_OnsetDate"));
		} else {
			agAssertContainsText(ANGPageObjects.textarea_Description, " On an unknown date ");
			Reports.ExtentReportLog("", Status.PASS, "On an unknown date ", true);
		}

		// Event Reported Term
		if (!getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "the subject experienced "
					+ getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		}

		// Event Seriousness
		if (getTestDataCellValue(scenarioName, "Events_EventSeriousness_Seriousness").equalsIgnoreCase("Yes")
				&& getTestDataCellValue(scenarioName, "Events_EventSeriousness_Death").equalsIgnoreCase("Yes")
				&& getTestDataCellValue(scenarioName, "Events_EventSeriousness_LifeThreatening").equalsIgnoreCase("Yes")
				&& getTestDataCellValue(scenarioName, "Events_EventSeriousness_CausedProlongedHospitalization")
						.equalsIgnoreCase("Yes")
				&& getTestDataCellValue(scenarioName, "Events_EventSeriousness_RequiredIntervention")
						.equalsIgnoreCase("Yes")
				&& getTestDataCellValue(scenarioName, "Events_EventSeriousness_CongenitalAnomalyBirthDefect")
						.equalsIgnoreCase("Yes")
				&& getTestDataCellValue(scenarioName, "Events_EventSeriousness_DisabilityPermanentDamage")
						.equalsIgnoreCase("Yes")
				&& getTestDataCellValue(scenarioName, "Events_EventSeriousness_CausedProlongedHospitalization")
						.equalsIgnoreCase("Yes")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"which was considered serious due to the following criteria: required intervenation, life threatening, congenital anomaly, hospitalization, disability, medical significance and death");
		}

		// The patient recovered
		if (getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome").equalsIgnoreCase("Recovered/Resolved")
				|| getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome")
						.equalsIgnoreCase("Recovered/Resolved With Sequelae")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "The patient recovered on "
					+ getTestDataCellValue(scenarioName, "Events_EventInformation_CessationDate"));
		}

		// The patient had not yet recovered
		if (getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome")
				.equalsIgnoreCase("Recovered/not resolved/ongoing")
				|| getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome")
						.equalsIgnoreCase("Recovering/resolving")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "The patient had not yet recovered ");
			Reports.ExtentReportLog("", Status.PASS, "The patient had not yet recovered", true);
		}

		// Outcome is unknown
		if (getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome").equalsIgnoreCase("Unknown")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"The status of the "
							+ getTestDataCellValue(scenarioName,
									"Products_ProductInformation_ProductDescription_ProductName")
							+ " medication is unknown.");
		}

		// The patient died
		if (getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome").equalsIgnoreCase("Fatal")) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Patient");
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"The patient died " + getTestDataCellValue(scenarioName, "Patient_DeathDetails_DateOfDeath"));
		}

		// Action taken with drug
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ActionTakenWithDrug")
				.equalsIgnoreCase("Dose not changed")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "Study medication dose was maintained.");

		}
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ActionTakenWithDrug")
				.equalsIgnoreCase("Drug withdrawn")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "Study medication was discontinued on "
					+ getTestDataCellValue(scenarioName, "Products_Therapies_TherapyEndDate"));

		}
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ActionTakenWithDrug")
				.equalsIgnoreCase("Dose increased")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "Study medication dose was increased.");

		}
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ActionTakenWithDrug")
				.equalsIgnoreCase("Dose Reduced")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "Study medication dose was reduced.");

		}
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ActionTakenWithDrug")
				.equalsIgnoreCase("Unknown")
				|| (getTestDataCellValue(scenarioName, "Products_ProductInformation_ActionTakenWithDrug")
						.equalsIgnoreCase("#skip#"))) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "The status of the study medication is unknown");
		}

		// Patient Disease
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Patient");
		if (!getTestDataCellValue(scenarioName, "Patient_MedicalHistory_DiseaseTerm").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"Diseases included " + getTestDataCellValue(scenarioName, "Patient_MedicalHistory_DiseaseTerm"));
		} else {
			Reports.ExtentReportLog("", Status.PASS, "Medical history was not reported", true);
			agAssertContainsText(ANGPageObjects.textarea_Description, "Medical history was not reported");
		}

		// Concomitant medication
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductCharacterization")
				.equalsIgnoreCase("Concomitant")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "Concomitant therapy "
					+ getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"));
		} else {
			agAssertContainsText(ANGPageObjects.textarea_Description, "Concomitant medications were not reported");
		}

		// Reporter Casuality
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Causality");
		if (getTestDataCellValue(scenarioName, "Reporter_Casuality").equalsIgnoreCase("No Reasonable possibility")
				|| (getTestDataCellValue(scenarioName, "Reporter_Casuality").equalsIgnoreCase("#skip#"))) {

			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"The investigator considers that there was no reasonable possibility for a causal relationship between study medication and the event "
							+ getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		}

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Causality");
		if (getTestDataCellValue(scenarioName, "Reporter_Casuality").equalsIgnoreCase("Reasonable possibility")) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"The investigator considers that there was a reasonable possibility for a causal relationship between study medication and the event "
							+ getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		}

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Causality");
		if (getTestDataCellValue(scenarioName, "Reporter_Casuality").equalsIgnoreCase("Not Reported")) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"The investigator did not provide a causal assessment for event "
							+ getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		}

		// Company Casuality
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Causality");
		if (getTestDataCellValue(scenarioName, "Company_Casuality").equalsIgnoreCase("No Reasonable possibility")
				|| (getTestDataCellValue(scenarioName, "Company_Casuality").equalsIgnoreCase("#skip#"))) {

			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"For regulatory reporting purposes, Boehringer Ingelheim considers that there was no reasonable causal association between the study medication and the event "
							+ getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		}

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Causality");
		if (getTestDataCellValue(scenarioName, "Company_Casuality").equalsIgnoreCase("Reasonable possibility")) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"For regulatory reporting purposes, Boehringer Ingelheim considers that there was a reasonable causal association between the study medication and the event "
							+ getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		}

		// Initial Received Date
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		if (!getTestDataCellValue(scenarioName, "Gen_CaseDates_InitialReceivedDate").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Gen_CaseDates_InitialReceivedDate")
							+ ": initial information was received.");
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the SP[Spontaneous]
	 *             Narrative template
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 27-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifySPNarrativeTemplate(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		agWaitTillInvisibilityOfElement(ANGPageObjects.contextViewBtn);

		agAssertContainsText(ANGPageObjects.textarea_Description,
				getTestDataCellValue(scenarioName, "Gen_CaseSpecificInformation_PrimarySourceCountry"));

		if (!getTestDataCellValue(scenarioName, "Gen_CaseReferences_AuthorityNoCompNumber")
				.equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Gen_CaseReferences_AuthorityNoCompNumber"));
		} else {
			Reports.ExtentReportLog("", Status.PASS, "No Authority No displayed ", true);
		}

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductCharacterization")
				.equalsIgnoreCase("Suspect")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"));
		}

		if (!getTestDataCellValue(scenarioName, "Products_Therapies_FormOfAdmin").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Products_Therapies_FormOfAdmin"));
		}

		if (!getTestDataCellValue(scenarioName, "Products_Therapies_UnitDose").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Products_Therapies_UnitDose"));
		}

		if (!getTestDataCellValue(scenarioName, "Products_Therapies_UnitDoseUnit").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Products_Therapies_UnitDoseUnit"));
		}

		if (!getTestDataCellValue(scenarioName, "Products_Therapies_Frequency").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Products_Therapies_Frequency"));
		}

		if (!getTestDataCellValue(scenarioName, "Products_Therapies_FrequencyTime").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Products_Therapies_FrequencyTime"));
		}

		if (!getTestDataCellValue(scenarioName, "Products_Therapies_FrequencyTimeUnit").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Products_Therapies_FrequencyTimeUnit"));
		}

		if (getTestDataCellValue(scenarioName, "Products_Indications_IndicationTerm").equalsIgnoreCase("10057097")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "Drug use for unknown indication");
		} else if (!getTestDataCellValue(scenarioName, "Products_Indications_IndicationTerm")
				.equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "Indication for use was "
					+ getTestDataCellValue(scenarioName, "Products_Indications_IndicationTerm"));
		}

		if (!getTestDataCellValue(scenarioName, "Products_Therapies_LotNumber").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"The lot number was " + getTestDataCellValue(scenarioName, "Products_Therapies_LotNumber"));
		}

		// Therapy Start Date
		if (!getTestDataCellValue(scenarioName, "Products_Therapies_TherapyStartDate").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "The patient initiated treatment on "
					+ getTestDataCellValue(scenarioName, "Products_Therapies_TherapyStartDate"));
		}

		// Event Onset Date
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
		if (!getTestDataCellValue(scenarioName, "Events_EventInformation_OnsetDate").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Events_EventInformation_OnsetDate"));
		} else {
			agAssertContainsText(ANGPageObjects.textarea_Description, " On an unknown date ");
			Reports.ExtentReportLog("", Status.PASS, "On an unknown date ", true);
		}

		// Event Reported Term
		if (!getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "the patient experienced "
					+ getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		}

		// Event Seriousness
		if (getTestDataCellValue(scenarioName, "Events_EventSeriousness_Seriousness").equalsIgnoreCase("Yes")
				&& getTestDataCellValue(scenarioName, "Events_EventSeriousness_Death").equalsIgnoreCase("Yes")
				&& getTestDataCellValue(scenarioName, "Events_EventSeriousness_LifeThreatening").equalsIgnoreCase("Yes")
				&& getTestDataCellValue(scenarioName, "Events_EventSeriousness_CausedProlongedHospitalization")
						.equalsIgnoreCase("Yes")
				&& getTestDataCellValue(scenarioName, "Events_EventSeriousness_RequiredIntervention")
						.equalsIgnoreCase("Yes")
				&& getTestDataCellValue(scenarioName, "Events_EventSeriousness_CongenitalAnomalyBirthDefect")
						.equalsIgnoreCase("Yes")
				&& getTestDataCellValue(scenarioName, "Events_EventSeriousness_DisabilityPermanentDamage")
						.equalsIgnoreCase("Yes")
				&& getTestDataCellValue(scenarioName, "Events_EventSeriousness_CausedProlongedHospitalization")
						.equalsIgnoreCase("Yes")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"which was considered serious due to the following criteria: required intervenation, life threatening, congenital anomaly, hospitalization, disability, medical significance and death");
		}

		// The patient recovered
		if (getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome").equalsIgnoreCase("Recovered/Resolved")
				|| getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome")
						.equalsIgnoreCase("Recovered/Resolved With Sequelae")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "The patient recovered on "
					+ getTestDataCellValue(scenarioName, "Events_EventInformation_CessationDate"));
		}

		// The patient had not yet recovered
		if (getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome")
				.equalsIgnoreCase("Recovered/not resolved/ongoing")
				|| getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome")
						.equalsIgnoreCase("Recovering/resolving")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "The patient had not yet recovered ");
			Reports.ExtentReportLog("", Status.PASS, "The patient had not yet recovered", true);
		}

		// Outcome is unknown
		if (getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome").equalsIgnoreCase("Unknown")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"The status of the "
							+ getTestDataCellValue(scenarioName,
									"Products_ProductInformation_ProductDescription_ProductName")
							+ " medication is unknown.");
		}

		// The patient died
		if (getTestDataCellValue(scenarioName, "Events_EventInformation_Outcome").equalsIgnoreCase("Fatal")) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Patient");
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"The patient died " + getTestDataCellValue(scenarioName, "Patient_DeathDetails_DateOfDeath"));
		}

		// Action taken with drug
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ActionTakenWithDrug")
				.equalsIgnoreCase("Dose not changed")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName")
							+ " was continued");

		}
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ActionTakenWithDrug")
				.equalsIgnoreCase("Drug withdrawn")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName")
							+ " was discontinued");

		}
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ActionTakenWithDrug")
				.equalsIgnoreCase("Dose increased")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName")
							+ " dose was increased");

		}
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ActionTakenWithDrug")
				.equalsIgnoreCase("Dose Reduced")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName")
							+ " dose was reduced");

		}
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ActionTakenWithDrug")
				.equalsIgnoreCase("Unknown")
				|| (getTestDataCellValue(scenarioName, "Products_ProductInformation_ActionTakenWithDrug")
						.equalsIgnoreCase("#skip#"))) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName")
							+ " medication is unknown");
		}

		// Patient Disease
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Patient");
		if (!getTestDataCellValue(scenarioName, "Patient_MedicalHistory_DiseaseTerm").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"Diseases included " + getTestDataCellValue(scenarioName, "Patient_MedicalHistory_DiseaseTerm"));
		} else {
			Reports.ExtentReportLog("", Status.PASS, "Medical history was not reported", true);
			agAssertContainsText(ANGPageObjects.textarea_Description, "Medical history was not reported");
		}

		if (!getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent")
				.equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent"));
		}

		if (!getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent_Units")
				.equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_AgeAtTheTimeOfEvent_Units"));
		}

		if (!getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_Gender").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Patient_PatientIdentifiers_Gender"));
		}

		// Concomitant medication
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
		if (getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductCharacterization")
				.equalsIgnoreCase("Concomitant")) {
			agAssertContainsText(ANGPageObjects.textarea_Description, "Concomitant medication included "
					+ getTestDataCellValue(scenarioName, "Products_ProductInformation_ProductDescription_ProductName"));
		} else {
			agAssertContainsText(ANGPageObjects.textarea_Description, "Concomitant medications were not reported");
		}

		// Reporter Casuality
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Causality");
		if (getTestDataCellValue(scenarioName, "Reporter_Casuality").equalsIgnoreCase("No Reasonable possibility")
				|| (getTestDataCellValue(scenarioName, "Reporter_Casuality").equalsIgnoreCase("#skip#"))) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"The reporter considers that there was no reasonable possibility of a causal association between "
							+ getTestDataCellValue(scenarioName,
									"Products_ProductInformation_ProductDescription_ProductName"));

			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
			agAssertContainsText(ANGPageObjects.textarea_Description, " therapy and the event "
					+ getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		}

		else if (getTestDataCellValue(scenarioName, "Reporter_Casuality").equalsIgnoreCase("Reasonable possibility")) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"The reporter considers that there was a reasonable possibility of a causal association between "
							+ getTestDataCellValue(scenarioName,
									"Products_ProductInformation_ProductDescription_ProductName"));

			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
			agAssertContainsText(ANGPageObjects.textarea_Description, " therapy and the event "
					+ getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		}

		else if (getTestDataCellValue(scenarioName, "Reporter_Casuality").equalsIgnoreCase("Not Reported")) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"The reporter did not provide a causal assessment for event "
							+ getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		}

		// Company Casuality
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Causality");
		if (getTestDataCellValue(scenarioName, "Company_Casuality").equalsIgnoreCase("No Reasonable possibility")
				|| (getTestDataCellValue(scenarioName, "Company_Casuality").equalsIgnoreCase("#skip#"))) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"For regulatory reporting purposes, Boehringer Ingelheim considers that there was no reasonable causal association between "
							+ getTestDataCellValue(scenarioName,
									"Products_ProductInformation_ProductDescription_ProductName"));

			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
			agAssertContainsText(ANGPageObjects.textarea_Description, " therapy and the event "
					+ getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		}

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Causality");
		if (getTestDataCellValue(scenarioName, "Company_Casuality").equalsIgnoreCase("Reasonable possibility")) {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Products");
			agAssertContainsText(ANGPageObjects.textarea_Description,
					"For regulatory reporting purposes, Boehringer Ingelheim considers that there was a reasonable causal association between  "
							+ getTestDataCellValue(scenarioName,
									"Products_ProductInformation_ProductDescription_ProductName"));

			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");
			agAssertContainsText(ANGPageObjects.textarea_Description, " therapy and the event "
					+ getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		}

		// Initial Received Date
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		if (!getTestDataCellValue(scenarioName, "Gen_CaseDates_InitialReceivedDate").equalsIgnoreCase("#skip#")) {
			agAssertContainsText(ANGPageObjects.textarea_Description,
					getTestDataCellValue(scenarioName, "Gen_CaseDates_InitialReceivedDate")
							+ ": Initial information was received.");
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created Update the ANG data manually and
	 *             verify ANG
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 15-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void UpdateandVerifyANGData() {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Update and Verify ANG Data", true);
			FDE_Operations.tabNavigation("Narrative");
			if (agIsVisible(ANGPageObjects.editBtn) == true) {
				Reports.ExtentReportLog("", Status.INFO,
						"Edit Button is displayed in Event Description Text Box under Narrative", true);
				agClick(ANGPageObjects.editBtn);
				if (agIsVisible(ANGPageObjects.AutoNarrative) == true) {
					Reports.ExtentReportLog("", Status.INFO, "Context is displayed in AutoNarrative Section", true);
					agClick(ANGPageObjects.NonEditableTextBox);
					ArrayList<String> NonEditable = ANGOperations.GetNonEditableContext();
					int NEcount = NonEditable.size();
					System.out.print(NEcount);
					ArrayList<String> Editable = ANGOperations.GetEditableContext();
					int Ecount = Editable.size();
					System.out.print(Ecount);

					for (int i = 1; i < Ecount; i++) {
						String EditableText = Editable.get(i);
						int Space = ' ';
						int comma = ',';
						int stop = '.';

						if (EditableText.equalsIgnoreCase(Integer.toString(Space))
								|| EditableText.equalsIgnoreCase(Integer.toString(Space))
								|| EditableText.equalsIgnoreCase(Integer.toString(stop))) {
							Reports.ExtentReportLog("", Status.INFO, "Delimeters", true);
						} else {
							agSetStepExecutionDelay("3000");
							agClick(ANGPageObjects.Edit(String.valueOf(i)));
//							agClearText(ANGPageObjects.Edit(String.valueOf(i)));
							
							agSetValue(ANGPageObjects.Edit(String.valueOf(i)), "Update-ANG-Data");
							Reports.ExtentReportLog("", Status.INFO, "ANG Data Updated", true);
							agClick(ANGPageObjects.okBtn);
							agClick(FullDataEntryFormPageObjects.SaveButton);
							agWaitTillInvisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
							agClick(FullDataEntryFormPageObjects.saveOkButton);
							ArrayList<String> EventDescription = ANGOperations.GetEventDescriptionContext();
							int Eventcount = EventDescription.size();

							for (int j = 1; j < Eventcount; j++) {
								String EventText = EventDescription.get(j);
								if (EventText.contains("Update-ANG-Data")) {
									Reports.ExtentReportLog("", Status.PASS,
											"ANG Data Verified in Event Description TextBox", true);
									break;
								} else {
									Reports.ExtentReportLog("", Status.FAIL,
											"ANG Data not Verified in Event Description TextBox", true);
								}
							}

							agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
							break;
						}
					}
				} else {
					Reports.ExtentReportLog("", Status.INFO, "No Context Displayed", true);
				}
			} else {
				Reports.ExtentReportLog("", Status.INFO, "Event Description Cannot be Edited", true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.INFO, "Update and Verify ANG Data fails", true);
			if (agIsVisible(ANGPageObjects.CloseBtn) == true) {

				agJavaScriptExecuctorClick(ANGPageObjects.CloseBtn);
			}
		}
		Reports.ExtentReportLog("", Status.INFO, "Update and Verify ANG Data Ends", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Get list of editable values
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 17-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> GetEditableContext() {
		ArrayList Al = new ArrayList<>();
		String EditableText = agGetText(ANGPageObjects.EditableText);

		for (int i = 0; i < 20; i++) {
			Al.add(i, EditableText);
		}
		return Al;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Get list of Event Description data from
	 *             event description textarea
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 17-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> GetEventDescriptionContext() {
		ArrayList Al = new ArrayList<>();
		agClick(ANGPageObjects.textarea_Description);

		String Text = agGetAttribute("value", ANGPageObjects.textarea_Description);
		for (int i = 0; i < 20; i++) {
			Al.add(i, Text);
		}
		return Al;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to Get list of Non editable values
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 17-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList<String> GetNonEditableContext() {
		ArrayList Al = new ArrayList<>();
		String NonEditableText = agGetText(ANGPageObjects.NonEditableTextBox);

		for (int i = 0; i < 20; i++) {
			Al.add(i, NonEditableText);
		}
		return Al;
	}

}
