package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class BatchPrintConfigurationsPageObjects {

	public static String batchPrintListingSearchTextbox = "xpath#//input[@id='utilityConfigList:searchText']";
	public static String searchIcon = "xpath#//a[@id='utilityConfigList:findButton']/img";
	public static String paginator = "xpath#//div[@id='utilityConfigList:ippPrintDataTable_paginator_top']/span[@class='ui-paginator-current']";
	public static String editIcon = "xpath#//a[contains(@id,'editLink')] ";
	public static String printer_Details = "xpath#//label[@id='utilityConfig:j_id_me']";

	public static String refresh_icon = "xpath#//a[@id='utilityConfigList:refreshImage']";
	public static String get_ListofconfigrationName = "xpath#//tbody[@id='utilityConfigList:ippPrintDataTable_data']/tr/child::td[3]";
	public static String columnHeader = "xpath#(//tbody[@id='utilityConfigList:ippPrintDataTable_data']/tr/child::td[3])[{%count}]";

	public static String add_Btn = "xpath#//a[@id='utilityConfigList:newId']";
	public static String delete_Btn = "xpath#//a[@id='utilityConfigList:deleteId']";
	public static String getOperatingSystemName = "xpath#//label[@id='utilityConfig:opSys_label']";

	public static String batchConfigName_Txtfield = "xpath#//input[@id='utilityConfig:hostNameinput']";
	public static String click_OperatingSystem = "xpath#//div[@id='utilityConfig:opSys']/div/span";
	public static String set_OperatingSystem = "xpath#//ul[@id='utilityConfig:opSys_items']/li[text()='%s']";
	public static String hostName_Txtfield = "xpath#//input[@id='utilityConfig:urlInput']";
	public static String pdfPath_Txtfield = "xpath#//input[@id='utilityConfig:PDFpathInput']";
	public static String printerPortTxtfield = "xpath#//input[@id='utilityConfig:portInput']";
	public static String compressedFileSize_Txtfield = "xpath#//input[@id='utilityConfig:attSize']";
	public static String medwatch_Txtfield = "xpath#//input[@id='utilityConfig:medwatchlimit']";
	public static String cimos_Txtfield = "xpath#//input[@id='utilityConfig:ciomsLimit']";
	public static String warnAfter_Txtfield = "xpath#//input[@id='utilityConfig:warnAfttLimit']";
	public static String numberOfDaysArchive_Txtfield = "xpath#//input[@id='utilityConfig:numberOfDays']";
	public static String NumberOfDaysToDelete_Txtfield = "xpath#//input[@id='utilityConfig:numberOfDaysForDelete']";
	public static String coverPageDisclaimer_Txtarea = "xpath#//textarea[@id='utilityConfig:coverPageDisclaimer']";

	public static String save_Btn = "xpath#//button[@id='utilityConfig:visibleSave']";
	public static String SaveOkBtn = "xpath#//button[@id='mandatoryDialogform:okButton']/span";
	public static String cancel_Btn = "xpath#//button[@id='utilityConfig:cancelId']";

	public static String listingScreen_CheckBoxs = "xpath#//td[text()='%s']/ancestor::tbody[@id='utilityConfigList:ippPrintDataTable_data']/tr/td/div/child::div/span";

	public static String downloadIcon = "xpath#//a[@id='utilityConfigList:actionId']";
	public static String exporttoExcel_link = "xpath#//button[contains(@id,'utilityConfigList:j_id')]/span[text()='Export To Excel']";
	public static String exporttoExcel_popup = "xpath#//span[@id='listingForm:columnSelectionDialogId_title']";
	public static String export_Btn = "xpath#//button[@id='utilityConfigList:submitId']";
	public static String exportexcelcancel_Btn = "xpath#//button[@id='utilityConfigList:cancelDialogId']";

	public static String set_OperatingSystem(String runTimeLabel) {
		String value = set_OperatingSystem;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:The below method is created to select checkbox by passing value at
	 *                runtime.
	 * @Input Parameters: runTimeLabel
	 * @Scenario Name Output
	 * @Parameters:
	 * @author:Avinash K Date :18-Oct-2019 Updated by and when
	 **********************************************************************************************************/

	public static String selectListingCheckbox(String runTimeLabel) {
		String value = listingScreen_CheckBoxs;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective:get substance name by passing input Parameters:rowNum Output
	 * @Parameters: Case data attribute value
	 * @author:DushyanthMahesh Date :16-September-2019 Updated by and when
	 **********************************************************************************************************/
	public static String columnHeaderList(String num) {
		String value = columnHeader;
		String value2;
		value2 = value.replace("{%count}", num);
		return value2;
	}

}