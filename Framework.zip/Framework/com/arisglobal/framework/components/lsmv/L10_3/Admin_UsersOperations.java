package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.UsersPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Admin_UsersOperations extends ToolManager {
	static String className = Admin_UsersOperations.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: The below method is created to search User.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static boolean searchUser(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("3000");
		agAssertVisible(UsersPageObjects.searchListing_TextBox);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetValue(UsersPageObjects.searchListing_TextBox, getTestDataCellValue(scenarioName, "SearchText"));
		agClick(UsersPageObjects.search_Icon);
		CommonOperations.takeScreenShot();
		agSetStepExecutionDelay("5000");
		String paginator = agGetText(UsersPageObjects.paginator);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.PASS,
					"Search Result with '" + getTestDataCellValue(scenarioName, "SearchText") + "' exists!", true);
			return true;
		} else {
			return false;
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click on New Button in User
	 *             Listing Screen.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickNewButton() {
		agClick(UsersPageObjects.newButton);
		agAssertVisible(UsersPageObjects.firstName_TextBox);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit User.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void editUser() {
		agClick(UsersPageObjects.edit_Icon);
		agAssertVisible(UsersPageObjects.firstName_TextBox);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to save User.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void saveUser(String scenarioName) {
		agClick(UsersPageObjects.saveButton);
		CommonOperations.setAuditInfo(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set User Details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 10-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setUserDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		CommonOperations.clickRadioButton(UsersPageObjects.userType_RadioBtn,
				getTestDataCellValue(scenarioName, "UserType"));
		CommonOperations.setListDropDownValue(UsersPageObjects.title_DropDown,
				getTestDataCellValue(scenarioName, "Title"));
		agSetValue(UsersPageObjects.firstName_TextBox, getTestDataCellValue(scenarioName, "FirstName"));
		agSetValue(UsersPageObjects.middleName_TextBox, getTestDataCellValue(scenarioName, "MiddleName"));
		agSetValue(UsersPageObjects.lastName_TextBox, getTestDataCellValue(scenarioName, "LastName"));
		agSetValue(UsersPageObjects.designation_TextBox, getTestDataCellValue(scenarioName, "Designation"));
		CommonOperations.setListDropDownValue(UsersPageObjects.department_DropDown,
				getTestDataCellValue(scenarioName, "Department"));
		agSetValue(UsersPageObjects.userName_TextBox, getTestDataCellValue(scenarioName, "UserName"));
		CommonOperations.clickCheckBoxLeftOf(UsersPageObjects.ssoUser_CheckBox,
				getTestDataCellValue(scenarioName, "SSOUser"));
		CommonOperations.clickCheckBoxLeftOf(UsersPageObjects.webServiceUser_CheckBox,
				getTestDataCellValue(scenarioName, "WebServiceUser"));
		CommonOperations.setListDropDownValue(UsersPageObjects.ldapDomain_DropDown,
				getTestDataCellValue(scenarioName, "LDAPDomain"));
		agSetValue(UsersPageObjects.degree_TextBox, getTestDataCellValue(scenarioName, "Degree"));
		agSetValue(UsersPageObjects.emailId_TextBox, getTestDataCellValue(scenarioName, "EmailId"));
		agSetValue(UsersPageObjects.mobileId_TextBox, getTestDataCellValue(scenarioName, "MobileId"));
		agSetValue(UsersPageObjects.phoneCntryCode_TextBox, getTestDataCellValue(scenarioName, "PhoneCountryCode"));
		agSetValue(UsersPageObjects.phoneAreaCode_TextBox, getTestDataCellValue(scenarioName, "PhoneAreaCode"));
		agSetValue(UsersPageObjects.phoneNo_TextBox, getTestDataCellValue(scenarioName, "PhoneNumber"));
		agSetValue(UsersPageObjects.faxCntryCode_TextBox, getTestDataCellValue(scenarioName, "FaxCountryCode"));
		agSetValue(UsersPageObjects.faxAreaCode_TextBox, getTestDataCellValue(scenarioName, "FaxAreaCode"));
		agSetValue(UsersPageObjects.faxNumber_TextBox, getTestDataCellValue(scenarioName, "FaxNumber"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in User >> General >> User Details Section 1 : Scenario Name::" + scenarioName, true);

		agSetValue(UsersPageObjects.batchPrintLimit_TextBox, getTestDataCellValue(scenarioName, "BatchPrintLimit"));
		agSetValue(UsersPageObjects.batchPrintRunningCount_TextBox,
				getTestDataCellValue(scenarioName, "BatchPrintRunningCount"));
		CommonOperations.clickCheckBoxLeftOf(UsersPageObjects.accountLocked_CheckBox,
				getTestDataCellValue(scenarioName, "AccountLocked"));
		CommonOperations.clickCheckBoxLeftOf(UsersPageObjects.active_CheckBox,
				getTestDataCellValue(scenarioName, "Active"));
		CommonOperations.clickCheckBoxLeftOf(UsersPageObjects.alsoPortalUser_CheckBox,
				getTestDataCellValue(scenarioName, "AlsoAPortalUser"));
		if (getTestDataCellValue(scenarioName, "AlsoAPortalUser").equalsIgnoreCase("true")) {
			CommonOperations.setListDropDownValue(UsersPageObjects.companyUnit_DropDown,
					getTestDataCellValue(scenarioName, "CompanyUnit"));
			CommonOperations.clickCheckBoxLeftOf(UsersPageObjects.deleteAccess_CheckBox,
					getTestDataCellValue(scenarioName, "DeleteAccess"));
		}
		CommonOperations.clickCheckBoxLeftOf(UsersPageObjects.multiDatabaseAccess_CheckBox,
				getTestDataCellValue(scenarioName, "MultiDatabaseAccess"));
		CommonOperations.clickCheckBoxLeftOf(UsersPageObjects.loginUnderMaintenance_CheckBox,
				getTestDataCellValue(scenarioName, "LoginUnderMaintenance"));

		agJavaScriptExecuctorScrollToElement(UsersPageObjects.mobileId_TextBox);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in User >> General >> User Details Section 2 : Scenario Name::" + scenarioName, true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify User Details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 10-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyUserDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.verifyRadioButton(UsersPageObjects.userType_RadioBtn,
				getTestDataCellValue(scenarioName, "UserType"));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Title"), UsersPageObjects.title_DropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FirstName"),
				UsersPageObjects.firstName_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MiddleName"),
				UsersPageObjects.middleName_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "LastName"),
				UsersPageObjects.lastName_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Designation"),
				UsersPageObjects.designation_TextBox);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Department"), UsersPageObjects.department_DropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "UserName"),
				UsersPageObjects.userName_TextBox);
		CommonOperations.verifyCheckBoxLeftOf(UsersPageObjects.ssoUser_CheckBox,
				getTestDataCellValue(scenarioName, "SSOUser"));
		CommonOperations.verifyCheckBoxLeftOf(UsersPageObjects.webServiceUser_CheckBox,
				getTestDataCellValue(scenarioName, "WebServiceUser"));
		agCheckPropertyText(getTestDataCellValue(scenarioName, "LDAPDomain"), UsersPageObjects.ldapDomain_DropDown);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "Degree"), UsersPageObjects.degree_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "EmailId"), UsersPageObjects.emailId_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MobileId"),
				UsersPageObjects.mobileId_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PhoneCountryCode"),
				UsersPageObjects.phoneCntryCode_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PhoneAreaCode"),
				UsersPageObjects.phoneAreaCode_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PhoneNumber"),
				UsersPageObjects.phoneNo_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FaxCountryCode"),
				UsersPageObjects.faxCntryCode_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FaxAreaCode"),
				UsersPageObjects.faxAreaCode_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "FaxNumber"),
				UsersPageObjects.faxNumber_TextBox);

		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in User >> General >> User Details Section 1 : Scenario Name::" + scenarioName,
				true);

		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "BatchPrintLimit"),
				UsersPageObjects.batchPrintLimit_TextBox);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "BatchPrintRunningCount"),
				UsersPageObjects.batchPrintRunningCount_TextBox);
		CommonOperations.verifyCheckBoxLeftOf(UsersPageObjects.accountLocked_CheckBox,
				getTestDataCellValue(scenarioName, "AccountLocked"));
		CommonOperations.verifyCheckBoxLeftOf(UsersPageObjects.active_CheckBox,
				getTestDataCellValue(scenarioName, "Active"));
		CommonOperations.verifyCheckBoxLeftOf(UsersPageObjects.alsoPortalUser_CheckBox,
				getTestDataCellValue(scenarioName, "AlsoAPortalUser"));
		if (getTestDataCellValue(scenarioName, "AlsoAPortalUser").equalsIgnoreCase("true")) {
			CommonOperations.verifyCheckBoxLeftOf(UsersPageObjects.deleteAccess_CheckBox,
					getTestDataCellValue(scenarioName, "DeleteAccess"));
		}
		CommonOperations.verifyCheckBoxLeftOf(UsersPageObjects.multiDatabaseAccess_CheckBox,
				getTestDataCellValue(scenarioName, "MultiDatabaseAccess"));
		CommonOperations.verifyCheckBoxLeftOf(UsersPageObjects.loginUnderMaintenance_CheckBox,
				getTestDataCellValue(scenarioName, "LoginUnderMaintenance"));

		agJavaScriptExecuctorScrollToElement(UsersPageObjects.mobileId_TextBox);
		Reports.ExtentReportLog("", Status.INFO,
				"Data Verification in User >> General >> User Details Section 2 : Scenario Name::" + scenarioName,
				true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Portal Settings Details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 10-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setPortalSettingsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		if (getTestDataCellValue(scenarioName, "AlsoAPortalUser").equalsIgnoreCase("true")
				|| getTestDataCellValue(scenarioName, "UserType").equalsIgnoreCase("Portal")) {
			CommonOperations.clickCheckBoxLeftOf(UsersPageObjects.studyManager_CheckBox,
					getTestDataCellValue(scenarioName, "StudyManager"));
			CommonOperations.clickCheckBoxLeftOf(UsersPageObjects.adverseEvent_CheckBox,
					getTestDataCellValue(scenarioName, "AdverseEvent"));
			if (getTestDataCellValue(scenarioName, "AdverseEvent").equalsIgnoreCase("true")) {
				CommonOperations.clickCheckBoxLeftOf(UsersPageObjects.adverseEventListing_CheckBox,
						getTestDataCellValue(scenarioName, "AdverseEventListing"));
				if (getTestDataCellValue(scenarioName, "AdverseEventListing").equalsIgnoreCase("true")) {
					CommonOperations.clickCheckBoxLeftOf(UsersPageObjects.adverseEventFollowUp_CheckBox,
							getTestDataCellValue(scenarioName, "AdverseEventFollowUp"));
				}
			}
			CommonOperations.clickCheckBoxLeftOf(UsersPageObjects.documents_CheckBox,
					getTestDataCellValue(scenarioName, "Documents"));
			CommonOperations.clickCheckBoxLeftOf(UsersPageObjects.hcpDocumentSearch_CheckBox,
					getTestDataCellValue(scenarioName, "HCPDocumentSearch"));
			CommonOperations.clickCheckBoxLeftOf(UsersPageObjects.FAQs_CheckBox,
					getTestDataCellValue(scenarioName, "FAQs"));
			CommonOperations.clickCheckBoxLeftOf(UsersPageObjects.reporterOffLineAccess_CheckBox,
					getTestDataCellValue(scenarioName, "ReporterOffLineAccess"));

			agJavaScriptExecuctorScrollToElement(UsersPageObjects.batchPrintLimit_TextBox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in User >> General >> Portal Settings Section : Scenario Name::" + scenarioName,
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Portal Settings Details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 10-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyPortalSettingsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "AlsoAPortalUser").equalsIgnoreCase("true")
				|| getTestDataCellValue(scenarioName, "UserType").equalsIgnoreCase("Portal")) {
			CommonOperations.verifyCheckBoxLeftOf(UsersPageObjects.studyManager_CheckBox,
					getTestDataCellValue(scenarioName, "StudyManager"));
			CommonOperations.verifyCheckBoxLeftOf(UsersPageObjects.adverseEvent_CheckBox,
					getTestDataCellValue(scenarioName, "AdverseEvent"));
			if (getTestDataCellValue(scenarioName, "AdverseEvent").equalsIgnoreCase("true")) {
				CommonOperations.verifyCheckBoxLeftOf(UsersPageObjects.adverseEventListing_CheckBox,
						getTestDataCellValue(scenarioName, "AdverseEventListing"));
				if (getTestDataCellValue(scenarioName, "AdverseEventListing").equalsIgnoreCase("true")) {
					CommonOperations.verifyCheckBoxLeftOf(UsersPageObjects.adverseEventFollowUp_CheckBox,
							getTestDataCellValue(scenarioName, "AdverseEventFollowUp"));
				}
			}
			CommonOperations.verifyCheckBoxLeftOf(UsersPageObjects.documents_CheckBox,
					getTestDataCellValue(scenarioName, "Documents"));
			CommonOperations.verifyCheckBoxLeftOf(UsersPageObjects.hcpDocumentSearch_CheckBox,
					getTestDataCellValue(scenarioName, "HCPDocumentSearch"));
			CommonOperations.verifyCheckBoxLeftOf(UsersPageObjects.FAQs_CheckBox,
					getTestDataCellValue(scenarioName, "FAQs"));
			CommonOperations.verifyCheckBoxLeftOf(UsersPageObjects.reporterOffLineAccess_CheckBox,
					getTestDataCellValue(scenarioName, "ReporterOffLineAccess"));

			agJavaScriptExecuctorScrollToElement(UsersPageObjects.batchPrintLimit_TextBox);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Verification in User >> General >> Portal Settings Section : Scenario Name::" + scenarioName,
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Company Unit(s) / Processing
	 *             Unit(s) Details
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setCompanyUnitsProcessingUnitsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		switch (getTestDataCellValue(scenarioName, "CaseListingAccess")) {
		case "Company Unit(s)":
			agClick(UsersPageObjects
					.caseListingAccessRadioBtn(getTestDataCellValue(scenarioName, "CaseListingAccess")));
			CommonOperations.setListDropDownValue(UsersPageObjects.allCompanyUnits_DropDown,
					getTestDataCellValue(scenarioName, "AllCompanyUnits"));
			if (getTestDataCellValue(scenarioName, "AllCompanyUnits").equalsIgnoreCase("Read/Update")) {
				CommonOperations.setListDropDownValue(UsersPageObjects.default_DropDown,
						getTestDataCellValue(scenarioName, "AllCompanyUnitsDefault"));
			}
			if (getTestDataCellValue(scenarioName, "boolAddCompanyUnits").equalsIgnoreCase("true")) {
				// agClick(UsersPageObjects.clickAddButtonOf(UsersPageObjects.allCompanyUnits_label));
			}
			break;
		case "Processing Unit(s)":
			agClick(UsersPageObjects
					.caseListingAccessRadioBtn(getTestDataCellValue(scenarioName, "CaseListingAccess")));
			CommonOperations.setListDropDownValue(UsersPageObjects.allProcessingUnits_DropDown,
					getTestDataCellValue(scenarioName, "AllProcessingUnits"));
			if (getTestDataCellValue(scenarioName, "boolAddProcessingUnits").equalsIgnoreCase("true")) {
				// agClick(UsersPageObjects.clickAddButtonOf(UsersPageObjects.allProcessingUnits_label));
			}
			break;
		}

		agJavaScriptExecuctorScrollToElement(UsersPageObjects.companyUnitProcessingUnit_Label);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in User >> General >> Company Unit(s) / Processing Unit(s) Section : Scenario Name::"
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Distribution Units/Contacts ID
	 *             Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setDistributionUnitsContactsIdDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.setListDropDownValue(UsersPageObjects.allUnitsContactsID_DropDown,
				getTestDataCellValue(scenarioName, "AllUnitsContactsID"));
		if (getTestDataCellValue(scenarioName, "boolAddAllUnitsContactsID").equalsIgnoreCase("true")) {
			String subName = getTestDataCellValue(scenarioName, "ContactName");
			String[] totalRecords = subName.split(",");
			for (int i = 0; i < totalRecords.length; i++) {
				agSetStepExecutionDelay("2000");
				agClick(UsersPageObjects.clickAddButtonOf(UsersPageObjects.allUnitsContactsID_label));
				agSetValue(UsersPageObjects.contactName_TextBox, totalRecords[i]);
				agClick(UsersPageObjects.searchSubContactLookup_Button);
				agClick(CommonPageObjects.selectListingCheckbox(totalRecords[i]));
				CommonOperations.takeScreenShot();
				agClick(UsersPageObjects.okSubContactLookup_Button);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				if (getTestDataCellValue(scenarioName, "ReadAccess").equalsIgnoreCase(totalRecords[i])) {
					agClick(UsersPageObjects.selectGridRadioButton(totalRecords[i]));
				}
			}
		}
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorScrollToElement(UsersPageObjects.DistributionUnitsContactsID_Label);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in User >> General >> Distribution Units/Contacts ID Section : Scenario Name::"
						+ scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Submitting Units Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 4-Feb-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSubmittingUnitsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.setListDropDownValue(UsersPageObjects.allSubmittingUnits_DropDown,
				getTestDataCellValue(scenarioName, "AllSubmittingUnits"));
		if (getTestDataCellValue(scenarioName, "boolAllSubmittingUnits").equalsIgnoreCase("true")) {
			CommonOperations.setCompanyUnitLookupDetails(getTestDataCellValue(scenarioName, "UnitCode"),
					getTestDataCellValue(scenarioName, "UnitName"), getTestDataCellValue(scenarioName, "Type"),
					getTestDataCellValue(scenarioName, "Country"));
		}
		if (!getTestDataCellValue(scenarioName, "SubmittingUnitsReadAccess").equalsIgnoreCase("#skip#")) {
			agClick(UsersPageObjects.selectGridRadioButton(getTestDataCellValue(scenarioName, "UnitName")));
		}
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorScrollToElement(UsersPageObjects.submittingUnits_Label);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in User >> General >> Submitting Units Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Roles Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setRolesDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "boolAddRole").equalsIgnoreCase("true")) {
			String subName = getTestDataCellValue(scenarioName, "RoleName");
			String[] totalRecords = subName.split(",");
			for (int i = 0; i < totalRecords.length; i++) {
				agClick(UsersPageObjects.clickAddButtonOf(UsersPageObjects.roles_label));
				agSetStepExecutionDelay("3000");
				agSetValue(UsersPageObjects.roleName_TextBox, totalRecords[i]);
				agClick(UsersPageObjects.searchRolesLookup_Button);
				agClick(CommonPageObjects.selectListingCheckbox(totalRecords[i]));
				agSetStepExecutionDelay("1000");
				CommonOperations.takeScreenShot();
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				agClick(UsersPageObjects.okRolesLookup_Button);
				if (getTestDataCellValue(scenarioName, "DefaultRole").equalsIgnoreCase(totalRecords[i])) {
					agClick(UsersPageObjects.selectGridRadioButton(totalRecords[i]));
				}
			}
		}
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorScrollToElement(UsersPageObjects.roles_div);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in User >> General >> Roles Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Group Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setGroupDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "boolAddGroup").equalsIgnoreCase("true")) {
			String subName = getTestDataCellValue(scenarioName, "GroupData");
			String[] totalRecords = subName.split(",");
			for (int i = 0; i < totalRecords.length; i++) {
				agClick(UsersPageObjects.clickAddButtonOf(UsersPageObjects.group_label));
				agSetValue(UsersPageObjects.groupName_TextBox, totalRecords[i]);
				agClick(UsersPageObjects.searchGroupLookup_Button);
				agSetStepExecutionDelay("1000");
				agJavaScriptExecuctorClick(CommonPageObjects.selectListingCheckbox(totalRecords[i]));
				CommonOperations.takeScreenShot();
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				agClick(UsersPageObjects.okGroupLookup_Button);
			}
		}
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorScrollToElement(UsersPageObjects.group_div);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in User >> General >> Group Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Other Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setOtherDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(UsersPageObjects.otherDetails_Tab);
		agSetValue(UsersPageObjects.maxNoOfCasesDayUser_TextBox,
				getTestDataCellValue(scenarioName, "MaxNoOfCasesDayUser"));
		CommonOperations.clickCheckBoxRightOf(UsersPageObjects.accessAllEligibleProducts_CheckBox,
				getTestDataCellValue(scenarioName, "AccessAllEligibleProducts"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in User >> Other Details >> Other Details Section : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Other Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyOtherDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(UsersPageObjects.otherDetails_Tab);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MaxNoOfCasesDayUser"),
				UsersPageObjects.maxNoOfCasesDayUser_TextBox);
		CommonOperations.verifyCheckBoxRightOf(UsersPageObjects.accessAllEligibleProducts_CheckBox,
				getTestDataCellValue(scenarioName, "AccessAllEligibleProducts"));

		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in User >> Other Details >> Other Details Section : Scenario Name::" + scenarioName,
				true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created for new User Creation.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createUser(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		clickNewButton();
		setUserDetails(scenarioName);
		setPortalSettingsDetails(scenarioName);
		setCompanyUnitsProcessingUnitsDetails(scenarioName);
		if (agIsVisible(UsersPageObjects.allUnitsContactsID_DropDown) == true) {
			setDistributionUnitsContactsIdDetails(scenarioName);
		} else {
			setSubmittingUnitsDetails(scenarioName);
		}
		setRolesDetails(scenarioName);
		setGroupDetails(scenarioName);
		if (getTestDataCellValue(scenarioName, "boolOtherDetails").equalsIgnoreCase("true")) {
			setOtherDetails(scenarioName);
		}

		agClick(UsersPageObjects.saveButton);
		CommonOperations.setAuditInfo("Create_User");
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created for verifying User Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyUser(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		searchUser(scenarioName);
		editUser();
		verifyUserDetails(scenarioName);
		verifyPortalSettingsDetails(scenarioName);
		// verifyCompanyUnitsProcessingUnitsDetails(scenarioName);
		// verifyDistributionUnitsContactsIdDetails(scenarioName);
		// verifyRolesDetails(scenarioName);
		// verifyGroupDetails(scenarioName);
		if (getTestDataCellValue(scenarioName, "boolOtherDetails").equalsIgnoreCase("true")) {
			verifyOtherDetails(scenarioName);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created for updating User Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateUser(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		searchUser(scenarioName);
		editUser();
		setUserDetails(scenarioName);
		setPortalSettingsDetails(scenarioName);
		setCompanyUnitsProcessingUnitsDetails(scenarioName);
		if (agIsVisible(UsersPageObjects.allUnitsContactsID_DropDown) == true) {
			setDistributionUnitsContactsIdDetails(scenarioName);
		} else {
			setSubmittingUnitsDetails(scenarioName);
		}
		setRolesDetails(scenarioName);
		setGroupDetails(scenarioName);
		if (getTestDataCellValue(scenarioName, "boolOtherDetails").equalsIgnoreCase("true")) {
			setOtherDetails(scenarioName);
		}
		// saveUser(scenarioName);

		agClick(UsersPageObjects.saveButton);
		CommonOperations.setAuditInfo("Create_User");
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete User.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 11-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndDeleteUser(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		boolean searchResults = searchUser(scenarioName);
		if (searchResults) {
			agClick(CommonPageObjects.selectListingCheckbox(getTestDataCellValue(scenarioName, "SearchText")));
			agClick(UsersPageObjects.deleteButton);
			CommonOperations.setDeleteAuditInfo("LSMV_Delete_User");
		}
		boolean deleteSearchResults = searchUser(scenarioName);
		if (deleteSearchResults) {
			Reports.ExtentReportLog("", Status.FAIL,
					"User : " + getTestDataCellValue(scenarioName, "SearchText") + " is not deleted", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS,
					"User : " + getTestDataCellValue(scenarioName, "SearchText") + " is deleted", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to enter Password Settings Details.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 17-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setPasswordSettingsDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(UsersPageObjects.password_TextBox, getTestDataCellValue(scenarioName, "TemporaryPassword"));
		agSetValue(UsersPageObjects.confirmPassword_TextBox, getTestDataCellValue(scenarioName, "TemporaryPassword"));

		agJavaScriptExecuctorScrollToElement(UsersPageObjects.passwordSettings_div);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO,
				"Data Entered in User >> General >> Password Settings Section : Scenario Name::" + scenarioName, true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to reset Password Details for User.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 17-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void resetPassword(String scenarioName) {
		searchUser(scenarioName);
		editUser();
		setPasswordSettingsDetails(scenarioName);

		agClick(UsersPageObjects.saveButton);
		CommonOperations.setAuditInfo("Create_User");
	}

	/**********************************************************************************************************
	 * @Objective: This method is created get data from excel sheet
	 * @InputParameters: scenarioName
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 19-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
}
