package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.CaseManagementPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FAQPageObjects;
import com.arisglobal.framework.lib.main.ToolManager;

public class FAQOperations extends ToolManager{

	/**********************************************************************************************************
	 * @Objective: Navigate to sub menu
	 * @InputParameters: Menu Name
	 * @OutputParameters:
	 * @author:DushyanthMahesh
	 * @Date : 09-Mar-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	 public static void FAQ_SubMenuNavigation(String object) {
		agMouseHover(FAQPageObjects.FAQ);
		agClick(object);
	}
	
}
