package com.arisglobal.framework.components.lsmv.L10_3;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AppParameters_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.AppParameters_SubmissionPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.WorkFlowPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AppParameters_Submission extends ToolManager {
	static String className = AppParameters_Submission.class.getSimpleName();

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Advanced Search Field Details
	 *             in Submission Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 16-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setAdvancedSearchFieldDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (getTestDataCellValue(scenarioName, "allAdvancedSearchField").equalsIgnoreCase("true")) {
				agClick((AppParameters_SubmissionPageObjects.advancedSearchField_Button).replace("%option%",
						"Add All"));
			} else {
				String fieldName = getTestDataCellValue(scenarioName, "AdvancedSearchField");
				String[] totalRecords = fieldName.split(",");
				for (int i = 0; i < totalRecords.length; i++) {
					agClick((AppParameters_SubmissionPageObjects.advancedSearchField_List).replace("%value%",
							totalRecords[i]));
					agClick((AppParameters_SubmissionPageObjects.advancedSearchField_Button).replace("%option%",
							"Add"));
				}
			}

			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Submission >> Advanced Search Field Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Out-Of-Workflow Advance Search
	 *             Fields Details in Submission Tab under Application Parameters
	 *             Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 16-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setOutOfWorkflowAdvanceSearchFieldsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (getTestDataCellValue(scenarioName, "allOutOfWorkflowAdvanceSearchFields").equalsIgnoreCase("true")) {
				agClick((AppParameters_SubmissionPageObjects.outOfWorkflowAdvanceSearchFields_Button)
						.replace("%option%", "Add All"));
			} else {
				String fieldName = getTestDataCellValue(scenarioName, "OutOfWorkflowAdvanceSearchFields");
				String[] totalRecords = fieldName.split(",");
				for (int i = 0; i < totalRecords.length; i++) {
					agClick((AppParameters_SubmissionPageObjects.outOfWorkflowAdvanceSearchFields_List)
							.replace("%value%", totalRecords[i]));
					agClick((AppParameters_SubmissionPageObjects.outOfWorkflowAdvanceSearchFields_Button)
							.replace("%option%", "Add"));
				}
			}

			agJavaScriptExecuctorScrollToElement(
					AppParameters_SubmissionPageObjects.outOfWorkflowAdvanceSearchFields_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Submission >> Out-Of-Workflow Advance Search Fields Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Submission Reports Search
	 *             Fields Details in Submission Tab under Application Parameters
	 *             Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 16-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setSubmissionReportsSearchFieldsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (getTestDataCellValue(scenarioName, "allSubmissionReportsSearchFields").equalsIgnoreCase("true")) {
				agClick((AppParameters_SubmissionPageObjects.submissionReportsSearchFields_Button).replace("%option%",
						"Add All"));
			} else {
				String fieldName = getTestDataCellValue(scenarioName, "SubmissionReportsSearchFields");
				String[] totalRecords = fieldName.split(",");
				for (int i = 0; i < totalRecords.length; i++) {
					agClick((AppParameters_SubmissionPageObjects.submissionReportsSearchFields_List).replace("%value%",
							totalRecords[i]));
					agClick((AppParameters_SubmissionPageObjects.submissionReportsSearchFields_Button)
							.replace("%option%", "Add"));
				}
			}

			agJavaScriptExecuctorScrollToElement(
					AppParameters_SubmissionPageObjects.submissionReportsSearchFields_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Submission >> Submission Reports Search Fields Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Informed Authority Fields
	 *             Details in Submission Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 16-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setInformedAuthorityFieldsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			CommonOperations.clickCheckBoxLeftOf(AppParameters_SubmissionPageObjects.editDecisionDate_CheckBox,
					getTestDataCellValue(scenarioName, "EditDecisionDate"));
			CommonOperations.clickCheckBoxLeftOf(
					AppParameters_SubmissionPageObjects.editDateInformedToDistributor_CheckBox,
					getTestDataCellValue(scenarioName, "EditDateInformedToDistributor"));
			CommonOperations.clickCheckBoxLeftOf(AppParameters_SubmissionPageObjects.editDateofReport_CheckBox,
					getTestDataCellValue(scenarioName, "EditDateofReport"));
			CommonOperations.clickCheckBoxLeftOf(AppParameters_SubmissionPageObjects.editRespondDate_CheckBox,
					getTestDataCellValue(scenarioName, "EditRespondDate"));
			CommonOperations.clickCheckBoxLeftOf(AppParameters_SubmissionPageObjects.editReportMedium_CheckBox,
					getTestDataCellValue(scenarioName, "EditReportMedium"));
			CommonOperations.clickCheckBoxLeftOf(AppParameters_SubmissionPageObjects.editReportType_CheckBox,
					getTestDataCellValue(scenarioName, "EditReportType"));

			agJavaScriptExecuctorScrollToElement(AppParameters_SubmissionPageObjects.informedAuthorityFields_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Submission >> Informed Authority Fields Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Submission Out-Of-Workflow
	 *             Details in Submission Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 16-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setSubmissionOutOfWorkflowDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			CommonOperations.clickCheckBoxLeftOf(
					AppParameters_SubmissionPageObjects.outOfWorkflowFailedSubmissions_CheckBox,
					getTestDataCellValue(scenarioName, "OutOfWorkflowFailedSubmissions"));
			agSetValue(AppParameters_SubmissionPageObjects.outOfWorkflowSubmissionsOlderThan_TextBox,
					getTestDataCellValue(scenarioName, "OutOfWorkflowSubmissionsOlderThan"));

			agClick(AppParameters_SubmissionPageObjects.outOfWorkflowSubmissionsOlderThanUnit_DropDown);
			agClick(CommonPageObjects.selectListDropDown(
					AppParameters_SubmissionPageObjects.outOfWorkflowSubmissionsOlderThanUnit_DropDownValue,
					getTestDataCellValue(scenarioName, "OutOfWorkflowSubmissionsOlderThanUnit")));
			// CommonOperations.setListDropDownValue(
			// AppParameters_SubmissionPageObjects.outOfWorkflowSubmissionsOlderThanUnit_DropDown,
			// getTestDataCellValue(scenarioName, "OutOfWorkflowSubmissionsOlderThanUnit"));
			CommonOperations.setListDropDownValue(
					AppParameters_SubmissionPageObjects.yearRangeToDisplayOutOfWorkflowData_DropDown,
					getTestDataCellValue(scenarioName, "YearRangeToDisplayOutOfWorkflowData"));
			agSetValue(AppParameters_SubmissionPageObjects.maximumPackageSizeKB_TextBox,
					getTestDataCellValue(scenarioName, "MaximumPackageSizeKB"));
			
			if(getTestDataCellValue(scenarioName, "AppParameters_SubmissionPageObjects").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_SubmissionPageObjects.convertSubmissionSupportDocumentintoPDF_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_SubmissionPageObjects.convertSubmissionSupportDocumentintoPDF_CheckBox,
								getTestDataCellValue(scenarioName, "ConvertSubmissionSupportDocumentintoPDF"));
				}
					}
			
			CommonOperations.setListDropDownValue(AppParameters_SubmissionPageObjects.submittingUnitAccess_DropDown,
					getTestDataCellValue(scenarioName, "SubmittingUnitAccess"));
			agSetValue(AppParameters_SubmissionPageObjects.maximumNumberOfCasesForAssigning_TextBox,
					getTestDataCellValue(scenarioName, "MaximumNumberOfCasesForAssigning"));
			agSetValue(AppParameters_SubmissionPageObjects.temporaryFilePathforEmailScheduler_TextBox,
					getTestDataCellValue(scenarioName, "TemporaryFilePathforEmailScheduler"));
			agSetValue(AppParameters_SubmissionPageObjects.retryCountForFailureEmailSubmission_TextBox,
					getTestDataCellValue(scenarioName, "RetryCountForFailureEmailSubmission"));
			
			if(getTestDataCellValue(scenarioName, "AllowLabelingOnlyForSuspectProducts").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_SubmissionPageObjects.allowLabelingOnlyForSuspectProducts_CheckBox))==true)
					{
					
					}else{
						CommonOperations.clickCheckBoxLeftOf(AppParameters_SubmissionPageObjects.allowLabelingOnlyForSuspectProducts_CheckBox,
								getTestDataCellValue(scenarioName, "AllowLabelingOnlyForSuspectProducts"));
				}
					}
			
			
			
			agSetValue(AppParameters_SubmissionPageObjects.sendAlertEmailifMDNnotReceivedBy_TextBox,
					getTestDataCellValue(scenarioName, "SendAlertEmailifMDNnotReceivedBy"));
			agSelectByValue(AppParameters_SubmissionPageObjects.sendAlertEmailifMDNnotReceivedByUnit_DropDown,
					getTestDataCellValue(scenarioName, "SendAlertEmailifMDNnotReceivedByUnit"));
			if (!getTestDataCellValue(scenarioName, "SendAlertEmailforAcknowledgementNotReceivedbydays")
					.equalsIgnoreCase("#skip#")) {
				agClick((AppParameters_SubmissionPageObjects.sendAlertEmailforAcknowledgementNotReceivedbydays_List)
						.replace("%value%", getTestDataCellValue(scenarioName,
								"SendAlertEmailforAcknowledgementNotReceivedbydays")));
			}
			if (!getTestDataCellValue(scenarioName, "SendAlertEmailforCaseApproachingDueDateforSubmissioninNextdays")
					.equalsIgnoreCase("#skip#")) {
				agClick((AppParameters_SubmissionPageObjects.sendAlertEmailforCaseApproachingDueDateforSubmissioninNextdays_List)
						.replace("%value%", getTestDataCellValue(scenarioName,
								"SendAlertEmailforCaseApproachingDueDateforSubmissioninNextdays")));
			}

			agJavaScriptExecuctorScrollToElement(AppParameters_SubmissionPageObjects.submissionOutOfWorkflow_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Submission >> Submission Out-Of-Workflow Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Advanced Search Field Details
	 *             in Submission Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar s
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadAdvancedSearchFieldDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (agIsVisible(AppParameters_SubmissionPageObjects.advancedSearchFieldSelected_List) == true) {

				List<WebElement> Value = agGetElementList(
						AppParameters_SubmissionPageObjects.advancedSearchFieldSelected_List);
				String delim = ",";
				StringBuilder sb = new StringBuilder();
				int i = 0;
				for (i = 0; i < Value.size(); i++) {
					sb.append(Value.get(i).getText());
					sb.append(delim);
				}

				String res = sb.toString();
				res = sb.deleteCharAt(sb.length() - 1).toString();
				System.out.println(res);

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "AdvancedSearchField",
						res);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"allAdvancedSearchField", "#skip#");
			}
			Reports.ExtentReportLog("", Status.INFO,
					"Read Entered Data in Application Parameters >> Submission >> Advanced Search Field Section", true);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Out-Of-Workflow Advance
	 *             Search Fields Details in Submission Tab under Application
	 *             Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadOutOfWorkflowAdvanceSearchFieldsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (agIsVisible(
					AppParameters_SubmissionPageObjects.outOfWorkflowAdvanceSearchFieldsSelected_List) == true) {

				List<WebElement> Value = agGetElementList(
						AppParameters_SubmissionPageObjects.outOfWorkflowAdvanceSearchFieldsSelected_List);
				String delim = ",";
				StringBuilder sb = new StringBuilder();
				int i = 0;
				for (i = 0; i < Value.size(); i++) {
					sb.append(Value.get(i).getText());
					sb.append(delim);
				}

				String res = sb.toString();
				res = sb.deleteCharAt(sb.length() - 1).toString();
				System.out.println(res);

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"OutOfWorkflowAdvanceSearchFields", res);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"allOutOfWorkflowAdvanceSearchFields", "#skip#");
			}
			agJavaScriptExecuctorScrollToElement(
					AppParameters_SubmissionPageObjects.outOfWorkflowAdvanceSearchFields_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data Entered in Application Parameters >> Submission >> Out-Of-Workflow Advance Search Fields Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Submission Reports Search
	 *             Fields Details in Submission Tab under Application Parameters
	 *             Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadSubmissionReportsSearchFieldsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (agIsVisible(AppParameters_SubmissionPageObjects.submissionReportsSearchFieldsSelected_List) == true) {

				List<WebElement> Value = agGetElementList(
						AppParameters_SubmissionPageObjects.submissionReportsSearchFieldsSelected_List);
				String delim = ",";
				StringBuilder sb = new StringBuilder();
				int i = 0;
				for (i = 0; i < Value.size(); i++) {
					sb.append(Value.get(i).getText());
					sb.append(delim);
				}

				String res = sb.toString();
				res = sb.deleteCharAt(sb.length() - 1).toString();
				System.out.println(res);

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"SubmissionReportsSearchFields", res);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"allSubmissionReportsSearchFields", "#skip#");
			}

			agJavaScriptExecuctorScrollToElement(
					AppParameters_SubmissionPageObjects.submissionReportsSearchFields_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Read Data Entered in Application Parameters >> Submission >> Submission Reports Search Fields Section",
					true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Informed Authority Fields
	 *             Details in Submission Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 16-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadInformedAuthorityFieldsDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_SubmissionPageObjects.editDecisionDate_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EditDecisionDate",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EditDecisionDate",
						"false");
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_SubmissionPageObjects.editDateofReport_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EditDateofReport",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EditDateofReport",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_SubmissionPageObjects.editDateInformedToDistributor_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EditDateInformedToDistributor", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"EditDateInformedToDistributor", "false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_SubmissionPageObjects.editRespondDate_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EditRespondDate",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EditRespondDate",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_SubmissionPageObjects.editReportMedium_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EditReportMedium",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EditReportMedium",
						"false");
			}
			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_SubmissionPageObjects.editReportType_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EditReportType",
						"true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EditReportType",
						"false");
			}

			agJavaScriptExecuctorScrollToElement(AppParameters_SubmissionPageObjects.informedAuthorityFields_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Submission >> Informed Authority Fields Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Submission Out-Of-Workflow
	 *             Details in Submission Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadSubmissionOutOfWorkflowDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_SubmissionPageObjects.outOfWorkflowFailedSubmissions_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"OutOfWorkflowFailedSubmissions", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"OutOfWorkflowFailedSubmissions", "false");
			}
			agClick(AppParameters_SubmissionPageObjects.outOfWorkflowSubmissionsOlderThan_TextBox);
			String OutOfWorkflowSubmissionsOlderThan = agGetAttribute("value",
					AppParameters_SubmissionPageObjects.outOfWorkflowSubmissionsOlderThan_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"OutOfWorkflowSubmissionsOlderThan", OutOfWorkflowSubmissionsOlderThan);

			String OutOfWorkflowSubmissionsOlderThanUnit = agGetText(
					AppParameters_SubmissionPageObjects.outOfWorkflowSubmissionsOlderThanUnit_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"OutOfWorkflowSubmissionsOlderThanUnit", OutOfWorkflowSubmissionsOlderThanUnit);

			String YearRangeToDisplayOutOfWorkflowData = agGetText(
					AppParameters_SubmissionPageObjects.yearRangeToDisplayOutOfWorkflowData_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"YearRangeToDisplayOutOfWorkflowData", YearRangeToDisplayOutOfWorkflowData);

			agClick(AppParameters_SubmissionPageObjects.maximumPackageSizeKB_TextBox);
			String MaximumPackageSizeKB = agGetAttribute("value",
					AppParameters_SubmissionPageObjects.maximumPackageSizeKB_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "MaximumPackageSizeKB",
					MaximumPackageSizeKB);

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_SubmissionPageObjects.convertSubmissionSupportDocumentintoPDF_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ConvertSubmissionSupportDocumentintoPDF", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ConvertSubmissionSupportDocumentintoPDF", "No");
			}
			String SubmittingUnitAccess = agGetText(AppParameters_SubmissionPageObjects.submittingUnitAccess_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "SubmittingUnitAccess",
					SubmittingUnitAccess);

			agClick(AppParameters_SubmissionPageObjects.maximumNumberOfCasesForAssigning_TextBox);
			String MaximumNumberOfCasesForAssigning = agGetAttribute("value",
					AppParameters_SubmissionPageObjects.maximumNumberOfCasesForAssigning_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"MaximumNumberOfCasesForAssigning", MaximumNumberOfCasesForAssigning);

			agClick(AppParameters_SubmissionPageObjects.temporaryFilePathforEmailScheduler_TextBox);
			String TemporaryFilePathforEmailScheduler = agGetAttribute("value",
					AppParameters_SubmissionPageObjects.temporaryFilePathforEmailScheduler_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"TemporaryFilePathforEmailScheduler", TemporaryFilePathforEmailScheduler);

			agClick(AppParameters_SubmissionPageObjects.retryCountForFailureEmailSubmission_TextBox);
			String RetryCountForFailureEmailSubmission = agGetAttribute("value",
					AppParameters_SubmissionPageObjects.retryCountForFailureEmailSubmission_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"RetryCountForFailureEmailSubmission", RetryCountForFailureEmailSubmission);

			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_SubmissionPageObjects.allowLabelingOnlyForSuspectProducts_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowLabelingOnlyForSuspectProducts", "Yes");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"AllowLabelingOnlyForSuspectProducts", "No");
			}

			agClick(AppParameters_SubmissionPageObjects.sendAlertEmailifMDNnotReceivedBy_TextBox);
			String SendAlertEmailifMDNnotReceivedBy = agGetAttribute("value",
					AppParameters_SubmissionPageObjects.sendAlertEmailifMDNnotReceivedBy_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"SendAlertEmailifMDNnotReceivedBy", SendAlertEmailifMDNnotReceivedBy);

			String SendAlertEmailifMDNnotReceivedByUnit = agGetText(
					AppParameters_SubmissionPageObjects.sendAlertEmailifMDNnotReceivedByUnit_DropDown);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
					"SendAlertEmailifMDNnotReceivedByUnit", SendAlertEmailifMDNnotReceivedByUnit);

			agJavaScriptExecuctorScrollToElement(AppParameters_SubmissionPageObjects.submissionOutOfWorkflow_Label);
			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Submission >> Submission Out-Of-Workflow Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set data in Submission Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 17-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setAppParameters_SubmissionTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >>Submission Tab Started",
				true);
		setAdvancedSearchFieldDetails(scenarioName);
		setOutOfWorkflowAdvanceSearchFieldsDetails(scenarioName);
		setSubmissionReportsSearchFieldsDetails(scenarioName);
		setInformedAuthorityFieldsDetails(scenarioName);
		setSubmissionOutOfWorkflowDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >>Submission Tab Completed",
				true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read data in Submission Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar s
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadAppParameters_SubmissionTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Read Data Entered in Application Parameters >>Submission Tab Started",
				true);
		ReadAdvancedSearchFieldDetails(scenarioName);
		ReadOutOfWorkflowAdvanceSearchFieldsDetails(scenarioName);
		ReadSubmissionReportsSearchFieldsDetails(scenarioName);
		ReadInformedAuthorityFieldsDetails(scenarioName);
		ReadSubmissionOutOfWorkflowDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO,
				"Read Data Entered in Application Parameters >>Submission Tab Completed", true);
	}
}
