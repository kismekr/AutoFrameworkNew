package com.arisglobal.framework.components.lsmv.L10_3;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AppParameters_CallLogPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.AppParameters_ComplaintPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.AppParameters_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.WorkFlowPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class AppParameters_CallLog extends ToolManager {
	static String className = AppParameters_CallLog.class.getSimpleName();

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Call Log Details in Call Log
	 *             Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 16-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setCallLogDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetValue(AppParameters_CallLogPageObjects.callLogNumberingFormat_TextBox,
					getTestDataCellValue(scenarioName, "CallLogNumberingFormat"));
			CommonOperations.setListDropDownValue(AppParameters_CallLogPageObjects.callLogNumberingFormat1_DropDown,
					getTestDataCellValue(scenarioName, "CallLogNumberingFormat1"));
			CommonOperations.setListDropDownValue(AppParameters_CallLogPageObjects.callLogNumberingFormat2_DropDown,
					getTestDataCellValue(scenarioName, "CallLogNumberingFormat2"));
			CommonOperations.setListDropDownValue(AppParameters_CallLogPageObjects.resetSequenceBy_DropDown,
					getTestDataCellValue(scenarioName, "ResetSequenceBy"));
			
			if(getTestDataCellValue(scenarioName, "DisplaySupportDocument").equalsIgnoreCase("true")) {
			if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CallLogPageObjects.displaySupportDocument_CheckBox))==true)
				{
				
				}else{
				CommonOperations.clickCheckBoxLeftOf(AppParameters_CallLogPageObjects.displaySupportDocument_CheckBox,
						getTestDataCellValue(scenarioName, "DisplaySupportDocument"));
			}
				}	
			
			
			if(getTestDataCellValue(scenarioName, "ConsiderProtectConfidentialitySummarySheet").equalsIgnoreCase("true")) {
			if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CallLogPageObjects.considerProtectConfidentialitySummarySheet_CheckBox))==true)
				{
				
				}else{
				CommonOperations.clickCheckBoxLeftOf(AppParameters_CallLogPageObjects.considerProtectConfidentialitySummarySheet_CheckBox,
						getTestDataCellValue(scenarioName, "ConsiderProtectConfidentialitySummarySheett"));
			}
				}
			if(getTestDataCellValue(scenarioName, "ReAuthenticationforCallLogSubmission").equalsIgnoreCase("true")) {
				if(agIsVisible( CommonPageObjects.checkBoxChecked(AppParameters_CallLogPageObjects.reAuthenticationforCallLogSubmission_CheckBox))==true)
					{
					
					}else{
					CommonOperations.clickCheckBoxLeftOf(AppParameters_CallLogPageObjects.reAuthenticationforCallLogSubmission_CheckBox,
							getTestDataCellValue(scenarioName, "ReAuthenticationforCallLogSubmission"));
				}
					}
		

			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Call Log >> Call Log Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set Dispatcher Details in Call Log
	 *             Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 16-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setDispatcherDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agClick(AppParameters_CallLogPageObjects.EnableAutoSaveRadioBtn);
			agSetValue(AppParameters_CallLogPageObjects.dispatcherAutoSaveTime_TextBox,
					getTestDataCellValue(scenarioName, "DispatcherAutoSaveTime"));

			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Call Log >> Dispatcher Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Call Log Details in Call Log
	 *             Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadCallLogDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			agClick(AppParameters_CallLogPageObjects.callLogNumberingFormat_TextBox);
			String CallLogNumberingFormat = agGetAttribute("value",
					AppParameters_CallLogPageObjects.callLogNumberingFormat_TextBox);
			XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "CallLogNumberingFormat",
					CallLogNumberingFormat);
			String CallLogNumberingFormat1 = agGetText(
					AppParameters_CallLogPageObjects.callLogNumberingFormat1_DropDown);
			if (CallLogNumberingFormat1.equalsIgnoreCase("--Select--")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"CallLogNumberingFormat1", "#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"CallLogNumberingFormat1", CallLogNumberingFormat1);
			}

			String CallLogNumberingFormat2 = agGetText(
					AppParameters_CallLogPageObjects.callLogNumberingFormat2_DropDown);
			if (CallLogNumberingFormat2.equalsIgnoreCase("--Select--")) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"CallLogNumberingFormat2", "#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"CallLogNumberingFormat2", CallLogNumberingFormat2);
			}
			String ResetSequenceBy = agGetText(AppParameters_CallLogPageObjects.resetSequenceBy_DropDown);
			if (ResetSequenceBy.equalsIgnoreCase("--Select--")) {

				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"CallLogNumberingFormat2", "#skip#");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"CallLogNumberingFormat2", ResetSequenceBy);
			}

			if (agIsVisible(WorkFlowPageObjects
					.CheckedCheckBox(AppParameters_CallLogPageObjects.displaySupportDocument_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DisplaySupportDocument", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DisplaySupportDocument", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CallLogPageObjects.considerProtectConfidentialitySummarySheet_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ConsiderProtectConfidentialitySummarySheet", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ConsiderProtectConfidentialitySummarySheet", "false");
			}
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(
					AppParameters_CallLogPageObjects.reAuthenticationforCallLogSubmission_CheckBox)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ReAuthenticationforCallLogSubmission", "true");
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"ReAuthenticationforCallLogSubmission", "false");
			}

			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Call Log >> Call Log Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read Dispatcher Details in Call
	 *             Log Tab under Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:WajahatUmar s
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadDispatcherDetails(String scenarioName) {
		try {
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			if (agIsVisible(WorkFlowPageObjects.CheckedCheckBox(AppParameters_ComplaintPageObjects.Yes)) == true) {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableAutoSave",
						"Yes");
				agClick(AppParameters_CallLogPageObjects.dispatcherAutoSaveTime_TextBox);
				String DispatcherAutoSaveTime = agGetAttribute("value",
						AppParameters_CallLogPageObjects.dispatcherAutoSaveTime_TextBox);
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName,
						"DispatcherAutoSaveTime", DispatcherAutoSaveTime);
			} else {
				XlsReader.writeToTestData(lsmvConstants.LSMV_testData, className, scenarioName, "EnableAutoSave", "No");
			}

			Reports.ExtentReportLog("", Status.INFO,
					"Data Entered in Application Parameters >> Call Log >> Dispatcher Section", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to set data in Call Log Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: Sanchit
	 * @Date : 17-April-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void setAppParameters_CallLogTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >> Call Log Tab Started",
				true);
		setCallLogDetails(scenarioName);
		setDispatcherDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO, "Data Entered in Application Parameters >> Call Log Tab Completed",
				true);
	}

	/***********************************************************************************************************************
	 * @Objective: The below method is created to Read data in Call Log Tab under
	 *             Application Parameters Section.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author: WajahatUmar S
	 * @Date : 24-Nov-2020
	 * @UpdatedByAndWhen:
	 ************************************************************************************************************************/
	public static void ReadAppParameters_CallLogTabDetails(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Read Data Entered in Application Parameters >> Call Log Tab Started",
				true);
		ReadCallLogDetails(scenarioName);
		ReadDispatcherDetails(scenarioName);
		Reports.ExtentReportLog("", Status.INFO,
				"Read Data Entered in Application Parameters >> Call Log Tab Completed", true);
	}

}
