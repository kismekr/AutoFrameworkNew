package com.arisglobal.framework.components.lsmv.L10_3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_EventsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FullDataEntryFormPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.Lib_AlwaysSeriousEvent_PageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.LibrariesPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.ReportsPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Libraries_AlwaysSeriousEvent extends ToolManager {
	static String className = Libraries_AlwaysSeriousEvent.class.getSimpleName();

	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit and verify Always Serious
	 *             Event.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :27-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyAlwaysSeriousEvent(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(Lib_AlwaysSeriousEvent_PageObjects.edit_Icon);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "PTTerm"),
				Lib_AlwaysSeriousEvent_PageObjects.get_AlwaysSeriousEventMedDRAPTTerm);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "MedDRAPTCode"),
				Lib_AlwaysSeriousEvent_PageObjects.get_MedDRAPTCode);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "SOCName"),
				Lib_AlwaysSeriousEvent_PageObjects.get_SOCName);
		CommonOperations.verifyCheckBoxUnder(Lib_AlwaysSeriousEvent_PageObjects.active_checkbox,
				getTestDataCellValue(scenarioName, "Active"));
		CommonOperations.takeScreenShot();
		agClick(Lib_AlwaysSeriousEvent_PageObjects.cancelButton);
		agSetStepExecutionDelay("3000");
		agIsVisible(Lib_AlwaysSeriousEvent_PageObjects.paginator);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Always Serious Event.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 27-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void search(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(Lib_AlwaysSeriousEvent_PageObjects.eventVersion(getTestDataCellValue(scenarioName, "Version")));
		agSetStepExecutionDelay("2000");
		agSetValue(Lib_AlwaysSeriousEvent_PageObjects.keywordSearch_Textbox,
				getTestDataCellValue(scenarioName, "PTTerm"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(Lib_AlwaysSeriousEvent_PageObjects.search_Icon);
		agSetStepExecutionDelay("3000");
		agIsVisible(Lib_AlwaysSeriousEvent_PageObjects.paginator);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Search is successful", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Always Serious Event.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :27-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreateAlwaysSeriousEvent(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		if (verifysearchData(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Always Serious Event already exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "PTTerm"),
					Lib_AlwaysSeriousEvent_PageObjects.get_PtTerm);
		} else {
			agClick(Lib_AlwaysSeriousEvent_PageObjects.new_Btn);
			createAlwaysSeriousEvent(scenarioName);
			search(scenarioName);
			VerifyAlwaysSeriousEvent(scenarioName);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Always Serious Event Pt
	 *             term in listing screen
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :27-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Boolean verifysearchData(String scenarioName) {
		Boolean falg = false;
		String paginator = agGetText(Lib_AlwaysSeriousEvent_PageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			List<WebElement> list = agGetElementList(Lib_AlwaysSeriousEvent_PageObjects.get_ListofAlwaysSeriousEvent);
			String columnHeader = null;
			for (int j = 1; j <= list.size(); j++) {
				columnHeader = agGetText(Lib_AlwaysSeriousEvent_PageObjects.columnHeaderList(Integer.toString(j)));
				if (getTestDataCellValue(scenarioName, "PTTerm").equalsIgnoreCase(columnHeader)) {
					falg = true;
					break;
				}
			}
		}
		System.out.println(falg);
		return falg;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create Always Serious Event.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :27-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createAlwaysSeriousEvent(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agAssertVisible(Lib_AlwaysSeriousEvent_PageObjects.alwaysSeriousEvent_Lable);
		agClick(Lib_AlwaysSeriousEvent_PageObjects.alwaysSeriousEventMedDRAPTTerm_lookup);
		agSetValue(Lib_AlwaysSeriousEvent_PageObjects.dictionaryCodingBrowser_SearchTxtfield,
				getTestDataCellValue(scenarioName, "SearchTerm"));
		agClick(Lib_AlwaysSeriousEvent_PageObjects.dictionaryCodingBrowser_SearchBtn);
		agSetStepExecutionDelay("2000");
		agWaitTillVisibilityOfElement(Lib_AlwaysSeriousEvent_PageObjects.dictionaryCodingBrowser_OkBtn);
		agClick(Lib_AlwaysSeriousEvent_PageObjects.dictionaryCodingBrowser_OkBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agJavaScriptExecuctorClick(Lib_AlwaysSeriousEvent_PageObjects.saveButton);
		agWaitTillVisibilityOfElement(CommonPageObjects.validaionOk_Btn);
		agClick(CommonPageObjects.validaionOk_Btn);
		agIsVisible(LibrariesPageObjects.alwaysSeriousKeywordSearch);
		Reports.ExtentReportLog("", Status.INFO, "Always Serious Event Listing screen is displayed", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add medra version tab in listing
	 *             screen.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :27-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addMedraVersion(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		CommonOperations.setListDropDownValue(Lib_AlwaysSeriousEvent_PageObjects.AddSeriousEventVer_Dropdown,
				getTestDataCellValue(scenarioName, "AlwaysSeriousEventVersion"));
		agClick(Lib_AlwaysSeriousEvent_PageObjects.addversion_Btn);
		agSetStepExecutionDelay("3000");
		if (agIsVisible(Lib_AlwaysSeriousEvent_PageObjects.validationPopup_Btn) == true)
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		{
			agClick(Lib_AlwaysSeriousEvent_PageObjects.validationOK_Btn);
		}
		if (agIsVisible(Lib_AlwaysSeriousEvent_PageObjects
				.verfiyColumn(getTestDataCellValue(scenarioName, "Version"))) == true) {
			Reports.ExtentReportLog("", Status.PASS,
					"Always Serious Event Version is added::" + getTestDataCellValue(scenarioName, "Version"), true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL,
					"Always Serious Event Version is not added::" + getTestDataCellValue(scenarioName, "Version"),
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Add Import Download Delete Always
	 *             Serious Event.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :04-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void IsAlwaysSeriousEventListandUpdate(String scenarioName, String scenarioName1) {
		try {
			Reports.ExtentReportLog("", Status.INFO, "Add,Import,Download,Delete Always Serious Event Started", true);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

			LibrariesOperations.librariesNavigations("alwaysSeriousEvent");

			searchandDelete(scenarioName);
			// To Create Always Serious Event
			agClick(Lib_AlwaysSeriousEvent_PageObjects.new_Btn);
			createAlwaysSeriousEvent(scenarioName);

			PanelVerification(scenarioName);

			// Delete Always Serious Event
			DeleteAlwaysSeriousEvent(scenarioName);

			// DownLoad Template
			DownLoadandImportTemplate(scenarioName);

			// Verify Always serious event population in case
			agClick(Lib_AlwaysSeriousEvent_PageObjects.new_Btn);
			createAlwaysSeriousEvent(scenarioName);

			// Verify Always Serious Event Population In Case
			VerifyAlwaysSeriouseventpopulationincase(scenarioName);

			// Downgrading Always serious event
			DownGradingAlwaysSeriousEvent();

			LibrariesOperations.librariesNavigations("alwaysSeriousEvent");

			// Delete Always Serious Event
			DeleteAlwaysSeriousEvent(scenarioName);

			// Verify the Audit trail for changes made.
			VerifytheAudittrailforchangesmade(scenarioName, scenarioName1);

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Add,Import,Download,Delete Always Serious Event Fails", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Delete Always Serious Event.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :05-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void DeleteAlwaysSeriousEvent(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		// To Delete Always Serious Event
		agSetStepExecutionDelay("2000");
		agSetValue(Lib_AlwaysSeriousEvent_PageObjects.keywordSearch_Textbox,
				getTestDataCellValue(scenarioName, "PTTerm"));

		agClick(Lib_AlwaysSeriousEvent_PageObjects.search_Icon);
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorClick(Lib_AlwaysSeriousEvent_PageObjects.ASECheckBox);
		agClick(Lib_AlwaysSeriousEvent_PageObjects.DeleteBtn);
		agWaitTillVisibilityOfElement(CommonPageObjects.deletePopupYes_Btn);
		agClick(CommonPageObjects.deletePopupYes_Btn);
		agWaitTillVisibilityOfElement(CommonPageObjects.validaionOk_Btn);
		agClick(CommonPageObjects.validaionOk_Btn);
		agSetStepExecutionDelay("2000");
		agClick(Lib_AlwaysSeriousEvent_PageObjects.RefreshBtn);
		agSetValue(Lib_AlwaysSeriousEvent_PageObjects.keywordSearch_Textbox,
				getTestDataCellValue(scenarioName, "PTTerm"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(Lib_AlwaysSeriousEvent_PageObjects.search_Icon);
		agSetStepExecutionDelay("2000");
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		if (agIsVisible(Lib_AlwaysSeriousEvent_PageObjects.NoRecordFound) == true) {
			Reports.ExtentReportLog("", Status.INFO, "Always Serious Event Deleted Successfully", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Always Serious Event not Deleted", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Filter,Downloadicon in
	 *             Always Serious Event.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :05-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void PanelVerification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");

		agSetValue(Lib_AlwaysSeriousEvent_PageObjects.keywordSearch_Textbox,
				getTestDataCellValue(scenarioName, "PTTerm"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(Lib_AlwaysSeriousEvent_PageObjects.search_Icon);
		agSetStepExecutionDelay("2000");
		agJavaScriptExecuctorClick(Lib_AlwaysSeriousEvent_PageObjects.ASECheckBox);
		agSetStepExecutionDelay("2000");

		agMouseHover(Lib_AlwaysSeriousEvent_PageObjects.DownloadIcon);
		agSetStepExecutionDelay("2000");
		agClick(Lib_AlwaysSeriousEvent_PageObjects.ExportSelectedRecords);

		agGetCurrentWindow();
		agCloseCurrentWindow();
		agGetWindowControlByInstance(1);
		agGetCurrentWindow();
		agSetStepExecutionDelay("2000");

		agJavaScriptExecuctorClick(Lib_AlwaysSeriousEvent_PageObjects.ASECheckBox);
		agMouseHover(Lib_AlwaysSeriousEvent_PageObjects.DownloadIcon);
		agSetStepExecutionDelay("2000");
		agClick(Lib_AlwaysSeriousEvent_PageObjects.ExportAllRecords);

		agGetCurrentWindow();
		agCloseCurrentWindow();
		agGetWindowControlByInstance(1);
		agGetCurrentWindow();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

		// Filter
		agClick(Lib_AlwaysSeriousEvent_PageObjects.RefreshBtn);
		agSetStepExecutionDelay("2000");
		agClick(Lib_AlwaysSeriousEvent_PageObjects.FilterIcon);
		agSetValue(Lib_AlwaysSeriousEvent_PageObjects.PTTermTextBox, getTestDataCellValue(scenarioName, "PTTerm"));

		if (agIsVisible(Lib_AlwaysSeriousEvent_PageObjects.PTTermVerify) == true) {
			Reports.ExtentReportLog("", Status.INFO, "Always Serious Event PT TERM Verified", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify Filter,Downloadicon in
	 *             Always Serious Event.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :05-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void DownLoadandImportTemplate(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);

		// DownLoad Template
		agClick(Lib_AlwaysSeriousEvent_PageObjects.DownLoadTemplate);
		agSetStepExecutionDelay("3000");
		agGetCurrentWindow();
		agCloseCurrentWindow();
		agGetWindowControlByInstance(1);
		agGetCurrentWindow();
		Reports.ExtentReportLog("", Status.INFO, "Always Serious Event Template Downloaded Successfully", true);

		searchandDelete("TemplateData_AlwaysSeriousEvent");

		// import Template
		agSetStepExecutionDelay("5000");
		Actions builder = new Actions(driver);
		builder.moveToElement(driver.findElement(By.xpath(
				"//div[@id='alwaysListingId:excelfileimportId']//span[@class='ui-button ui-widget ui-state-default ui-corner-all ui-button-text-icon-left ui-fileupload-choose']")))
				.click(driver.findElement(By.xpath(
						"//div[@id='alwaysListingId:excelfileimportId']//span[@class='ui-button ui-widget ui-state-default ui-corner-all ui-button-text-icon-left ui-fileupload-choose']")));
		builder.perform();

		agUploadDocuments(lsmvConstants.lsmvXmlPath + getTestDataCellValue(scenarioName, "FileUpload"));
		agWaitTillVisibilityOfElement(Lib_AlwaysSeriousEvent_PageObjects.validationOK_Btn);
		if (agIsVisible(Lib_AlwaysSeriousEvent_PageObjects.validationOK_Btn) == true) {
			agClick(Lib_AlwaysSeriousEvent_PageObjects.validationOK_Btn);
			Reports.ExtentReportLog("", Status.INFO, "Always Serious Event File/Template Imported Successfully", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify Always serious event
	 *             population in case.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :05-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyAlwaysSeriouseventpopulationincase(String scenarioName) {
		Reports.ExtentReportLog("", Status.INFO, "Verify Always Serious event population in case Started", true);
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_General");
		CaseManagementOperations.caseManagement_MenuNavigations("fullDataEntryForm");
		FDE_General.LSMVSetGeneralBasicDetails(scenarioName);
		FDE_Operations.tabNavigation("Event(s)");
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "FDE_Events");

		agJavaScriptExecuctorClick(FDE_EventsPageObjects.eventInfo_Label);
		agSetValue(FDE_EventsPageObjects.reportedTerm_Textfield,
				getTestDataCellValue(scenarioName, "Events_EventInformation_ReportedTerm"));
		FDE_Events.set_EventMedDRALLTCode(scenarioName);
		agSetStepExecutionDelay("3000");
		FDE_Operations.LSMVSave("CopyCase", "FDE_General");

		if (agIsVisible(Lib_AlwaysSeriousEvent_PageObjects.IsAlwaysSeriousCheckBoxChecked) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Is Always Serious is Checked", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Is Always Serious is not Checked", true);
		}
		if (agIsVisible(Lib_AlwaysSeriousEvent_PageObjects.SeriousnessYes) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Case Seriousness is Selected as Yes", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Case Seriousness is not Selected as Yes", true);

		}

		if (agIsVisible(Lib_AlwaysSeriousEvent_PageObjects.OtherMedicalConditionYes) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Other Medical Condition is Selected as Yes", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Other Medical Condition is not Selected as Yes", true);

		}

		agClick(FDE_EventsPageObjects.OtherMedicallyCondition_Textarea);
		String Value = agGetAttribute("value", FDE_EventsPageObjects.OtherMedicallyCondition_Textarea);
		if (Value.equalsIgnoreCase(Value)) {
			Reports.ExtentReportLog("", Status.PASS, "Other Medically Important Condition Info Entered as 1", true);
		}
		Reports.ExtentReportLog("", Status.INFO, "Verify Always Serious event population in case Ends", true);

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to DownGrade Always serious event
	 *             population in case.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :05-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void DownGradingAlwaysSeriousEvent() {
		Reports.ExtentReportLog("", Status.INFO, "To Downgrade ALways Serious Event!!!", true);
		agClick(Lib_AlwaysSeriousEvent_PageObjects.ManualIsalwaysSeriousChkbox);
		agWaitTillVisibilityOfElement(Lib_AlwaysSeriousEvent_PageObjects.DownGradeConfirmation);
		if (agIsVisible(Lib_AlwaysSeriousEvent_PageObjects.DownGradeConfirmation) == true) {
			Reports.ExtentReportLog("", Status.PASS, "DownGrade Confirmation Pop-Up appears", true);
			agSetValue(Lib_AlwaysSeriousEvent_PageObjects.DownGradeComment, "Downgrade");
			agClick(Lib_AlwaysSeriousEvent_PageObjects.SubmitBtn);
			if (agIsVisible(Lib_AlwaysSeriousEvent_PageObjects.DownGradeImg) == true
					&& agIsVisible(Lib_AlwaysSeriousEvent_PageObjects.IsAlwaysSeriousCheckboxUnchecked) == true) {
				Reports.ExtentReportLog("", Status.INFO, "ALways Serious Event Downgraded", true);
				agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.SaveButton);
				agWaitTillVisibilityOfElement(FullDataEntryFormPageObjects.saveOkButton);
				agJavaScriptExecuctorClick(FullDataEntryFormPageObjects.saveOkButton);

			} else {
				Reports.ExtentReportLog("", Status.FAIL, "ALways Serious Event not Downgraded", true);
			}
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "DownGrade Confirmation Pop-Up not appear", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify the Audit trail for changes
	 *             made.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :06-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifytheAudittrailforchangesmade(String scenarioName, String scenarioName1) {
		try {
			Reports.ExtentReportLog("", Status.INFO, " Verify the Audit trail for changes made Started", true);
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			LibrariesOperations.librariesNavigations("alwaysSeriousEvent");
			searchandDelete(scenarioName1);

			LibrariesOperations.librariesNavigations("alwaysSeriousEvent");
			searchandDelete(scenarioName);

			LibrariesOperations.librariesNavigations("alwaysSeriousEvent");
			agClick(Lib_AlwaysSeriousEvent_PageObjects.new_Btn);
			createAlwaysSeriousEvent(scenarioName);
			AuditTrailVerifcationInsert(scenarioName);

			LibrariesOperations.librariesNavigations("alwaysSeriousEvent");
			search(scenarioName);
			UpdateAlwaysSeriousEvent(scenarioName1);
			AuditTrailVerifcationUpdate(scenarioName, scenarioName1);

			LibrariesOperations.librariesNavigations("alwaysSeriousEvent");
			search(scenarioName1);
			DeleteAlwaysSeriousEvent(scenarioName1);
			AuditTrailVerifcationDelete(scenarioName1);

			Reports.ExtentReportLog("", Status.INFO, " Verify the Audit trail for changes made Ends", true);
		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, " Verify the Audit trail for changes made Fails", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify the Audit trail for changes
	 *             made.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :06-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AuditTrailVerifcationInsert(String scenarioName) {
		try {

			ReportsOperations.reportsNavigations("standard");

			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetStepExecutionDelay("3000");
			CommonOperations.setListDropDownValue(ReportsPageObjects.messageTypeSelect,
					getTestDataCellValue(scenarioName, "MessageType"));

			agSetValue(ReportsPageObjects.auditTrialBetweenFrom,
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "auditTrialBetween")));
			agSetValue(ReportsPageObjects.auditTrialBetweenTo,
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "auditTrialBetween")));

			agClick(ReportsPageObjects.auditTrialGenerateReportButton);
			if (agIsVisible(ReportsPageObjects.Insert) == true) {
				String ActiveValue = agGetText(ReportsPageObjects.InsertOpeartionType(ReportsPageObjects.ACTIVE));
				if (ActiveValue.equalsIgnoreCase("1")) {
					Reports.ExtentReportLog("", Status.PASS, "Active Value in Audit Trail Inserted Successfully", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Active Value in Audit Trail not Inserted Successfully",
							true);
				}
				String ALWAYS_BROAD_NARROW = agGetText(
						ReportsPageObjects.InsertOpeartionType(ReportsPageObjects.ALWAYS_BROAD_NARROW));
				if (ALWAYS_BROAD_NARROW.equalsIgnoreCase("3")) {
					Reports.ExtentReportLog("", Status.PASS,
							"ALWAYS_BROAD_NARROW Value in Audit Trail Inserted Successfully", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL,
							"ALWAYS_BROAD_NARROW Value in Audit Trail not Inserted Successfully", true);
				}
				String MEDDRA_CODE = agGetText(ReportsPageObjects.InsertOpeartionType(ReportsPageObjects.MEDDRA_CODE));
				if (MEDDRA_CODE.equalsIgnoreCase(getTestDataCellValue(scenarioName, "MedDRAPTCode"))) {
					Reports.ExtentReportLog("", Status.PASS, "MEDDRA_CODE Value in Audit Trail Inserted Successfully",
							true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL,
							"MEDDRA_CODE Value in Audit Trail not Inserted Successfully", true);
				}

				String MEDDRA_PT_TERM = agGetText(
						ReportsPageObjects.InsertOpeartionType(ReportsPageObjects.MEDDRA_PT_TERM));
				if (MEDDRA_PT_TERM.equalsIgnoreCase(getTestDataCellValue(scenarioName, "PTTerm"))) {
					Reports.ExtentReportLog("", Status.PASS,
							"MEDDRA_PT_TERM Value in Audit Trail Inserted Successfully", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL,
							"MEDDRA_PT_TERM Value in Audit Trail not Inserted Successfully", true);
				}

				String SOC_NAME = agGetText(ReportsPageObjects.InsertOpeartionType(ReportsPageObjects.SOC_NAME))
						.substring(0, 10);

				if (SOC_NAME.contains(getTestDataCellValue(scenarioName, "SOCName").substring(0, 10))) {
					Reports.ExtentReportLog("", Status.PASS, "SOC_NAME Value in Audit Trail Inserted Successfully",
							true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "SOC_NAME Value in Audit Trail not Inserted Successfully",
							true);
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, " Verify the Audit trail for changes made Fails", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify the Audit trail for changes
	 *             made.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :06-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AuditTrailVerifcationUpdate(String scenarioName, String scenarioName1) {
		try {

			ReportsOperations.reportsNavigations("standard");
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetStepExecutionDelay("3000");
			CommonOperations.setListDropDownValue(ReportsPageObjects.messageTypeSelect,
					getTestDataCellValue(scenarioName, "MessageType"));

			agSetValue(ReportsPageObjects.auditTrialBetweenFrom,
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "auditTrialBetween")));
			agSetValue(ReportsPageObjects.auditTrialBetweenTo,
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "auditTrialBetween")));

			agClick(ReportsPageObjects.auditTrialGenerateReportButton);
			if (agIsVisible(ReportsPageObjects.Update) == true) {
				String Medracode_oldValue = agGetText(
						ReportsPageObjects.UpdateOpeartionTypeOldValue(ReportsPageObjects.MEDDRA_CODE));
				if (Medracode_oldValue.equalsIgnoreCase(getTestDataCellValue(scenarioName, "MedDRAPTCode"))) {
					Reports.ExtentReportLog("", Status.PASS, "Medracode_oldValue  in Audit Trail updated Successfully",
							true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Medracode_oldValue  in Audit Trail updated Successfully",
							true);
				}
				String MEDDRA_PT_TERM = agGetText(
						ReportsPageObjects.UpdateOpeartionTypeOldValue(ReportsPageObjects.MEDDRA_PT_TERM));
				if (MEDDRA_PT_TERM.equalsIgnoreCase(getTestDataCellValue(scenarioName, "PTTerm"))) {
					Reports.ExtentReportLog("", Status.PASS,
							"MEDDRA_PT_TERM_oldValue  in Audit Trail updated Successfully", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL,
							"MEDDRA_PT_TERM_oldValue  in Audit Trail updated Successfully", true);
				}
				String SOC_NAME = agGetText(ReportsPageObjects.UpdateOpeartionTypeOldValue(ReportsPageObjects.SOC_NAME))
						.substring(0, 10);
				if (SOC_NAME.contains(getTestDataCellValue(scenarioName, "SOCName").substring(0, 10))) {
					Reports.ExtentReportLog("", Status.PASS, "SOC_NAME_oldValue  in Audit Trail updated Successfully",
							true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "SOC_NAME_oldValue  in Audit Trail updated Successfully",
							true);
				}

				String Medracode_newValue = agGetText(
						ReportsPageObjects.UpdateOpeartionTypeNewValue(ReportsPageObjects.MEDDRA_CODE));
				if (Medracode_newValue.equalsIgnoreCase(getTestDataCellValue(scenarioName1, "MedDRAPTCode"))) {
					Reports.ExtentReportLog("", Status.PASS, "Medracode_newValue  in Audit Trail updated Successfully",
							true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Medracode_newValue  in Audit Trail updated Successfully",
							true);
				}
				String MEDDRA_PT_TERM_newValue = agGetText(
						ReportsPageObjects.UpdateOpeartionTypeNewValue(ReportsPageObjects.MEDDRA_PT_TERM));
				if (MEDDRA_PT_TERM_newValue.equalsIgnoreCase(getTestDataCellValue(scenarioName1, "PTTerm"))) {
					Reports.ExtentReportLog("", Status.PASS,
							"MEDDRA_PT_TERM_newValue  in Audit Trail updated Successfully", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL,
							"MEDDRA_PT_TERM_newValue  in Audit Trail updated Successfully", true);
				}
				String SOC_NAME_newValue = agGetText(
						ReportsPageObjects.UpdateOpeartionTypeNewValue(ReportsPageObjects.SOC_NAME)).substring(0, 10);
				if (SOC_NAME_newValue.contains(getTestDataCellValue(scenarioName1, "SOCName").substring(0, 10))) {
					Reports.ExtentReportLog("", Status.PASS, "SOC_NAME_newValue  in Audit Trail updated Successfully",
							true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "SOC_NAME_newValue  in Audit Trail updated Successfully",
							true);
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, " Verify the Audit trail for changes made Fails", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Verify the Audit trail for changes
	 *             made.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date :06-Nov-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AuditTrailVerifcationDelete(String scenarioName) {
		try {

			ReportsOperations.reportsNavigations("standard");
			Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
			agSetStepExecutionDelay("3000");
			CommonOperations.setListDropDownValue(ReportsPageObjects.messageTypeSelect,
					getTestDataCellValue(scenarioName, "MessageType"));

			agSetValue(ReportsPageObjects.auditTrialBetweenFrom,
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "auditTrialBetween")));
			agSetValue(ReportsPageObjects.auditTrialBetweenTo,
					CommonOperations.returnDateTime(getTestDataCellValue(scenarioName, "auditTrialBetween")));

			agClick(ReportsPageObjects.auditTrialGenerateReportButton);
			if (agIsVisible(ReportsPageObjects.Delete) == true) {
				String ActiveValue = agGetText(ReportsPageObjects.DeleteOpeartionType(ReportsPageObjects.ACTIVE));
				if (ActiveValue.equalsIgnoreCase("true")) {
					Reports.ExtentReportLog("", Status.PASS, "Active Value in Audit Trail Deleted Successfully", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "Active Value in Audit Trail not Deleted Successfully",
							true);
				}
				String ALWAYS_BROAD_NARROW = agGetText(
						ReportsPageObjects.DeleteOpeartionType(ReportsPageObjects.ALWAYS_BROAD_NARROW));
				if (ALWAYS_BROAD_NARROW.equalsIgnoreCase("3")) {
					Reports.ExtentReportLog("", Status.PASS,
							"ALWAYS_BROAD_NARROW Value in Audit Trail Deleted Successfully", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL,
							"ALWAYS_BROAD_NARROW Value in Audit Trail has not Deleted Successfully", true);
				}
				String MEDDRA_CODE = agGetText(ReportsPageObjects.DeleteOpeartionType(ReportsPageObjects.MEDDRA_CODE));
				if (MEDDRA_CODE.equalsIgnoreCase(getTestDataCellValue(scenarioName, "MedDRAPTCode"))) {
					Reports.ExtentReportLog("", Status.PASS, "MEDDRA_CODE Value in Audit Trail Deleted Successfully",
							true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL,
							"MEDDRA_CODE Value in Audit Trail not Deleted Successfully", true);
				}

				String MEDDRA_PT_TERM = agGetText(
						ReportsPageObjects.DeleteOpeartionType(ReportsPageObjects.MEDDRA_PT_TERM));

				if (MEDDRA_PT_TERM.equalsIgnoreCase(getTestDataCellValue(scenarioName, "PTTerm"))) {
					Reports.ExtentReportLog("", Status.PASS, "MEDDRA_PT_TERM Value in Audit Trail Deleted Successfully",
							true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL,
							"MEDDRA_PT_TERM Value in Audit Trail not Deleted Successfully", true);
				}

				String SOC_NAME = agGetText(ReportsPageObjects.DeleteOpeartionType(ReportsPageObjects.SOC_NAME))
						.substring(0, 10);
				;
				if (SOC_NAME.contains(getTestDataCellValue(scenarioName, "SOCName").substring(0, 10))) {
					Reports.ExtentReportLog("", Status.PASS, "SOC_NAME Value in Audit Trail Deleted Successfully",
							true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "SOC_NAME Value in Audit Trail not Deleted Successfully",
							true);
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, " Verify the Audit trail for changes made Fails", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create Always Serious Event.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date :27-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void UpdateAlwaysSeriousEvent(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(Lib_AlwaysSeriousEvent_PageObjects.edit_Icon);
		agAssertVisible(Lib_AlwaysSeriousEvent_PageObjects.alwaysSeriousEvent_Lable);
		agClick(Lib_AlwaysSeriousEvent_PageObjects.alwaysSeriousEventMedDRAPTTerm_lookup);
		agSetValue(Lib_AlwaysSeriousEvent_PageObjects.dictionaryCodingBrowser_SearchTxtfield,
				getTestDataCellValue(scenarioName, "SearchTerm"));
		agClick(Lib_AlwaysSeriousEvent_PageObjects.dictionaryCodingBrowser_SearchBtn);
		agSetStepExecutionDelay("2000");
		agClick(Lib_AlwaysSeriousEvent_PageObjects.dictionaryCodingBrowser_OkBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agJavaScriptExecuctorClick(Lib_AlwaysSeriousEvent_PageObjects.saveButton);
		agWaitTillVisibilityOfElement(CommonPageObjects.validaionOk_Btn);
		agClick(CommonPageObjects.validaionOk_Btn);
		agIsVisible(LibrariesPageObjects.alwaysSeriousKeywordSearch);
		Reports.ExtentReportLog("", Status.INFO, "Always Serious Event Updated", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Always Serious Event.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 27-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchandDelete(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(Lib_AlwaysSeriousEvent_PageObjects.eventVersion(getTestDataCellValue(scenarioName, "Version")));
		agSetStepExecutionDelay("2000");
		agSetValue(Lib_AlwaysSeriousEvent_PageObjects.keywordSearch_Textbox,
				getTestDataCellValue(scenarioName, "PTTerm"));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agClick(Lib_AlwaysSeriousEvent_PageObjects.search_Icon);
		agSetStepExecutionDelay("3000");
		agIsVisible(Lib_AlwaysSeriousEvent_PageObjects.paginator);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("", Status.INFO, "Search is successful", true);

		if (agIsVisible(Lib_AlwaysSeriousEvent_PageObjects.edit_Icon) == true) {
			DeleteAlwaysSeriousEvent(scenarioName);
		}
	}

}
