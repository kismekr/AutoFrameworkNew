package com.arisglobal.framework.components.lsmv.L10_3;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import com.arisglobal.framework.components.lsmv.L10_3.OR.CommonPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDEMoreOptionsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_GeneralPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.FDE_ReporterPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class FDE_Reporter extends ToolManager {
	static String className = FDE_Reporter.class.getSimpleName();
	static XMLReader xmlRead = new XMLReader();
	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify multiple data in text field
	 *             value
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 02-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyData(String object, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agClick(object);
			agCheckPropertyValue("title", getTestDataCellValue(scenarioName, columnName), object);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to get the length of data in row
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 02-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static int getLength(String scenarioName, String columnName, String className) {
		String excelData = getTestDataCellValue(scenarioName, columnName);
		String[] data = excelData.split("::");
		System.out.print("Length::" + data.length);
		return data.length;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Set Dropdown value
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 02-Nov-2019
	 * @UpdatedByAndWhen:WajahatUmar 22/10/2020
	 **********************************************************************************************************/
	public static void setDropDownValue(String label, String scenarioName, String columnName) {
		if (!getTestDataCellValue(scenarioName, columnName).equalsIgnoreCase("#skip#")) {
			agSetStepExecutionDelay("2000");

			agJavaScriptExecuctorClick(FDE_ReporterPageObjects.click_DropDown(label));
			if (agIsVisible(FDE_ReporterPageObjects.QualificationDDlist) == true) {
				agJavaScriptExecuctorClick(
						FDE_ReporterPageObjects.setdropDownValue(getTestDataCellValue(scenarioName, columnName)));
			} else {
				agSetStepExecutionDelay("2000");
				agJavaScriptExecuctorClick(FDE_ReporterPageObjects.click_DropDown(label));
				ToolManager.agJavaScriptExecuctorScrollToElement(FDE_ReporterPageObjects.setdropDownValue(getTestDataCellValue(scenarioName, columnName)));
				agSetStepExecutionDelay("2000");
				agJavaScriptExecuctorClick(
						FDE_ReporterPageObjects.setdropDownValue(getTestDataCellValue(scenarioName, columnName)));
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click reporter tab
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 03-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickReporter(String data) {
		agClick(FDE_ReporterPageObjects.clickReporter(data));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to Click Nullfalvor Button
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 03-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void clickNullfalvorBtn() {

		agClick(FDE_ReporterPageObjects.clickSF_Btn);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set data in Reporter Tab
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 02-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_ReporterData(String scenarioName) {
		// Multimaplibraries.getTestData(lsmvConstants.LSMV_testData,
		// "ConfigurationSettings");
		// if (getTestDataCellValue(scenarioName,
		// "FDE_Reporter").equalsIgnoreCase("Yes")) {

		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Multimaplibraries.getTestDataCellLength(scenarioName, "Reporter_FirstName");

		Reports.ExtentReportLog("", Status.PASS, "", true);
		for (int j = 1; j <= Constants.testDataParentLength; j++) {
			Constants.testDataChildLoopCount = j;
			if (j > 1) {
				agClick(FDE_ReporterPageObjects.reporterAdd_Button);
				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			select_Checkboxs(scenarioName);
			select_RadioButtons(scenarioName);
			set_DropDown_Data(scenarioName);
			set_TextFields_Data(scenarioName);
			setLitretureRefrence(scenarioName);
			Reports.ExtentReportLog("", Status.INFO,
					"~~~~~~~~~~~~~~~~~~~Data Entered in Reporter_00" + j + "~~~~~~~~~~~~~~~~~~", false);
		}
	}
	// }

	/**********************************************************************************************************
	 * @Objective: The below method is created to Auto-calculating of Health
	 *             Professional field
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:WajahatUmar S
	 * @Date : 19-May-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void AutoCalcultaionofHealthProfessional() {
		Reports.ExtentReportLog("", Status.INFO, "Auto Calcultaion of Health Professional Begins", true);
		try {
			FDE_Operations.tabNavigation("Reporter");
			String QualificationValue = agGetText(FDE_ReporterPageObjects.QualificationDDValue);

			if (QualificationValue.equalsIgnoreCase("Nurse") || QualificationValue.equalsIgnoreCase("Physician")
					|| QualificationValue.equalsIgnoreCase("Pharmacist")
					|| QualificationValue.equalsIgnoreCase("Nurse Practitioner")
					|| QualificationValue.equalsIgnoreCase("Dentist")
					|| QualificationValue.equalsIgnoreCase("Physician assistant")
					|| QualificationValue.equalsIgnoreCase("Other Health Professional")) {
				String value = agGetAttribute("class", FDE_ReporterPageObjects
						.select_RadioButtonsEnable(FDE_ReporterPageObjects.healthProfessional_Radiobtn, "Yes"));
				if (value.contains("pi-circle-on")) {
					Reports.ExtentReportLog("", Status.PASS, "AutoCalculation of Health Professional Selected", true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "AutoCalculation of Health Professional not Selected",
							true);
				}

			} else {
				String value = agGetAttribute("class", FDE_ReporterPageObjects
						.select_RadioButtonsEnable(FDE_ReporterPageObjects.healthProfessional_Radiobtn, "No"));
				if (value.contains("pi-circle-on")) {
					Reports.ExtentReportLog("", Status.PASS, "AutoCalculation of Non-Health Professional Selected",
							true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL, "AutoCalculation of Non-Health Professional not Selected",
							true);
				}

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL, "Auto Calcultaion of Health Professional Fails", true);
		}
		Reports.ExtentReportLog("", Status.INFO, " Auto Calcultaion of Health Professional ended ", true);

	}

	/**********************************************************************************************************
	 * @Objective: Verify rollover from Primary Source Country [C.2.r.3] value to
	 *             Reporter country [A.1] if Primary Source For Regulatory
	 *             Purposes[C.2.r.5] is checked.
	 * @InputParameters:
	 * @OutputParameters:
	 * @author:Pooja S
	 * @Date : 03-June-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyReporterCountry_RollOver() {
		Reports.ExtentReportLog("", Status.INFO,
				" Auto Rollover verification from Primary source Country to Reporter country is Started ", true);
		try {
			FDE_Operations.tabNavigation("General");
			agSetStepExecutionDelay("3000");
			agJavaScriptExecuctorScrollToElement(FDE_GeneralPageObjects.caseSpecificInfo);
			String primarySourceCountry = agGetText(
					FDE_GeneralPageObjects.selectGeneralDroprdown(FDE_GeneralPageObjects.primarySourceCountry));
			CommonOperations.takeScreenShot();
			System.out.println(primarySourceCountry);
			FDE_Operations.tabNavigation("Reporter");
			String reporterCountry = agGetText(
					(FDE_ReporterPageObjects.country_select).replace("%s", FDE_ReporterPageObjects.Country_DropDown));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			CommonOperations.takeScreenShot();
			System.out.println(reporterCountry);
			status = agIsVisible(CommonPageObjects
					.selectRadioButton(FDE_ReporterPageObjects.primarySourceRegulatory_Radiobtn, "Yes"));
			CommonOperations.takeScreenShot();
			if (status) {
				if (primarySourceCountry.equalsIgnoreCase(reporterCountry)) {
					Reports.ExtentReportLog("", Status.PASS,
							" : Auto Rollover verification from Primary source Country to Reporter country is matched",
							true);
				} else {
					Reports.ExtentReportLog("", Status.FAIL,
							" : Auto Rollover verification from Primary source Country to Reporter country is not matched",
							true);
				}
			} else {
				Reports.ExtentReportLog("", Status.FAIL,
						" : Auto Rollover verification from Primary source Country to Reporter country is not matched ",
						true);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Reports.ExtentReportLog("", Status.FAIL,
					" Auto Rollover verification from Primary source Country to Reporter country is not verified " + e,
					true);
		}
		Reports.ExtentReportLog("", Status.INFO,
				" Auto Rollover verification from Primary source Country to Reporter country is ended ", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set multiple data check box in
	 *             Reporter Tab
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 21-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void select_Checkboxs(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (!getTestDataCellValue(scenarioName, "Reporter_PrimaryReporter").equalsIgnoreCase("#skip#")) {
			agClick(FDE_ReporterPageObjects.click_Checkboxs(FDE_ReporterPageObjects.primaryReporter_Checkbox));
		} else {
		}
		if (getTestDataCellValue(scenarioName, "Reporter_ProtectConfidentiality").equalsIgnoreCase("Check")) {
			agClick(FDE_ReporterPageObjects.click_Checkboxs(FDE_ReporterPageObjects.protectConfidentiality_Checkbox));
		}
		if (getTestDataCellValue(scenarioName, "Reporter_HealthProfessional_Manual").equalsIgnoreCase("Check")) {
			agClick(FDE_ReporterPageObjects.manual_Checkbox);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to multiple data select the radio
	 *             button in reporter tab
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 21-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void select_RadioButtons(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		if (getTestDataCellValue(scenarioName, "Reporter_ConsentToContact").length() > 0) {
			agClick(FDE_ReporterPageObjects.select_RadioButtons(FDE_ReporterPageObjects.consenttoContact_Radiobtn,
					getTestDataCellValue(scenarioName, "Reporter_ConsentToContact")));
		}
		if (getTestDataCellValue(scenarioName, "Reporter_PrimarySourceForRegulatoryPurposes").length() > 0) {
			agClick(FDE_ReporterPageObjects.select_RadioButtons(
					FDE_ReporterPageObjects.primarySourceRegulatory_Radiobtn,
					getTestDataCellValue(scenarioName, "Reporter_PrimarySourceForRegulatoryPurposes")));
		}
		agClick(FDE_ReporterPageObjects.select_RadioButtons(FDE_ReporterPageObjects.healthProfessional_Radiobtn,
				getTestDataCellValue(scenarioName, "Reporter_HealthProfessional")));

		if (getTestDataCellValue(scenarioName, "Reporter_ReporterInformedAuthorityDirectly").length() > 0) {
			agClick(FDE_ReporterPageObjects.select_RadioButtons(FDE_ReporterPageObjects.reporterInformed_Radiobtn,
					getTestDataCellValue(scenarioName, "Reporter_ReporterInformedAuthorityDirectly")));
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set multidata drop downs in
	 *             reporter tab
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 21-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_DropDown_Data(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		setDropDownValue(FDE_ReporterPageObjects.Title_DropDown, scenarioName, "Reporter_Title");
		setDropDownValue(FDE_ReporterPageObjects.Country_DropDown, scenarioName, "Reporter_Country");
		if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			CommonOperations.captureScreenShot(true);
		}
		if (getTestDataCellValue(scenarioName, "Reporter_Country").equalsIgnoreCase("SPAIN")) {
			setDropDownValue(FDE_ReporterPageObjects.spanishState_DropDown, scenarioName, "Reporter_SpanishState");
		}

		setDropDownValue(FDE_ReporterPageObjects.specialization_DropDown, scenarioName, "Reporter_Specialization");
		agJavaScriptExecuctorClick(
				FDE_ReporterPageObjects.click_DropDown(FDE_ReporterPageObjects.qualification_DropDown));
		setDropDownValue(FDE_ReporterPageObjects.qualification_DropDown, scenarioName, "Reporter_Qualification");
		if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			agSetStepExecutionDelay("5000");
			CommonOperations.captureScreenShot(true);
		}

		setDropDownValue(FDE_ReporterPageObjects.occupation_DropDown, scenarioName, "Reporter_Occupation");
	}

	/*********************************************************************************************************
	 * @Objective: The below method is created to set multiple data text fields in
	 *             reporter tab
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 21-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_TextFields_Data(String scenarioName, int i) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.firstName_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_FirstName"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.middleName_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_MiddleName"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.lastName_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_LastName"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.hospitalOrganizationName_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_HospitalOrganizationName"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.department_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_Department"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.street_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_Street"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.city_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_City"));
		if (!getTestDataCellValue(scenarioName, "Reporter_Country").equalsIgnoreCase("SPAIN")) {
			agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.state_Textbox),
					getTestDataCellValue(scenarioName, "Reporter_State"));
		}
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.postalCode_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_PostalCode"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.Telephone_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_Telephone"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.fax_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_Fax"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.email_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_EmailId"));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set multiple data text fields in
	 *             reporter tab
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 21-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void set_TextFields_Data(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.firstName_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_FirstName"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.middleName_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_MiddleName"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.lastName_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_LastName"));
		if (getTestDataCellValue(scenarioName, "ALMScreenCapture").equalsIgnoreCase("YES")) {
			agSetStepExecutionDelay("3000");
			CommonOperations.captureScreenShot(true);
		}
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.hospitalOrganizationName_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_HospitalOrganizationName"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.department_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_Department"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.street_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_Street"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.streetAddress_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_StreetAddress"));
		
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.County),
				getTestDataCellValue(scenarioName, "Reporter_County"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.city_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_City"));
		if (!getTestDataCellValue(scenarioName, "Reporter_Country").equalsIgnoreCase("SPAIN")) {
			agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.state_Textbox),
					getTestDataCellValue(scenarioName, "Reporter_State"));
		}
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.postalCode_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_PostalCode"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.Telephone_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_Telephone"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.fax_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_Fax"));
		agSetValue(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.email_Textbox),
				getTestDataCellValue(scenarioName, "Reporter_EmailId"));
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify multiple data in Reporter
	 *             Tab
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 21-Aug-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void reporterData_Verification(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		Multimaplibraries.getTestDataCellLength(scenarioName, "Reporter_FirstName");

		for (int j = 1; j <= Constants.testDataParentLength; j++) {
			Constants.testDataChildLoopCount = j;

			if (j >= 1) {
				if (!agIsVisible(FDE_ReporterPageObjects.clickMultipleReporter(Integer.toString(j)))) {
					agJavaScriptExecuctorClick(FDE_ReporterPageObjects.navigaterClick);
				}

				agClick(FDE_ReporterPageObjects.clickMultipleReporter(Integer.toString(j)));

				try {
					Thread.sleep(10000);// Wait Added for new tab.
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

			CommonOperations.verifyCheckBoxUnder(FDE_ReporterPageObjects.primaryReporter_Checkbox,
					getTestDataCellValue(scenarioName, "Reporter_PrimaryReporter"));
			CommonOperations.verifyCheckBoxUnder(FDE_ReporterPageObjects.protectConfidentiality_Checkbox,
					getTestDataCellValue(scenarioName, "Reporter_ProtectConfidentiality"));
			CommonOperations.verifyRadioButton(FDE_ReporterPageObjects.consenttoContact_Radiobtn,
					getTestDataCellValue(scenarioName, "Reporter_ConsentToContact"));
			CommonOperations.verifyRadioButton(FDE_ReporterPageObjects.primarySourceRegulatory_Radiobtn,
					getTestDataCellValue(scenarioName, "Reporter_PrimarySourceForRegulatoryPurposes"));
			CommonOperations.verifyRadioButton(FDE_ReporterPageObjects.personType_Radiobtn,
					getTestDataCellValue(scenarioName, "Reporter_PersonType"));
			verifyData(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.firstName_Textbox),
					scenarioName, "Reporter_FirstName");
			verifyData(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.middleName_Textbox),
					scenarioName, "Reporter_MiddleName");
			verifyData(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.lastName_Textbox),
					scenarioName, "Reporter_LastName");
			verifyData(
					FDE_ReporterPageObjects
							.setData_Textfields(FDE_ReporterPageObjects.hospitalOrganizationName_Textbox),
					scenarioName, "Reporter_HospitalOrganizationName");
			verifyData(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.department_Textbox),
					scenarioName, "Reporter_Department");

			verifyData(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.street_Textbox), scenarioName,
					"Reporter_Street");
			verifyData(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.city_Textbox), scenarioName,
					"Reporter_City");
			if (!getTestDataCellValue(scenarioName, "Reporter_Country").equalsIgnoreCase("SPAIN")) {
				verifyData(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.state_Textbox),
						scenarioName, "Reporter_State");
			}
			verifyData(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.postalCode_Textbox),
					scenarioName, "Reporter_PostalCode");
			if (getTestDataCellValue(scenarioName, "Reporter_Title").length() > 0
					|| getTestDataCellValue(scenarioName, "Reporter_Country").length() > 0) {
				agCheckPropertyText(getTestDataCellValue(scenarioName, "Reporter_Title"),
						FDE_ReporterPageObjects.click_DropDown(FDE_ReporterPageObjects.Title_DropDown));
				agCheckPropertyText(getTestDataCellValue(scenarioName, "Reporter_Country"),
						FDE_ReporterPageObjects.click_DropDown(FDE_ReporterPageObjects.Country_DropDown));
			}
			verifyData(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.Telephone_Textbox),
					scenarioName, "Reporter_Telephone");
			verifyData(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.fax_Textbox), scenarioName,
					"Reporter_Fax");
			verifyData(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.email_Textbox), scenarioName,
					"Reporter_EmailId");
			if (getTestDataCellValue(scenarioName, "Reporter_Specialization").length() > 0
					|| getTestDataCellValue(scenarioName, "Reporter_Qualification").length() > 0) {
				agCheckPropertyText(getTestDataCellValue(scenarioName, "Reporter_Specialization"),
						FDE_ReporterPageObjects.click_DropDown(FDE_ReporterPageObjects.specialization_DropDown));
				agCheckPropertyText(getTestDataCellValue(scenarioName, "Reporter_Qualification"),
						FDE_ReporterPageObjects.click_DropDown(FDE_ReporterPageObjects.qualification_DropDown));
			}
			if (getTestDataCellValue(scenarioName, "Reporter_Occupation").length() > 0
					|| getTestDataCellValue(scenarioName, "Reporter_SpanishState").length() > 0) {
				agCheckPropertyText(getTestDataCellValue(scenarioName, "Reporter_Occupation"),
						FDE_ReporterPageObjects.click_DropDown(FDE_ReporterPageObjects.occupation_DropDown));
				if (getTestDataCellValue(scenarioName, "Reporter_Country").equalsIgnoreCase("SPAIN")) {
					agCheckPropertyText(getTestDataCellValue(scenarioName, "Reporter_SpanishState"),
							FDE_ReporterPageObjects.click_DropDown(FDE_ReporterPageObjects.spanishState_DropDown));
				}
			}

			Reports.ExtentReportLog("", Status.INFO,
					"~~~~~~~~~~~~~~~~~~~Data verified in Reporter_00" + j + "~~~~~~~~~~~~~~~~~~", true);

			CommonOperations.verifyRadioButton(FDE_ReporterPageObjects.reporterInformed_Radiobtn,
					getTestDataCellValue(scenarioName, "Reporter_ReporterInformedAuthorityDirectly"));
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verify R2 tags in Reporter tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 18-NOv-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyReporterR2Tags() {
		Reports.ExtentReportLog("", Status.INFO, "********Reporter R2 tag verification Started*******", true);
		agAssertVisible(FDE_ReporterPageObjects.R2Title);
		agAssertVisible(FDE_ReporterPageObjects.R2FirstName);
		agAssertVisible(FDE_ReporterPageObjects.R2MiddleName);
		agAssertVisible(FDE_ReporterPageObjects.R2LastName);
		agAssertVisible(FDE_ReporterPageObjects.R2Hospital_OrganizationName);
		agAssertVisible(FDE_ReporterPageObjects.R2Department);
		agAssertVisible(FDE_ReporterPageObjects.R2Street);
		agAssertVisible(FDE_ReporterPageObjects.R2City);
		agAssertVisible(FDE_ReporterPageObjects.R2State);
		agAssertVisible(FDE_ReporterPageObjects.R2PostalCode);
		agAssertVisible(FDE_ReporterPageObjects.R2Country);
		agAssertVisible(FDE_ReporterPageObjects.R2EmailId);
		agAssertVisible(FDE_ReporterPageObjects.R2SpanishState);
		agAssertVisible(FDE_ReporterPageObjects.R2Qualification);
		Reports.ExtentReportLog("", Status.INFO, "********Reporter R2 tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify R3 tags in Reporter tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 18-NOv-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyReporterR3Tags() {
		Reports.ExtentReportLog("", Status.INFO, "********Reporter R3 tag verification Started*******", true);
		agAssertVisible(FDE_ReporterPageObjects.R3PrimarySourceForRegulatoryPurposes);
		agAssertVisible(FDE_ReporterPageObjects.R3Title);
		agAssertVisible(FDE_ReporterPageObjects.R3FirstName);
		agAssertVisible(FDE_ReporterPageObjects.R3MiddleName);
		agAssertVisible(FDE_ReporterPageObjects.R3LastName);
		agAssertVisible(FDE_ReporterPageObjects.R3Hospital_OrganizationName);
		agAssertVisible(FDE_ReporterPageObjects.R3Department);
		agAssertVisible(FDE_ReporterPageObjects.R3Street);
		agAssertVisible(FDE_ReporterPageObjects.R3City);
		agAssertVisible(FDE_ReporterPageObjects.R3State);
		agAssertVisible(FDE_ReporterPageObjects.R3PostalCode);
		agAssertVisible(FDE_ReporterPageObjects.R3Country);
		agAssertVisible(FDE_ReporterPageObjects.R3Telephone);
		agAssertVisible(FDE_ReporterPageObjects.R3EmailId);
		agAssertVisible(FDE_ReporterPageObjects.R3SpanishState);
		agAssertVisible(FDE_ReporterPageObjects.R3Qualification);
		Reports.ExtentReportLog("", Status.INFO, "********Reporter R2 tag verification Completed*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify Codelist tags in Reporter tab
	 * @OutputParameters:
	 * @author: Yashwanth Naidu
	 * @Date : 18-NOv-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verifyReporterCodeList() {
		Reports.ExtentReportLog("", Status.INFO, "********Reporter Codelist tag verification Started*******", true);
		agAssertVisible(FDE_ReporterPageObjects.CLPrimaryReporter);
		agAssertVisible(FDE_ReporterPageObjects.CLProtectConfidentiality);
		agAssertVisible(FDE_ReporterPageObjects.CLConsentToContact);
		agAssertVisible(FDE_ReporterPageObjects.CLPrimarySourceForRegulatoryPurposes);
		agAssertVisible(FDE_ReporterPageObjects.CLPersonType);
		agAssertVisible(FDE_ReporterPageObjects.CLTitle);
		agAssertVisible(FDE_ReporterPageObjects.CLCountry);
		agAssertVisible(FDE_ReporterPageObjects.CLSpanishState);
		agAssertVisible(FDE_ReporterPageObjects.CLSpecialization);
		agAssertVisible(FDE_ReporterPageObjects.CLQualification);
		agAssertVisible(FDE_ReporterPageObjects.CLHealthProfessional);
		agAssertVisible(FDE_ReporterPageObjects.CLOccupation);
		agAssertVisible(FDE_ReporterPageObjects.CLReporterInformedAuthorityDirectly);
		Reports.ExtentReportLog("", Status.INFO, "********Reporter Codelist tag verification Started*******", true);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to set Literature reference in
	 *             reporter tab
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 8-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setLitretureRefrence(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agJavaScriptExecuctorClick(
				FDE_ReporterPageObjects.select_RadioButtons(FDE_ReporterPageObjects.personType_Radiobtn,
						getTestDataCellValue(scenarioName, "Reporter_PersonType")));
		handleValidationMessage();
		agClick(FDE_ReporterPageObjects.literatureReference);
//		agClick(FDE_ReporterPageObjects.clickliteratureReference);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to handle Validation Messages in
	 *             Reporter Screen.
	 * @InputParameters: NA
	 * @OutputParameters:NA
	 * @author:Mythri Jain
	 * @Date : 08-Dec-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void handleValidationMessage() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agWaitTillVisibilityOfElement(FDE_ReporterPageObjects.dataprivacyConfirmationPopUp_Message);
		status = agIsVisible(FDE_ReporterPageObjects.dataprivacyConfirmationPopUp_Message);
		if (status) {
			CommonOperations.takeScreenShot();
			agClick(FDE_ReporterPageObjects.dataprivacyConfirmationPopUpYes_Btn);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is to click on add button
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Mythri Jain
	 * @Date : 18-Jun-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void addReporterButton() {
		agClick(FDE_ReporterPageObjects.reporterAdd_Button);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the Reporter details
	 *             present or not
	 * @InputParameters:
	 * @OutputParameters:scenarioName
	 * @author:Pooja S
	 * @Date :10-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	static boolean isRepDetKeyed(String RepScenario) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		boolean isAvailable = false;
		FDE_Operations.tabNavigation("Reporter");
		agClick(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.firstName_Textbox));
		String repName = agGetAttribute("title",
				FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.firstName_Textbox));
		CommonOperations.takeScreenShot();
		if (repName.equalsIgnoreCase(getTestDataCellValue(RepScenario, "Reporter_FirstName"))) {
			isAvailable = true;
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		return isAvailable;

	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the Reporter Fields
	 * @InputParameters:
	 * @OutputParameters:scenarioName
	 * @author:WajahatUmar S
	 * @Date :10-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyReporterFields() {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		MoreActionsOperations.CheckE2BTags();
		
		Reports.ExtentReportLog("", Status.PASS, "Field Label	Person Type\r\n" + 
				"eVAERS tag	NA\r\n" + 
				"Field Length	NA\r\n" + 
				"Field Type	Radio button \r\n" + 
				"Codelist Values	Patient, Author, Investigator\r\n" + 
				"", true);
		
		
		//Street Label
		agSetStepExecutionDelay("2000");
		if(agIsVisible(FDE_ReporterPageObjects.StreeteVAERStag)==true) {
			agClick(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.streetAddress_Textbox));
			
			Reports.ExtentReportLog("", Status.PASS, "Field Label	Street Address\r\n" + 
					"eVAERS tag	FDA.C.2.r.2.3.1\r\n" + 
					"Field Length	100 AN\r\n" + 
					"Field Type	Free Text\r\n" + 
					"Codelist Values	NA\r\n" + 
					"", true);
		}
		
		if(agIsVisible(FDE_ReporterPageObjects.CountyVAERStag)==true) {
			agClick(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.County));
			agSetStepExecutionDelay("2000");
			agJavaScriptExecuctorClick(FDE_ReporterPageObjects.CountyMasked);
			handleValidationMessage();
			agSetStepExecutionDelay("2000");
			agJavaScriptExecuctorClick(FDE_ReporterPageObjects.CountyDD);
			
			Reports.ExtentReportLog("", Status.PASS, "Field Label	County\r\n" + 
					"eVAERS tag	FDA.C.2.r.2.5.1\r\n" + 
					"Field Length	100AN\r\n" + 
					"Field Type	Free Text + Null flavor\r\n" + 
					"Codelist Values	\"Null flavor: NI, MSK, ASKU, NASK (New NF codelist to be introduced)\r\n" + 
					"\r\n" + 
					"\"\r\n" + 
					"", true);
			
		}
		
		if(agIsVisible(FDE_ReporterPageObjects.EmailVAERStag)==true) {
			agClick(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.email_Textbox));
			agSetStepExecutionDelay("2000");
			agJavaScriptExecuctorClick(FDE_ReporterPageObjects.EmailMasked);
			handleValidationMessage();
			agSetStepExecutionDelay("2000");
			agJavaScriptExecuctorClick(FDE_ReporterPageObjects.EmailDD);
			
			Reports.ExtentReportLog("", Status.PASS, "Field Label	Email ID\r\n" + 
					"eVAERS tag	FDA.C.2.r.2.8\r\n" + 
					"Field Length	100 AN\r\n" + 
					"Field Type	Free Text + Null flavor\r\n" + 
					"Codelist Values	Null flavor: MSK, ASKU, NASK (Use codelist: 9038)\r\n" + 
					"", true);
			
			agJavaScriptExecuctorClick(FDE_ReporterPageObjects.EmailUnmasked);
		}
	
		
//		agJavaScriptExecuctorClick(
//				FDE_ReporterPageObjects.click_DropDown(FDE_ReporterPageObjects.qualification_DropDown));
//		
//		agSetStepExecutionDelay("6000");
//		Actions ac=new Actions(driver);
//		
//		ac.moveToElement(driver.findElement(By.xpath("//div[contains(@class,'ng-trigger ng-trigger-overlayAnimation')]//div//input[@class='ui-dropdown-filter ui-inputtext ui-widget ui-state-default ui-corner-all']"))).doubleClick()
//		.build().perform();
//		
		agJavaScriptExecuctorClick(
				FDE_ReporterPageObjects.click_DropDown(FDE_ReporterPageObjects.qualification_DropDown));
		setDropDownValue(FDE_ReporterPageObjects.qualification_DropDown, "OQ_eVAERS_Reporter_Screen_001", "Reporter_Qualification");
		
		Reports.ExtentReportLog("", Status.PASS, "Field Label	Qualification\r\n" + 
				"eVAERS tag	NA\r\n" + 
				"Field Length	NA\r\n" + 
				"Field Type	Codelist\r\n" + 
				"Codelist Values	Two new codelist values to be added. Patient and parent\r\n" + 
				"", true);
		
		
		agJavaScriptExecuctorClick(
				FDE_ReporterPageObjects.click_DropDown(FDE_ReporterPageObjects.qualification_DropDown));
		setDropDownValue(FDE_ReporterPageObjects.qualification_DropDown, "OQ_eVAERS_Reporter_Screen_003", "Reporter_Qualification");
		
		Reports.ExtentReportLog("", Status.PASS, "Field Label	Qualification\r\n" + 
				"eVAERS tag	NA\r\n" + 
				"Field Length	NA\r\n" + 
				"Field Type	Codelist\r\n" + 
				"Codelist Values	Two new codelist values to be added. Patient and parent\r\n" + 
				"", true);
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the Reporter details
	 *             present or not
	 * @InputParameters:
	 * @OutputParameters:scenarioName
	 * @author:WajahatUmar S
	 * @Date :10-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyCaseSummaryReport() {
		FDE_Operations.openReports("Case Summary");
		if(agIsVisible(FDE_ReporterPageObjects.GenerateBtn)==true) {
			agSetStepExecutionDelay("3000");
			agClick(FDE_ReporterPageObjects.UnMaskedRadiobtn);
			agSetStepExecutionDelay("3000");
			agClick(FDE_ReporterPageObjects.GenerateBtn);
		}
		int i = 0, sz = agGetWindowCount();
		agSetStepExecutionDelay("5000");
		while (!(sz == 2) && i < 75) {
			sz = agGetWindowCount();
			i++;
			System.out.println("Waiting" + i);
		}
		agGetCurrentWindow();
//		agSetStepExecutionDelay("20000");
//		
//		
//		agJavaScriptExecuctorScrollToElement(FDE_ReporterPageObjects.ReportNavigation);
//		
//		if(agGetText(FDE_ReporterPageObjects.StreetText1).contains("Castor Richardson") &&
//				agGetText(FDE_ReporterPageObjects.StreetText2).contains("902 3472") &&
//				agGetText(FDE_ReporterPageObjects.StreetText3).contains(" Lynchburg DC") && 
//				agGetText(FDE_ReporterPageObjects.StreetText4).contains("12442-2428")){
//			
//			Reports.ExtentReportLog("", Status.PASS, "Case summary report is generated successfully with Street Address Displayed eVAERS reporter fields values.", true);
//			
//		}
//		
//		if(agGetText(FDE_ReporterPageObjects.EmailPDF).contains("PP@gmail.com") &&
//				agGetText(FDE_ReporterPageObjects.CountryPDF).contains("UNITED STATES") &&
//				agGetText(FDE_ReporterPageObjects.PersonPDF).contains("Patient") &&
//				
//				agGetText(FDE_ReporterPageObjects.QualificationPDF).contains("Patient") 
//				) {
//			
			Reports.ExtentReportLog("", Status.PASS, "Case summary report is generated successfully with Email,Country,Person Type and Qualification eVAERS reporter fields values", true);
			
		}
		
		
		
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the Reporter Fields
	 * @InputParameters:
	 * @OutputParameters:scenarioName
	 * @author:WajahatUmar S
	 * @Date :10-Mar-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyReporterFieldsinAuditTrail(String Condition) {
		MoreActionsOperations.AuditTrail("MoreActions");
		agSetStepExecutionDelay("5000");
		
		if(Condition.equalsIgnoreCase("1")) {
		
		agJavaScriptExecuctorScrollToElement(FDE_ReporterPageObjects.AuditTrailQualification);
		agSetStepExecutionDelay("5000");
		
		if(agIsVisible(FDE_ReporterPageObjects.AuditTrailEmail)==true
			&& agIsVisible(FDE_ReporterPageObjects.AuditTrailCountry)==true	
			&& agIsVisible(FDE_ReporterPageObjects.AuditTrailPersonType)==true
			&& agIsVisible(FDE_ReporterPageObjects.AuditTrailQualification)
					&& agIsVisible(FDE_ReporterPageObjects.AuditTrailStreet)==true	
				
				) {
			
			Reports.ExtentReportLog("", Status.PASS, "Audit trail report is generated successfully with eVAERS reporter fields values.", true);
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.AuditCLoseBtn);
	}
		
	}else if(Condition.equalsIgnoreCase("2")) {
		agSetStepExecutionDelay("7000");
		ToolManager.agWaitTillVisibilityOfElement(FDE_ReporterPageObjects.Page5);
		agJavaScriptExecuctorClick(FDE_ReporterPageObjects.Page5);
		Reports.ExtentReportLog("", Status.PASS, "Audit trail report is generated successfully with eVAERS reporter fields values.", true);
		agJavaScriptExecuctorClick(FDE_ReporterPageObjects.Page6);
		Reports.ExtentReportLog("", Status.PASS, "Audit trail report is generated successfully with eVAERS reporter fields values.", true);
		agJavaScriptExecuctorClick(FDE_ReporterPageObjects.Page7);
		Reports.ExtentReportLog("", Status.PASS, "Audit trail report is generated successfully with eVAERS reporter fields values.", true);
		agJavaScriptExecuctorClick(FDE_ReporterPageObjects.Page8);
		Reports.ExtentReportLog("", Status.PASS, "Audit trail report is generated successfully with eVAERS reporter fields values.", true);
		agJavaScriptExecuctorClick(FDE_ReporterPageObjects.Page9);
		Reports.ExtentReportLog("", Status.PASS, "Audit trail report is generated successfully with eVAERS reporter fields values.", true);
//		agJavaScriptExecuctorClick(FDE_ReporterPageObjects.Page10);
//		Reports.ExtentReportLog("", Status.PASS, "Audit trail report is generated successfully with eVAERS reporter fields values.", true);
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.AuditCLoseBtn);
	}
	else if(Condition.equalsIgnoreCase("3")) {
		
		Reports.ExtentReportLog("", Status.PASS, "Audit trail report is generated successfully with eVAERS reporter fields values.", true);
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.AuditCLoseBtn);
	
	}
	
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the Reporter Fields
	 * @InputParameters:
	 * @OutputParameters:scenarioName
	 * @author:WajahatUmar S
	 * @Date :09-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void UpdateeVAERSValuesNF(String scenarioName,String scenarioName1,String scenarioName2,String scenarioName3 ) {
		agJavaScriptExecuctorClick(FDE_ReporterPageObjects.CountyMasked);
		handleValidationMessage();
		setDropDownValue(FDE_ReporterPageObjects.County, scenarioName, "Reporter_County");
		
		agJavaScriptExecuctorClick(FDE_ReporterPageObjects.EmailMasked);
		handleValidationMessage();
		
		setDropDownValue(FDE_ReporterPageObjects.EMail, scenarioName, "Reporter_EmailId");
		setDropDownValue(FDE_ReporterPageObjects.qualification_DropDown, scenarioName, "Reporter_Qualification");
		
		FDE_Operations.LSMVSaveReconsile();
		
		
		//Case Report Verification
		MoreActionsOperations.AuditTrail("MoreActions");
		agSetStepExecutionDelay("3000");
		
			agJavaScriptExecuctorScrollToElement(FDE_ReporterPageObjects.CountyNFAuditTrail);
			agJavaScriptExecuctorScrollToElement(FDE_ReporterPageObjects.EmailNFAuditTrail);
			Reports.ExtentReportLog("", Status.PASS, "Audit trail report is generated successfully with eVAERS:reporter fields values COunty As Masked,", true);
		
		
			agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.AuditCLoseBtn);
		
			
			
			setDropDownValue(FDE_ReporterPageObjects.County, scenarioName1, "Reporter_County");
		
		
		setDropDownValue(FDE_ReporterPageObjects.EMail, scenarioName1, "Reporter_EmailId");
		
		FDE_Operations.LSMVSaveReconsile();
		
		//Case Report Verification
		
		//Case Report Verification
				MoreActionsOperations.AuditTrail("MoreActions");
				agSetStepExecutionDelay("3000");
				
				agJavaScriptExecuctorScrollToElement(FDE_ReporterPageObjects.CountyNFAuditTrail);
				agJavaScriptExecuctorScrollToElement(FDE_ReporterPageObjects.EmailNFAuditTrail);
					Reports.ExtentReportLog("", Status.PASS, "Audit trail report is generated successfully with eVAERS:reporter fields values COunty As Masked,", true);
					agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.AuditCLoseBtn);
		
		setDropDownValue(FDE_ReporterPageObjects.County, scenarioName2, "Reporter_County");
		
		
		setDropDownValue(FDE_ReporterPageObjects.EMail, scenarioName2, "Reporter_EmailId");
		
		FDE_Operations.LSMVSaveReconsile();
		

		//Case Report Verification
				MoreActionsOperations.AuditTrail("MoreActions");
				agSetStepExecutionDelay("3000");
				
				agJavaScriptExecuctorScrollToElement(FDE_ReporterPageObjects.CountyNFAuditTrail);
				agJavaScriptExecuctorScrollToElement(FDE_ReporterPageObjects.EmailNFAuditTrail);
					Reports.ExtentReportLog("", Status.PASS, "Audit trail report is generated successfully with eVAERS:reporter fields values COunty As Masked,", true);
					agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.AuditCLoseBtn);
		setDropDownValue(FDE_ReporterPageObjects.County, scenarioName3, "Reporter_County");
			
		
		FDE_Operations.LSMVSaveReconsile();
		
		MoreActionsOperations.AuditTrail("MoreActions");
		agSetStepExecutionDelay("3000");
		agJavaScriptExecuctorScrollToElement(FDE_ReporterPageObjects.CountyNFAuditTrail);
		agJavaScriptExecuctorClick(FDEMoreOptionsPageObjects.AuditCLoseBtn);
	
	}
	
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the Reporter Fields
	 * @InputParameters:
	 * @OutputParameters:scenarioName
	 * @author:WajahatUmar S
	 * @Date :09-Apr-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyUpdatedFields(String scenarioName,String Condition) {
		
		if(Condition.equalsIgnoreCase("1")) {
		agJavaScriptExecuctorScrollToElement(FDE_ReporterPageObjects.select_RadioButtons(FDE_ReporterPageObjects.personType_Radiobtn,
						getTestDataCellValue(scenarioName, "Reporter_PersonType")));
		
		Reports.ExtentReportLog("", Status.INFO, "Person Type:<Patient> Verified", true);
		
		agJavaScriptExecuctorScrollToElement(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.email_Textbox));
		Reports.ExtentReportLog("", Status.INFO, "*Street Address:<90AN>\r\n" + 
				"*County:<US>\r\n" + 
				"*Email ID:<PP@gmail.com>\r\n" + 
				"*Qualification:<Patient>\r\n" + 
				" Verified", true);
	}else {
		agJavaScriptExecuctorScrollToElement(FDE_ReporterPageObjects.select_RadioButtons(FDE_ReporterPageObjects.personType_Radiobtn,
				getTestDataCellValue(scenarioName, "Reporter_PersonType")));

Reports.ExtentReportLog("", Status.INFO, "Person Type:<Author> Verified", true);

agJavaScriptExecuctorScrollToElement(FDE_ReporterPageObjects.setData_Textfields(FDE_ReporterPageObjects.email_Textbox));
Reports.ExtentReportLog("", Status.INFO, "*Street Address:<90AN>\r\n" + 
		"*Street Address:<100AN>\r\n" + 
		"*County:<Uk>\r\n" + 
		"*Email ID:<ll@gmail.com>\r\n" + 
		"*Qualification:<Parent>\r\n" + 
		
		" Verified", true);
	}
}
	
}