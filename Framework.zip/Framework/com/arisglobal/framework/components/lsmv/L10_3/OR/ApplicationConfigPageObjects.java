package com.arisglobal.framework.components.lsmv.L10_3.OR;

import org.openqa.selenium.By;

public abstract class ApplicationConfigPageObjects {
	
	public static String formsLink  = "xpath#//span[contains(text(),'Forms')]";
	public static String formsLabel = "xpath#//label[@id='formList:adminformId']";
	public static String workFlowLink = "xpath#//a[@id='headerForm:wrkflwId']//span[@class='ui-menuitem-text'][contains(text(),'Workflow')]";
	public static String workFlowLabel = "xpath#//label[@id='wrkflowList:adminformId']";
	public static String ruleBuilderLink = "xpath#//span[contains(text(),'Rule builder')]";
	public static String scriptedRulesLink = "xpath#//span[contains(text(),'Scripted rules')]";
	public static String scriptedRulesLabel = "xpath#//div[@id='restServletListform:header']/label[text()='Scripted Rules']";
	public static String supplementFieldsLink = "xpath#//span[contains(text(),'Supplement fields')]";
	public static String duplicatecheckpoliciesLink = "xpath#//a[@id='headerForm:duplicateCheckPolicies']/span[text()='Duplicate check policies']";
	public static String duplicatecheckpoliciesLabel = "xpath#//span[@id='DuplicateCheckListform:hyphen']/following::label[text()='Duplicate Check Policies']";
	public static String xmldocConfigurationLink = "xpath#//a[@id='headerForm:e2bSettingsId']/span[text()='Xml doc configuration']";
	public static String xmldocConfigurationLabel = "xpath#//div[@id='e2bSettingsListform:header']/label[text()='XML Doc Configuration ']";
	public static String importConfigurationLink = "xpath#//li[@id='headerForm:appconfId']//child::ul/li/a/span[text()='Import configuration']";
	public static String importConfigurationLabel = "xpath#//span[@id='importDataListForm:header']/label[text()='Administration > Import Configuration']";
	public static String formsKeywordSearch = "xpath#//input[@id='formList:keyword']";
	public static String workFlowKeywordSearch = "xpath#//input[@id='wrkflowList:keyword']";
	public static String ruleBuilderLabel= "xpath#//span[contains(text(),'Rule Type')]";
	public static String scriptedKeywordSearch= "xpath# //input[@id='restServletListform:keywordSearch']";
	public static String supplementFieldsLabel = "xpath#//span[contains(text(),'Text')]";
	public static String duplicatecheckKeywordSearch = "xpath#//input[@id='DuplicateCheckListform:searchText']";
	public static String xmldocConfigNewButton = "xpath#//a[@id='e2bSettingsListform:newId']";
	public static String importConfigKeywordSearch = "xpath#//input[@id='importDataListForm:searchText']";
	public static String reportParamaterLink="xpath#//li[@id='headerForm:appconfId']//child::ul/li/a/span[text()='Report parameter']";
	
}
