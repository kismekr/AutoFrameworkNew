package com.arisglobal.framework.components.lsmv.L10_3.OR;


public abstract class ApplicationConfig_WorkFlowPageObjects {
	
	//List page
	public static String workFlowListingBreadCrumb = "xpath#//td[@class='PageTitPoc']/label[text()='WorkFlow']";
	public static String searchBar_TxtArea = "xpath#//div[@class='searchDIv keySearchDatainput']/input[@id='wrkflowList:keyword']";
	public static String search_Icon = "xpath#//div[@class='searchBlack']/a/img";
	public static String paginator = "xpath#//div[@id='wrkflowList:wrkflowTablenew_paginator_top']/span";
	public static String selectAll_CheckBx = "xpath#//div[@class='ui-chkbox ui-chkbox-all ui-widget']/div/span";
	public static String recordEdit_Icon = "xpath#//td/a/img[@id='wrkflowList:wrkflowTablenew:0:editIcon']";
	
	//WorkFlow Configuration Page
	public static String workFlowConfigBreadCrumb = "xpath#//div[@class='PageTitPoc']/label[text()='%s']";
	public static String fullDataEntryActivity_Label = "xpath#//ul[@class='ui-treenode-children']/li/span/span[text()='Full Data Entry']";
	public static String workFlowTransitionHeader_Label = "xpath#//span/label[text()='WorkFlow Activity > Full Data Entry']";
	public static String configurationMenuItem_Label = "xpath#//span[@class='ui-menuitem-text'][text()='Configuration ']";
	public static String configSubMenuItem_Label = "xpath#//span[@class='ui-menuitem-text'][text()='Configurations']";
	public static String configAssessmentType_Label = "xpath#//label[@class='ui-outputlabel ui-widget'][text()='Assessment Type']";
	public static String generateNarrativeHeader_Label = "Generate Narrative";//"xpath#//span/label[@id='configForm:j_id_yj'][text()='Generate Narrative']";
	public static String eventDescCheckBox_Label = "xpath#//div[@class='ui-panelgrid-cell ui-g-12 ui-md-6']/label[text()='Event Description']";
	public static String save_Btn = "xpath#//div[@class='DocPanelDiv']/button/span[text()='Save']";
	public static String Activity_Label = "xpath#//ul[@class='ui-treenode-children']/li/span/span[text()='%s']";
	public static String configurationLabel = "xpath#//a[@id='configForm:wfactConfigTab']/span";
	//Pivot Rule Type
	public static String config_pivotType = "xpath#//ul/li/a/span[text()='Company Unit Pivot Rule']";
	
	public static String confirmationWinTitle = "xpath#//div/span[@id='mandatoryDialogform:mandatoryID_title']";
	public static String confirmationWinInfo_Text = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String confirmationWinOK_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']/span";
	
	public static String transitionActivity_Node = "xpath#//ul[@class='ui-treenode-children']/li/span/span[text()='%s']";
	public static String subMenuHeader_Validations = "xpath#//span[@class='ui-menuitem-text'][text()='Validations']";
	
	public static String ruleNameHeader_Label = "xpath#//th/span[text()='Rule Name']";
	public static String ruleName_Label = "xpath#//tbody[@id='configForm:editCheckTableId_data']/tr/td[text()='%s']";
	public static String onSave_RadioBtn = "xpath#//tr/td[text()='%s%']/following::td[2]/div//td/label[text()='%eventType%']";
	public static String onComplete_RadioBtn = "xpath#//tr/td[text()='%s%']/following::td[5]/div//td/label[text()='%eventType%']";
	
	/**********************************************************************************************************
	 * @Objective: Verify the page bread crumb based on the config selected
	 * @InputParameters: Work Flow Name (eg. ISP Case Processing Workflow)
	 * @OutputParameters: 
	 * @author: Shamanth S 
	 * @Date: 16-Nov-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String workFlowPageTitleBreadScrumb(String configName) {
		String value = workFlowConfigBreadCrumb;
		String value2;
		value2 = value.replace("%s", configName);
		return value2;
	}
	/**********************************************************************************************************
	 * @Objective: activityname based on the inputparameter
	 * @InputParameters: Work Flow Name (eg. ISP Case Processing Workflow)
	 * @OutputParameters: 
	 * @author: rashmi MN 
	 * @Date: 16-Nov-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String workflowName(String workFlowName) {
		String value = Activity_Label;
		String value2;
		value2 = value.replace("%s", workFlowName);
		System.out.println(value2+"------------------------");
		return value2;
	}
	/**********************************************************************************************************
	 * @Objective: To build a locator so to identify activity tree node in WorkFlow edit screen 
	 * @InputParameters: Activate Name (eg. Intake and Assessment)
	 * @OutputParameters: 
	 * @author: Shamanth S 
	 * @Date: 24-Nov-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String selectTransitionActivityNode(String activityName) {
		String value = transitionActivity_Node;
		String value2;
		value2 = value.replace("%s", activityName);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: To build a locator so to identify Rule Name table data in WorkFlow edit screen 
	 * @InputParameters: Activate Name (eg. ISP-V0067)
	 * @OutputParameters: 
	 * @author: Shamanth S 
	 * @Date: 24-Nov-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String selectRuleNameLocator(String ruleName) {
		String value = ruleName_Label;
		String value2;
		value2 = value.replace("%s", ruleName);
		return value2;
	}
	
	/**********************************************************************************************************
	 * @Objective: To build a locator so to identify a Radio Button Label particular to a Rule Name on Save
	 * @InputParameters: Activate Name (eg. ISP-V0067)
	 * @OutputParameters: 
	 * @author: Shamanth S 
	 * @Date: 24-Nov-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String onSaveRadioBtnLable(String ruleName, String eventType) {
		String value = onSave_RadioBtn;
		String value2, value3;
		value2 = value.replace("%eventType%", eventType);
		value3 = value2.replace("%s%", ruleName);
		return value3;
	}
	
		
	/**********************************************************************************************************
	 * @Objective: To build a locator so to identify Warning Radio Button Label particular to a Rule Name on Complete
	 * @InputParameters: Activate Name (eg. ISP-V0067)
	 * @OutputParameters: 
	 * @author: Shamanth S 
	 * @Date: 24-Nov-2020 Updated by and when:
	 **********************************************************************************************************/
	public static String onCompleteRadioBtnLable(String ruleName, String eventType) {
		String value = onComplete_RadioBtn;
		String value2, value3;
		value2 = value.replace("%eventType%", eventType);
		value3 = value2.replace("%s%", ruleName);
		return value3;
	}
}
