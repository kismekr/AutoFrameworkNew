package com.arisglobal.framework.components.lsmv.L10_3;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.LibrariesPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.TherapeuticAreaPageObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Libraries_TherapeuticArea extends ToolManager {
	static String className = Libraries_TherapeuticArea.class.getSimpleName();

	static boolean status;

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit and verify Therapeutic Area.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 21-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyTherapeuticArea(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(TherapeuticAreaPageObjects.edit_Icon);
		agIsVisible(TherapeuticAreaPageObjects.therapeuticArea_Lable);
		agCheckPropertyValue("value", getTestDataCellValue(scenarioName, "TherapeuticArea"),
				TherapeuticAreaPageObjects.therapeuticArea_TxtField);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "Description"),
				TherapeuticAreaPageObjects.description_TextArea);
		agCheckPropertyText(getTestDataCellValue(scenarioName, "TherapeuticKeywords"),
				TherapeuticAreaPageObjects.therapeuticKeywords_Txtarea);
		CommonOperations.takeScreenShot();
		agClick(TherapeuticAreaPageObjects.cancel_Btn);
		agIsVisible(TherapeuticAreaPageObjects.paginator);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Therapeutic Area.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 21-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void search(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agSetStepExecutionDelay("2000");
		agSetValue(TherapeuticAreaPageObjects.keywordSearch_TxtField,
				getTestDataCellValue(scenarioName, "TherapeuticArea"));
		agClick(TherapeuticAreaPageObjects.search_Icon);
		agIsVisible(TherapeuticAreaPageObjects.paginator);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		CommonOperations.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Therapeutic Area.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 21-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreateTherapeuticArea(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		if (verifysearchData(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Therapeutic Area already exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "TherapeuticArea"),
					TherapeuticAreaPageObjects.get_TherapeuticArea);
		} else {
			agClick(TherapeuticAreaPageObjects.new_Btn);
			createTherapeuticArea(scenarioName);
			CommonOperations.setAuditInfo(scenarioName);
			agIsVisible(LibrariesPageObjects.therapeuticAreaKeywordSearch);
			CommonOperations.takeScreenShot();
			search(scenarioName);
			VerifyTherapeuticArea(scenarioName);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Therapeutic Area.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 05-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchAndCreateTherapeuticAreaRecord(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		if (verifysearchData(scenarioName) == true) {
			Reports.ExtentReportLog("", Status.PASS, "Therapeutic Area already exists!", true);
			agCheckPropertyText(getTestDataCellValue(scenarioName, "TherapeuticArea"),
					TherapeuticAreaPageObjects.get_TherapeuticArea);
		} else {
			agClick(TherapeuticAreaPageObjects.new_Btn);
			createTherapeuticArea(scenarioName);
			CommonOperations.setAuditInfo("Create_TherapeuticArea");
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to add Active Moiety
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 23-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static Boolean verifysearchData(String scenarioName) {
		Boolean falg = false;
		String paginator = agGetText(TherapeuticAreaPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			List<WebElement> list = agGetElementList(TherapeuticAreaPageObjects.get_ListofTherapeuticArea);
			String columnHeader = null;
			for (int j = 1; j <= list.size(); j++) {
				columnHeader = agGetText(TherapeuticAreaPageObjects.columnHeaderList(Integer.toString(j)));
				if (getTestDataCellValue(scenarioName, "TherapeuticArea").equalsIgnoreCase(columnHeader)) {
					falg = true;
					break;
				}
			}
		}
		return falg;

	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search Therapeutic Area.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 17-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchTherapeuticArea(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		String paginator = agGetText(TherapeuticAreaPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {

			agCheckPropertyText(getTestDataCellValue(scenarioName, "TherapeuticArea"),
					TherapeuticAreaPageObjects.get_TherapeuticArea);
			Reports.ExtentReportLog("", Status.PASS, "Search Therapeutic Area: Therapeutic Area Listed", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Search Therapeutic Area: Therapeutic Area Not Listed", true);
		}
		// agClick(TherapeuticAreaPageObjects.refresh_Icon);
		agIsVisible(LibrariesPageObjects.therapeuticAreaKeywordSearch);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to search for deleted Therapeutic
	 *             Area.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void searchDeletedTherapeuticArea(String scenarioName) {
		search(scenarioName);
		String paginator = agGetText(TherapeuticAreaPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			Reports.ExtentReportLog("", Status.FAIL,
					"Search for Deleted Therapeutic Area: Deleted Therapeutic Area is listed", true);
		} else {
			Reports.ExtentReportLog("", Status.PASS,
					"Search for Deleted Therapeutic Area: Deleted Therapeutic Area is not listed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete Therapeutic Area.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 21-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void delete(String scenarioName) {
		agClick(TherapeuticAreaPageObjects.delete_Btn);
		CommonOperations.setDeleteAuditInfo(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to delete Therapeutic Area.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 18-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void deleteTherapeuticArea(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		search(scenarioName);
		agWaitTillVisibilityOfElement(TherapeuticAreaPageObjects.paginator);
		String paginator = agGetText(TherapeuticAreaPageObjects.paginator);
		if (paginator != null && paginator.startsWith("1")) {
			agCheckPropertyText(getTestDataCellValue(scenarioName, "TherapeuticArea"),
					TherapeuticAreaPageObjects.get_TherapeuticArea);
			Reports.ExtentReportLog("", Status.PASS, "Therapeutic Area Found", true);
			agClick(TherapeuticAreaPageObjects
					.selectListingCheckbox(getTestDataCellValue(scenarioName, "TherapeuticArea")));
			agIsSelected(TherapeuticAreaPageObjects
					.selectListingCheckbox(getTestDataCellValue(scenarioName, "TherapeuticArea")));
			agSetStepExecutionDelay("5000");
			delete(scenarioName);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Therapeutic Area Not Found", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to edit and update Therapeutic Area.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void updateTherapeuticArea(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agClick(TherapeuticAreaPageObjects.edit_Icon);
		createTherapeuticArea(scenarioName);
		CommonOperations.setAuditInfo(scenarioName);
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to download active moiety export to
	 *             excel.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 18-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void exportToexcel(String FileName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, className);
		agMouseHover(TherapeuticAreaPageObjects.downloadIcon);
		agClick(TherapeuticAreaPageObjects.exporttoExcel_link);
		agWaitTillVisibilityOfElement(TherapeuticAreaPageObjects.export_Btn);
		if (agIsVisible(TherapeuticAreaPageObjects.export_Btn) == true) {
			Reports.ExtentReportLog("", Status.INFO, "Export to excel pop is displayed", true);
			agClick(TherapeuticAreaPageObjects.export_Btn);
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			CommonOperations.move_Downloadedexcel(FileName);
			agClick(TherapeuticAreaPageObjects.exportexcelcancel_Btn);
		} else {
			Reports.ExtentReportLog("", Status.INFO, "Export to excel pop is not displayed", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to compare record count with download
	 *             excel
	 * @InputParameters: filePath
	 * @OutputParameters:
	 * @author:Avinash K
	 * @Date : 31-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void recordCountVerification(String filePath) {
		XlsReader xls = new XlsReader(filePath);
		String count = xls.getCellData("Therapeutic", 2, 4);
		String[] Totalcount = count.split(":");
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in exported excel::" + Totalcount[1].trim(),
				false);
		String applrecordcount = agGetText(TherapeuticAreaPageObjects.paginator);
		String[] data = applrecordcount.split(" ");
		String recordCount = data[4];
		Reports.ExtentReportLog("", Status.INFO, "Total no of Records in application::" + recordCount, false);
		if (recordCount.equalsIgnoreCase(Totalcount[1].trim())) {
			Reports.ExtentReportLog("", Status.PASS, "Record count verification is successfull", true);
		} else {
			Reports.ExtentReportLog("", Status.FAIL, "Record count verification is Unsuccessfull", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to create Therapeutic Area.
	 * @InputParameters: Sceanrio Name
	 * @OutputParameters:
	 * @author:Avinash k
	 * @Date : 21-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createTherapeuticArea(String scenarioName) {
		agAssertVisible(TherapeuticAreaPageObjects.therapeuticArea_Lable);
		agSetValue(TherapeuticAreaPageObjects.therapeuticArea_TxtField,
				getTestDataCellValue(scenarioName, "TherapeuticArea"));
		agSetValue(TherapeuticAreaPageObjects.description_TextArea, getTestDataCellValue(scenarioName, "Description"));
		agSetValue(TherapeuticAreaPageObjects.therapeuticKeywords_Txtarea,
				getTestDataCellValue(scenarioName, "TherapeuticKeywords"));
		CommonOperations.takeScreenShot();
		agClick(TherapeuticAreaPageObjects.save_Btn);
	}
}
