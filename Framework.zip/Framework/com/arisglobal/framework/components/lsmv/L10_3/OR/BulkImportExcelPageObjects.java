package com.arisglobal.framework.components.lsmv.L10_3.OR;


public class BulkImportExcelPageObjects {

	public static String addImportBtn = "xpath#//*[@id='importDataListForm:newId']";
	public static String ImportNameTxt = "xpath#//input[@id='bulkImportDetailForm:importNametxt']";
	public static String templateDropDown = "xpath#//div[@id='bulkImportDetailForm:templateIdList']";
	public static String uploadExcelBtn = "xpath#//input[@id='bulkImportDetailForm:uploadFile_input']";
	public static String saveImportBtn = "xpath#//span[contains(text(),'Save')]";
	public static String templateSelectDD = "xpath#//li[contains(@id,'bulkImportDetailForm:templateIdList') and contains(text(),'%value')]";
	public static String importExcelOkBtn = "xpath#//button[@id='mandatoryDialogform:okButton']";
	public static String importSearchTxt = "xpath#//input[@id='importDataListForm:searchText']";
	public static String importSearch = "xpath#//img[@id='importDataListForm:j_id_nu']";
	public static String importStatus = "xpath#(//label[contains(@id,'importDataListForm:importDataTable:0')])[last()]";
	public static String importRefresh = "xpath#//a[@id='importDataListForm:refresh']";
	public static String editImport = "xpath#//a[@id='importDataListForm:importDataTable:0:editLinkHid']";
	public static String importChkBoxSelect = "xpath#//tbody[@id='importDataListForm:importDataTable_data']//td[1]";
	public static String importSubmitBtn = "xpath#//a[@id='importDataListForm:submitId']";
	public static String totalRowCount = "xpath#//tbody[@id='bulkImportDetailForm:logsDataTable_data']/tr";
	public static String scenarioName = "xpath#//tbody[@id='bulkImportDetailForm:logsDataTable_data']/tr[%row]/td[2]";
	public static String rctNumber = "xpath#//tbody[@id='bulkImportDetailForm:logsDataTable_data']/tr[%row]/td[4]";

	/**********************************************************************************************************
	 * @Objective: The below Method is created to retreive run time value for
	 *             template Dropdown
	 * @UpdatedByAndWhen: Karthikeyan Natarajan, 30-Jul-2020
	 **********************************************************************************************************/
	public static String templateSelect(String runtimeLabel) {
		String value = templateSelectDD;
		String value2 = value.replace("%value", runtimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to retreive run time value of
	 *             scenario name in import
	 * @UpdatedByAndWhen: Karthikeyan Natarajan, 30-Jul-2020
	 **********************************************************************************************************/
	public static String scenarioNameSelect(String runtimeLabel) {
		String value = scenarioName;
		String value2 = value.replace("%row", runtimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: The below Method is created to retreive run time value of rct
	 *             number in import
	 * @UpdatedByAndWhen: Karthikeyan Natarajan, 30-Jul-2020
	 **********************************************************************************************************/
	public static String rctNumSelect(String runtimeLabel) {
		String value = rctNumber;
		String value2 = value.replace("%row", runtimeLabel);
		return value2;
	}

}

