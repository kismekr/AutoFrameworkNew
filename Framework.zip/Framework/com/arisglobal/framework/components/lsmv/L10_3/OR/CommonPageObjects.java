package com.arisglobal.framework.components.lsmv.L10_3.OR;

public abstract class CommonPageObjects {

	public static String menuRightToggle = "xpath#//form[@id='fdeAngularForm']//div[@class='agTreeToggle left']//img";
	public static String validationToggle = "xpath#//form[@id='fdeAngularForm']//div[@class='agTreeToggle right ng-star-inserted mandatoryOpenState']//img";

	public static String applicationLogo = "xpath#//img[contains(@src,'MultiVigilance_logo.png')]";
	public static String menuNavigations = "xpath#//div[@id='headerForm:menuMainId']//ul[@class='ui-menu-list ui-helper-reset']/child::li/a/span[contains(text(),'%s')]/following::ul/li/a/span[contains(text(),'%r')]";
	public static String copyCaseloading = "xpath#//div[@id='adverseEventNew:angularLoader']/label[text()='Loading']";

	public static String searchButton = "xpath#//a[@id='ADL:searchId']/img[contains(@id,'ADL:j_id')]";
	public static String receiptNumberlink = "xpath#//a[@id='ADL:ADT:0:editDeptIdang']";
	public static String moreOptions_caselisting = "xpath#//span[contains(text(),'More Options')]";
	public static String newButton = "xpath#//a[@id='ADL:newId']";
	public static String importXml = "xpath#//div[@id='ADL:xmlfileimport']//input[@id='ADL:xmlfileimport_input']";
	public static String caseListingAssessedcolumn = "xpath#//tbody[@id='ADL:ADT_data']/tr/child::td[@class='width100 caseAttributImageSize assessed']/a";
	public static String caseListinglable = "xpath#//div[@class='CaseList_Label']/div/label[contains(text(),'Case Listings')]";
	public static String listingCheckBox = "xpath#//tbody[@id='ADL:ADT_data']//child::div/span[@class='ui-chkbox-icon ui-icon ui-icon-blank ui-c']";
	public static String deleteLink = "xpath#//div[@class='DeleteLink']/a[@id='ADL:deleteAe']";
	public static String noRecordFound = "xpath#//tbody[@id='ADL:ADT_data']//child::td[text()='No records found.']";
	public static String reAssignButton = "xpath#//a[@id='ADL:reassign']";
	public static String assignToLabel = "xpath#//div[@class='caseAssgnToAe']/label[text()='Assign To']";
	public static String clickAssignToDropDown = "xpath#//input[@id='AEL:caseAssgnTo_focus']/ancestor::div[@class='ui-helper-hidden-accessible']/following-sibling::label";
	public static String setAssignToDropDown = "xpath#//ul[@id='AEL:caseAssgnTo_items']/child::li[contains(text(),";
	public static String activityDropDown = "xpath#//div[contains(@class,'completeActDropDown')]/descendant::select";
	public static String completeActivity = "xpath#//a[text()='Complete Activity']";
	public static String completeActivityExit = "xpath#//a[text()='Complete Activity & Exit']";

	public static String refreshIcon = "xpath#//a[@id='ADL:refreshImage']/label[text()='Refresh']";
	public static String outofWorkflowLink = "xpath#//a[@id='AEL:archiveadvanceSearchID']";

	public static String checkBoxLeftOf = "xpath#(//label[starts-with(normalize-space(text()),'{0}')]/preceding::div[1]/span)[1]";
	public static String checkBoxRightOf = "xpath#//label[starts-with(normalize-space(text()),'{0}')]/following::div[1]/div/span";
	public static String checkBoxUnder = "xpath#//label[starts-with(normalize-space(text()),'{0}')]/../descendant::div[contains(@class,'ui-chkbox-box')]";
	//public static String manualCheckBox = "xpath#(//label[starts-with(normalize-space(text()),'%label%')]/following::label[text()='Manual']/../descendant::span[contains(@class,'ui-chkbox-icon')])[1]";
	public static String manualCheckBox = "xpath#(//label[starts-with(normalize-space(text()),'%label%')]/following::label[text()='Manual']/../descendant::div[contains(@class,'ui-chkbox-box ui-widget ui-corner-all ui-state-default')])[1]";

	
	public static String ManualCheckboxupdated = "xpath#//label[starts-with(normalize-space(text()),'%s')]/descendant::span";
	public static String ChkboxSplit = "xpath#//label[starts-with(normalize-space(text()),'%s')]/parent::div";
	public static String CheckBoxChecked = "xpath#(//label[starts-with(normalize-space(text()),'{0}')]/preceding::div[1]/span[contains(@class,'check')])[1]";
	public static String checkBoxRightOfChecked = "xpath#//label[starts-with(normalize-space(text()),'{0}')]/following::div[1]/div/span[contains(@class,'check')])";
	public static String manualAutopsyCheckbox = "xpath#//label[contains(text(),'Date of Death')]/parent::span/parent::div/parent::div/div[@class='col-md-4 agSkipClear ng-star-inserted']/label[contains(text(),'{0}')]/parent::div/p-checkbox/div[@class='ui-chkbox ui-widget']";
	public static String emailIntakeMsgTopReceiptNo = "xpath#//div[@class='lsmv-grid-row'][1]//div[@fieldid='receiptNo']";
	// Validation Message Page Objects
	public static String validationPopup = "xpath#//label[@id='mandatoryDialogform:mandatoryDatatable:0:cmdinfo']";
	public static String passwrdChangeValPopup = "xpath#//label[@id='changePasswordDialogForm:chngLbl']";

	public static String validaionOk_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']";
	public static String passwrdChangeValPopupOk_Btn = "xpath#//button[@id='changePasswordDialogForm:okButton']";
	public static String deletevalidation_Popup = "xpath#//div[@class='ui-dialog-content ui-widget-content']//span[@class='ui-confirm-dialog-message']";
	public static String deletevalidation_Popup1 = "xpath#//div[@class='ui-dialog-content ui-widget-content']//div/label[@class='ui-outputlabel ui-widget']";
	public static String deletevalidation_popup2 = "xpath#//div[@class='ui-dialog-content ui-widget-content']//div[@class='confmDlgLblBtm']";
	public static String deletePopupYes_Btn = "xpath#//button[contains(@id,'confirmation_yes')]";
	public static String deletePopupYes_Btn1 = "xpath#//button[contains(@id,'partnerForm:confirmation_yes')]";
	public static String deptDeletePopupYes_Btn = "xpath#//button[contains(@id,'deptListform:confirmation_yes')]";
	public static String AccGroupDeletePopupYes_Btn = "xpath#//button[contains(@id,'accountsGroupListForm:confirmation_yes')]";
	public static String substanceDeletePopupYes_Btn = "xpath#//button[contains(@id,'listingForm:confirmation_yes')]";

	// Audit trail Page object
	// public static String auditInfo_Label =
	// "xpath#//span[@id='auditForm:auditDialog_title'][text()='Audit Reason']";
	public static String auditInfo_Label = "xpath#//div[contains(@class,'htmlAuditTrialDailog ')]//span[text()='Audit Reason']";
	// public static String auditreason_Textarea =
	// "xpath#//textarea[@id='auditForm:auditReason']";
	public static String auditreason_Textarea = "xpath#//div[@id='htmlAuditTrialDailog']//textarea[@id='reasonTxt']";
	// public static String submit_Btn =
	// "xpath#//button[@id='auditForm:auditSubmitButton']";
	public static String submit_Btn = "xpath#//button[contains(@onclick,'Submit')]";
	// public static String cancel_Btn =
	// "xpath#//button[contains(@id,'auditForm')]/span[text()='Cancel']";
	public static String cancel_Btn = "xpath#//button[contains(@onclick,'Cancel')]";
	// public static String clickAuditReason_dropdwn =
	// "xpath#//label[@id='auditForm:C-354_label']";
	public static String clickAuditReason_dropdwn = "xpath#//div[@id='htmlAuditTrialDailog']/select[@id='auditTrialCode']";
	public static String clickDeleteAuditReason_dropdwn = "xpath#//label[@id='auditForm:C-9026_label']";
	public static String setDeleteDropdown_Auditreason = "xpath#//ul[@id='auditForm:C-9026_items']/li[contains(text(),'%s')]";
	public static String setDropdown_Auditreason = "xpath#//ul[@id='auditForm:C-354_items']/li[contains(text(),'%s')]";

	public static String CheckBoxsplitCase = "xpath#//label[starts-with(normalize-space(text()),'%s')]/preceding-sibling::input";
	// Toggle Button Form or List
	public static String toggleViewButton = "xpath#//label[text()='%divName%']/ancestor::span[@class='ui-panel-title']/descendant::span[text()='%view%']";

	// Export to
	public static String exportTypeLabel = "xpath#//span[text()='Export To %export%']";

	// Listing screen check box
	public static String listingScreenCheckbox = "xpath#//span[text()='%ss%']/ancestor::tr/td/div/div/span[contains(@class,'ui-icon-blank')]";
	// public static String searchResultSelectRadio =
	// "xpath#//*[text()='%data%']/ancestor::tr/td/div/div/span[contains(@class,'ui-radiobutton-icon')]";
	// public static String searchResultSelectRadio =
	// "xpath#//*[text()='%data%']/ancestor::tr/td/descendant::span[contains(@class,'ui-radiobutton-icon')]";

	public static String searchResultSelectRadio = "xpath#(//*[starts-with(normalize-space(text()),'%data%')]/ancestor::tr/td/descendant::span[contains(@class,'ui-radiobutton-icon')])[1]";
	public static String RadioBtnLatest = "xpath#//label[text()='%radioButtonLabel%']/parent::div/following-sibling::div//label[text()='%radioButtonValue%']/preceding-sibling::div/descendant::span[contains(@class,'ui-radiobutton-icon')]";
	public static String RadioButtonUpdated = "xpath#//label[text()='%radioButtonLabel%']/parent::div[@class='AppRadioButAlign']/following-sibling::div//label[text()='%radioButtonValue%']/preceding-sibling::div/descendant::span[contains(@class,'ui-radiobutton-icon')]";
	public static String selectRadioButton = "xpath#//label[text()='%radioButtonLabel%']/parent::*/descendant::label[text()='%radioButtonValue%']/preceding-sibling::div/descendant::span[contains(@class,'ui-radiobutton-icon')]";
	public static String divAddLink = "xpath#//label[text()='{0}']/ancestor::span[@class='ui-panel-title']/div/a[text()='Add']";
	public static String divDeleteLink = "xpath#//label[text()='{0}']/ancestor::span[@class='ui-panel-title']/div/a[text()='Delete']";

	public static String dropDownListItem = "xpath#//li[text()='{0}'][contains(@id,'{1}')]";
	public static String distributiondropDownListItem = "xpath#//option[text()='{0}']";
	// public static String FDEDropDownListItem =
	// "xpath#//li[contains(@class,'{%loc%}')]/descendant::span[starts-with(text(),'{%val%}')]";
	public static String FDEDropDownListItem = "xpath#//li[contains(@class,'{%loc%}')]/descendant::span[starts-with(normalize-space(text()),'{%val%}')]";

	public static String addButton = "xpath#//label[text()='%divName%']/../descendant::a[text()='Add']";
	public static String deleteButton = "xpath#//label[text()='%divName%']/../descendant::a[text()='Delete']";
	public static String linkText = "xpath#//a[contains(text(),'{0}')]";

	public static String downloadPdf = "xpath#//button[@id='download']";

	// Delete Reason

	// validation message in Data assessment
	public static String validationMsg = "xpath#//span[@class='lsmv-info-message']";
	public static String FUNotificationPOPUP = "xpath#//label[@class='validationDialogSpanSty newDesign_INFO_label']";
	public static String FUNotifictionOKBtn = "xpath#//button[contains(@onclick,'closeValidationDialog()')]";

	public static String blindedUnblindedReportPopUP = "xpath#//div[@id='reportaccessdialog']//parent::div//div[@id='selectdataprivacy']";
	public static String checkMaskedReport = "xpath#//div[@id='selectdataprivacy']//div/div/label[text()='Masked ']/span[@class='customradioIcon']";
	public static String checkBlindedUnblindedReport = "xpath#//div[@id='selectblinded']//div/div/label[text()='Blinded report']/span[@class='customradioIcon']";
	public static String clickGenerateReport = "xpath#//button[@id='generateSummary']";

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the Radio button passing
	 *             value at runtime.
	 * @InputParameters: radioButtonLabel, radioButtonValue
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Naresh
	 * @Date : 07-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectRadioButton(String radioButtonLabel, String radioButtonValue) {
		String resultLocator, result1 = null;
		result1 = selectRadioButton.replace("%radioButtonLabel%", radioButtonLabel);
		resultLocator = result1.replace("%radioButtonValue%", radioButtonValue);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the Radio button passing
	 *             value at runtime.
	 * @InputParameters: radioButtonLabel, radioButtonValue
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Naresh
	 * @Date : 07-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectRadioButtonUpdated(String radioButtonLabel, String radioButtonValue) {
		String resultLocator, result1 = null;
		result1 = RadioButtonUpdated.replace("%radioButtonLabel%", radioButtonLabel);
		resultLocator = result1.replace("%radioButtonValue%", radioButtonValue);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the Radio button passing
	 *             value at runtime.
	 * @InputParameters: radioButtonLabel, radioButtonValue
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Naresh
	 * @Date : 07-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectRadioButtonLatest(String radioButtonLabel, String radioButtonValue) {
		String resultLocator, result1 = null;
		result1 = RadioBtnLatest.replace("%radioButtonLabel%", radioButtonLabel);
		resultLocator = result1.replace("%radioButtonValue%", radioButtonValue);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox in listing
	 *             screen passing value at runtime.
	 * @InputParameters: runTimeLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Naresh
	 * @Date : 04-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectListingCheckbox(String runTimeLabel) {
		String resultLocator;
		resultLocator = listingScreenCheckbox.replace("%ss%", runTimeLabel);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Data which need to be
	 *             selected from Search Result.
	 * @InputParameters: Label Name
	 * @OutputParameters:
	 * @author:Sanchit
	 * @Date : 16-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String searchResultSelectRadio(String data) {
		String value = searchResultSelectRadio.replace("%data%", data.trim());
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the export report type
	 *             passing value at runtime.
	 * @InputParameters: runTimeLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Naresh
	 * @Date : 04-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectExportType(String runTimeLabel) {
		String value = exportTypeLabel.replace("%export%", runTimeLabel);
		return value;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select Audit reason Dropdown value
	 * by passing value at runtime. Input Parameters: runTimeLabel Scenario Name
	 * Output Parameters:
	 * 
	 * @author:Avinash K Date :25-Oct-2019 Updated by and when
	 **********************************************************************************************************/

	public static String setAuditreasonDropdrown(String runTimeLabel) {
		String value = setDropdown_Auditreason;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to select Audit reason Dropdown value
	 * by passing value at runtime. Input Parameters: runTimeLabel Scenario Name
	 * Output Parameters:
	 * 
	 * @author:Avinash K Date :25-Oct-2019 Updated by and when
	 **********************************************************************************************************/

	public static String setDeleteDropdown_Auditreason(String runTimeLabel) {
		String value = setDeleteDropdown_Auditreason;
		String value2;
		value2 = value.replace("%s", runTimeLabel);
		return value2;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox left of
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Naresh
	 * @Date : 25-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String resultLocator = null;

	public static String checkBoxLeftOf(String checkBoxLabel) {
		String actualLocator = checkBoxLeftOf;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox right of
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Naresh
	 * @Date : 25-Oct-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String checkBoxRightOf(String checkBoxLabel) {
		String actualLocator = checkBoxRightOf;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Sanchit
	 * @Date : 2-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String checkBoxUnder(String checkBoxLabel) {
		String actualLocator = checkBoxUnder;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Sanchit
	 * @Date : 2-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String checkBoxChecked(String checkBoxLabel) {
		String actualLocator = CheckBoxChecked;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}
	 
	public static String checkBoxCheckedRight(String checkBoxLabel) {
		String actualLocator =checkBoxRightOfChecked;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}
	/**********************************************************************************************************
	 * @Objective: The below method is created to select the Manual Check Box under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Sanchit
	 * @Date : 5-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String manualCheckBox(String checkBoxLabel) {
		String actualLocator = manualCheckBox;
		resultLocator = actualLocator.replace("%label%", checkBoxLabel.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the Manual Check Box under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:WajahatUmars
	 * @Date : 19-March-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String ManualCheckBoxNew(String checkBoxLabel) {
		String actualLocator = ManualCheckboxupdated;
		resultLocator = actualLocator.replace("%s", checkBoxLabel.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the Manual Check Box under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:WajahatUmars
	 * @Date : 09-Sept-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String ManualCheckBoxSplit(String checkBoxLabel) {
		String actualLocator = ChkboxSplit;
		resultLocator = actualLocator.replace("%s", checkBoxLabel.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click on Add button of specified
	 *             div label passing value at runtime.
	 * @InputParameters: divName
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Naresh
	 * @Date : 13-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String clickAddDivOf(String divName) {
		String actualLocator = divAddLink;
		resultLocator = actualLocator.replace("{0}", divName);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to click on Add button of specified
	 *             div label passing value at runtime.
	 * @InputParameters: divName
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Naresh
	 * @Date : 13-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String clickDeleteDivOf(String divName) {
		String actualLocator = divDeleteLink;
		resultLocator = actualLocator.replace("{0}", divName);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to generate xpath based on locator
	 *             and value to select from dropdown.
	 * @InputParameters: locator, valueToSelect
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Naresh
	 * @Date : 14-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectListDropDown(String locator, String valueToSelect) {
		String xpath[] = locator.split("'");
		String resLocator = xpath[1].replace("_label", "");
		String actualLocator = dropDownListItem;
		String tempLocator = actualLocator.replace("{0}", valueToSelect);
		String resultLocator = tempLocator.replace("{1}", resLocator);
		return resultLocator;
	}

	public static String selectListDropDownUnstructured(String locator, String valueToSelect) {
		String xpath[] = locator.split("-");
		String resLocator = xpath[1];
		String actualLocator = dropDownListItem;
		String tempLocator = actualLocator.replace("{0}", valueToSelect);
		String resultLocator = tempLocator.replace("{1}", resLocator);
		return resultLocator;
	}
	public static String selectDistributionListDropDown(String locator, String valueToSelect) {
		String actualLocator = distributiondropDownListItem;
		String resultLocator = actualLocator.replace("{0}", valueToSelect);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select Form or List View in Div
	 *             during runtime.
	 * @InputParameters: runTimeLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Sanchit
	 * @Date : 18-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String toggleViewButton(String divName, String viewButton) {
		String resultLocator;
		resultLocator = toggleViewButton.replace("%divName%", divName);
		resultLocator = resultLocator.replace("%view%", viewButton);
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to generate xpath based on locator
	 *             and value to select for FDE screen dropdown.
	 * @InputParameters: classValue, valueToSelect
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Naresh
	 * @Date : 22-Nov-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String selectFDEDropDown(String classValue, String valueToSelect) {
		String actualLocator = FDEDropDownListItem;
		String tempLocator = actualLocator.replace("{%loc%}", classValue);
		String resultLocator = tempLocator.replace("{%val%}", valueToSelect.trim());
		return resultLocator;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to generate xpath based on locator
	 *             and value to select for FDE screen dropdown.
	 * @InputParameters: classValue, valueToSelect
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Sanchit
	 * @Date : 04-Dec-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String verifyFDEDropDown(String classValue, String valueToSelect) {
		String actualLocator = FDEDropDownListItem;
		String tempLocator = actualLocator.replace("{%loc%}", classValue);
		String resultLocator = tempLocator.replace("{%val%}", valueToSelect.trim());
		String verifyresultLocator = resultLocator.replaceFirst("li", "label");
		return verifyresultLocator;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click on Add Button for specified
	 * Div. Input Parameters: Div Name Parameters:
	 * 
	 * @author:Sanchit Date :27-Nov-2019 Updated by and when
	 **********************************************************************************************************/
	public static String clickAddButton(String divName) {
		String value = addButton;
		String value2 = value.replace("%divName%", divName);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click on Delete Button for specified
	 * Div. Input Parameters: Div Name Parameters:
	 * 
	 * @author:Sanchit Date :27-Nov-2019 Updated by and when
	 **********************************************************************************************************/
	public static String clickDeleteButton(String divName) {
		String value = deleteButton;
		String value2 = value.replace("%divName%", divName);
		return value2;
	}

	/**********************************************************************************************************
	 * Objective:The below method is created to click on link Input Parameters:
	 * Value Parameters:
	 * 
	 * @author:Mythri Jain Date :02-Jan-2020 Updated by and when
	 **********************************************************************************************************/

	public static String linkText(String value) {
		String actualValue = linkText;
		String result = actualValue.replace("{0}", value);
		return result;
	}

	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Yashwanth Naidu
	 * @Date : 1-April-2020
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String checkAutopsyManual(String checkBoxLabel) {
		String actualLocator = manualAutopsyCheckbox;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}
	
	public static String warnings = "xpath#//tbody/tr/td/label[contains(.,'WARNING')]";
	public static String warningsCount = "xpath#//tbody/tr/td/label[contains(.,'WARNING')]/following-sibling::label";
	public static String ErrorCount = "xpath#//tbody/tr/td/label[contains(.,'ERROR')]/following-sibling::label";
	public static String Errors = "xpath#//tbody/tr/td/label[contains(.,'ERROR')]";

	public static String data(int rowNum) {
		return "xpath#//tbody[@id='mandatoryDialogform:mandatoryDatatable_data']/tr[" + rowNum
				+ "]/td/label[contains(@id,'cmdinfo')]";
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Abhisek Ghosh
	 * @Date : 19-Feb-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String manualCheckBoxSelection = "xpath#(//label[starts-with(normalize-space(text()),'{0}')]/parent::span/parent::div/following-sibling::div/label[contains(text(), 'Manual')])[1]/parent::div//p-checkbox/div/div[2]";
	
	
	public static String manualCheckBoxSelection(String checkBoxLabel) {
		String actualLocator = manualCheckBoxSelection;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}
	
	
	public static String manualCheckBoxClick = "xpath#(//label[starts-with(normalize-space(text()),'{0}')]/parent::span/parent::div/following-sibling::div/label[contains(text(), 'Manual')])[1]/parent::div//p-checkbox/div/div[2]/span";
	
	
	public static String manualCheckBoxClick(String checkBoxLabel) {
		String actualLocator = manualCheckBoxClick;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}
	
	//public static String collapse_icon = "xpath#//*[@id='fdeAngularForm']/div/div[2]/img";
	public static String collapse_icon = "xpath#//*[@id='fdeAngularForm']/div/div[2]";
	public static String mainForm_Header = "xpath#//div[contains(@class,'MainBoxDiv')]";
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Abhisek Ghosh
	 * @Date : 1-March-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String LibrariesStudyList_checkbox = "xpath#//label[text()='{0}']/ancestor::tr/td/div/div/span[contains(@class,'ui-icon-blank')]";
	
	public static String checkLibrariesStudyList(String checkBoxLabel) {
		String actualLocator = LibrariesStudyList_checkbox;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to select the checkbox under
	 *             specified label passing value at runtime.
	 * @InputParameters: checkBoxLabel
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Abhisek Ghosh
	 * @Date : 1-March-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String companyUnitList_checkbox = "xpath#//td[text()='{0}']/ancestor::tr/td/div/div/span[contains(@class,'ui-icon-blank')]";
	
	public static String checkCompanyUnitList(String checkBoxLabel) {
		String actualLocator = companyUnitList_checkbox;
		resultLocator = actualLocator.replace("{0}", checkBoxLabel.trim());
		return resultLocator;
	}	
	
	public static String activityLabel = "xpath#//label[@id='adverseEventNew:workflowId'][text()='{0}']";
	
	/**********************************************************************************************************
	 * @Objective: The below method is created to verify the activity label by passing label text at runtime.
	 * @InputParameters: activityLabelText
	 * @OutputParameters: Return's dynamic xpath
	 * @author:Praveen Patil
	 * @Date : 9-March-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String getActivityLabel(String activityLabelText) {
		String actualActivityLabel = activityLabel;
		resultLocator = actualActivityLabel.replace("{0}", activityLabelText);
		return resultLocator;
	}
	
}