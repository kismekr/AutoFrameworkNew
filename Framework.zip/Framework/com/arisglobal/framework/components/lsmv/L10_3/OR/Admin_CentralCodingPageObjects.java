package com.arisglobal.framework.components.lsmv.L10_3.OR;

public class Admin_CentralCodingPageObjects {

	public static String codingMatchOrder_Label = "xpath#//label[text()='Coding Match Order']";
	public static String codingMatchOrder_RadioBtn = "xpath#//label[contains(text(),'Coding Match Order')]/ancestor::div//table//label[text()='%s']/ancestor::td/div";
	public static String medDRAVersioninuse_Drpdown = "xpath#// div[@id='applicationParameterForm:orderByDisplayOrder_A1-5073']";
	public static String save_Btn = "xpath#//button[@id='applicationParameterForm:visibleSave']/span";
	public static String ok_Btn = "xpath#//button[@id='mandatoryDialogform:okButton']/span";
	
	 /**********************************************************************************************************
		 *@ Objective:The below method is created to set radio button by passing lable name at runtime. 
		 *@Input Parameters:
		 *@Parameters:
		 * @author:Avinash k Date :28-Dec-2019 
		 **********************************************************************************************************/
		public static String setcodingMatchOrder(String runTimeLabel) {
			String value = codingMatchOrder_RadioBtn;
			String value2;
			value2 = value.replace("%s", runTimeLabel);
			return value2;
		}
	 
	
		
	
	
	
	
}
