package com.arisglobal.framework.components.lsmv.L10_3;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsmv.L10_3.OR.AdministrationDepartmentPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.DictionaryCodingBrowser_LookupPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.DictonaryBrowserObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.GlossaryOfTermsPageObjects;
import com.arisglobal.framework.components.lsmv.L10_3.OR.SubmissionPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsmvConfig.lsmvConstants;
import com.aventstack.extentreports.Status;

public class Libraries_DictonaryBrowser extends ToolManager {
	
	static String className = Libraries_DictonaryBrowser.class.getSimpleName();
	
	/********************************************************************************************************
	 * @Objective: The below method is created to search SMQ Term.
	 * @InputParameters: Scenario Name
	 * @OutputParameters:
	 * @author:Abhisek Ghosh
	 * @Date : 24-Oct-2021
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/

	public static void searchSMQCMQTerm(String scenarioName) {
		Multimaplibraries.getTestData(lsmvConstants.LSMV_testData, "ProductsOperations");
		
		String value="";
		String smqcmqTerm= "";
		
		String Label= getTestDataCellValue(scenarioName, "labelingSMQorCMQ");
		
		String medraVersion= getTestDataCellValue(scenarioName, "MedraVersion");
		agClick(DictonaryBrowserObjects.viewVersionDropdown);
		agClick(DictonaryBrowserObjects.setLabelDropdown(medraVersion));
		
		agClick(DictonaryBrowserObjects.viewModeDropdown);
		agClick(DictonaryBrowserObjects.setLabelDropdown(Label));
		agClick(DictonaryBrowserObjects.searchBtn);
		
		agWaitTillVisibilityOfElement(DictonaryBrowserObjects.searchResult);
		
		List<WebElement> resultCount = agGetElementList(DictonaryBrowserObjects.listOfResult);
		System.out.println(resultCount.size());
		
		for (int i = 0; i < resultCount.size(); i++) {
			//agSetStepExecutionDelay("2000");
			boolean k= false;
			
			smqcmqTerm = agGetText(DictonaryBrowserObjects.smqcmqText(Integer.toString(i + 1)));
			agJavaScriptExecuctorClick(DictonaryBrowserObjects.getTerms(Integer.toString(i + 1)));
			
			List<WebElement> childCount = agGetElementList(DictonaryBrowserObjects.getchildCount(Integer.toString(i + 1)));
			System.out.println(childCount.size());
			
			for (int j = 0; j < childCount.size(); j++) {
				
				//agJavaScriptExecuctorClick(DictonaryBrowserObjects.getPTterm(Integer.toString(i + 1), Integer.toString(j + 1)));
				
				value=agGetText(DictonaryBrowserObjects.getPTterm(Integer.toString(i + 1), Integer.toString(j + 1)));
				System.out.println(value);
				
				if(value.contains("(PT)"))
				{
					Reports.ExtentReportLog("", Status.INFO, "PT Term Extracted", true);
					
					String a1[]=value.split("(PT)");
					String value2= a1[0];
					String fval=value2.replace("(", "");
					//fval.trim();
					
					System.out.println(fval);
					
					String smqcmqTerm1=smqcmqTerm.replace("(", "#");
					String t1[]=smqcmqTerm1.split("#");
					String smqcmqTermFinal= t1[0];
					//String t1[]=smqcmqTerm.split("(SMQ)");
					//String value2= a1[0];
					//String fval=value2.replace("(", "");
					//smqcmqTermFinal.trim();
					
					
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "ProductsOperations", scenarioName, "labelingSMQorCMQNames", smqcmqTermFinal.trim());
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "FDE_Events", scenarioName, "Events_EventInformation_ReportedTerm", fval.trim());
					XlsReader.writeToTestData(lsmvConstants.LSMV_testData, "FDE_Labelling", scenarioName, "ReportedTerm", fval.trim());
					
					
					k=true;
				}
				
				break;		
			}
			
			if(k) {
				break;
			}	
		}
		
		agCloseCurrentWindow();
		agGetWindowControlByInstance(1);

	}
	
}
