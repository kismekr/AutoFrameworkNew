package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.OutboundGeneralObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DateOperations;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.framework.lib.utils.generic.DateOperations.dateFormat;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class OutboundGeneral extends ToolManager {

	static String className = OutboundGeneral.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Enter HQ Instructions.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 16-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setHQInstructionDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agSetValue(OutboundGeneralObjects.submissionDueDateTextbox,
				DateOperations.getDateByInputData(dateFormat.ddMMMyyyy, Multimaplibraries.getTestDataCellValue(scenarioName, "Submission Due Date")));
		agSetValue(OutboundGeneralObjects.ownerUnitTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Owner Unit"));
		agSetValue(OutboundGeneralObjects.ownerTextbox, Multimaplibraries.getTestDataCellValue(scenarioName, "Owner"));
		agSetValue(OutboundGeneralObjects.commentsTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Comments"));
		String fileName = Multimaplibraries.getTestDataCellValue(scenarioName, "Template Name");
		if (!fileName.trim().equalsIgnoreCase("#skip#")) {
			agSetValue(OutboundGeneralObjects.templateUploadBtn, lsitstConstants.LSITST_FileUploadPath + fileName);
		}
		Reports.ExtentReportLog("Add HQ Instructions", Status.INFO, "", true);
	}

	/**********************************************************************************************************
	 * @Objective: Enter Email Details.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 16-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setEmailDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agSetValue(OutboundGeneralObjects.emailSubTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Email Subject"));
		agSetValue(OutboundGeneralObjects.emailMsgTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Email Body"));
		Reports.ExtentReportLog("Add Email Details", Status.INFO, "", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify Documents in General tab.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 16-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyARISgDocuments(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String[] multipleSupportingDocs = Multimaplibraries.getTestDataCellValue(scenarioName, "ARISg Document")
				.split(",");
		if (multipleSupportingDocs.length == 0) {
			agX_Common.verifyDataList(OutboundGeneralObjects.arisgDocTable, multipleSupportingDocs.toString());
		} else {
			for (int i = 0; i < multipleSupportingDocs.length; i++) {
				agX_Common.verifyDataList(OutboundGeneralObjects.arisgDocTable, multipleSupportingDocs[i]);
			}
		}
		Reports.ExtentReportLog("Documents", Status.INFO, "ARISg Documents Attached", true);
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
}
