package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.MessageAuditTrailObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DateOperations;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.framework.lib.utils.generic.DateOperations.dateFormat;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class MessageAuditTrail extends ToolManager {

	static String className = MessageAuditTrail.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Enter Message Audit Trail details.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 01-Oct-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setMessageAuditTrailCriteria(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agX_Common.selectLabelDropdown(MessageAuditTrailObjects.messageTypeDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Message Type"));
		agSetValue(MessageAuditTrailObjects.sessionIDTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Session ID"));
		// Dates need's be handled here
		
		agSetValue(MessageAuditTrailObjects.auditTrailFromDate, DateOperations.getDateByInputData(dateFormat.ddMMMyyyy, Multimaplibraries.getTestDataCellValue(scenarioName, "From Date")));
		
		agSetValue(MessageAuditTrailObjects.auditTrailToDate, DateOperations.getDateByInputData(dateFormat.ddMMMyyyy, Multimaplibraries.getTestDataCellValue(scenarioName, "To Date")));

		
		
		agSetValue(MessageAuditTrailObjects.receiptNoTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Receipt Number"));
		agSetValue(MessageAuditTrailObjects.lrnNoTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "LRN Number"));
		agSetValue(MessageAuditTrailObjects.aerNoTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "AER Number"));
		agSetValue(MessageAuditTrailObjects.trackingNoTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Tracking Number"));
		agSetValue(MessageAuditTrailObjects.messageNoTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Message Number"));
		agSetValue(MessageAuditTrailObjects.userIDTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "User ID"));
		agX_Common.selectLabelDropdown(MessageAuditTrailObjects.operationTypeDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Operation Type"));
		agSetValue(MessageAuditTrailObjects.reasonTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Reason"));
		Reports.ExtentReportLog("Message Audit Trail Data", Status.INFO, "", true);
		agClick(MessageAuditTrailObjects.generatePvtRepButton);
		agAssertVisible(MessageAuditTrailObjects.fieldUpdatesLabel);
		agX_Common.takeScreenShot();
		// agClick(MessageAuditTrailObjects.backButton);
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

}
