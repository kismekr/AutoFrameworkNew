package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.OutboundListingObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class OutboundListing extends ToolManager {

	static String className = OutboundListing.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Search Outbound Listing case.
	 * @Input Parameters: scenarioName, columnName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 16-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void outboundListingSearchCase(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String aerNumber = Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
		for (int i = 0; i <= lsitstConstants.maxIterateCount; i++) {
			agJavaScriptExecuctorSendKeys(OutboundListingObjects.outboundSearchTextbox, aerNumber);
			agClick(OutboundListingObjects.outboundSearchButton);
			agX_Common.waitTillLoading();
			agSetGlobalTimeOut("5");
			boolean message = agIsVisible(CommonObjects.searchResultsDataRow);
			System.out.println("msg" + message);
			agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
			if (!message) {
				try {
					System.out.println("Waiting");
					Thread.sleep(10000);
				} catch (InterruptedException e) {
				}
			} else {
				agJavaScriptExecuctorScrollToElement(OutboundListingObjects.aerNoLink);
				agCheckPropertyText(aerNumber, OutboundListingObjects.aerNoLink);
				Reports.ExtentReportLog("Outbound Listing Case Search", Status.PASS,
						"Case with number '" + aerNumber + "' is available", true);
				break;
			}
			if (i == lsitstConstants.maxIterateCount) {
				Reports.ExtentReportLog("Outbound Listing Case Search Failed", Status.FAIL,
						"Case with number '" + aerNumber + "'  not available", true);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: Get Receipt Number.
	 * @Input Parameters: NA
	 * @Output Parameters: Return Receipt Number
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getOutboundManualCase() {
		String appMsg = null;
		appMsg = agGetText(CommonObjects.applicationMessage);
		String[] resultText1 = appMsg.split("'");
		String[] resultText2 = resultText1[1].split("'");

		agClick(CommonObjects.applicationMessageClose);
		System.out.println("RCT" + resultText2[0]);
		return resultText2[0];
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	/**********************************************************************************************************
	 * @Objective: Click and Select E2B Views in Listing Screen
	 * @Input Parameters: NA
	 * @Output Parameters: NA
	 * @author: Sanchit
	 * @throws InterruptedException
	 * @Date : 25-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void selectOutboundE2BViews(String e2bFormat) {
		agClick(OutboundListingObjects.e2bLink);
		agX_Common.selectE2BViews(e2bFormat, false, "#skip#", "#skip#");
	}

}
