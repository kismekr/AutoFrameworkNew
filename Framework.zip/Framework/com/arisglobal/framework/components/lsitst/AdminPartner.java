package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.agX_Common.menuName;
import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.PartnersPageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.lsitstConfig.lsitstConstants;

public class AdminPartner extends ToolManager {
	static String className = AdminPartner.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: To Delete Specified Gateway Transport settings.
	 * @Input Parameters: Scenario Name
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 03-October-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void deleteTransportSettings(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agX_Common.agX_Navigations(menuName.administrator);
		agX_Common.agX_Navigations(menuName.partners);
		boolean searchResults = agX_Common
				.basicSearch(Multimaplibraries.getTestDataCellValue(scenarioName, "Partner Name"));
		if (searchResults == true) {
			agClick(CommonObjects.editIcon);
			// agX_Common.editRecord();
			agX_Common.takeScreenShot();
			if (Multimaplibraries.getTestDataCellValue(scenarioName, "Transport Type").equalsIgnoreCase("Inbound")) {
				agX_Common.clickCheckBox(Multimaplibraries.getTestDataCellValue(scenarioName, "Transport Name"),
						"true");
				agClick(PartnersPageObjects.removeInboundButton);
				agAssertContainsText(CommonObjects.applicationMessage, "successfully");
				agClick(PartnersPageObjects.saveButton);
			} else if (Multimaplibraries.getTestDataCellValue(scenarioName, "Transport Type")
					.equalsIgnoreCase("Outbound")) {
			}
			{
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: To add Gateway Transport settings in the specified partner.
	 * @Input Parameters: Scenario Name
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 03-October-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void addTransportSettings(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agX_Common.agX_Navigations(menuName.administrator);
		agX_Common.agX_Navigations(menuName.partners);
		boolean searchResults = agX_Common
				.basicSearch(Multimaplibraries.getTestDataCellValue(scenarioName, "Partner Name"));
		if (searchResults == true) {
			// agX_Common.editRecord();
			agClick(CommonObjects.editIcon);
			agX_Common.takeScreenShot();
			if (Multimaplibraries.getTestDataCellValue(scenarioName, "Transport Type").equalsIgnoreCase("Inbound")) {
				agClick(PartnersPageObjects.addInboundButton);
				agSetValue(PartnersPageObjects.nameTextbox,
						Multimaplibraries.getTestDataCellValue(scenarioName, "Transport Name"));
				agX_Common.selectLabelDropdown(PartnersPageObjects.mediumDropdown,
						Multimaplibraries.getTestDataCellValue(scenarioName, "Medium"));
				agSetValue(PartnersPageObjects.partnerIDTextbox,
						Multimaplibraries.getTestDataCellValue(scenarioName, "Partner ID"));
				agSetValue(PartnersPageObjects.receiverIDTextbox,
						Multimaplibraries.getTestDataCellValue(scenarioName, "Receiver ID"));
				agX_Common.takeScreenShot();
				agClick(PartnersPageObjects.addButton);
				agClick(PartnersPageObjects.saveButton);
			}
		}
	}
}
