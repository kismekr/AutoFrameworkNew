package com.arisglobal.framework.components.lsitst;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsitst.OR.HomePageObjects;
import com.arisglobal.framework.components.lsitst.OR.LoginObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class LSITST_Login extends ToolManager {

	public static WebElement webElement;
	static String loginWindow = null;
	static String className = LSITST_Login.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Login to LSITST application.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void login(String scenarioName) {
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		// if (!agCheckWindowExists("ARISg")) {
		if (!agCheckWindowExists("ARISg") || (agCheckWindowExists("ARISg7 Administrator"))) {
			agNavigate(Multimaplibraries.getTestDataCellValue(scenarioName, "URL"));
		}

		agGetCurrentWindow();
		agSetValue(LoginObjects.userNameTextbox, Multimaplibraries.getTestDataCellValue(scenarioName, "UserName"));
		agSetValue(LoginObjects.passwordTextbox, Multimaplibraries.getTestDataCellValue(scenarioName, "Password"));
		agSelectByVisibleText(LoginObjects.databaseDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "DB"));
		Reports.ExtentReportLog("Login Screen", Status.INFO,
				"User Name : " + Multimaplibraries.getTestDataCellValue(scenarioName, "UserName") + ", Database : "
						+ Multimaplibraries.getTestDataCellValue(scenarioName, "DB"),
				true);
		if (scenarioName.contains("agXchange")) {
			agMouseHover(LoginObjects.loginDropdown);
			agClick(LoginObjects.agxchangeLoginButton);
			agGetCurrentWindow();
			agSetGlobalTimeOut("0");
			if (!agIsVisible(HomePageObjects.homePageLogo)) {
				if (agIsVisible(LoginObjects.agxchangeContinueLoginText)) {
					agClick(LoginObjects.agxchangeContinueLoginButton);
				}
			}
			agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
			agSetStepExecutionDelay("0");
			agAssertVisible(HomePageObjects.logoutIcon);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalTimeOut));
			Constants.driver.manage().window().maximize();
		}
		if (agIsVisible(HomePageObjects.logoutIcon)) {
			Reports.ExtentReportLog("Login Successfull", Status.INFO,
					"User Name : " + Multimaplibraries.getTestDataCellValue(scenarioName, "UserName") + ", Database : "
							+ Multimaplibraries.getTestDataCellValue(scenarioName, "DB"),
					true);
		} else {
			Reports.ExtentReportLog("Login Failed", Status.INFO,
					"User Name : " + Multimaplibraries.getTestDataCellValue(scenarioName, "UserName") + ", Database : "
							+ Multimaplibraries.getTestDataCellValue(scenarioName, "DB"),
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
}
