package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.HomePageObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundListingObjects;
import com.arisglobal.framework.components.lsitst.OR.LoginObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.aventstack.extentreports.Status;

public class LSITST_HomePage extends ToolManager {
	/**********************************************************************************************************
	 * @Objective: Logout from LSITST application.
	 * @Input Parameters: NA
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void logout() {
		agClick(HomePageObjects.logoutIcon);
		agGetCurrentWindow();
		agSetGlobalTimeOut("0");
		agAssertVisible(LoginObjects.userNameTextbox);
		boolean status = agIsVisible(LoginObjects.userNameTextbox);
		if (status) {
			Reports.ExtentReportLog("LSITST Logout", Status.PASS, "Application Logout Successful", true);
		} else {
			Reports.ExtentReportLog("LSITST Logout", Status.FAIL, "Application Logout Unsuccessful", true);
		}
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
	}
	/**********************************************************************************************************
	 * @Objective: for viewing unread mails
	 * @Input Parameters: NA
	 * @Output Parameters: NA
	 * @author: Vamsi krishna RS
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/	
	public static void clickUnread() {
		agClick(HomePageObjects.unreadLink);
	}
	/**********************************************************************************************************
	 * @Objective:This method is used for navigating homepage from other screen
	 * @Input Parameters: NA
	 * @Output Parameters: NA
	 * @author: Vamsi krishna RS
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/	
	public static void navigateTohomepage() {
		agClick(HomePageObjects.irthompage);
	}

}
