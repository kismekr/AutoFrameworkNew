package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundEventObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DateOperations;
import com.arisglobal.framework.lib.utils.generic.DateOperations.dateFormat;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class EventTab extends ToolManager {

	static String className = EventTab.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Enter Event information.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setEventInfo(String scenarioName, int noOfExtraRecords) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String multiScenario;
		for (int i = 1; i <= noOfExtraRecords; i++) {
			if (noOfExtraRecords == 1) {
				multiScenario = scenarioName;
			} else {
				multiScenario = scenarioName + i;
			}
			agSetValue(InboundEventObjects.reportedTermTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Reported Term"));
			agClick(InboundEventObjects
					.reporterHighRdoBtn(Multimaplibraries.getTestDataCellValue(multiScenario, "Reporter Highlighted")));
			agSetValue(InboundEventObjects.onsetDateTextbox, DateOperations.getDateByInputData(dateFormat.ddMMMyyyy,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Onset Date")));
			agSetValue(InboundEventObjects.cessationDateTextbox, DateOperations.getDateByInputData(dateFormat.ddMMMyyyy,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Cessation Date")));
			agX_Common.selectLabelDropdown(InboundEventObjects.outcomeDropdown,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Outcome"));
			agClick(InboundEventObjects.companySeriousnessRdoBtn(
					Multimaplibraries.getTestDataCellValue(multiScenario, "Reporter Seriousness")));
			agClick(InboundEventObjects.companySeriousnessRdoBtn(
					Multimaplibraries.getTestDataCellValue(multiScenario, "Company Seriousness")));
			String seriousnessCriteria = Multimaplibraries.getTestDataCellValue(multiScenario, "Seriousness Criteria");
			String[] seriousnessCriteriaResult = seriousnessCriteria.split(",");
			if (seriousnessCriteriaResult.length == 0) {
				agX_Common.clickCheckBoxLeftOf(seriousnessCriteriaResult[0], "true");
			} else {
				for (int j = 0; j < seriousnessCriteriaResult.length; j++) {
					agX_Common.clickCheckBoxLeftOf(seriousnessCriteriaResult[j], "true");
				}
			}
			Reports.ExtentReportLog("Event tab data", Status.INFO, "Added Event information", false);
			agX_Common.takeScreenShot(CommonObjects.labelText("Event"));
			if (i != noOfExtraRecords) {
				agX_Common.formRecordNavigation("Event", "Next Record");
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verify Event information.
	 * @Input Parameters: scenarioName, noOfExtraRecords.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 10-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyEventInfo(String scenarioName, int noOfExtraRecords) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String multiScenario;
		for (int i = 1; i <= noOfExtraRecords; i++) {
			if (noOfExtraRecords == 1) {
				multiScenario = scenarioName;
			} else {
				multiScenario = scenarioName + i;
			}
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Reported Term"),
					InboundEventObjects.reportedTermTextbox);
			agX_Common.verifyRadioButton(InboundEventObjects.reporterHighRdoBtn(Multimaplibraries.getTestDataCellValue(multiScenario, "Reporter Highlighted")));
			agX_Common.takeScreenShot(CommonObjects.labelText("Event"));
			if (i != noOfExtraRecords) {
				agX_Common.formRecordNavigation("Event", "Next Record");
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
}
