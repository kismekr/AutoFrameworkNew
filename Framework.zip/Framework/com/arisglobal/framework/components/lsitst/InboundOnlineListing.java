package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.HeaderObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundOnlineListingObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class InboundOnlineListing extends ToolManager {

	static String className = InboundOnlineListing.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Edit Online Case.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void editCase(String scenarioName, String columnName) {
		String caseNumber = InboundOnlineEntryCommon.getData(scenarioName, columnName);
		if (agGetText(InboundOnlineListingObjects.atnNumberLabel).equals(caseNumber)) {
			if (agIsVisible(InboundOnlineListingObjects.editIcon)) {
				agClick(InboundOnlineListingObjects.editIcon);
			}
			agAssertVisible(HeaderObjects.cancelButton);
		} else {
			Reports.ExtentReportLog("Case Number mismatch", Status.FAIL, caseNumber + " - is not available for edit",
					true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Search Online Listing Case.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void searchOnlineListingCase(String scenarioName, String columnName) {
		// Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		// String receiptNumber = Multimaplibraries.getTestDataCellValue(scenarioName,
		// columnName);
		agJavaScriptExecuctorSendKeys(InboundOnlineListingObjects.searchTextbox,
				InboundOnlineEntryCommon.getData(scenarioName, columnName));
		agClick(InboundOnlineListingObjects.searchIcon);
		// for (int i = 0; i <= maxCount; i++) {
		// agJavaScriptExecuctorSendKeys(InboundOnlineObjects.onlineListingSearchTextbox,
		// Multimaplibraries.getTestDataCellValue(scenarioName, columnName));
		// agClick(InboundOnlineObjects.onlineListingSearchIcon);
		// agSetStepExecutionDelay("15000");
		// if (agIsVisible(InboundOnlineObjects.onlineEditIcon)) {
		// Common.agAssertEqual(agGetText(InboundOnlineObjects.atnNumber),
		// receiptNumber);
		// Reports.ExtentReportLog("Case Search", Status.PASS, "", true);
		// } else {
		// try {
		// Thread.sleep(10000);
		// } catch (InterruptedException e) {
		// }
		// }
		// agSetStepExecutionDelay("1000");
		// if (i == maxCount) {
		// Reports.ExtentReportLog("Case Search Failed", Status.FAIL,
		// "Case with number " + receiptNumber + " is not available", true);
		// }
		// }
	}

	/**********************************************************************************************************
	 * @Objective: Get Receipt Number.
	 * @Input Parameters: NA
	 * @Output Parameters: Return Receipt Number.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getATNNumber() {
		String receiptNo = null;
		String appMsg = null;
		appMsg = agGetText(CommonObjects.applicationMessage);
		String[] resultText = appMsg.split("'");
		receiptNo = resultText[1];
		agClick(CommonObjects.applicationMessageClose);
		return receiptNo;
	}

	/*
	 * public static void downloadOnlinePDFFile() {
	 * agClick("xpath#//img[@title='View PDF']"); agGetCurrentWindow();
	 * agClick("xpath#//*[@id='download']"); }
	 */

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
}
