package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundNewE2BCaseEntryObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class InboundNewE2BCaseEntry extends ToolManager {
	static String className = InboundNewE2BCaseEntry.class.getSimpleName();

	public static void createNewE2BCase(String scenarioName) {
		String fileName = LSITST_FileOperations.getData(scenarioName, "FileName");
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agClick(CommonObjects.radioButton(Multimaplibraries.getTestDataCellValue(scenarioName, "E2B File Format")));
		agSetValue(InboundNewE2BCaseEntryObjects.sourceDocUploadButton,
				lsitstConstants.LSITST_FileUploadPath + fileName);
		agAssertVisible(CommonObjects.linkText(LSITST_FileOperations.getData(scenarioName, "FileName")));
		Reports.ExtentReportLog("E2B Case", Status.INFO, "E2B Case Data", true);
		agClick(InboundNewE2BCaseEntryObjects.createReceiptItemButton);
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
}
