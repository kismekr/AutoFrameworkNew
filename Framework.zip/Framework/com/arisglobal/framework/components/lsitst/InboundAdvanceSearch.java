package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.agX_Common.linkText;
import com.arisglobal.framework.components.lsitst.OR.InboundAdvancedSearchObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;

public class InboundAdvanceSearch extends ToolManager {

	static String className = InboundAdvanceSearch.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: To enter Inbound advance search general details.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 06-09-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setGeneralData(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agSetValue(InboundAdvancedSearchObjects.receiptNumberTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Receipt Number"));
		agSetValue(InboundAdvancedSearchObjects.senderTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Sender"));
		agSetValue(InboundAdvancedSearchObjects.receiverTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Receiver"));
		agSetValue(InboundAdvancedSearchObjects.lrnNumberTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "LRN"));
		agSetValue(InboundAdvancedSearchObjects.aerNumberTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "AER"));
		agSetValue(InboundAdvancedSearchObjects.productDescriptionTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Product Description"));
		agSetValue(InboundAdvancedSearchObjects.reporterTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Reporter"));
		agX_Common.selectLabelDropdown(InboundAdvancedSearchObjects.reporterCountryDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Reporter Country"));
		agX_Common.selectLabelDropdown(InboundAdvancedSearchObjects.primarySourceCountryDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Primary Source Country"));
		agX_Common.selectLabelDropdown(InboundAdvancedSearchObjects.sourceMediumDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Source Medium"));
		agX_Common.selectLabelDropdown(InboundAdvancedSearchObjects.statusDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Status"));
	}

	/**********************************************************************************************************
	 * @Objective: To perform Inbound advance search when case is getting processed.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 06-09-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void advanceSearchWaitForCase(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		for (int i = 0; i <= 10; i++) {
			agX_Common.clickLink(linkText.advanceSearch);
			InboundAdvanceSearch.setGeneralData(scenarioName);
			if (agX_Common.buttonOperation("Search") == true) {
				break;
			}
		}
	}
	
	public static void SearchEmailForCase(String scenarioName) 
	{
		agX_Common.clickLink(linkText.advanceSearch);
		setEmailSearchData(scenarioName);
		agX_Common.buttonOperation("Search");

	}
	
	public static void setEmailSearchData(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agJavaScriptExecuctorScrollToElement(InboundAdvancedSearchObjects.emailTab);
		agJavaScriptExecuctorClick(InboundAdvancedSearchObjects.emailTab);
		agSetValue(InboundAdvancedSearchObjects.emailSenderTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Email_Sender"));
		agSetValue(InboundAdvancedSearchObjects.emailDateFromTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Email_FromDate"));
		agSetValue(InboundAdvancedSearchObjects.emailRecDateToTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Email_ToDate"));
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
}
