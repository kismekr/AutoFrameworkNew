package com.arisglobal.framework.components.lsitst.OR;

public class PartnerLookupObjects {

	public static String nameTextbox = "xpath#//input[@id='body:partnerLookup:firstNameValue']";
	public static String typeDropdown = "xpath#//label[@id='body:partnerLookup:selectPartnerTypeId_label']";
	public static String countryDropdown = "xpath#//label[@id='body:partnerLookup:selectCountry_label']";
	public static String searchButton = "xpath#//button[@id='body:partnerLookup:findButton']";
	public static String cancelButton = "xpath#//button[@id='body:partnerLookup:cancelTopButton']";
	public static String selectButton = "xpath#//button[contains(@id,'body:partnerLookup:selectTopButton')]";
	public static String globalPartnersTab = "xpath#//a[@id='body:partnerLookup:globalPartnerstab']";
	public static String localPartnersTab = "xpath#//a[@id='body:partnerLookup:localPartnerstab']";

}
