package com.arisglobal.framework.components.lsitst.OR;

public class InboundArchiveObjects {
	
	public static String receiptNumberTextbox = "xpath#//input[@name='body:inboundList:rNoInList']";
	public static String receiptNumberLink = "xpath#//a[@id='body:inboundList:Inbound:0:rctActionId']";
	public static String searchButton = "xpath#//span[@class='ui-button-text ui-c'][contains(.,'Search')]";
	public static String resetButton = "xpath#//span[contains(.,'Reset')]";

}
