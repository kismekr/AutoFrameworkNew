package com.arisglobal.framework.components.lsitst.OR;

public class InboundAERSummaryObjects {

	public static String aerNoLabel = "xpath#//span[@id='body:aerSummaryLookup:aerlan2']";
	                                                     
	public static String medicallyConfirmedLabel = "xpath#//span[@id='body:aerSummaryLookup:Medicinfo']";
	public static String patientInitialsLabel = "xpath#//span[@id='body:aerSummaryLookup:patientInformation:0:patidinfo1']";
	public static String reporterTitleLabel = "xpath#//label[text()='Reporter Information']/following::tr[2]/td[1]";
	public static String reporterFirstNameLabel = "xpath#//label[text()='Reporter Information']/following::tr[2]/td[2]";
	public static String adverseEventReportedTermLabel = "xpath#//label[text()='Adverse Event']/following::tr[2]/td[1]";
	public static String aerSummaryLabel = "xpath#//span[contains(text(),'Aer Summary')]";
}
