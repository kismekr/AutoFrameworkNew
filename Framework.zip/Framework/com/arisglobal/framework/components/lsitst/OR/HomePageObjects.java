package com.arisglobal.framework.components.lsitst.OR;

public class HomePageObjects {

	public static String homePageLogo = "xpath#//img[@alt='agXchange']";
	public static String logoutIcon = "xpath#//a[@class='signoutIcon']";
	public static String irthompage="xpath#//a[@class='homeIcon']";
	public static String unreadLink = "xpath#//label[.='Unread']/preceding-sibling::a";
}
