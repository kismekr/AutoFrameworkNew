package com.arisglobal.framework.components.lsitst.OR;

public class InboundLocalReceiptObjects {

	public static String tabTextValue = "xpath#//span[.='{0}']";
	public static String LrnSearchButton = "xpath#//button[@id='body:inboundForm:searchButton2Visible']";
	public static String aerRadio = "xpath#//input[@id='body:inboundForm:ICD:0:copyAERRadio:0']";
	public static String LrnProceedButton = "xpath#//button[@id='body:inboundForm:proceedButton']";
	public static String receiptClassificationSaveButton = "xpath#//button[@id='body:inboundForm:saveButtonWithAudit']";
	public static String flagIcon = "xpath#//div[@id='body:inboundForm:completeActivityDropDown']/parent::div/img";
	public static String ToDispositiontoARISgLink = "xpath#//a[@id='body:inboundForm:completeActivityTable:1:completeActivity']";

	public static String unknownSenderInfoTextBox = "xpath#//input[@id='body:inboundForm:unknownSourceInfo']";
	public static String slideLink = "xpath#//div[@id='toggle-right-lay']/i";
	public static String fileNamelink = "xpath#//a[contains(@id,'body:inboundForm:sourceDocListId:0:viewE2bSourceDoc')]";

	public static String Sender = "xpath#//input[@id='body:inboundForm:source']";
	public static String Receiver = "xpath#//input[@id='body:inboundForm:receiver_input']";
	public static String SenderOrganization = "xpath#//input[@id='body:inboundForm:senderOrgNameSelected']";
	public static String ReceiverOrganization = "xpath#//input[@id='body:inboundForm:ownerUnitSelected_input']";
	public static String Owner = "xpath#//input[@id='body:inboundForm:ownerSelected_input']";
	public static String EisaiReceivedDate = "xpath#//input[@id='body:inboundForm:cdate_input']";
	public static String LocalReceivedDate = "xpath#//input[@id='body:inboundForm:ldate_input']";
	public static String UnknownSenderInfo = "xpath#//input[@id='body:inboundForm:unknownSourceInfo']";

	//public static String ReportType = "xpath#//div[@id='body:inboundForm:tabView:ID_42704279102112']";
	public static String ReportType ="xpath#//div[@id='body:inboundForm:tabView:ID_42702683102112']";
	//public static String primarySourceCountryLableDropdown ="xpath#//div[@id='body:inboundForm:tabView:ID_42704277102106']";
	public static String primarySourceCountryLableDropdown = "xpath#//div[@id='body:inboundForm:tabView:ID_42702681102106']";
	//public static String ARISgWorkflowTrackLableDropdown ="xpath#//div[@id='body:inboundForm:tabView:ID_42704285102801']";
	public static String ARISgWorkflowTrackLableDropdown = "xpath#//div[@id='body:inboundForm:tabView:ID_42702689102801']";
	
	//public static String CaseOwner = "xpath#//input[@id='body:inboundForm:tabView:ID_42704287102802']";
	public static String CaseOwner = "xpath#//input[@id='body:inboundForm:tabView:ID_42702691102802']";
	
	
	//public static String isPrimarySource = "xpath#//div[@id='body:inboundForm:tabView:ID_42704296124002']";
	public static String isPrimarySource = "xpath#//div[@id='body:inboundForm:tabView:ID_42702700124002']";
	
	//public static String SourceLableDropdown = "xpath#//div[@id='body:inboundForm:tabView:ID_42704291124001']";
	
	public static String SourceLableDropdown = "xpath#//div[@id='body:inboundForm:tabView:ID_42702695124001']";
//public static String Reportedterm = "xpath#//input[@id='body:inboundForm:tabView:ID_42704357111102']";
	public static String Reportedterm = "xpath#//input[@id='body:inboundForm:tabView:ID_42702761111102']";
	
	public static String localTradeName = "xpath#//input[@id='body:productLookup:localTradeNameFind']";
	public static String localTradeNameTab = "xpath#//span[.='Local Tradenames']";

	public static String protocolLookupIcon = "xpath#//i[@title='Protocol Lookup']";
	public static String protocolTextBox = "xpath#//input[@id='body:studyLookup:studyNameFind']";
	public static String searchButton = "xpath#//button[@id='body:studyLookup:findButton']";
	public static String caseProceed = "xpath#//span[.='Proceed']/parent::button";
	public static String categoryLabelDropdown = "xpath#//div[@id='body:inboundForm:sourceDocListId:0:sourceCategory']";
	public static String LrnPopupTextBox = "xpath#//div[@id='message:growlMessages_container']/div/div/div/span";

	public static String SenderOrganizationCode = "xpath#//input[@id='body:inboundForm:senderOrgSelected_input']";

	public static String dipostitionConfimarion = "xpath#//div[@id='message:messages_container']/div/div/div/span";
	public static String closeJavaScriptPOPup = "xpath#//div[@class='ui-growl-icon-close ui-icon ui-icon-closethick']";

	public static String lrnTabs(String tabName) {
		return tabTextValue.replace("{0}", tabName);
	}
	
	
	
	
	
	
	
	/***********************************************************************************************/
	public static String frmFrame="xpath#//iframe[@id='ifrm']";
	public static String xmlCheckpoint="xpath#//form[@name='ExportActionForm']/div/table//table//tr/td";
	public static String othersDropDown="xpath#//div[@id='body:e2bReport:selectTransition']";
	public static String pdfCheckpoint="xpath#//embed[@type='application/pdf']";
	public static String acknowldgement="xpath#//a[.='Acknowledgement']";
	public static String acknowldgementDropDown="xpath#//select[@id='body:acknowledgment:selectTransition']";
	public static String ackCheckpoint="xpath#//label[.='Acknowledgment Details']";
	public static String ackReportcheckpoint ="xpath#//label[.='Acknowledgement Details']";
	public static String archiveXMLLink="xpath#//a[@title='R3']";
	 
	

}
