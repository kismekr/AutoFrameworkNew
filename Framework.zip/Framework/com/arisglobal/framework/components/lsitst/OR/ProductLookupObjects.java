package com.arisglobal.framework.components.lsitst.OR;

public class ProductLookupObjects {

	// Level 1
	public static String productTypeDropdown = "xpath#//label[@id='body:productLookup:drugId2_label']";
	public static String preferredProdDescTextbox = "xpath#//input[@id='body:productLookup:productNameFind']";
	public static String manufactureNameTxtbox = "xpath#//input[@id='body:productLookup:ManufactureNameFind']";
	public static String formOfAdminDropdown = "xpath#//label[@id='body:productLookup:FormofAdminLabelFilter_label']";
	public static String routeOfAdminDropdown = "xpath#//label[@id='body:productLookup:RouteofAdminLabelFilter_label']";
	public static String productClassDropdown = "xpath#//label[@id='body:productLookup:ProductClassFilter_label']";
	public static String productGroupNameTxtbox = "xpath#//input[@id='body:productLookup:productGroupNameLabelFind']";
	public static String productStatusDropdown = "xpath#//label[@id='body:productLookup:productStatusFilter_label']";

	// Level2
	public static String productTypeLevel2Dropdown = "xpath#//label[@id='body:productLookup:level2ProductType_label']";
	public static String localTradeNameTxtbox = "xpath#//input[@id='body:productLookup:localTradeNameFind']";
	public static String companyProdCodeTxtbox = "xpath#//label[@id='body:productLookup:companyPoductCode']/../input[@type='text']";
	public static String approvalNoDropdown = "xpath#// input[@id='body:productLookup:approvalNoFind']";
	public static String approvalTypeDropdown = "xpath#// label[@id='body:productLookup:approvalTypeFind_label']";
	public static String countryDropdown = "xpath#// label[@id='body:productLookup:countryApprovalTypeFind_label']";
	public static String activeIngredientTxtbox = "xpath#// input[@id='body:productLookup:genericNameFind']";
	public static String ingredientStatusDropdown = "xpath#// label[@id='body:productLookup:ingredientStatusFilter_label']";
	public static String licenseStatusDropdown = "xpath#// label[@id='body:productLookup:licenseStatusFilter_label']";
	public static String submissionTypeDropdown = "xpath#// label[@id='body:productLookup:submissionTypeFilter_label']";
	public static String searchButton = "xpath#//button[@id='body:productLookup:findButton']";
	public static String selectButton = "xpath#//button[contains(@id,'select')]";
	public static String cancelButton = "xpath#//button[@id='body:productLookup:cancelTopButton']";

}
