package com.arisglobal.framework.components.lsitst.OR;

public class OutboundNewObjects {
	public static String outboundCaseTypeDropdown = "xpath#//label[@id='body:manualUploadForm:caseType_label']";
	public static String recipientTextbox = "xpath#//input[@id='body:manualUploadForm:selectRecipient_input']";
	public static String recipientLookup = "xpath#//i[@id='lookUpImage']";
	public static String reportTypeDropdown = "xpath#//label[@id='body:manualUploadForm:reportTypeLabelId_label']";
	public static String submissionDueDateTextbox = "xpath#//input[@id='body:manualUploadForm:companyReceiptDate_input']";
	public static String languageDropdown = "xpath#//label[@id='body:manualUploadForm:languageId_label']";
	public static String latestReceiptDateTextbox = "xpath#//input[@id='body:manualUploadForm:LatestreceiptDate_input']";
	public static String patientIDTextbox = "xpath#//input[@id='body:manualUploadForm:patientData']";
	public static String countryOfDetectionDropdown = "xpath#//label[@id='body:manualUploadForm:countryData_label']";
	public static String primarySourceCountryDropdown = "xpath#//label[@id='body:manualUploadForm:prmSrcCountryData_label']";
	public static String seriousnessDropdown = "xpath#//label[@id='body:manualUploadForm:seriousness_label']";
	public static String medicallyConfirmedDropdown = "xpath#//label[@id='body:manualUploadForm:medicalData_label']";
	public static String primaryReporterTextbox = "xpath#//input[@id='body:manualUploadForm:reporterData']";
	public static String productTextbox = "xpath#//input[@id='body:manualUploadForm:product_input']";
	public static String productLkpIcon = "xpath#//i[@id='lookUpImageProduct']";
	public static String EventTextbox = "xpath#//input[@id='body:manualUploadForm:reactionData']";
	public static String protocolNoTextbox = "xpath#//input[@id='body:manualUploadForm:inputProtocol_input']";
	public static String protocolNoLkpIcon = "xpath#//i[@id='lookUpImageStudy']";
	public static String sourceDocUploadButton = "xpath#//input[@id='body:manualUploadForm:uploadFileAdvanced_input']";
	public static String applicationLogo = "xpath#//img[contains(@src,'logo.png')]";
	public static String submitButton = "xpath#//span[@class='ui-button-text ui-c'][contains(.,'Submit')]";
	public static String structuredFormatDropdown = "xpath#//label[@id='body:manualUploadForm:formatStr_label']";
	public static String structuredMediumDropdown = "xpath#//label[@id='body:manualUploadForm:mediumForStr_label']";
	public static String unStructuredFormatDropdown = "xpath#//label[@id='body:manualUploadForm:formatUnStr_label']";
	public static String unStructuredMediumDropdown = "xpath#//label[@id='body:manualUploadForm:mediumForUnStr_label']";
}
