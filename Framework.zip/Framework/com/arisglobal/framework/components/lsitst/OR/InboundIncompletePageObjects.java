package com.arisglobal.framework.components.lsitst.OR;

public class InboundIncompletePageObjects {

	public static String receiptNumberLink = "xpath#//a[@id='body:inboundList:Inbound:0:rctId1']";

	public static String e2bLink = "xpath#//img[contains(@id,'e2bimage')]";

}
