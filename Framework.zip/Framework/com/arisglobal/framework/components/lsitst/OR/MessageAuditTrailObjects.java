package com.arisglobal.framework.components.lsitst.OR;

public class MessageAuditTrailObjects {

	public static String messageTypeDropdown = "xpath#//label[@id='body:message_audit:messagetypeid_label']";
	public static String sessionIDTextbox = "xpath#//input[@id='body:message_audit:sessionid']";
	public static String auditTrailFromDate = "xpath#//input[@id='body:message_audit:fromdatecalender_input']";
	public static String auditTrailToDate = "xpath#//input[@id='body:message_audit:todatecalender_input']";
	public static String receiptNoTextbox = "xpath#//input[@id='body:message_audit:messageId_input']";
	public static String lrnNoTextbox = "xpath#//input[@id='body:message_audit:lrnNo_input']";
	public static String aerNoTextbox = "xpath#//input[@id='body:message_audit:aerNo_input']";
	public static String trackingNoTextbox = "xpath#//input[@id='body:message_audit:atnid']";
	public static String messageNoTextbox = "xpath#//input[@id='body:message_audit:msgno']";
	public static String userIDTextbox = "xpath#//input[@id='body:message_audit:userid']";
	public static String operationTypeDropdown = "xpath#//label[@id='body:message_audit:operationtypeid_label']";
	public static String reasonTextbox = "xpath#//textarea[@id='body:message_audit:reasonid']";
	public static String generatePvtRepButton = "xpath#//button[@id='body:message_audit:generatePrivateReport']";
	public static String backButton = "xpath#//button[@id='body:dirListId:backLink']";
	public static String downloadFileTypeDropdown = "xpath#//label[@id='body:dirListId:selectReportTypeId_label']";
	public static String downloadButton = "xpath#//button[@id='body:dirListId:downloadReport']";

	public static String fieldUpdatesLabel = "xpath#//span[text()='Field Updates']";
}
