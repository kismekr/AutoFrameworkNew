package com.arisglobal.framework.components.lsitst.OR;

public class CommonObjects {

	public static String basicSearchTextbox = "xpath#//input[contains(@title,'Keyword search')]";
	public static String basicSearchIcon = "xpath#//i[contains(@class,'SearchIcon')]";
	public static String dropDownLabelValue = "xpath#//div[contains(@style,'display: block')]/div[2]/ul/li[text()='{0}']";
	
	
	public static String dropDownLabelValuecase = "xpath#//div[contains(@style,'display: block')]/div/ul/li[text()='{0}']";
	
	public static String radioButton = "xpath#//*[text()='{0}']/preceding::div[1]";
	public static String applicationMessage = "xpath#//div[contains(@id,'message:')]//div/div/span[@class='ui-growl-title']";
	public static String applicationMessageClose = "xpath#//div[contains(@id,'message:')]//div[@class='ui-growl-icon-close ui-icon ui-icon-closethick']";
	public static String passwordAuthentication = "xpath#//input[contains(@id,'password1')]";
	public static String linkText = "xpath#//a[text()='{0}']";
	public static String completeActivityIcon = "xpath#//img[contains(@src,'cactivity.svg')]";
	public static String formTabRecordNavigation = "xpath#//label[text()='{0}' and @class='ui-outputlabel ui-widget']/following::div[1]/table/tbody/tr/td/a/i[@title='{1}']";
	public static String processingLabel = "xpath#(//span[text()='Processing...'])";
	public static String noRecordsFoundLabel = "xpath#//td[text()='No Records Found']";
	public static String editIcon = "xpath#(//img[contains(@id,'editLink')])[2]";
	public static String editIcon1 = "xpath#(//img[contains(@id,'editLink')])[1]";
	public static String searchResultsDataRow = "xpath#//tr[@class='ui-widget-content ui-datatable-even ui-datatable-selectable']";
	public static String checkBoxRightOfLabel = "xpath#//label[text()='{0}']/../descendant::div/span[contains(@class,'ui-chkbox-icon')]";
	public static String checkBoxLeftOfLabel = "xpath#//*[contains(@title,'{0}')]/ancestor::tr[contains(@class,'ui-datatable')]/td/div/div/input[@type='checkbox']";
	public static String listingScreenData = "xpath#//span[contains(@title,'{0}')]";
	public static String containsLinkText = "xpath#//a[contains(text(),'{0}')]";
	public static String labelText = "xpath#//*[text()='{0}']";
	public static String listingScreenIcons = "xpath#//*[contains(@title,'{0}')]";
	public static String listDropDown = "xpath#//li[contains(text(),'{0}')]";
	public static String e2bFormat = "xpath#//label[@id='body:e2bReport:selectTransition_label']";
	public static String r2Icon = "xpath#//img[contains(@id,'R2image')]";
	public static String e2bReportView = "xpath#//img[contains(@src,'e2bform')]";
	public static String e2bXMLView = "xpath#//font[contains(text(),'xml')]";
	public static String errorViewLabel = "xpath#//label[contains(text(),'Error')]";
	public static String incompleteDataRow = "xpath#//tr[@class='ui-widget-content ui-datatable-even']";
	public static String textData = "xpath#//*[text()='{0}']";
	public static String checkBoxLeftOf = "xpath#//*[contains(@title,'{0}')]/../parent::tr/td/div/div/span";
	public static String calenderCloseButton = "xpath#//button[text()='Close']";
	public static String recordNavigationValue = "xpath#//label[text()='{0}' and @class='ui-outputlabel ui-widget']/following::div[1]/table/tbody/tr/td/input[contains(@id,'NAV_INPUT')]";
	public static String closeButton = "xpath#//span[@class='ui-button-text ui-c'][contains(.,'Close')]";
	public static String searchButton = "xpath#//span[text()='Search']";
	public static String uiXmlContent = "xpath#// table[@class='entry_innercolor']";
	public static String e2bCaseNumberLabel = "xpath#//span[contains(@id,'panelGroup')]/label[contains(@id,'body:e2bReport:')]";

	
	
	
	
	public static String recordNavigationValue(String panelName) {
		String actualValue = recordNavigationValue;
		String result = actualValue.replace("{0}", panelName);
		return result;
	}

	public static String checkBoxLeftOf(String value) {
		String actualValue = checkBoxLeftOf;
		String result = actualValue.replace("{0}", value);
		return result;
	}

	public static String textData(String value) {
		String actualValue = textData;
		String result = actualValue.replace("{0}", value);
		return result;
	}

	public static String listingScreenIcons(String value) {
		String actualValue = listingScreenIcons;
		String result = actualValue.replace("{0}", value);
		return result;
	}

	public static String listDropDown(String value) {
		String actualValue = listDropDown;
		String result = actualValue.replace("{0}", value);
		return result;
	}

	public static String labelText(String value) {
		String actualValue = labelText;
		String result = actualValue.replace("{0}", value);
		return result;
	}

	public static String listingScreenData(String value) {
		String actualValue = listingScreenData;
		String result = actualValue.replace("{0}", value);
		return result;
	}

	public static String checkBoxRightOfLabel(String value) {
		String actualValue = checkBoxRightOfLabel;
		String result = actualValue.replace("{0}", value);
		return result;
	}

	public static String checkBoxLeftOfLabel(String value) {
		String actualValue = checkBoxLeftOfLabel;
		String result = actualValue.replace("{0}", value);
		return result;
	}

	public static String linkText(String value) {
		String actualValue = linkText;
		String result = actualValue.replace("{0}", value);
		return result;
	}

	public static String containsLinkText(String value) {
		String actualValue = containsLinkText;
		String result = actualValue.replace("{0}", value);
		return result;
	}

	public static String radioButton(String value) {
		String actualValue = radioButton;
		String result = actualValue.replace("{0}", value);
		return result;
	}

	public static String dropDownLabelValue(String expectedValue) {
		String actualValue = dropDownLabelValue;
		String result = actualValue.replace("{0}", expectedValue);
		return result;
	}

	public static String formTabRecordNavigation(String panelName, String navigateTo) {
		String actualValue = formTabRecordNavigation;
		String panel = actualValue.replace("{0}", panelName);
		String result = panel.replace("{1}", navigateTo);
		return result;
	}
	
	public static String dropDownLabelValuecase(String expectedValue) {
		return dropDownLabelValuecase.replace("{0}", expectedValue);
	}
}
