package com.arisglobal.framework.components.lsitst.OR;

public class InboundNewE2BCaseEntryObjects {

	public static String sourceDocUploadButton = "xpath#//input[contains(@id,'body:inboundForm:uploadFile1_input')]";
	public static String createReceiptItemButton = "xpath#//span[@class='ui-button-text ui-c'][contains(.,'Create Receipt Item')]";
	public static String cancelButton = "xpath#//span[@class='ui-button-text ui-c'][contains(.,'Cancel')]";
}
