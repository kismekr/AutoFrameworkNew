package com.arisglobal.framework.components.lsitst.OR;

public class ProtocolLookupObjects {

	public static String protocolNoTextbox = "xpath#//input[@id='body:studyLookup:studyNameFind']";
	public static String statusDropdown = "xpath#//label[@id='body:studyLookup:stuudyStatusFilter_label']";
	public static String searchButton = "xpath#//button[@id='body:studyLookup:findButton']";
	public static String selectButton = "xpath#//button[@id='body:studyLookup:selectTopButton']";
	public static String cancelButton = "xpath#//button[@id='body:studyLookup:cancelTopButton']";
}
