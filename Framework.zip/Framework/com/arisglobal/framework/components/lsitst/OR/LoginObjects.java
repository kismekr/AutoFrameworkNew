package com.arisglobal.framework.components.lsitst.OR;

public class LoginObjects {

	public static String userNameTextbox = "xpath#//input[@name='userId']";
	public static String passwordTextbox = "xpath#//input[@name='password']";
	public static String databaseDropdown = "xpath#//select[@name='dbnames']";
	public static String loginDropdown = "xpath#//a[contains(text(),'▼')]";
	public static String agxchangeLoginButton = "xpath#//a[contains(text(),'agXchange Login')]";
	public static String agxchangeContinueLoginText = "xpath#//div[@id='commonLoginId']";
	public static String agxchangeContinueLoginButton = "xpath#//input[@name='continueLogin']";

}
