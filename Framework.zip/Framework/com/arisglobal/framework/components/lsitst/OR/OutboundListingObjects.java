package com.arisglobal.framework.components.lsitst.OR;

public class OutboundListingObjects {

	public static String outboundSearchTextbox = "xpath#//input[@id='body:singleCaseMessageListForm:find']";
	public static String outboundSearchButton = "xpath#//i[contains(@class,'SearchIcon')]";
	public static String aerNoLink = "xpath#//a[@id='body:singleCaseMessageListForm:partnerMessageDataTable:0:AerSummaryLookup']";

	public static String e2bLink = "xpath#//span[contains(@id, 'e2bLinktxt')]";
	public static String e2bFormat = "xpath#//label[@id='body:e2bReport:selectTransition_label']";
	public static String r2Icon = "xpath#//img[contains(@id,'R2image')]";

}
