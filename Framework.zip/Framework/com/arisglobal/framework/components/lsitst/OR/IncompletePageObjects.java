package com.arisglobal.framework.components.lsitst.OR;

public class IncompletePageObjects {

	public static String incompleteTransactionLink = "xpath#//span[text()='Incomplete Transactions']";

}
