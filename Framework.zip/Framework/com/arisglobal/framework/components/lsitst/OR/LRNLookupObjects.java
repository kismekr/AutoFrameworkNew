package com.arisglobal.framework.components.lsitst.OR;

public class LRNLookupObjects {

	public static String lrnLookupIcon = "xpath#//i[@id='lookUpImageLrn']";
	public static String lrnNumberTextbox = "xpath#//input[@id='body:lrnLookup:lrnNumber']";
	public static String selectButton = "xpath#//button[@id='body:lrnLookup:findButton']";
	public static String cancelButton = "xpath#//button[@id='body:lrnLookup:cancelTopButton']";

}
