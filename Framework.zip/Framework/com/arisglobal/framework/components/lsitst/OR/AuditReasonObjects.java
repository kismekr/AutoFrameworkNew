package com.arisglobal.framework.components.lsitst.OR;

public class AuditReasonObjects {

	public static String reasonCodeDropdown = "xpath#//label[contains(@id,'reasonCode_label')]";
	public static String reasonTextbox = "xpath#//textarea[contains(@id,'auditReason')]";
	// public static String submitButton = "xpath#(//span[text()='Submit'])";

	public static String submitButton = "xpath#//button[contains(@id,'Submit')][@aria-disabled='false'][not(@style='display:none')]";

}
