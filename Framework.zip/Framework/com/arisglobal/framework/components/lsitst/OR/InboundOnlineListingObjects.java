package com.arisglobal.framework.components.lsitst.OR;

public class InboundOnlineListingObjects {

	public static String searchIcon = "xpath#//a[@id='body:aeForm:findButtonList']";
	public static String searchTextbox = "xpath#//input[@id='body:aeForm:searchText1']";
	public static String editIcon = "xpath#//img[@id='body:aeForm:onlineEntryRecord:0:editLink']";
	public static String noRecordsFoundLabel = "xpath#// td[text()='No Records Found']";
	public static String onlineListingScreenMsg = "xpath#//tbody[@id='body:aeForm:onlineEntryRecord_data']";
	public static String atnNumberLabel = "xpath#//span[@id='body:aeForm:onlineEntryRecord:0:statusValue']";
	public static String viewPDFIcon = "xpath#//img[@title='View PDF']";

}
