package com.arisglobal.framework.components.lsitst.OR;

public class NavigationObjects {

	public static String inboundLink = "xpath#//a[@id='INBOUND']";
	public static String defaultDataAssesmentFormLink = "xpath#//a[contains(text(),'Default Data Assessment Form')]";
	public static String inboundListingLink = "xpath#//a[contains(.,'Inbound Listing')]";
	public static String caseDataTab = "xpath#//span[contains(.,'Case Data')]";
	public static String generalTab = "xpath#//a[text()='General']";
	public static String reporterTab = "xpath#//a[text()='Reporter']";
	public static String patientTab = "xpath#//a[text()='Patient']";
	public static String productTab = "xpath#//a[text()='Product']";
	public static String eventTab = "xpath#//a[text()='Event']";
	public static String narrativeTab = "xpath#//a[text()='Narrative']";
	public static String labTab = "xpath#//a[text()='Lab']";
	public static String classificationTab = "xpath#//span[contains(.,'Classification')]";
	public static String onlineEntryLink = "xpath#//table[@class='indOnlineEntryTable']//a[contains(@title,'Lists Online Entry cases')]";
	public static String defaultOnlineFormLink = "xpath#//table[@class='indOnlineEntryTable']//a[contains(text(),'Default Online Form')]";
	public static String inboundArchiveLink = "xpath#//a[contains(@title,'archive cases')]";
	public static String defaultDataEntryFormLink = "xpath#//label[text()='Data Entry']/following::table[1]//a[text()='Default Data Entry Form']";
	public static String newE2BCaseEntryLink = "xpath#//a[contains(text(),'New E2B Case Entry')]";
	public static String outboundLink = "xpath#//a[@id='OUTBOUND']";
	public static String newLink = "xpath#//a[text()='New']";
	public static String singleCaseLink = "xpath#//a[text()='Single Case']";
	public static String outboundArchiveLink = "xpath#//a[contains(@title,'archived cases')]";
	public static String failedDistributionLink = "xpath#//a[text()='Failed Distributions']";
	public static String failedSubmissionLink = "xpath#//a[text()='Failed Submissions']";
	public static String administratorLink = "xpath#//a[@id='ADMINISTRATION']";
	public static String msgAuditTrailLink = "xpath#//a[text()='Message Audit Trail']";
	public static String incompleteLink = "xpath#//a[text()='Incomplete']";
	public static String partnersLink = "xpath#//a[text()='Partners']";
	public static String reconciliationLink="xpath#//a[.='Reconciliation']";

}
