package com.arisglobal.framework.components.lsitst.OR;

public class RecepientLookupObjects {

	public static String receiptLookupIcon = "xpath#//i[@id='lookUpImageReceipt']";
	public static String receiptNumberTextbox = "xpath#//input[@id='body:receiptNoLookup:receiptNumber']";
	public static String selectButton = "xpath#//button[@id='body:receiptNoLookup:findButton']";
	public static String cancelButton = "xpath#//button[@id='body:receiptNoLookup:cancelTopButton']";

}
