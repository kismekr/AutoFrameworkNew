package com.arisglobal.framework.components.lsitst.OR;

public class InboundLRNSummaryObjects {
	
	public static String lrnSummaryLabel = "xpath#//label[text()='LRN Summary']";

}
