package com.arisglobal.framework.components.lsitst.OR;

public class PartnersPageObjects {

	public static String addButton = "xpath#//span[text()='Add']";

	public static String cancelButton = "xpath#//span[text()='Cancel']";

	public static String removePartnerButton = "xpath#//span[text()='Remove']";

	public static String inboundTransportLink = "xpath#//a[contains(@href,'partnerTabView:inboundTabId')]";

	public static String outboundTransportLink = "xpath#//a[contains(@href,'partnerTabView:outboundTabId')]";

	public static String addInboundButton = "xpath#//button[@id='body:partnerDetailsForm:partnerTabView:AddInbound']";

	public static String removeInboundButton = "xpath#//button[@id='body:partnerDetailsForm:partnerTabView:Remove']";

	public static String saveButton = "xpath#//button[@title='Ctrl+S']";

	public static String nameTextbox = "xpath#//input[@id='body:inBoundTransport:transportName']";

	public static String mediumDropdown = "xpath#//label[@id='body:inBoundTransport:medium_label']";

	public static String partnerIDTextbox = "xpath#//input[@id='body:inBoundTransport:interchangeId']";

	public static String receiverIDTextbox = "xpath#//input[@id='body:inBoundTransport:receiverinterchangeId']";
}
