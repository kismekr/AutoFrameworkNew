package com.arisglobal.framework.components.lsitst.OR;

public class ConfirmRemoveObjects {

	public static String reasonCodeDropdown = "xpath#//label[contains(@id,'removeReasonCode_label')]";
	public static String reasonTextbox = "xpath#//textarea[contains(@id,'removeReason')]";
	public static String submitButton = "xpath#//button[@id='body:inboundForm:auditSubmit1']";
}
