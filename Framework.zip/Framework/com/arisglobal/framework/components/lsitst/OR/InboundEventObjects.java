package com.arisglobal.framework.components.lsitst.OR;

public class InboundEventObjects {
	static String result = null;
	public static String eventLabel = "xpath#//label[text()='Event']";
	public static String reportedTermTextbox = "xpath#//label[contains(text(),'Reported term')]/following::input[contains(@id,'111102')]";
	public static String onsetDateTextbox = "xpath#//label[text()='Onset date']/../span/span/input[contains(@id,'111116')]";
	public static String cessationDateTextbox = "xpath#//label[text()='Cessation date']/../span/span/input[contains(@id,'111118')]";
	public static String outcomeDropdown = "xpath#//label[contains(@id,'111127_label')]";
	public static String reporterTermTextbox = "xpath#//input[contains(@id,'117104')]";
	public static String reporterCasualityDropdown = "xpath#//label[contains(@id,'117112_label')]";
	public static String deathDropdown = "xpath#//label[contains(@id,'111150_label')]";
	public static String lifeThreateningDropdown = "xpath#//label[contains(@id,'111151_label')]";
	public static String congentialAnomalyDropdown = "xpath#//label[contains(@id,'111153_label')]";
	public static String disabilityOrPermanentDamageDropdown = "xpath#//label[contains(@id,'111154_label')]";
	public static String otherSeriousDropdown = "xpath#//label[contains(@id,'111155_label')]";
	public static String reporterHighlighted = "xpath#//label[contains(@for,'111114') and text()='{0}']";
	public static String reporterSeriousness = "xpath#//label[contains(@for,'111253') and text()='{0}']";
	public static String companySeriousness = "xpath#// label[contains(@for,'111159') and text()='{0}']";

	public static String reporterHighRdoBtn(String value) {
		String actualLocator = reporterHighlighted;
		result = actualLocator.replace("{0}", value);
		return result;
	}

	public static String reporterSeriousnessRdoBtn(String value) {
		String actualLocator = reporterSeriousness;
		result = actualLocator.replace("{0}", value);
		return result;
	}

	public static String companySeriousnessRdoBtn(String value) {
		String actualLocator = companySeriousness;
		result = actualLocator.replace("{0}", value);
		return result;
	}
}
