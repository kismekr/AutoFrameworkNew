package com.arisglobal.framework.components.lsitst.OR;

public class InboundNarrativeObjects {

	public static String eventDescriptionTextbox = "xpath#//textarea[contains(@id, '114102')]";
	public static String arisgAdditionalCommentsTextbox = "xpath#//textarea[contains(@id, '114102')]";
	public static String irtCommentsTextbox = "xpath#//textarea[contains(@id, '101212')]";

}
