package com.arisglobal.framework.components.lsitst.OR;

public class InboundPatientObjects {

	public static String patientDetailsLabel = "xpath#//label[text()='Patient Details']";
	public static String patientInitialsTextbox = "xpath#//input[contains(@id, '106102')]";
	public static String weightTextbox = "xpath#//input[contains(@id, '106121')]";
	public static String weightComboDropdown = "xpath#//label[contains(@id,'106135_label')]";
	public static String dateOfBirthTextbox = "xpath#//input[contains(@id, '106113')]";
	public static String heightTextbox = "xpath#//input[contains(@id, '106123')]";
	public static String heightComboDropdwon = "xpath#//label[contains(@id,'106134_label')]";
	public static String ageAtTheTimeOfEventTextbox = "xpath#//input[contains(@id, '106114')]";
	public static String ageAtTheTimeOfEventDropdown = "xpath#//label[contains(@id,'106116_label')]";
	public static String ethinicOriginDropdwon = "xpath#//label[contains(@id,'106137_label')]";
	public static String specialistNumberTextbox = "xpath#//input[contains(@id, '106106')]";
	public static String gpMedicalNoTextbox = "xpath#//input[contains(@id, '106104')]";
	public static String investigationNoTextbox = "xpath#//input[contains(@id, '106110')]";
	public static String hospitalNoTextbox = "xpath#//input[contains(@id, '106108')]";
	public static String sexDropdown = "xpath#//label[contains(@id,'106125_label')]";
	public static String medicalHistoryTermTextbox = "xpath#//input[contains(@id, '107102')]";
	public static String relevantMedHisstartDateTextbox = "xpath#//input[contains(@id, '107107')]";
	public static String relevantMedHisendDateTextbox = "xpath#//input[contains(@id, '107110')]";
	public static String continuingDropdown = "xpath#//label[contains(@id,'107108_label')]";
	public static String productDesriptionTextbox = "xpath#//input[contains(@id, '108102')]";
	public static String relevantPastProdHisStartDateTextbox = "xpath#//input[contains(@id,'108105')]";
	public static String relevantPastProdHisEndDateTextbox = "xpath#//input[contains(@id,'108107')]";
	public static String indicationTextbox = "xpath#//input[contains(@id, '108110')]";
	public static String reactionTextbox = "xpath#//input[contains(@id, '108114')]";
	public static String ageGroupRadioBtn = "xpath#//label[contains(@for,'106120') and text()='{0}']";

	public static String ageGroupRdoBtn(String value) {
		String ageGroup = ageGroupRadioBtn;
		String result = ageGroup.replace("{0}", value);
		return result;
	}

}
