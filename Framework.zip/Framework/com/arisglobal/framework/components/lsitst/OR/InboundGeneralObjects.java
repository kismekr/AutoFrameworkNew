package com.arisglobal.framework.components.lsitst.OR;

public class InboundGeneralObjects {
	public static String aerInfoLabel = "xpath#//label[text()='AER Information']";
	public static String lrnNumberTextbox = "xpath#//label[contains(text(),'LRN')]/following::input[contains(@id,'101208')]";
	public static String initialReceivedDateTextbox = "xpath#//input[contains(@id,'102121_input')]";
	public static String aerNoTextbox = "xpath#//label[contains(text(),'AER No.')]/following::input[contains(@id,'101201')]";
	public static String latestReceivedDateTextbox = "xpath#//input[contains(@id,'102123_input')]";
	public static String medicallyConfirmedDropdown = "xpath#//label[contains(@id,'102138_label')]";
	public static String reportTypeDropdown = "xpath#//label[contains(@id,'102112_label')]";
	public static String otherReferenceNoTextbox = "xpath#//input[contains(@id,'102143')]";
	public static String subReportTypeDropdown = "xpath#//label[contains(@id,'102142_label')]";
	public static String productComplaintCheckbox = "xpath#//label[text()='Product Complaint']/following-sibling::table//span[contains(@class,'ui-chkbox-icon')]";
	public static String sourceDropdown = "xpath#//label[contains(@id,'124001_label')]";
	public static String sourceIdentificationNoTextbox = "xpath#//input[contains(@id,'124003')]";
	public static String linkReportNoTextbox = "xpath#//input[contains(@id,'104102')]";
	public static String protocolNoTextbox = "xpath#//input[contains(@id,'125003_input')]";
	public static String protocolLookupIcon = "xpath#//i[@title='Protocol Lookup']";
	public static String siteNoTextbox = "xpath#//input[contains(@id,'125013')]";

	// Common for all the form tabs
	public static String outstandingCommunicationChkbox = "xpath#//div[@id='body:inboundForm:outstandingQueries1']/div/span[contains(@class,'ui-chkbox-icon')]";
	public static String communicationDueDateTextbox = "xpath#//input[@id='body:inboundForm:queryDueDate1']";

}
