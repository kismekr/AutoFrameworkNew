package com.arisglobal.framework.components.lsitst.OR;

public class InboundAdvancedSearchObjects {
	public static String receiptNumberTextbox = "xpath#//input[@id='body:inboundList:rNo_input']";
	public static String senderTextbox = "xpath#//input[@id='body:inboundList:senderid_input']";
	public static String receiverTextbox = "xpath#//input[@id='body:inboundList:receiver_input']";
	public static String lrnNumberTextbox = "xpath#//input[@id='body:inboundList:lrnNo_input']";
	public static String aerNumberTextbox = "xpath#//input[@id='body:inboundList:aerNo_input']";
	public static String productDescriptionTextbox = "xpath#//input[@id='body:inboundList:product']";
	public static String reporterTextbox = "xpath#//input[@id='body:inboundList:reporter']";
	public static String reporterCountryDropdown = "xpath#//label[@id='body:inboundList:reporterCountry_label']";
	public static String countryOfDetectionDropdown = "xpath#//label[@id='body:inboundList:countryoccur_label']";
	public static String primarySourceCountryDropdown = "xpath#//label[@id='body:inboundList:primarySrcCountry_label']";
	public static String spainStateDropdown = "xpath#//label[@id='body:inboundList:spainStateDropDown_label']";
	public static String patientID = "xpath#//input[@id='body:inboundList:patientId']";
	public static String patientInitials = "xpath#//input[@id='body:inboundList:intial']";
	public static String dobFromTextbox = "xpath#//input[@id='body:inboundList:from_input']";
	public static String dobToTextbox = "xpath#//input[@id='body:inboundList:todate_input']";
	public static String latestRecDateFromTextbox = "xpath#//input[@id='body:inboundList:rcptfromdate_input']";
	public static String latestRecDateToTextbox = "xpath#//input[@id='body:inboundList:rcpttodate_input']";
	public static String sourceMediumDropdown = "xpath#//label[@id='body:inboundList:srcMedium_label']";
	public static String agFrmReceiveDateTextbox = "xpath#//input[@id='body:inboundList:companyReceivedDateFrom_input']";
	public static String agToReceiveDateTextbox = "xpath#//input[@id='body:inboundList:companyReceivedDateTo_input']";
	public static String localRecDateFromTextbox = "xpath#//input[@id='body:inboundList:localReceiptDateFrom_input']";
	public static String localRecDateToTextbox = "xpath#//input[@id='body:inboundList:localReceiptDateTo_input']";
	public static String documentNameTextbox = "xpath#//input[@id='body:inboundList:documentName']";
	public static String documentCategoryDropdown = "xpath#//label[@id='body:inboundList:selectcategory_label']";
	public static String lastUserModifiedTextbox = "xpath#//input[@id='body:inboundList:userModified']";
	public static String statusDropdown = "xpath#//label[@id='body:inboundList:statusValue_label']";	
	public static String disposeFromDateTextbox = "xpath#//input[@id='body:inboundList:fromDisposeDate_input']";
	public static String disposeFromToDateTextbox = "xpath#//input[@id='body:inboundList:toDisposeDate_input']";
	public static String acknowledgeFromDateTextbox = "xpath#//input[@id='body:inboundList:fromAckDate_input']";
	public static String acknowledgeToDateTextbox = "xpath#//input[@id='body:inboundList:toAckDate_input']";
	public static String workflowActivityDropdown = "xpath#//label[@id='body:inboundList:wfActivitySelected_label']";
	public static String companySeriousnessDropdown = "xpath#//label[@id='body:inboundList:seriousVal_label']";
	public static String classificationTypeDropdown = "xpath#//label[@id='body:inboundList:classificationTypeVal_label']";
	public static String otherIdentificationNoTextbox = "xpath#//input[contains(@id,'body:inboundList:otherIdNoField')]";
	public static String caseTagTextbox = "xpath#//input[@id='body:inboundList:j_id_1pt_input']";
	public static String sourceIdentificationNoTextbox = "xpath#//input[@id='body:inboundList:IdNoField']";
	public static String localCaseIDTextbox = "xpath#//input[@id='body:inboundList:localCaseIdField']";
	public static String ownerTextbox = "xpath#//input[@id='body:inboundList:ownerField_input']";
	public static String onSetDateFromTextbox = "xpath#//input[@id='body:inboundList:onsetStartDate_input']";
	public static String onSetDateToTextbox = "xpath#//input[@id='body:inboundList:onsetStartToDate_input']";
	public static String cessationDateFromTextbox = "xpath#//input[@id='body:inboundList:onsetEndFromDate_input']";
	public static String cessationDateToTextbox = "xpath#//input[@id='body:inboundList:onsetEndToDate_input']";
	public static String pendingDropdown = "xpath#//label[@id='body:inboundList:advPending_label']";
	
	
	public static String emailTab ="xpath#//a[@id='body:inboundList:emailPanelId_toggler']";
	public static String emailDateFromTextbox = "xpath#//input[@id='body:inboundList:emailSentOnFromDt_input']";
	public static String emailRecDateToTextbox = "xpath#//input[@id='body:inboundList:emailSentOnToDt_input']";
	public static String emailSenderTextbox="xpath#//input[@id='body:inboundList:emailSendertxt']";
	
}
