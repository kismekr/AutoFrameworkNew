package com.arisglobal.framework.components.lsitst.OR;

public class InboundOnlineBasicInfoObjects {

	public static String supportingDocUploadButton = "xpath#//input[@id='body:onlineform:uploadSupportFileAdvanced_input']";
	public static String supportingDocLink = "xpath#//a[@id='body:onlineform:attachedFiles1:0:suportDocs']";
	public static String submitAEForm = "xpath#//span[contains(.,'Submit AE Form')]";

}
