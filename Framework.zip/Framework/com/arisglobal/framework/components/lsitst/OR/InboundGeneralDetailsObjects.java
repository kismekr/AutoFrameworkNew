package com.arisglobal.framework.components.lsitst.OR;

public class InboundGeneralDetailsObjects {
	public static String senderTextbox = "xpath#//input[@id='body:inboundForm:source']";
	public static String senderLookup = "xpath#//i[@id='lookUpImage']";
	public static String receiverTextbox = "xpath#//input[@id='body:inboundForm:receiver_input']";
	public static String receiverLookup = "xpath#//i[@id='reclookUpImage']";
	public static String arisGlobalReceivedDateTextbox = "xpath#//span[contains(@id,'companyReceivedDate')]/../span/span/input[contains(@id,'input')]";
	public static String localReceivedDateTextbox = "xpath#//label[text()='Local Received Date']/../span/span/input[contains(@id,'input')]";
	public static String sourceDocUploadButton = "xpath#//input[@id='body:inboundForm:uploadFile_input']";
	public static String sourceDocUploadedLink = "xpath#//a[@id='body:inboundForm:sourceDocListId:0:viewE2bSourceDocId1']";
	public static String createReceiptItemButton = "xpath#//span[@class='ui-button-text ui-c'][contains(.,'Create Receipt Item')]";
	public static String editReceiptLabel = "xpath#//label[text()='Edit Receipt']";
	public static String supportingDocUploadButton = "xpath#//input[@id='body:inboundForm:uploadSupportFile_input']";
	public static String supportingDocUploadedLink = "xpath#//a[contains(@id,'FileLink')]";
	public static String fileUploadingIcon = "xpath#//button[contains(@class,'ui-fileupload-cancel')]";
	public static String reportTypeDropdown = "xpath#//label[contains(@id,'reportType_label')]";

	// Edit case
	public static String editCaseSuppDocUploadFileBtn = "xpath#//span[contains(@class,'addButtonIcon')]";
	public static String editCaseSuppDocUploadBtn = "xpath#//span[contains(@aria-labelledby,'uploadSupportFile')]";
	public static String editCaseFileUploadingIcon = "xpath#//div[@class='ui-fileupload-row']";
	public static String editCaseSuppDocUploadedLink = "xpath#//a[contains(@id,'viewHtmlFileLink')]";
	public static String expandCollapseDocWindowBtn = "xpath#//div[@id='toggle-right-lay']";
}
