package com.arisglobal.framework.components.lsitst.OR;

public class OutboundGeneralObjects {

	// HQ Instructions
	public static String generalTab = "xpath#//a[@id='body:editSingleCaseMessagePartner:generalTab']";
	public static String submissionDueDateTextbox = "xpath#//input[@id='body:editSingleCaseMessagePartner:dueDate_input']";
	public static String ownerUnitTextbox = "xpath#//input[@id='body:editSingleCaseMessagePartner:ownerUnit']";
	public static String ownerTextbox = "xpath#//input[@id='body:editSingleCaseMessagePartner:userSelected_input']";
	public static String commentsTextbox = "xpath#//textarea[@id='body:editSingleCaseMessagePartner:comments']";
	public static String coverLetterTemplateLink = "xpath#//a[@id='body:editSingleCaseMessagePartner:coverLetter']";
	public static String templateUploadBtn = "xpath#//input[contains(@id,'body:editSingleCaseMessagePartner:coverLetterUploadAdvanced_input')]";
	public static String removeButton = "xpath#//button[@id='body:editSingleCaseMessagePartner:removeButton']";

	// Email
	public static String emailSubTextbox = "xpath#//input[@id='body:editSingleCaseMessagePartner:emailSubjecttextarea']";
	public static String emailMsgTextbox = "xpath#// textarea[@id='body:editSingleCaseMessagePartner:emailMessagetextarea']";

	// Local Driver
	public static String localDriveTab = "xpath#// a[@id='body:editSingleCaseMessagePartner:localDriveDocumentLabelHeader']";
	public static String documentUploadBtn = "xpath#// input[@id='body:editSingleCaseMessagePartner:localDriveUploadFileAdvanced_input']";

	// ARISg Documents
	public static String arisgDocumentsTab = "xpath#//a[@id='body:editSingleCaseMessagePartner:arisgDocumentLabelHeader']";
	public static String arsigDocAddButton = "xpath#//button[@id='body:editSingleCaseMessagePartner:arisgDocLookup1']";
	public static String arisgDocRemoveButton = "xpath#//button[@id='body:editSingleCaseMessagePartner:arisgRemoveButton1']";
	public static String arisgDocCancelButton = "xpath#//button[@id='body:arisgDocumentList:removeButton']";
	public static String arisgDocTable = "xpath#//div[@id='body:editSingleCaseMessagePartner:arisgDoc1']";

	// Template
	public static String templateTab = "xpath#//a[@id='body:editSingleCaseMessagePartner:documentTemplateLabelHeader']";
	public static String templateDropdown = "xpath#//label[@id='body:editSingleCaseMessagePartner:language21_label']";
	public static String generateAndAttachBtn = "xpath#//button[@id='body:editSingleCaseMessagePartner:generate1']";
	public static String templateRemoveBtn = "xpath#//button[@id='body:editSingleCaseMessagePartner:documentTemplateRemoveButton1']";

}
