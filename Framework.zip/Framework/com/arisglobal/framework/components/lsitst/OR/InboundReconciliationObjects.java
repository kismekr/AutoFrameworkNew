package com.arisglobal.framework.components.lsitst.OR;

public class InboundReconciliationObjects {
	public static String mediumDropdown = "xpath#//div[@id='body:reconciliationReport:schedularlabelId']";
	public static String fromTextbox = "xpath#//input[@id='body:reconciliationReport:receivedfromdatecalender_input']";
	public static String toTextBox = "xpath#//input[@id='body:reconciliationReport:receivedtodatecalender_input']";
	public static String generateButton = "xpath#//button[@id='body:reconciliationReport:generatereportlabel']";
	public static String tableId = "xpath#//tbody[@id='body:ReconciliationListing:schedularReportId_data']/tr";
	public static String backButton="xpath#//span[.='Back']/parent::button";
	public static String noRecordsFound = "xpath#//td[.='No Records Found']";
	public static String sortRecivedDate="xpath#//span[.='Eisai Received Date']/following-sibling::span";

	public static String reconciliationResultTable(int rowNum, int columnNum) {
		return tableId + "[" + rowNum + "]/td[" + columnNum + "]";

	}
}
