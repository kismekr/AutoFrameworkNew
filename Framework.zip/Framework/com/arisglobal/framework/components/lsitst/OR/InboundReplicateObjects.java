package com.arisglobal.framework.components.lsitst.OR;

public class InboundReplicateObjects {
	
	public static String numberOfItemsTextbox = "xpath#//input[@id='body:form:numofrecords']";
	public static String commentsTextbox = "xpath#//textarea[@id='body:form:replicateComments']";
	public static String communicationCheckbox = "xpath#//input[@id='body:form:Querychek']";
	public static String caseDataCheckbox = "xpath#//input[contains(@id,'body:form:Assessmentchek')]";
	public static String submitButton = "xpath#//button[@id='body:form:submit12']";

}
