package com.arisglobal.framework.components.lsitst.OR;

public class InboundListingObjects {

	public static String inboundSearchTextbox = "xpath#//input[@id='body:inboundList:searchText1']";
	public static String inboundSearchButton = "xpath#//i[contains(@class,'SearchIcon')]";
	public static String lrnLink = "xpath#//span[@id='body:inboundList:Inbound:0:LRNNOValue']";
	public static String aerLink = "xpath#//a[@id='body:inboundList:Inbound:0:AerSummaryLookupdup']";
	public static String aerNumber = "xpath#//span[@id='body:inboundList:Inbound:0:dupquery2']";
	public static String aerVersionLabel = "xpath#//span[@id='body:inboundList:Inbound:0:aerVersion']";
	public static String receiptNumberLink = "xpath#//a[contains(@id,'body:inboundList:Inbound:0:j_id_1c')]";
	public static String replicateMediumLink = "xpath#//span[@id='body:inboundList:Inbound:0:mediumCommentsLabel']";
	public static String receiptNoDescSortLink = "xpath#//span[@id='body:inboundList:Inbound:receiptNumber']/../following-sibling::span[@class='ui-sortable-column-icon ui-icon ui-icon ui-icon-carat-2-n-s ui-icon-triangle-1-n']";
	public static String receiptNoAscSortLink = "xpath#//span[@id='body:inboundList:Inbound:receiptNumber']/../following-sibling::span[@class='ui-sortable-column-icon ui-icon ui-icon ui-icon-carat-2-n-s ui-icon-triangle-1-s']";
	public static String e2bLink = "xpath#//img[contains(@id,'e2bimage')]";
	public static String messageNoLabel = "xpath#//span[@id='body:inboundList:Inbound:0:inboundMsgNoValue']";
	
	public static String lrnGridRowlist = "xpath#//tbody[@id='body:inboundList:Inbound_data']/tr";

	public static String gridElementCombinations(String name) {
		String value = "";
		switch (name) {
		case "Receipt Number":
			value = "a/span";
			break;
		case "LRN Number":
			value = "a[contains(@id,'lrnValue')]/span";
			break;
		case "Medium":
			value = "a/span";
			break;
		}
		return value;

	}

	public static String lrngridData(int rowNum, int columnNum, String columnName) {
		return lrnGridRowlist + "[" + rowNum + "]/td[" + columnNum + "]/" + gridElementCombinations(columnName);
	}
	
	
	

}
