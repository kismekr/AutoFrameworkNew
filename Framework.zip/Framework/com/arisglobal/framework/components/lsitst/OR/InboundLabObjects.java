package com.arisglobal.framework.components.lsitst.OR;

public class InboundLabObjects {
	
	public static String testNameTextbox = "xpath#//div[contains(@class,'ui-panelgrid-cell')]/input[contains(@id,'112104')]";
	public static String testDateTextbox = "xpath#//label[text()='Test date']/../span/span/span[contains(@id,'112103')]";
	public static String testResultTextbox = "xpath#//div[contains(@class,'ui-panelgrid-cell')]/input[contains(@id,'112106')]";

}
