package com.arisglobal.framework.components.lsitst.OR;

public class AERLookupObjects {

	public static String aerLookupIcon = "xpath#//i[@id='lookUpImageAer']";
	public static String aerNumberTextbox = "xpath#//input[@id='body:aerLookup:aerNumber']";
	public static String selectButton = "xpath#//button[@id='body:aerLookup:findButton']";
	public static String cancelButton = "xpath#//button[@id='body:aerLookup:cancelTopButton']";

}
