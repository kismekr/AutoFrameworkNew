package com.arisglobal.framework.components.lsitst.OR;

public class InboundCaseDataObjects {
	
	public static String chooseAssessmentFormDropdown = "xpath#//label[@id='body:inboundForm:chooseAssessmentForm_label']";
	public static String e2bAuthority ="xpath#//label[contains(@id,'body:inboundForm:authorityList_label')]";
}
