package com.arisglobal.framework.components.lsitst.OR;

public class InboundProductObjects {
	
	public static String productLabel = "xpath#//label[text()='Product']";
	public static String productFlagDropdown = "xpath#//label[text()='Product flag']/../span/div/label[contains(@id,'113102_label')]";
	//public static String productDescriptionTextbox = "xpath#//label[text()='Product description']/../span/input[contains(@id,'037548')]";
	
	
	public static String productDescriptionTextbox = "xpath#//label[text()='Product description']//following::input[contains(@onkeypress,'prodCommandLink')][@aria-readonly='true']";
	public static String productLookupIcon = "xpath#//i[@title='Company Product Lookup']";
	public static String lotNoTextbox = "xpath#//input[contains(@id,'113107')]";
	public static String expiryDateTextTextbox = "xpath#//input[contains(@id,'113165')]";
	public static String indicationTermTextbox = "xpath#//textarea[contains(@id,'123004')]";
	public static String routeOfAdminDropdown = "xpath#//label[contains(@id,'122028_label')]";
	public static String formOfAdminTextbox = "xpath#//input[contains(@id, '122032')]";
	public static String unitDoseTextbox = "xpath#//input[contains(@id, '122014')]";
	public static String unitDoseComboDropdown = "xpath#//label[contains(@id,'122016_label')]";
	public static String frequencyTextbox = "xpath#//input[contains(@id, '122022')]";
	public static String frequencyTimeTextbox = "xpath#//input[contains(@id, '122024')]";
	public static String frequenctTimeComboDropdown = "xpath#//label[contains(@id,'122026_label')]";
	public static String dosageTextbox = "xpath#//input[contains(@id, '122012')]";
	public static String therapyStartDateTextbox = "xpath#//input[contains(@id, '122002')]";
	public static String therapyEndDateTextbox = "xpath#//input[contains(@id, '122004')]";
	public static String specialProjectNameDropdown = "xpath#//label[contains(@id,'147103_label')]";
	//public static String productDescriptionLrnSummaryTextbox = "xpath#//label[contains(text(),'Product description')]/following::input[contains(@id,'038090')]";

	
	public static String productDescriptionLrnSummaryTextbox = "xpath#(//label[contains(text(),'Product description')]/following::input[contains(@onkeypress,'prodCommandLink')])";
}
