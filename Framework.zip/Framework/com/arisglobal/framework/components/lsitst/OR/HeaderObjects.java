package com.arisglobal.framework.components.lsitst.OR;

public class HeaderObjects {

	public static String removeButton = "xpath#//label[contains(.,'Remove')]";
	public static String saveButton = "xpath#//label[text()='Save']";
	public static String cancelButton = "xpath#//label[contains(.,'Cancel')]";
	public static String completeActivityIcon = "xpath#//img[contains(@src,'cactivity.svg')]";
	public static String replicateIcon = "xpath#//img[@id='body:inboundForm:replicateLink']";

}
