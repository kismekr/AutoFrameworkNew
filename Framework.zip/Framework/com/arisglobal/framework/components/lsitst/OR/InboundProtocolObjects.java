package com.arisglobal.framework.components.lsitst.OR;

public class InboundProtocolObjects {

	public static String protocolNoTextbox = "xpath#//input[@id='body:studyLookup:studyNameFind']";
	public static String statusDropdown = "xpath#//label[contains(@id,'body:studyLookup:stuudyStatusFilter_label')]";
	public static String searchButton = "xpath#//span[@class='ui-button-text ui-c'][contains(.,'Search')]";
	public static String cancelButton = "xpath#//button[@id='body:studyLookup:cancelTopButton']";

}
