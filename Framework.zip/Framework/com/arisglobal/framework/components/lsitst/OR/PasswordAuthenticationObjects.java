package com.arisglobal.framework.components.lsitst.OR;

public class PasswordAuthenticationObjects {

	public static String passwordTextBox = "xpath#//input[contains(@id,'password1')]";
	public static String submitButton = "xpath#//button[contains(@id,'Save1')]";

}
