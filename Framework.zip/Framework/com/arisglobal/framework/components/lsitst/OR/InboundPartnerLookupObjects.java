package com.arisglobal.framework.components.lsitst.OR;

public class InboundPartnerLookupObjects {
	
	public static String partnerIDTextbox = "xpath#//input[@id='body:partnerLookup:partnerId']";
	public static String partnerIDRadioButton = "xpath#//span[@id='body:partnerLookup:searchPartnerTableId:0:partnerIdValue']/preceding::div[1]";
	public static String searchButton = "xpath#//span[@class='ui-button-text ui-c'][contains(.,'Search')]";
	public static String cancelButton = "xpath#//label[contains(.,'Cancel')]";
	public static String selectButton = "xpath#//button[@id='body:partnerLookup:AddButton']";
}
