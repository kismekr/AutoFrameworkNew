package com.arisglobal.framework.components.lsitst.OR;

public class InboundReporterObjects {

	public static String reporterDetailsLabel = "xpath#//label[text()='Reporter Details']";
	public static String titleTextbox = "xpath#//input[contains(@id, '105102')]";
	public static String firstNameTextbox = "xpath#//input[contains(@id, '105104')]";
	public static String middleInitialsTextbox = "xpath#//input[contains(@id, '105106')]";
	public static String lastNameTextbox = "xpath#//input[contains(@id, '105108')]";
	public static String departmentTextbox = "xpath#//input[contains(@id, '105112')]";
	public static String hospitalNameTextbox = "xpath#//input[contains(@id, '105110')]";
	public static String address1Textbox = "xpath#//input[contains(@id, '105114')]";
	public static String cityTextbox = "xpath#//input[contains(@id, '105116')]";
	public static String stateTextbox = "xpath#//input[contains(@id, '105118')]";
	public static String zipCodeTextbox = "xpath#//input[contains(@id, '105120')]";
	public static String reporterCountryDropdown = "xpath#//label[contains(@id,'105122_label')]";
	public static String phoneNumberTextbox = "xpath#//input[contains(@id, '105142')]";
	public static String faxNumberTextbox = "xpath#//input[contains(@id, '105141')]";
	public static String emailAddressTextbox = "xpath#//input[contains(@id, '105140')]";
	public static String reporterTypeDropdown = "xpath#//label[contains(@id,'105150_label')]";
	public static String specializationDropdown = "xpath#//label[contains(@id,'105133_label')]";
	public static String occupationTextbox = "xpath#//input[contains(@id, '105132')]";
	public static String isPrimaryReporterDropdown = "xpath#//label[contains(@id,'105138_label')]";
	public static String doNotReportNameDropdown = "xpath#//label[contains(@id,'105136_label')]";
	
	//public static String mITextbox = "xpath#//input[@id='body:inboundForm:tabView:ID_42704311105106']";
	public static String mITextbox = "xpath#//input[@id='body:inboundForm:tabView:ID_42702715105106']";
	


}
