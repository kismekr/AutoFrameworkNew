package com.arisglobal.framework.components.lsitst.OR;

public class InboundSplitObjects {
	
	public static String splitIcon = "xpath#//img[@id='body:inboundForm:splitImage']";

}
