package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundGeneralDetailsObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundOnlineBasicInfoObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundPartnerLookupObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;

public class InboundOnlineEntryCommon extends ToolManager {

	static String className = InboundOnlineEntryCommon.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Enter Online screen information.
	 * @Input Parameters: scenarioName.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setBasicInformation(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		if (Multimaplibraries.getTestDataCellValue(scenarioName, "boolSenderLookup").equalsIgnoreCase("true")) {
			agClick(InboundGeneralDetailsObjects.senderLookup);
			agSetValue(InboundPartnerLookupObjects.partnerIDTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Sender"));
			agClick(InboundPartnerLookupObjects.searchButton);
			agClick(CommonObjects.radioButton(Multimaplibraries.getTestDataCellValue(scenarioName, "Sender")));
			agClick(InboundPartnerLookupObjects.selectButton);
		} else {
			agSetValue(InboundGeneralDetailsObjects.senderTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Sender"));
		}
		agSetStepExecutionDelay("3000");
		if (Multimaplibraries.getTestDataCellValue(scenarioName, "boolReceiverLookup").equalsIgnoreCase("true")) {
			agClick(InboundGeneralDetailsObjects.receiverLookup);
			agSetValue(InboundPartnerLookupObjects.partnerIDTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Receiver"));
			agClick(InboundPartnerLookupObjects.searchButton);
			agClick(CommonObjects.radioButton(Multimaplibraries.getTestDataCellValue(scenarioName, "Receiver")));
			agClick(InboundPartnerLookupObjects.selectButton);

		} else {
			agSetValue(InboundGeneralDetailsObjects.receiverTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Receiver"));
		}
		agSetStepExecutionDelay("1000");
	}

	/**********************************************************************************************************
	 * @Objective: Upload Supporting document in Online Entry Section.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setSupportingDocument(String scenarioName) {
		String fileName = Multimaplibraries.getTestDataCellValue(scenarioName, "UploadFileName");
		agSetValue(InboundOnlineBasicInfoObjects.supportingDocUploadButton,
				lsitstConstants.LSITST_FileUploadPath + fileName);
		agAssertVisible(InboundOnlineBasicInfoObjects.supportingDocLink);
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
}
