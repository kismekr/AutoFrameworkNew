package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.OutboundNewObjects;
import com.arisglobal.framework.components.lsitst.OR.PartnerLookupObjects;
import com.arisglobal.framework.components.lsitst.OR.ProductLookupObjects;
import com.arisglobal.framework.components.lsitst.OR.ProtocolLookupObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DateOperations;
import com.arisglobal.framework.lib.utils.generic.DateOperations.dateFormat;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class OutboundNew extends ToolManager {
	static String className = OutboundNew.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Enter Outbound Unstructured case data.
	 * @Input Parameters: scenarioName.
	 * @Output Parameters: NA
	 * @author: Sanchit
	 * @Date : 19-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void createOutboundUnStructuredCase(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agX_Common.selectLabelDropdown(OutboundNewObjects.outboundCaseTypeDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Outbound Case Type"));
		if ((Multimaplibraries.getTestDataCellValue(scenarioName, "BoolRecipientLookp").equalsIgnoreCase("true"))) {
			agClick(OutboundNewObjects.recipientLookup);
			agSetValue(PartnerLookupObjects.nameTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Recipient"));
			agX_Common.selectLabelDropdown(PartnerLookupObjects.typeDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Type"));
			agX_Common.selectLabelDropdown(PartnerLookupObjects.countryDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Country"));
			agClick(PartnerLookupObjects.searchButton);
			if (Multimaplibraries.getTestDataCellValue(scenarioName, "Bool Local Partner").equalsIgnoreCase("true")) {
				agClick(PartnerLookupObjects.localPartnersTab);
			} else if (Multimaplibraries.getTestDataCellValue(scenarioName, "Bool Global Partner")
					.equalsIgnoreCase("true")) {
				agClick(PartnerLookupObjects.globalPartnersTab);
			}
			agClick(CommonObjects.radioButton(Multimaplibraries.getTestDataCellValue(scenarioName, "Recipient")));
			agClick(PartnerLookupObjects.selectButton);
		} else {
			agSetValue(OutboundNewObjects.recipientTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Recipient"));
		}
		agX_Common.selectLabelDropdown(OutboundNewObjects.reportTypeDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Report Type"));
		agSetValue(OutboundNewObjects.submissionDueDateTextbox, DateOperations.getDateByInputData(dateFormat.ddMMMyyyy, Multimaplibraries.getTestDataCellValue(scenarioName, "Submission Due Date")));
		agClick(CommonObjects.calenderCloseButton);
		agX_Common.selectLabelDropdown(OutboundNewObjects.unStructuredFormatDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Format"));
		agX_Common.selectLabelDropdown(OutboundNewObjects.unStructuredMediumDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Medium"));
		agX_Common.selectLabelDropdown(OutboundNewObjects.languageDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Language"));
		agSetValue(OutboundNewObjects.latestReceiptDateTextbox, DateOperations.getDateByInputData(dateFormat.ddMMMyyyy, Multimaplibraries.getTestDataCellValue(scenarioName, "Latest Receipt Date")));
		agClick(CommonObjects.calenderCloseButton);
		agSetValue(OutboundNewObjects.patientIDTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Patient ID"));
		agX_Common.selectLabelDropdown(OutboundNewObjects.countryOfDetectionDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Country Of Detection"));
		agX_Common.selectLabelDropdown(OutboundNewObjects.primarySourceCountryDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Primary Source Country"));
		agX_Common.selectLabelDropdown(OutboundNewObjects.seriousnessDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Seriousness"));
		agX_Common.selectLabelDropdown(OutboundNewObjects.medicallyConfirmedDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Medically Confirmed"));
		agSetValue(OutboundNewObjects.primaryReporterTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Primary Reporter"));
		if (Multimaplibraries.getTestDataCellValue(scenarioName, "Bool Product Lookup").equalsIgnoreCase("true")) {
			agX_Common.selectLabelDropdown(ProductLookupObjects.productTypeDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Product Type"));
			agSetValue(ProductLookupObjects.preferredProdDescTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Product"));
			agClick(ProductLookupObjects.searchButton);
			agClick(CommonObjects.radioButton(Multimaplibraries.getTestDataCellValue(scenarioName, "Product")));
			agClick(ProductLookupObjects.selectButton);
		} else {
			agSetValue(OutboundNewObjects.productTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Product"));
		}
		agSetValue(OutboundNewObjects.EventTextbox, Multimaplibraries.getTestDataCellValue(scenarioName, "Event"));
		if (Multimaplibraries.getTestDataCellValue(scenarioName, "BoolProtocolLookp").equalsIgnoreCase("true")) {
			agClick(OutboundNewObjects.protocolNoLkpIcon);
			agSetValue(ProtocolLookupObjects.protocolNoTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Protocol No. (Study No.)"));
			agX_Common.selectLabelDropdown(ProtocolLookupObjects.statusDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Status"));
			agClick(ProtocolLookupObjects.searchButton);
			agClick(CommonObjects
					.radioButton(Multimaplibraries.getTestDataCellValue(scenarioName, "Protocol No. (Study No.)")));
			agClick(ProtocolLookupObjects.selectButton);
		} else {
			agSetValue(OutboundNewObjects.protocolNoTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Protocol No. (Study No.)"));
		}
		String sourceDocument = Multimaplibraries.getTestDataCellValue(scenarioName, "FileName");
		agSetValue(OutboundNewObjects.sourceDocUploadButton, lsitstConstants.LSITST_FileUploadPath + sourceDocument);
		agSetStepExecutionDelay("1000");
		agAssertVisible(CommonObjects.linkText(sourceDocument));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("Outbound Case", Status.INFO, "Outbound Unstructred Case Details", true);
		agClick(OutboundNewObjects.submitButton);
	}

	/**********************************************************************************************************
	 * @Objective: Enter Outbound Structured case data.
	 * @Input Parameters: scenarioName.
	 * @Output Parameters: NA
	 * @author: Naresh
	 * @Date : 23-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void createOutboundStructuredCase(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agX_Common.selectLabelDropdown(OutboundNewObjects.outboundCaseTypeDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Outbound Case Type"));
		if ((Multimaplibraries.getTestDataCellValue(scenarioName, "BoolRecipientLookp").equalsIgnoreCase("true"))) {
			agClick(OutboundNewObjects.recipientLookup);
			agSetValue(PartnerLookupObjects.nameTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Recipient"));
			agX_Common.selectLabelDropdown(PartnerLookupObjects.typeDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Type"));
			agX_Common.selectLabelDropdown(PartnerLookupObjects.countryDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Country"));
			agClick(PartnerLookupObjects.searchButton);
			if (Multimaplibraries.getTestDataCellValue(scenarioName, "Bool Local Partner").equalsIgnoreCase("true")) {
				agClick(PartnerLookupObjects.localPartnersTab);
			} else if (Multimaplibraries.getTestDataCellValue(scenarioName, "Bool Global Partner")
					.equalsIgnoreCase("true")) {
				agClick(PartnerLookupObjects.globalPartnersTab);
			}
			agClick(CommonObjects.radioButton(Multimaplibraries.getTestDataCellValue(scenarioName, "Recipient")));
			agClick(PartnerLookupObjects.selectButton);
		} else {
			agSetValue(OutboundNewObjects.recipientTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Recipient"));
		}
		agX_Common.selectLabelDropdown(OutboundNewObjects.reportTypeDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Report Type"));
		agSetValue(OutboundNewObjects.submissionDueDateTextbox, DateOperations.getDateByInputData(dateFormat.ddMMMyyyy, Multimaplibraries.getTestDataCellValue(scenarioName, "Submission Due Date")));
		agClick(CommonObjects.calenderCloseButton);
		agX_Common.selectLabelDropdown(OutboundNewObjects.structuredFormatDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Format"));
		agX_Common.selectLabelDropdown(OutboundNewObjects.structuredMediumDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Medium"));
		String sourceDocument = Multimaplibraries.getTestDataCellValue(scenarioName, "FileName");
		agSetValue(OutboundNewObjects.sourceDocUploadButton, lsitstConstants.LSITST_FileUploadPath + sourceDocument);
		agSetStepExecutionDelay("1000");
		agAssertVisible(CommonObjects.linkText(sourceDocument));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		Reports.ExtentReportLog("Outbound Case", Status.INFO, "Outbound Structred Case Details", true);
		agClick(OutboundNewObjects.submitButton);
	}
}
