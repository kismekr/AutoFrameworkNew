package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundReporterObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class ReporterTab extends ToolManager {

	static String className = ReporterTab.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Enter Reporter information.
	 * @Input Parameters: scenarioName, noOfExtraRecords.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setReporterDetails(String scenarioName, int noOfExtraRecords) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String multiScenario;
		for (int i = 1; i <= noOfExtraRecords; i++) {
			if (noOfExtraRecords == 1) {
				multiScenario = scenarioName;
			} else {
				multiScenario = scenarioName + i;
			}
			agSetValue(InboundReporterObjects.titleTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Title"));
			agSetValue(InboundReporterObjects.firstNameTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "First Name"));
			agSetValue(InboundReporterObjects.middleInitialsTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Middle Name"));
			agSetValue(InboundReporterObjects.lastNameTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Last Name"));
			agSetValue(InboundReporterObjects.departmentTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Department"));
			agSetValue(InboundReporterObjects.hospitalNameTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Hospital"));
			agSetValue(InboundReporterObjects.address1Textbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Address1"));
			agSetValue(InboundReporterObjects.cityTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "City"));
			agSetValue(InboundReporterObjects.stateTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "State"));
			agSetValue(InboundReporterObjects.zipCodeTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Zip Code"));
			if (i != noOfExtraRecords) {
				agX_Common.formRecordNavigation("Reporter Details", "Next Record");
			}
		}
		Reports.ExtentReportLog("Reporter tab data", Status.INFO, "Added reporter details", false);
		agX_Common.takeScreenShot(CommonObjects.labelText("Reporter Details"));
	}

	/**********************************************************************************************************
	 * @Objective: Verify Reporter information.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyReporterDetails(String scenarioName, int noOfExtraRecords) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String multiScenario;
		for (int i = 1; i <= noOfExtraRecords; i++) {
			if (noOfExtraRecords == 1) {
				multiScenario = scenarioName;
			} else {
				multiScenario = scenarioName + i;
			}
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Title"),
					InboundReporterObjects.titleTextbox);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "First Name"),
					InboundReporterObjects.firstNameTextbox);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Middle Name"),
					InboundReporterObjects.middleInitialsTextbox);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Last Name"),
					InboundReporterObjects.lastNameTextbox);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Department"),
					InboundReporterObjects.departmentTextbox);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Hospital"),
					InboundReporterObjects.hospitalNameTextbox);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Address1"),
					InboundReporterObjects.address1Textbox);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "City"),
					InboundReporterObjects.cityTextbox);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "State"),
					InboundReporterObjects.stateTextbox);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Zip Code"),
					InboundReporterObjects.zipCodeTextbox);
			agX_Common.takeScreenShot(CommonObjects.labelText("Reporter Details"));
			if (i != noOfExtraRecords) {
				agX_Common.formRecordNavigation("Reporter Details", "Next Record");
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
}
