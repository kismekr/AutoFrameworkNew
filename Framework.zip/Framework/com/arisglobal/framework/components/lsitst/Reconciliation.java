package com.arisglobal.framework.components.lsitst;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.arisglobal.framework.components.lsitst.OR.InboundReconciliationObjects;
import com.arisglobal.framework.components.lssmv.DocsManagement;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class Reconciliation extends ToolManager {

	static String className = Reconciliation.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: This method is used for generating report in Reconciliation
	 *             window
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void generateReport(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agX_Common.selectLabelDropdown(InboundReconciliationObjects.mediumDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Medium"));
		agJavaScriptExecuctorSendKeys(InboundReconciliationObjects.fromTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "FromDate"));
		agJavaScriptExecuctorSendKeys(InboundReconciliationObjects.toTextBox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "ToDate"));
		agClick(InboundReconciliationObjects.generateButton);
	}

	/**********************************************************************************************************
	 * @Objective: This method is used for verifying the generated report contains
	 *             data
	 * @Input Parameters: Na
	 * @Output Parameters: NA
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @Updated by and when:
	 **********************************************************************************************************/

	public static void verifyReportGeneration() {
		while (agIsVisible(InboundReconciliationObjects.noRecordsFound)) {
			agClick(InboundReconciliationObjects.backButton);
			agClick(InboundReconciliationObjects.generateButton);
		}
		agClick(InboundReconciliationObjects.sortRecivedDate);

	}

	/**********************************************************************************************************
	 * @Objective: This method is used for fetching receiptNumber from
	 *             Reconciliation report
	 * @Input Parameters: NA
	 * @Output Parameters: NA
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String fetchReceiptnumber(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		int count = 0;
		String receiptNumber = "";
		for (int receiptrow = 1; receiptrow <= agGetElementList(InboundReconciliationObjects.tableId)
				.size(); receiptrow++) {
			String value = agGetText(InboundReconciliationObjects.reconciliationResultTable(receiptrow, 1));
			String date = agGetText(InboundReconciliationObjects.reconciliationResultTable(receiptrow, 4));

			System.out.println("*" + value + "*");
			if (value.endsWith(Multimaplibraries.getTestDataCellValue(scenarioName, "Sender") + ")")) {
				receiptNumber = agGetText(InboundReconciliationObjects.reconciliationResultTable(receiptrow, 5));
				count = count + 1;
				break;
			}
		}

		if (receiptNumber.length() > 0) {
			Reports.ExtentReportLog("Receipt is generation", Status.PASS, receiptNumber + " :: Succesfull", true);
			DocsManagement.setData(scenarioName, "SourceDocuments", receiptNumber);
		} else {
			Reports.ExtentReportLog("Receipt is generation", Status.FAIL, "Receipt generation failed :: UnSuccesfull",
					true);
		}
		return receiptNumber;
	}

	/**********************************************************************************************************
	 * @Objective: Sending mail to application from local systen
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void sendingMail() {
		try {
			Runtime.getRuntime().exec("wscript " + System.getProperty("user.dir")
					+ "\\Scripts\\com\\arisglobal\\scripts\\testdata\\lsitst\\FileUploads\\SendingMailFromLocalSystem.vbs");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * public static String currentTime() { DateTimeFormatter dtf =
	 * DateTimeFormatter.ofPattern("HH:mm"); LocalDateTime now =
	 * LocalDateTime.now(); return dtf.format(now); }
	 */

	/**********************************************************************************************************
	 * @Objective: Sending mail to application from local system
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Sagar
	 * @Date : 03/02/2020
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void sendingMailOQ() {
		try {
			Runtime.getRuntime().exec("wscript " + System.getProperty("user.dir")
					+ "\\Scripts\\com\\arisglobal\\scripts\\testdata\\lsmv\\SendingMailFromLocalSystem.vbs");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
