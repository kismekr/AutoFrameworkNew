package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundGeneralObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DateOperations;
import com.arisglobal.framework.lib.utils.generic.DateOperations.dateFormat;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class GeneralTab extends ToolManager {

	static String className = GeneralTab.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Enter AER information.
	 * @Input Parameters: scenarioName.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setAERInformation(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agSetValue(InboundGeneralObjects.initialReceivedDateTextbox, DateOperations.getDateByInputData(
				dateFormat.ddMMMyyyy, Multimaplibraries.getTestDataCellValue(scenarioName, "Intial Received Date")));
		agSetValue(InboundGeneralObjects.latestReceivedDateTextbox, DateOperations.getDateByInputData(
				dateFormat.ddMMMyyyy, Multimaplibraries.getTestDataCellValue(scenarioName, "Latest Received Date")));
		Reports.ExtentReportLog("Add General tab data", Status.INFO, "Added AER information data", false);
		agX_Common.takeScreenShot(CommonObjects.labelText("AER Information"));
	}

	/**********************************************************************************************************
	 * @Objective: Verify AER information.
	 * @Input Parameters: scenarioName.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyAERInformation(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agCheckPropertyValue("value",
				DateOperations.getDateByInputData(dateFormat.ddMMMyyyy,
						Multimaplibraries.getTestDataCellValue(scenarioName, "Intial Received Date")),
				InboundGeneralObjects.initialReceivedDateTextbox);
		agCheckPropertyValue("value",
				DateOperations.getDateByInputData(dateFormat.ddMMMyyyy,
						Multimaplibraries.getTestDataCellValue(scenarioName, "Latest Received Date")),
				InboundGeneralObjects.initialReceivedDateTextbox);
		agX_Common.takeScreenShot(CommonObjects.labelText("AER Information"));
	}

	/**********************************************************************************************************
	 * @Objective: Enter Report information.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setReportInformation(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agX_Common.selectLabelDropdown(InboundGeneralObjects.medicallyConfirmedDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Medically Confirmed"));
		agX_Common.selectLabelDropdown(InboundGeneralObjects.reportTypeDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Report Type"));
		agSetValue(InboundGeneralObjects.otherReferenceNoTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Other Reference No"));
		agX_Common.selectLabelDropdown(InboundGeneralObjects.subReportTypeDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Sub Report Type"));
		agX_Common.clickCheckBoxRightOf("Product Complaint",
				Multimaplibraries.getTestDataCellValue(scenarioName, "Bool Product Complaint"));
		Reports.ExtentReportLog("Add Report tab data", Status.INFO, "Added Reporter information", false);
		agX_Common.takeScreenShot(CommonObjects.labelText("Report Information"));
	}

	/**********************************************************************************************************
	 * @Objective: Vefiy Report information.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyReportInformation(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agCheckPropertyText(Multimaplibraries.getTestDataCellValue(scenarioName, "Medically Confirmed"),
				InboundGeneralObjects.medicallyConfirmedDropdown);
		agCheckPropertyText(Multimaplibraries.getTestDataCellValue(scenarioName, "Report Type"),
				InboundGeneralObjects.reportTypeDropdown);
		agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(scenarioName, "Other Reference No"),
				InboundGeneralObjects.otherReferenceNoTextbox);
		agCheckPropertyText(Multimaplibraries.getTestDataCellValue(scenarioName, "Sub Report Type"),
				InboundGeneralObjects.subReportTypeDropdown);
		agX_Common.verifyCheckBoxRightOf("Product Complaint",
				Multimaplibraries.getTestDataCellValue(scenarioName, "Bool Product Complaint"));
		agX_Common.takeScreenShot(CommonObjects.labelText("Report Information"));
	}

	/**********************************************************************************************************
	 * @Objective: Enter Source information.
	 * @Input Parameters: scenarioName, noOfExtraRecords.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setSource(String scenarioName, int noOfExtraRecords) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String multiScenario;
		for (int i = 1; i <= noOfExtraRecords; i++) {
			if (noOfExtraRecords == 1) {
				multiScenario = scenarioName;
			} else {
				multiScenario = scenarioName + i;
			}
			agX_Common.selectLabelDropdown(InboundGeneralObjects.sourceDropdown,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Source"));
			agSetValue(InboundGeneralObjects.sourceIdentificationNoTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Source Identification Number"));
			Reports.ExtentReportLog("Add General tab data", Status.INFO, "Added Source information", false);
			agX_Common.takeScreenShot(CommonObjects.labelText("Source"));
			if (i != noOfExtraRecords) {
				agX_Common.formRecordNavigation("Source", "Next Record");
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verify Source information.
	 * @Input Parameters: scenarioName, noOfExtraRecords.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifySource(String scenarioName, int noOfExtraRecords) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String multiScenario = null;
		for (int i = 1; i <= noOfExtraRecords; i++) {
			if (noOfExtraRecords == 1) {
				multiScenario = scenarioName;
			} else {
				multiScenario = scenarioName + i;
			}
			agCheckPropertyText(Multimaplibraries.getTestDataCellValue(multiScenario, "Source"),
					InboundGeneralObjects.sourceDropdown);
			agCheckPropertyValue("value",
					Multimaplibraries.getTestDataCellValue(multiScenario, "Source Identification Number"),
					InboundGeneralObjects.sourceIdentificationNoTextbox);
			agX_Common.takeScreenShot(CommonObjects.labelText("Source"));
			if (i != noOfExtraRecords) {
				agX_Common.formRecordNavigation("Source", "Next Record");
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: Enter Linked Reports.
	 * @Input Parameters: scenarioName, noOfExtraRecords.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setLinkedReports(String scenarioName, int noOfExtraRecords) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String multiScenario = null;
		for (int i = 1; i <= noOfExtraRecords; i++) {
			if (noOfExtraRecords == 1) {
				multiScenario = scenarioName;
			} else {
				multiScenario = scenarioName + i;
			}
			agSetValue(InboundGeneralObjects.linkReportNoTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Link Report No"));
			Reports.ExtentReportLog("Add General tab data", Status.INFO, "Added Link Report Number", false);
			agX_Common.takeScreenShot(CommonObjects.labelText("Linked Reports"));
			if (i != noOfExtraRecords) {
				agX_Common.formRecordNavigation("Linked Reports", "Next Record");
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verify Linked Reports.
	 * @Input Parameters: scenarioName, noOfExtraRecords.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyLinkedReports(String scenarioName, int noOfExtraRecords) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String multiScenario;
		for (int i = 1; i <= noOfExtraRecords; i++) {
			if (noOfExtraRecords == 1) {
				multiScenario = scenarioName;
			} else {
				multiScenario = scenarioName + i;
			}
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Link Report No"),
					InboundGeneralObjects.linkReportNoTextbox);
			agX_Common.takeScreenShot(CommonObjects.labelText("Linked Reports"));
			if (i != noOfExtraRecords) {
				agX_Common.formRecordNavigation("Linked Reports", "Next Record");
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
}
