package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.InboundCaseDataObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundClassificationObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class InboundClassification extends ToolManager {

	static String className = InboundClassification.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: To Classify the case.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
//	public static void classifyCase(String scenarioName) {
//		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
//		agSelectByVisibleText(InboundClassificationObjects.selectClassificationDropdown,
//				Multimaplibraries.getTestDataCellValue(scenarioName, "Classification Type"));
//		agSetValue(InboundClassificationObjects.commentsTextbox,
//				Multimaplibraries.getTestDataCellValue(scenarioName, "Comments"));
//		Reports.ExtentReportLog("Classification", Status.INFO, "Case classification", true);
//		agClick(InboundClassificationObjects.nextButton);
//		if (agIsVisible(InboundCaseDataObjects.chooseAssessmentFormDropdown)) {
//			Reports.ExtentReportLog("Classification", Status.PASS, "Classified case successfully", true);
//		} else {
//			Reports.ExtentReportLog("Classification", Status.FAIL, "Failed to Classify case", true);
//		}
//	}

	
public static void classifyCase(String scenarioName) {
		
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		
		switch (Multimaplibraries.getTestDataCellValue(scenarioName, "Classification Type")){
		
		case "New":
			agSelectByVisibleText(InboundClassificationObjects.selectClassificationDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Classification Type"));
			
			agSetValue(InboundClassificationObjects.commentsTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Comments"));
			
			Reports.ExtentReportLog("Classification", Status.INFO, "Case classification", true);
			agClick(InboundClassificationObjects.nextButton);
			
			if (agIsVisible(InboundCaseDataObjects.chooseAssessmentFormDropdown)) {
				Reports.ExtentReportLog("Classification", Status.PASS, "Classified case successfully", true);
			} else {
				Reports.ExtentReportLog("Classification", Status.FAIL, "Failed to Classify case", true);
			}
			break;
			
		case "E2B_Follow-up ":
			agSelectByVisibleText(InboundClassificationObjects.selectClassificationDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Classification Type"));
			
			agSetValue(InboundClassificationObjects.commentsTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Comments"));
			
			agSelectByVisibleText(InboundClassificationObjects.chooseVerTypeDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Choose Version Type"));
			
			agSetValue(InboundClassificationObjects.aerNumberTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "AER Number"));
			
			agSetValue(InboundClassificationObjects.lrnNumberTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "LRN Number"));
			
			Reports.ExtentReportLog("Classification", Status.INFO, "Case classification", true);
			agClick(InboundClassificationObjects.nextButton);
			
			if (agIsVisible(InboundCaseDataObjects.e2bAuthority)) {
				Reports.ExtentReportLog("Classification", Status.PASS, "Classified case successfully", true);
			} else {
				Reports.ExtentReportLog("Classification", Status.FAIL, "Failed to Classify case", true);
			}
			break;
			
		case "Follow-up":
			agSelectByVisibleText(InboundClassificationObjects.selectClassificationDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Classification Type"));
			
			agSetValue(InboundClassificationObjects.commentsTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Comments"));
			
			/*agSelectByVisibleText(InboundClassificationObjects.chooseVerTypeDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Choose Version Type"));*/
			
			
			agX_Common.selectLabelDropdown(InboundClassificationObjects.chooseVerTypeDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Choose Version Type"));
			
			agSetValue(InboundClassificationObjects.aerNumberTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "AER Number"));
			
			agSetValue(InboundClassificationObjects.lrnNumberTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "LRN Number"));
			
			Reports.ExtentReportLog("Classification", Status.INFO, "Case classification", true);
			agClick(InboundClassificationObjects.nextButton);
			
			if (agIsVisible(InboundCaseDataObjects.chooseAssessmentFormDropdown)) {
				Reports.ExtentReportLog("Classification", Status.PASS, "Classified case successfully", true);
			} else {
				Reports.ExtentReportLog("Classification", Status.FAIL, "Failed to Classify case", true);
			}
			break;	
			
		case "Duplicate":
			agSelectByVisibleText(InboundClassificationObjects.selectClassificationDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Classification Type"));
			
			agSetValue(InboundClassificationObjects.commentsTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Comments"));
			
			agSelectByVisibleText(InboundClassificationObjects.specifyReasonDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Specify Reason"));
			
			agSetValue(InboundClassificationObjects.aerNumberTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "AER Number"));
			
			agSetValue(InboundClassificationObjects.lrnNumberTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "LRN Number"));
			
			Reports.ExtentReportLog("Classification", Status.INFO, "Case classification", true);
			agClick(InboundClassificationObjects.nextButton);
			
			if (agIsVisible(InboundCaseDataObjects.chooseAssessmentFormDropdown)) {
				Reports.ExtentReportLog("Classification", Status.PASS, "Classified case successfully", true);
			} else {
				Reports.ExtentReportLog("Classification", Status.FAIL, "Failed to Classify case", true);
			}
			break;	
			
		case "Append to existing":
			agSelectByVisibleText(InboundClassificationObjects.selectClassificationDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Classification Type"));
			
			agSetValue(InboundClassificationObjects.commentsTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Comments"));
			
			agSetValue(InboundClassificationObjects.aerNumberTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "AER Number"));
			
			agSetValue(InboundClassificationObjects.lrnNumberTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "LRN Number"));
			
			Reports.ExtentReportLog("Classification", Status.INFO, "Case classification", true);
			agClick(InboundClassificationObjects.nextButton);
			
			if (agIsVisible(InboundCaseDataObjects.chooseAssessmentFormDropdown)) {
				Reports.ExtentReportLog("Classification", Status.PASS, "Classified case successfully", true);
			} else {
				Reports.ExtentReportLog("Classification", Status.FAIL, "Failed to Classify case", true);
			}
			break;
			
		case "Query":
			agSelectByVisibleText(InboundClassificationObjects.selectClassificationDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Classification Type"));
			
			agSetValue(InboundClassificationObjects.commentsTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Comments"));
			
			agSetValue(InboundClassificationObjects.aerNumberTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "AER Number"));
			
			agSetValue(InboundClassificationObjects.lrnNumberTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "LRN Number"));
			
			Reports.ExtentReportLog("Classification", Status.INFO, "Case classification", true);
			agClick(InboundClassificationObjects.nextButton);
			
			if (agIsVisible(InboundCaseDataObjects.chooseAssessmentFormDropdown)) {
				Reports.ExtentReportLog("Classification", Status.PASS, "Classified case successfully", true);
			} else {
				Reports.ExtentReportLog("Classification", Status.FAIL, "Failed to Classify case", true);
			}
			break;
		}			
	}
	/**********************************************************************************************************
	 * @Objective: Enter Duplicate Search information.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setDuplicateSearchCriteria(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agJavaScriptExecuctorSendKeys(InboundClassificationObjects.patientInitialsTextbox,
				PatientTab.getData(scenarioName, "Patient Initials"));
		agJavaScriptExecuctorScrollToElement(InboundClassificationObjects.patientInitialsTextbox);
		Reports.ExtentReportLog("Duplicate Search", Status.INFO, "Duplicate Search Criteria", true);
		agClick(InboundClassificationObjects.searchButton);
		agAssertVisible(InboundClassificationObjects.duplicateSearchResultTabLabel);
		agJavaScriptExecuctorScrollToElement(InboundClassificationObjects.duplicateSearchResultTabLabel);
		Reports.ExtentReportLog("Duplicate Search", Status.INFO, "Duplicate Search Criteria Results", true);
		agClick(InboundClassificationObjects.proceedButton);
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
}
