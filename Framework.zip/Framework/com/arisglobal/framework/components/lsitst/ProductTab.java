package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundProductObjects;
import com.arisglobal.framework.components.lsitst.OR.ProductLookupObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DateOperations;
import com.arisglobal.framework.lib.utils.generic.DateOperations.dateFormat;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class ProductTab extends ToolManager {

	static String className = ProductTab.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Enter Product information.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setProductInfo(String scenarioName, int noOfExtraRecords) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String multiScenario;
		for (int i = 1; i <= noOfExtraRecords; i++) {
			if (noOfExtraRecords == 1) {
				multiScenario = scenarioName;
			} else {
				multiScenario = scenarioName + i;
			}
			agX_Common.selectLabelDropdown(InboundProductObjects.productFlagDropdown,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Product Type"));
			agClick(InboundProductObjects.productLookupIcon);
			agSetValue(ProductLookupObjects.preferredProdDescTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Product Description"));
			agClick(ProductLookupObjects.searchButton);
			agSetGlobalTimeOut("60");
			agSetStepExecutionDelay("1000");
			if (agIsVisible(ProductLookupObjects.selectButton)) {
				agClick(CommonObjects
						.radioButton(Multimaplibraries.getTestDataCellValue(multiScenario, "Product Description")));
				agClick(ProductLookupObjects.selectButton);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				agWaitTillInvisibilityOfElement(ProductLookupObjects.selectButton);
			}
			agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
			agSetValue(InboundProductObjects.lotNoTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Lot No"));
			agSetValue(InboundProductObjects.expiryDateTextTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Expiry Date Text"));
			Reports.ExtentReportLog("Product tab data", Status.INFO, "Added product information", false);
			agX_Common.takeScreenShot(CommonObjects.labelText("Product"));
			if (i != noOfExtraRecords) {
				agX_Common.formRecordNavigation("Product", "Next Record");
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: Verify Product information.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyProductInfo(String scenarioName, int noOfExtraRecords) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String multiScenario;
		for (int i = 1; i <= noOfExtraRecords; i++) {
			if (noOfExtraRecords == 1) {
				multiScenario = scenarioName;
			} else {
				multiScenario = scenarioName + i;
			}
			agCheckPropertyText(Multimaplibraries.getTestDataCellValue(multiScenario, "Product Type"),
					InboundProductObjects.productFlagDropdown);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Product Description"),
					InboundProductObjects.productDescriptionTextbox);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Lot No"),
					InboundProductObjects.lotNoTextbox);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Expiry Date Text"),
					InboundProductObjects.expiryDateTextTextbox);
			agX_Common.takeScreenShot(CommonObjects.labelText("Product"));
			if (i != noOfExtraRecords) {
				agX_Common.formRecordNavigation("Product", "Next Record");
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verify Product Summary information.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyProductSummaryInfo(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agCheckPropertyText(Multimaplibraries.getTestDataCellValue(scenarioName, "Product Type"),
				InboundProductObjects.productFlagDropdown);
		agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(scenarioName, "Product Description"),
				agX_Common.uniqueXpath(InboundProductObjects.productDescriptionLrnSummaryTextbox));
	}

	/**********************************************************************************************************
	 * @Objective: Enter Theraphy Details.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 11-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setTheraptyDetails(String scenarioName, int noOfExtraRecords) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String multiScenario;
		for (int i = 1; i <= noOfExtraRecords; i++) {
			if (noOfExtraRecords == 1) {
				multiScenario = scenarioName;
			} else {
				multiScenario = scenarioName + i;
			}
			agX_Common.selectLabelDropdown(InboundProductObjects.routeOfAdminDropdown,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Route of Admin Text"));
			agSetValue(InboundProductObjects.formOfAdminTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Form of Admin Text"));
			agSetValue(InboundProductObjects.unitDoseTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Unit Dose"));
			agX_Common.selectLabelDropdown(InboundProductObjects.unitDoseComboDropdown,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Unit Dose Combo"));
			agSetValue(InboundProductObjects.frequencyTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Frequency"));
			agSetValue(InboundProductObjects.frequencyTimeTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Frequency Time"));
			agX_Common.selectLabelDropdown(InboundProductObjects.frequenctTimeComboDropdown,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Frequency Time Combo"));
			agSetValue(InboundProductObjects.dosageTextbox,
					Multimaplibraries.getTestDataCellValue(multiScenario, "Dosage Text"));
			agSetValue(InboundProductObjects.therapyStartDateTextbox, DateOperations.getDateByInputData(
					dateFormat.ddMMMyyyy, Multimaplibraries.getTestDataCellValue(multiScenario, "Therapy Start Date")));
			agSetValue(InboundProductObjects.therapyEndDateTextbox, DateOperations.getDateByInputData(
					dateFormat.ddMMMyyyy, Multimaplibraries.getTestDataCellValue(multiScenario, "Therapy End Date")));
			Reports.ExtentReportLog("Add Product tab data", Status.INFO, "Added Therapy Details", false);
			agX_Common.takeScreenShot(CommonObjects.labelText("Therapy Details"));
			if (i != noOfExtraRecords) {
				agX_Common.formRecordNavigation("Therapy Details", "Next Record");
			}
		}

	}

	/**********************************************************************************************************
	 * @Objective: Verify Theraphy Details.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 11-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyTheraptyDetails(String scenarioName, int noOfExtraRecords) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String multiScenario;
		for (int i = 1; i <= noOfExtraRecords; i++) {
			if (noOfExtraRecords == 1) {
				multiScenario = scenarioName;
			} else {
				multiScenario = scenarioName + i;
			}
			agCheckPropertyText(Multimaplibraries.getTestDataCellValue(multiScenario, "Route of Admin Text"),
					InboundProductObjects.routeOfAdminDropdown);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Form of Admin Text"),
					InboundProductObjects.formOfAdminTextbox);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Unit Dose"),
					InboundProductObjects.unitDoseTextbox);
			agCheckPropertyText(Multimaplibraries.getTestDataCellValue(multiScenario, "Unit Dose Combo"),
					InboundProductObjects.unitDoseComboDropdown);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Frequency"),
					InboundProductObjects.frequencyTextbox);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Frequency Time"),
					InboundProductObjects.frequencyTimeTextbox);
			agCheckPropertyText(Multimaplibraries.getTestDataCellValue(multiScenario, "Frequency Time Combo"),
					InboundProductObjects.frequenctTimeComboDropdown);
			agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(multiScenario, "Dosage Text"),
					InboundProductObjects.dosageTextbox);
			agCheckPropertyValue("value",
					DateOperations.getDateByInputData(dateFormat.ddMMMyyyy,
							Multimaplibraries.getTestDataCellValue(multiScenario, "Therapy Start Date")),
					InboundProductObjects.therapyStartDateTextbox);
			agCheckPropertyValue("value",
					DateOperations.getDateByInputData(dateFormat.ddMMMyyyy,
							Multimaplibraries.getTestDataCellValue(multiScenario, "Therapy End Date")),
					InboundProductObjects.therapyEndDateTextbox);
			agX_Common.takeScreenShot(CommonObjects.labelText("Therapy Details"));
			if (i != noOfExtraRecords) {
				agX_Common.formRecordNavigation("Therapy Details", "Next Record");
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
}
