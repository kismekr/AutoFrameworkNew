package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundPatientObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DateOperations;
import com.arisglobal.framework.lib.utils.generic.DateOperations.dateFormat;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class PatientTab extends ToolManager {

	static String className = PatientTab.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Enter Patient information.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setPatientDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agSetValue(InboundPatientObjects.patientInitialsTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Patient Initials"));
		agSetValue(InboundPatientObjects.weightTextbox, Multimaplibraries.getTestDataCellValue(scenarioName, "Weight"));
		agX_Common.selectLabelDropdown(InboundPatientObjects.weightComboDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Weight Combo"));
		agSetValue(InboundPatientObjects.dateOfBirthTextbox, DateOperations.getDateByInputData(dateFormat.ddMMMyyyy,
				Multimaplibraries.getTestDataCellValue(scenarioName, "DOB")));

		if (!Multimaplibraries.getTestDataCellValue(scenarioName, "DOB").trim().equalsIgnoreCase("#skip#")) {
			agClick(CommonObjects.calenderCloseButton);
		}

		agSetValue(InboundPatientObjects.heightTextbox, Multimaplibraries.getTestDataCellValue(scenarioName, "Height"));
		agSetValue(InboundPatientObjects.heightComboDropdwon,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Height Combo"));
		agSetValue(InboundPatientObjects.ageAtTheTimeOfEventTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Age at the Time of Event"));
		agSetValue(InboundPatientObjects.ageAtTheTimeOfEventDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Age at the Time of Event Combo"));
		agX_Common.selectLabelDropdown(InboundPatientObjects.ethinicOriginDropdwon,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Ethnic Origin"));
		agClick(InboundPatientObjects
				.ageGroupRdoBtn(Multimaplibraries.getTestDataCellValue(scenarioName, "Age Group")));
		agSetValue(InboundPatientObjects.specialistNumberTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Specialist No"));
		agSetValue(InboundPatientObjects.investigationNoTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "GP Medical No"));
		agSetValue(InboundPatientObjects.hospitalNoTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Hospital No"));
		agX_Common.selectLabelDropdown(InboundPatientObjects.sexDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Sex"));
		Reports.ExtentReportLog("Patient tab data", Status.INFO, "Added patient details", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify Patient information.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyPatientDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(scenarioName, "Patient Initials"),
				InboundPatientObjects.patientInitialsTextbox);
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

}
