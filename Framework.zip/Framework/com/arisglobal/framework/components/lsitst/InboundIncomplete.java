package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundIncompletePageObjects;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;

public class InboundIncomplete extends ToolManager {

	static String className = InboundIncomplete.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Get First Receipt Number from Listing Screen.
	 * @Input Parameters: NA
	 * @Output Parameters: Return Receipt Number.
	 * @author: Naresh S
	 * @Date : 06-09-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getIncompleteListingScreenReceiptNumber() {
		String receiptNo = agGetText(InboundIncompletePageObjects.receiptNumberLink);
		return receiptNo;
	}

	/**********************************************************************************************************
	 * @Objective: Click and Select E2B Views in Inbound Incomplete E2B Views
	 * @Input Parameters: e2bFormat, verifyXMLTagValue, xmlTagNames, xmlTagValues.
	 * @Output Parameters: NA.
	 * @author: Naresh
	 * @Date : 27-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void selectInboundIncompleteE2BViews(String e2bFormat, boolean verifyXMLTagValue, String xmlTagNames,
			String xmlTagValues) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String caseNumber = InboundIncomplete.getIncompleteListingScreenReceiptNumber();
		agClick(InboundIncompletePageObjects.e2bLink);
		agX_Common.agWaitTillWindowExists("e2b_report");
		agAssertContainsText(CommonObjects.e2bCaseNumberLabel, caseNumber);
		agX_Common.takeScreenShot();
		agX_Common.selectE2BViews(e2bFormat, verifyXMLTagValue, xmlTagNames, xmlTagValues);
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

}
