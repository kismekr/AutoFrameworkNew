package com.arisglobal.framework.components.lsitst;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.HeaderObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundArchiveObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundCaseDataObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundClassificationObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundEventObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundGeneralDetailsObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundGeneralObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundListingObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundNewE2BCaseEntryObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundOnlineBasicInfoObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundOnlineListingObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundPartnerLookupObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundPatientObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundProductObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundReplicateObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundReporterObjects;
import com.arisglobal.framework.components.lsitst.OR.IncompletePageObjects;
import com.arisglobal.framework.components.lsitst.OR.MessageAuditTrailObjects;
import com.arisglobal.framework.components.lsitst.OR.NavigationObjects;
import com.arisglobal.framework.components.lsitst.OR.OutboundGeneralObjects;
import com.arisglobal.framework.components.lsitst.OR.OutboundListingObjects;
import com.arisglobal.framework.components.lsitst.OR.OutboundNewObjects;
import com.arisglobal.framework.components.lsitst.OR.PartnersPageObjects;
import com.arisglobal.framework.components.lsitst.OR.PasswordAuthenticationObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class agX_Common extends ToolManager {

	/**********************************************************************************************************
	 * @Objective: Select Value from label dropdown.
	 * @Input Parameters: element, dropdownValue.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void selectLabelDropdown(String element, String dropdownValue) {
		if (dropdownValue != null && !dropdownValue.trim().equalsIgnoreCase("#skip#")) {
			try {
				agJavaScriptExecuctorScrollToElement(element);
				agClick(element);
				agClick(CommonObjects.dropDownLabelValue(dropdownValue));
			} catch (Exception e) {
				System.out.println("Check the label dropdown ID/Value");
				e.printStackTrace();
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: Click on the link text.
	 * @Input Parameters: text
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void clickLink(linkText text) {
		agClick(CommonObjects.linkText(text.value));
		waitTillLoading();
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Store Enum values for Link Text.
	 * @Input Parameters: NA
	 * @Output Parameters: Return's expected string stored in Enum.
	 * @author: Naresh S
	 * @Date : 03-09-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public enum linkText {
		intakeAndReceipt("Intake And Receipt"), translationAndReview("Translation And Review"), triage(
				"Triage"), failedToImport("Failed To Import"), importedCase("Imported Cases"), unImportedCases(
						"Un-Imported Cases"), hqSubmission("HQ Submission"), localSubmission(
								"Local Submission"), submittedCases(
										"Submitted Cases"), advanceSearch("Advanced Search"),dispositionARISg("Disposition to ARISg");
		private String value;

		linkText(String evalue) {
			this.value = evalue;
		}
	}

	/**********************************************************************************************************
	 * @Objective: To click button objects.
	 * @Input Parameters: buttonName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static boolean buttonOperation(String buttonName) {
		switch (buttonName) {
		case "Create Receipt Item":
			agClick(InboundGeneralDetailsObjects.createReceiptItemButton);
			break;
		case "Remove":
			agClick(HeaderObjects.removeButton);
			break;
		case "Select Partner":
			agClick(InboundPartnerLookupObjects.selectButton);
			break;
		case "SubmitAEForm":
			agClick(InboundOnlineBasicInfoObjects.submitAEForm);
			break;
		case "Replicate":
			agClick(HeaderObjects.replicateIcon);
			agAssertVisible(InboundReplicateObjects.numberOfItemsTextbox);
			break;
		case "Replicate Submit":
			agClick(InboundReplicateObjects.submitButton);
			break;
		case "Save":
			agClick(HeaderObjects.saveButton);
			break;
		case "Close":
			agClick(CommonObjects.closeButton);
			agGetCurrentWindow();
			break;
		case "Search":
			agClick(agX_Common.uniqueXpath(CommonObjects.searchButton));
			agX_Common.waitTillLoading();
			if (agIsVisible(CommonObjects.searchResultsDataRow)) {
				return true;
			} else {
				return false;
			}
		case "Receipt Column Sort Descending":
			agJavaScriptExecuctorScrollToElement(InboundListingObjects.receiptNumberLink);
			agSetStepExecutionDelay("0");
			agSetGlobalTimeOut("0");
			if (agIsVisible(InboundListingObjects.receiptNoDescSortLink)) {
				agClick(agX_Common.uniqueXpath(InboundListingObjects.receiptNoDescSortLink));
				agSetGlobalTimeOut("60");
				agWaitTillInvisibilityOfElement(InboundListingObjects.receiptNoDescSortLink);
			}
			agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			break;
		default:
			Reports.ExtentReportLog("Button operation failed", Status.FAIL,
					"Button with name :" + buttonName + " is not found on the browser", true);
			System.out.println("'" + buttonName + "' Button operation not found");
			break;

		}
		return false;
	}

	/**********************************************************************************************************
	 * @Objective: Menu Navigations.
	 * @Input Parameters: navigationMenuText
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void agX_Navigations(menuName navigationMenuText) {
		switch (navigationMenuText.value) {
		case "Inbound":
			agClick(NavigationObjects.inboundLink);
			break;
		case "Reconciliation":
			agClick(NavigationObjects.reconciliationLink);
			break;	
		case "Default Data Assessment Form":
			agClick(NavigationObjects.defaultDataAssesmentFormLink);
			agAssertVisible(InboundGeneralDetailsObjects.senderLookup);
			break;
		case "Inbound Listing":
			agClick(NavigationObjects.inboundListingLink);
			agX_Common.waitTillLoading();
			agSetStepExecutionDelay("0");
			agAssertVisible(InboundListingObjects.inboundSearchTextbox);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			break;
		case "Case Data":
			agClick(NavigationObjects.caseDataTab);
			//agAssertVisible(InboundCaseDataObjects.chooseAssessmentFormDropdown);
			break;
		case "General":
			agClick(NavigationObjects.generalTab);
			agAssertVisible(InboundGeneralObjects.aerInfoLabel);
			break;
		case "Reporter":
			agClick(NavigationObjects.reporterTab);
			agAssertVisible(InboundReporterObjects.reporterDetailsLabel);
			break;
		case "Patient":
			agClick(NavigationObjects.patientTab);
			agAssertVisible(InboundPatientObjects.patientDetailsLabel);
			break;
		case "Product":
			agClick(NavigationObjects.productTab);
			agAssertVisible(InboundProductObjects.productLabel);
			break;
		case "Event":
			agClick(NavigationObjects.eventTab);
			agAssertVisible(InboundEventObjects.eventLabel);
			break;
		case "Narrative":
			agClick(NavigationObjects.narrativeTab);
			break;
		case "Lab":
			agClick(NavigationObjects.labTab);
			break;
		case "Classification":
			agClick(NavigationObjects.classificationTab);
			agAssertVisible(InboundClassificationObjects.duplicateSearchCriteriaLabel);
			break;
		case "Default Online Form":
			agClick(NavigationObjects.defaultOnlineFormLink);
			agAssertVisible(InboundGeneralDetailsObjects.senderLookup);
			break;
		case "Online Entry":
			agClick(NavigationObjects.onlineEntryLink);
			agAssertVisible(InboundOnlineListingObjects.searchTextbox);
			break;
		case "Inbound Archive":
			agClick(NavigationObjects.inboundArchiveLink);
			agAssertVisible(InboundArchiveObjects.receiptNumberTextbox);
			break;
		case "Default Data Entry Form":
			agClick(NavigationObjects.defaultDataEntryFormLink);
			agAssertVisible(InboundGeneralDetailsObjects.senderLookup);
			break;
		case "Outbound":
			agClick(NavigationObjects.outboundLink);
			break;
		case "Outbound New":
			agClick(NavigationObjects.newLink);
			agAssertVisible(OutboundNewObjects.outboundCaseTypeDropdown);
			break;
		case "SingleCase":
			agClick(NavigationObjects.singleCaseLink);
			agAssertVisible(OutboundListingObjects.outboundSearchButton);
			break;
		case "Outbound General":
			agClick(OutboundGeneralObjects.generalTab);
			agAssertVisible(OutboundGeneralObjects.submissionDueDateTextbox);
			break;
		case "Local Drive":
			agClick(OutboundGeneralObjects.localDriveTab);
			agAssertVisible(OutboundGeneralObjects.documentUploadBtn);
			break;
		case "ARISg Documents":
			agClick(OutboundGeneralObjects.arisgDocumentsTab);
			agAssertVisible(OutboundGeneralObjects.arsigDocAddButton);
			break;
		case "Outbound Template":
			agClick(OutboundGeneralObjects.templateTab);
			agAssertVisible(OutboundGeneralObjects.generateAndAttachBtn);
			break;
		case "New E2B Case Entry":
			agClick(NavigationObjects.newE2BCaseEntryLink);
			agX_Common.waitTillLoading();
			agAssertVisible(InboundNewE2BCaseEntryObjects.createReceiptItemButton);
			break;

		case "Administrator":
			agClick(NavigationObjects.administratorLink);
			break;

		case "MessageAuditTrail":
			agClick(NavigationObjects.msgAuditTrailLink);
			agAssertVisible(MessageAuditTrailObjects.messageTypeDropdown);
			break;

		case "Incomplete":
			agClick(NavigationObjects.incompleteLink);
			agAssertVisible(IncompletePageObjects.incompleteTransactionLink);
			break;

		case "Partners":
			agClick(NavigationObjects.partnersLink);
			agAssertVisible(PartnersPageObjects.addButton);
			break;

		default:
			Reports.ExtentReportLog("Navigation text not found", Status.FAIL,
					"Navigation text :" + navigationMenuText + " is not found on the browser", true);
			break;
		}
	}

	/**********************************************************************************************************
	 * @Objective: Click on complete activity link.
	 * @Input Parameters: text
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void completeActivity(toActivityName text) {
		agMouseHover(HeaderObjects.completeActivityIcon);
		agClick(CommonObjects.linkText(text.value));
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Store Enum values for Complete
	 *             Activity.
	 * @Input Parameters: NA
	 * @Output Parameters: Return's expected string stored in Enum.
	 * @author: Naresh S
	 * @Date : 03-09-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public enum toActivityName {
		toTriage("To Triage"), toTranslationAndReview("To Translation And Review"), toImportedCase(
				"Import_case_to_Safety_System"), toUnimported("To Un-Imported Cases"), toDispose(
						"To Dispose"), toSubmitToAffilate(
								"Submit to Affiliate"), toDoNotDispose("Do not Submit"), toSubmit("Submit");
		private String value;

		toActivityName(String evalue) {
			this.value = evalue;
		}
	}

	/**********************************************************************************************************
	 * @Objective: Enter Password.
	 * @Input Parameters: text
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void passwordAuthentication(String text) {
		if (agIsVisible(PasswordAuthenticationObjects.passwordTextBox)) {
			agSetValue(PasswordAuthenticationObjects.passwordTextBox, text);
			Reports.ExtentReportLog("Password prompt", Status.INFO, "Password prompt", true);
			agClick(PasswordAuthenticationObjects.submitButton);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Navigate between different records in multi record forms field.
	 * @Input Parameters: panelName, navigateTo.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void formRecordNavigation(String panelName, String navigateTo) {
		String currentRecordValue, newRecordValue = null;
		currentRecordValue = agGetAttribute("value", CommonObjects.recordNavigationValue(panelName));
		agSetStepExecutionDelay("500");
		agJavaScriptExecuctorClick(CommonObjects.formTabRecordNavigation(panelName, navigateTo));
		for (int i = 0; i <= lsitstConstants.maxIterateCount; i++) {
			newRecordValue = agGetAttribute("value", CommonObjects.recordNavigationValue(panelName));
			if (!currentRecordValue.equalsIgnoreCase(newRecordValue)) {
				break;
			} else {
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Verify data in the table.
	 * @Input Parameters: Locator, Data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 03-09-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyDataList(String locator, String Data) {
		if (!Data.equalsIgnoreCase("#skip#")) {
			List<WebElement> list1 = new ArrayList<>();
			String ExcelData = Data;
			List<String> list2 = new ArrayList<>();
			list1 = agGetElementList(locator);
			for (WebElement webElement : list1) {
				if (!webElement.getText().isEmpty())
					list2.add(webElement.getText());
			}
			boolean status = false;
			for (String string : list2) {
				if (string.contains(ExcelData)) {
					Reports.ExtentReportLog("Data is Present", Status.PASS, ExcelData, false);
					status = true;
				}
			}
			if (status == false) {
				Reports.ExtentReportLog("Data is missing", Status.FAIL, "Element '" + ExcelData + "' does not exist",
						true);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to wait till loading icon to disappear.
	 * @Input Parameters: NA
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 03-09-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void waitTillLoading() {
		agSetGlobalTimeOut("30");
		agWaitTillInvisibilityOfElement(uniqueXpath(CommonObjects.processingLabel));
		agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
	}

	/**********************************************************************************************************
	 * @Objective:This method is created return unique xpath when indexing is
	 *                 associated.
	 * @Input Parameters: xpath within "()" example: xpath#(//span[text()='Submit'])
	 * @Output Parameters: Return's path
	 * @author: Naresh S
	 * @Date : 03-09-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String uniqueXpath(String xpath) {
		List<WebElement> list = new ArrayList<>();
		list = agGetElementList(xpath);
		agSetGlobalTimeOut("0");
		agSetStepExecutionDelay("0");
		if (agGetElementList(xpath).size() > 1) {
			for (int k = 1; k <= list.size(); k++) {
				if (agIsVisible(xpath + "[" + k + "]")) {
					xpath = xpath + "[" + k + "]";
				}
			}
		}
		agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		System.out.println(xpath);
		return xpath;
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to Store Enum values for Navigation.
	 * @Input Parameters: NA
	 * @Output Parameters: Return's expected string stored in Enum.
	 * @author: Naresh S
	 * @Date : 03-09-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public enum menuName {
		inbound("Inbound"), defaultDataAssessmentForm("Default Data Assessment Form"), inboundListing(
				"Inbound Listing"), caseData("Case Data"), general("General"), reporter("Reporter"), patient(
						"Patient"), product("Product"), event("Event"), narrative("Narrative"), lab(
								"Lab"), classification("Classification"), defaultOnlineForm(
										"Default Online Form"), onlineEntry("Online Entry"), inboundArchive(
												"Inbound Archive"), defaultDataEntryForm(
														"Default Data Entry Form"), singleCase("SingleCase"), outbound(
																"Outbound"), outboundGeneral(
																		"Outbound General"), localDrive(
																				"Local Drive"), arisgDocuments(
																						"ARISg Documents"), outboundTemplates(
																								"Outbound Template"), outboundNew(
																										"Outbound New"), newE2BCaseEntry(
																												"New E2B Case Entry"), administrator(
																														"Administrator"), messageAuditTrail(
																																"MessageAuditTrail"), incomplete(
																																		"Incomplete"), partners(
																																				"Partners"),reconciliation("Reconciliation");
		private String value;

		menuName(String evalue) {
			this.value = evalue;
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to click check box Right of the specified
	 *             label.
	 * @Input Parameters: checkBoxLabel, boolCheck.
	 * @Output Parameters: NA.
	 * @author: Naresh S
	 * @Date : 18-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void clickCheckBoxRightOf(String checkBoxLabel, String boolCheck) {
		if (!boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = agGetAttribute("class", CommonObjects.checkBoxRightOfLabel(checkBoxLabel));
			if (boolCheck.equalsIgnoreCase("true")) {
				if (checkBoxStatus.contains("ui-icon-blank")) {
					agClick(CommonObjects.checkBoxRightOfLabel(checkBoxLabel));
				}
			} else if (boolCheck.equalsIgnoreCase("false")) {
				if (checkBoxStatus.contains("ui-icon-check")) {
					agClick(CommonObjects.checkBoxRightOfLabel(checkBoxLabel));
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to verfiy check box Right of the specified
	 *             label.
	 * @Input Parameters: checkBoxLabel, boolCheck.
	 * @Output Parameters: NA.
	 * @author: Naresh S
	 * @Date : 18-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyCheckBoxRightOf(String checkBoxLabel, String boolCheck) {
		if (!checkBoxLabel.trim().contains("#skip#") && !boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = agGetAttribute("class", CommonObjects.checkBoxRightOfLabel(checkBoxLabel));
			if (boolCheck.equalsIgnoreCase("true")) {
				if (checkBoxStatus.contains("ui-icon-blank")) {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, checkBoxLabel + " : Checkbox is not checked",
							true);
				} else {
					Reports.ExtentReportLog("Checkbox", Status.PASS, checkBoxLabel + " : Checkbox is checked", false);
				}
			} else if (boolCheck.equalsIgnoreCase("false")) {
				if (checkBoxStatus.contains("ui-icon-check")) {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, checkBoxLabel + " : Checkbox is checked", true);
				} else {
					Reports.ExtentReportLog("Checkbox", Status.PASS, checkBoxLabel + " : Checkbox is not checked",
							false);
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to click check box Left of the specified
	 *             label.
	 * @Input Parameters: checkBoxLabel, boolCheck.
	 * @Output Parameters: NA.
	 * @author: Naresh S
	 * @Date : 18-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void clickCheckBoxLeftOf(String checkBoxLabel, String boolCheck) {
		if (!boolCheck.trim().contains("#skip#") && !checkBoxLabel.trim().contains("#skip#")) {
			String checkBoxStatus = agGetAttribute("class", CommonObjects.checkBoxLeftOfLabel(checkBoxLabel));
			if (boolCheck.equalsIgnoreCase("true")) {
				if (checkBoxStatus.contains("ui-icon-blank")) {
					agClick(CommonObjects.checkBoxLeftOfLabel(checkBoxLabel));
				}
			} else if (boolCheck.equalsIgnoreCase("false")) {
				if (checkBoxStatus.contains("ui-icon-check")) {
					agClick(CommonObjects.checkBoxLeftOfLabel(checkBoxLabel));
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to verify check box Left of the specified
	 *             label.
	 * @Input Parameters: checkBoxLabel, boolCheck.
	 * @Output Parameters: NA.
	 * @author: Naresh S
	 * @Date : 18-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyCheckBoxLeftOf(String checkBoxLabel, String boolCheck) {
		if (!checkBoxLabel.trim().contains("#skip#") && !boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = agGetAttribute("class", CommonObjects.checkBoxLeftOfLabel(checkBoxLabel));
			if (boolCheck.equalsIgnoreCase("true")) {
				if (checkBoxStatus.contains("ui-icon-blank")) {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, checkBoxLabel + " : Checkbox is not checked",
							true);
				} else {
					Reports.ExtentReportLog("Checkbox", Status.PASS, checkBoxLabel + " : Checkbox is checked", false);
				}
			} else if (boolCheck.equalsIgnoreCase("false")) {
				if (checkBoxStatus.contains("ui-icon-check")) {
					Reports.ExtentReportLog("Checkbox", Status.FAIL, checkBoxLabel + " : Checkbox is not checked",
							true);
				} else {
					Reports.ExtentReportLog("Checkbox", Status.PASS, checkBoxLabel + " : Checkbox is checked", false);
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to click check box Left of the specified
	 *             text.
	 * @Input Parameters: checkBoxText, boolCheck
	 * @Output Parameters: NA.
	 * @author: Naresh S
	 * @Date : 03-Oct-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void clickCheckBox(String checkBoxText, String boolCheck) {
		if (!checkBoxText.trim().contains("#skip#") && !boolCheck.trim().contains("#skip#")) {
			String checkBoxStatus = agGetAttribute("class", CommonObjects.checkBoxLeftOf(checkBoxText));
			if (boolCheck.equalsIgnoreCase("true")) {
				if (checkBoxStatus.contains("ui-icon-blank")) {
					agClick(CommonObjects.checkBoxLeftOf(checkBoxText));
				}
			} else if (boolCheck.equalsIgnoreCase("false")) {
				if (checkBoxStatus.contains("ui-icon-check")) {
					agClick(CommonObjects.checkBoxLeftOf(checkBoxText));
				}
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to search for the case.
	 * @Input Parameters: searchData.
	 * @Output Parameters: Returns true if search record is found.
	 * @author: Naresh S
	 * @Date : 18-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static boolean basicSearch(String searchData) {
		agJavaScriptExecuctorSendKeys(CommonObjects.basicSearchTextbox, searchData);
		agSetStepExecutionDelay("1000");
		agClick(CommonObjects.basicSearchIcon);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agX_Common.waitTillLoading();
		if (agIsVisible(CommonObjects.searchResultsDataRow)) {
			return true;
		} else {
			return false;
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to search for the case in Inbound
	 *             Incomplete Section.
	 * @Input Parameters: searchData.
	 * @Output Parameters: Returns true if search record is found.
	 * @author: Naresh S
	 * @Date : 18-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static boolean incompleteBasicSearch(String searchData) {
		agJavaScriptExecuctorSendKeys(CommonObjects.basicSearchTextbox, searchData);
		agSetStepExecutionDelay("1000");
		agClick(CommonObjects.basicSearchIcon);
		agIsVisible(CommonObjects.applicationMessage);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agSetGlobalTimeOut("10");
		if (agIsVisible(CommonObjects.incompleteDataRow)) {
			agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
			return true;
		} else {
			agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
			return false;
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to search for the case till visible.
	 * @Input Parameters: searchData.
	 * @Output Parameters: NA.
	 * @author: Naresh S
	 * @Date : 18-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void searchCase(String searchData) {
		for (int i = 0; i <= lsitstConstants.maxIterateCount; i++) {
			boolean searchResults = agX_Common.basicSearch(searchData);
			if (!searchResults) {
				agSetStepExecutionDelay("2500");
				agClick(CommonObjects.basicSearchIcon);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			} else {
				break;
			}
		}
		agAssertVisible(CommonObjects.listingScreenData(searchData));
		agX_Common.takeScreenShot(CommonObjects.listingScreenData(searchData));
	}

	/**********************************************************************************************************
	 * @Objective: This method is created to search for the case till visible in
	 *             inbound incomplete section.
	 * @Input Parameters: searchData.
	 * @Output Parameters: NA.
	 * @author: Naresh S
	 * @Date : 18-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void incompleteSearchCase(String searchData) {
		for (int i = 0; i <= lsitstConstants.maxIterateCount; i++) {
			boolean searchResults = agX_Common.incompleteBasicSearch(searchData);
			if (searchResults == false) {
				agSetStepExecutionDelay("5000");
				agClick(CommonObjects.basicSearchIcon);
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			} else {
				break;
			}
		}
		agAssertVisible(CommonObjects.textData(searchData));
		agX_Common.takeScreenShot(CommonObjects.textData(searchData));
	}

	/**********************************************************************************************************
	 * @Objective: Edit Record.
	 * @Input Parameters: NA
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void editRecord() {
		agClick(CommonObjects.editIcon1);
		agAssertVisible(HeaderObjects.cancelButton);
	}

	/**********************************************************************************************************
	 * @Objective: Take screenshot.
	 * @Input Parameters: boolScreenShot.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 20-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void takeScreenShot(boolean boolScreenShot) {
		Reports.ExtentReportLog("ScreenShot", Status.INFO, "", boolScreenShot);
	}

	/**********************************************************************************************************
	 * @Objective: Take screenshot.
	 * @Input Parameters: NA.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 20-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/

	public static void takeScreenShot() {
		Reports.ExtentReportLog("ScreenShot", Status.INFO, "", lsitstConstants.boolScreenShot);
	}

	/**********************************************************************************************************
	 * @Objective: Scroll and Take screenshot.
	 * @Input Parameters: locator.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 20-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void takeScreenShot(String locator) {
		agJavaScriptExecuctorScrollToElement(locator);
		Reports.ExtentReportLog("ScreenShot", Status.INFO, "", lsitstConstants.boolScreenShot);
	}

	/**********************************************************************************************************
	 * @Objective:This method will return current date and Time.
	 * @Input Parameters: NA
	 * @Output Parameters: current data and time in yyyymmddhhmm format.
	 * @author:Naresh
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getDateTime() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddhhmmss");
		LocalDateTime now = LocalDateTime.now();
		return dtf.format(now);
	}

	/**********************************************************************************************************
	 * @Objective:This method created to verify text data in listing screen search
	 *                 results.
	 * @Input Parameters: data
	 * @Output Parameters: NA
	 * @author:Naresh
	 * @Date : 25-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyListingScreenTextData(String text) {
		String[] multipleTextData = text.split(",");
		for (int i = 0; i < multipleTextData.length; i++) {
			agSetStepExecutionDelay("0");
			agSetGlobalTimeOut("0");
			agX_Common.verifyDataList(CommonObjects.searchResultsDataRow, multipleTextData[i]);
			if (agIsVisible(CommonObjects.listingScreenData(multipleTextData[i]))) {
				agX_Common.takeScreenShot(CommonObjects.listingScreenData(multipleTextData[i]));
			}
			agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: Verfify Listing Screen Icons Data
	 * @Input Parameters: title.
	 * @Output Parameters: NA
	 * @author: Sanchit
	 * @Date : 25-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyListingScreenIcons(String title) {
		agAssertVisible(CommonObjects.listingScreenIcons(title));
		agJavaScriptExecuctorScrollToElement(CommonObjects.listingScreenIcons(title));
		Reports.ExtentReportLog("ScreenShot", Status.INFO, "", lsitstConstants.boolScreenShot);

	}

	/**********************************************************************************************************
	 * @Objective:This method created to verify text data in Incomplete listing
	 *                 screen search results.
	 * @Input Parameters: data
	 * @Output Parameters: NA
	 * @author:Naresh
	 * @Date : 25-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyIncompleteListingScreenTextData(String text) {
		String[] multipleTextData = text.split(",");
		for (int i = 0; i < multipleTextData.length; i++) {
			agSetStepExecutionDelay("0");
			agSetGlobalTimeOut("0");
			agX_Common.verifyDataList(CommonObjects.incompleteDataRow, multipleTextData[i]);
			if (agIsVisible(CommonObjects.textData(multipleTextData[i]))) {
				agX_Common.takeScreenShot(CommonObjects.textData(multipleTextData[i]));
			}
			agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: Select E2B Views in Listing Screen
	 * @Input Parameters: e2bFormat
	 * @Output Parameters: NA
	 * @author: Sanchit
	 * @Date : 25-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void selectE2BViews(String e2bFormat, boolean verifyXMLTagValue, String xmlTagNames,
			String xmlTagValues) {
		agWaitTillWindowExists("e2b_report");
		agAssertVisible(CommonObjects.e2bFormat);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		String[] e2BTempData = e2bFormat.split(",");
		for (int j = 0; j < e2BTempData.length; j++) {
			if (e2BTempData.length == 1) {
			} else {
				agClick(CommonObjects.e2bFormat);
				agAssertVisible(CommonObjects.listDropDown(e2BTempData[j]));
				agJavaScriptExecuctorClick(CommonObjects.listDropDown(e2BTempData[j]));
			}
			agSetGlobalTimeOut("0");
			if (e2BTempData[j].equals("E2B Report")) {
				agSwitchFrame("ifrm");
				agAssertVisible(CommonObjects.e2bReportView);
				agAssertNotVisible(CommonObjects.errorViewLabel);
				agGetCurrentWindow();
			} else if (e2BTempData[j].equals("E2B XML")) {
				agSwitchFrame("ifrm");
				agAssertVisible(CommonObjects.e2bXMLView);
				agAssertNotVisible(CommonObjects.errorViewLabel);

				if (verifyXMLTagValue == true) {
					verifyXMLTagValue(xmlTagNames, xmlTagValues);
				}

				agGetCurrentWindow();
			} else if (e2BTempData[j].equals("E2B PDF Report")) {
				agSwitchFrame("ifrm");
				agAssertNotVisible(CommonObjects.errorViewLabel);
				agGetCurrentWindow();
			}
			agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
			agX_Common.takeScreenShot();
		}
		agCloseCurrentWindow();
		agGetCurrentWindow();
	}

	public static boolean window;

	public static void agWaitTillWindowExists(String windowUrlText) {
		for (int i = 0; i <= 50; i++) {
			agGetCurrentWindow();
			window = Constants.driver.getCurrentUrl().contains(windowUrlText);
			if (window == false) {
				agSetStepExecutionDelay("3000");
			} else {
				agGetCurrentWindow();
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				break;
			}
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		}
	}

	/**********************************************************************************************************
	 * @Objective: To verify radio button is selected or not.
	 * @Input Parameters: locator.
	 * @Output Parameters: NA
	 * @author: Naresh
	 * @Date : 10-Oct-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyRadioButton(String locator) {
		String radioBtnStatus = agGetAttribute("class", locator + "/../div/div/span");
		if (radioBtnStatus.contains("bullet")) {
			Reports.ExtentReportLog("Radio Button", Status.PASS, "Radio button is selected", false);
		} else {
			Reports.ExtentReportLog("Radio Button", Status.FAIL, "Radio button is not selected", false);
		}
	}

	/**********************************************************************************************************
	 * @Objective: To verify required xml tag content
	 * @Input Parameters: tagName, expectedTagValue.
	 * @Output Parameters: NA
	 * @author: Naresh
	 * @Date : 10-Oct-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyXMLTagValue(String tagName, String expectedTagValue) {
		String xmlContent = agGetText(CommonObjects.uiXmlContent);
		String[] tagNameSplitData = tagName.split(",");
		String[] tagValueSplitData = expectedTagValue.split(",");
		int xmlFileType = xmlContent.indexOf("id extension");
		if (xmlFileType == -1) { // R2 File
			try {
				for (int j = 0; j < tagNameSplitData.length; j++) {
					if (xmlContent.contains("<" + tagNameSplitData[j] + ">" + tagValueSplitData[j] + "</"
							+ tagNameSplitData[j] + ">")) {
						Reports.ExtentReportLog("R2 XML Tag", Status.PASS, "XML Tag '" + tagNameSplitData[j]
								+ "' with value '" + tagValueSplitData[j] + "' is matched", false);
					} else {
						Reports.ExtentReportLog("R2 XML Tag", Status.FAIL, "XML Tag '" + tagNameSplitData[j]
								+ "' with value '" + tagValueSplitData[j] + "' is not matched", true);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else { // R3 File
			try {
				for (int j = 0; j < tagNameSplitData.length; j++) {
					if (xmlContent.contains("<" + tagNameSplitData[j] + "=\"" + tagValueSplitData[j] + "\"")) {
						Reports.ExtentReportLog("R3 XML Tag", Status.PASS, "XML Tag '" + tagNameSplitData[j]
								+ "' with value '" + tagValueSplitData[j] + "' is matched", false);
					} else {
						Reports.ExtentReportLog("R3 XML Tag", Status.FAIL, "XML Tag '" + tagNameSplitData[j]
								+ "' with value '" + tagValueSplitData[j] + "' is not matched", true);
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		agGetCurrentWindow();
	}
	
	
	public static void selectLabelDrop(String element,String dropdownValue) {
		if (dropdownValue != null && !dropdownValue.trim().equalsIgnoreCase("#skip#")) {
			try {
				agJavaScriptExecuctorScrollToElement(element);
				agClick(element);
				agClick(CommonObjects.dropDownLabelValuecase(dropdownValue));
			} catch (Exception e) {
				System.out.println("Check the label dropdown ID/Value");
				e.printStackTrace();
			}
		}
	}
	
	
}
