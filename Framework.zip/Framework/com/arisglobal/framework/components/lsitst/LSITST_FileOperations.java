package com.arisglobal.framework.components.lsitst;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.utils.generic.TextFileReader;
import com.arisglobal.framework.lib.utils.generic.XMLReader;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;

public class LSITST_FileOperations {
	static String className = LSITST_FileOperations.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: To create batch file to place in linux/Windows machine through
	 *             command line
	 * @InputParameters: scenarioName, medium.
	 * @OutputParameters:
	 * @author: Naresh
	 * @Date : 05-09-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void createFaxFileCase(String scenarioName, String medium) {
		String faxPath = LSITST_Login.getData("agXchange", "Fax Path");
		String filePath = LSITST_Login.getData("agXchange", "File Path");
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String files = lsitstConstants.LSITST_FileUploadPath;
		if (LSITST_Login.getData("agXchange", "Server Type").equalsIgnoreCase("Windows")) {
			if (medium.equalsIgnoreCase("fax")) {
				copyFile(scenarioName, faxPath);
			} else if (medium.equalsIgnoreCase("file")) {
				copyFile(scenarioName, filePath);
			}
		} else if (LSITST_Login.getData("agXchange", "Server Type").equalsIgnoreCase("Linux")) {
			String ppkFileName = LSITST_Login.getData("agXchange", "PpkFileName");
			String userName = LSITST_Login.getData("agXchange", "PpkUserName");
			String hostName = LSITST_Login.getData("agXchange", "PpkHostName");
			Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
			if (medium.equalsIgnoreCase("fax")) {
				try {
					File file = new File(files + Multimaplibraries.getTestDataCellValue(scenarioName, "BatchFileName"));
					FileOutputStream fout = new FileOutputStream(file);
					DataOutputStream dos = new DataOutputStream(fout);
					String sourceFileName = Multimaplibraries.getTestDataCellValue(scenarioName, "FileName");
					String targetFilePath = LSITST_Login.getData("agXchange", "Fax Path");
					dos.writeBytes("pscp -i " + files + ppkFileName + " \"" + files + sourceFileName + "\" -l "
							+ userName + "@" + hostName + ":" + targetFilePath);
					dos.close();
					executeBatchFile(scenarioName);
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else if (medium.equalsIgnoreCase("file")) {
				try {
					File file = new File(files + Multimaplibraries.getTestDataCellValue(scenarioName, "BatchFileName"));
					FileOutputStream fout = new FileOutputStream(file);
					DataOutputStream dos = new DataOutputStream(fout);
					String sourceFileName = Multimaplibraries.getTestDataCellValue(scenarioName, "FileName");
					String targetFilePath = LSITST_Login.getData("agXchange", "File Path");
					dos.writeBytes("pscp -i " + files + ppkFileName + " \"" + files + sourceFileName + "\" -l "
							+ userName + "@" + hostName + ":" + targetFilePath);
					dos.close();
					executeBatchFile(scenarioName);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} else {
			System.out.println(LSITST_Login.getData("agXchange", "Server Type") + " : Server Type is not available");
		}
	}

	/**********************************************************************************************************
	 * @Objective: To execute the batch file.
	 * @InputParameters: scenarioName, batFileName.
	 * @OutputParameters:
	 * @author: Naresh
	 * @Date : 06-09-2019
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void executeBatchFile(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		File dir = new File(lsitstConstants.LSITST_FileUploadPath);
		ProcessBuilder pb = new ProcessBuilder("cmd.exe", "/C", "Start",
				Multimaplibraries.getTestDataCellValue(scenarioName, "BatchFileName"));
		pb.directory(dir);
		try {
			pb.start();
			Thread.sleep(1000);
			// Runtime.getRuntime().exec("taskkill /f /im cmd.exe");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**********************************************************************************************************
	 * @Objective: Place file in the shared path.
	 * @Input Parameters: componentName, scenarioName, targetFilePath, columnName.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void copyFile(String scenarioName, String targetFilePath) {
		try {
			Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
			String sourcePath = lsitstConstants.LSITST_FileUploadPath;
			String fileName = Multimaplibraries.getTestDataCellValue(scenarioName, "FileName");
			File source = new File(sourcePath + fileName);
			boolean checkSourceFilePresence = source.exists();
			if (checkSourceFilePresence == false) {
				System.out.println("Specified File is not available in : " + source);
			}
			File destination = new File(targetFilePath + "\\" + fileName);
			Files.copy(source.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
			boolean checkDestinationFilePresence = destination.exists();
			if (checkDestinationFilePresence == false) {
				System.out.println(fileName + " - is not placed in : " + destination);
			}
		} catch (IOException e) {
		}
	}

	/**********************************************************************************************************
	 * @Objective: Updates xml file content with current date and time stamp.
	 * @Input Parameters: xmlFileName.
	 * @Output Parameters: Create's xml file with the same name with current date
	 *         and time stamp.
	 * @author: Naresh S
	 * @Date : 24-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void updateXMLData(String xmlFileName) {
		String xmlFileContent = TextFileReader.readTextFile(lsitstConstants.LSITST_FileUploadPath + "\\" + xmlFileName);
		int xmlFileType = xmlFileContent.indexOf("id extension");
		String safetyReportID = null;
		if (xmlFileType == -1) { // R2 File
			try {
				safetyReportID = XMLReader.getR2TagValue(lsitstConstants.LSITST_FileUploadPath + "\\" + xmlFileName,
						"//messagenumb[1]");
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else { // R3 File
			try {
				safetyReportID = XMLReader.getR2TagValue(lsitstConstants.LSITST_FileUploadPath + "\\" + xmlFileName,
						"//PORR_IN049016UV[1]/id[1]/@extension");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		String[] toReplaceSeq = safetyReportID.split(":");
		String xmlModified = xmlFileContent.replaceAll(toReplaceSeq[1], agX_Common.getDateTime());
		TextFileReader.writeToTextFile(lsitstConstants.LSITST_FileUploadPath + "\\" + xmlFileName, xmlModified);
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

}
