package com.arisglobal.framework.components.lsitst;

import java.util.ArrayList;

import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.HeaderObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundClassificationObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundGeneralDetailsObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundLocalReceiptObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundProductObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundReporterObjects;
import com.arisglobal.framework.components.lsitst.OR.ProductLookupObjects;
import com.arisglobal.framework.components.lsitst.agX_Common.linkText;
import com.arisglobal.framework.components.lsitst.agX_Common.menuName;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class InboundLocalReceipt extends ToolManager {
	static String className = InboundLocalReceipt.class.getSimpleName();
	static {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
	}

	/**********************************************************************************************************
	 * @Objective: This method perform Duplicate Search in receipt Screen
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void duplicateSearchCriteria(String scenarioName) {
		agSetStepExecutionDelay("2000");
		agSetValue(InboundClassificationObjects.aerNumberTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "AER Number"));
		agSetValue(InboundClassificationObjects.lrnNumberTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "LRN Number"));
		agSetValue(InboundClassificationObjects.patientIDTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Patient ID"));
		agSetValue(InboundClassificationObjects.localTradeNameTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Local Trade Name"));	
		agSetValue(InboundClassificationObjects.protocolNoTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Protocol No"));
		
		agSetValue(InboundClassificationObjects.reportedTermTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Reported term"));
		
		agSetValue(InboundClassificationObjects.dobFromDateTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "FromDoB"));
		agSetValue(InboundClassificationObjects.dobToDateTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "ToDoB"));
		
		agSetValue(InboundClassificationObjects.patientInitialsTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Patient Initial"));
		Reports.ExtentReportLog("Classification", Status.INFO, "Case classification", true);
		agClick(InboundLocalReceiptObjects.LrnSearchButton);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: This method selects AER and proceeds the case in receipt Screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setAERinformationProceed() {
		agSetStepExecutionDelay(String.valueOf(Constants.globalStepExecutionDelay));
		if (agIsVisible(InboundLocalReceiptObjects.aerRadio)) {
			agClick(InboundLocalReceiptObjects.aerRadio);
		}
		agClick(InboundLocalReceiptObjects.LrnProceedButton);

	}

	/**********************************************************************************************************
	 * @Objective: This method setReceipt Classification information
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setReceiptClassification(String scenarioName) {
		boolean flag=true;
		agSelectByVisibleText(InboundClassificationObjects.selectClassificationDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Classification Type"));
		agSetValue(InboundClassificationObjects.aerNumberTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "AER Number"));
		agSetValue(InboundClassificationObjects.lrnNumberTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "LRN Number"));
		if (agIsVisible(InboundLocalReceiptObjects.receiptClassificationSaveButton)) {
			agClick(InboundLocalReceiptObjects.receiptClassificationSaveButton);
			flag=false;
		} else {
			agClick(InboundClassificationObjects.nextButton);
			flag=false;
		}

		if (agIsVisible(InboundLocalReceiptObjects.LrnPopupTextBox)) {
			Reports.ExtentReportLog("LRN number is generated ", Status.PASS,
					agGetText(InboundLocalReceiptObjects.LrnPopupTextBox) + " :: Succesfull", true);
		}else if(flag==false){
			Reports.ExtentReportLog("setReceiptClassification", Status.INFO,
					"setReceiptClassification", true);
		}else {
			Reports.ExtentReportLog("LRN number generation failed", Status.FAIL,
					"LRN number generation failed ::UnSuccesfull", true);
		}

	}

	/**********************************************************************************************************
	 * @Objective: This method will diposes case from IRT
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void diposetheCase(String Scenario) {
		agSetStepExecutionDelay("4000");
		agJavaScriptExecuctorClick(InboundLocalReceiptObjects.flagIcon);
		agJavaScriptExecuctorClick(InboundLocalReceiptObjects.ToDispositiontoARISgLink);
		agSetStepExecutionDelay(String.valueOf(Constants.globalStepExecutionDelay));
		AuditInfo.auditReason(Scenario);
	}

	/**********************************************************************************************************
	 * @Objective: This method will Verfies source Document in receipt Screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void verfiySourceDocumentExtention() {
		agSetStepExecutionDelay("3000");
		agClick(InboundLocalReceiptObjects.slideLink);
		if (agGetText(InboundLocalReceiptObjects.fileNamelink).contains(".pdf")) {
			Reports.ExtentReportLog("Verifiying SourceDocument", Status.PASS,
					"source Document is in pdf format ::Succesfull", true);
		} else {
			Reports.ExtentReportLog("Verifiying SourceDocument", Status.FAIL,
					"source Document is not in pdf format ::UnSuccesfull", true);
		}
		agClick(InboundLocalReceiptObjects.fileNamelink);
		agGetCurrentWindow();
		Reports.ExtentReportLog("SourceDocument Content", Status.INFO,"SourceDocument Content", true);
		agCloseCurrentWindow();
		agGetCurrentWindow();
		agClick(InboundLocalReceiptObjects.slideLink);
		agSetStepExecutionDelay(String.valueOf(Constants.globalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: This method will get ReceiptData
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static ArrayList getEditReceiptData() {
		ArrayList<String> editrecipit = new ArrayList<String>();
		editrecipit.add(agGetAttribute("value", InboundLocalReceiptObjects.Sender));
		editrecipit.add(agGetAttribute("value", InboundLocalReceiptObjects.Receiver));
		editrecipit.add(agGetAttribute("value", InboundLocalReceiptObjects.ReceiverOrganization));
		editrecipit.add(agGetAttribute("value", InboundLocalReceiptObjects.SenderOrganization));
		editrecipit.add(agGetAttribute("value", InboundLocalReceiptObjects.LocalReceivedDate));
		editrecipit.add(agGetAttribute("value", InboundLocalReceiptObjects.EisaiReceivedDate));
		editrecipit.add(agGetAttribute("value", InboundLocalReceiptObjects.Owner));
		editrecipit.add(agGetAttribute("value", InboundLocalReceiptObjects.UnknownSenderInfo));
		return editrecipit;
	}

	/**********************************************************************************************************
	 * @Objective: This method will Verify ReceiptData
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void VerifyEditReceiptData(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		int index = Integer.valueOf(Multimaplibraries.getTestDataCellValue(scenarioName, "CelNumber"));
		String value = Multimaplibraries.getTestDataCellValue(scenarioName, "SenderInfo");
		System.out.println(getEditReceiptData());
		if (getEditReceiptData().get(index).toString().equalsIgnoreCase(value)) {
			Reports.ExtentReportLog("Verifiying sender info", Status.PASS, "Sender information verified ::Succesfull",
					true);

		} else {
			Reports.ExtentReportLog("Verifiying sender info", Status.FAIL,
					"Sender information verification ::UnSuccesfull", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method will set Source Document in document section
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSourceDocument(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agClick(InboundGeneralDetailsObjects.expandCollapseDocWindowBtn);
		agX_Common.selectLabelDropdown(InboundLocalReceiptObjects.categoryLabelDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "category"));
		agClick(InboundGeneralDetailsObjects.expandCollapseDocWindowBtn);
		Reports.ExtentReportLog("SourceDocument", Status.INFO,"SourceDocument", true);
	}

	/**********************************************************************************************************
	 * @Objective: This method will set SafetyReport Data
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSafetyReport(String scenarioName) {
		agX_Common.selectLabelDropdown(InboundLocalReceiptObjects.ReportType,
				Multimaplibraries.getTestDataCellValue(scenarioName, "ReportType"));
		agX_Common.selectLabelDropdown(InboundLocalReceiptObjects.ARISgWorkflowTrackLableDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "ARISg WorkflowTrack"));
		agX_Common.selectLabelDropdown(InboundLocalReceiptObjects.primarySourceCountryLableDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "PrimarySourceCountry"));
		agSetValue(InboundLocalReceiptObjects.CaseOwner,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Case Owner"));
		Reports.ExtentReportLog("setSafetyReport", Status.INFO,"setSafetyReport", true);
	}

	/**********************************************************************************************************
	 * @Objective: This method will set Source Data
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSource(String scenarioName) {
		agX_Common.selectLabelDropdown(InboundLocalReceiptObjects.isPrimarySource,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Is Primary Source"));
		agX_Common.selectLabelDropdown(InboundLocalReceiptObjects.SourceLableDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Source"));
		Reports.ExtentReportLog("setSource information", Status.INFO,"setSource information", true);
	}

	/**********************************************************************************************************
	 * @Objective: This method will set Reaction Data
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setReaction(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agSetValue(InboundLocalReceiptObjects.Reportedterm,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Reported term"));
		Reports.ExtentReportLog("setReaction information", Status.INFO,"setReaction information", true);
	}

	/**********************************************************************************************************
	 * @Objective: This method will set Reporter Data
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setReporterDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, "ReporterTab");
		agX_Common.selectLabelDropdown(InboundReporterObjects.isPrimaryReporterDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Primary reporter"));
		agSetValue(InboundReporterObjects.titleTextbox, Multimaplibraries.getTestDataCellValue(scenarioName, "Title"));
		agSetValue(InboundReporterObjects.firstNameTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "First Name"));
		agSetValue(InboundReporterObjects.middleInitialsTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Middle Name"));
		agSetValue(InboundReporterObjects.lastNameTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Last Name"));
		agSetValue(InboundReporterObjects.departmentTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Department"));
		agSetValue(InboundReporterObjects.hospitalNameTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Hospital"));
		agSetValue(InboundReporterObjects.address1Textbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Address1"));
		agSetValue(InboundReporterObjects.cityTextbox, Multimaplibraries.getTestDataCellValue(scenarioName, "City"));
		agX_Common.selectLabelDropdown(InboundReporterObjects.reporterCountryDropdown,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Country"));
		agSetValue(InboundReporterObjects.stateTextbox, Multimaplibraries.getTestDataCellValue(scenarioName, "State"));
		agSetValue(InboundReporterObjects.zipCodeTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Zip Code"));
		agSetValue(InboundReporterObjects.emailAddressTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Email Address"));
		agSetValue(InboundReporterObjects.faxNumberTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Fax"));
		agSetValue(InboundReporterObjects.mITextbox, Multimaplibraries.getTestDataCellValue(scenarioName, "MI"));
		
		Reports.ExtentReportLog("setReporter information", Status.INFO,"setReporter information", true);
	}

	/**********************************************************************************************************
	 * @Objective: This method will set Product Data
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setProductInfo(String scenarioName) {
		agClick(InboundProductObjects.productLookupIcon);
		agSetValue(ProductLookupObjects.preferredProdDescTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Product Description"));
		agSetValue(ProductLookupObjects.localTradeNameTxtbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Local Trade Name"));
		agClick(ProductLookupObjects.searchButton);
		agSetGlobalTimeOut("60");
		agSetStepExecutionDelay("1000");
		agClick(InboundLocalReceiptObjects.localTradeNameTab);
		
		if (agIsVisible(ProductLookupObjects.selectButton)) {
			String product = Multimaplibraries.getTestDataCellValue(scenarioName, "Product Description");
			String localTrade = Multimaplibraries.getTestDataCellValue(scenarioName, "Local Trade Name");
			String data;
			
			if(!product.equalsIgnoreCase("#skip#")) {
				data=product;
			}else {
				data=localTrade;
			}
			agClick(CommonObjects.radioButton(data));
			agClick(ProductLookupObjects.selectButton);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agWaitTillInvisibilityOfElement(ProductLookupObjects.selectButton);
		}
		agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
		Reports.ExtentReportLog("setProduct information", Status.INFO,"setProduct information", true);
	}

	/**********************************************************************************************************
	 * @Objective: This method will set Study Data
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setStudyInfo(String scenarioName) {
		
		agClick(InboundLocalReceiptObjects.protocolLookupIcon);
		agSetValue(InboundLocalReceiptObjects.protocolTextBox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Protocol No"));
		agClick(InboundLocalReceiptObjects.searchButton);
		agSetGlobalTimeOut("60");
		agSetStepExecutionDelay("2000");
		if (agIsVisible(ProductLookupObjects.selectButton)) {
			agClick(CommonObjects.radioButton(Multimaplibraries.getTestDataCellValue(scenarioName, "Protocol No")));
			agClick(ProductLookupObjects.selectButton);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agWaitTillInvisibilityOfElement(ProductLookupObjects.selectButton);
		}
		agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
		Reports.ExtentReportLog("setStudy information", Status.INFO,"setStudy information", true);
	}

	/**********************************************************************************************************
	 * @Objective: This method will confirming the Validation
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void confirmingTheValidation() {
		agJavaScriptExecuctorClick(InboundLocalReceiptObjects.caseProceed);
		if (agIsVisible(InboundLocalReceiptObjects.dipostitionConfimarion)) {
			Reports.ExtentReportLog("Case Dispostion ", Status.PASS,
					agGetText(InboundLocalReceiptObjects.dipostitionConfimarion) + " :: Succesfull", true);
		} else {
			Reports.ExtentReportLog("Case Dispostion ", Status.FAIL, "Dispostion is failed :: unSuccesfull", true);
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method will set Source Data
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setSourceFileUpload(String scenarioName) {
		String fileName = Multimaplibraries.getTestDataCellValue(scenarioName, "UploadFileName");
		agSetValue(InboundGeneralDetailsObjects.sourceDocUploadButton,
				lsitstConstants.LSITST_FileUploadPath + fileName);
		agSetGlobalTimeOut("300000");
		agAssertVisible(CommonObjects.linkText(fileName));
		agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
		Reports.ExtentReportLog("Source Documents", Status.INFO, "Added Source document", true);
		agClick(InboundGeneralDetailsObjects.expandCollapseDocWindowBtn);
	}
	/**********************************************************************************************************
	 * @Objective: This method confirming javascript popup
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void javscriptPopup() {
		if (agIsVisible(InboundLocalReceiptObjects.closeJavaScriptPOPup)) {
			agJavaScriptExecuctorClick(InboundLocalReceiptObjects.closeJavaScriptPOPup);
		}
	}

	/**********************************************************************************************************
	 * @Objective: This method will Fetch The Aer Number
	 * @InputParameters:receiptNum
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static String fetchingAerNumber(String receiptNum) {
		agX_Common.agX_Navigations(menuName.inbound);
		agX_Common.agX_Navigations(menuName.inboundListing);
		agX_Common.clickLink(linkText.dispositionARISg);
		agX_Common.searchCase(receiptNum);
		String value = InboundListing.getAERNumber();
		if (value.isEmpty()) {
			Reports.ExtentReportLog("Aer number is generation", Status.FAIL,
					"Aer number generation failed :: UnSuccesfull", true);
		} else {
			Reports.ExtentReportLog("Aer number is generation", Status.PASS, value + " :: Succesfull", true);

		}
		return value;
	}

	/**********************************************************************************************************
	 * @Objective: This method will set Receipt Summary
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setReceiptSummary() {
		// Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agSetValue(InboundLocalReceiptObjects.SenderOrganizationCode, "003");
	}
	
	
	
	/**********************************************************************************************************
	 * @Objective: This method selects AER and proceeds the case in receipt Screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void setAERfromDuplicateSearch() {
		agSetStepExecutionDelay(String.valueOf(Constants.globalStepExecutionDelay));
		if (agIsVisible(InboundLocalReceiptObjects.aerRadio)) {
			agClick(InboundLocalReceiptObjects.aerRadio);
		}
	}
	
	/**********************************************************************************************************
	 * @Objective: This method perform clear the Duplicate Search fields data
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/
	public static void duplicateSearchCriteriaClear() {
		agClearText(InboundClassificationObjects.aerNumberTextbox);
		agClearText(InboundClassificationObjects.lrnNumberTextbox);
		agClearText(InboundClassificationObjects.patientIDTextbox);
		agClearText(InboundClassificationObjects.localTradeNameTextbox);
		Reports.ExtentReportLog("Classification", Status.INFO, "Case classification", true);
	}
	
	/**********************************************************************************************************
	 * @Objective: This method resetting the duplicateSearch data
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void reset() {
		agClick(InboundClassificationObjects.resetButton);
	}
	
	/**********************************************************************************************************
	 * @Objective: This method is used for verfying the xml and pdf report in report screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/		
	public static void verifiythereport() {
		agSetStepExecutionDelay("2000");
		agGetCurrentWindow();	
		agSwitchFrameByLocator(InboundLocalReceiptObjects.frmFrame);
		if(agIsVisible(InboundLocalReceiptObjects.xmlCheckpoint)) {
			Reports.ExtentReportLog("E2B XML", Status.PASS,"E2B XML", true);
		}else {
			Reports.ExtentReportLog("E2B XML", Status.FAIL,"E2B XML", true);
		}
		agSwitchToDefaultFrame();
		agX_Common.selectLabelDrop(InboundLocalReceiptObjects.othersDropDown,"E2B PDF Report");
		agSetStepExecutionDelay("5000");
		agSwitchFrameByLocator(InboundLocalReceiptObjects.frmFrame);
		Constants.highlightObjects = false;
		if(agIsVisible(InboundLocalReceiptObjects.pdfCheckpoint)) {
			Reports.ExtentReportLog("E2B PDF Report", Status.PASS,"E2B PDF Report", true);
		}else {
			Reports.ExtentReportLog("E2B PDF Report", Status.FAIL,"E2B PDF Report", true);
		}
		agSwitchToDefaultFrame();
		agSetStepExecutionDelay(String.valueOf(Constants.globalStepExecutionDelay));
		Constants.highlightObjects = true;
	}
	
	/**********************************************************************************************************
	 * @Objective: This method is used for verfying the xml and pdf report in acknwodement tab
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/		
	public static void acknowreport() {
		agSetStepExecutionDelay("1000");
		agClick(InboundLocalReceiptObjects.acknowldgement);
		agSelectByVisibleText(InboundLocalReceiptObjects.acknowldgementDropDown, "ACK XML");
		
		if (agIsVisible(InboundLocalReceiptObjects.ackCheckpoint)) {
			Reports.ExtentReportLog("ACK XML", Status.PASS, "ACK XML", true);
		} else {
			Reports.ExtentReportLog("ACK XML", Status.FAIL, "ACK XML", true);
		}	
		agSelectByVisibleText(InboundLocalReceiptObjects.acknowldgementDropDown, "ACK REPORT");
		agSwitchFrameByLocator(InboundLocalReceiptObjects.frmFrame);
		
		if (agIsVisible(InboundLocalReceiptObjects.ackReportcheckpoint)) {
			Reports.ExtentReportLog("ACK REPORT", Status.PASS, "ACK REPORT", true);
		} else {
			Reports.ExtentReportLog("ACK REPORT", Status.FAIL, "ACK REPORT", true);
		}
		agSwitchToDefaultFrame();
	}
	/**********************************************************************************************************
	 * @Objective: This method is used for verfying report
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/			
	public static void verifyingArchive() {
		verifiythereport();
		acknowreport();
		agCloseCurrentWindow();
		agGetCurrentWindow();
	}
	/**********************************************************************************************************
	 * @Objective: This method is used for clicking file link in lrn screen
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void clickOnfile() {
		agClick(InboundLocalReceiptObjects.fileNamelink);
	}
	/**********************************************************************************************************
	 * @Objective: This method is used for clicking on xmlink
	 * @InputParameters:
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void clickOnxmlLink() {
		agClick(InboundLocalReceiptObjects.archiveXMLLink);
	}
	/**********************************************************************************************************
	 * @Objective: This method is used editing case in diposearg link
	 * @InputParameters:scenarioName
	 * @OutputParameters:
	 * @author: Vamsi krishna RS
	 * @Date :
	 * @UpdatedByAndWhen:
	 **********************************************************************************************************/	
	public static void editcaseinDoposition() {
		agClick(CommonObjects.editIcon);
		agAssertVisible(HeaderObjects.cancelButton);
	}
	


}
