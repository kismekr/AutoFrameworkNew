package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.AuditReasonObjects;
import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.ConfirmRemoveObjects;
import com.arisglobal.framework.components.lsitst.OR.PasswordAuthenticationObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class AuditInfo extends ToolManager {

	static String className = AuditInfo.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Enter Audit trail information.
	 * @Input Parameters: Scenario Name
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void auditReason(String scenarioName) {
		if (agIsVisible(AuditReasonObjects.reasonCodeDropdown)) {
			Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
			agX_Common.selectLabelDropdown(AuditReasonObjects.reasonCodeDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Reason Code"));
			agSetValue(AuditReasonObjects.reasonTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Reason Description"));
			Reports.ExtentReportLog("Audit Trail", Status.INFO, "Enter Audit Trail Information", true);
			agClick(agX_Common.uniqueXpath(AuditReasonObjects.submitButton));
			agWaitTillInvisibilityOfElement(AuditReasonObjects.submitButton);
		}
		agSetGlobalTimeOut("180");
		if (agIsVisible(CommonObjects.applicationMessage)) {
			Reports.ExtentReportLog("Application Info", Status.INFO,
					"The message '" + agGetText(CommonObjects.applicationMessage) + "' is displayed", true);
		}
		agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
		agAssertContainsText(CommonObjects.applicationMessage,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Message"));
	}

	/**********************************************************************************************************
	 * @Objective: Enter Remove Audit trail information.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void confirmRemove(String scenarioName) {
		if (agIsVisible(ConfirmRemoveObjects.reasonCodeDropdown)) {
			Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
			agX_Common.selectLabelDropdown(ConfirmRemoveObjects.reasonCodeDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Reason Code"));
			agSetValue(ConfirmRemoveObjects.reasonTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Reason Description"));
			Reports.ExtentReportLog("Remove Audit Trail", Status.PASS, "", true);
			agClick(ConfirmRemoveObjects.submitButton);
			if (agIsVisible(CommonObjects.applicationMessage)) {
				Reports.ExtentReportLog("Application Info", Status.PASS,
						"The message '" + agGetText(CommonObjects.applicationMessage) + "' is displayed", true);
			}
			agAssertContainsText(CommonObjects.applicationMessage, "Success");
			agClick(CommonObjects.applicationMessageClose);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Enter Password information.
	 * @Input Parameters: scenarioName,columnName.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void passwordAuthentication(String scenarioName, String columnName) {
		if (agIsVisible(CommonObjects.passwordAuthentication)) {
			agSetValue(CommonObjects.passwordAuthentication, LSITST_Login.getData(scenarioName, columnName));
			Reports.ExtentReportLog("Password Authentication", Status.INFO, "", true);
			agClick(PasswordAuthenticationObjects.submitButton);
		}
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
}
