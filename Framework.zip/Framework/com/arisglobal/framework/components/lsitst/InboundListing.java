package com.arisglobal.framework.components.lsitst;

import org.apache.poi.util.SystemOutLogger;

import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundAERSummaryObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundLRNSummaryObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundListingObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class InboundListing extends ToolManager {

	static String className = InboundListing.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Search Inbound Listing case.
	 * @Input Parameters: scenarioName, columnName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void InboundListingSearchCase(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String receiptNumber = Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
		for (int i = 0; i <= lsitstConstants.maxIterateCount; i++) {
			agJavaScriptExecuctorSendKeys(InboundListingObjects.inboundSearchTextbox, receiptNumber);
			agClick(InboundListingObjects.inboundSearchButton);
			agX_Common.waitTillLoading();
			agSetGlobalTimeOut("5");
			agSetStepExecutionDelay("3000");
			boolean message = agIsVisible(CommonObjects.searchResultsDataRow);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
			if (!message) {
				try {
					Thread.sleep(10000);
				} catch (InterruptedException e) {
				}
			} else {
				agJavaScriptExecuctorScrollToElement(InboundListingObjects.receiptNumberLink);
				agCheckPropertyText(receiptNumber, InboundListingObjects.receiptNumberLink);
				Reports.ExtentReportLog("Inbound Listing Case Search", Status.PASS,
						"Case with number '" + receiptNumber + "' is available", true);
				break;
			}
			if (i == lsitstConstants.maxIterateCount) {
				Reports.ExtentReportLog("Inbound Listing Case Search Failed", Status.FAIL,
						"Case with number '" + receiptNumber + "'  not available", true);
			}
		}
	}

	/**********************************************************************************************************
	 * @Objective: Click on LRN Summary link.
	 * @Input Parameters: NA
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void clickLRNSummaryLink() {
		agSetStepExecutionDelay("5000");
		agClick(InboundListingObjects.lrnLink);
		agGetCurrentWindow();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		agAssertVisible(InboundLRNSummaryObjects.lrnSummaryLabel);
		agX_Common.takeScreenShot();
	}

	/**********************************************************************************************************
	 * @Objective: Click on AER Summary link.
	 * @Input Parameters: NA
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void clickAERSummaryLink() {
		agClick(InboundListingObjects.aerLink);
		agSetStepExecutionDelay("3000");
		agAssertVisible(InboundAERSummaryObjects.aerSummaryLabel);
		agX_Common.takeScreenShot();
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
	}

	/**********************************************************************************************************
	 * @Objective: Get Receipt Number.
	 * @Input Parameters: NA
	 * @Output Parameters: Return Receipt Number
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getReceiptNumber() {
		String receiptNo = null;
		String appMsg = null;
		appMsg = agGetText(CommonObjects.applicationMessage);
		String[] resultText = appMsg.split("'");
		receiptNo = resultText[1];
		agClick(CommonObjects.applicationMessageClose);
		System.out.println("RCT" + receiptNo);
		return receiptNo;
	}

	/**********************************************************************************************************
	 * @Objective: Verify Replicated Receipt Number.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyReplicatedCase(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agCheckPropertyText(Multimaplibraries.getTestDataCellValue(scenarioName, "Replicated Receipt Number"),
				InboundListingObjects.receiptNumberLink);
		agCheckPropertyText(Multimaplibraries.getTestDataCellValue(scenarioName, "Replicate Medium Link"),
				InboundListingObjects.replicateMediumLink);
	}

	/**********************************************************************************************************
	 * @Objective: Verify AER Summary Page.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyAERSummary(String scenarioName) {
		agAssertContainsText(InboundAERSummaryObjects.aerNoLabel, InboundListing.getData(scenarioName, "AER Number"));
		agCheckPropertyText(GeneralTab.getData(scenarioName, "Medically Confirmed"),
				InboundAERSummaryObjects.medicallyConfirmedLabel);
		agCheckPropertyText(PatientTab.getData(scenarioName, "Patient Initials"),
				InboundAERSummaryObjects.patientInitialsLabel);
		agCheckPropertyText(ReporterTab.getData(scenarioName, "Title"), InboundAERSummaryObjects.reporterTitleLabel);
		agCheckPropertyText(ReporterTab.getData(scenarioName, "First Name"),
				InboundAERSummaryObjects.reporterFirstNameLabel);
	}

	/**********************************************************************************************************
	 * @Objective: Get AER Number.
	 * @Input Parameters: NA.
	 * @Output Parameters: Returns AER Number.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getAERNumber() {
		String aerNumber = "";
		if (agIsVisible(InboundListingObjects.aerLink)) {
			agJavaScriptExecuctorScrollToElement(InboundListingObjects.aerLink);
			aerNumber = agGetText(InboundListingObjects.aerLink);
			System.out.println("AER Number : " + aerNumber);
		} else {
			agJavaScriptExecuctorScrollToElement(InboundListingObjects.aerNumber);
			aerNumber = agGetText(InboundListingObjects.aerNumber);
			System.out.println("AER Number : " + aerNumber);
		}
		return aerNumber;
	}

	/**********************************************************************************************************
	 * @Objective: Verify AER Number.
	 * @Input Parameters: NA.
	 * @Output Parameters: NA.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyAERNumber(String expectedData) {
		agCheckPropertyText(expectedData, InboundListingObjects.aerLink);
		agX_Common.takeScreenShot(InboundListingObjects.aerLink);
	}

	/**********************************************************************************************************
	 * @Objective: Get First Receipt Number from Listing Screen.
	 * @Input Parameters: NA
	 * @Output Parameters: Return Receipt Number.
	 * @author: Naresh S
	 * @Date : 06-09-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getListingScreenReceiptNumber() {
		String receiptNo = agGetText(InboundListingObjects.receiptNumberLink);
		System.out.println("RCT Listing : " + receiptNo);
		return receiptNo;
	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}

	/**********************************************************************************************************
	 * @Objective: Click and Select E2B Views in Inbound Listing Screen
	 * @Input Parameters: e2bFormat, verifyXMLTagValue, xmlTagNames, xmlTagValues.
	 * @Output Parameters: NA.
	 * @author: Naresh
	 * @Date : 27-Sep-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void selectInboundE2BViews(String e2bFormat, boolean verifyXMLTagValue, String xmlTagNames,
			String xmlTagValues) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		String caseNumber = InboundListing.getListingScreenReceiptNumber();
		agClick(InboundListingObjects.e2bLink);
		agX_Common.agWaitTillWindowExists("e2b_report");
		agAssertContainsText(CommonObjects.e2bCaseNumberLabel, caseNumber);
		agX_Common.takeScreenShot();
		agX_Common.selectE2BViews(e2bFormat, verifyXMLTagValue, xmlTagNames, xmlTagValues);
	}

	/**********************************************************************************************************
	 * @Objective: Get Message Number from Listing Screen.
	 * @Input Parameters: NA
	 * @Output Parameters: Return Message Number.
	 * @author: Naresh S
	 * @Date : 06-09-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getListingScreenMessageNumber() {
		String messageNo = agGetText(InboundListingObjects.messageNoLabel);
		System.out.println("Message Number : " + messageNo);
		return messageNo;
	}
	/**********************************************************************************************************
	 * @Objective:This method is used for fetching unread mail 
	 * @Input Parameters: NA
	 * @Output Parameters: Return Message Number.
	 * @author: Vamsi krishna R S
	 * @Date : 
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String fetchUnreadEmailReceipt(String excpectedmedium, String excpectedlrn) {
		int tablesize = agGetElementList(InboundListingObjects.lrnGridRowlist).size();
		String actualreceipt = "", actualmedium, actuallrn;
		int num;
		for (int rowNumb = 0; rowNumb < tablesize; rowNumb++) {
			num=rowNumb+1;
			actualmedium = agGetText(InboundListingObjects.lrngridData(num, 19, "Medium"));
			if (actualmedium.equalsIgnoreCase(excpectedmedium)
					&& !(agIsVisible(InboundListingObjects.lrngridData(num, 30, "LRN Number")))) {
				actualreceipt = agGetText(InboundListingObjects.lrngridData(num, 18, "Receipt Number"));
				System.out.println("Case found and case number is ::" + actualreceipt);
				Reports.ExtentReportLog("fetching Receipt", Status.PASS,
						"Case with number '" + actualreceipt + "' is available", true);
				break;
			}
		}

		if (actualreceipt.equalsIgnoreCase("")) {
			System.out.println("Case found were found ");
			Reports.ExtentReportLog("fetching Receipt", Status.FAIL,
					"Case with number not available", true);
		}
		return actualreceipt;
	}

	
}
