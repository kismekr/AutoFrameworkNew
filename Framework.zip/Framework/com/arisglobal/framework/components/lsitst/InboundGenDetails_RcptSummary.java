package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.components.lsitst.OR.CommonObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundGeneralDetailsObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundPartnerLookupObjects;
import com.arisglobal.framework.components.lsitst.OR.InboundReplicateObjects;
import com.arisglobal.framework.lib.main.Constants;
import com.arisglobal.framework.lib.main.Multimaplibraries;
import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.DateOperations;
import com.arisglobal.framework.lib.utils.generic.DateOperations.dateFormat;
import com.arisglobal.framework.lib.utils.generic.Reports;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lsitstConfig.lsitstConstants;
import com.aventstack.extentreports.Status;

public class InboundGenDetails_RcptSummary extends ToolManager {
	static String className = InboundGenDetails_RcptSummary.class.getSimpleName();

	/**********************************************************************************************************
	 * @Objective: Enter Inbound General Details.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setGeneralDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		if (Multimaplibraries.getTestDataCellValue(scenarioName, "boolSenderLookup").equalsIgnoreCase("true")) {
			agSetStepExecutionDelay("1000");
			agClick(InboundGeneralDetailsObjects.senderLookup);
			agSetValue(InboundPartnerLookupObjects.partnerIDTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Sender"));
			agClick(InboundPartnerLookupObjects.searchButton);
			agClick(CommonObjects.radioButton(Multimaplibraries.getTestDataCellValue(scenarioName, "Sender")));
			agClick(InboundPartnerLookupObjects.selectButton);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} else {
			agSetValue(InboundGeneralDetailsObjects.senderTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Sender"));
		}
		if (Multimaplibraries.getTestDataCellValue(scenarioName, "boolReceiverLookup").equalsIgnoreCase("true")) {
			agSetStepExecutionDelay("1000");
			agClick(InboundGeneralDetailsObjects.receiverLookup);
			agSetValue(InboundPartnerLookupObjects.partnerIDTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Receiver"));
			agClick(InboundPartnerLookupObjects.searchButton);
			agClick(CommonObjects.radioButton(Multimaplibraries.getTestDataCellValue(scenarioName, "Receiver")));
			agClick(InboundPartnerLookupObjects.selectButton);
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		} else {
			agSetValue(InboundGeneralDetailsObjects.receiverTextbox,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Receiver"));
		}
		agSetValue(InboundGeneralDetailsObjects.arisGlobalReceivedDateTextbox, DateOperations.getDateByInputData(
				dateFormat.ddMMMyyyy, Multimaplibraries.getTestDataCellValue(scenarioName, "Company Received Date")));
		agClick(CommonObjects.calenderCloseButton);
		agSetValue(InboundGeneralDetailsObjects.localReceivedDateTextbox, DateOperations.getDateByInputData(
				dateFormat.ddMMMyyyy, Multimaplibraries.getTestDataCellValue(scenarioName, "Local Received Date")));
		agClick(CommonObjects.calenderCloseButton);
		agSetGlobalTimeOut("0");
		if (agIsVisible(InboundGeneralDetailsObjects.reportTypeDropdown)) {
			agX_Common.selectLabelDropdown(InboundGeneralDetailsObjects.reportTypeDropdown,
					Multimaplibraries.getTestDataCellValue(scenarioName, "Report Type"));
		}
		agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
		Reports.ExtentReportLog("Receipt Summary", Status.INFO, "Receipt Summary details", true);
	}

	/**********************************************************************************************************
	 * @Objective: Verify General Details.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifyGeneralDetails(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(scenarioName, "Sender"),
				InboundGeneralDetailsObjects.senderTextbox);
		agCheckPropertyValue("value", Multimaplibraries.getTestDataCellValue(scenarioName, "Receiver"),
				InboundGeneralDetailsObjects.receiverTextbox);
		agCheckPropertyValue("value",
				DateOperations.getDateByInputData(dateFormat.ddMMMyyyy,
						Multimaplibraries.getTestDataCellValue(scenarioName, "Company Received Date")),
				InboundGeneralDetailsObjects.arisGlobalReceivedDateTextbox);
		agCheckPropertyValue("value",
				DateOperations.getDateByInputData(dateFormat.ddMMMyyyy,
						Multimaplibraries.getTestDataCellValue(scenarioName, "Local Received Date")),
				InboundGeneralDetailsObjects.localReceivedDateTextbox);
	}

	/**********************************************************************************************************
	 * @Objective: To Upload Source document.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setSourceFileUpload(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agClick(InboundGeneralDetailsObjects.expandCollapseDocWindowBtn);
		String fileName = Multimaplibraries.getTestDataCellValue(scenarioName, "UploadFileName");
		agSetValue(InboundGeneralDetailsObjects.sourceDocUploadButton,
				lsitstConstants.LSITST_FileUploadPath + fileName);
		agSetGlobalTimeOut("300000");
		agAssertVisible(CommonObjects.linkText(fileName));
		agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
		Reports.ExtentReportLog("Source Documents", Status.INFO, "Added Source document", true);
		agClick(InboundGeneralDetailsObjects.expandCollapseDocWindowBtn);
	}

	/**********************************************************************************************************
	 * @Objective: To Upload Supporting documents.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 28-August-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setSupportingFileUpload(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agClick(InboundGeneralDetailsObjects.expandCollapseDocWindowBtn);
		String supportingDocFileName = Multimaplibraries.getTestDataCellValue(scenarioName, "SupportingDocuments");
		String[] multipleSuppDocs = supportingDocFileName.split(",");
		if (multipleSuppDocs.length == 0) {
			agSetValue(InboundGeneralDetailsObjects.supportingDocUploadButton,
					lsitstConstants.LSITST_FileUploadPath + multipleSuppDocs[0]);
			agSetGlobalTimeOut("300000");
			agSetStepExecutionDelay("1000");
			agAssertVisible(CommonObjects.linkText(multipleSuppDocs[0]));
			agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
			agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
		} else {
			for (int i = 0; i < multipleSuppDocs.length; i++) {
				agSetValue(InboundGeneralDetailsObjects.supportingDocUploadButton,
						lsitstConstants.LSITST_FileUploadPath + multipleSuppDocs[i]);
				agSetGlobalTimeOut("300000");
				agSetStepExecutionDelay("1000");
				agAssertVisible(CommonObjects.linkText(multipleSuppDocs[i]));
				agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
				agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
			}
		}
		Reports.ExtentReportLog("Supporting Documents", Status.INFO, "Added Supporting Documents", true);
		agClick(InboundGeneralDetailsObjects.expandCollapseDocWindowBtn);
	}

	/**********************************************************************************************************
	 * @Objective: Verify Source document.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void verifySourceFileUpload(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agClick(InboundGeneralDetailsObjects.expandCollapseDocWindowBtn);
		agAssertContainsText(InboundGeneralDetailsObjects.sourceDocUploadedLink,
				Multimaplibraries.getTestDataCellValue(scenarioName, "UploadFileName"));
		agClick(InboundGeneralDetailsObjects.expandCollapseDocWindowBtn);

	}

	/**********************************************************************************************************
	 * @Objective: Enter Replicate information.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void replicateCase(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agSetValue(InboundReplicateObjects.numberOfItemsTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Number of Items"));
		agSetValue(InboundReplicateObjects.commentsTextbox,
				Multimaplibraries.getTestDataCellValue(scenarioName, "Comments"));
		if (Multimaplibraries.getTestDataCellValue(scenarioName, "bool Communication").equalsIgnoreCase("true")) {
			agClick(InboundReplicateObjects.communicationCheckbox);
		}
		if (Multimaplibraries.getTestDataCellValue(scenarioName, "bool Case Data").equalsIgnoreCase("true")) {
			agClick(InboundReplicateObjects.caseDataCheckbox);
		}
		agAssertVisible(InboundReplicateObjects.numberOfItemsTextbox);
		agX_Common.buttonOperation("Replicate Submit");
	}

	/**********************************************************************************************************
	 * @Objective: Get Replicated Receipt Number.
	 * @Input Parameters: NA
	 * @Output Parameters: Replicated Receipt Number.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getReplicatedReceiptNumber() {
		String replicatedNumber = null;
		String appMsg = null;
		appMsg = agGetText(CommonObjects.applicationMessage);
		String resultText[] = appMsg.split("'");
		replicatedNumber = resultText[3].trim();
		System.out.println("REP"+ replicatedNumber);
		return replicatedNumber;
	}

	/**********************************************************************************************************
	 * @Objective: Get LRN Number.
	 * @Input Parameters: NA
	 * @Output Parameters: Return LRN Number
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getLRNNumber() {
		String lrnNumber = null;
		String appMsg = null;
		appMsg = agGetText(CommonObjects.applicationMessage);
		String[] resultText = appMsg.split("'");
		lrnNumber = resultText[3];
		return lrnNumber;
	}

	/**********************************************************************************************************
	 * @Objective: To Upload Edit Case Supporting documents.
	 * @Input Parameters: scenarioName
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 28-August-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setEditCaseSupportingDocuments(String scenarioName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		agSetStepExecutionDelay("2000");
		agClick(InboundGeneralDetailsObjects.expandCollapseDocWindowBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));
		String supportingDocFileName = Multimaplibraries.getTestDataCellValue(scenarioName, "SupportingDocuments");
		String[] multipleSuppDocs = supportingDocFileName.split(",");
		if (multipleSuppDocs.length == 0) {
			agClick(InboundGeneralDetailsObjects.editCaseSuppDocUploadFileBtn);
			agClick(InboundGeneralDetailsObjects.editCaseSuppDocUploadBtn);
			agUploadDocuments(lsitstConstants.LSITST_FileUploadPath + multipleSuppDocs);
			agSetGlobalTimeOut("300000");
			agAssertVisible(CommonObjects.containsLinkText(multipleSuppDocs[0]));
			// agWaitTillInvisibilityOfElement(InboundGeneralDetailsObjects.editCaseFileUploadingIcon);
			agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
			// agAssertVisible(InboundGeneralDetailsObjects.editCaseSuppDocUploadedLink);

		} else {
			for (int i = 0; i < multipleSuppDocs.length; i++) {
				agClick(InboundGeneralDetailsObjects.editCaseSuppDocUploadFileBtn);
				agClick(InboundGeneralDetailsObjects.editCaseSuppDocUploadBtn);
				agUploadDocuments(lsitstConstants.LSITST_FileUploadPath + multipleSuppDocs[i]);
				// agWaitTillInvisibilityOfElement(InboundGeneralDetailsObjects.editCaseFileUploadingIcon);
				agSetGlobalTimeOut("300000");
				agAssertVisible(CommonObjects.containsLinkText(multipleSuppDocs[i]));
				agSetGlobalTimeOut(String.valueOf(Constants.defaultGlobalTimeOut));
				// agAssertVisible(InboundGeneralDetailsObjects.editCaseSuppDocUploadedLink);

			}
		}
		Reports.ExtentReportLog("Supporting Documents", Status.INFO, "Added Supporting Documents", true);
		agSetStepExecutionDelay("2000");
		agClick(InboundGeneralDetailsObjects.expandCollapseDocWindowBtn);
		agSetStepExecutionDelay(String.valueOf(Constants.defaultGlobalStepExecutionDelay));

	}

	/**********************************************************************************************************
	 * @Objective: Write Data into respective component.
	 * @Input Parameters: scenarioName, columnName, data.
	 * @Output Parameters: NA
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setData(String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lsitstConstants.LSITST_testData, className, scenarioName, columnName, data);
	}

	/**********************************************************************************************************
	 * @Objective: Get respective component data.
	 * @Input Parameters: scenarioName, columnName.
	 * @Output Parameters: Return individual cell data.
	 * @author: Naresh S
	 * @Date : 09-July-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static String getData(String scenarioName, String columnName) {
		Multimaplibraries.getTestData(lsitstConstants.LSITST_testData, className);
		return Multimaplibraries.getTestDataCellValue(scenarioName, columnName);
	}
}
