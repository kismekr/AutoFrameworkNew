package com.arisglobal.framework.components.lsitst;

import com.arisglobal.framework.lib.main.ToolManager;
import com.arisglobal.framework.lib.utils.generic.XlsReader;
import com.arisglobal.lssmvConfig.lssmvConstants;

public class LSSMVTestData extends ToolManager {

	/**********************************************************************************************************
	 * @Objective: This method is created to write data into LSSMV data sheet.
	 * @Input Parameters: LSSMV Component name, Scenario Name, Column Name, Data
	 * @Output Parameters: Write's data into LSSMV data sheet
	 * @author: Naresh S
	 * @Date : 03-09-2019
	 * @Updated by and when:
	 **********************************************************************************************************/
	public static void setLSSMVData(String LSSMVComponentName, String scenarioName, String columnName, String data) {
		XlsReader.writeToTestData(lssmvConstants.LSSMV_testData, LSSMVComponentName, scenarioName, columnName, data);
	}

}
